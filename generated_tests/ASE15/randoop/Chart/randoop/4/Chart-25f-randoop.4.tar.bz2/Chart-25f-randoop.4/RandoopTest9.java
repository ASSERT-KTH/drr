
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    java.awt.Stroke var4 = null;
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets(12.0d, (-1.0d), 1.0d, 12.0d);
    double var11 = var9.calculateLeftOutset(0.0d);
    double var12 = var9.getTop();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var13 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var2, var4, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 12.0d);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, (-1.0d), (-1.0f), 10.0f);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets(12.0d, (-1.0d), 1.0d, 12.0d);
    double var9 = var7.calculateLeftOutset(0.0d);
    boolean var10 = var2.equals((java.lang.Object)0.0d);
    java.lang.String var11 = var2.getShapeCoords();
    var2.setToolTipText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "0,-1,-1,1,1,1,1,1"+ "'", var11.equals("0,-1,-1,1,1,1,1,1"));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("hi!", "", "0,-1,-1,1,1,1,1,1", "hi!", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("0,-1,-1,1,1,1,1,1", var1, (-1.0f), (-1.0f), var4, 1.0d, var6);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1");

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 100.0d, var2);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("", var1);
//     
//     // Checks the contract:  var2.equals(var2)
//     assertTrue("Contract failed: var2.equals(var2)", var2.equals(var2));
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 10.0d, (-1.0d), var3);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 1.0f, 100.0f);
    java.awt.Stroke var14 = null;
    java.awt.Color var17 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var18 = null;
    java.awt.Rectangle var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem(var0, "", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", var9, var14, (java.awt.Paint)var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, (java.awt.Paint)var4, 100.0f, 10, var7);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.awt.Color var16 = java.awt.Color.getColor("", 0);
    int var17 = var16.getGreen();
    float[] var18 = null;
    float[] var19 = var16.getColorComponents(var18);
    float[] var20 = var4.getRGBColorComponents(var18);
    org.jfree.data.general.Dataset var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.DatasetChangeEvent var22 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var18, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 100.0d);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", var3);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var9 = null;
    java.awt.Rectangle var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.awt.geom.AffineTransform var12 = null;
    java.awt.RenderingHints var13 = null;
    java.awt.PaintContext var14 = var8.createContext(var9, var10, var11, var12, var13);
    java.awt.Stroke var15 = null;
    java.awt.Paint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "0,-1,-1,1,1,1,1,1", var5, (java.awt.Paint)var8, var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    double var3 = var2.getLength();
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var5, 100, 10);
    org.jfree.chart.JFreeChart var9 = null;
    var8.setChart(var9);
    var8.setPercent((-1));
    boolean var13 = var2.equals((java.lang.Object)var8);
    double var14 = var2.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }


    int var3 = java.awt.Color.HSBtoRGB(10.0f, 100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-33));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateTopInset(10.0d);
    double var10 = var4.calculateRightInset(100.0d);
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var14 = var4.createOutsetRectangle(var11, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    float[] var3 = null;
    float[] var4 = java.awt.Color.RGBtoHSB(10, 10, 0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }


    java.awt.Font var2 = null;
    java.awt.Color var5 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var6 = null;
    java.awt.Rectangle var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    java.awt.geom.AffineTransform var9 = null;
    java.awt.RenderingHints var10 = null;
    java.awt.PaintContext var11 = var5.createContext(var6, var7, var8, var9, var10);
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, (java.awt.Paint)var5);
    org.jfree.chart.text.TextBlockAnchor var13 = null;
    org.jfree.chart.text.TextAnchor var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var16 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)1, var12, var13, var14, 12.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 100, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("0,-1,-1,1,1,1,1,1", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var1, 100, 10);
    org.jfree.chart.JFreeChart var5 = null;
    var4.setChart(var5);
    var4.setPercent((-1));
    var4.setPercent(0);
    java.lang.Object var11 = var4.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 10.0d+ "'", var11.equals(10.0d));

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateLeftInset(0.0d);
    double var9 = var4.getRight();
    double var11 = var4.extendHeight(1.0d);
    java.awt.geom.Rectangle2D var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var13 = var4.createInsetRectangle(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    java.awt.geom.Rectangle2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var4.createOutsetRectangle(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateLeftInset(0.0d);
    double var9 = var4.getRight();
    double var11 = var4.extendHeight(1.0d);
    org.jfree.chart.util.UnitType var12 = var4.getUnitType();
    org.jfree.chart.util.Size2D var15 = new org.jfree.chart.util.Size2D(10.0d, 14.0d);
    java.lang.Object var16 = var15.clone();
    boolean var17 = var12.equals(var16);
    java.lang.Object var18 = null;
    boolean var19 = var12.equals(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.awt.Color var16 = java.awt.Color.getColor("", 0);
    int var17 = var16.getGreen();
    float[] var18 = null;
    float[] var19 = var16.getColorComponents(var18);
    boolean var21 = var16.equals((java.lang.Object)1.0d);
    java.awt.Font var23 = null;
    java.awt.Color var26 = java.awt.Color.getColor("", 0);
    int var27 = var26.getGreen();
    float[] var28 = null;
    float[] var29 = var26.getColorComponents(var28);
    boolean var31 = var26.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var34 = null;
    org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, (java.awt.Paint)var26, 0.0f, 10, var34);
    java.awt.Color var38 = java.awt.Color.getColor("", 0);
    int var39 = var38.getGreen();
    float[] var40 = null;
    float[] var41 = var38.getColorComponents(var40);
    float[] var42 = var26.getRGBColorComponents(var40);
    float[] var43 = var16.getColorComponents(var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var44 = var4.getComponents(var42);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 10.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateTopInset(10.0d);
    double var10 = var4.calculateLeftInset(12.0d);
    double var11 = var4.getBottom();
    double var13 = var4.trimHeight(100.0d);
    java.awt.geom.Rectangle2D var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var15 = var4.createOutsetRectangle(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 102.0d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, (-33), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    java.awt.Paint[] var6 = new java.awt.Paint[] { var2};
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    java.awt.Paint[] var11 = new java.awt.Paint[] { var9};
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var25};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var11, var13, var15, var26);
    java.awt.Paint[] var28 = null;
    java.awt.Stroke var29 = null;
    java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
    java.awt.Stroke var31 = null;
    java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
    java.awt.Color var35 = java.awt.Color.getColor("", 0);
    int var36 = var35.getGreen();
    float[] var37 = null;
    float[] var38 = var35.getColorComponents(var37);
    java.awt.Paint[] var39 = new java.awt.Paint[] { var35};
    java.awt.Color var42 = java.awt.Color.getColor("", 0);
    int var43 = var42.getGreen();
    java.awt.Paint[] var44 = new java.awt.Paint[] { var42};
    java.awt.Stroke var45 = null;
    java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
    java.awt.Stroke var47 = null;
    java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.rotateShape(var50, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.rotateShape(var54, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var59 = new java.awt.Shape[] { var58};
    org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier(var39, var44, var46, var48, var59);
    org.jfree.chart.plot.DefaultDrawingSupplier var61 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var28, var30, var32, var59);
    java.awt.Stroke var62 = var61.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var4 = new org.jfree.data.Range(0.0d, 0.0d);
    double var5 = var4.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0d, var4);
    org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
    double var10 = var9.getLength();
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var12, 100, 10);
    org.jfree.chart.JFreeChart var16 = null;
    var15.setChart(var16);
    var15.setPercent((-1));
    boolean var20 = var9.equals((java.lang.Object)var15);
    org.jfree.chart.block.RectangleConstraint var21 = var6.toRangeHeight(var9);
    org.jfree.data.Range var22 = org.jfree.data.Range.combine(var0, var9);
    java.lang.Object var23 = null;
    boolean var24 = var9.equals(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Stroke var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("", 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("0,-1,-1,1,1,1,1,1", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "0,-1,-1,1,1,1,1,1", "", var10, var11, (java.awt.Paint)var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 1);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateLeftInset(0.0d);
    double var10 = var4.trimHeight(12.0d);
    double var12 = var4.calculateTopInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1.0d));

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 10.0d};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (short)0};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-1));
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.block.Arrangement var1 = null;
    org.jfree.chart.block.Arrangement var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, (-1.0f), 10.0f, 10.0d, 1.0f, 0.0f);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)1);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "");
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var2, "", "");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPadding(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    double var6 = var4.calculateLeftOutset(14.0d);
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var13 = var11.trimHeight(10.0d);
    double var15 = var11.calculateTopInset(10.0d);
    double var17 = var11.calculateLeftInset(12.0d);
    double var18 = var11.getBottom();
    boolean var19 = var4.equals((java.lang.Object)var18);
    java.awt.geom.Rectangle2D var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var21 = var4.createInsetRectangle(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.Plot var2 = null;
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("0,-1,-1,1,1,1,1,1", var1, var2, false);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    double var6 = var4.calculateLeftOutset(14.0d);
    double var8 = var4.calculateRightOutset(14.0d);
    java.awt.geom.Rectangle2D var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var4.createOutsetRectangle(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 12.0d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets(12.0d, (-1.0d), 1.0d, 12.0d);
    double var9 = var7.calculateLeftOutset(0.0d);
    boolean var10 = var2.equals((java.lang.Object)0.0d);
    java.lang.String var11 = var2.getShapeCoords();
    java.lang.String var12 = var2.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "0,-1,-1,1,1,1,1,1"+ "'", var11.equals("0,-1,-1,1,1,1,1,1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "0,-1,-1,1,1,1,1,1"+ "'", var12.equals("0,-1,-1,1,1,1,1,1"));

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    var4.addOptionalLibrary("");
    org.jfree.chart.ui.BasicProjectInfo var12 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var13 = var12.getVersion();
    var12.addOptionalLibrary("");
    var4.addOptionalLibrary((org.jfree.chart.ui.Library)var12);
    java.lang.String var17 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var13.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var17.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var3.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(1.0d, var3);
    org.jfree.chart.block.RectangleConstraint var7 = var5.toFixedHeight(14.0d);
    org.jfree.data.Range var8 = var7.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-33));
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    org.jfree.chart.text.TextLine var14 = null;
    var13.addLine(var14);
    java.awt.Font var17 = null;
    java.awt.Color var20 = java.awt.Color.getColor("", 0);
    int var21 = var20.getGreen();
    float[] var22 = null;
    float[] var23 = var20.getColorComponents(var22);
    java.awt.Color var24 = var20.brighter();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.addLine("", var17, (java.awt.Paint)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.ChartProgressEvent[source=10.0]", var1);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    var4.addOptionalLibrary("");
    var4.setLicenceName("0,-1,-1,1,1,1,1,1");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getCopyright();
    java.lang.String var6 = var4.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var6.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var1);
    org.jfree.data.general.Dataset var4 = null;
    var3.setDataset(var4);
    java.lang.Object var6 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(byte)1, var1);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    float[] var11 = null;
    float[] var12 = var9.getColorComponents(var11);
    java.awt.Color var13 = var9.brighter();
    java.awt.Stroke var14 = null;
    java.awt.Font var16 = null;
    java.awt.Color var19 = java.awt.Color.getColor("", 0);
    int var20 = var19.getGreen();
    float[] var21 = null;
    float[] var22 = var19.getColorComponents(var21);
    boolean var24 = var19.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var27 = null;
    org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var19, 0.0f, 10, var27);
    int var29 = var19.getTransparency();
    java.awt.Color var30 = var19.darker();
    java.awt.Color var31 = var30.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("", "", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "0,-1,-1,1,1,1,1,1", var5, (java.awt.Paint)var13, var14, (java.awt.Paint)var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    int var9 = var8.getGreen();
    float[] var10 = null;
    float[] var11 = var8.getColorComponents(var10);
    boolean var13 = var8.equals((java.lang.Object)1.0d);
    java.awt.Font var15 = null;
    java.awt.Color var18 = java.awt.Color.getColor("", 0);
    int var19 = var18.getGreen();
    float[] var20 = null;
    float[] var21 = var18.getColorComponents(var20);
    boolean var23 = var18.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var26 = null;
    org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("", var15, (java.awt.Paint)var18, 0.0f, 10, var26);
    java.awt.Color var30 = java.awt.Color.getColor("", 0);
    int var31 = var30.getGreen();
    float[] var32 = null;
    float[] var33 = var30.getColorComponents(var32);
    float[] var34 = var18.getRGBColorComponents(var32);
    float[] var35 = var8.getColorComponents(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem(var0, "hi!", "0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1", var4, var5, (java.awt.Paint)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("0,-1,-1,1,1,1,1,1", var1, 1.0f, 1.0f, var4);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    java.awt.Color var6 = var2.brighter();
    int var7 = var6.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    var4.addOptionalLibrary("");
    org.jfree.chart.ui.BasicProjectInfo var12 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var13 = var12.getVersion();
    var12.addOptionalLibrary("");
    var4.addOptionalLibrary((org.jfree.chart.ui.Library)var12);
    var4.setLicenceName("0,-1,-1,1,1,1,1,1");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var13.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", var3);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "");
    java.lang.String var6 = var5.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "poly"+ "'", var6.equals("poly"));

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    java.awt.Paint[] var6 = new java.awt.Paint[] { var2};
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    java.awt.Paint[] var11 = new java.awt.Paint[] { var9};
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var25};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var11, var13, var15, var26);
    java.awt.Paint var28 = var27.getNextFillPaint();
    java.awt.Paint var29 = var27.getNextOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("", 0);
//     int var5 = var4.getGreen();
//     float[] var6 = null;
//     float[] var7 = var4.getColorComponents(var6);
//     boolean var9 = var4.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
//     org.jfree.chart.text.TextLine var14 = null;
//     var13.addLine(var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.text.TextBlockAnchor var19 = null;
//     var13.draw(var16, 10.0f, 0.0f, var19, (-1.0f), 100.0f, (-1.0d));
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 100.0f, (-1.0f), 100.0d, 1.0f, 1.0f);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, var1);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var1);
    org.jfree.data.general.Dataset var4 = null;
    var3.setDataset(var4);
    var3.setURLText("poly");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("poly", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(12.0d, (-1.0d), 1.0d, 12.0d);
    double var6 = var4.calculateLeftOutset(0.0d);
    double var7 = var4.getTop();
    double var9 = var4.calculateRightOutset(12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 12.0d);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }
// 
// 
//     java.awt.Font var5 = null;
//     java.awt.Color var8 = java.awt.Color.getColor("", 0);
//     int var9 = var8.getGreen();
//     float[] var10 = null;
//     float[] var11 = var8.getColorComponents(var10);
//     boolean var13 = var8.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var8, 0.0f, 10, var16);
//     java.awt.Color var20 = java.awt.Color.getColor("", 0);
//     int var21 = var20.getGreen();
//     float[] var22 = null;
//     float[] var23 = var20.getColorComponents(var22);
//     float[] var24 = var8.getRGBColorComponents(var22);
//     int var25 = var8.getGreen();
//     org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 14.0d, (java.awt.Paint)var8);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     var26.draw(var27, var28);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    double var6 = var4.calculateLeftOutset(14.0d);
    double var8 = var4.extendWidth(12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 25.0d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(10.0d, 14.0d);
    double var3 = var2.getHeight();
    java.lang.String var4 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Size2D[width=10.0, height=14.0]"+ "'", var4.equals("Size2D[width=10.0, height=14.0]"));

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var7 = new org.jfree.chart.entity.LegendItemEntity(var6);
    java.awt.Stroke var8 = null;
    java.awt.Font var10 = null;
    java.awt.Color var13 = java.awt.Color.getColor("", 0);
    int var14 = var13.getGreen();
    float[] var15 = null;
    float[] var16 = var13.getColorComponents(var15);
    boolean var18 = var13.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var21 = null;
    org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, (java.awt.Paint)var13, 0.0f, 10, var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("LegendItemEntity: seriesKey=null, dataset=null", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "LegendItemEntity: seriesKey=null, dataset=null", "0,-1,-1,1,1,1,1,1", var6, var8, (java.awt.Paint)var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var1);
    var3.setToolTipText("");
    java.lang.Object var6 = var3.clone();
    org.jfree.data.general.Dataset var7 = var3.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var4 = new org.jfree.data.Range(0.0d, 0.0d);
    double var5 = var4.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0d, var4);
    org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
    double var10 = var9.getLength();
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var12, 100, 10);
    org.jfree.chart.JFreeChart var16 = null;
    var15.setChart(var16);
    var15.setPercent((-1));
    boolean var20 = var9.equals((java.lang.Object)var15);
    org.jfree.chart.block.RectangleConstraint var21 = var6.toRangeHeight(var9);
    org.jfree.data.Range var22 = org.jfree.data.Range.combine(var0, var9);
    org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 0.0d);
    double var27 = var26.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(1.0d, var26);
    org.jfree.data.Range var29 = org.jfree.data.Range.combine(var22, var26);
    org.jfree.data.general.Dataset var30 = null;
    org.jfree.data.general.DatasetChangeEvent var31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var22, var30);
    double var32 = var22.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    org.jfree.chart.text.TextLine var14 = null;
    var13.addLine(var14);
    java.awt.Font var17 = null;
    java.awt.Font var19 = null;
    java.awt.Color var22 = java.awt.Color.getColor("", 0);
    int var23 = var22.getGreen();
    float[] var24 = null;
    float[] var25 = var22.getColorComponents(var24);
    boolean var27 = var22.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var30 = null;
    org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, (java.awt.Paint)var22, 0.0f, 10, var30);
    int var32 = var22.getTransparency();
    java.awt.Color var33 = var22.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.addLine("LegendItemEntity: seriesKey=null, dataset=null", var17, (java.awt.Paint)var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 0.0d, (-1.0f), 100.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, 1.0d, 0.0f, 1.0f);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)(short)0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)0, "", var2, var3, 14.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 0.0d, 1.0f, 100.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 0.0d, 1.0f, 100.0f);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var5, var15);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var15, "poly");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var3);
    org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var7 = var6.getType();
    var4.setType(var7);
    org.jfree.data.Range var11 = new org.jfree.data.Range(0.0d, 0.0d);
    double var12 = var11.getUpperBound();
    double var13 = var11.getCentralValue();
    org.jfree.data.general.Dataset var14 = null;
    org.jfree.data.general.DatasetChangeEvent var15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var11, var14);
    boolean var16 = var7.equals((java.lang.Object)var11);
    java.lang.Object var17 = null;
    boolean var18 = var7.equals(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateLeftInset(0.0d);
    double var9 = var4.getRight();
    double var11 = var4.extendHeight(1.0d);
    double var13 = var4.trimHeight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(10.0d, 14.0d);
    java.lang.Object var3 = var2.clone();
    double var4 = var2.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 14.0d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }


    java.awt.Color var1 = java.awt.Color.getColor("poly");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }


    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.TickLabelEntity var10 = new org.jfree.chart.entity.TickLabelEntity(var7, "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "");
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, 10.0d, 102.0d);
    java.awt.Font var16 = null;
    java.awt.Color var19 = java.awt.Color.getColor("", 0);
    int var20 = var19.getGreen();
    float[] var21 = null;
    float[] var22 = var19.getColorComponents(var21);
    boolean var24 = var19.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var27 = null;
    org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var19, 0.0f, 10, var27);
    int var29 = var19.getTransparency();
    java.awt.Color var30 = var19.darker();
    java.awt.Color var34 = java.awt.Color.getColor("", 0);
    int var35 = var34.getGreen();
    float[] var36 = null;
    float[] var37 = var34.getColorComponents(var36);
    boolean var39 = var34.equals((java.lang.Object)1.0d);
    java.awt.Font var41 = null;
    java.awt.Color var44 = java.awt.Color.getColor("", 0);
    int var45 = var44.getGreen();
    float[] var46 = null;
    float[] var47 = var44.getColorComponents(var46);
    boolean var49 = var44.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var52 = null;
    org.jfree.chart.text.TextBlock var53 = org.jfree.chart.text.TextUtilities.createTextBlock("", var41, (java.awt.Paint)var44, 0.0f, 10, var52);
    java.awt.Color var56 = java.awt.Color.getColor("", 0);
    int var57 = var56.getGreen();
    float[] var58 = null;
    float[] var59 = var56.getColorComponents(var58);
    float[] var60 = var44.getRGBColorComponents(var58);
    float[] var61 = var34.getColorComponents(var60);
    java.awt.Stroke var62 = null;
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var66, 1.0d, 14.0d);
    java.awt.Stroke var70 = null;
    java.awt.Font var72 = null;
    java.awt.Color var75 = java.awt.Color.getColor("", 0);
    int var76 = var75.getGreen();
    float[] var77 = null;
    float[] var78 = var75.getColorComponents(var77);
    boolean var80 = var75.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var83 = null;
    org.jfree.chart.text.TextBlock var84 = org.jfree.chart.text.TextUtilities.createTextBlock("", var72, (java.awt.Paint)var75, 0.0f, 10, var83);
    int var85 = var75.getTransparency();
    java.awt.Color var86 = var75.darker();
    java.awt.Color var87 = var86.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var88 = new org.jfree.chart.LegendItem("LegendItemEntity: seriesKey=null, dataset=null", "", "poly", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", true, var13, true, (java.awt.Paint)var30, true, (java.awt.Paint)var34, var62, false, var66, var70, (java.awt.Paint)var86);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }


    java.awt.Color var5 = java.awt.Color.getColor("", 0);
    int var6 = var5.getGreen();
    float[] var7 = null;
    float[] var8 = var5.getColorComponents(var7);
    boolean var10 = var5.equals((java.lang.Object)1.0d);
    java.awt.Font var12 = null;
    java.awt.Color var15 = java.awt.Color.getColor("", 0);
    int var16 = var15.getGreen();
    float[] var17 = null;
    float[] var18 = var15.getColorComponents(var17);
    boolean var20 = var15.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var23 = null;
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var15, 0.0f, 10, var23);
    java.awt.Color var27 = java.awt.Color.getColor("", 0);
    int var28 = var27.getGreen();
    float[] var29 = null;
    float[] var30 = var27.getColorComponents(var29);
    float[] var31 = var15.getRGBColorComponents(var29);
    float[] var32 = var5.getColorComponents(var31);
    float[] var33 = java.awt.Color.RGBtoHSB((-1), 0, 1, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 1);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }


    java.lang.Object var0 = null;
    java.lang.Object var1 = null;
    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 1.0d, 14.0d);
    org.jfree.chart.util.RectangleAnchor var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var6, 25.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }


    java.lang.Comparable var0 = null;
    java.awt.Font var2 = null;
    java.awt.Color var5 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var6 = null;
    java.awt.Rectangle var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    java.awt.geom.AffineTransform var9 = null;
    java.awt.RenderingHints var10 = null;
    java.awt.PaintContext var11 = var5.createContext(var6, var7, var8, var9, var10);
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, (java.awt.Paint)var5);
    org.jfree.chart.text.TextBlockAnchor var13 = null;
    org.jfree.chart.text.TextAnchor var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var16 = new org.jfree.chart.axis.CategoryTick(var0, var12, var13, var14, 12.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    org.jfree.chart.ui.Library[] var6 = var4.getOptionalLibraries();
    java.lang.String var7 = var4.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "hi!"+ "'", var7.equals("hi!"));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.lang.Object var18 = var17.clone();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var21 = var17.arrange(var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"LegendItemEntity: seriesKey=null, dataset=null", 1.0d, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var1, var2);
    org.jfree.chart.JFreeChart var4 = null;
    var3.setChart(var4);
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var13 = var12.getType();
    var10.setType(var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var18 = new org.jfree.chart.entity.LegendItemEntity(var17);
    boolean var19 = var13.equals((java.lang.Object)var18);
    var3.setType(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var1);
    org.jfree.data.general.Dataset var4 = null;
    var3.setDataset(var4);
    org.jfree.data.general.Dataset var6 = null;
    var3.setDataset(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Size2D[width=10.0, height=14.0]", var3);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("poly", var1, 10.0f, 0.0f, var4, 25.0d, (-1.0f), 100.0f);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (-1));
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    int var17 = var7.getTransparency();
    java.awt.Color var18 = var7.darker();
    java.awt.Stroke var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d, var1, var2, (java.awt.Paint)var7, var19, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var8 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var9 = null;
//     org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
//     var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
//     org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
//     var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var16 = var1.getBounds();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var26 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var27 = null;
//     org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var27);
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var26);
//     var19.setFrame((org.jfree.chart.block.BlockFrame)var29);
//     org.jfree.chart.block.BlockFrame var31 = var19.getFrame();
//     var19.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var34 = var19.getBounds();
//     org.jfree.chart.util.RectangleAnchor var35 = null;
//     java.awt.geom.Point2D var36 = org.jfree.chart.util.RectangleAnchor.coordinates(var34, var35);
//     java.lang.Object var37 = null;
//     java.lang.Object var38 = var1.draw(var17, var34, var37);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    java.lang.String var6 = var4.getVersion();
    org.jfree.chart.ui.Library[] var7 = var4.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var6.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(14.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 25.0d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.LegendItemEntity var2 = new org.jfree.chart.entity.LegendItemEntity(var1);
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var3.equals("LegendItemEntity: seriesKey=null, dataset=null"));

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 1.0f, 100.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, 1.0f, 100.0f);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var9, var19);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    java.awt.Stroke var26 = null;
    java.awt.Font var28 = null;
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    int var32 = var31.getGreen();
    float[] var33 = null;
    float[] var34 = var31.getColorComponents(var33);
    boolean var36 = var31.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var39 = null;
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var31, 0.0f, 10, var39);
    int var41 = var31.getTransparency();
    java.awt.Color var42 = var31.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "0,-1,-1,1,1,1,1,1", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var25, var26, (java.awt.Paint)var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, (-1.0f));
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    var1.setUpperMargin(100.0d);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var8 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var9 = null;
//     org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
//     var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
//     org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
//     var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var16 = var1.getBounds();
//     org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var25 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var26 = null;
//     org.jfree.chart.event.ChartChangeEvent var27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var25, var26);
//     org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var25);
//     var18.setFrame((org.jfree.chart.block.BlockFrame)var28);
//     org.jfree.chart.block.BlockFrame var30 = var18.getFrame();
//     var18.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var33 = var18.getBounds();
//     org.jfree.chart.util.RectangleAnchor var34 = null;
//     java.awt.geom.Point2D var35 = org.jfree.chart.util.RectangleAnchor.coordinates(var33, var34);
//     boolean var36 = org.jfree.chart.util.ShapeUtilities.intersects(var16, var33);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var28
//     assertTrue("Contract failed: equals-hashcode on var11 and var28", var11.equals(var28) ? var11.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var11
//     assertTrue("Contract failed: equals-hashcode on var28 and var11", var28.equals(var11) ? var28.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var30
//     assertTrue("Contract failed: equals-hashcode on var13 and var30", var13.equals(var30) ? var13.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var13
//     assertTrue("Contract failed: equals-hashcode on var30 and var13", var30.equals(var13) ? var30.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 10.0d, 1.0d, (-33), (java.lang.Comparable)' ');
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var3.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(1.0d, var3);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    double var9 = var3.constrain(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var8 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var9 = null;
//     org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
//     var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
//     org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
//     var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var16 = var1.getBounds();
//     java.awt.geom.Rectangle2D var17 = null;
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.contains(var16, var17);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var1);
    var3.setToolTipText("");
    java.lang.Comparable var6 = var3.getSeriesKey();
    java.lang.String var7 = var3.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "0,-1,-1,1,1,1,1,1"+ "'", var7.equals("0,-1,-1,1,1,1,1,1"));

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    java.awt.Paint[] var6 = new java.awt.Paint[] { var2};
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    java.awt.Paint[] var11 = new java.awt.Paint[] { var9};
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var25};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var11, var13, var15, var26);
    java.awt.Shape var28 = var27.getNextShape();
    java.awt.Stroke var29 = var27.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LegendItemEntity: seriesKey=null, dataset=null", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var1);
    var3.setToolTipText("");
    java.lang.Comparable var6 = var3.getSeriesKey();
    org.jfree.data.general.Dataset var7 = var3.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TickLabelEntity var3 = new org.jfree.chart.entity.TickLabelEntity(var0, "Size2D[width=10.0, height=14.0]", "0,-1,-1,1,1,1,1,1");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    java.lang.String var6 = var4.getLicenceName();
    java.lang.String var7 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "hi!"+ "'", var6.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var7.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.chart.event.ChartProgressEvent[source=10.0]", var1, 100.0f, 100.0f, 25.0d, 10.0f, (-1.0f));
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 100.0f, 0.0f, var4, 14.0d, var6);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("", 0);
//     int var5 = var4.getGreen();
//     float[] var6 = null;
//     float[] var7 = var4.getColorComponents(var6);
//     boolean var9 = var4.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
//     java.util.List var14 = var13.getLines();
//     org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var20 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
//     org.jfree.data.general.Dataset var23 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var23, (java.lang.Comparable)(-33));
//     
//     // Checks the contract:  equals-hashcode on var22 and var25
//     assertTrue("Contract failed: equals-hashcode on var22 and var25", var22.equals(var25) ? var22.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var22
//     assertTrue("Contract failed: equals-hashcode on var25 and var22", var25.equals(var22) ? var25.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("", 0);
//     int var5 = var4.getGreen();
//     float[] var6 = null;
//     float[] var7 = var4.getColorComponents(var6);
//     boolean var9 = var4.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
//     java.util.List var14 = var13.getLines();
//     org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var20 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("hi!");
//     org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var34 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var35 = null;
//     org.jfree.chart.event.ChartChangeEvent var36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var34, var35);
//     org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var34);
//     var27.setFrame((org.jfree.chart.block.BlockFrame)var37);
//     org.jfree.chart.block.BlockFrame var39 = var27.getFrame();
//     var27.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var42 = var27.getBounds();
//     var25.setBounds(var42);
//     org.jfree.data.Range var46 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var47 = var46.getLength();
//     org.jfree.chart.JFreeChart var49 = null;
//     org.jfree.chart.event.ChartProgressEvent var52 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var49, 100, 10);
//     org.jfree.chart.JFreeChart var53 = null;
//     var52.setChart(var53);
//     var52.setPercent((-1));
//     boolean var57 = var46.equals((java.lang.Object)var52);
//     java.lang.Object var58 = var22.draw(var23, var42, (java.lang.Object)var52);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
    var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    double var16 = var1.getContentXOffset();
    double var17 = var1.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateTopInset(10.0d);
    double var10 = var4.calculateLeftInset(12.0d);
    double var11 = var4.getBottom();
    double var13 = var4.calculateBottomInset(102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.0d));

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Font var4 = null;
//     java.awt.Color var7 = java.awt.Color.getColor("", 0);
//     int var8 = var7.getGreen();
//     float[] var9 = null;
//     float[] var10 = var7.getColorComponents(var9);
//     boolean var12 = var7.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var15 = null;
//     org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
//     org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
//     boolean var18 = var17.isShapeOutlineVisible();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
//     org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("hi!");
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var37 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var38 = null;
//     org.jfree.chart.event.ChartChangeEvent var39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var37, var38);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var37);
//     var30.setFrame((org.jfree.chart.block.BlockFrame)var40);
//     org.jfree.chart.block.BlockFrame var42 = var30.getFrame();
//     var30.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var45 = var30.getBounds();
//     var28.setBounds(var45);
//     var17.draw(var26, var45);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.text.TextBlockAnchor var19 = null;
    java.awt.Shape var23 = var13.calculateBounds(var16, 1.0f, (-1.0f), var19, (-1.0f), 0.0f, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    double var13 = var1.getContentYOffset();
    double var14 = var1.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
    var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    double var16 = var1.getContentXOffset();
    var1.setWidth(14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    double var26 = var25.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 12.0d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-33));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
    java.lang.String var14 = var1.getToolTipText();
    var1.setToolTipText("poly");
    org.jfree.chart.block.BlockFrame var17 = var1.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.Graphics2D var23 = null;
    org.jfree.data.Range var25 = null;
    org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(10.0d, var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var27 = var22.arrange(var23, var26);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "");
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 10.0d, 102.0d);
    org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var8, "", "0,-1,-1,1,1,1,1,1");
    org.jfree.chart.entity.TickLabelEntity var14 = new org.jfree.chart.entity.TickLabelEntity(var8, "", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    java.awt.Paint[] var6 = new java.awt.Paint[] { var2};
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    java.awt.Paint[] var11 = new java.awt.Paint[] { var9};
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var25};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var11, var13, var15, var26);
    java.awt.Image var31 = null;
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1", "poly", var31, "0,-1,-1,1,1,1,1,1", "", "");
    org.jfree.chart.ui.Library[] var36 = var35.getLibraries();
    boolean var37 = var27.equals((java.lang.Object)var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    org.jfree.chart.util.RectangleAnchor var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setShapeAnchor(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var3.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(1.0d, var3);
    org.jfree.data.Range var8 = new org.jfree.data.Range(0.0d, 0.0d);
    double var9 = var8.getLength();
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartProgressEvent var14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var11, 100, 10);
    org.jfree.chart.JFreeChart var15 = null;
    var14.setChart(var15);
    var14.setPercent((-1));
    boolean var19 = var8.equals((java.lang.Object)var14);
    org.jfree.chart.block.RectangleConstraint var20 = var5.toRangeHeight(var8);
    org.jfree.chart.JFreeChart var21 = null;
    org.jfree.chart.event.ChartProgressEvent var24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var20, var21, 3, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var6.axisChanged(var7);
    var6.setDrawSharedDomainAxis(false);
    org.jfree.chart.plot.CategoryMarker var12 = null;
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(0, var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    var4.addOptionalLibrary("0,-1,-1,1,1,1,1,1");
    var4.addOptionalLibrary("LegendItemEntity: seriesKey=null, dataset=null");

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var3);
    int var5 = var2.getRed();
    java.awt.Stroke var6 = null;
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var13 = var11.trimHeight(10.0d);
    double var15 = var11.calculateTopInset(10.0d);
    double var17 = var11.calculateLeftInset(12.0d);
    double var18 = var11.getBottom();
    double var20 = var11.trimHeight(100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var2, var6, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 102.0d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var19 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var20 = null;
//     org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var19, var20);
//     org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var19);
//     var12.setFrame((org.jfree.chart.block.BlockFrame)var22);
//     org.jfree.chart.block.BlockFrame var24 = var12.getFrame();
//     var12.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var27 = var12.getBounds();
//     org.jfree.chart.util.RectangleAnchor var28 = null;
//     java.awt.geom.Point2D var29 = org.jfree.chart.util.RectangleAnchor.coordinates(var27, var28);
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var38 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var39 = null;
//     org.jfree.chart.event.ChartChangeEvent var40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var38, var39);
//     org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var38);
//     var31.setFrame((org.jfree.chart.block.BlockFrame)var41);
//     org.jfree.chart.block.BlockFrame var43 = var31.getFrame();
//     var31.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var46 = var31.getBounds();
//     org.jfree.chart.util.RectangleAnchor var47 = null;
//     java.awt.geom.Point2D var48 = org.jfree.chart.util.RectangleAnchor.coordinates(var46, var47);
//     org.jfree.chart.plot.PlotState var49 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     var6.draw(var10, var27, var48, var49, var50);
//     
//     // Checks the contract:  equals-hashcode on var12 and var31
//     assertTrue("Contract failed: equals-hashcode on var12 and var31", var12.equals(var31) ? var12.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var12
//     assertTrue("Contract failed: equals-hashcode on var31 and var12", var31.equals(var12) ? var31.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var41
//     assertTrue("Contract failed: equals-hashcode on var22 and var41", var22.equals(var41) ? var22.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var22
//     assertTrue("Contract failed: equals-hashcode on var41 and var22", var41.equals(var22) ? var41.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var43
//     assertTrue("Contract failed: equals-hashcode on var24 and var43", var24.equals(var43) ? var24.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var24
//     assertTrue("Contract failed: equals-hashcode on var43 and var24", var43.equals(var24) ? var43.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(3);
    java.lang.Object var2 = null;
    int var3 = var1.indexOf(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var4 = new org.jfree.data.Range(0.0d, 0.0d);
    double var5 = var4.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0d, var4);
    org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
    double var10 = var9.getLength();
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var12, 100, 10);
    org.jfree.chart.JFreeChart var16 = null;
    var15.setChart(var16);
    var15.setPercent((-1));
    boolean var20 = var9.equals((java.lang.Object)var15);
    org.jfree.chart.block.RectangleConstraint var21 = var6.toRangeHeight(var9);
    org.jfree.data.Range var22 = org.jfree.data.Range.combine(var0, var9);
    org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 0.0d);
    double var27 = var26.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(1.0d, var26);
    org.jfree.data.Range var29 = org.jfree.data.Range.combine(var22, var26);
    org.jfree.data.Range var31 = org.jfree.data.Range.shift(var29, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1", "poly", var3, "0,-1,-1,1,1,1,1,1", "", "");
    org.jfree.chart.ui.Library[] var8 = var7.getLibraries();
    java.lang.String var9 = var7.getLicenceText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    java.awt.Paint var26 = var17.getLinePaint();
    boolean var27 = var17.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    org.jfree.chart.block.RectangleConstraint var26 = var22.toUnconstrainedWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     java.awt.Paint var4 = var2.getTickLabelPaint();
//     java.lang.Object var5 = null;
//     boolean var6 = var2.equals(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var9 = var8.getLabelToolTip();
//     java.awt.Font var10 = var8.getTickLabelFont();
//     var2.setLabelFont(var10);
//     java.awt.Font var13 = null;
//     java.awt.Color var16 = java.awt.Color.getColor("", 0);
//     int var17 = var16.getGreen();
//     float[] var18 = null;
//     float[] var19 = var16.getColorComponents(var18);
//     boolean var21 = var16.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var16, 0.0f, 10, var24);
//     int var26 = var16.getTransparency();
//     java.awt.Color var27 = var16.brighter();
//     org.jfree.chart.text.TextMeasurer var29 = null;
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("LegendItemEntity: seriesKey=null, dataset=null", var10, (java.awt.Paint)var27, 100.0f, var29);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var1);
    var3.setToolTipText("");
    java.lang.String var6 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var6.equals("LegendItemEntity: seriesKey=null, dataset=null"));

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 12.0d, 1.0f, 10.0f);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var8 = null;
    java.awt.Color var11 = java.awt.Color.getColor("", 0);
    int var12 = var11.getGreen();
    float[] var13 = null;
    float[] var14 = var11.getColorComponents(var13);
    boolean var16 = var11.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var19 = null;
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var8, (java.awt.Paint)var11, 0.0f, 10, var19);
    org.jfree.chart.title.LegendGraphic var21 = new org.jfree.chart.title.LegendGraphic(var6, (java.awt.Paint)var11);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var23, var30);
    var21.setShape(var23);
    java.awt.Color var35 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var36 = null;
    org.jfree.chart.event.ChartChangeEvent var37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var35, var36);
    var21.setLinePaint((java.awt.Paint)var35);
    java.awt.geom.Rectangle2D var39 = var21.getBounds();
    java.awt.Paint var40 = null;
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var43 = var42.getLabelToolTip();
    java.awt.Stroke var44 = var42.getAxisLineStroke();
    java.awt.Color var47 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem(var0, "poly", "0,-1,-1,1,1,1,1,1", "Size2D[width=10.0, height=14.0]", (java.awt.Shape)var39, var40, var44, (java.awt.Paint)var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.Graphics2D var23 = null;
    org.jfree.data.Range var27 = new org.jfree.data.Range(0.0d, 0.0d);
    double var28 = var27.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var29 = new org.jfree.chart.block.RectangleConstraint(1.0d, var27);
    org.jfree.chart.block.RectangleConstraint var31 = var29.toFixedHeight(14.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var32 = var22.arrange(var23, var29);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var6.axisChanged(var7);
    java.awt.Image var9 = null;
    var6.setBackgroundImage(var9);
    org.jfree.chart.event.PlotChangeListener var11 = null;
    var6.removeChangeListener(var11);
    org.jfree.chart.plot.CategoryMarker var13 = null;
    org.jfree.chart.util.Layer var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)10, "Size2D[width=10.0, height=14.0]", var2, var3, 102.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)'4');
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    java.lang.String var10 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "AxisLocation.TOP_OR_RIGHT"+ "'", var10.equals("AxisLocation.TOP_OR_RIGHT"));

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    var4.addOptionalLibrary("");
    var4.setLicenceName("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.plot.DatasetRenderingOrder var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDatasetRenderingOrder(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("", 0);
//     int var5 = var4.getGreen();
//     float[] var6 = null;
//     float[] var7 = var4.getColorComponents(var6);
//     boolean var9 = var4.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
//     java.util.List var14 = var13.getLines();
//     org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var20 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
//     java.awt.Graphics2D var23 = null;
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Font var28 = null;
//     java.awt.Color var31 = java.awt.Color.getColor("", 0);
//     int var32 = var31.getGreen();
//     float[] var33 = null;
//     float[] var34 = var31.getColorComponents(var33);
//     boolean var36 = var31.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var39 = null;
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var31, 0.0f, 10, var39);
//     org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var31);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.rotateShape(var43, 0.0d, (-1.0f), 100.0f);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var43);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     boolean var51 = org.jfree.chart.util.ShapeUtilities.equal(var43, var50);
//     var41.setShape(var43);
//     java.awt.Color var55 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var56 = null;
//     org.jfree.chart.event.ChartChangeEvent var57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var55, var56);
//     var41.setLinePaint((java.awt.Paint)var55);
//     java.awt.geom.Rectangle2D var59 = var41.getBounds();
//     java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     org.jfree.chart.entity.LegendItemEntity var63 = new org.jfree.chart.entity.LegendItemEntity(var62);
//     java.lang.Object var64 = var22.draw(var23, var59, (java.lang.Object)var62);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var26);
    var17.setShape(var19);
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var32 = null;
    org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var31, var32);
    var17.setLinePaint((java.awt.Paint)var31);
    org.jfree.chart.util.RectangleAnchor var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setShapeAnchor(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var28 = null;
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    int var32 = var31.getGreen();
    float[] var33 = null;
    float[] var34 = var31.getColorComponents(var33);
    boolean var36 = var31.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var39 = null;
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var31, 0.0f, 10, var39);
    org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var31);
    boolean var42 = var41.isShapeOutlineVisible();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var47 = var46.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var48 = var46.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var49 = var41.arrange(var43, var46);
    java.awt.Paint var50 = var41.getLinePaint();
    var22.add((org.jfree.chart.block.Block)var41);
    java.lang.Object var52 = var22.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("", 0);
//     int var5 = var4.getGreen();
//     float[] var6 = null;
//     float[] var7 = var4.getColorComponents(var6);
//     boolean var9 = var4.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
//     java.util.List var14 = var13.getLines();
//     org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var20 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
//     org.jfree.data.general.Dataset var23 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var23, (java.lang.Comparable)"RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
//     
//     // Checks the contract:  equals-hashcode on var22 and var25
//     assertTrue("Contract failed: equals-hashcode on var22 and var25", var22.equals(var25) ? var22.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var22
//     assertTrue("Contract failed: equals-hashcode on var25 and var22", var25.equals(var22) ? var25.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.Graphics2D var23 = null;
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var28 = null;
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    int var32 = var31.getGreen();
    float[] var33 = null;
    float[] var34 = var31.getColorComponents(var33);
    boolean var36 = var31.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var39 = null;
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var31, 0.0f, 10, var39);
    org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var31);
    boolean var42 = var41.isShapeOutlineVisible();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var47 = var46.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var48 = var46.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var49 = var41.arrange(var43, var46);
    org.jfree.chart.util.Size2D var50 = var22.arrange(var23, var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateTopInset(10.0d);
    double var10 = var4.calculateLeftInset(12.0d);
    double var11 = var4.getBottom();
    double var13 = var4.calculateTopOutset(14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.0d));

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var3);
    org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var7 = var6.getType();
    var4.setType(var7);
    org.jfree.data.Range var11 = new org.jfree.data.Range(0.0d, 0.0d);
    double var12 = var11.getUpperBound();
    double var13 = var11.getCentralValue();
    org.jfree.data.general.Dataset var14 = null;
    org.jfree.data.general.DatasetChangeEvent var15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var11, var14);
    boolean var16 = var7.equals((java.lang.Object)var11);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 100.0f);
    boolean var20 = var7.equals((java.lang.Object)var19);
    org.jfree.chart.util.RectangleAnchor var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, var21, (-1.0d), 14.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Font var3 = var1.getTickLabelFont();
    boolean var4 = var1.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("0,-1,-1,1,1,1,1,1", var1, 100.0f, 0.0f, 10.0d, 0.0f, 0.0f);
// 
//   }

//  public void test181() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Size2D[width=10.0, height=14.0]", var1);
//
//  }
//
  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 1.0f, 1.0f, 100.0d, (-1.0f), 10.0f);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(12.0d, (-1.0d), 1.0d, 12.0d);
    double var6 = var4.calculateLeftOutset(0.0d);
    double var7 = var4.getTop();
    double var9 = var4.extendHeight(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 113.0d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var3.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(1.0d, var3);
    org.jfree.data.Range var8 = new org.jfree.data.Range(0.0d, 0.0d);
    double var9 = var8.getLength();
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartProgressEvent var14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var11, 100, 10);
    org.jfree.chart.JFreeChart var15 = null;
    var14.setChart(var15);
    var14.setPercent((-1));
    boolean var19 = var8.equals((java.lang.Object)var14);
    org.jfree.chart.block.RectangleConstraint var20 = var5.toRangeHeight(var8);
    org.jfree.data.Range var21 = var20.getWidthRange();
    java.lang.String var22 = var20.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"+ "'", var22.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    java.awt.Paint var26 = var17.getLinePaint();
    java.awt.Shape var27 = var17.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.axis.CategoryLabelPositions var17 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
    boolean var18 = var15.equals((java.lang.Object)var17);
    org.jfree.chart.axis.CategoryLabelPosition var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var17, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    org.jfree.chart.entity.LegendItemEntity var7 = new org.jfree.chart.entity.LegendItemEntity(var1);
    java.lang.Comparable var8 = var7.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var4 = var3.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var3, var5, var6);
//     boolean var8 = var7.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
//     java.awt.Font var10 = var7.getNoDataMessageFont();
//     java.awt.Color var13 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.text.TextMeasurer var15 = null;
//     org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("0,-1,-1,1,1,1,1,1", var10, (java.awt.Paint)var13, 10.0f, var15);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var16 = var14.trimHeight(10.0d);
    double var18 = var14.calculateTopInset(10.0d);
    double var20 = var14.calculateLeftInset(12.0d);
    double var21 = var14.getBottom();
    double var23 = var14.trimHeight(100.0d);
    var6.setInsets(var14, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 102.0d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
    org.jfree.chart.annotations.CategoryAnnotation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addAnnotation(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    org.jfree.chart.ui.Library[] var6 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var7 = var4.getLibraries();
    org.jfree.chart.ui.BasicProjectInfo var12 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var13 = var12.getVersion();
    java.lang.String var14 = var12.getLicenceName();
    var4.addOptionalLibrary((org.jfree.chart.ui.Library)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var13.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "hi!"+ "'", var14.equals("hi!"));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var6.getDomainMarkers((-1), var8);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleAnchor var13 = null;
    java.awt.geom.Point2D var14 = org.jfree.chart.util.RectangleAnchor.coordinates(var12, var13);
    var6.zoomRangeAxes(100.0d, var11, var14);
    org.jfree.chart.util.RectangleEdge var17 = var6.getDomainAxisEdge(0);
    org.jfree.chart.util.RectangleEdge var18 = org.jfree.chart.util.RectangleEdge.opposite(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 25.0d, (-1.0d));
    var19.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var6.axisChanged(var7);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var14, var15);
    boolean var17 = var16.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
    var16.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var21 = var16.getDomainAxisLocation(0);
    var6.setDomainAxisLocation(100, var21);
    org.jfree.chart.plot.PlotOrientation var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var24 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var21, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var5 = null;
    java.awt.Rectangle var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    java.awt.geom.AffineTransform var8 = null;
    java.awt.RenderingHints var9 = null;
    java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4);
    org.jfree.chart.text.TextLine var12 = null;
    var11.addLine(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var5 = null;
    java.awt.Rectangle var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    java.awt.geom.AffineTransform var8 = null;
    java.awt.RenderingHints var9 = null;
    java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var16 = var15.getLabelToolTip();
    java.awt.Font var17 = var15.getTickLabelFont();
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var22 = null;
    java.awt.Color var25 = java.awt.Color.getColor("", 0);
    int var26 = var25.getGreen();
    float[] var27 = null;
    float[] var28 = var25.getColorComponents(var27);
    boolean var30 = var25.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var33 = null;
    org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, (java.awt.Paint)var25, 0.0f, 10, var33);
    org.jfree.chart.title.LegendGraphic var35 = new org.jfree.chart.title.LegendGraphic(var20, (java.awt.Paint)var25);
    org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var17, (java.awt.Paint)var25);
    java.awt.Font var38 = null;
    java.awt.Color var41 = java.awt.Color.getColor("", 0);
    int var42 = var41.getGreen();
    float[] var43 = null;
    float[] var44 = var41.getColorComponents(var43);
    boolean var46 = var41.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var49 = null;
    org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var38, (java.awt.Paint)var41, 0.0f, 10, var49);
    int var51 = var41.getTransparency();
    java.awt.Color var52 = var41.darker();
    java.awt.Color var53 = var52.darker();
    var11.addLine("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var17, (java.awt.Paint)var53);
    org.jfree.chart.text.TextLine var55 = var11.getLastLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var28 = null;
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    int var32 = var31.getGreen();
    float[] var33 = null;
    float[] var34 = var31.getColorComponents(var33);
    boolean var36 = var31.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var39 = null;
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var31, 0.0f, 10, var39);
    org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var31);
    boolean var42 = var41.isShapeOutlineVisible();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var47 = var46.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var48 = var46.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var49 = var41.arrange(var43, var46);
    java.awt.Paint var50 = var41.getLinePaint();
    var22.add((org.jfree.chart.block.Block)var41);
    boolean var52 = var22.isEmpty();
    java.lang.String var53 = var22.getURLText();
    java.lang.Comparable var54 = var22.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "poly"+ "'", var54.equals("poly"));

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     org.jfree.chart.util.Layer var8 = null;
//     java.util.Collection var9 = var6.getDomainMarkers((-1), var8);
//     var6.zoom(113.0d);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.util.List var11 = var6.getAnnotations();
    java.awt.Font var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setNoDataMessageFont(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("org.jfree.chart.event.ChartProgressEvent[source=10.0]", var1, 10.0f, 100.0f, var4);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    java.awt.Font var7 = null;
    java.awt.Color var10 = java.awt.Color.getColor("", 0);
    int var11 = var10.getGreen();
    float[] var12 = null;
    float[] var13 = var10.getColorComponents(var12);
    boolean var15 = var10.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var18 = null;
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, (java.awt.Paint)var10, 0.0f, 10, var18);
    int var20 = var10.getTransparency();
    java.awt.Color var21 = var10.darker();
    java.awt.Color var22 = var21.darker();
    java.awt.image.ColorModel var23 = null;
    java.awt.Rectangle var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    java.awt.geom.AffineTransform var26 = null;
    java.awt.RenderingHints var27 = null;
    java.awt.PaintContext var28 = var21.createContext(var23, var24, var25, var26, var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem(var0, "", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "", var5, (java.awt.Paint)var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var1);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var1, 100, 10);
    org.jfree.chart.JFreeChart var5 = null;
    var4.setChart(var5);
    var4.setPercent((-1));
    var4.setType(0);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(12.0d, (-1.0d), 1.0d, 12.0d);
    double var6 = var4.calculateLeftOutset(0.0d);
    double var7 = var4.getTop();
    double var8 = var4.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.util.RectangleInsets var17 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    double var19 = var17.calculateLeftOutset(14.0d);
    org.jfree.chart.util.RectangleInsets var24 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var26 = var24.trimHeight(10.0d);
    double var28 = var24.calculateTopInset(10.0d);
    double var30 = var24.calculateLeftInset(12.0d);
    double var31 = var24.getBottom();
    boolean var32 = var17.equals((java.lang.Object)var31);
    boolean var33 = var11.equals((java.lang.Object)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var2.constrain(102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.axis.CategoryLabelPositions var17 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
    boolean var18 = var15.equals((java.lang.Object)var17);
    org.jfree.chart.axis.CategoryLabelPosition var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var17, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
//     double var6 = var4.trimHeight(10.0d);
//     double var8 = var4.calculateLeftInset(0.0d);
//     double var10 = var4.trimHeight(12.0d);
//     java.awt.geom.Rectangle2D var11 = null;
//     var4.trim(var11);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    java.awt.Font var36 = null;
    java.awt.Color var39 = java.awt.Color.getColor("", 0);
    int var40 = var39.getGreen();
    float[] var41 = null;
    float[] var42 = var39.getColorComponents(var41);
    boolean var44 = var39.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var47 = null;
    org.jfree.chart.text.TextBlock var48 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, (java.awt.Paint)var39, 0.0f, 10, var47);
    java.util.List var49 = var48.getLines();
    org.jfree.chart.util.HorizontalAlignment var50 = var48.getLineAlignment();
    org.jfree.chart.axis.CategoryLabelPositions var52 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
    boolean var53 = var50.equals((java.lang.Object)var52);
    var10.setHorizontalAlignment(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Font var12 = null;
//     java.awt.Color var15 = java.awt.Color.getColor("", 0);
//     int var16 = var15.getGreen();
//     float[] var17 = null;
//     float[] var18 = var15.getColorComponents(var17);
//     boolean var20 = var15.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var23 = null;
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var15, 0.0f, 10, var23);
//     java.util.List var25 = var24.getLines();
//     org.jfree.chart.util.HorizontalAlignment var26 = var24.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var31 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, var31, (java.lang.Comparable)"poly");
//     java.awt.geom.Rectangle2D var34 = var33.getBounds();
//     var10.setWrapper((org.jfree.chart.block.BlockContainer)var33);
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var39 = var38.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var36, var38, var40, var41);
//     boolean var43 = var42.isSubplot();
//     org.jfree.chart.axis.AxisLocation var45 = var42.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.data.Range var51 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var52 = var51.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(1.0d, var51);
//     org.jfree.data.Range var56 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var57 = var56.getLength();
//     org.jfree.chart.JFreeChart var59 = null;
//     org.jfree.chart.event.ChartProgressEvent var62 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var59, 100, 10);
//     org.jfree.chart.JFreeChart var63 = null;
//     var62.setChart(var63);
//     var62.setPercent((-1));
//     boolean var67 = var56.equals((java.lang.Object)var62);
//     org.jfree.chart.block.RectangleConstraint var68 = var53.toRangeHeight(var56);
//     org.jfree.data.Range var69 = var68.getWidthRange();
//     org.jfree.chart.util.Size2D var70 = var46.arrange(var47, var68);
//     org.jfree.chart.util.RectangleAnchor var71 = var46.getLegendItemGraphicLocation();
//     var10.setLegendItemGraphicLocation(var71);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var2);
    java.lang.Object var4 = var3.clone();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartChangeEventType var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var6, var7);
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var8.setType(var9);
    boolean var11 = var3.equals((java.lang.Object)var9);
    java.awt.Font var13 = null;
    java.awt.Color var16 = java.awt.Color.getColor("", 0);
    int var17 = var16.getGreen();
    float[] var18 = null;
    float[] var19 = var16.getColorComponents(var18);
    boolean var21 = var16.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var24 = null;
    org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var16, 0.0f, 10, var24);
    int var26 = var16.getTransparency();
    java.awt.Color var27 = var16.darker();
    boolean var28 = var3.equals((java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var3.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(1.0d, var3);
    org.jfree.chart.block.LengthConstraintType var6 = var5.getHeightConstraintType();
    java.lang.Object var7 = null;
    boolean var8 = var6.equals(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
//     double var2 = var1.getFixedDimension();
//     float var3 = var1.getMaximumCategoryLabelWidthRatio();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var8 = var7.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var7, var9, var10);
//     boolean var12 = var11.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var13 = var11.getDrawingSupplier();
//     var11.clearRangeMarkers();
//     boolean var15 = var11.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var18 = var17.getLabelToolTip();
//     java.awt.Font var22 = null;
//     java.awt.Color var25 = java.awt.Color.getColor("", 0);
//     int var26 = var25.getGreen();
//     float[] var27 = null;
//     float[] var28 = var25.getColorComponents(var27);
//     boolean var30 = var25.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var33 = null;
//     org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, (java.awt.Paint)var25, 0.0f, 10, var33);
//     java.util.List var35 = var34.getLines();
//     org.jfree.chart.util.HorizontalAlignment var36 = var34.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.ColumnArrangement var40 = new org.jfree.chart.block.ColumnArrangement(var36, var37, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var41 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var43 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var40, var41, (java.lang.Comparable)"poly");
//     java.awt.geom.Rectangle2D var44 = var43.getBounds();
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var48 = var47.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var45, var47, var49, var50);
//     org.jfree.chart.util.Layer var53 = null;
//     java.util.Collection var54 = var51.getDomainMarkers((-1), var53);
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     org.jfree.chart.util.RectangleAnchor var58 = null;
//     java.awt.geom.Point2D var59 = org.jfree.chart.util.RectangleAnchor.coordinates(var57, var58);
//     var51.zoomRangeAxes(100.0d, var56, var59);
//     org.jfree.chart.util.RectangleEdge var62 = var51.getDomainAxisEdge(0);
//     double var63 = var17.getCategoryEnd(0, 100, var44, var62);
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     org.jfree.chart.axis.AxisSpace var65 = null;
//     org.jfree.chart.axis.AxisSpace var66 = var1.reserveSpace(var4, (org.jfree.chart.plot.Plot)var11, var44, var64, var65);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    double var3 = var2.getUpperBound();
    org.jfree.data.Range var6 = org.jfree.data.Range.expand(var2, 12.0d, 12.0d);
    double var7 = var6.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    java.lang.Object var4 = null;
    boolean var5 = var1.equals(var4);
    boolean var6 = var1.isAxisLineVisible();
    boolean var7 = var1.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "0,-1,-1,1,1,1,1,1", "poly", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    java.awt.Image var9 = null;
    org.jfree.chart.ui.ProjectInfo var13 = new org.jfree.chart.ui.ProjectInfo("0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1", "poly", var9, "0,-1,-1,1,1,1,1,1", "", "");
    org.jfree.chart.ui.Library[] var14 = var13.getLibraries();
    java.lang.String var15 = var13.getCopyright();
    var5.addLibrary((org.jfree.chart.ui.Library)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "0,-1,-1,1,1,1,1,1"+ "'", var15.equals("0,-1,-1,1,1,1,1,1"));

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var14 = new org.jfree.data.Range(0.0d, 0.0d);
    double var15 = var14.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(1.0d, var14);
    org.jfree.data.Range var19 = new org.jfree.data.Range(0.0d, 0.0d);
    double var20 = var19.getLength();
    org.jfree.chart.JFreeChart var22 = null;
    org.jfree.chart.event.ChartProgressEvent var25 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var22, 100, 10);
    org.jfree.chart.JFreeChart var26 = null;
    var25.setChart(var26);
    var25.setPercent((-1));
    boolean var30 = var19.equals((java.lang.Object)var25);
    org.jfree.chart.block.RectangleConstraint var31 = var16.toRangeHeight(var19);
    org.jfree.data.Range var32 = org.jfree.data.Range.combine(var10, var19);
    org.jfree.data.Range var36 = new org.jfree.data.Range(0.0d, 0.0d);
    double var37 = var36.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(1.0d, var36);
    org.jfree.data.Range var39 = org.jfree.data.Range.combine(var32, var36);
    org.jfree.data.general.Dataset var40 = null;
    org.jfree.data.general.DatasetChangeEvent var41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var32, var40);
    var6.datasetChanged(var41);
    java.lang.String var43 = var41.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]"+ "'", var43.equals("org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]"));

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var3);
    org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var7 = var6.getType();
    var4.setType(var7);
    java.lang.String var9 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]"+ "'", var9.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]"));

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    var1.setVisible(true);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var10 = var9.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var7, var9, var11, var12);
    boolean var14 = var13.isSubplot();
    org.jfree.chart.axis.AxisLocation var16 = var13.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    java.awt.Graphics2D var18 = null;
    org.jfree.data.Range var22 = new org.jfree.data.Range(0.0d, 0.0d);
    double var23 = var22.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(1.0d, var22);
    org.jfree.data.Range var27 = new org.jfree.data.Range(0.0d, 0.0d);
    double var28 = var27.getLength();
    org.jfree.chart.JFreeChart var30 = null;
    org.jfree.chart.event.ChartProgressEvent var33 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var30, 100, 10);
    org.jfree.chart.JFreeChart var34 = null;
    var33.setChart(var34);
    var33.setPercent((-1));
    boolean var38 = var27.equals((java.lang.Object)var33);
    org.jfree.chart.block.RectangleConstraint var39 = var24.toRangeHeight(var27);
    org.jfree.data.Range var40 = var39.getWidthRange();
    org.jfree.chart.util.Size2D var41 = var17.arrange(var18, var39);
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var44 = var43.getLabelToolTip();
    java.awt.Paint var45 = var43.getTickLabelPaint();
    java.lang.Object var46 = null;
    boolean var47 = var43.equals(var46);
    org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var50 = var49.getLabelToolTip();
    java.awt.Font var51 = var49.getTickLabelFont();
    var43.setLabelFont(var51);
    var17.setItemFont(var51);
    var1.setTickLabelFont((java.lang.Comparable)(-1.0d), var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    org.jfree.chart.util.GradientPaintTransformer var26 = var17.getFillPaintTransformer();
    java.awt.Stroke var27 = var17.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    boolean var14 = var11.equals((java.lang.Object)' ');
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var6.axisChanged(var7);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var14, var15);
    boolean var17 = var16.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
    var16.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var21 = var16.getDomainAxisLocation(0);
    var6.setDomainAxisLocation(100, var21);
    var6.configureDomainAxes();
    org.jfree.chart.util.Layer var24 = null;
    java.util.Collection var25 = var6.getDomainMarkers(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 0.0d, 1.0f, 100.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 0.0d, 1.0f, 100.0f);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var5, var15);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var5, "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var1, var2, var3, 25.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var6.axisChanged(var7);
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var13 = var12.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var14, var15);
//     boolean var17 = var16.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
//     var16.clearRangeMarkers();
//     org.jfree.chart.axis.AxisLocation var21 = var16.getDomainAxisLocation(0);
//     var6.setDomainAxisLocation(100, var21);
//     java.awt.Graphics2D var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var28 = var27.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var25, var27, var29, var30);
//     org.jfree.chart.util.Layer var33 = null;
//     java.util.Collection var34 = var31.getDomainMarkers((-1), var33);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleAnchor var38 = null;
//     java.awt.geom.Point2D var39 = org.jfree.chart.util.RectangleAnchor.coordinates(var37, var38);
//     var31.zoomRangeAxes(100.0d, var36, var39);
//     org.jfree.chart.plot.PlotState var41 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     var6.draw(var23, var24, var39, var41, var42);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test228"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(100.0d, (-1.0d));
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, (-1.0f), 100.0f);
    boolean var9 = var2.equals((java.lang.Object)100.0f);
    double var10 = var2.getWidth();
    var2.setWidth(14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100.0d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test229"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(3);
    java.lang.Object var2 = null;
    boolean var3 = var1.equals(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test230"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
    var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    double var16 = var1.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test231"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var1, 100, 10);
    org.jfree.chart.JFreeChart var5 = var4.getChart();
    org.jfree.chart.JFreeChart var6 = null;
    var4.setChart(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test232"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", var3);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test233"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var3);
    org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var7 = var6.getType();
    var4.setType(var7);
    java.lang.Object var9 = var4.getSource();
    java.awt.Color var12 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var13 = null;
    org.jfree.chart.event.ChartChangeEvent var14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var12, var13);
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var17 = var16.getType();
    var14.setType(var17);
    org.jfree.data.Range var21 = new org.jfree.data.Range(0.0d, 0.0d);
    double var22 = var21.getUpperBound();
    double var23 = var21.getCentralValue();
    org.jfree.data.general.Dataset var24 = null;
    org.jfree.data.general.DatasetChangeEvent var25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var21, var24);
    boolean var26 = var17.equals((java.lang.Object)var21);
    java.lang.String var27 = var17.toString();
    var4.setType(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var27.equals("ChartChangeEventType.GENERAL"));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test234"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var3.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(1.0d, var3);
    org.jfree.data.Range var8 = new org.jfree.data.Range(0.0d, 0.0d);
    double var9 = var8.getLength();
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartProgressEvent var14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var11, 100, 10);
    org.jfree.chart.JFreeChart var15 = null;
    var14.setChart(var15);
    var14.setPercent((-1));
    boolean var19 = var8.equals((java.lang.Object)var14);
    org.jfree.chart.block.RectangleConstraint var20 = var5.toRangeHeight(var8);
    double var21 = var8.getUpperBound();
    java.lang.String var22 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Range[0.0,0.0]"+ "'", var22.equals("Range[0.0,0.0]"));

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test235"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var16 = var15.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
//     org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var21 = var20.getLength();
//     org.jfree.chart.JFreeChart var23 = null;
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
//     org.jfree.chart.JFreeChart var27 = null;
//     var26.setChart(var27);
//     var26.setPercent((-1));
//     boolean var31 = var20.equals((java.lang.Object)var26);
//     org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
//     org.jfree.data.Range var33 = var32.getWidthRange();
//     org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
//     org.jfree.chart.util.RectangleEdge var35 = var10.getLegendItemGraphicEdge();
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var39 = var38.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var36, var38, var40, var41);
//     boolean var43 = var42.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var44 = var42.getDrawingSupplier();
//     var42.setRangeCrosshairVisible(false);
//     org.jfree.chart.util.RectangleEdge var48 = var42.getDomainAxisEdge(1);
//     var10.setLegendItemGraphicEdge(var48);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test236"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    org.jfree.chart.util.VerticalAlignment var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setVerticalAlignment(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test237"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.setRangeCrosshairVisible(false);
    org.jfree.chart.util.RectangleEdge var12 = var6.getDomainAxisEdge(1);
    org.jfree.chart.plot.DatasetRenderingOrder var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDatasetRenderingOrder(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test238"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    int var14 = var4.getTransparency();
    java.awt.Color var15 = var4.darker();
    int var16 = var15.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 255);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test239"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var28 = null;
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    int var32 = var31.getGreen();
    float[] var33 = null;
    float[] var34 = var31.getColorComponents(var33);
    boolean var36 = var31.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var39 = null;
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var31, 0.0f, 10, var39);
    org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var31);
    boolean var42 = var41.isShapeOutlineVisible();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var47 = var46.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var48 = var46.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var49 = var41.arrange(var43, var46);
    java.awt.Paint var50 = var41.getLinePaint();
    var22.add((org.jfree.chart.block.Block)var41);
    java.lang.String var52 = var22.getURLText();
    org.jfree.data.general.Dataset var53 = var22.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test240"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     java.awt.Font var9 = var6.getNoDataMessageFont();
//     java.awt.Stroke var10 = var6.getRangeCrosshairStroke();
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     var6.drawOutline(var11, var12);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test241"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var1);
    var3.setToolTipText("");
    java.lang.Comparable var6 = var3.getSeriesKey();
    org.jfree.data.general.Dataset var7 = null;
    var3.setDataset(var7);
    java.lang.String var9 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var9.equals("LegendItemEntity: seriesKey=null, dataset=null"));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test242"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Shape var19 = null;
    var17.setLine(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test243"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", var1);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test244"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("0,-1,-1,1,1,1,1,1");

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test245"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    int var9 = var8.getGreen();
    float[] var10 = null;
    float[] var11 = var8.getColorComponents(var10);
    boolean var13 = var8.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var8, 0.0f, 10, var16);
    org.jfree.chart.title.LegendGraphic var18 = new org.jfree.chart.title.LegendGraphic(var3, (java.awt.Paint)var8);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var20, var27);
    var18.setShape(var20);
    java.awt.Color var32 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var33 = null;
    org.jfree.chart.event.ChartChangeEvent var34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var32, var33);
    var18.setLinePaint((java.awt.Paint)var32);
    java.awt.Color var36 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test246"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var26);
    var17.setShape(var19);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.block.RectangleConstraint var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var31 = var17.arrange(var29, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test247"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test248"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var2);
    java.lang.Object var4 = var3.clone();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartChangeEventType var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var6, var7);
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var8.setType(var9);
    boolean var11 = var3.equals((java.lang.Object)var9);
    java.lang.Comparable var12 = null;
    var3.setSeriesKey(var12);
    var3.setSeriesKey((java.lang.Comparable)12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test249"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 0.0d, (-1.0f), 100.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 0.0d, 1.0f, 100.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var6, 25.0d, 100.0f, 100.0f);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test250"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var6.getDomainMarkers((-1), var8);
    double var10 = var6.getRangeCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test251"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Stroke var3 = var1.getAxisLineStroke();
    boolean var4 = var1.isTickLabelsVisible();
    boolean var5 = var1.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test252"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var16 = var15.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
//     org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var21 = var20.getLength();
//     org.jfree.chart.JFreeChart var23 = null;
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
//     org.jfree.chart.JFreeChart var27 = null;
//     var26.setChart(var27);
//     var26.setPercent((-1));
//     boolean var31 = var20.equals((java.lang.Object)var26);
//     org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
//     org.jfree.data.Range var33 = var32.getWidthRange();
//     org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
//     org.jfree.chart.util.RectangleEdge var35 = var10.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var36 = var10.getLegendItemGraphicEdge();
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var40 = var39.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var37, var39, var41, var42);
//     boolean var44 = var43.isSubplot();
//     org.jfree.chart.axis.AxisLocation var46 = var43.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
//     java.awt.Graphics2D var48 = null;
//     org.jfree.data.Range var52 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var53 = var52.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var54 = new org.jfree.chart.block.RectangleConstraint(1.0d, var52);
//     org.jfree.data.Range var57 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var58 = var57.getLength();
//     org.jfree.chart.JFreeChart var60 = null;
//     org.jfree.chart.event.ChartProgressEvent var63 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var60, 100, 10);
//     org.jfree.chart.JFreeChart var64 = null;
//     var63.setChart(var64);
//     var63.setPercent((-1));
//     boolean var68 = var57.equals((java.lang.Object)var63);
//     org.jfree.chart.block.RectangleConstraint var69 = var54.toRangeHeight(var57);
//     org.jfree.data.Range var70 = var69.getWidthRange();
//     org.jfree.chart.util.Size2D var71 = var47.arrange(var48, var69);
//     org.jfree.chart.util.RectangleEdge var72 = var47.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var73 = var47.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleAnchor var74 = var47.getLegendItemGraphicAnchor();
//     var10.setLegendItemGraphicLocation(var74);
//     
//     // Checks the contract:  equals-hashcode on var6 and var43
//     assertTrue("Contract failed: equals-hashcode on var6 and var43", var6.equals(var43) ? var6.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var6
//     assertTrue("Contract failed: equals-hashcode on var43 and var6", var43.equals(var6) ? var43.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var71
//     assertTrue("Contract failed: equals-hashcode on var34 and var71", var34.equals(var71) ? var34.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var34
//     assertTrue("Contract failed: equals-hashcode on var71 and var34", var71.equals(var34) ? var71.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test253"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("poly", var1);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test254"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    java.lang.Object var4 = null;
    boolean var5 = var1.equals(var4);
    boolean var6 = var1.isAxisLineVisible();
    var1.setLabelToolTip("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test255"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var28 = null;
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    int var32 = var31.getGreen();
    float[] var33 = null;
    float[] var34 = var31.getColorComponents(var33);
    boolean var36 = var31.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var39 = null;
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var31, 0.0f, 10, var39);
    org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var31);
    boolean var42 = var41.isShapeOutlineVisible();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var47 = var46.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var48 = var46.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var49 = var41.arrange(var43, var46);
    java.awt.Paint var50 = var41.getLinePaint();
    var22.add((org.jfree.chart.block.Block)var41);
    boolean var52 = var22.isEmpty();
    java.lang.String var53 = var22.getURLText();
    java.lang.Object var54 = var22.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test256"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0f, 1.0f, 1.0d, (-1.0f), 0.0f);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test257"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    var17.setID("Size2D[width=10.0, height=14.0]");
    java.awt.Shape var20 = var17.getShape();
    org.jfree.data.category.CategoryDataset var23 = null;
    java.lang.Comparable var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var26 = new org.jfree.chart.entity.CategoryItemEntity(var20, "hi!", "Size2D[width=10.0, height=14.0]", var23, (java.lang.Comparable)113.0d, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test258"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    java.awt.Paint[] var6 = new java.awt.Paint[] { var2};
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    java.awt.Paint[] var11 = new java.awt.Paint[] { var9};
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var25};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var11, var13, var15, var26);
    java.awt.Paint var28 = var27.getNextFillPaint();
    java.awt.Stroke var29 = var27.getNextStroke();
    org.jfree.data.category.CategoryDataset var30 = null;
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var33 = var32.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var30, var32, var34, var35);
    boolean var37 = var36.isSubplot();
    org.jfree.chart.axis.AxisLocation var39 = var36.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
    java.awt.Graphics2D var41 = null;
    org.jfree.data.Range var45 = new org.jfree.data.Range(0.0d, 0.0d);
    double var46 = var45.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint(1.0d, var45);
    org.jfree.data.Range var50 = new org.jfree.data.Range(0.0d, 0.0d);
    double var51 = var50.getLength();
    org.jfree.chart.JFreeChart var53 = null;
    org.jfree.chart.event.ChartProgressEvent var56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var53, 100, 10);
    org.jfree.chart.JFreeChart var57 = null;
    var56.setChart(var57);
    var56.setPercent((-1));
    boolean var61 = var50.equals((java.lang.Object)var56);
    org.jfree.chart.block.RectangleConstraint var62 = var47.toRangeHeight(var50);
    org.jfree.data.Range var63 = var62.getWidthRange();
    org.jfree.chart.util.Size2D var64 = var40.arrange(var41, var62);
    org.jfree.chart.util.RectangleEdge var65 = var40.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var66 = var40.getLegendItemGraphicAnchor();
    java.lang.String var67 = var66.toString();
    boolean var68 = var27.equals((java.lang.Object)var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + "RectangleAnchor.CENTER"+ "'", var67.equals("RectangleAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test259"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 113.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test260"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateLeftInset(0.0d);
    double var9 = var4.getRight();
    double var11 = var4.extendHeight(1.0d);
    org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("hi!");
    org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var22 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22, var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var22);
    var15.setFrame((org.jfree.chart.block.BlockFrame)var25);
    org.jfree.chart.block.BlockFrame var27 = var15.getFrame();
    var15.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.awt.geom.Rectangle2D var30 = var15.getBounds();
    var13.setBounds(var30);
    java.awt.geom.Rectangle2D var34 = var4.createOutsetRectangle(var30, true, false);
    org.jfree.data.category.CategoryDataset var35 = null;
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var38 = var37.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var35, var37, var39, var40);
    boolean var42 = var41.isSubplot();
    org.jfree.chart.axis.AxisLocation var44 = var41.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
    java.awt.Graphics2D var46 = null;
    org.jfree.data.Range var50 = new org.jfree.data.Range(0.0d, 0.0d);
    double var51 = var50.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var52 = new org.jfree.chart.block.RectangleConstraint(1.0d, var50);
    org.jfree.data.Range var55 = new org.jfree.data.Range(0.0d, 0.0d);
    double var56 = var55.getLength();
    org.jfree.chart.JFreeChart var58 = null;
    org.jfree.chart.event.ChartProgressEvent var61 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var58, 100, 10);
    org.jfree.chart.JFreeChart var62 = null;
    var61.setChart(var62);
    var61.setPercent((-1));
    boolean var66 = var55.equals((java.lang.Object)var61);
    org.jfree.chart.block.RectangleConstraint var67 = var52.toRangeHeight(var55);
    org.jfree.data.Range var68 = var67.getWidthRange();
    org.jfree.chart.util.Size2D var69 = var45.arrange(var46, var67);
    org.jfree.chart.util.RectangleEdge var70 = var45.getLegendItemGraphicEdge();
    double var71 = org.jfree.chart.util.RectangleEdge.coordinate(var30, var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test261"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test262"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Font var12 = null;
//     java.awt.Color var15 = java.awt.Color.getColor("", 0);
//     int var16 = var15.getGreen();
//     float[] var17 = null;
//     float[] var18 = var15.getColorComponents(var17);
//     boolean var20 = var15.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var23 = null;
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var15, 0.0f, 10, var23);
//     java.util.List var25 = var24.getLines();
//     org.jfree.chart.util.HorizontalAlignment var26 = var24.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var31 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, var31, (java.lang.Comparable)"poly");
//     java.awt.geom.Rectangle2D var34 = var33.getBounds();
//     var10.setWrapper((org.jfree.chart.block.BlockContainer)var33);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
//     double var43 = var41.trimHeight(10.0d);
//     double var45 = var41.calculateLeftInset(0.0d);
//     double var46 = var41.getRight();
//     double var48 = var41.extendHeight(1.0d);
//     org.jfree.chart.block.LabelBlock var50 = new org.jfree.chart.block.LabelBlock("hi!");
//     org.jfree.chart.block.LabelBlock var52 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var59 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var60 = null;
//     org.jfree.chart.event.ChartChangeEvent var61 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var59, var60);
//     org.jfree.chart.block.BlockBorder var62 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var59);
//     var52.setFrame((org.jfree.chart.block.BlockFrame)var62);
//     org.jfree.chart.block.BlockFrame var64 = var52.getFrame();
//     var52.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var67 = var52.getBounds();
//     var50.setBounds(var67);
//     java.awt.geom.Rectangle2D var71 = var41.createOutsetRectangle(var67, true, false);
//     java.lang.Object var72 = null;
//     java.lang.Object var73 = var33.draw(var36, var67, var72);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test263"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test264"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var37 = var36.getLabelToolTip();
    java.awt.Paint var38 = var36.getTickLabelPaint();
    java.lang.Object var39 = null;
    boolean var40 = var36.equals(var39);
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var43 = var42.getLabelToolTip();
    java.awt.Font var44 = var42.getTickLabelFont();
    var36.setLabelFont(var44);
    var10.setItemFont(var44);
    org.jfree.chart.util.RectangleInsets var51 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    var10.setItemLabelPadding(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test265"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var16 = var15.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
//     org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var21 = var20.getLength();
//     org.jfree.chart.JFreeChart var23 = null;
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
//     org.jfree.chart.JFreeChart var27 = null;
//     var26.setChart(var27);
//     var26.setPercent((-1));
//     boolean var31 = var20.equals((java.lang.Object)var26);
//     org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
//     org.jfree.data.Range var33 = var32.getWidthRange();
//     org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var37 = var36.getLabelToolTip();
//     java.awt.Paint var38 = var36.getTickLabelPaint();
//     java.lang.Object var39 = null;
//     boolean var40 = var36.equals(var39);
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var43 = var42.getLabelToolTip();
//     java.awt.Font var44 = var42.getTickLabelFont();
//     var36.setLabelFont(var44);
//     var10.setItemFont(var44);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.util.Size2D var48 = var10.arrange(var47);
//     
//     // Checks the contract:  equals-hashcode on var34 and var48
//     assertTrue("Contract failed: equals-hashcode on var34 and var48", var34.equals(var48) ? var34.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var34
//     assertTrue("Contract failed: equals-hashcode on var48 and var34", var48.equals(var34) ? var48.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test266"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var3);
    org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var7 = var6.getType();
    var4.setType(var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var12 = new org.jfree.chart.entity.LegendItemEntity(var11);
    boolean var13 = var7.equals((java.lang.Object)var12);
    java.lang.String var14 = var12.toString();
    var12.setSeriesKey((java.lang.Comparable)(short)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var14.equals("LegendItemEntity: seriesKey=null, dataset=null"));

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test267"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var26);
    var17.setShape(var19);
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var32 = null;
    org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var31, var32);
    var17.setLinePaint((java.awt.Paint)var31);
    java.awt.geom.Rectangle2D var35 = var17.getBounds();
    boolean var36 = var17.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test268"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.axis.AxisLocation var13 = null;
    var6.setDomainAxisLocation(100, var13, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test269"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Stroke var3 = var1.getAxisLineStroke();
    double var4 = var1.getLowerMargin();
    float var5 = var1.getTickMarkInsideLength();
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    int var11 = var8.getRed();
    var1.setLabelPaint((java.awt.Paint)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test270"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getHeightConstraintType();
    org.jfree.data.Range var4 = var2.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test271"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    java.awt.Paint[] var6 = new java.awt.Paint[] { var2};
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    java.awt.Paint[] var11 = new java.awt.Paint[] { var9};
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var25};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var11, var13, var15, var26);
    java.awt.Paint var28 = var27.getNextFillPaint();
    java.awt.Stroke var29 = var27.getNextStroke();
    java.awt.Stroke var30 = var27.getNextStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test272"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Color var20 = java.awt.Color.getColor("", 0);
    var17.setFillPaint((java.awt.Paint)var20);
    org.jfree.chart.util.RectangleAnchor var22 = var17.getShapeAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test273"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var3);
    org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var7 = var6.getType();
    var4.setType(var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var12 = new org.jfree.chart.entity.LegendItemEntity(var11);
    boolean var13 = var7.equals((java.lang.Object)var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var17 = var16.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var16, var18, var19);
    boolean var21 = var20.isSubplot();
    var20.clearRangeMarkers(0);
    java.awt.Font var25 = null;
    java.awt.Color var28 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var29 = null;
    java.awt.Rectangle var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    java.awt.geom.AffineTransform var32 = null;
    java.awt.RenderingHints var33 = null;
    java.awt.PaintContext var34 = var28.createContext(var29, var30, var31, var32, var33);
    org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, (java.awt.Paint)var28);
    var20.setNoDataMessagePaint((java.awt.Paint)var28);
    var20.clearRangeMarkers(3);
    boolean var39 = var7.equals((java.lang.Object)3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test274"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.JFreeChart var14 = null;
    org.jfree.chart.event.ChartProgressEvent var17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var14, 100, 10);
    org.jfree.chart.JFreeChart var18 = null;
    var17.setChart(var18);
    var17.setPercent((-1));
    var17.setPercent(0);
    boolean var24 = var1.equals((java.lang.Object)var17);
    org.jfree.chart.block.BlockFrame var25 = var1.getFrame();
    java.awt.Paint var26 = var1.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test275"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "0,-1,-1,1,1,1,1,1", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test276"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);
    org.jfree.chart.plot.PlotRenderingInfo var2 = var1.getInfo();
    org.jfree.chart.plot.PlotRenderingInfo var3 = var1.getInfo();
    org.jfree.chart.entity.EntityCollection var4 = var1.getEntityCollection();
    org.jfree.chart.plot.PlotRenderingInfo var5 = var1.getInfo();
    org.jfree.chart.entity.EntityCollection var6 = var1.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test277"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    double var6 = var4.calculateLeftOutset(14.0d);
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var13 = var11.trimHeight(10.0d);
    double var15 = var11.calculateTopInset(10.0d);
    double var17 = var11.calculateLeftInset(12.0d);
    double var18 = var11.getBottom();
    boolean var19 = var4.equals((java.lang.Object)var18);
    double var21 = var4.calculateTopInset((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 10.0d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test278"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var12 = var11.getLabelToolTip();
    java.awt.Paint var13 = var11.getTickLabelPaint();
    java.lang.Object var14 = null;
    boolean var15 = var11.equals(var14);
    boolean var16 = var11.isAxisLineVisible();
    boolean var17 = var11.isVisible();
    org.jfree.chart.axis.CategoryAxis[] var18 = new org.jfree.chart.axis.CategoryAxis[] { var11};
    var6.setDomainAxes(var18);
    var6.setRangeGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test279"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var6.getRangeAxisIndex(var7);
    org.jfree.chart.axis.ValueAxis var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setRangeAxis((-1), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test280"); }
// 
// 
//     org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);
//     double var3 = var2.getWidth();
//     var2.setHeight(0.0d);
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var11 = var10.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var8, var10, var12, var13);
//     boolean var15 = var14.isSubplot();
//     org.jfree.chart.axis.AxisLocation var17 = var14.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.data.Range var23 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var24 = var23.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(1.0d, var23);
//     org.jfree.data.Range var28 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var29 = var28.getLength();
//     org.jfree.chart.JFreeChart var31 = null;
//     org.jfree.chart.event.ChartProgressEvent var34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var31, 100, 10);
//     org.jfree.chart.JFreeChart var35 = null;
//     var34.setChart(var35);
//     var34.setPercent((-1));
//     boolean var39 = var28.equals((java.lang.Object)var34);
//     org.jfree.chart.block.RectangleConstraint var40 = var25.toRangeHeight(var28);
//     org.jfree.data.Range var41 = var40.getWidthRange();
//     org.jfree.chart.util.Size2D var42 = var18.arrange(var19, var40);
//     org.jfree.chart.util.RectangleEdge var43 = var18.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleAnchor var44 = var18.getLegendItemGraphicAnchor();
//     java.lang.String var45 = var44.toString();
//     java.awt.geom.Rectangle2D var46 = org.jfree.chart.util.RectangleAnchor.createRectangle(var2, 113.0d, 14.0d, var44);
//     
//     // Checks the contract:  equals-hashcode on var2 and var42
//     assertTrue("Contract failed: equals-hashcode on var2 and var42", var2.equals(var42) ? var2.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var2
//     assertTrue("Contract failed: equals-hashcode on var42 and var2", var42.equals(var2) ? var42.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test281"); }


    java.awt.Color var2 = java.awt.Color.getColor("org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]", (-33));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test282"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    java.awt.Stroke var14 = var12.getAxisLineStroke();
    var6.setDomainGridlineStroke(var14);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var6.getDomainMarkers(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test283"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var6.axisChanged(var7);
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var13 = var12.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var14, var15);
//     boolean var17 = var16.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
//     var16.clearRangeMarkers();
//     org.jfree.chart.axis.AxisLocation var21 = var16.getDomainAxisLocation(0);
//     var6.setDomainAxisLocation(100, var21);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var32 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var33 = null;
//     org.jfree.chart.event.ChartChangeEvent var34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var32, var33);
//     org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var32);
//     var25.setFrame((org.jfree.chart.block.BlockFrame)var35);
//     org.jfree.chart.block.BlockFrame var37 = var25.getFrame();
//     var25.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var40 = var25.getBounds();
//     java.awt.geom.Point2D var41 = null;
//     org.jfree.chart.plot.PlotState var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     var6.draw(var23, var40, var41, var42, var43);
//     org.jfree.chart.plot.Marker var45 = null;
//     org.jfree.chart.util.Layer var46 = null;
//     var6.addRangeMarker(var45, var46);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test284"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 12.0d, 25.0d, 102.0d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test285"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    double var6 = var4.calculateLeftOutset(14.0d);
    double var8 = var4.calculateBottomOutset(12.0d);
    java.awt.Font var10 = null;
    java.awt.Color var13 = java.awt.Color.getColor("", 0);
    int var14 = var13.getGreen();
    float[] var15 = null;
    float[] var16 = var13.getColorComponents(var15);
    boolean var18 = var13.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var21 = null;
    org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, (java.awt.Paint)var13, 0.0f, 10, var21);
    int var23 = var13.getTransparency();
    java.awt.Color var24 = var13.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var4, (java.awt.Paint)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test286"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("0,-1,-1,1,1,1,1,1", var1, (-1.0f), 1.0f, var4, 0.0d, var6);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test287"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var6.getRangeAxisIndex(var7);
    org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var15 = var13.trimHeight(10.0d);
    double var17 = var13.calculateLeftInset(0.0d);
    double var18 = var13.getRight();
    double var20 = var13.extendHeight(1.0d);
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var32 = null;
    org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var31, var32);
    org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var31);
    var24.setFrame((org.jfree.chart.block.BlockFrame)var34);
    org.jfree.chart.block.BlockFrame var36 = var24.getFrame();
    var24.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.awt.geom.Rectangle2D var39 = var24.getBounds();
    var22.setBounds(var39);
    java.awt.geom.Rectangle2D var43 = var13.createOutsetRectangle(var39, true, false);
    var6.setInsets(var13, false);
    org.jfree.chart.event.PlotChangeEvent var46 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.axis.AxisLocation var47 = var6.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test288"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var15 = var14.getLabelToolTip();
    java.awt.Paint var16 = var14.getTickLabelPaint();
    var1.setPaint(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test289"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test290"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    org.jfree.chart.util.GradientPaintTransformer var26 = var17.getFillPaintTransformer();
    boolean var27 = var17.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test291"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var4 = var3.getLabelToolTip();
    java.awt.Font var5 = var3.getTickLabelFont();
    var1.setFont(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test292"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var2);
    java.lang.Object var4 = var3.clone();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartChangeEventType var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var6, var7);
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var8.setType(var9);
    boolean var11 = var3.equals((java.lang.Object)var9);
    org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets(12.0d, (-1.0d), 1.0d, 12.0d);
    boolean var17 = var3.equals((java.lang.Object)12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test293"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     var6.clearRangeMarkers();
//     org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
//     org.jfree.chart.util.RectangleInsets var12 = var6.getInsets();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var16 = var15.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var15, var17, var18);
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var19.axisChanged(var20);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var26 = var25.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var23, var25, var27, var28);
//     boolean var30 = var29.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var31 = var29.getDrawingSupplier();
//     var29.clearRangeMarkers();
//     org.jfree.chart.axis.AxisLocation var34 = var29.getDomainAxisLocation(0);
//     var19.setDomainAxisLocation(100, var34);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var45 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var46 = null;
//     org.jfree.chart.event.ChartChangeEvent var47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var45, var46);
//     org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var45);
//     var38.setFrame((org.jfree.chart.block.BlockFrame)var48);
//     org.jfree.chart.block.BlockFrame var50 = var38.getFrame();
//     var38.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var53 = var38.getBounds();
//     java.awt.geom.Point2D var54 = null;
//     org.jfree.chart.plot.PlotState var55 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     var19.draw(var36, var53, var54, var55, var56);
//     java.awt.geom.Rectangle2D var58 = var12.createOutsetRectangle(var53);
//     
//     // Checks the contract:  equals-hashcode on var6 and var29
//     assertTrue("Contract failed: equals-hashcode on var6 and var29", var6.equals(var29) ? var6.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var6
//     assertTrue("Contract failed: equals-hashcode on var29 and var6", var29.equals(var6) ? var29.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var31
//     assertTrue("Contract failed: equals-hashcode on var8 and var31", var8.equals(var31) ? var8.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var8
//     assertTrue("Contract failed: equals-hashcode on var31 and var8", var31.equals(var8) ? var31.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test294"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("Size2D[width=10.0, height=14.0]");
    org.jfree.data.category.CategoryDataset var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var1.generateLabel(var2, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test295"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    var17.setID("Size2D[width=10.0, height=14.0]");
    java.awt.Shape var20 = var17.getShape();
    var17.setShapeOutlineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test296"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    java.awt.Font var9 = var6.getNoDataMessageFont();
    java.awt.Color var12 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
    int var13 = var12.getTransparency();
    var6.setNoDataMessagePaint((java.awt.Paint)var12);
    var6.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test297"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    boolean var7 = var2.equals((java.lang.Object)1.0d);
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("", 0);
    int var13 = var12.getGreen();
    float[] var14 = null;
    float[] var15 = var12.getColorComponents(var14);
    boolean var17 = var12.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var20 = null;
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var12, 0.0f, 10, var20);
    java.awt.Color var24 = java.awt.Color.getColor("", 0);
    int var25 = var24.getGreen();
    float[] var26 = null;
    float[] var27 = var24.getColorComponents(var26);
    float[] var28 = var12.getRGBColorComponents(var26);
    float[] var29 = var2.getColorComponents(var28);
    java.awt.image.ColorModel var30 = null;
    java.awt.Rectangle var31 = null;
    org.jfree.chart.util.RectangleInsets var36 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var38 = var36.trimHeight(10.0d);
    double var40 = var36.calculateLeftInset(0.0d);
    double var41 = var36.getRight();
    double var43 = var36.extendHeight(1.0d);
    org.jfree.chart.block.LabelBlock var45 = new org.jfree.chart.block.LabelBlock("hi!");
    org.jfree.chart.block.LabelBlock var47 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var54 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var55 = null;
    org.jfree.chart.event.ChartChangeEvent var56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var54, var55);
    org.jfree.chart.block.BlockBorder var57 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var54);
    var47.setFrame((org.jfree.chart.block.BlockFrame)var57);
    org.jfree.chart.block.BlockFrame var59 = var47.getFrame();
    var47.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.awt.geom.Rectangle2D var62 = var47.getBounds();
    var45.setBounds(var62);
    java.awt.geom.Rectangle2D var66 = var36.createOutsetRectangle(var62, true, false);
    java.awt.geom.AffineTransform var67 = null;
    java.awt.RenderingHints var68 = null;
    java.awt.PaintContext var69 = var2.createContext(var30, var31, var62, var67, var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test298"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(14.0d, 1.0d);
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    double var6 = var5.getLength();
    boolean var7 = var2.equals((java.lang.Object)var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var12 = null;
    java.awt.Color var15 = java.awt.Color.getColor("", 0);
    int var16 = var15.getGreen();
    float[] var17 = null;
    float[] var18 = var15.getColorComponents(var17);
    boolean var20 = var15.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var23 = null;
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var15, 0.0f, 10, var23);
    org.jfree.chart.title.LegendGraphic var25 = new org.jfree.chart.title.LegendGraphic(var10, (java.awt.Paint)var15);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var27, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var27, var34);
    var25.setShape(var27);
    java.awt.Color var39 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var40 = null;
    org.jfree.chart.event.ChartChangeEvent var41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var39, var40);
    var25.setLinePaint((java.awt.Paint)var39);
    java.awt.geom.Rectangle2D var43 = var25.getBounds();
    boolean var44 = var2.equals((java.lang.Object)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test299"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var26);
    var17.setShape(var19);
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var32 = null;
    org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var31, var32);
    var17.setLinePaint((java.awt.Paint)var31);
    java.awt.geom.Rectangle2D var35 = var17.getBounds();
    org.jfree.chart.util.RectangleAnchor var36 = var17.getShapeAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test300"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.chart.event.ChartProgressEvent[source=10.0]", var1, 102.0d, 1.0f, (-1.0f));
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test301"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Font var12 = null;
//     java.awt.Color var15 = java.awt.Color.getColor("", 0);
//     int var16 = var15.getGreen();
//     float[] var17 = null;
//     float[] var18 = var15.getColorComponents(var17);
//     boolean var20 = var15.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var23 = null;
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var15, 0.0f, 10, var23);
//     java.util.List var25 = var24.getLines();
//     org.jfree.chart.util.HorizontalAlignment var26 = var24.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var31 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, var31, (java.lang.Comparable)"poly");
//     java.awt.geom.Rectangle2D var34 = var33.getBounds();
//     var10.setWrapper((org.jfree.chart.block.BlockContainer)var33);
//     java.awt.Font var36 = var10.getItemFont();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
//     org.jfree.chart.block.LengthConstraintType var41 = var40.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var42 = var10.arrange(var37, var40);
//     org.jfree.data.category.CategoryDataset var43 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var46 = var45.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var43, var45, var47, var48);
//     boolean var50 = var49.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var51 = var49.getDrawingSupplier();
//     var49.setRangeCrosshairVisible(false);
//     org.jfree.chart.util.RectangleEdge var55 = var49.getDomainAxisEdge(1);
//     var10.setPosition(var55);
//     
//     // Checks the contract:  equals-hashcode on var6 and var49
//     assertTrue("Contract failed: equals-hashcode on var6 and var49", var6.equals(var49) ? var6.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var6
//     assertTrue("Contract failed: equals-hashcode on var49 and var6", var49.equals(var6) ? var49.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test302"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var4 = new org.jfree.data.Range(0.0d, 0.0d);
    double var5 = var4.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0d, var4);
    org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
    double var10 = var9.getLength();
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var12, 100, 10);
    org.jfree.chart.JFreeChart var16 = null;
    var15.setChart(var16);
    var15.setPercent((-1));
    boolean var20 = var9.equals((java.lang.Object)var15);
    org.jfree.chart.block.RectangleConstraint var21 = var6.toRangeHeight(var9);
    org.jfree.data.Range var22 = org.jfree.data.Range.combine(var0, var9);
    org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 0.0d);
    double var27 = var26.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(1.0d, var26);
    org.jfree.data.Range var29 = org.jfree.data.Range.combine(var22, var26);
    java.lang.String var30 = var22.toString();
    org.jfree.data.Range var33 = org.jfree.data.Range.shift(var22, 1.0d, true);
    boolean var35 = var22.contains(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "Range[0.0,0.0]"+ "'", var30.equals("Range[0.0,0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test303"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var16 = var15.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
//     org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var21 = var20.getLength();
//     org.jfree.chart.JFreeChart var23 = null;
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
//     org.jfree.chart.JFreeChart var27 = null;
//     var26.setChart(var27);
//     var26.setPercent((-1));
//     boolean var31 = var20.equals((java.lang.Object)var26);
//     org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
//     org.jfree.data.Range var33 = var32.getWidthRange();
//     org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var37 = var36.getLabelToolTip();
//     java.awt.Paint var38 = var36.getTickLabelPaint();
//     java.lang.Object var39 = null;
//     boolean var40 = var36.equals(var39);
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var43 = var42.getLabelToolTip();
//     java.awt.Font var44 = var42.getTickLabelFont();
//     var36.setLabelFont(var44);
//     var10.setItemFont(var44);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var50 = var49.getLabelToolTip();
//     java.awt.Stroke var51 = var49.getAxisLineStroke();
//     double var52 = var49.getLowerMargin();
//     float var53 = var49.getTickMarkInsideLength();
//     org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var64 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var65 = null;
//     org.jfree.chart.event.ChartChangeEvent var66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var64, var65);
//     org.jfree.chart.block.BlockBorder var67 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var64);
//     var57.setFrame((org.jfree.chart.block.BlockFrame)var67);
//     org.jfree.chart.block.BlockFrame var69 = var57.getFrame();
//     var57.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var72 = var57.getBounds();
//     org.jfree.chart.util.RectangleAnchor var73 = null;
//     java.awt.geom.Point2D var74 = org.jfree.chart.util.RectangleAnchor.coordinates(var72, var73);
//     org.jfree.chart.util.RectangleEdge var75 = null;
//     double var76 = var49.getCategoryStart((-1), (-1), var72, var75);
//     org.jfree.data.category.CategoryDataset var77 = null;
//     org.jfree.chart.axis.CategoryAxis var79 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var80 = var79.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var81 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var82 = null;
//     org.jfree.chart.plot.CategoryPlot var83 = new org.jfree.chart.plot.CategoryPlot(var77, var79, var81, var82);
//     boolean var84 = var83.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var85 = var83.getDrawingSupplier();
//     var83.clearRangeMarkers();
//     boolean var87 = var83.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var89 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var90 = var89.getLabelToolTip();
//     java.awt.Stroke var91 = var89.getAxisLineStroke();
//     var83.setDomainGridlineStroke(var91);
//     java.lang.Object var93 = var10.draw(var47, var72, (java.lang.Object)var91);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test304"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test305"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 10.0f, 0.0f, 12.0d, 10.0f, 0.0f);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test306"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    java.awt.Paint[] var6 = new java.awt.Paint[] { var2};
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    java.awt.Paint[] var11 = new java.awt.Paint[] { var9};
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var25};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var11, var13, var15, var26);
    java.awt.Shape var28 = var27.getNextShape();
    java.awt.Stroke var29 = var27.getNextStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test307"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    java.awt.Font var9 = var6.getNoDataMessageFont();
    java.awt.Stroke var10 = var6.getRangeCrosshairStroke();
    var6.setAnchorValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test308"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    java.awt.Stroke var14 = var12.getAxisLineStroke();
    var6.setDomainGridlineStroke(var14);
    org.jfree.chart.axis.ValueAxis var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setRangeAxis((-33), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test309"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Font var12 = null;
//     java.awt.Color var15 = java.awt.Color.getColor("", 0);
//     int var16 = var15.getGreen();
//     float[] var17 = null;
//     float[] var18 = var15.getColorComponents(var17);
//     boolean var20 = var15.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var23 = null;
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var15, 0.0f, 10, var23);
//     java.util.List var25 = var24.getLines();
//     org.jfree.chart.util.HorizontalAlignment var26 = var24.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var31 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, var31, (java.lang.Comparable)"poly");
//     java.awt.geom.Rectangle2D var34 = var33.getBounds();
//     var10.setWrapper((org.jfree.chart.block.BlockContainer)var33);
//     java.awt.Font var36 = var10.getItemFont();
//     java.awt.Font var37 = var10.getItemFont();
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var41 = var40.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var38, var40, var42, var43);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     int var46 = var44.getRangeAxisIndex(var45);
//     org.jfree.chart.LegendItemSource[] var47 = new org.jfree.chart.LegendItemSource[] { var44};
//     var10.setSources(var47);
//     
//     // Checks the contract:  equals-hashcode on var6 and var44
//     assertTrue("Contract failed: equals-hashcode on var6 and var44", var6.equals(var44) ? var6.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var6
//     assertTrue("Contract failed: equals-hashcode on var44 and var6", var44.equals(var6) ? var44.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test310"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
    org.jfree.chart.util.RectangleInsets var12 = var6.getInsets();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var16 = var15.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var15, var17, var18);
    org.jfree.chart.event.AxisChangeEvent var20 = null;
    var19.axisChanged(var20);
    org.jfree.chart.util.RectangleInsets var22 = var19.getInsets();
    org.jfree.chart.util.SortOrder var23 = var19.getColumnRenderingOrder();
    var6.setColumnRenderingOrder(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test311"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(3);
    var1.clear();

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test312"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("LegendItemEntity: seriesKey=null, dataset=null", "hi!");

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test313"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var2);
    java.lang.Object var4 = var3.clone();
    org.jfree.data.general.Dataset var5 = var3.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test314"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var6.getDomainMarkers((-1), var8);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleAnchor var13 = null;
    java.awt.geom.Point2D var14 = org.jfree.chart.util.RectangleAnchor.coordinates(var12, var13);
    var6.zoomRangeAxes(100.0d, var11, var14);
    org.jfree.chart.util.RectangleEdge var17 = var6.getDomainAxisEdge(0);
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var22 = var21.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var19, var21, var23, var24);
    boolean var26 = var25.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var27 = var25.getDrawingSupplier();
    var25.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var30 = var25.getDomainAxisLocation(0);
    var6.setRangeAxisLocation(3, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test315"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    org.jfree.chart.event.MarkerChangeEvent var11 = null;
    var6.markerChanged(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test316"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    java.lang.Object var4 = null;
    boolean var5 = var1.equals(var4);
    org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var12 = var10.trimHeight(10.0d);
    double var14 = var10.calculateLeftInset(0.0d);
    double var16 = var10.trimHeight(12.0d);
    double var17 = var10.getLeft();
    double var19 = var10.calculateLeftInset(25.0d);
    var1.setTickLabelInsets(var10);
    var1.setLabelToolTip("Size2D[width=10.0, height=14.0]");
    var1.setVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1.0d));

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test317"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    var17.setID("Size2D[width=10.0, height=14.0]");
    double var20 = var17.getContentXOffset();
    java.lang.Object var21 = null;
    boolean var22 = var17.equals(var21);
    boolean var23 = var17.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test318"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var27 = var26.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var24, var26, var28, var29);
    boolean var31 = var30.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
    var30.clearRangeMarkers();
    boolean var34 = var30.isDomainGridlinesVisible();
    boolean var35 = var22.equals((java.lang.Object)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test319"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("LegendItemEntity: seriesKey=null, dataset=null", var1);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test320"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.CategoryAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDomainGridlinePosition(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test321"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var2);
    java.lang.Object var4 = var3.clone();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartChangeEventType var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var6, var7);
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var8.setType(var9);
    boolean var11 = var3.equals((java.lang.Object)var9);
    java.lang.Comparable var12 = null;
    var3.setSeriesKey(var12);
    var3.setSeriesKey((java.lang.Comparable)"");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test322"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    java.awt.Font var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var15 = null;
    java.awt.Rectangle var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    java.awt.geom.AffineTransform var18 = null;
    java.awt.RenderingHints var19 = null;
    java.awt.PaintContext var20 = var14.createContext(var15, var16, var17, var18, var19);
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var14);
    var6.setNoDataMessagePaint((java.awt.Paint)var14);
    java.awt.Paint var23 = null;
    var6.setBackgroundPaint(var23);
    org.jfree.chart.plot.DrawingSupplier var25 = null;
    var6.setDrawingSupplier(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test323"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    var4.addOptionalLibrary("");
    org.jfree.chart.ui.BasicProjectInfo var12 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var13 = var12.getVersion();
    var12.addOptionalLibrary("");
    var4.addOptionalLibrary((org.jfree.chart.ui.Library)var12);
    var4.addOptionalLibrary("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var13.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test324"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.ui.BasicProjectInfo var8 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var9 = var8.getCopyright();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var11, var18);
    boolean var20 = var8.equals((java.lang.Object)var11);
    java.awt.Font var23 = null;
    java.awt.Color var26 = java.awt.Color.getColor("", 0);
    int var27 = var26.getGreen();
    float[] var28 = null;
    float[] var29 = var26.getColorComponents(var28);
    boolean var31 = var26.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var34 = null;
    org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, (java.awt.Paint)var26, 0.0f, 10, var34);
    java.awt.Color var38 = java.awt.Color.getColor("", 0);
    int var39 = var38.getGreen();
    float[] var40 = null;
    float[] var41 = var38.getColorComponents(var40);
    float[] var42 = var26.getRGBColorComponents(var40);
    java.awt.Color var43 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem(var0, "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", var11, (java.awt.Paint)var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test325"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
    var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.awt.geom.Rectangle2D var16 = var1.getBounds();
    org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var23 = var21.trimHeight(10.0d);
    double var25 = var21.calculateTopInset(10.0d);
    var1.setMargin(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1.0d));

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test326"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var6.setFixedDomainAxisSpace(var12);
    org.jfree.chart.event.MarkerChangeEvent var14 = null;
    var6.markerChanged(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test327"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var9 = var7.trimHeight(10.0d);
    double var11 = var7.calculateLeftInset(0.0d);
    double var13 = var7.calculateTopOutset(14.0d);
    java.awt.Color var16 = java.awt.Color.getColor("", 0);
    int var17 = var16.getGreen();
    float[] var18 = null;
    float[] var19 = var16.getColorComponents(var18);
    java.awt.Paint[] var20 = new java.awt.Paint[] { var16};
    java.awt.Color var23 = java.awt.Color.getColor("", 0);
    int var24 = var23.getGreen();
    java.awt.Paint[] var25 = new java.awt.Paint[] { var23};
    java.awt.Stroke var26 = null;
    java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
    java.awt.Stroke var28 = null;
    java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.rotateShape(var35, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var40 = new java.awt.Shape[] { var39};
    org.jfree.chart.plot.DefaultDrawingSupplier var41 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var25, var27, var29, var40);
    java.awt.Paint[] var42 = null;
    java.awt.Stroke var43 = null;
    java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
    java.awt.Stroke var45 = null;
    java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
    java.awt.Color var49 = java.awt.Color.getColor("", 0);
    int var50 = var49.getGreen();
    float[] var51 = null;
    float[] var52 = var49.getColorComponents(var51);
    java.awt.Paint[] var53 = new java.awt.Paint[] { var49};
    java.awt.Color var56 = java.awt.Color.getColor("", 0);
    int var57 = var56.getGreen();
    java.awt.Paint[] var58 = new java.awt.Paint[] { var56};
    java.awt.Stroke var59 = null;
    java.awt.Stroke[] var60 = new java.awt.Stroke[] { var59};
    java.awt.Stroke var61 = null;
    java.awt.Stroke[] var62 = new java.awt.Stroke[] { var61};
    java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var68 = org.jfree.chart.util.ShapeUtilities.rotateShape(var64, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.rotateShape(var68, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var73 = new java.awt.Shape[] { var72};
    org.jfree.chart.plot.DefaultDrawingSupplier var74 = new org.jfree.chart.plot.DefaultDrawingSupplier(var53, var58, var60, var62, var73);
    org.jfree.chart.plot.DefaultDrawingSupplier var75 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var42, var44, var46, var73);
    java.awt.Paint var76 = var75.getNextPaint();
    org.jfree.chart.block.BlockBorder var77 = new org.jfree.chart.block.BlockBorder(var7, var76);
    var1.setLabelInsets(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test328"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var12 = var11.getLabelToolTip();
    java.awt.Paint var13 = var11.getTickLabelPaint();
    java.lang.Object var14 = null;
    boolean var15 = var11.equals(var14);
    var6.setDomainAxis(var11);
    org.jfree.chart.LegendItemCollection var17 = var6.getLegendItems();
    org.jfree.chart.axis.ValueAxis var18 = null;
    int var19 = var6.getRangeAxisIndex(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test329"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("LegendItemEntity: seriesKey=null, dataset=null", var1, 100.0f, 10.0f, var4, 100.0d, var6);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test330"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Font var12 = null;
    java.awt.Color var15 = java.awt.Color.getColor("", 0);
    int var16 = var15.getGreen();
    float[] var17 = null;
    float[] var18 = var15.getColorComponents(var17);
    boolean var20 = var15.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var23 = null;
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var15, 0.0f, 10, var23);
    java.util.List var25 = var24.getLines();
    org.jfree.chart.util.HorizontalAlignment var26 = var24.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var27 = null;
    org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var31 = null;
    org.jfree.chart.title.LegendItemBlockContainer var33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, var31, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var34 = var33.getBounds();
    var10.setWrapper((org.jfree.chart.block.BlockContainer)var33);
    java.awt.Font var36 = var10.getItemFont();
    java.awt.Graphics2D var37 = null;
    org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var41 = var40.getWidthConstraintType();
    org.jfree.chart.util.Size2D var42 = var10.arrange(var37, var40);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var46 = new org.jfree.chart.entity.LegendItemEntity(var45);
    boolean var47 = var42.equals((java.lang.Object)var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test331"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var12 = var11.getLabelToolTip();
    java.awt.Stroke var13 = var11.getAxisLineStroke();
    var6.setDomainGridlineStroke(var13);
    var6.setWeight((-33));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test332"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.chart.util.RectangleInsets var24 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var26 = var24.trimHeight(10.0d);
    double var28 = var24.calculateLeftInset(0.0d);
    double var29 = var24.getRight();
    double var31 = var24.extendHeight(1.0d);
    org.jfree.chart.util.UnitType var32 = var24.getUnitType();
    boolean var34 = var32.equals((java.lang.Object)10);
    org.jfree.chart.util.RectangleInsets var39 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var41 = var39.trimHeight(10.0d);
    double var43 = var39.calculateTopInset(10.0d);
    double var45 = var39.calculateLeftInset(12.0d);
    double var46 = var39.getBottom();
    boolean var47 = var32.equals((java.lang.Object)var39);
    boolean var48 = var19.equals((java.lang.Object)var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test333"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
    org.jfree.chart.util.RectangleInsets var12 = var6.getInsets();
    double var14 = var12.calculateLeftInset(14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 8.0d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test334"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test335"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var11 = var10.getLabelToolTip();
    java.awt.Stroke var12 = var10.getAxisLineStroke();
    var6.setRangeGridlineStroke(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test336"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(12.0d);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var3, 100, 10);
    org.jfree.chart.JFreeChart var7 = null;
    var6.setChart(var7);
    boolean var9 = var1.equals((java.lang.Object)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test337"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    java.awt.Stroke var14 = var12.getAxisLineStroke();
    var6.setDomainGridlineStroke(var14);
    org.jfree.chart.axis.ValueAxis var17 = var6.getRangeAxis((-1));
    var6.setForegroundAlpha(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test338"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    var17.setID("Size2D[width=10.0, height=14.0]");
    double var20 = var17.getContentXOffset();
    java.awt.Paint var21 = var17.getOutlinePaint();
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var25 = var24.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var22, var24, var26, var27);
    boolean var29 = var28.isSubplot();
    org.jfree.chart.axis.AxisLocation var31 = var28.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    java.awt.Graphics2D var33 = null;
    org.jfree.data.Range var37 = new org.jfree.data.Range(0.0d, 0.0d);
    double var38 = var37.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var39 = new org.jfree.chart.block.RectangleConstraint(1.0d, var37);
    org.jfree.data.Range var42 = new org.jfree.data.Range(0.0d, 0.0d);
    double var43 = var42.getLength();
    org.jfree.chart.JFreeChart var45 = null;
    org.jfree.chart.event.ChartProgressEvent var48 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var45, 100, 10);
    org.jfree.chart.JFreeChart var49 = null;
    var48.setChart(var49);
    var48.setPercent((-1));
    boolean var53 = var42.equals((java.lang.Object)var48);
    org.jfree.chart.block.RectangleConstraint var54 = var39.toRangeHeight(var42);
    org.jfree.data.Range var55 = var54.getWidthRange();
    org.jfree.chart.util.Size2D var56 = var32.arrange(var33, var54);
    org.jfree.chart.util.RectangleEdge var57 = var32.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var58 = var32.getLegendItemGraphicAnchor();
    org.jfree.chart.util.RectangleAnchor var59 = var32.getLegendItemGraphicLocation();
    var17.setShapeLocation(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test339"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateLeftInset(0.0d);
    double var9 = var4.getRight();
    double var11 = var4.extendHeight(1.0d);
    org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("hi!");
    org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var22 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22, var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var22);
    var15.setFrame((org.jfree.chart.block.BlockFrame)var25);
    org.jfree.chart.block.BlockFrame var27 = var15.getFrame();
    var15.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.awt.geom.Rectangle2D var30 = var15.getBounds();
    var13.setBounds(var30);
    java.awt.geom.Rectangle2D var34 = var4.createOutsetRectangle(var30, true, false);
    org.jfree.chart.entity.TickLabelEntity var37 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var34, "0,-1,-1,1,1,1,1,1", "");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test340"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var11 = var10.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var8, var10, var12, var13);
    boolean var15 = var14.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
    var14.clearRangeMarkers();
    boolean var18 = var14.isSubplot();
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var21 = var20.getLabelToolTip();
    java.awt.Stroke var22 = var20.getAxisLineStroke();
    var14.setDomainGridlineStroke(var22);
    var6.setOutlineStroke(var22);
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var28 = var27.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var25, var27, var29, var30);
    org.jfree.chart.axis.ValueAxis var32 = null;
    int var33 = var31.getRangeAxisIndex(var32);
    org.jfree.chart.axis.ValueAxis var34 = var31.getRangeAxis();
    boolean var35 = var6.equals((java.lang.Object)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test341"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var1, 100, 10);
    org.jfree.chart.JFreeChart var5 = null;
    var4.setChart(var5);
    var4.setPercent((-1));
    var4.setPercent(0);
    org.jfree.chart.JFreeChart var11 = var4.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test342"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    org.jfree.chart.util.RectangleAnchor var35 = var10.getLegendItemGraphicLocation();
    org.jfree.chart.block.BlockContainer var36 = var10.getItemContainer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test343"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    org.jfree.chart.util.RectangleEdge var35 = var10.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var36 = var10.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var37 = var10.getLegendItemGraphicAnchor();
    org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var44 = var42.trimHeight(10.0d);
    double var46 = var42.calculateTopInset(10.0d);
    double var48 = var42.calculateLeftInset(12.0d);
    double var49 = var42.getBottom();
    var10.setLegendItemGraphicPadding(var42);
    double var51 = var10.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test344"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    int var14 = var4.getBlue();
    int var15 = var4.getBlue();
    java.awt.Color var16 = var4.darker();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test345"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    java.lang.String var6 = var4.getVersion();
    var4.setVersion("Size2D[width=10.0, height=14.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var6.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test346"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    java.lang.Object var4 = null;
    boolean var5 = var1.equals(var4);
    org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var12 = var10.trimHeight(10.0d);
    double var14 = var10.calculateLeftInset(0.0d);
    double var16 = var10.trimHeight(12.0d);
    double var17 = var10.getLeft();
    double var19 = var10.calculateLeftInset(25.0d);
    var1.setTickLabelInsets(var10);
    boolean var21 = var1.isTickLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test347"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var2);
    org.jfree.chart.entity.LegendItemEntity var4 = new org.jfree.chart.entity.LegendItemEntity(var2);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var2, "poly", "0,-1,-1,1,1,1,1,1");
    org.jfree.chart.entity.CategoryLabelEntity var10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var2, "", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]");
    java.lang.String var11 = var10.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "CategoryLabelEntity: category=false, tooltip=, url=org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]"+ "'", var11.equals("CategoryLabelEntity: category=false, tooltip=, url=org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]"));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test348"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    boolean var11 = var6.isSubplot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    var6.setRenderer(10, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test349"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var3);
    org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var7 = var6.getType();
    var4.setType(var7);
    org.jfree.data.Range var11 = new org.jfree.data.Range(0.0d, 0.0d);
    double var12 = var11.getUpperBound();
    double var13 = var11.getCentralValue();
    org.jfree.data.general.Dataset var14 = null;
    org.jfree.data.general.DatasetChangeEvent var15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var11, var14);
    boolean var16 = var7.equals((java.lang.Object)var11);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 100.0f);
    boolean var20 = var7.equals((java.lang.Object)var19);
    java.lang.String var21 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var21.equals("ChartChangeEventType.GENERAL"));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test350"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1", "poly", var3, "0,-1,-1,1,1,1,1,1", "", "");
    org.jfree.chart.ui.Library[] var8 = var7.getLibraries();
    java.lang.String var9 = var7.getCopyright();
    var7.setLicenceText("LegendItemEntity: seriesKey=null, dataset=null");
    java.awt.Image var12 = var7.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "0,-1,-1,1,1,1,1,1"+ "'", var9.equals("0,-1,-1,1,1,1,1,1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test351"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
    boolean var12 = var6.isRangeGridlinesVisible();
    var6.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test352"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var8 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var9 = null;
//     org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
//     var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
//     org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
//     var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var16 = var1.getBounds();
//     var1.setHeight(100.0d);
//     java.lang.String var19 = var1.getToolTipText();
//     org.jfree.chart.util.RectangleInsets var24 = new org.jfree.chart.util.RectangleInsets(12.0d, (-1.0d), 1.0d, 12.0d);
//     double var25 = var24.getLeft();
//     var1.setPadding(var24);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var32 = var31.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var29, var31, var33, var34);
//     org.jfree.chart.event.AxisChangeEvent var36 = null;
//     var35.axisChanged(var36);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var42 = var41.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var41, var43, var44);
//     boolean var46 = var45.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var47 = var45.getDrawingSupplier();
//     var45.clearRangeMarkers();
//     org.jfree.chart.axis.AxisLocation var50 = var45.getDomainAxisLocation(0);
//     var35.setDomainAxisLocation(100, var50);
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.block.LabelBlock var54 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var61 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var62 = null;
//     org.jfree.chart.event.ChartChangeEvent var63 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var61, var62);
//     org.jfree.chart.block.BlockBorder var64 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var61);
//     var54.setFrame((org.jfree.chart.block.BlockFrame)var64);
//     org.jfree.chart.block.BlockFrame var66 = var54.getFrame();
//     var54.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var69 = var54.getBounds();
//     java.awt.geom.Point2D var70 = null;
//     org.jfree.chart.plot.PlotState var71 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     var35.draw(var52, var69, var70, var71, var72);
//     java.awt.geom.Point2D var74 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 10.0d, var69);
//     boolean var75 = var1.equals((java.lang.Object)var74);
//     
//     // Checks the contract:  equals-hashcode on var11 and var64
//     assertTrue("Contract failed: equals-hashcode on var11 and var64", var11.equals(var64) ? var11.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var11
//     assertTrue("Contract failed: equals-hashcode on var64 and var11", var64.equals(var11) ? var64.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var66
//     assertTrue("Contract failed: equals-hashcode on var13 and var66", var13.equals(var66) ? var13.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var13
//     assertTrue("Contract failed: equals-hashcode on var66 and var13", var66.equals(var13) ? var66.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test353"); }


    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    float[] var11 = null;
    float[] var12 = var9.getColorComponents(var11);
    boolean var14 = var9.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var17 = null;
    org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var9, 0.0f, 10, var17);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var4, (java.awt.Paint)var9);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var21, var28);
    var19.setShape(var21);
    java.awt.Color var33 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var34 = null;
    org.jfree.chart.event.ChartChangeEvent var35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var33, var34);
    var19.setLinePaint((java.awt.Paint)var33);
    java.awt.geom.Rectangle2D var37 = var19.getBounds();
    java.awt.geom.Point2D var38 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(102.0d, 14.0d, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test354"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    java.lang.Object var4 = null;
    boolean var5 = var1.equals(var4);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var8 = var7.getLabelToolTip();
    java.awt.Font var9 = var7.getTickLabelFont();
    var1.setLabelFont(var9);
    var1.setMaximumCategoryLabelWidthRatio(10.0f);
    var1.setCategoryMargin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test355"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     var6.clearRangeMarkers();
//     org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var6.setFixedDomainAxisSpace(var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("hi!");
//     org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var25 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var26 = null;
//     org.jfree.chart.event.ChartChangeEvent var27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var25, var26);
//     org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var25);
//     var18.setFrame((org.jfree.chart.block.BlockFrame)var28);
//     org.jfree.chart.block.BlockFrame var30 = var18.getFrame();
//     var18.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var33 = var18.getBounds();
//     var16.setBounds(var33);
//     var6.drawBackground(var14, var33);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test356"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    java.awt.Font var9 = var6.getNoDataMessageFont();
    java.awt.Color var12 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
    int var13 = var12.getTransparency();
    var6.setNoDataMessagePaint((java.awt.Paint)var12);
    var6.setRangeGridlinesVisible(true);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var21 = var20.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var20, var22, var23);
    boolean var25 = var24.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
    var24.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var29 = var24.getDomainAxisLocation(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDomainAxisLocation((-33), var29, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test357"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    java.lang.Object var4 = null;
    boolean var5 = var1.equals(var4);
    org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var12 = var10.trimHeight(10.0d);
    double var14 = var10.calculateLeftInset(0.0d);
    double var16 = var10.trimHeight(12.0d);
    double var17 = var10.getLeft();
    double var19 = var10.calculateLeftInset(25.0d);
    var1.setTickLabelInsets(var10);
    var1.setLabelToolTip("Size2D[width=10.0, height=14.0]");
    var1.setFixedDimension(0.0d);
    var1.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1.0d));

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test358"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    java.awt.Stroke var14 = var12.getAxisLineStroke();
    var6.setDomainGridlineStroke(var14);
    org.jfree.data.general.DatasetGroup var16 = var6.getDatasetGroup();
    int var17 = var6.getRangeAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test359"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("0,-1,-1,1,1,1,1,1", var1);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test360"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    double var5 = var4.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test361"); }


    java.awt.Font var3 = null;
    java.awt.Color var6 = java.awt.Color.getColor("", 0);
    int var7 = var6.getGreen();
    float[] var8 = null;
    float[] var9 = var6.getColorComponents(var8);
    boolean var11 = var6.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var14 = null;
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, (java.awt.Paint)var6, 0.0f, 10, var14);
    java.awt.Color var18 = java.awt.Color.getColor("", 0);
    int var19 = var18.getGreen();
    float[] var20 = null;
    float[] var21 = var18.getColorComponents(var20);
    float[] var22 = var6.getRGBColorComponents(var20);
    java.awt.Color var23 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", var6);
    java.awt.Color var26 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var27 = null;
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var27);
    int var29 = var26.getRed();
    java.awt.Color var30 = var26.brighter();
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var34 = var33.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var31, var33, var35, var36);
    boolean var38 = var37.isSubplot();
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var42 = var41.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var41, var43, var44);
    boolean var46 = var45.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var47 = var45.getDrawingSupplier();
    var45.clearRangeMarkers();
    boolean var49 = var45.isSubplot();
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var52 = var51.getLabelToolTip();
    java.awt.Stroke var53 = var51.getAxisLineStroke();
    var45.setDomainGridlineStroke(var53);
    var37.setOutlineStroke(var53);
    org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var64 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var65 = null;
    org.jfree.chart.event.ChartChangeEvent var66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var64, var65);
    org.jfree.chart.block.BlockBorder var67 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var64);
    var57.setFrame((org.jfree.chart.block.BlockFrame)var67);
    org.jfree.chart.block.BlockFrame var69 = var57.getFrame();
    var57.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var72 = var57.getToolTipText();
    double var73 = var57.getWidth();
    org.jfree.chart.util.RectangleInsets var74 = var57.getMargin();
    org.jfree.chart.block.LineBorder var75 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var30, var53, var74);
    org.jfree.chart.plot.ValueMarker var76 = new org.jfree.chart.plot.ValueMarker(100.0d, (java.awt.Paint)var23, var53);
    java.awt.Paint var77 = var76.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test362"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
    org.jfree.chart.util.RectangleInsets var12 = var6.getInsets();
    var6.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test363"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var1, var2);
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    var3.setType(var4);
    java.lang.Object var6 = var3.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test364"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(12.0d);
    org.jfree.chart.ui.BasicProjectInfo var6 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    var6.addOptionalLibrary("0,-1,-1,1,1,1,1,1");
    int var9 = var1.compareTo((java.lang.Object)var6);
    int var10 = var1.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test365"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    int var14 = var4.getTransparency();
    java.awt.Color var15 = var4.brighter();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test366"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var3);
    int var5 = var2.getRed();
    java.awt.Color var6 = var2.brighter();
    int var7 = var2.getRed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test367"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var4 = new org.jfree.data.Range(0.0d, 0.0d);
    double var5 = var4.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0d, var4);
    org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
    double var10 = var9.getLength();
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var12, 100, 10);
    org.jfree.chart.JFreeChart var16 = null;
    var15.setChart(var16);
    var15.setPercent((-1));
    boolean var20 = var9.equals((java.lang.Object)var15);
    org.jfree.chart.block.RectangleConstraint var21 = var6.toRangeHeight(var9);
    org.jfree.data.Range var22 = org.jfree.data.Range.combine(var0, var9);
    java.awt.Font var24 = null;
    java.awt.Color var27 = java.awt.Color.getColor("", 0);
    int var28 = var27.getGreen();
    float[] var29 = null;
    float[] var30 = var27.getColorComponents(var29);
    boolean var32 = var27.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var35 = null;
    org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, (java.awt.Paint)var27, 0.0f, 10, var35);
    java.util.List var37 = var36.getLines();
    org.jfree.chart.util.HorizontalAlignment var38 = var36.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var39 = null;
    org.jfree.chart.block.ColumnArrangement var42 = new org.jfree.chart.block.ColumnArrangement(var38, var39, 25.0d, (-1.0d));
    boolean var43 = var9.equals((java.lang.Object)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test368"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.util.List var11 = var6.getAnnotations();
    org.jfree.chart.axis.AxisLocation var13 = var6.getDomainAxisLocation(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test369"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    org.jfree.chart.util.RectangleEdge var35 = var10.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var36 = var10.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var37 = var10.getLegendItemGraphicAnchor();
    org.jfree.chart.util.RectangleInsets var38 = var10.getItemLabelPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test370"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var6.axisChanged(var7);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var14, var15);
    boolean var17 = var16.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
    var16.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var21 = var16.getDomainAxisLocation(0);
    var6.setDomainAxisLocation(100, var21);
    var6.configureDomainAxes();
    var6.clearDomainMarkers();
    var6.setBackgroundAlpha((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test371"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    java.awt.Font var9 = var6.getNoDataMessageFont();
    org.jfree.data.category.CategoryDataset var10 = var6.getDataset();
    org.jfree.data.general.DatasetGroup var11 = var6.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test372"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 1.0d, 14.0d);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var2, "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test373"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var6.getDomainMarkers((-1), var8);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleAnchor var13 = null;
    java.awt.geom.Point2D var14 = org.jfree.chart.util.RectangleAnchor.coordinates(var12, var13);
    var6.zoomRangeAxes(100.0d, var11, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var6.setFixedLegendItems(var16);
    var6.mapDatasetToRangeAxis(3, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test374"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test375"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.chart.event.ChartProgressEvent[source=10.0]", var1);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test376"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("CategoryLabelEntity: category=false, tooltip=, url=org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", var1, 0.0f, 100.0f, 12.0d, (-1.0f), 0.0f);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test377"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var4 = new org.jfree.data.Range(0.0d, 0.0d);
    double var5 = var4.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0d, var4);
    org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
    double var10 = var9.getLength();
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var12, 100, 10);
    org.jfree.chart.JFreeChart var16 = null;
    var15.setChart(var16);
    var15.setPercent((-1));
    boolean var20 = var9.equals((java.lang.Object)var15);
    org.jfree.chart.block.RectangleConstraint var21 = var6.toRangeHeight(var9);
    org.jfree.data.Range var22 = org.jfree.data.Range.combine(var0, var9);
    org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 0.0d);
    double var27 = var26.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(1.0d, var26);
    org.jfree.data.Range var29 = org.jfree.data.Range.combine(var22, var26);
    org.jfree.data.general.Dataset var30 = null;
    org.jfree.data.general.DatasetChangeEvent var31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var22, var30);
    org.jfree.data.Range var34 = org.jfree.data.Range.expand(var22, 102.0d, 0.0d);
    java.lang.String var35 = var34.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "Range[0.0,0.0]"+ "'", var35.equals("Range[0.0,0.0]"));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test378"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
    org.jfree.chart.util.RectangleInsets var12 = var6.getInsets();
    org.jfree.chart.plot.DatasetRenderingOrder var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDatasetRenderingOrder(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test379"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    java.awt.Font var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("", 0);
    int var15 = var14.getGreen();
    float[] var16 = null;
    float[] var17 = var14.getColorComponents(var16);
    boolean var19 = var14.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var22 = null;
    org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var14, 0.0f, 10, var22);
    int var24 = var14.getTransparency();
    java.awt.color.ColorSpace var25 = var14.getColorSpace();
    var6.setNoDataMessagePaint((java.awt.Paint)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test380"); }


    java.awt.Font var2 = null;
    java.awt.Color var5 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var6 = null;
    java.awt.Rectangle var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    java.awt.geom.AffineTransform var9 = null;
    java.awt.RenderingHints var10 = null;
    java.awt.PaintContext var11 = var5.createContext(var6, var7, var8, var9, var10);
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, (java.awt.Paint)var5);
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var17 = var16.getLabelToolTip();
    java.awt.Font var18 = var16.getTickLabelFont();
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var23 = null;
    java.awt.Color var26 = java.awt.Color.getColor("", 0);
    int var27 = var26.getGreen();
    float[] var28 = null;
    float[] var29 = var26.getColorComponents(var28);
    boolean var31 = var26.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var34 = null;
    org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, (java.awt.Paint)var26, 0.0f, 10, var34);
    org.jfree.chart.title.LegendGraphic var36 = new org.jfree.chart.title.LegendGraphic(var21, (java.awt.Paint)var26);
    org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var18, (java.awt.Paint)var26);
    java.awt.Font var39 = null;
    java.awt.Color var42 = java.awt.Color.getColor("", 0);
    int var43 = var42.getGreen();
    float[] var44 = null;
    float[] var45 = var42.getColorComponents(var44);
    boolean var47 = var42.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var50 = null;
    org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var39, (java.awt.Paint)var42, 0.0f, 10, var50);
    int var52 = var42.getTransparency();
    java.awt.Color var53 = var42.darker();
    java.awt.Color var54 = var53.darker();
    var12.addLine("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var18, (java.awt.Paint)var54);
    java.awt.Font var57 = null;
    java.awt.Color var60 = java.awt.Color.getColor("", 0);
    int var61 = var60.getGreen();
    float[] var62 = null;
    float[] var63 = var60.getColorComponents(var62);
    boolean var65 = var60.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var68 = null;
    org.jfree.chart.text.TextBlock var69 = org.jfree.chart.text.TextUtilities.createTextBlock("", var57, (java.awt.Paint)var60, 0.0f, 10, var68);
    java.awt.Color var72 = java.awt.Color.getColor("", 0);
    int var73 = var72.getGreen();
    float[] var74 = null;
    float[] var75 = var72.getColorComponents(var74);
    float[] var76 = var60.getRGBColorComponents(var74);
    int var77 = var60.getGreen();
    org.jfree.chart.block.LabelBlock var78 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var18, (java.awt.Paint)var60);
    var78.setID("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test381"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var4 = var3.getLabelToolTip();
    java.awt.Font var5 = var3.getTickLabelFont();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var10 = null;
    java.awt.Color var13 = java.awt.Color.getColor("", 0);
    int var14 = var13.getGreen();
    float[] var15 = null;
    float[] var16 = var13.getColorComponents(var15);
    boolean var18 = var13.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var21 = null;
    org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, (java.awt.Paint)var13, 0.0f, 10, var21);
    org.jfree.chart.title.LegendGraphic var23 = new org.jfree.chart.title.LegendGraphic(var8, (java.awt.Paint)var13);
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var5, (java.awt.Paint)var13);
    java.awt.Paint var25 = null;
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var25);
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.text.TextBlockAnchor var30 = null;
    java.awt.Shape var34 = var26.calculateBounds(var27, 10.0f, 10.0f, var30, 1.0f, 0.0f, (-1.0d));
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.text.TextBlockAnchor var38 = null;
    var26.draw(var35, 100.0f, 1.0f, var38, 10.0f, 1.0f, 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test382"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var37 = var36.getLabelToolTip();
    java.awt.Paint var38 = var36.getTickLabelPaint();
    java.lang.Object var39 = null;
    boolean var40 = var36.equals(var39);
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var43 = var42.getLabelToolTip();
    java.awt.Font var44 = var42.getTickLabelFont();
    var36.setLabelFont(var44);
    var10.setItemFont(var44);
    org.jfree.chart.util.VerticalAlignment var47 = var10.getVerticalAlignment();
    org.jfree.chart.util.RectangleInsets var52 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var54 = var52.trimHeight(10.0d);
    double var56 = var52.calculateTopInset(10.0d);
    double var58 = var52.calculateLeftInset(12.0d);
    double var59 = var52.getBottom();
    org.jfree.chart.util.UnitType var60 = var52.getUnitType();
    var10.setLegendItemGraphicPadding(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test383"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    java.awt.Font var9 = var6.getNoDataMessageFont();
    java.awt.Color var12 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
    int var13 = var12.getTransparency();
    var6.setNoDataMessagePaint((java.awt.Paint)var12);
    var6.setDomainGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test384"); }
// 
// 
//     java.awt.Font var3 = null;
//     java.awt.Color var6 = java.awt.Color.getColor("", 0);
//     int var7 = var6.getGreen();
//     float[] var8 = null;
//     float[] var9 = var6.getColorComponents(var8);
//     boolean var11 = var6.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var14 = null;
//     org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, (java.awt.Paint)var6, 0.0f, 10, var14);
//     java.awt.Color var18 = java.awt.Color.getColor("", 0);
//     int var19 = var18.getGreen();
//     float[] var20 = null;
//     float[] var21 = var18.getColorComponents(var20);
//     float[] var22 = var6.getRGBColorComponents(var20);
//     java.awt.Color var23 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", var6);
//     java.awt.Color var26 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var27 = null;
//     org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var27);
//     int var29 = var26.getRed();
//     java.awt.Color var30 = var26.brighter();
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var34 = var33.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var31, var33, var35, var36);
//     boolean var38 = var37.isSubplot();
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var42 = var41.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var41, var43, var44);
//     boolean var46 = var45.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var47 = var45.getDrawingSupplier();
//     var45.clearRangeMarkers();
//     boolean var49 = var45.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var52 = var51.getLabelToolTip();
//     java.awt.Stroke var53 = var51.getAxisLineStroke();
//     var45.setDomainGridlineStroke(var53);
//     var37.setOutlineStroke(var53);
//     org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var64 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var65 = null;
//     org.jfree.chart.event.ChartChangeEvent var66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var64, var65);
//     org.jfree.chart.block.BlockBorder var67 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var64);
//     var57.setFrame((org.jfree.chart.block.BlockFrame)var67);
//     org.jfree.chart.block.BlockFrame var69 = var57.getFrame();
//     var57.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.lang.String var72 = var57.getToolTipText();
//     double var73 = var57.getWidth();
//     org.jfree.chart.util.RectangleInsets var74 = var57.getMargin();
//     org.jfree.chart.block.LineBorder var75 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var30, var53, var74);
//     org.jfree.chart.plot.ValueMarker var76 = new org.jfree.chart.plot.ValueMarker(100.0d, (java.awt.Paint)var23, var53);
//     java.lang.Object var77 = var76.clone();
//     org.jfree.data.category.CategoryDataset var78 = null;
//     org.jfree.chart.axis.CategoryAxis var80 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var81 = var80.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var82 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var83 = null;
//     org.jfree.chart.plot.CategoryPlot var84 = new org.jfree.chart.plot.CategoryPlot(var78, var80, var82, var83);
//     boolean var85 = var84.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var86 = var84.getDrawingSupplier();
//     var84.clearRangeMarkers();
//     boolean var88 = var84.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var90 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var91 = var90.getLabelToolTip();
//     java.awt.Stroke var92 = var90.getAxisLineStroke();
//     var84.setDomainGridlineStroke(var92);
//     var76.setOutlineStroke(var92);
//     
//     // Checks the contract:  equals-hashcode on var45 and var84
//     assertTrue("Contract failed: equals-hashcode on var45 and var84", var45.equals(var84) ? var45.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var45
//     assertTrue("Contract failed: equals-hashcode on var84 and var45", var84.equals(var45) ? var84.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var86
//     assertTrue("Contract failed: equals-hashcode on var47 and var86", var47.equals(var86) ? var47.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var47
//     assertTrue("Contract failed: equals-hashcode on var86 and var47", var86.equals(var47) ? var86.hashCode() == var47.hashCode() : true);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test385"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateTopInset(10.0d);
    double var10 = var4.calculateLeftInset(12.0d);
    double var11 = var4.getBottom();
    double var13 = var4.trimWidth((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test386"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getHeightConstraintType();
    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    int var9 = var8.getGreen();
    float[] var10 = null;
    float[] var11 = var8.getColorComponents(var10);
    boolean var13 = var8.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var8, 0.0f, 10, var16);
    java.util.List var18 = var17.getLines();
    org.jfree.chart.util.HorizontalAlignment var19 = var17.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var20 = null;
    org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var24 = null;
    org.jfree.chart.title.LegendItemBlockContainer var26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var23, var24, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var27 = var26.getBounds();
    boolean var28 = var3.equals((java.lang.Object)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test387"); }


    int var3 = java.awt.Color.HSBtoRGB(10.0f, 1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test388"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    java.awt.Font var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var15 = null;
    java.awt.Rectangle var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    java.awt.geom.AffineTransform var18 = null;
    java.awt.RenderingHints var19 = null;
    java.awt.PaintContext var20 = var14.createContext(var15, var16, var17, var18, var19);
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var14);
    var6.setNoDataMessagePaint((java.awt.Paint)var14);
    java.awt.Paint var23 = null;
    var6.setBackgroundPaint(var23);
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var28 = var27.getLabelToolTip();
    java.awt.Paint var30 = var27.getTickLabelPaint((java.lang.Comparable)(short)100);
    var27.removeCategoryLabelToolTip((java.lang.Comparable)100.0f);
    var6.setDomainAxis(10, var27);
    java.lang.String var34 = var27.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "poly"+ "'", var34.equals("poly"));

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test389"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    org.jfree.chart.util.GradientPaintTransformer var26 = var17.getFillPaintTransformer();
    java.lang.Object var27 = var17.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test390"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     var6.clearRangeMarkers();
//     org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
//     org.jfree.chart.util.RectangleInsets var12 = var6.getInsets();
//     boolean var13 = var6.isRangeZoomable();
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var6.drawBackground(var14, var15);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test391"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Stroke var3 = var1.getAxisLineStroke();
    double var4 = var1.getLowerMargin();
    float var5 = var1.getTickMarkInsideLength();
    org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var16 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var17 = null;
    org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var16, var17);
    org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var16);
    var9.setFrame((org.jfree.chart.block.BlockFrame)var19);
    org.jfree.chart.block.BlockFrame var21 = var9.getFrame();
    var9.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.awt.geom.Rectangle2D var24 = var9.getBounds();
    org.jfree.chart.util.RectangleAnchor var25 = null;
    java.awt.geom.Point2D var26 = org.jfree.chart.util.RectangleAnchor.coordinates(var24, var25);
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var1.getCategoryStart((-1), (-1), var24, var27);
    var1.setTickMarksVisible(false);
    java.util.EventListener var31 = null;
    boolean var32 = var1.hasListener(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test392"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var11 = var10.getLabelToolTip();
    java.awt.Paint var12 = var10.getTickLabelPaint();
    java.lang.Object var13 = null;
    boolean var14 = var10.equals(var13);
    boolean var15 = var10.isAxisLineVisible();
    var6.setDomainAxis(10, var10);
    var6.clearDomainMarkers();
    int var18 = var6.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test393"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var6.getRangeAxisIndex(var7);
    org.jfree.chart.axis.ValueAxis var9 = var6.getRangeAxis();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var14, var15);
    boolean var17 = var16.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
    var16.clearRangeMarkers();
    boolean var20 = var16.isSubplot();
    boolean var21 = var16.isSubplot();
    org.jfree.data.Range var24 = new org.jfree.data.Range(0.0d, 0.0d);
    double var25 = var24.getUpperBound();
    double var26 = var24.getCentralValue();
    org.jfree.data.general.Dataset var27 = null;
    org.jfree.data.general.DatasetChangeEvent var28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var24, var27);
    var16.datasetChanged(var28);
    var6.setParent((org.jfree.chart.plot.Plot)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test394"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    double var6 = var5.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(1.0d, var5);
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    double var11 = var10.getLength();
    org.jfree.chart.JFreeChart var13 = null;
    org.jfree.chart.event.ChartProgressEvent var16 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var13, 100, 10);
    org.jfree.chart.JFreeChart var17 = null;
    var16.setChart(var17);
    var16.setPercent((-1));
    boolean var21 = var10.equals((java.lang.Object)var16);
    org.jfree.chart.block.RectangleConstraint var22 = var7.toRangeHeight(var10);
    org.jfree.data.Range var23 = org.jfree.data.Range.combine(var1, var10);
    org.jfree.data.Range var27 = new org.jfree.data.Range(0.0d, 0.0d);
    double var28 = var27.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var29 = new org.jfree.chart.block.RectangleConstraint(1.0d, var27);
    org.jfree.data.Range var30 = org.jfree.data.Range.combine(var23, var27);
    java.lang.String var31 = var23.toString();
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(1.0d, var23);
    java.lang.String var33 = var32.toString();
    java.lang.String var34 = var32.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "Range[0.0,0.0]"+ "'", var31.equals("Range[0.0,0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"+ "'", var33.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"+ "'", var34.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"));

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test395"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    java.awt.Font var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var15 = null;
    java.awt.Rectangle var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    java.awt.geom.AffineTransform var18 = null;
    java.awt.RenderingHints var19 = null;
    java.awt.PaintContext var20 = var14.createContext(var15, var16, var17, var18, var19);
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var14);
    var6.setNoDataMessagePaint((java.awt.Paint)var14);
    var6.clearRangeMarkers(3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    int var26 = var6.getIndexOf(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test396"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    java.awt.Font var13 = null;
    java.awt.Color var16 = java.awt.Color.getColor("", 0);
    int var17 = var16.getGreen();
    float[] var18 = null;
    float[] var19 = var16.getColorComponents(var18);
    boolean var21 = var16.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var24 = null;
    org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var16, 0.0f, 10, var24);
    java.awt.Color var28 = java.awt.Color.getColor("", 0);
    int var29 = var28.getGreen();
    float[] var30 = null;
    float[] var31 = var28.getColorComponents(var30);
    float[] var32 = var16.getRGBColorComponents(var30);
    java.awt.Color var33 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", var16);
    java.awt.Color var36 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var37 = null;
    org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var36, var37);
    int var39 = var36.getRed();
    java.awt.Color var40 = var36.brighter();
    org.jfree.data.category.CategoryDataset var41 = null;
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var44 = var43.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var41, var43, var45, var46);
    boolean var48 = var47.isSubplot();
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var52 = var51.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var49, var51, var53, var54);
    boolean var56 = var55.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var57 = var55.getDrawingSupplier();
    var55.clearRangeMarkers();
    boolean var59 = var55.isSubplot();
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var62 = var61.getLabelToolTip();
    java.awt.Stroke var63 = var61.getAxisLineStroke();
    var55.setDomainGridlineStroke(var63);
    var47.setOutlineStroke(var63);
    org.jfree.chart.block.LabelBlock var67 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var74 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var75 = null;
    org.jfree.chart.event.ChartChangeEvent var76 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var74, var75);
    org.jfree.chart.block.BlockBorder var77 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var74);
    var67.setFrame((org.jfree.chart.block.BlockFrame)var77);
    org.jfree.chart.block.BlockFrame var79 = var67.getFrame();
    var67.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var82 = var67.getToolTipText();
    double var83 = var67.getWidth();
    org.jfree.chart.util.RectangleInsets var84 = var67.getMargin();
    org.jfree.chart.block.LineBorder var85 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var40, var63, var84);
    org.jfree.chart.plot.ValueMarker var86 = new org.jfree.chart.plot.ValueMarker(100.0d, (java.awt.Paint)var33, var63);
    var6.addRangeMarker((org.jfree.chart.plot.Marker)var86);
    var86.setLabel("LegendItemEntity: seriesKey=null, dataset=null");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test397"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(14.0d, 1.0d);
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    double var6 = var5.getLength();
    boolean var7 = var2.equals((java.lang.Object)var6);
    java.lang.Number var8 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 14.0d+ "'", var8.equals(14.0d));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test398"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 0.0d, 1.0f, 100.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 0.0d, 1.0f, 100.0f);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var8, var18);
    org.jfree.chart.entity.AxisLabelEntity var26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var8, "org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]", "hi!");
    java.lang.String var27 = var26.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AxisLabelEntity: label = poly"+ "'", var27.equals("AxisLabelEntity: label = poly"));

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test399"); }
// 
// 
//     org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(14.0d, 1.0d);
//     java.awt.Font var4 = null;
//     java.awt.Color var7 = java.awt.Color.getColor("", 0);
//     java.awt.image.ColorModel var8 = null;
//     java.awt.Rectangle var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     java.awt.geom.AffineTransform var11 = null;
//     java.awt.RenderingHints var12 = null;
//     java.awt.PaintContext var13 = var7.createContext(var8, var9, var10, var11, var12);
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7);
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var19 = var18.getLabelToolTip();
//     java.awt.Font var20 = var18.getTickLabelFont();
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Font var25 = null;
//     java.awt.Color var28 = java.awt.Color.getColor("", 0);
//     int var29 = var28.getGreen();
//     float[] var30 = null;
//     float[] var31 = var28.getColorComponents(var30);
//     boolean var33 = var28.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var36 = null;
//     org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, (java.awt.Paint)var28, 0.0f, 10, var36);
//     org.jfree.chart.title.LegendGraphic var38 = new org.jfree.chart.title.LegendGraphic(var23, (java.awt.Paint)var28);
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var20, (java.awt.Paint)var28);
//     java.awt.Font var41 = null;
//     java.awt.Color var44 = java.awt.Color.getColor("", 0);
//     int var45 = var44.getGreen();
//     float[] var46 = null;
//     float[] var47 = var44.getColorComponents(var46);
//     boolean var49 = var44.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var52 = null;
//     org.jfree.chart.text.TextBlock var53 = org.jfree.chart.text.TextUtilities.createTextBlock("", var41, (java.awt.Paint)var44, 0.0f, 10, var52);
//     int var54 = var44.getTransparency();
//     java.awt.Color var55 = var44.darker();
//     java.awt.Color var56 = var55.darker();
//     var14.addLine("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var20, (java.awt.Paint)var56);
//     boolean var58 = var2.equals((java.lang.Object)var14);
//     java.awt.Graphics2D var59 = null;
//     org.jfree.chart.text.TextBlockAnchor var62 = null;
//     java.awt.Shape var66 = var14.calculateBounds(var59, 1.0f, 0.0f, var62, (-1.0f), (-1.0f), 0.0d);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test400"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Font var12 = null;
    java.awt.Color var15 = java.awt.Color.getColor("", 0);
    int var16 = var15.getGreen();
    float[] var17 = null;
    float[] var18 = var15.getColorComponents(var17);
    boolean var20 = var15.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var23 = null;
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var15, 0.0f, 10, var23);
    java.util.List var25 = var24.getLines();
    org.jfree.chart.util.HorizontalAlignment var26 = var24.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var27 = null;
    org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var31 = null;
    org.jfree.chart.title.LegendItemBlockContainer var33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, var31, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var34 = var33.getBounds();
    var10.setWrapper((org.jfree.chart.block.BlockContainer)var33);
    java.awt.Font var36 = var10.getItemFont();
    java.awt.Graphics2D var37 = null;
    org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var41 = var40.getWidthConstraintType();
    org.jfree.chart.util.Size2D var42 = var10.arrange(var37, var40);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var47 = null;
    java.awt.Color var50 = java.awt.Color.getColor("", 0);
    int var51 = var50.getGreen();
    float[] var52 = null;
    float[] var53 = var50.getColorComponents(var52);
    boolean var55 = var50.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var58 = null;
    org.jfree.chart.text.TextBlock var59 = org.jfree.chart.text.TextUtilities.createTextBlock("", var47, (java.awt.Paint)var50, 0.0f, 10, var58);
    org.jfree.chart.title.LegendGraphic var60 = new org.jfree.chart.title.LegendGraphic(var45, (java.awt.Paint)var50);
    var60.setID("Size2D[width=10.0, height=14.0]");
    double var63 = var60.getContentXOffset();
    org.jfree.chart.util.RectangleAnchor var64 = var60.getShapeLocation();
    var10.setLegendItemGraphicLocation(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test401"); }


    java.awt.Color var1 = java.awt.Color.getColor("AxisLabelEntity: label = poly");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test402"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)0L, "0,-1,-1,1,1,1,1,1", var2, var3, 12.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test403"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     var6.clearRangeMarkers(0);
//     java.awt.Font var11 = null;
//     java.awt.Color var14 = java.awt.Color.getColor("", 0);
//     java.awt.image.ColorModel var15 = null;
//     java.awt.Rectangle var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     java.awt.geom.AffineTransform var18 = null;
//     java.awt.RenderingHints var19 = null;
//     java.awt.PaintContext var20 = var14.createContext(var15, var16, var17, var18, var19);
//     org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var14);
//     var6.setNoDataMessagePaint((java.awt.Paint)var14);
//     java.awt.Paint var23 = null;
//     var6.setBackgroundPaint(var23);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var28 = var27.getLabelToolTip();
//     java.awt.Paint var30 = var27.getTickLabelPaint((java.lang.Comparable)(short)100);
//     var27.removeCategoryLabelToolTip((java.lang.Comparable)100.0f);
//     var6.setDomainAxis(10, var27);
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var37 = var36.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var34, var36, var38, var39);
//     boolean var41 = var40.isSubplot();
//     var40.clearRangeMarkers(0);
//     java.awt.Font var45 = null;
//     java.awt.Color var48 = java.awt.Color.getColor("", 0);
//     java.awt.image.ColorModel var49 = null;
//     java.awt.Rectangle var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     java.awt.geom.AffineTransform var52 = null;
//     java.awt.RenderingHints var53 = null;
//     java.awt.PaintContext var54 = var48.createContext(var49, var50, var51, var52, var53);
//     org.jfree.chart.text.TextBlock var55 = org.jfree.chart.text.TextUtilities.createTextBlock("", var45, (java.awt.Paint)var48);
//     var40.setNoDataMessagePaint((java.awt.Paint)var48);
//     java.awt.Paint var57 = null;
//     var40.setBackgroundPaint(var57);
//     org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var62 = var61.getLabelToolTip();
//     java.awt.Paint var64 = var61.getTickLabelPaint((java.lang.Comparable)(short)100);
//     var61.removeCategoryLabelToolTip((java.lang.Comparable)100.0f);
//     var40.setDomainAxis(10, var61);
//     java.lang.String var68 = var61.getLabel();
//     org.jfree.chart.axis.CategoryAxis[] var69 = new org.jfree.chart.axis.CategoryAxis[] { var61};
//     var6.setDomainAxes(var69);
//     
//     // Checks the contract:  equals-hashcode on var6 and var40
//     assertTrue("Contract failed: equals-hashcode on var6 and var40", var6.equals(var40) ? var6.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var6
//     assertTrue("Contract failed: equals-hashcode on var40 and var6", var40.equals(var6) ? var40.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test404"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    float var3 = var1.getMaximumCategoryLabelWidthRatio();
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var6 = var1.getTickLabelPaint((java.lang.Comparable)(short)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test405"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toUnconstrainedHeight();
    org.jfree.data.Range var8 = new org.jfree.data.Range(0.0d, 0.0d);
    double var9 = var8.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var10 = var5.toRangeHeight(var8);
    org.jfree.chart.block.RectangleConstraint var12 = var10.toFixedWidth(100.0d);
    org.jfree.chart.block.RectangleConstraint var13 = var12.toUnconstrainedHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test406"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    boolean var11 = var6.isSubplot();
    org.jfree.data.Range var14 = new org.jfree.data.Range(0.0d, 0.0d);
    double var15 = var14.getUpperBound();
    double var16 = var14.getCentralValue();
    org.jfree.data.general.Dataset var17 = null;
    org.jfree.data.general.DatasetChangeEvent var18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var14, var17);
    var6.datasetChanged(var18);
    var6.setOutlineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test407"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateBottomInset(102.0d);
    org.jfree.chart.util.UnitType var9 = var4.getUnitType();
    java.lang.String var10 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "RectangleInsets[t=-1.0,l=-1.0,b=-1.0,r=-1.0]"+ "'", var10.equals("RectangleInsets[t=-1.0,l=-1.0,b=-1.0,r=-1.0]"));

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test408"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(14.0d, 1.0d);
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    double var6 = var5.getLength();
    boolean var7 = var2.equals((java.lang.Object)var6);
    java.awt.Font var10 = null;
    java.awt.Color var13 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var14 = null;
    java.awt.Rectangle var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    java.awt.geom.AffineTransform var17 = null;
    java.awt.RenderingHints var18 = null;
    java.awt.PaintContext var19 = var13.createContext(var14, var15, var16, var17, var18);
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, (java.awt.Paint)var13);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var25 = var24.getLabelToolTip();
    java.awt.Font var26 = var24.getTickLabelFont();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var31 = null;
    java.awt.Color var34 = java.awt.Color.getColor("", 0);
    int var35 = var34.getGreen();
    float[] var36 = null;
    float[] var37 = var34.getColorComponents(var36);
    boolean var39 = var34.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var42 = null;
    org.jfree.chart.text.TextBlock var43 = org.jfree.chart.text.TextUtilities.createTextBlock("", var31, (java.awt.Paint)var34, 0.0f, 10, var42);
    org.jfree.chart.title.LegendGraphic var44 = new org.jfree.chart.title.LegendGraphic(var29, (java.awt.Paint)var34);
    org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var26, (java.awt.Paint)var34);
    java.awt.Font var47 = null;
    java.awt.Color var50 = java.awt.Color.getColor("", 0);
    int var51 = var50.getGreen();
    float[] var52 = null;
    float[] var53 = var50.getColorComponents(var52);
    boolean var55 = var50.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var58 = null;
    org.jfree.chart.text.TextBlock var59 = org.jfree.chart.text.TextUtilities.createTextBlock("", var47, (java.awt.Paint)var50, 0.0f, 10, var58);
    int var60 = var50.getTransparency();
    java.awt.Color var61 = var50.darker();
    java.awt.Color var62 = var61.darker();
    var20.addLine("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var26, (java.awt.Paint)var62);
    java.awt.Font var65 = null;
    java.awt.Color var68 = java.awt.Color.getColor("", 0);
    int var69 = var68.getGreen();
    float[] var70 = null;
    float[] var71 = var68.getColorComponents(var70);
    boolean var73 = var68.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var76 = null;
    org.jfree.chart.text.TextBlock var77 = org.jfree.chart.text.TextUtilities.createTextBlock("", var65, (java.awt.Paint)var68, 0.0f, 10, var76);
    int var78 = var68.getTransparency();
    java.awt.Color var79 = var68.darker();
    java.awt.Color var80 = var79.darker();
    org.jfree.chart.text.TextLine var81 = new org.jfree.chart.text.TextLine("Size2D[width=10.0, height=14.0]", var26, (java.awt.Paint)var79);
    boolean var82 = var2.equals((java.lang.Object)var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test409"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(102.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test410"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var6.getDomainMarkers((-1), var8);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleAnchor var13 = null;
    java.awt.geom.Point2D var14 = org.jfree.chart.util.RectangleAnchor.coordinates(var12, var13);
    var6.zoomRangeAxes(100.0d, var11, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var6.setFixedLegendItems(var16);
    java.awt.Paint var18 = var6.getDomainGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test411"); }


    java.awt.Font var3 = null;
    java.awt.Color var6 = java.awt.Color.getColor("", 0);
    int var7 = var6.getGreen();
    float[] var8 = null;
    float[] var9 = var6.getColorComponents(var8);
    boolean var11 = var6.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var14 = null;
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, (java.awt.Paint)var6, 0.0f, 10, var14);
    java.awt.Color var18 = java.awt.Color.getColor("", 0);
    int var19 = var18.getGreen();
    float[] var20 = null;
    float[] var21 = var18.getColorComponents(var20);
    float[] var22 = var6.getRGBColorComponents(var20);
    java.awt.Color var23 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", var6);
    java.awt.Color var26 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var27 = null;
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var27);
    int var29 = var26.getRed();
    java.awt.Color var30 = var26.brighter();
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var34 = var33.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var31, var33, var35, var36);
    boolean var38 = var37.isSubplot();
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var42 = var41.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var41, var43, var44);
    boolean var46 = var45.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var47 = var45.getDrawingSupplier();
    var45.clearRangeMarkers();
    boolean var49 = var45.isSubplot();
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var52 = var51.getLabelToolTip();
    java.awt.Stroke var53 = var51.getAxisLineStroke();
    var45.setDomainGridlineStroke(var53);
    var37.setOutlineStroke(var53);
    org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var64 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var65 = null;
    org.jfree.chart.event.ChartChangeEvent var66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var64, var65);
    org.jfree.chart.block.BlockBorder var67 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var64);
    var57.setFrame((org.jfree.chart.block.BlockFrame)var67);
    org.jfree.chart.block.BlockFrame var69 = var57.getFrame();
    var57.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var72 = var57.getToolTipText();
    double var73 = var57.getWidth();
    org.jfree.chart.util.RectangleInsets var74 = var57.getMargin();
    org.jfree.chart.block.LineBorder var75 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var30, var53, var74);
    org.jfree.chart.plot.ValueMarker var76 = new org.jfree.chart.plot.ValueMarker(100.0d, (java.awt.Paint)var23, var53);
    java.lang.String var77 = var76.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test412"); }


    java.awt.Shape var5 = null;
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var10 = var9.getLabelToolTip();
    java.awt.Font var11 = var9.getTickLabelFont();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var16 = null;
    java.awt.Color var19 = java.awt.Color.getColor("", 0);
    int var20 = var19.getGreen();
    float[] var21 = null;
    float[] var22 = var19.getColorComponents(var21);
    boolean var24 = var19.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var27 = null;
    org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var19, 0.0f, 10, var27);
    org.jfree.chart.title.LegendGraphic var29 = new org.jfree.chart.title.LegendGraphic(var14, (java.awt.Paint)var19);
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var11, (java.awt.Paint)var19);
    java.awt.Paint var32 = null;
    org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var35 = var34.getLabelToolTip();
    java.awt.Stroke var36 = var34.getAxisLineStroke();
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var40 = new org.jfree.chart.entity.ChartEntity(var39);
    org.jfree.chart.entity.LegendItemEntity var41 = new org.jfree.chart.entity.LegendItemEntity(var39);
    org.jfree.chart.entity.ChartEntity var44 = new org.jfree.chart.entity.ChartEntity(var39, "poly", "0,-1,-1,1,1,1,1,1");
    java.awt.Stroke var45 = null;
    org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var48 = var47.getLabelToolTip();
    java.awt.Paint var49 = var47.getTickLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("CategoryLabelEntity: category=false, tooltip=, url=org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", "AxisLabelEntity: label = poly", "0,-1,-1,1,1,1,1,1", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", true, var5, true, (java.awt.Paint)var19, false, var32, var36, false, var39, var45, var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test413"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var4 = var3.getLabelToolTip();
    java.awt.Font var5 = var3.getTickLabelFont();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var10 = null;
    java.awt.Color var13 = java.awt.Color.getColor("", 0);
    int var14 = var13.getGreen();
    float[] var15 = null;
    float[] var16 = var13.getColorComponents(var15);
    boolean var18 = var13.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var21 = null;
    org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, (java.awt.Paint)var13, 0.0f, 10, var21);
    org.jfree.chart.title.LegendGraphic var23 = new org.jfree.chart.title.LegendGraphic(var8, (java.awt.Paint)var13);
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var5, (java.awt.Paint)var13);
    org.jfree.chart.text.TextLine var25 = new org.jfree.chart.text.TextLine("0,-1,-1,1,1,1,1,1", var5);
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var29 = var28.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var26, var28, var30, var31);
    boolean var33 = var32.isSubplot();
    var32.clearRangeMarkers(0);
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var38 = var37.getLabelToolTip();
    java.awt.Paint var39 = var37.getTickLabelPaint();
    java.lang.Object var40 = null;
    boolean var41 = var37.equals(var40);
    boolean var42 = var37.isAxisLineVisible();
    boolean var43 = var37.isVisible();
    org.jfree.chart.axis.CategoryAxis[] var44 = new org.jfree.chart.axis.CategoryAxis[] { var37};
    var32.setDomainAxes(var44);
    org.jfree.data.category.CategoryDataset var46 = null;
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var49 = var48.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var51 = null;
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot(var46, var48, var50, var51);
    boolean var53 = var52.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var54 = var52.getDrawingSupplier();
    java.awt.Font var55 = var52.getNoDataMessageFont();
    java.awt.Color var58 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
    int var59 = var58.getTransparency();
    var52.setNoDataMessagePaint((java.awt.Paint)var58);
    var52.setRangeGridlinesVisible(true);
    var32.setParent((org.jfree.chart.plot.Plot)var52);
    boolean var64 = var25.equals((java.lang.Object)var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test414"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test415"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.setRangeCrosshairVisible(false);
    java.awt.Stroke var11 = var6.getOutlineStroke();
    org.jfree.data.general.DatasetGroup var12 = var6.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test416"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var6 = var5.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var3, var5, var7, var8);
    boolean var10 = var9.isSubplot();
    var9.clearRangeMarkers(0);
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var17 = new org.jfree.data.Range(0.0d, 0.0d);
    double var18 = var17.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(1.0d, var17);
    org.jfree.data.Range var22 = new org.jfree.data.Range(0.0d, 0.0d);
    double var23 = var22.getLength();
    org.jfree.chart.JFreeChart var25 = null;
    org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var25, 100, 10);
    org.jfree.chart.JFreeChart var29 = null;
    var28.setChart(var29);
    var28.setPercent((-1));
    boolean var33 = var22.equals((java.lang.Object)var28);
    org.jfree.chart.block.RectangleConstraint var34 = var19.toRangeHeight(var22);
    org.jfree.data.Range var35 = org.jfree.data.Range.combine(var13, var22);
    org.jfree.data.Range var39 = new org.jfree.data.Range(0.0d, 0.0d);
    double var40 = var39.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(1.0d, var39);
    org.jfree.data.Range var42 = org.jfree.data.Range.combine(var35, var39);
    org.jfree.data.general.Dataset var43 = null;
    org.jfree.data.general.DatasetChangeEvent var44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var35, var43);
    var9.datasetChanged(var44);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var9);
    org.jfree.data.category.CategoryDataset var47 = null;
    org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var50 = var49.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var47, var49, var51, var52);
    org.jfree.chart.event.AxisChangeEvent var54 = null;
    var53.axisChanged(var54);
    org.jfree.chart.util.RectangleInsets var56 = var53.getInsets();
    org.jfree.chart.util.SortOrder var57 = var53.getColumnRenderingOrder();
    var9.setColumnRenderingOrder(var57);
    org.jfree.chart.axis.AxisLocation var60 = var9.getDomainAxisLocation(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test417"); }


    org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var2 = var1.getType();
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var3.equals("ChartChangeEventType.GENERAL"));

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test418"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var6.getRangeAxisIndex(var7);
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var10 = var9.getOpposite();
    org.jfree.chart.plot.PlotOrientation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var12 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var9, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test419"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Font var4 = null;
//     java.awt.Color var7 = java.awt.Color.getColor("", 0);
//     int var8 = var7.getGreen();
//     float[] var9 = null;
//     float[] var10 = var7.getColorComponents(var9);
//     boolean var12 = var7.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var15 = null;
//     org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
//     org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, (-1.0f), 100.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var19);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var26);
//     var17.setShape(var19);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var33 = var32.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var30, var32, var34, var35);
//     boolean var37 = var36.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var38 = var36.getDrawingSupplier();
//     java.awt.Font var39 = var36.getNoDataMessageFont();
//     java.awt.Color var42 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
//     int var43 = var42.getTransparency();
//     var36.setNoDataMessagePaint((java.awt.Paint)var42);
//     java.awt.image.ColorModel var45 = null;
//     java.awt.Rectangle var46 = null;
//     org.jfree.chart.util.RectangleInsets var51 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
//     double var53 = var51.trimHeight(10.0d);
//     double var55 = var51.calculateLeftInset(0.0d);
//     double var56 = var51.getRight();
//     double var58 = var51.extendHeight(1.0d);
//     org.jfree.chart.block.LabelBlock var60 = new org.jfree.chart.block.LabelBlock("hi!");
//     org.jfree.chart.block.LabelBlock var62 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var69 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var70 = null;
//     org.jfree.chart.event.ChartChangeEvent var71 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var69, var70);
//     org.jfree.chart.block.BlockBorder var72 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var69);
//     var62.setFrame((org.jfree.chart.block.BlockFrame)var72);
//     org.jfree.chart.block.BlockFrame var74 = var62.getFrame();
//     var62.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var77 = var62.getBounds();
//     var60.setBounds(var77);
//     java.awt.geom.Rectangle2D var81 = var51.createOutsetRectangle(var77, true, false);
//     java.awt.geom.AffineTransform var82 = null;
//     java.awt.RenderingHints var83 = null;
//     java.awt.PaintContext var84 = var42.createContext(var45, var46, var77, var82, var83);
//     org.jfree.data.category.CategoryDataset var85 = null;
//     org.jfree.chart.axis.CategoryAxis var87 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var88 = var87.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var89 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var90 = null;
//     org.jfree.chart.plot.CategoryPlot var91 = new org.jfree.chart.plot.CategoryPlot(var85, var87, var89, var90);
//     org.jfree.chart.axis.AxisLocation var93 = var91.getDomainAxisLocation((-1));
//     java.lang.Object var94 = var17.draw(var29, (java.awt.geom.Rectangle2D)var46, (java.lang.Object)var91);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test420"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 10.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test421"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var28 = null;
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    int var32 = var31.getGreen();
    float[] var33 = null;
    float[] var34 = var31.getColorComponents(var33);
    boolean var36 = var31.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var39 = null;
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var31, 0.0f, 10, var39);
    org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var31);
    boolean var42 = var41.isShapeOutlineVisible();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var47 = var46.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var48 = var46.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var49 = var41.arrange(var43, var46);
    java.awt.Paint var50 = var41.getLinePaint();
    var22.add((org.jfree.chart.block.Block)var41);
    boolean var52 = var22.isEmpty();
    java.lang.String var53 = var22.getURLText();
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var56 = new org.jfree.chart.entity.ChartEntity(var55);
    boolean var57 = var22.equals((java.lang.Object)var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test422"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    java.awt.Font var13 = null;
    java.awt.Color var16 = java.awt.Color.getColor("", 0);
    int var17 = var16.getGreen();
    float[] var18 = null;
    float[] var19 = var16.getColorComponents(var18);
    boolean var21 = var16.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var24 = null;
    org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var16, 0.0f, 10, var24);
    java.awt.Color var28 = java.awt.Color.getColor("", 0);
    int var29 = var28.getGreen();
    float[] var30 = null;
    float[] var31 = var28.getColorComponents(var30);
    float[] var32 = var16.getRGBColorComponents(var30);
    java.awt.Color var33 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", var16);
    java.awt.Color var36 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var37 = null;
    org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var36, var37);
    int var39 = var36.getRed();
    java.awt.Color var40 = var36.brighter();
    org.jfree.data.category.CategoryDataset var41 = null;
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var44 = var43.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var41, var43, var45, var46);
    boolean var48 = var47.isSubplot();
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var52 = var51.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var49, var51, var53, var54);
    boolean var56 = var55.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var57 = var55.getDrawingSupplier();
    var55.clearRangeMarkers();
    boolean var59 = var55.isSubplot();
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var62 = var61.getLabelToolTip();
    java.awt.Stroke var63 = var61.getAxisLineStroke();
    var55.setDomainGridlineStroke(var63);
    var47.setOutlineStroke(var63);
    org.jfree.chart.block.LabelBlock var67 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var74 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var75 = null;
    org.jfree.chart.event.ChartChangeEvent var76 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var74, var75);
    org.jfree.chart.block.BlockBorder var77 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var74);
    var67.setFrame((org.jfree.chart.block.BlockFrame)var77);
    org.jfree.chart.block.BlockFrame var79 = var67.getFrame();
    var67.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var82 = var67.getToolTipText();
    double var83 = var67.getWidth();
    org.jfree.chart.util.RectangleInsets var84 = var67.getMargin();
    org.jfree.chart.block.LineBorder var85 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var40, var63, var84);
    org.jfree.chart.plot.ValueMarker var86 = new org.jfree.chart.plot.ValueMarker(100.0d, (java.awt.Paint)var33, var63);
    var6.addRangeMarker((org.jfree.chart.plot.Marker)var86);
    boolean var88 = var6.isDomainGridlinesVisible();
    org.jfree.chart.annotations.CategoryAnnotation var89 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var90 = var6.removeAnnotation(var89);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test423"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateLeftInset(0.0d);
    double var10 = var4.calculateTopOutset(14.0d);
    java.awt.Color var13 = java.awt.Color.getColor("", 0);
    int var14 = var13.getGreen();
    float[] var15 = null;
    float[] var16 = var13.getColorComponents(var15);
    java.awt.Paint[] var17 = new java.awt.Paint[] { var13};
    java.awt.Color var20 = java.awt.Color.getColor("", 0);
    int var21 = var20.getGreen();
    java.awt.Paint[] var22 = new java.awt.Paint[] { var20};
    java.awt.Stroke var23 = null;
    java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var37 = new java.awt.Shape[] { var36};
    org.jfree.chart.plot.DefaultDrawingSupplier var38 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var22, var24, var26, var37);
    java.awt.Paint[] var39 = null;
    java.awt.Stroke var40 = null;
    java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
    java.awt.Stroke var42 = null;
    java.awt.Stroke[] var43 = new java.awt.Stroke[] { var42};
    java.awt.Color var46 = java.awt.Color.getColor("", 0);
    int var47 = var46.getGreen();
    float[] var48 = null;
    float[] var49 = var46.getColorComponents(var48);
    java.awt.Paint[] var50 = new java.awt.Paint[] { var46};
    java.awt.Color var53 = java.awt.Color.getColor("", 0);
    int var54 = var53.getGreen();
    java.awt.Paint[] var55 = new java.awt.Paint[] { var53};
    java.awt.Stroke var56 = null;
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    java.awt.Stroke var58 = null;
    java.awt.Stroke[] var59 = new java.awt.Stroke[] { var58};
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.rotateShape(var61, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.rotateShape(var65, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var70 = new java.awt.Shape[] { var69};
    org.jfree.chart.plot.DefaultDrawingSupplier var71 = new org.jfree.chart.plot.DefaultDrawingSupplier(var50, var55, var57, var59, var70);
    org.jfree.chart.plot.DefaultDrawingSupplier var72 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var39, var41, var43, var70);
    java.awt.Paint var73 = var72.getNextPaint();
    org.jfree.chart.block.BlockBorder var74 = new org.jfree.chart.block.BlockBorder(var4, var73);
    java.awt.Paint var75 = var74.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test424"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    org.jfree.chart.util.RectangleInsets var35 = var10.getPadding();
    java.awt.Font var36 = var10.getItemFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test425"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "poly", "Size2D[width=10.0, height=14.0]");

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test426"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    org.jfree.chart.entity.CategoryLabelEntity var10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)(short)0, var2, "", "0,-1,-1,1,1,1,1,1");
    java.lang.Object var11 = var10.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test427"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    java.awt.Font var9 = var6.getNoDataMessageFont();
    java.awt.Color var12 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
    int var13 = var12.getTransparency();
    var6.setNoDataMessagePaint((java.awt.Paint)var12);
    boolean var15 = var6.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test428"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    java.awt.Font var9 = var6.getNoDataMessageFont();
    org.jfree.data.category.CategoryDataset var10 = var6.getDataset();
    boolean var11 = var6.isSubplot();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var15 = var14.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var14, var16, var17);
    boolean var19 = var18.isSubplot();
    var18.clearRangeMarkers(0);
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var24 = var23.getLabelToolTip();
    java.awt.Paint var25 = var23.getTickLabelPaint();
    java.lang.Object var26 = null;
    boolean var27 = var23.equals(var26);
    boolean var28 = var23.isAxisLineVisible();
    boolean var29 = var23.isVisible();
    org.jfree.chart.axis.CategoryAxis[] var30 = new org.jfree.chart.axis.CategoryAxis[] { var23};
    var18.setDomainAxes(var30);
    var6.setDomainAxes(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test429"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.0d, 12.0d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test430"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
    var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var16 = var1.getToolTipText();
    double var17 = var1.getWidth();
    org.jfree.chart.block.BlockFrame var18 = var1.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test431"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(113.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test432"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    var1.setAxisLineVisible(true);
    float var4 = var1.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0f);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test433"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var3 = null;
    java.awt.Rectangle var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    java.awt.geom.AffineTransform var6 = null;
    java.awt.RenderingHints var7 = null;
    java.awt.PaintContext var8 = var2.createContext(var3, var4, var5, var6, var7);
    java.awt.Color var9 = var2.brighter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test434"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 0);
    int var3 = var2.getGreen();
    float[] var4 = null;
    float[] var5 = var2.getColorComponents(var4);
    java.awt.Paint[] var6 = new java.awt.Paint[] { var2};
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    java.awt.Paint[] var11 = new java.awt.Paint[] { var9};
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var25};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var11, var13, var15, var26);
    java.awt.Paint var28 = var27.getNextFillPaint();
    java.awt.Paint var29 = var27.getNextFillPaint();
    java.awt.Stroke var30 = var27.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test435"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    java.util.List var14 = var13.getLines();
    org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var20 = null;
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    java.awt.Color var26 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var27 = null;
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var27);
    org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var31 = var30.getType();
    var28.setType(var31);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var36 = new org.jfree.chart.entity.LegendItemEntity(var35);
    boolean var37 = var31.equals((java.lang.Object)var36);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var42 = var41.getLabelToolTip();
    java.awt.Font var43 = var41.getTickLabelFont();
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var48 = null;
    java.awt.Color var51 = java.awt.Color.getColor("", 0);
    int var52 = var51.getGreen();
    float[] var53 = null;
    float[] var54 = var51.getColorComponents(var53);
    boolean var56 = var51.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var59 = null;
    org.jfree.chart.text.TextBlock var60 = org.jfree.chart.text.TextUtilities.createTextBlock("", var48, (java.awt.Paint)var51, 0.0f, 10, var59);
    org.jfree.chart.title.LegendGraphic var61 = new org.jfree.chart.title.LegendGraphic(var46, (java.awt.Paint)var51);
    org.jfree.chart.text.TextBlock var62 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var43, (java.awt.Paint)var51);
    org.jfree.chart.text.TextLine var63 = new org.jfree.chart.text.TextLine("0,-1,-1,1,1,1,1,1", var43);
    boolean var64 = var36.equals((java.lang.Object)var63);
    boolean var65 = var22.equals((java.lang.Object)var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test436"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var5 = var4.getVersion();
    org.jfree.chart.ui.Library[] var6 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var7 = var4.getLibraries();
    var4.setLicenceName("0,-1,-1,1,1,1,1,1");
    java.lang.String var10 = var4.getInfo();
    var4.setCopyright("poly");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var10.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test437"); }


    java.awt.Color var1 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test438"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var6.getDomainMarkers((-1), var8);
    java.awt.Color var12 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
    var6.setNoDataMessagePaint((java.awt.Paint)var12);
    int var14 = var12.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 255);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test439"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var6.setFixedDomainAxisSpace(var12);
    java.awt.Stroke var14 = var6.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test440"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "AxisLabelEntity: label = poly", "org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]", var3, "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", "CategoryLabelEntity: category=false, tooltip=, url=org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", "org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]");

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test441"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test442"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("poly");
    org.jfree.chart.text.TextFragment var2 = null;
    var1.addFragment(var2);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test443"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var10 = var9.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var7, var9, var11, var12);
    boolean var14 = var13.isSubplot();
    var13.clearRangeMarkers(0);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var19 = var18.getLabelToolTip();
    java.awt.Stroke var20 = var18.getAxisLineStroke();
    var13.setDomainGridlineStroke(var20);
    var6.setOutlineStroke(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test444"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.plot.DrawingSupplier var10 = var6.getDrawingSupplier();
    org.jfree.chart.axis.ValueAxis var11 = var6.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test445"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var12 = var11.getLabelToolTip();
    java.awt.Paint var13 = var11.getTickLabelPaint();
    java.lang.Object var14 = null;
    boolean var15 = var11.equals(var14);
    var6.setDomainAxis(var11);
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.data.Range var18 = var6.getDataRange(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test446"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1", "poly", var3, "0,-1,-1,1,1,1,1,1", "", "");
    org.jfree.chart.ui.Library[] var8 = var7.getLibraries();
    java.awt.Image var9 = null;
    var7.setLogo(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test447"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var14, var15);
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var16.axisChanged(var17);
    org.jfree.chart.util.RectangleInsets var19 = var16.getInsets();
    org.jfree.chart.util.SortOrder var20 = var16.getColumnRenderingOrder();
    var6.setRowRenderingOrder(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test448"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var6.axisChanged(var7);
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var12 = var11.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var11, var13, var14);
//     boolean var16 = var15.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
//     var6.setDrawingSupplier(var17);
//     
//     // Checks the contract:  equals-hashcode on var6 and var15
//     assertTrue("Contract failed: equals-hashcode on var6 and var15", var6.equals(var15) ? var6.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test449"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);
    double var3 = var2.getHeight();
    double var4 = var2.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test450"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]", var1, 10.0f, (-1.0f), var4, 102.0d, var6);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test451"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var37 = var36.getLabelToolTip();
    java.awt.Paint var38 = var36.getTickLabelPaint();
    java.lang.Object var39 = null;
    boolean var40 = var36.equals(var39);
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var43 = var42.getLabelToolTip();
    java.awt.Font var44 = var42.getTickLabelFont();
    var36.setLabelFont(var44);
    var10.setItemFont(var44);
    org.jfree.chart.util.VerticalAlignment var47 = var10.getVerticalAlignment();
    java.awt.Font var49 = null;
    java.awt.Color var52 = java.awt.Color.getColor("", 0);
    int var53 = var52.getGreen();
    float[] var54 = null;
    float[] var55 = var52.getColorComponents(var54);
    boolean var57 = var52.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var60 = null;
    org.jfree.chart.text.TextBlock var61 = org.jfree.chart.text.TextUtilities.createTextBlock("", var49, (java.awt.Paint)var52, 0.0f, 10, var60);
    java.util.List var62 = var61.getLines();
    org.jfree.chart.util.HorizontalAlignment var63 = var61.getLineAlignment();
    org.jfree.chart.axis.CategoryLabelPositions var65 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
    boolean var66 = var63.equals((java.lang.Object)var65);
    java.lang.String var67 = var63.toString();
    var10.setHorizontalAlignment(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var67.equals("HorizontalAlignment.CENTER"));

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test452"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Stroke var3 = var1.getAxisLineStroke();
    int var4 = var1.getMaximumCategoryLabelLines();
    java.awt.Paint var5 = var1.getAxisLinePaint();
    var1.setLabel("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test453"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var6.axisChanged(var7);
    org.jfree.chart.util.RectangleInsets var9 = var6.getInsets();
    var6.mapDatasetToRangeAxis(0, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test454"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    float var3 = var1.getMaximumCategoryLabelWidthRatio();
    boolean var4 = var1.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test455"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 0.0d, 1.0f, 100.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 0.0d, 1.0f, 100.0f);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var8, var18);
    org.jfree.chart.entity.AxisLabelEntity var26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var8, "org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]", "hi!");
    var1.setMaximumCategoryLabelWidthRatio(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test456"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    java.awt.Font var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var15 = null;
    java.awt.Rectangle var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    java.awt.geom.AffineTransform var18 = null;
    java.awt.RenderingHints var19 = null;
    java.awt.PaintContext var20 = var14.createContext(var15, var16, var17, var18, var19);
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var14);
    var6.setNoDataMessagePaint((java.awt.Paint)var14);
    java.awt.Paint var23 = null;
    var6.setBackgroundPaint(var23);
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var28 = var27.getLabelToolTip();
    java.awt.Paint var30 = var27.getTickLabelPaint((java.lang.Comparable)(short)100);
    var27.removeCategoryLabelToolTip((java.lang.Comparable)100.0f);
    var6.setDomainAxis(10, var27);
    var27.setTickMarkOutsideLength(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test457"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var6.axisChanged(var7);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var14, var15);
    boolean var17 = var16.isSubplot();
    org.jfree.chart.axis.AxisLocation var19 = var16.getDomainAxisLocation((-33));
    org.jfree.chart.axis.AxisLocation var20 = var19.getOpposite();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setRangeAxisLocation((-1), var19, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test458"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    org.jfree.chart.block.BlockFrame var13 = var1.getFrame();
    var1.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.awt.geom.Rectangle2D var16 = var1.getBounds();
    var1.setHeight(100.0d);
    org.jfree.chart.block.BlockFrame var19 = var1.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test459"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    java.awt.Font var9 = var6.getNoDataMessageFont();
    java.awt.Stroke var10 = var6.getRangeCrosshairStroke();
    var6.setRangeCrosshairValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test460"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    float var3 = var1.getMaximumCategoryLabelWidthRatio();
    var1.configure();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var8 = var7.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var7, var9, var10);
    org.jfree.chart.event.AxisChangeEvent var12 = null;
    var11.axisChanged(var12);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var18 = var17.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var17, var19, var20);
    boolean var22 = var21.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
    var21.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var26 = var21.getDomainAxisLocation(0);
    var11.setDomainAxisLocation(100, var26);
    var11.configureDomainAxes();
    var11.clearDomainMarkers();
    boolean var30 = var1.hasListener((java.util.EventListener)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test461"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 0.0d, 1.0f, 100.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 0.0d, 1.0f, 100.0f);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var8, var18);
    org.jfree.chart.entity.AxisLabelEntity var26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var8, "org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]", "hi!");
    var1.setTickMarkInsideLength((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test462"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var5 = null;
    java.awt.Rectangle var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    java.awt.geom.AffineTransform var8 = null;
    java.awt.RenderingHints var9 = null;
    java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    java.awt.Shape var19 = var11.calculateBounds(var12, 10.0f, 1.0f, var15, 0.0f, (-1.0f), 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test463"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    double var6 = var5.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(1.0d, var5);
    org.jfree.chart.block.LengthConstraintType var8 = var7.getHeightConstraintType();
    boolean var9 = var1.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test464"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1);
//     org.jfree.chart.util.Size2D var3 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test465"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    java.awt.Font var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var15 = null;
    java.awt.Rectangle var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    java.awt.geom.AffineTransform var18 = null;
    java.awt.RenderingHints var19 = null;
    java.awt.PaintContext var20 = var14.createContext(var15, var16, var17, var18, var19);
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var14);
    var6.setNoDataMessagePaint((java.awt.Paint)var14);
    java.awt.Paint var23 = null;
    var6.setBackgroundPaint(var23);
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var28 = var27.getLabelToolTip();
    java.awt.Paint var30 = var27.getTickLabelPaint((java.lang.Comparable)(short)100);
    var27.removeCategoryLabelToolTip((java.lang.Comparable)100.0f);
    var6.setDomainAxis(10, var27);
    boolean var34 = var6.isRangeGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test466"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var7 = var6.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var6, var8, var9);
    boolean var11 = var10.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var12 = var10.getDrawingSupplier();
    var10.clearRangeMarkers();
    boolean var14 = var10.isSubplot();
    org.jfree.chart.event.PlotChangeEvent var15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var10);
    boolean var16 = var10.isRangeGridlinesVisible();
    java.awt.Paint var17 = var10.getOutlinePaint();
    var1.setAxisLinePaint(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test467"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
    org.jfree.chart.util.RectangleInsets var12 = var6.getInsets();
    boolean var13 = var6.isRangeZoomable();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var6.getDomainMarkers(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test468"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.clearRangeMarkers();
    boolean var10 = var6.isSubplot();
    boolean var11 = var6.isSubplot();
    org.jfree.data.Range var14 = new org.jfree.data.Range(0.0d, 0.0d);
    double var15 = var14.getUpperBound();
    double var16 = var14.getCentralValue();
    org.jfree.data.general.Dataset var17 = null;
    org.jfree.data.general.DatasetChangeEvent var18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var14, var17);
    var6.datasetChanged(var18);
    org.jfree.chart.axis.CategoryAxis var21 = var6.getDomainAxisForDataset(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test469"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateLeftInset(0.0d);
    double var10 = var4.calculateTopOutset(14.0d);
    java.awt.Color var13 = java.awt.Color.getColor("", 0);
    int var14 = var13.getGreen();
    float[] var15 = null;
    float[] var16 = var13.getColorComponents(var15);
    java.awt.Paint[] var17 = new java.awt.Paint[] { var13};
    java.awt.Color var20 = java.awt.Color.getColor("", 0);
    int var21 = var20.getGreen();
    java.awt.Paint[] var22 = new java.awt.Paint[] { var20};
    java.awt.Stroke var23 = null;
    java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var37 = new java.awt.Shape[] { var36};
    org.jfree.chart.plot.DefaultDrawingSupplier var38 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var22, var24, var26, var37);
    java.awt.Paint[] var39 = null;
    java.awt.Stroke var40 = null;
    java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
    java.awt.Stroke var42 = null;
    java.awt.Stroke[] var43 = new java.awt.Stroke[] { var42};
    java.awt.Color var46 = java.awt.Color.getColor("", 0);
    int var47 = var46.getGreen();
    float[] var48 = null;
    float[] var49 = var46.getColorComponents(var48);
    java.awt.Paint[] var50 = new java.awt.Paint[] { var46};
    java.awt.Color var53 = java.awt.Color.getColor("", 0);
    int var54 = var53.getGreen();
    java.awt.Paint[] var55 = new java.awt.Paint[] { var53};
    java.awt.Stroke var56 = null;
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    java.awt.Stroke var58 = null;
    java.awt.Stroke[] var59 = new java.awt.Stroke[] { var58};
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.rotateShape(var61, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.rotateShape(var65, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var70 = new java.awt.Shape[] { var69};
    org.jfree.chart.plot.DefaultDrawingSupplier var71 = new org.jfree.chart.plot.DefaultDrawingSupplier(var50, var55, var57, var59, var70);
    org.jfree.chart.plot.DefaultDrawingSupplier var72 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var39, var41, var43, var70);
    java.awt.Paint var73 = var72.getNextPaint();
    org.jfree.chart.block.BlockBorder var74 = new org.jfree.chart.block.BlockBorder(var4, var73);
    org.jfree.chart.util.RectangleInsets var75 = var74.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test470"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1", "poly", var3, "0,-1,-1,1,1,1,1,1", "", "");
    java.lang.String var8 = var7.getLicenceText();
    var7.setLicenceText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test471"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var2);
//     java.lang.Object var4 = var3.clone();
//     org.jfree.chart.JFreeChart var6 = null;
//     org.jfree.chart.event.ChartChangeEventType var7 = null;
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var6, var7);
//     org.jfree.chart.event.ChartChangeEventType var9 = null;
//     var8.setType(var9);
//     boolean var11 = var3.equals((java.lang.Object)var9);
//     java.lang.Comparable var12 = null;
//     var3.setSeriesKey(var12);
//     org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var22 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var23 = null;
//     org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22, var23);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var22);
//     var15.setFrame((org.jfree.chart.block.BlockFrame)var25);
//     org.jfree.chart.block.BlockFrame var27 = var15.getFrame();
//     boolean var28 = var3.equals((java.lang.Object)var15);
//     java.lang.Object var29 = var3.clone();
//     
//     // Checks the contract:  equals-hashcode on var4 and var29
//     assertTrue("Contract failed: equals-hashcode on var4 and var29", var4.equals(var29) ? var4.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var4
//     assertTrue("Contract failed: equals-hashcode on var29 and var4", var29.equals(var4) ? var29.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test472"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    java.awt.Shape var26 = var17.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test473"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(short)100, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test474"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var4 = var1.getTickLabelPaint((java.lang.Comparable)(short)100);
    var1.removeCategoryLabelToolTip((java.lang.Comparable)100.0f);
    int var7 = var1.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test475"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var26);
    var17.setShape(var19);
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var32 = null;
    org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var31, var32);
    var17.setLinePaint((java.awt.Paint)var31);
    var17.setHeight(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test476"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var26);
    var17.setShape(var19);
    org.jfree.chart.util.RectangleInsets var33 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    var17.setPadding(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test477"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1", "poly", var3, "0,-1,-1,1,1,1,1,1", "", "");
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("", 0);
    int var13 = var12.getGreen();
    float[] var14 = null;
    float[] var15 = var12.getColorComponents(var14);
    boolean var17 = var12.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var20 = null;
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var12, 0.0f, 10, var20);
    java.util.List var22 = var21.getLines();
    var7.setContributors(var22);
    java.lang.String var24 = var7.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "0,-1,-1,1,1,1,1,1"+ "'", var24.equals("0,-1,-1,1,1,1,1,1"));

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test478"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var12 = var11.getLabelToolTip();
    java.awt.Paint var13 = var11.getTickLabelPaint();
    java.lang.Object var14 = null;
    boolean var15 = var11.equals(var14);
    var6.setDomainAxis(var11);
    org.jfree.chart.LegendItemCollection var17 = var6.getLegendItems();
    java.util.Iterator var18 = var17.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test479"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var4 = var3.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var3, var5, var6);
    boolean var8 = var7.isSubplot();
    org.jfree.chart.axis.AxisLocation var10 = var7.getDomainAxisLocation((-33));
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var14 = var13.getLabelToolTip();
    java.awt.Font var15 = var13.getTickLabelFont();
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var20 = null;
    java.awt.Color var23 = java.awt.Color.getColor("", 0);
    int var24 = var23.getGreen();
    float[] var25 = null;
    float[] var26 = var23.getColorComponents(var25);
    boolean var28 = var23.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var31 = null;
    org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var20, (java.awt.Paint)var23, 0.0f, 10, var31);
    org.jfree.chart.title.LegendGraphic var33 = new org.jfree.chart.title.LegendGraphic(var18, (java.awt.Paint)var23);
    org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var15, (java.awt.Paint)var23);
    var7.setNoDataMessageFont(var15);
    java.awt.Color var38 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
    int var39 = var38.getTransparency();
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var44 = null;
    java.awt.Color var47 = java.awt.Color.getColor("", 0);
    int var48 = var47.getGreen();
    float[] var49 = null;
    float[] var50 = var47.getColorComponents(var49);
    boolean var52 = var47.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var55 = null;
    org.jfree.chart.text.TextBlock var56 = org.jfree.chart.text.TextUtilities.createTextBlock("", var44, (java.awt.Paint)var47, 0.0f, 10, var55);
    org.jfree.chart.title.LegendGraphic var57 = new org.jfree.chart.title.LegendGraphic(var42, (java.awt.Paint)var47);
    boolean var58 = var57.isShapeOutlineVisible();
    java.awt.Graphics2D var59 = null;
    org.jfree.chart.block.RectangleConstraint var62 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var63 = var62.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var64 = var62.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var65 = var57.arrange(var59, var62);
    org.jfree.chart.util.GradientPaintTransformer var66 = var57.getFillPaintTransformer();
    boolean var67 = var38.equals((java.lang.Object)var57);
    org.jfree.chart.block.LabelBlock var68 = new org.jfree.chart.block.LabelBlock("", var15, (java.awt.Paint)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test480"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var4 = var3.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var3, var5, var6);
    boolean var8 = var7.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    var7.setRangeCrosshairVisible(false);
    var7.setBackgroundImageAlignment(1);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var14.setTextAntiAlias(false);
    org.jfree.chart.ui.BasicProjectInfo var21 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]", "hi!", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var22 = var21.getVersion();
    org.jfree.chart.ui.Library[] var23 = var21.getOptionalLibraries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setTextAntiAlias((java.lang.Object)var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=10.0]"+ "'", var22.equals("org.jfree.chart.event.ChartProgressEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test481"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    int var14 = var4.getTransparency();
    java.awt.Color var15 = var4.brighter();
    java.awt.color.ColorSpace var16 = var15.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test482"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 100.0d, 10.0d, 1, (java.lang.Comparable)"hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test483"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    java.lang.Object var4 = null;
    boolean var5 = var1.equals(var4);
    org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var12 = var10.trimHeight(10.0d);
    double var14 = var10.calculateLeftInset(0.0d);
    double var16 = var10.trimHeight(12.0d);
    double var17 = var10.getLeft();
    double var19 = var10.calculateLeftInset(25.0d);
    var1.setTickLabelInsets(var10);
    var1.setLabelToolTip("Size2D[width=10.0, height=14.0]");
    var1.setFixedDimension(0.0d);
    var1.setUpperMargin(0.0d);
    var1.setTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1.0d));

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test484"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    boolean var8 = var6.isRangeCrosshairVisible();
    org.jfree.data.category.CategoryDataset var10 = var6.getDataset(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test485"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var4 = new org.jfree.data.Range(0.0d, 0.0d);
    double var5 = var4.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0d, var4);
    org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
    double var10 = var9.getLength();
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var12, 100, 10);
    org.jfree.chart.JFreeChart var16 = null;
    var15.setChart(var16);
    var15.setPercent((-1));
    boolean var20 = var9.equals((java.lang.Object)var15);
    org.jfree.chart.block.RectangleConstraint var21 = var6.toRangeHeight(var9);
    org.jfree.data.Range var22 = org.jfree.data.Range.combine(var0, var9);
    org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 0.0d);
    double var27 = var26.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(1.0d, var26);
    org.jfree.data.Range var29 = org.jfree.data.Range.combine(var22, var26);
    java.lang.String var30 = var22.toString();
    org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var22, 1.0d);
    org.jfree.chart.util.Size2D var35 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);
    double var36 = var35.getHeight();
    var35.setHeight(14.0d);
    boolean var39 = var22.equals((java.lang.Object)var35);
    java.awt.Font var41 = null;
    java.awt.Color var44 = java.awt.Color.getColor("", 0);
    int var45 = var44.getGreen();
    float[] var46 = null;
    float[] var47 = var44.getColorComponents(var46);
    boolean var49 = var44.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var52 = null;
    org.jfree.chart.text.TextBlock var53 = org.jfree.chart.text.TextUtilities.createTextBlock("", var41, (java.awt.Paint)var44, 0.0f, 10, var52);
    java.util.List var54 = var53.getLines();
    boolean var55 = var35.equals((java.lang.Object)var53);
    org.jfree.data.Range var56 = null;
    org.jfree.data.Range var60 = new org.jfree.data.Range(0.0d, 0.0d);
    double var61 = var60.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var62 = new org.jfree.chart.block.RectangleConstraint(1.0d, var60);
    org.jfree.data.Range var65 = new org.jfree.data.Range(0.0d, 0.0d);
    double var66 = var65.getLength();
    org.jfree.chart.JFreeChart var68 = null;
    org.jfree.chart.event.ChartProgressEvent var71 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var68, 100, 10);
    org.jfree.chart.JFreeChart var72 = null;
    var71.setChart(var72);
    var71.setPercent((-1));
    boolean var76 = var65.equals((java.lang.Object)var71);
    org.jfree.chart.block.RectangleConstraint var77 = var62.toRangeHeight(var65);
    org.jfree.data.Range var78 = org.jfree.data.Range.combine(var56, var65);
    org.jfree.data.Range var82 = new org.jfree.data.Range(0.0d, 0.0d);
    double var83 = var82.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var84 = new org.jfree.chart.block.RectangleConstraint(1.0d, var82);
    org.jfree.data.Range var85 = org.jfree.data.Range.combine(var78, var82);
    boolean var86 = var35.equals((java.lang.Object)var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "Range[0.0,0.0]"+ "'", var30.equals("Range[0.0,0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test486"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var2);
    org.jfree.chart.entity.LegendItemEntity var4 = new org.jfree.chart.entity.LegendItemEntity(var2);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var2, "poly", "0,-1,-1,1,1,1,1,1");
    org.jfree.chart.entity.CategoryLabelEntity var10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var2, "", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]");
    var10.setToolTipText("0,-1,-1,1,1,1,1,1");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test487"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("0,-1,-1,1,1,1,1,1", "0,-1,-1,1,1,1,1,1", "poly", var3, "0,-1,-1,1,1,1,1,1", "", "");
    java.lang.String var8 = var7.getLicenceText();
    var7.setVersion("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test488"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var26);
    var17.setShape(var19);
    java.awt.Color var31 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var32 = null;
    org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var31, var32);
    var17.setLinePaint((java.awt.Paint)var31);
    java.awt.geom.Rectangle2D var35 = var17.getBounds();
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var40 = null;
    java.awt.Color var43 = java.awt.Color.getColor("", 0);
    int var44 = var43.getGreen();
    float[] var45 = null;
    float[] var46 = var43.getColorComponents(var45);
    boolean var48 = var43.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var51 = null;
    org.jfree.chart.text.TextBlock var52 = org.jfree.chart.text.TextUtilities.createTextBlock("", var40, (java.awt.Paint)var43, 0.0f, 10, var51);
    org.jfree.chart.title.LegendGraphic var53 = new org.jfree.chart.title.LegendGraphic(var38, (java.awt.Paint)var43);
    var53.setID("Size2D[width=10.0, height=14.0]");
    double var56 = var53.getContentXOffset();
    org.jfree.chart.util.RectangleAnchor var57 = var53.getShapeLocation();
    var17.setShapeAnchor(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test489"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var6.getDomainMarkers((-1), var8);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleAnchor var13 = null;
    java.awt.geom.Point2D var14 = org.jfree.chart.util.RectangleAnchor.coordinates(var12, var13);
    var6.zoomRangeAxes(100.0d, var11, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var6.setFixedLegendItems(var16);
    org.jfree.chart.axis.AxisSpace var18 = null;
    var6.setFixedRangeAxisSpace(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test490"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var6 = var5.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var3, var5, var7, var8);
    boolean var10 = var9.isSubplot();
    var9.clearRangeMarkers(0);
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var17 = new org.jfree.data.Range(0.0d, 0.0d);
    double var18 = var17.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(1.0d, var17);
    org.jfree.data.Range var22 = new org.jfree.data.Range(0.0d, 0.0d);
    double var23 = var22.getLength();
    org.jfree.chart.JFreeChart var25 = null;
    org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var25, 100, 10);
    org.jfree.chart.JFreeChart var29 = null;
    var28.setChart(var29);
    var28.setPercent((-1));
    boolean var33 = var22.equals((java.lang.Object)var28);
    org.jfree.chart.block.RectangleConstraint var34 = var19.toRangeHeight(var22);
    org.jfree.data.Range var35 = org.jfree.data.Range.combine(var13, var22);
    org.jfree.data.Range var39 = new org.jfree.data.Range(0.0d, 0.0d);
    double var40 = var39.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(1.0d, var39);
    org.jfree.data.Range var42 = org.jfree.data.Range.combine(var35, var39);
    org.jfree.data.general.Dataset var43 = null;
    org.jfree.data.general.DatasetChangeEvent var44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var35, var43);
    var9.datasetChanged(var44);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var9);
    org.jfree.data.category.CategoryDataset var47 = null;
    org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var50 = var49.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var47, var49, var51, var52);
    org.jfree.chart.event.AxisChangeEvent var54 = null;
    var53.axisChanged(var54);
    org.jfree.chart.util.RectangleInsets var56 = var53.getInsets();
    org.jfree.chart.util.SortOrder var57 = var53.getColumnRenderingOrder();
    var9.setColumnRenderingOrder(var57);
    org.jfree.chart.LegendItemCollection var59 = var9.getFixedLegendItems();
    boolean var61 = var9.equals((java.lang.Object)3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test491"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var8 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var8);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var11);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 0.0d, 1.0f, 100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var24, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, 0.0d, 1.0f, 100.0f);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var18, var28);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    boolean var35 = var11.equals((java.lang.Object)var34);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test492"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Stroke var3 = var1.getAxisLineStroke();
    java.lang.String var4 = var1.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test493"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Color var20 = java.awt.Color.getColor("", 0);
    var17.setFillPaint((java.awt.Paint)var20);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    var17.setShape(var23);
    boolean var25 = var17.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test494"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var4 = var3.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var3, var5, var6);
    boolean var8 = var7.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    var7.setRangeCrosshairVisible(false);
    var7.setBackgroundImageAlignment(1);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var14.setTextAntiAlias(false);
    int var17 = var14.getSubtitleCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test495"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    float var4 = var1.getTickMarkOutsideLength();
    var1.clearCategoryLabelToolTips();
    org.jfree.chart.util.RectangleInsets var6 = var1.getTickLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test496"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var4 = new org.jfree.data.Range(0.0d, 0.0d);
    double var5 = var4.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0d, var4);
    org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
    double var10 = var9.getLength();
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var12, 100, 10);
    org.jfree.chart.JFreeChart var16 = null;
    var15.setChart(var16);
    var15.setPercent((-1));
    boolean var20 = var9.equals((java.lang.Object)var15);
    org.jfree.chart.block.RectangleConstraint var21 = var6.toRangeHeight(var9);
    org.jfree.data.Range var22 = org.jfree.data.Range.combine(var0, var9);
    org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 0.0d);
    double var27 = var26.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(1.0d, var26);
    org.jfree.data.Range var29 = org.jfree.data.Range.combine(var22, var26);
    org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(var26, 1.0d);
    java.lang.String var32 = var26.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "Range[0.0,0.0]"+ "'", var32.equals("Range[0.0,0.0]"));

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test497"); }


    java.awt.Shape var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("LegendItemEntity: seriesKey=null, dataset=null", (-1));
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartProgressEvent[source=10.0]", "RectangleInsets[t=-1.0,l=-1.0,b=-1.0,r=-1.0]", "CategoryLabelEntity: category=false, tooltip=, url=org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", "", var4, (java.awt.Paint)var7);
    java.awt.Stroke var9 = var8.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test498"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var6.getDomainMarkers((-1), var8);
    java.awt.Paint var10 = var6.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test499"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     var6.clearRangeMarkers();
//     org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
//     org.jfree.chart.util.RectangleInsets var12 = var6.getInsets();
//     boolean var13 = var6.isRangeZoomable();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var18 = var17.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var17, var19, var20);
//     boolean var22 = var21.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     var21.setRangeCrosshairVisible(false);
//     var21.setBackgroundImageAlignment(1);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var21);
//     var6.addChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test500"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("", 0);
//     int var5 = var4.getGreen();
//     float[] var6 = null;
//     float[] var7 = var4.getColorComponents(var6);
//     boolean var9 = var4.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
//     java.util.List var14 = var13.getLines();
//     org.jfree.chart.util.HorizontalAlignment var15 = var13.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 12.0d, 25.0d);
//     org.jfree.data.general.Dataset var20 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)"poly");
//     java.awt.geom.Rectangle2D var23 = var22.getBounds();
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Font var28 = null;
//     java.awt.Color var31 = java.awt.Color.getColor("", 0);
//     int var32 = var31.getGreen();
//     float[] var33 = null;
//     float[] var34 = var31.getColorComponents(var33);
//     boolean var36 = var31.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var39 = null;
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var31, 0.0f, 10, var39);
//     org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var31);
//     boolean var42 = var41.isShapeOutlineVisible();
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
//     org.jfree.chart.block.LengthConstraintType var47 = var46.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var48 = var46.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var49 = var41.arrange(var43, var46);
//     java.awt.Paint var50 = var41.getLinePaint();
//     var22.add((org.jfree.chart.block.Block)var41);
//     java.lang.String var52 = var22.getURLText();
//     java.awt.Font var54 = null;
//     java.awt.Color var57 = java.awt.Color.getColor("", 0);
//     int var58 = var57.getGreen();
//     float[] var59 = null;
//     float[] var60 = var57.getColorComponents(var59);
//     boolean var62 = var57.equals((java.lang.Object)1.0d);
//     org.jfree.chart.text.TextMeasurer var65 = null;
//     org.jfree.chart.text.TextBlock var66 = org.jfree.chart.text.TextUtilities.createTextBlock("", var54, (java.awt.Paint)var57, 0.0f, 10, var65);
//     java.util.List var67 = var66.getLines();
//     org.jfree.chart.util.HorizontalAlignment var68 = var66.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var69 = null;
//     org.jfree.chart.block.ColumnArrangement var72 = new org.jfree.chart.block.ColumnArrangement(var68, var69, 12.0d, 25.0d);
//     var72.clear();
//     var22.setArrangement((org.jfree.chart.block.Arrangement)var72);
//     
//     // Checks the contract:  equals-hashcode on var19 and var72
//     assertTrue("Contract failed: equals-hashcode on var19 and var72", var19.equals(var72) ? var19.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var19
//     assertTrue("Contract failed: equals-hashcode on var72 and var19", var72.equals(var19) ? var72.hashCode() == var19.hashCode() : true);
// 
//   }

}
