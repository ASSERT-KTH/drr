
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    var6.clearRangeMarkers(0);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var12 = var11.getLabelToolTip();
    java.awt.Paint var13 = var11.getTickLabelPaint();
    java.lang.Object var14 = null;
    boolean var15 = var11.equals(var14);
    var6.setDomainAxis(var11);
    org.jfree.chart.LegendItemCollection var17 = var6.getLegendItems();
    org.jfree.chart.axis.AxisLocation var18 = var6.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var19 = org.jfree.chart.axis.AxisLocation.getOpposite(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(12.0d);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("", 0);
    int var10 = var9.getGreen();
    float[] var11 = null;
    float[] var12 = var9.getColorComponents(var11);
    boolean var14 = var9.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var17 = null;
    org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var9, 0.0f, 10, var17);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var4, (java.awt.Paint)var9);
    boolean var20 = var19.isShapeOutlineVisible();
    java.awt.Paint var21 = var19.getLinePaint();
    java.lang.Object var22 = var19.clone();
    boolean var23 = var1.equals(var22);
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, 100.0d, 12.0d);
    boolean var29 = var1.equals((java.lang.Object)12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    org.jfree.chart.entity.CategoryLabelEntity var10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)(short)0, var2, "", "0,-1,-1,1,1,1,1,1");
    java.lang.Comparable var11 = var10.getKey();
    java.lang.String var12 = var10.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (short)0+ "'", var11.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "0,-1,-1,1,1,1,1,1"+ "'", var12.equals("0,-1,-1,1,1,1,1,1"));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    org.jfree.chart.event.TitleChangeEvent var11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }


    java.awt.Font var3 = null;
    java.awt.Color var6 = java.awt.Color.getColor("", 0);
    int var7 = var6.getGreen();
    float[] var8 = null;
    float[] var9 = var6.getColorComponents(var8);
    boolean var11 = var6.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var14 = null;
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, (java.awt.Paint)var6, 0.0f, 10, var14);
    java.awt.Color var18 = java.awt.Color.getColor("", 0);
    int var19 = var18.getGreen();
    float[] var20 = null;
    float[] var21 = var18.getColorComponents(var20);
    float[] var22 = var6.getRGBColorComponents(var20);
    java.awt.Color var23 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", var6);
    java.awt.Color var26 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var27 = null;
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var27);
    int var29 = var26.getRed();
    java.awt.Color var30 = var26.brighter();
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var34 = var33.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var31, var33, var35, var36);
    boolean var38 = var37.isSubplot();
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var42 = var41.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var41, var43, var44);
    boolean var46 = var45.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var47 = var45.getDrawingSupplier();
    var45.clearRangeMarkers();
    boolean var49 = var45.isSubplot();
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var52 = var51.getLabelToolTip();
    java.awt.Stroke var53 = var51.getAxisLineStroke();
    var45.setDomainGridlineStroke(var53);
    var37.setOutlineStroke(var53);
    org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var64 = java.awt.Color.getColor("", 0);
    org.jfree.chart.JFreeChart var65 = null;
    org.jfree.chart.event.ChartChangeEvent var66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var64, var65);
    org.jfree.chart.block.BlockBorder var67 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var64);
    var57.setFrame((org.jfree.chart.block.BlockFrame)var67);
    org.jfree.chart.block.BlockFrame var69 = var57.getFrame();
    var57.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var72 = var57.getToolTipText();
    double var73 = var57.getWidth();
    org.jfree.chart.util.RectangleInsets var74 = var57.getMargin();
    org.jfree.chart.block.LineBorder var75 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var30, var53, var74);
    org.jfree.chart.plot.ValueMarker var76 = new org.jfree.chart.plot.ValueMarker(100.0d, (java.awt.Paint)var23, var53);
    java.lang.Object var77 = var76.clone();
    org.jfree.chart.util.LengthAdjustmentType var78 = var76.getLabelOffsetType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    double var2 = var1.getFixedDimension();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 0.0d, 1.0f, 100.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 0.0d, 1.0f, 100.0f);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var8, var18);
    org.jfree.chart.entity.AxisLabelEntity var26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var8, "org.jfree.data.general.DatasetChangeEvent[source=Range[0.0,0.0]]", "hi!");
    org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var8, "LegendItemEntity: seriesKey=null, dataset=null");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var4 = var3.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var3, var5, var6);
    boolean var8 = var7.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    var7.setRangeCrosshairVisible(false);
    var7.setBackgroundImageAlignment(1);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.title.TextTitle var15 = var14.getTitle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    boolean var18 = var17.isShapeOutlineVisible();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var25 = var17.arrange(var19, var22);
    java.awt.Color var28 = java.awt.Color.getColor("", 0);
    int var29 = var28.getGreen();
    float[] var30 = null;
    float[] var31 = var28.getColorComponents(var30);
    java.awt.Paint[] var32 = new java.awt.Paint[] { var28};
    java.awt.Color var35 = java.awt.Color.getColor("", 0);
    int var36 = var35.getGreen();
    java.awt.Paint[] var37 = new java.awt.Paint[] { var35};
    java.awt.Stroke var38 = null;
    java.awt.Stroke[] var39 = new java.awt.Stroke[] { var38};
    java.awt.Stroke var40 = null;
    java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.rotateShape(var43, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.rotateShape(var47, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var52 = new java.awt.Shape[] { var51};
    org.jfree.chart.plot.DefaultDrawingSupplier var53 = new org.jfree.chart.plot.DefaultDrawingSupplier(var32, var37, var39, var41, var52);
    java.awt.Paint[] var54 = null;
    java.awt.Stroke var55 = null;
    java.awt.Stroke[] var56 = new java.awt.Stroke[] { var55};
    java.awt.Stroke var57 = null;
    java.awt.Stroke[] var58 = new java.awt.Stroke[] { var57};
    java.awt.Color var61 = java.awt.Color.getColor("", 0);
    int var62 = var61.getGreen();
    float[] var63 = null;
    float[] var64 = var61.getColorComponents(var63);
    java.awt.Paint[] var65 = new java.awt.Paint[] { var61};
    java.awt.Color var68 = java.awt.Color.getColor("", 0);
    int var69 = var68.getGreen();
    java.awt.Paint[] var70 = new java.awt.Paint[] { var68};
    java.awt.Stroke var71 = null;
    java.awt.Stroke[] var72 = new java.awt.Stroke[] { var71};
    java.awt.Stroke var73 = null;
    java.awt.Stroke[] var74 = new java.awt.Stroke[] { var73};
    java.awt.Shape var76 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var80 = org.jfree.chart.util.ShapeUtilities.rotateShape(var76, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var84 = org.jfree.chart.util.ShapeUtilities.rotateShape(var80, 0.0d, 1.0f, 100.0f);
    java.awt.Shape[] var85 = new java.awt.Shape[] { var84};
    org.jfree.chart.plot.DefaultDrawingSupplier var86 = new org.jfree.chart.plot.DefaultDrawingSupplier(var65, var70, var72, var74, var85);
    org.jfree.chart.plot.DefaultDrawingSupplier var87 = new org.jfree.chart.plot.DefaultDrawingSupplier(var32, var54, var56, var58, var85);
    java.awt.Paint var88 = var87.getNextPaint();
    boolean var89 = var17.equals((java.lang.Object)var88);
    java.awt.Paint var90 = var17.getFillPaint();
    java.awt.Paint var91 = var17.getFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("poly", var1, (-1.0f), 1.0f, var4);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    int var5 = var4.getGreen();
    float[] var6 = null;
    float[] var7 = var4.getColorComponents(var6);
    boolean var9 = var4.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4, 0.0f, 10, var12);
    int var14 = var4.getTransparency();
    java.awt.Color var15 = var4.darker();
    java.awt.Color var16 = var15.darker();
    java.awt.image.ColorModel var17 = null;
    java.awt.Rectangle var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    java.awt.geom.AffineTransform var20 = null;
    java.awt.RenderingHints var21 = null;
    java.awt.PaintContext var22 = var15.createContext(var17, var18, var19, var20, var21);
    java.awt.image.ColorModel var23 = null;
    java.awt.Rectangle var24 = null;
    java.awt.Font var26 = null;
    java.awt.Color var29 = java.awt.Color.getColor("", 0);
    int var30 = var29.getGreen();
    float[] var31 = null;
    float[] var32 = var29.getColorComponents(var31);
    boolean var34 = var29.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var37 = null;
    org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, (java.awt.Paint)var29, 0.0f, 10, var37);
    java.util.List var39 = var38.getLines();
    org.jfree.chart.util.HorizontalAlignment var40 = var38.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var45 = null;
    org.jfree.chart.title.LegendItemBlockContainer var47 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var44, var45, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var48 = var47.getBounds();
    java.awt.geom.AffineTransform var49 = null;
    java.awt.RenderingHints var50 = null;
    java.awt.PaintContext var51 = var15.createContext(var23, var24, var48, var49, var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("Size2D[width=10.0, height=14.0]", "", "", "Size2D[width=10.0, height=14.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    var5.setLicenceName("0,-1,-1,1,1,1,1,1");

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var5 = null;
    java.awt.Rectangle var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    java.awt.geom.AffineTransform var8 = null;
    java.awt.RenderingHints var9 = null;
    java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var4);
    java.awt.color.ColorSpace var12 = var4.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    int var8 = var7.getGreen();
    float[] var9 = null;
    float[] var10 = var7.getColorComponents(var9);
    boolean var12 = var7.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var7, 0.0f, 10, var15);
    org.jfree.chart.title.LegendGraphic var17 = new org.jfree.chart.title.LegendGraphic(var2, (java.awt.Paint)var7);
    java.awt.Color var20 = java.awt.Color.getColor("", 0);
    var17.setFillPaint((java.awt.Paint)var20);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    var17.setShape(var23);
    boolean var25 = var17.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var13 = var12.getLabelToolTip();
    java.awt.Font var14 = var12.getTickLabelFont();
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var19 = null;
    java.awt.Color var22 = java.awt.Color.getColor("", 0);
    int var23 = var22.getGreen();
    float[] var24 = null;
    float[] var25 = var22.getColorComponents(var24);
    boolean var27 = var22.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var30 = null;
    org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, (java.awt.Paint)var22, 0.0f, 10, var30);
    org.jfree.chart.title.LegendGraphic var32 = new org.jfree.chart.title.LegendGraphic(var17, (java.awt.Paint)var22);
    org.jfree.chart.text.TextBlock var33 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var14, (java.awt.Paint)var22);
    var6.setNoDataMessageFont(var14);
    org.jfree.chart.plot.CategoryMarker var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    org.jfree.chart.util.RectangleEdge var35 = var10.getLegendItemGraphicEdge();
    java.lang.Object var36 = var10.clone();
    org.jfree.chart.util.RectangleInsets var37 = var10.getLegendItemGraphicPadding();
    java.awt.Font var39 = null;
    java.awt.Color var42 = java.awt.Color.getColor("", 0);
    int var43 = var42.getGreen();
    float[] var44 = null;
    float[] var45 = var42.getColorComponents(var44);
    boolean var47 = var42.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var50 = null;
    org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var39, (java.awt.Paint)var42, 0.0f, 10, var50);
    java.util.List var52 = var51.getLines();
    org.jfree.chart.util.HorizontalAlignment var53 = var51.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var54 = null;
    org.jfree.chart.block.ColumnArrangement var57 = new org.jfree.chart.block.ColumnArrangement(var53, var54, 12.0d, 25.0d);
    org.jfree.data.general.Dataset var58 = null;
    org.jfree.chart.title.LegendItemBlockContainer var60 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var57, var58, (java.lang.Comparable)"poly");
    java.awt.geom.Rectangle2D var61 = var60.getBounds();
    java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var66 = null;
    java.awt.Color var69 = java.awt.Color.getColor("", 0);
    int var70 = var69.getGreen();
    float[] var71 = null;
    float[] var72 = var69.getColorComponents(var71);
    boolean var74 = var69.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var77 = null;
    org.jfree.chart.text.TextBlock var78 = org.jfree.chart.text.TextUtilities.createTextBlock("", var66, (java.awt.Paint)var69, 0.0f, 10, var77);
    org.jfree.chart.title.LegendGraphic var79 = new org.jfree.chart.title.LegendGraphic(var64, (java.awt.Paint)var69);
    boolean var80 = var79.isShapeOutlineVisible();
    java.awt.Graphics2D var81 = null;
    org.jfree.chart.block.RectangleConstraint var84 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 12.0d);
    org.jfree.chart.block.LengthConstraintType var85 = var84.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var86 = var84.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var87 = var79.arrange(var81, var84);
    java.awt.Paint var88 = var79.getLinePaint();
    var60.add((org.jfree.chart.block.Block)var79);
    boolean var90 = var60.isEmpty();
    var10.setWrapper((org.jfree.chart.block.BlockContainer)var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     var6.clearRangeMarkers(0);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var12 = var11.getLabelToolTip();
//     java.awt.Paint var13 = var11.getTickLabelPaint();
//     java.lang.Object var14 = null;
//     boolean var15 = var11.equals(var14);
//     var6.setDomainAxis(var11);
//     org.jfree.chart.LegendItemCollection var17 = var6.getLegendItems();
//     java.lang.Object var18 = var17.clone();
//     org.jfree.chart.LegendItemCollection var19 = null;
//     var17.addAll(var19);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     var6.clearRangeMarkers();
//     org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation(0);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var15 = var14.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var14, var16, var17);
//     boolean var19 = var18.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     java.awt.Font var21 = var18.getNoDataMessageFont();
//     org.jfree.data.category.CategoryDataset var22 = var18.getDataset();
//     java.awt.Stroke var23 = var18.getDomainGridlineStroke();
//     var6.setOutlineStroke(var23);
//     
//     // Checks the contract:  equals-hashcode on var8 and var20
//     assertTrue("Contract failed: equals-hashcode on var8 and var20", var8.equals(var20) ? var8.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var8
//     assertTrue("Contract failed: equals-hashcode on var20 and var8", var20.equals(var8) ? var20.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    var6.setRangeCrosshairVisible(false);
    java.awt.Stroke var11 = var6.getOutlineStroke();
    java.awt.Font var13 = null;
    java.awt.Color var16 = java.awt.Color.getColor("", 0);
    int var17 = var16.getGreen();
    float[] var18 = null;
    float[] var19 = var16.getColorComponents(var18);
    boolean var21 = var16.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var24 = null;
    org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var16, 0.0f, 10, var24);
    int var26 = var16.getTransparency();
    java.awt.color.ColorSpace var27 = var16.getColorSpace();
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Font var32 = null;
    java.awt.Color var35 = java.awt.Color.getColor("", 0);
    int var36 = var35.getGreen();
    float[] var37 = null;
    float[] var38 = var35.getColorComponents(var37);
    boolean var40 = var35.equals((java.lang.Object)1.0d);
    org.jfree.chart.text.TextMeasurer var43 = null;
    org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("", var32, (java.awt.Paint)var35, 0.0f, 10, var43);
    org.jfree.chart.title.LegendGraphic var45 = new org.jfree.chart.title.LegendGraphic(var30, (java.awt.Paint)var35);
    var45.setID("Size2D[width=10.0, height=14.0]");
    double var48 = var45.getContentXOffset();
    java.awt.Paint var49 = var45.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var52 = var51.getLabelToolTip();
    java.awt.Stroke var53 = var51.getAxisLineStroke();
    var45.setOutlineStroke(var53);
    org.jfree.chart.util.RectangleInsets var59 = new org.jfree.chart.util.RectangleInsets(12.0d, (-1.0d), 1.0d, 12.0d);
    org.jfree.chart.block.LineBorder var60 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var16, var53, var59);
    var6.setNoDataMessagePaint((java.awt.Paint)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var4 = var3.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var3, var5, var6);
    boolean var8 = var7.isSubplot();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    var7.setRangeCrosshairVisible(false);
    var7.setBackgroundImageAlignment(1);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var14.setTextAntiAlias(false);
    var14.setBorderVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
//     double var2 = var1.getFixedDimension();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var6 = var5.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var3, var5, var7, var8);
//     boolean var10 = var9.isSubplot();
//     var9.clearRangeMarkers(0);
//     org.jfree.data.Range var13 = null;
//     org.jfree.data.Range var17 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var18 = var17.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(1.0d, var17);
//     org.jfree.data.Range var22 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var23 = var22.getLength();
//     org.jfree.chart.JFreeChart var25 = null;
//     org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var25, 100, 10);
//     org.jfree.chart.JFreeChart var29 = null;
//     var28.setChart(var29);
//     var28.setPercent((-1));
//     boolean var33 = var22.equals((java.lang.Object)var28);
//     org.jfree.chart.block.RectangleConstraint var34 = var19.toRangeHeight(var22);
//     org.jfree.data.Range var35 = org.jfree.data.Range.combine(var13, var22);
//     org.jfree.data.Range var39 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var40 = var39.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(1.0d, var39);
//     org.jfree.data.Range var42 = org.jfree.data.Range.combine(var35, var39);
//     org.jfree.data.general.Dataset var43 = null;
//     org.jfree.data.general.DatasetChangeEvent var44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var35, var43);
//     var9.datasetChanged(var44);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var9);
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var50 = var49.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var47, var49, var51, var52);
//     org.jfree.chart.event.AxisChangeEvent var54 = null;
//     var53.axisChanged(var54);
//     org.jfree.chart.util.RectangleInsets var56 = var53.getInsets();
//     org.jfree.chart.util.SortOrder var57 = var53.getColumnRenderingOrder();
//     var9.setColumnRenderingOrder(var57);
//     var9.zoom(12.0d);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
//     java.lang.String var3 = var2.getLabelToolTip();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     java.awt.Font var9 = var6.getNoDataMessageFont();
//     java.awt.Color var12 = java.awt.Color.getColor("0,-1,-1,1,1,1,1,1", (-1));
//     int var13 = var12.getTransparency();
//     var6.setNoDataMessagePaint((java.awt.Paint)var12);
//     java.awt.image.ColorModel var15 = null;
//     java.awt.Rectangle var16 = null;
//     org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
//     double var23 = var21.trimHeight(10.0d);
//     double var25 = var21.calculateLeftInset(0.0d);
//     double var26 = var21.getRight();
//     double var28 = var21.extendHeight(1.0d);
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("hi!");
//     org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var39 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var40 = null;
//     org.jfree.chart.event.ChartChangeEvent var41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var39, var40);
//     org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var39);
//     var32.setFrame((org.jfree.chart.block.BlockFrame)var42);
//     org.jfree.chart.block.BlockFrame var44 = var32.getFrame();
//     var32.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var47 = var32.getBounds();
//     var30.setBounds(var47);
//     java.awt.geom.Rectangle2D var51 = var21.createOutsetRectangle(var47, true, false);
//     java.awt.geom.AffineTransform var52 = null;
//     java.awt.RenderingHints var53 = null;
//     java.awt.PaintContext var54 = var12.createContext(var15, var16, var47, var52, var53);
//     org.jfree.chart.util.RectangleInsets var59 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
//     double var61 = var59.trimHeight(10.0d);
//     double var63 = var59.calculateLeftInset(0.0d);
//     double var64 = var59.getRight();
//     double var66 = var59.extendHeight(1.0d);
//     org.jfree.chart.block.LabelBlock var68 = new org.jfree.chart.block.LabelBlock("hi!");
//     org.jfree.chart.block.LabelBlock var70 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var77 = java.awt.Color.getColor("", 0);
//     org.jfree.chart.JFreeChart var78 = null;
//     org.jfree.chart.event.ChartChangeEvent var79 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var77, var78);
//     org.jfree.chart.block.BlockBorder var80 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 1.0d, 100.0d, (java.awt.Paint)var77);
//     var70.setFrame((org.jfree.chart.block.BlockFrame)var80);
//     org.jfree.chart.block.BlockFrame var82 = var70.getFrame();
//     var70.setURLText("org.jfree.chart.event.ChartProgressEvent[source=10.0]");
//     java.awt.geom.Rectangle2D var85 = var70.getBounds();
//     var68.setBounds(var85);
//     java.awt.geom.Rectangle2D var89 = var59.createOutsetRectangle(var85, true, false);
//     boolean var90 = org.jfree.chart.util.ShapeUtilities.contains((java.awt.geom.Rectangle2D)var16, var85);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("LegendItemEntity: seriesKey=null, dataset=null", "org.jfree.chart.event.ChartProgressEvent[source=10.0]");
    java.lang.String var3 = var2.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var3.equals("LegendItemEntity: seriesKey=null, dataset=null"));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var3 = var2.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var4, var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.axis.AxisLocation var9 = var6.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    double var16 = var15.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, var15);
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    double var21 = var20.getLength();
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var23, 100, 10);
    org.jfree.chart.JFreeChart var27 = null;
    var26.setChart(var27);
    var26.setPercent((-1));
    boolean var31 = var20.equals((java.lang.Object)var26);
    org.jfree.chart.block.RectangleConstraint var32 = var17.toRangeHeight(var20);
    org.jfree.data.Range var33 = var32.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var10.arrange(var11, var32);
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var37 = var36.getLabelToolTip();
    java.awt.Paint var38 = var36.getTickLabelPaint();
    java.lang.Object var39 = null;
    boolean var40 = var36.equals(var39);
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var43 = var42.getLabelToolTip();
    java.awt.Font var44 = var42.getTickLabelFont();
    var36.setLabelFont(var44);
    var10.setItemFont(var44);
    org.jfree.chart.util.VerticalAlignment var47 = var10.getVerticalAlignment();
    java.lang.String var48 = var47.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "VerticalAlignment.CENTER"+ "'", var48.equals("VerticalAlignment.CENTER"));

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var6 = var4.trimHeight(10.0d);
    double var8 = var4.calculateLeftInset(0.0d);
    double var10 = var4.trimHeight(12.0d);
    double var11 = var4.getLeft();
    double var13 = var4.extendHeight(12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10.0d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var2 = var1.getLabelToolTip();
    java.awt.Paint var4 = var1.getTickLabelPaint((java.lang.Comparable)(short)100);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var9 = var8.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var6, var8, var10, var11);
    boolean var13 = var12.isSubplot();
    org.jfree.chart.axis.AxisLocation var15 = var12.getDomainAxisLocation((-33));
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
    java.awt.Graphics2D var17 = null;
    org.jfree.data.Range var21 = new org.jfree.data.Range(0.0d, 0.0d);
    double var22 = var21.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(1.0d, var21);
    org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 0.0d);
    double var27 = var26.getLength();
    org.jfree.chart.JFreeChart var29 = null;
    org.jfree.chart.event.ChartProgressEvent var32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10.0d, var29, 100, 10);
    org.jfree.chart.JFreeChart var33 = null;
    var32.setChart(var33);
    var32.setPercent((-1));
    boolean var37 = var26.equals((java.lang.Object)var32);
    org.jfree.chart.block.RectangleConstraint var38 = var23.toRangeHeight(var26);
    org.jfree.data.Range var39 = var38.getWidthRange();
    org.jfree.chart.util.Size2D var40 = var16.arrange(var17, var38);
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var43 = var42.getLabelToolTip();
    java.awt.Paint var44 = var42.getTickLabelPaint();
    java.lang.Object var45 = null;
    boolean var46 = var42.equals(var45);
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var49 = var48.getLabelToolTip();
    java.awt.Font var50 = var48.getTickLabelFont();
    var42.setLabelFont(var50);
    var16.setItemFont(var50);
    org.jfree.data.category.CategoryDataset var53 = null;
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("poly");
    java.lang.String var56 = var55.getLabelToolTip();
    org.jfree.chart.axis.ValueAxis var57 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var53, var55, var57, var58);
    boolean var60 = var59.isSubplot();
    var59.clearRangeMarkers(0);
    java.awt.Font var64 = null;
    java.awt.Color var67 = java.awt.Color.getColor("", 0);
    java.awt.image.ColorModel var68 = null;
    java.awt.Rectangle var69 = null;
    java.awt.geom.Rectangle2D var70 = null;
    java.awt.geom.AffineTransform var71 = null;
    java.awt.RenderingHints var72 = null;
    java.awt.PaintContext var73 = var67.createContext(var68, var69, var70, var71, var72);
    org.jfree.chart.text.TextBlock var74 = org.jfree.chart.text.TextUtilities.createTextBlock("", var64, (java.awt.Paint)var67);
    var59.setNoDataMessagePaint((java.awt.Paint)var67);
    org.jfree.chart.text.TextMeasurer var77 = null;
    org.jfree.chart.text.TextBlock var78 = org.jfree.chart.text.TextUtilities.createTextBlock("", var50, (java.awt.Paint)var67, (-1.0f), var77);
    var1.setTickLabelFont(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

}
