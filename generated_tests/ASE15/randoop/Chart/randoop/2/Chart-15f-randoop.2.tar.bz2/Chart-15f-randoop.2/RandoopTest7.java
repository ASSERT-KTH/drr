
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }


    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var4.java2DToValue(100.0d, var6, var7);
    var4.setUpperMargin(10.0d);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    java.awt.Paint var13 = null;
    var12.setLabelShadowPaint(var13);
    java.awt.Graphics2D var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    var18.setLabelGap((-1.0d));
    java.lang.Object var21 = var18.clone();
    java.awt.Paint var22 = var18.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var23 = null;
    var18.setURLGenerator(var23);
    var18.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    org.jfree.chart.plot.PiePlotState var29 = var12.initialise(var15, var16, var18, (java.lang.Integer)0, var28);
    org.jfree.chart.urls.PieURLGenerator var30 = var12.getLegendLabelURLGenerator();
    java.awt.Paint var31 = var12.getNoDataMessagePaint();
    var4.setAxisLinePaint(var31);
    org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder(3.0d, 2.0d, 0.0d, 0.0d, var31);
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var35.configure();
    org.jfree.chart.axis.DateTickUnit var37 = null;
    var35.setTickUnit(var37, false, false);
    var35.configure();
    java.awt.Shape var42 = var35.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=10.0]", "");
    boolean var46 = var33.equals((java.lang.Object)var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var5 = null;
    java.awt.Rectangle var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    java.awt.geom.AffineTransform var8 = null;
    java.awt.RenderingHints var9 = null;
    java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
    java.lang.String var11 = var4.toString();
    float[] var12 = null;
    float[] var13 = var4.getRGBComponents(var12);
    int var14 = var4.getBlue();
    java.awt.Color var15 = java.awt.Color.getColor("hi!", var4);
    java.awt.Color var16 = var4.brighter();
    java.awt.Color var17 = var4.darker();
    int var18 = var4.getRed();
    float[] var19 = null;
    float[] var20 = var4.getRGBComponents(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "java.awt.Color[r=255,g=255,b=254]"+ "'", var11.equals("java.awt.Color[r=255,g=255,b=254]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 254);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextAnchor var2 = var1.getLabelTextAnchor();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    java.awt.Color var21 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var22 = null;
    java.awt.Rectangle var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.awt.geom.AffineTransform var25 = null;
    java.awt.RenderingHints var26 = null;
    java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
    java.awt.color.ColorSpace var28 = var21.getColorSpace();
    var5.setNoDataMessagePaint((java.awt.Paint)var21);
    boolean var30 = var2.equals((java.lang.Object)var5);
    java.lang.String var31 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "TextAnchor.CENTER"+ "'", var31.equals("TextAnchor.CENTER"));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var2.valueToJava2D(10.0d, var4, var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var10.setTickMarkOutsideLength(1.0f);
    java.awt.Font var13 = var10.getLabelFont();
    double var14 = var10.getLowerMargin();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    var15.setUpperMargin(1.0d);
    boolean var18 = var15.isTickMarksVisible();
    org.jfree.chart.axis.NumberTickUnit var19 = var15.getTickUnit();
    var10.removeCategoryLabelToolTip((java.lang.Comparable)var19);
    java.awt.Color var24 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var25 = null;
    java.awt.Rectangle var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    java.awt.geom.AffineTransform var28 = null;
    java.awt.RenderingHints var29 = null;
    java.awt.PaintContext var30 = var24.createContext(var25, var26, var27, var28, var29);
    java.awt.color.ColorSpace var31 = var24.getColorSpace();
    int var32 = var24.getGreen();
    var10.setAxisLinePaint((java.awt.Paint)var24);
    var8.setDomainGridlinePaint((java.awt.Paint)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 255);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
    java.awt.Stroke var21 = var19.getRangeZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var23 = var19.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataset var24 = null;
    int var25 = var19.indexOf(var24);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var31 = var30.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var33 = null;
    org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
    var34.setLabelGap((-1.0d));
    java.lang.Object var37 = var34.clone();
    java.awt.Paint var38 = var34.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var39 = null;
    var34.setURLGenerator(var39);
    java.awt.Stroke var42 = var34.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var44 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var34.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var44);
    boolean var46 = var32.equals((java.lang.Object)var34);
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var29, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.axis.ValueAxis)var32, var47);
    org.jfree.chart.LegendItemCollection var49 = var48.getFixedLegendItems();
    var48.clearRangeMarkers(0);
    java.awt.geom.Point2D var52 = var48.getQuadrantOrigin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.zoomRangeAxes(14.0d, (-1.99999999d), var28, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var1.setTickMarkOutsideLength(1.0f);
    java.awt.Font var4 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Paint var7 = null;
    var6.setLabelShadowPaint(var7);
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    var12.setLabelGap((-1.0d));
    java.lang.Object var15 = var12.clone();
    java.awt.Paint var16 = var12.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var17 = null;
    var12.setURLGenerator(var17);
    var12.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    org.jfree.chart.plot.PiePlotState var23 = var6.initialise(var9, var10, var12, (java.lang.Integer)0, var22);
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
    var25.setLabelGap((-1.0d));
    java.awt.Font var28 = var25.getLabelFont();
    var12.setNoDataMessageFont(var28);
    boolean var30 = var1.equals((java.lang.Object)var12);
    var12.setSimpleLabels(false);
    org.jfree.chart.urls.PieURLGenerator var33 = null;
    var12.setLegendLabelURLGenerator(var33);
    java.awt.Paint var35 = null;
    var12.setBackgroundPaint(var35);
    java.awt.Paint var37 = var12.getShadowPaint();
    org.jfree.chart.LegendItemCollection var38 = var12.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var58 = var57.clone();
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var57.notifyListeners(var59);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
    var57.setLabelPaint(var64);
    var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.util.Layer var68 = null;
    var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
    org.jfree.chart.axis.CategoryAnchor var70 = var54.getDomainGridlinePosition();
    org.jfree.chart.axis.AxisSpace var71 = var54.getFixedDomainAxisSpace();
    java.awt.Stroke var72 = var54.getRangeCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
    org.jfree.chart.block.BlockContainer var21 = var20.getItemContainer();
    var21.clear();
    var21.setWidth(1.0E-8d);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.util.Size2D var29 = var21.arrange(var25, var28);
    org.jfree.chart.block.RectangleConstraint var31 = var28.toFixedHeight(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var58 = var57.clone();
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var57.notifyListeners(var59);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
    var57.setLabelPaint(var64);
    var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.util.Layer var68 = null;
    var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
    var54.setWeight(0);
    var54.clearAnnotations();
    org.jfree.chart.util.RectangleEdge var74 = var54.getDomainAxisEdge(100);
    boolean var75 = var54.isDomainGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis var77 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    float var78 = var77.getMaximumCategoryLabelWidthRatio();
    float var79 = var77.getMaximumCategoryLabelWidthRatio();
    java.util.List var80 = var54.getCategoriesForAxis(var77);
    var77.setCategoryLabelPositionOffset(254);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var5 = var4.getTextAlignment();
    var1.setHorizontalAlignment(var5);
    var1.setText("");
    double var9 = var1.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    var2.setRenderer(var3);
    java.lang.String var5 = var2.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "WMAP_Plot"+ "'", var5.equals("WMAP_Plot"));

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    float var2 = var1.getMaximumCategoryLabelWidthRatio();
    double var3 = var1.getUpperMargin();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var8 = var7.getTextAlignment();
    var7.setHeight(1.0d);
    double var11 = var7.getContentXOffset();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var13 = var12.getLabelFont();
    boolean var14 = var7.equals((java.lang.Object)var13);
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=254]", var13);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var18 = var17.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
    var21.setLabelGap((-1.0d));
    java.lang.Object var24 = var21.clone();
    java.awt.Paint var25 = var21.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var26 = null;
    var21.setURLGenerator(var26);
    java.awt.Stroke var29 = var21.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var31 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var21.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var31);
    boolean var33 = var19.equals((java.lang.Object)var21);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var19, var34);
    var35.clearDomainAxes();
    org.jfree.chart.axis.AxisLocation var38 = null;
    var35.setRangeAxisLocation(4, var38, false);
    java.awt.Color var44 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var45 = null;
    java.awt.Rectangle var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    java.awt.geom.AffineTransform var48 = null;
    java.awt.RenderingHints var49 = null;
    java.awt.PaintContext var50 = var44.createContext(var45, var46, var47, var48, var49);
    java.lang.String var51 = var44.toString();
    var35.setRangeZeroBaselinePaint((java.awt.Paint)var44);
    org.jfree.chart.text.TextBlock var53 = org.jfree.chart.text.TextUtilities.createTextBlock("Other", var13, (java.awt.Paint)var44);
    boolean var54 = var1.equals((java.lang.Object)var53);
    float var55 = var1.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "java.awt.Color[r=255,g=255,b=254]"+ "'", var51.equals("java.awt.Color[r=255,g=255,b=254]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0f);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var58 = var57.clone();
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var57.notifyListeners(var59);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
    var57.setLabelPaint(var64);
    var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.util.Layer var68 = null;
    var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
    org.jfree.chart.axis.CategoryAnchor var70 = var54.getDomainGridlinePosition();
    org.jfree.chart.axis.CategoryAxis var73 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    int var74 = var73.getMaximumCategoryLabelLines();
    int var75 = var73.getCategoryLabelPositionOffset();
    var73.addCategoryLabelToolTip((java.lang.Comparable)'#', "Size2D[width=0.0, height=0.0]");
    var54.setDomainAxis(0, var73, false);
    org.jfree.chart.axis.AxisLocation var82 = null;
    var54.setRangeAxisLocation(255, var82);
    org.jfree.data.category.CategoryDataset var84 = var54.getDataset();
    java.awt.Stroke var85 = var54.getRangeCrosshairStroke();
    org.jfree.chart.axis.AxisLocation var86 = var54.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    java.awt.Paint var8 = var1.getLabelOutlinePaint();
    boolean var9 = var1.getSectionOutlinesVisible();
    java.awt.Paint var10 = var1.getLabelOutlinePaint();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Shape var12 = var11.getNextShape();
    java.awt.Paint var13 = var11.getNextOutlinePaint();
    java.awt.Stroke var14 = var11.getNextStroke();
    var1.setBaseSectionOutlineStroke(var14);
    var1.setInteriorGap(0.03374999999999999d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    org.jfree.chart.LegendItemCollection var20 = var19.getFixedLegendItems();
    var19.setDomainCrosshairVisible(false);
    java.awt.Stroke var23 = var19.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisSpace var24 = var19.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

//  public void test16() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleEdge.RIGHT", var1);
//
//  }
//
  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
    org.jfree.chart.LegendItemCollection var19 = var1.getLegendItems();
    java.lang.Object var20 = var19.clone();
    int var21 = var19.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainAxes();
    var19.clearDomainMarkers();
    boolean var22 = var19.isDomainGridlinesVisible();
    boolean var23 = var19.isDomainZeroBaselineVisible();
    java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextAnchor var29 = var28.getLabelTextAnchor();
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var28.notifyListeners(var30);
    java.lang.String var32 = var28.getLabel();
    org.jfree.chart.util.Layer var33 = null;
    var25.addRangeMarker(0, (org.jfree.chart.plot.Marker)var28, var33);
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var39 = var38.getTextAlignment();
    var38.setHeight(1.0d);
    double var42 = var38.getContentXOffset();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var44 = var43.getLabelFont();
    boolean var45 = var38.equals((java.lang.Object)var44);
    org.jfree.chart.text.TextLine var46 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=254]", var44);
    boolean var47 = var35.equals((java.lang.Object)"java.awt.Color[r=255,g=255,b=254]");
    java.awt.Stroke var48 = var35.getAngleGridlineStroke();
    var28.setOutlineStroke(var48);
    var19.setDomainZeroBaselineStroke(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

}
