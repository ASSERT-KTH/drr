
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getLastMillisecond(var1);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "January"+ "'", var1.equals("January"));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Following"+ "'", var1.equals("Following"));

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("January");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.delete(0, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)10L);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var2 = var1.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)1418759999999L);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2014", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getMiddleMillisecond(var3);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var2, var3);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var1.getValue(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setKey(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("January");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Wed Dec 31 16:00:00 PST 1969");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     java.util.Calendar var10 = null;
//     var7.peg(var10);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 10.0d);
//     java.util.Calendar var4 = null;
//     var0.peg(var4);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("January");

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     java.util.TimeZone var3 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var2, var3);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var5 = var1.getTimePeriod(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var7 = var1.getDataItem(2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(100, 1, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var8 = var1.createCopy(100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 16:00:00 PST 1969");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-1), 10, 20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.util.Calendar var4 = null;
//     long var5 = var3.getLastMillisecond(var4);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var5 = var4.getStart();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var4, 10.0d);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Following", var1);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("January", var1);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.lang.String var7 = var6.toString();
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(1, var6);
//     int var9 = var8.getYearValue();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)2014L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "2014"+ "'", var7.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 10.0d);
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(10, var3);
//     org.jfree.data.time.Year var8 = var7.getYear();
//     long var9 = var7.getFirstMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(short)1);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1412146800000L);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.data.time.Year var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, var1);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var3 = var2.next();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, 10.0d);
    org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(10, var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(20, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.String var13 = var12.toString();
//     int var15 = var12.compareTo((java.lang.Object)"2014");
//     int var16 = var11.getIndex((org.jfree.data.time.RegularTimePeriod)var12);
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var18);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1));
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    var2.setDescription("org.jfree.data.general.SeriesException: January");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setKey((java.lang.Comparable)'4');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var1.getTimePeriod((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     java.util.Calendar var9 = null;
//     long var10 = var2.getFirstMillisecond(var9);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", var1);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("2014", var1);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.Object var7 = var1.clone();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 10.0d);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(10, var9);
//     org.jfree.data.time.Year var14 = var13.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var18 = var1.getTimePeriod(2014);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var7 = var1.createCopy(12, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var3 = var2.next();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, 10.0d);
    org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(10, var2);
    org.jfree.data.time.Year var7 = var6.getYear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(100, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(12, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
    org.jfree.data.time.RegularTimePeriod var7 = var6.getPeriod();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var6, true);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2, var4);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2, var4);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100);
    var3.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var3);
    var3.setDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2014, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.RegularTimePeriod var2 = var0.next();
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
    org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(10, 100);
    java.lang.Number var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.update((org.jfree.data.time.RegularTimePeriod)var6, var7);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMaximumItemCount((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    org.jfree.data.time.RegularTimePeriod var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var6, 0.0d, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    var1.setDescription("org.jfree.data.general.SeriesException: January");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = var1.getFollowingDayOfWeek(28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Wed Dec 31 16:00:00 PST 1969", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-453));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(31, 1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     int var3 = var0.getDayOfMonth();
//     java.lang.String var4 = var0.toString();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getLastMillisecond(var5);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.lang.Comparable var3 = var1.getKey();
    org.jfree.data.time.RegularTimePeriod var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var4, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.delete(2014, 31);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesException: January", var1);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    java.lang.Object var6 = var1.clone();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var9 = var8.getStart();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var8, 0.0d, true);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var2, var3);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    long var7 = var6.getLastMillisecond();
    long var8 = var6.getLastMillisecond();
    long var9 = var6.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var10 = var6.previous();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var10, 1.0d);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(31, (-453), 28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.fireSeriesChanged();

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Wed Dec 31 16:00:00 PST 1969");

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Time");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.Object var7 = var1.clone();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 10.0d);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(10, var9);
//     org.jfree.data.time.Year var14 = var13.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     java.lang.String var20 = var19.toString();
//     int var22 = var19.compareTo((java.lang.Object)"2014");
//     int var23 = var18.getIndex((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var19, 10.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-1));
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var24 = org.jfree.chart.util.ObjectUtilities.deepClone(var23);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)1391241599999L);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var3 = var2.getStart();
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var3);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addYears(0, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = var6.getNearestDayOfWeek(28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var2.setMaximumItemCount(0);
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var7 = var6.next();
    org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, 10.0d);
    org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(10, var6);
    org.jfree.data.time.RegularTimePeriod var11 = var6.next();
    var2.delete((org.jfree.data.time.RegularTimePeriod)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(2014, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    boolean var6 = var1.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var7 = var1.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.lang.Comparable var3 = var1.getKey();
    var1.setMaximumItemAge(1412146800000L);
    java.lang.String var6 = var1.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(100, (java.lang.Number)2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
    java.util.TimeZone var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var2, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-453));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-570));

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Value", var1);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Wed Dec 31 16:00:00 PST 1969", var1);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     java.util.Calendar var28 = null;
//     long var29 = var25.getFirstMillisecond(var28);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     java.lang.String var2 = var1.toString();
//     java.util.Date var3 = var1.getEnd();
//     int var4 = var1.getDayOfMonth();
//     java.lang.String var5 = var1.toString();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(100);
//     var8.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(1, var8);
//     var8.setDescription("");
//     boolean var14 = var1.equals((java.lang.Object)var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addDays((-453), var8);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "20-December-2014"+ "'", var2.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "20-December-2014"+ "'", var5.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.lang.Comparable var3 = var1.getKey();
    var1.setMaximumItemAge(1412146800000L);
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var7 = var6.next();
    org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, 10.0d);
    java.lang.Object var10 = var9.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var9);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    java.lang.Class var0 = null;
    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", var1);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getMiddleMillisecond(var4);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-570), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     java.util.Date var11 = var2.getStart();
//     java.util.TimeZone var12 = null;
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(var11, var12);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    var1.setDescription("org.jfree.data.general.SeriesException: January");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = var1.getPreviousDayOfWeek(20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-570), 1, 28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("20-December-2014");

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     int var3 = var0.getDayOfMonth();
//     java.lang.String var4 = var0.toString();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
//     var7.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
//     var7.setDescription("");
//     boolean var13 = var0.equals((java.lang.Object)var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var15 = var7.getPreviousDayOfWeek(10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "20-December-2014"+ "'", var4.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(20, 20, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(100);
    var5.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    org.jfree.data.time.SerialDate var9 = var2.getEndOfCurrentMonth(var5);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(100);
    var14.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addMonths(1, var14);
    org.jfree.data.time.SerialDate var18 = var11.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var19 = var9.getEndOfCurrentMonth(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    java.util.TimeZone var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-570), 0, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var3 = var2.getStart();
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var3);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addYears(0, var5);
    org.jfree.data.time.SerialDate var8 = var6.getFollowingDayOfWeek(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var6.getFollowingDayOfWeek((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

//  public void test133() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
//
//
//    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var0);
//
//  }
//
  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.util.Calendar var7 = null;
//     long var8 = var2.getFirstMillisecond(var7);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var1.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10, 12, (-453));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var2 = var1.getTime();
    java.util.TimeZone var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(31, 31, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    java.lang.Object var6 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var8 = var1.getDataItem(12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Value", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 0.0d);
//     org.jfree.data.time.Year var30 = var27.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)(byte)10);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesException: January", var1);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.util.List var3 = var1.getItems();
    var1.setMaximumItemAge(2014L);
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var7 = var6.next();
    org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var9, false);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(100);
    var5.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    org.jfree.data.time.SerialDate var9 = var2.getEndOfCurrentMonth(var5);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(100);
    var14.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addMonths(1, var14);
    org.jfree.data.time.SerialDate var18 = var11.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var19 = var9.getEndOfCurrentMonth(var14);
    org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(28, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-453));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var6 = var1.getTimePeriod(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.fireSeriesChanged();
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var6.setMaximumItemCount(0);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 10.0d);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var10);
//     org.jfree.data.time.RegularTimePeriod var15 = var10.next();
//     var6.delete((org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     java.lang.String var20 = var19.toString();
//     int var22 = var19.compareTo((java.lang.Object)"2014");
//     int var23 = var18.getIndex((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var26 = var18.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.lang.String var29 = var28.toString();
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month(1, var28);
//     java.lang.Number var31 = var18.getValue((org.jfree.data.time.RegularTimePeriod)var30);
//     boolean var32 = var10.equals((java.lang.Object)var30);
//     org.jfree.data.time.Year var33 = var30.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)0, true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "2014"+ "'", var29.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + (-1)+ "'", var31.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     long var3 = var1.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var1.next();
//     java.lang.String var5 = var4.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var5.equals("Wed Dec 31 16:00:00 PST 1969"));
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-453));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    var4.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
    org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var12 = var11.getStart();
    org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var12);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var12);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addYears(0, var14);
    org.jfree.data.time.SerialDate var17 = var15.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var18 = var8.getEndOfCurrentMonth(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var20 = var8.getNearestDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    java.util.TimeZone var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(12, 2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(28, 10, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October 2014", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-570));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-598));

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", var1);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.Year var28 = var25.getYear();
//     java.util.Calendar var29 = null;
//     var25.peg(var29);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-1), 0, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("December 2014", var1);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    var4.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
    org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var8.getPreviousDayOfWeek((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var2, var6);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 10);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getLastMillisecond(var3);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(1, var1);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    var4.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
    org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var4.getFollowingDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var3 = var2.getStart();
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var3);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addYears(0, var5);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(100);
    var11.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(1, var11);
    org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var11);
    org.jfree.data.time.SerialDate var16 = var6.getEndOfCurrentMonth(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var18 = var6.getPreviousDayOfWeek((-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var1);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setKey((java.lang.Comparable)'4');
    boolean var8 = var1.getNotify();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var11 = var10.getTime();
    java.util.Calendar var12 = null;
    long var13 = var10.getFirstMillisecond(var12);
    var1.setKey((java.lang.Comparable)var10);
    org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var17 = var16.next();
    org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
    org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
    org.jfree.data.time.RegularTimePeriod var21 = var16.next();
    org.jfree.data.time.TimeSeriesDataItem var22 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMaximumItemCount((-453));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Wed Dec 31 16:00:00 PST 1969");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(0, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-570), var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("January 2014", var1);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.time.TimePeriodFormatException: 20-December-2014");

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     java.lang.String var28 = var25.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "January 2014"+ "'", var28.equals("January 2014"));
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(100);
    var5.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    org.jfree.data.time.SerialDate var9 = var2.getEndOfCurrentMonth(var5);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(100);
    var14.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addMonths(1, var14);
    org.jfree.data.time.SerialDate var18 = var11.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var19 = var9.getEndOfCurrentMonth(var14);
    org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(12, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (-598));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays((-453), var1);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var2);
//     java.util.Calendar var5 = null;
//     var4.peg(var5);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var18 = var17.getLastMillisecond();
//     long var19 = var17.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var22 = var21.getDescription();
//     java.lang.Comparable var23 = var21.getKey();
//     var21.setMaximumItemAge(1412146800000L);
//     boolean var26 = var17.equals((java.lang.Object)1412146800000L);
//     java.util.Calendar var27 = null;
//     long var28 = var17.getLastMillisecond(var27);
//     long var29 = var17.getMiddleMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)(byte)1);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + (byte)100+ "'", var23.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-453));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100);
    var3.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var3);
    var3.setDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-570), var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    var1.removeAgedItems(2014L, false);
    var1.removeAgedItems(false);
    org.jfree.data.time.RegularTimePeriod var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var11 = var1.addOrUpdate(var9, (java.lang.Number)12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100);
    var3.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var3);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(12, var3);
    java.lang.String var8 = var3.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var3.getFollowingDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.jfree.data.general.SeriesException: January"+ "'", var8.equals("org.jfree.data.general.SeriesException: January"));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    long var6 = var1.getMaximumItemAge();
    int var7 = var1.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var1.getTimePeriod((-598));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    var1.removeAgedItems(2014L, false);
    var1.fireSeriesChanged();
    org.jfree.data.time.TimeSeriesDataItem var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var8, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Following");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     java.lang.String var5 = var1.getDomainDescription();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, var7);
//     boolean var10 = var1.equals((java.lang.Object)var7);
//     java.util.Calendar var11 = null;
//     var7.peg(var11);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.util.List var3 = var1.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    long var8 = var7.getLastMillisecond();
    long var9 = var7.getFirstMillisecond();
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var12 = var11.getDescription();
    java.lang.Comparable var13 = var11.getKey();
    var11.setMaximumItemAge(1412146800000L);
    boolean var16 = var7.equals((java.lang.Object)1412146800000L);
    java.util.Calendar var17 = null;
    long var18 = var7.getLastMillisecond(var17);
    java.lang.Number var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var7, var19, false);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (byte)100+ "'", var13.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.removeChangeListener(var4);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var8 = var7.getDescription();
//     java.lang.Comparable var9 = var7.getKey();
//     var7.setMaximumItemAge(1412146800000L);
//     java.lang.String var12 = var7.getDescription();
//     java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     long var21 = var19.getFirstMillisecond();
//     java.lang.String var22 = var19.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.update((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(byte)10);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "October 2014"+ "'", var22.equals("October 2014"));
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setKey((java.lang.Comparable)'4');
    boolean var8 = var1.getNotify();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var11 = var10.getTime();
    java.util.Calendar var12 = null;
    long var13 = var10.getFirstMillisecond(var12);
    var1.setKey((java.lang.Comparable)var10);
    org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var17 = var16.next();
    org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
    org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
    org.jfree.data.time.RegularTimePeriod var21 = var16.next();
    org.jfree.data.time.TimeSeriesDataItem var22 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var16);
    var1.fireSeriesChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     int var3 = var0.getDayOfMonth();
//     java.lang.String var4 = var0.toString();
//     java.lang.String var5 = var0.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "20-December-2014"+ "'", var4.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "20-December-2014"+ "'", var5.equals("20-December-2014"));
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    var4.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
    org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var4.getFollowingDayOfWeek((-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     org.jfree.data.time.Year var6 = var5.getYear();
//     java.util.Calendar var7 = null;
//     var5.peg(var7);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     java.util.Calendar var6 = null;
//     var5.peg(var6);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var8);
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var11.setMaximumItemCount(0);
    int var14 = var11.getMaximumItemCount();
    java.util.Collection var15 = var1.getTimePeriodsUniqueToOtherSeries(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var17 = var1.getTimePeriod((-598));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     var1.setNotify(false);
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     java.lang.String var19 = var18.toString();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)(-1L), false);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "2014"+ "'", var19.equals("2014"));
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(100, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-453), 2014, 20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     java.lang.String var5 = var1.getDomainDescription();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, var7);
//     boolean var10 = var1.equals((java.lang.Object)var7);
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var12.setMaximumItemCount(0);
//     int var15 = var12.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var12.removeChangeListener(var16);
//     java.beans.PropertyChangeListener var18 = null;
//     var12.removePropertyChangeListener(var18);
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)var12);
//     java.util.Calendar var21 = null;
//     var7.peg(var21);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var2 = var1.getTime();
    java.util.Calendar var3 = null;
    long var4 = var1.getFirstMillisecond(var3);
    org.jfree.data.time.RegularTimePeriod var5 = var1.next();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    var4.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
    org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var12 = var11.getStart();
    org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var12);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var12);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addYears(0, var14);
    org.jfree.data.time.SerialDate var17 = var15.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var18 = var8.getEndOfCurrentMonth(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var20 = var18.getFollowingDayOfWeek(12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Sunday"+ "'", var1.equals("Sunday"));

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(1, var1);
//     int var4 = var3.getYearValue();
//     java.util.Calendar var5 = null;
//     var3.peg(var5);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     var1.setKey((java.lang.Comparable)'4');
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var11 = var10.getTime();
//     java.util.Calendar var12 = null;
//     long var13 = var10.getFirstMillisecond(var12);
//     var1.setKey((java.lang.Comparable)var10);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.data.time.RegularTimePeriod var21 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 0.0d);
//     java.util.Calendar var25 = null;
//     long var26 = var16.getMiddleMillisecond(var25);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.fireSeriesChanged();
    boolean var5 = var1.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var7 = var1.getDataItem((-598));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.general.SeriesChangeEvent var28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var25);
//     java.lang.Object var29 = var28.getSource();
//     java.lang.String var30 = var28.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=January 2014]"+ "'", var30.equals("org.jfree.data.general.SeriesChangeEvent[source=January 2014]"));
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     long var5 = var1.getSerialIndex();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var6 = new org.jfree.data.time.Month((-570), var1);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014L);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    long var6 = var1.getMaximumItemAge();
    int var7 = var1.getItemCount();
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var9 = var8.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var9, (java.lang.Number)1);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2014, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(12, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "December"+ "'", var2.equals("December"));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     long var4 = var0.getLastMillisecond();
//     java.util.Calendar var5 = null;
//     var0.peg(var5);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     java.lang.String var27 = var22.getDescription();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var29 = var28.next();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, 10.0d);
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var35 = var34.getPeriod();
//     boolean var36 = var31.equals((java.lang.Object)var35);
//     java.lang.Object var37 = var31.clone();
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     java.lang.String var39 = var38.toString();
//     java.util.Date var40 = var38.getEnd();
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(var40);
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month(var40);
//     boolean var43 = var31.equals((java.lang.Object)var42);
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     java.lang.String var47 = var46.toString();
//     int var49 = var46.compareTo((java.lang.Object)"2014");
//     int var50 = var45.getIndex((org.jfree.data.time.RegularTimePeriod)var46);
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var53 = var45.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var51, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var55 = new org.jfree.data.time.Year();
//     java.lang.String var56 = var55.toString();
//     org.jfree.data.time.Month var57 = new org.jfree.data.time.Month(1, var55);
//     java.lang.Number var58 = var45.getValue((org.jfree.data.time.RegularTimePeriod)var57);
//     long var59 = var57.getSerialIndex();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var60 = var22.createCopy((org.jfree.data.time.RegularTimePeriod)var42, (org.jfree.data.time.RegularTimePeriod)var57);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "20-December-2014"+ "'", var39.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "20-December-2014"+ "'", var47.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var56 + "' != '" + "2014"+ "'", var56.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var58 + "' != '" + (-1)+ "'", var58.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 24169L);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    org.jfree.data.time.RegularTimePeriod var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.delete(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     boolean var24 = var1.isEmpty();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var26 = var25.next();
//     org.jfree.data.time.RegularTimePeriod var27 = var25.previous();
//     long var28 = var25.getMiddleMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var25, 10.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1404331199999L);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 28, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-570));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getSerialIndex();
//     long var2 = var0.getLastMillisecond();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 10, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
//     org.jfree.data.time.Year var7 = var4.getYear();
//     int var8 = var0.compareTo((java.lang.Object)var4);
//     java.util.Calendar var9 = null;
//     var4.peg(var9);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
    org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var10, 1.0d, true);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    java.util.Date var0 = null;
    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var2);
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var2, var5);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.RegularTimePeriod var2 = var0.next();
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
    var3.setDomainDescription("Time");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
    var10.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(1, var10);
    org.jfree.data.time.SerialDate var14 = var7.getEndOfCurrentMonth(var10);
    var3.setKey((java.lang.Comparable)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var17 = var10.getFollowingDayOfWeek(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 10.0d);
//     long var4 = var0.getSerialIndex();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getMiddleMillisecond(var5);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var7 = var4.createCopy(0, 0);
//     java.lang.Class var8 = var7.getTimePeriodClass();
//     java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var2, var8);
//     java.net.URL var10 = org.jfree.chart.util.ObjectUtilities.getResource("October 10", var2);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var7 = var6.getStart();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var7);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(0, var9);
    var10.setDescription("January 2014");
    boolean var13 = var2.equals((java.lang.Object)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var15 = var10.getFollowingDayOfWeek((-453));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    var1.setDomainDescription("Following");
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    long var9 = var8.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var10 = var8.previous();
    var1.delete(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     java.util.Calendar var6 = null;
//     var1.peg(var6);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var8 = var7.getDescription();
    java.lang.Comparable var9 = var7.getKey();
    var7.setMaximumItemAge(1412146800000L);
    java.lang.String var12 = var7.getDescription();
    java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
    org.jfree.data.time.RegularTimePeriod var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.delete(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var6 = var5.next();
    org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
    org.jfree.data.time.RegularTimePeriod var10 = var5.next();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
    var1.setDescription("ERROR : Relative To String");
    boolean var14 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("January 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.util.Calendar var3 = null;
//     var1.peg(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var7 = var5.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var8 = var5.next();
//     long var9 = var5.getLastMillisecond();
//     int var10 = var1.compareTo((java.lang.Object)var5);
//     long var11 = var1.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var1.getFirstMillisecond(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10L);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var8 = var7.getDescription();
    java.lang.Comparable var9 = var7.getKey();
    var7.setMaximumItemAge(1412146800000L);
    java.lang.String var12 = var7.getDescription();
    java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
    var7.setDomainDescription("ThreadContext");
    java.util.List var16 = var7.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var17 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var16);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     long var3 = var0.getLastMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 100);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
    org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var8.setMaximumItemCount(0);
    int var11 = var5.compareTo((java.lang.Object)var8);
    java.lang.Number var12 = var5.getValue();
    org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
    boolean var15 = var5.equals((java.lang.Object)var14);
    int var16 = var2.compareTo((java.lang.Object)var5);
    java.lang.Object var17 = var5.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-453));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("December 2014");

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var2);
//     int var4 = var0.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     long var3 = var0.getLastMillisecond();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     long var5 = var4.getMiddleMillisecond();
//     int var6 = var4.getYearValue();
//     int var7 = var0.compareTo((java.lang.Object)var6);
//     java.util.Calendar var8 = null;
//     long var9 = var0.getLastMillisecond(var8);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, var4);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var2, var6);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-570), (-598), 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var7 = var6.getDescription();
    java.lang.Comparable var8 = var6.getKey();
    org.jfree.data.time.TimeSeries var9 = var1.addAndOrUpdate(var6);
    org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(10, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.add((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(-1.0f), true);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)100+ "'", var8.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    java.util.Calendar var4 = null;
    long var5 = var3.getMiddleMillisecond(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10L);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var30 = var29.getTime();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(var30);
//     int var32 = var25.compareTo((java.lang.Object)var30);
//     java.util.Calendar var33 = null;
//     long var34 = var25.getFirstMillisecond(var33);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Wed Dec 31 16:00:00 PST 1969");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    java.util.Date var4 = var3.getEnd();
    java.util.TimeZone var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=January 2014]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
    boolean var4 = var2.equals((java.lang.Object)"January");
    var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
    boolean var7 = var1.getNotify();
    boolean var8 = var1.getNotify();
    org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var10 = var9.next();
    org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 10.0d);
    java.lang.Object var13 = var12.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var12, false);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-598));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    java.lang.Class var5 = var4.getTimePeriodClass();
    var4.removeAgedItems(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)false);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var12 = var2.previous();
//     java.util.Calendar var13 = null;
//     long var14 = var2.getLastMillisecond(var13);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(12, 2014, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var8);
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var11.setMaximumItemCount(0);
    int var14 = var11.getMaximumItemCount();
    java.util.Collection var15 = var1.getTimePeriodsUniqueToOtherSeries(var11);
    org.jfree.data.general.SeriesChangeListener var16 = null;
    var1.removeChangeListener(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var19 = var1.getValue(31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-457));

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(28, (-570), 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("30-April-1900");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
    boolean var4 = var2.equals((java.lang.Object)"January");
    var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
    boolean var7 = var1.getNotify();
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var9 = var8.next();
    org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var11, true);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-598), 2147483647);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var2 = var1.next();
    org.jfree.data.time.RegularTimePeriod var3 = var1.next();
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1);
    var4.setDomainDescription("Time");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(100);
    var11.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(1, var11);
    org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var11);
    var4.setKey((java.lang.Comparable)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-570), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var2);
//     int var5 = var4.getYear();
//     java.util.Calendar var6 = null;
//     long var7 = var4.getLastMillisecond(var6);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-570), 9, 28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getLastMillisecond();
//     long var8 = var6.getLastMillisecond();
//     long var9 = var6.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var6.previous();
//     java.util.Calendar var11 = null;
//     long var12 = var6.getFirstMillisecond(var11);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.data.time.Year var21 = var20.getYear();
//     long var22 = var20.getFirstMillisecond();
//     java.lang.Number var23 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var26 = var1.createCopy(2147483647, 1);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-453), (-598));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var3 = var2.toString();
//     long var4 = var2.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "January 0"+ "'", var3.equals("January 0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-62167363200000L));
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("SerialDate.weekInMonthToString(): invalid code.");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var8);
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var11.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var14 = null;
    var11.addChangeListener(var14);
    var11.setKey((java.lang.Comparable)'4');
    boolean var18 = var11.getNotify();
    org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var21 = var20.getTime();
    java.util.Calendar var22 = null;
    long var23 = var20.getFirstMillisecond(var22);
    var11.setKey((java.lang.Comparable)var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)(-1), true);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 10L);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var4 = var3.getDescription();
//     java.lang.Comparable var5 = var3.getKey();
//     var3.setMaximumItemAge(1412146800000L);
//     java.lang.String var8 = var3.getDescription();
//     java.lang.Class var9 = var3.getTimePeriodClass();
//     java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October 10", var9);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     java.util.Date var13 = var11.getEnd();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     java.util.TimeZone var15 = null;
//     org.jfree.data.time.RegularTimePeriod var16 = org.jfree.data.time.RegularTimePeriod.createInstance(var9, var13, var15);
//     java.net.URL var17 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + (byte)100+ "'", var5.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.addPropertyChangeListener(var3);
    boolean var5 = var2.getNotify();
    java.util.Collection var6 = var2.getTimePeriods();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var2.getTimePeriod((-570));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var7 = var6.getDescription();
    java.lang.Comparable var8 = var6.getKey();
    org.jfree.data.time.TimeSeries var9 = var1.addAndOrUpdate(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMaximumItemCount((-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)100+ "'", var8.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-598));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var6 = var5.next();
    org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
    org.jfree.data.time.RegularTimePeriod var10 = var5.next();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
    var1.setDescription("ERROR : Relative To String");
    org.jfree.data.time.RegularTimePeriod var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var14, (java.lang.Number)(-1L), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(12, (-453), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    var1.setDomainDescription("30-April-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(1, var1);
//     org.jfree.data.time.Year var4 = var3.getYear();
//     java.lang.String var5 = var3.toString();
//     java.util.Calendar var6 = null;
//     long var7 = var3.getMiddleMillisecond(var6);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.lang.String var3 = var1.toString();
//     java.util.Date var4 = var1.getTime();
//     long var5 = var1.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var3.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10L);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(100, (-453), 9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    java.beans.PropertyChangeListener var6 = null;
    var1.addPropertyChangeListener(var6);
    var1.setDescription("");
    var1.setDescription("Following");
    org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 0.0d);
    org.jfree.data.time.RegularTimePeriod var15 = var14.getPeriod();
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var17.setMaximumItemCount(0);
    int var20 = var14.compareTo((java.lang.Object)var17);
    java.lang.Number var21 = var14.getValue();
    org.jfree.data.general.SeriesException var23 = new org.jfree.data.general.SeriesException("January");
    boolean var24 = var14.equals((java.lang.Object)var23);
    org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var26 = var25.next();
    org.jfree.data.time.RegularTimePeriod var27 = var25.next();
    boolean var28 = var14.equals((java.lang.Object)var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var27, (java.lang.Number)1.0f, false);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 0.0d+ "'", var21.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.util.List var3 = var1.getItems();
    var1.setMaximumItemAge(2014L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var1.getValue(9);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     java.util.Calendar var4 = null;
//     long var5 = var3.getLastMillisecond(var4);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var27 = var26.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
    int var2 = var1.getDayOfMonth();
    int var3 = var1.getMonth();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var5 = var4.next();
    org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var1.compareTo((java.lang.Object)10.0d);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var7 = var6.getDescription();
    java.lang.Comparable var8 = var6.getKey();
    org.jfree.data.time.TimeSeries var9 = var1.addAndOrUpdate(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var12 = var9.createCopy(0, (-453));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)100+ "'", var8.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    var4.setMaximumItemAge(1412146800000L);
    org.jfree.data.time.RegularTimePeriod var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(var7, (java.lang.Number)(-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-598), 20, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     org.jfree.data.time.RegularTimePeriod var6 = var1.next();
//     long var7 = var1.getSerialIndex();
//     java.util.Calendar var8 = null;
//     long var9 = var1.getFirstMillisecond(var8);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-598));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: 20-December-2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     long var11 = var2.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148799999L);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(2, 28, 2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("December");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     var1.setDomainDescription("20-December-2014");
//     org.jfree.data.time.RegularTimePeriod var9 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var9, 100.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     var7.removeAgedItems(true);
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var28 = var27.getLastMillisecond();
//     long var29 = var27.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var32 = var31.getDescription();
//     java.lang.Comparable var33 = var31.getKey();
//     var31.setMaximumItemAge(1412146800000L);
//     boolean var36 = var27.equals((java.lang.Object)1412146800000L);
//     java.util.Calendar var37 = null;
//     long var38 = var27.getLastMillisecond(var37);
//     long var39 = var27.getMiddleMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.add((org.jfree.data.time.RegularTimePeriod)var27, (-1.0d));
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + (byte)100+ "'", var33.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1L);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 100);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setMaximumItemCount(0);
//     int var11 = var5.compareTo((java.lang.Object)var8);
//     java.lang.Number var12 = var5.getValue();
//     org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
//     boolean var15 = var5.equals((java.lang.Object)var14);
//     int var16 = var2.compareTo((java.lang.Object)var5);
//     long var17 = var2.getFirstMillisecond();
//     long var18 = var2.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-58987929600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-58987929600000L));
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.util.Collection var7 = var1.getTimePeriods();
//     java.lang.String var8 = var1.getDomainDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.delete(0, (-453));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "Time"+ "'", var8.equals("Time"));
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "October"+ "'", var1.equals("October"));

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("20-December-2014", var1);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     org.jfree.data.time.TimeSeries var3 = null;
//     org.jfree.data.time.TimeSeries var4 = var1.addAndOrUpdate(var3);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    java.lang.Number var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(2147483647, var7);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-598));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update(2147483647, (java.lang.Number)(byte)0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     var1.setMaximumItemCount(100);
//     org.jfree.data.time.RegularTimePeriod var17 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var19 = var1.addOrUpdate(var17, 1.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
// 
//   }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var2 = var1.getDayOfMonth();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var5 = var1.isBefore(var4);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var8 = var7.getDescription();
//     java.lang.Comparable var9 = var7.getKey();
//     var7.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     java.lang.Object var19 = var13.clone();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, 10.0d);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(10, var21);
//     org.jfree.data.time.Year var26 = var25.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var28 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var25, (-1.0d));
//     java.util.Collection var29 = var7.getTimePeriodsUniqueToOtherSeries(var13);
//     var13.removeAgedItems(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var32 = var1.compareTo((java.lang.Object)true);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(31, 28, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     org.jfree.data.time.RegularTimePeriod var6 = var1.next();
//     java.util.Calendar var7 = null;
//     long var8 = var1.getFirstMillisecond(var7);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var2 = var1.getDayOfMonth();
//     int var3 = var1.getMonth();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(100);
//     var9.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addMonths(1, var9);
//     org.jfree.data.time.SerialDate var13 = var6.getEndOfCurrentMonth(var9);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(100);
//     var18.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addMonths(1, var18);
//     org.jfree.data.time.SerialDate var22 = var15.getEndOfCurrentMonth(var18);
//     org.jfree.data.time.SerialDate var23 = var13.getEndOfCurrentMonth(var18);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var18);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(100);
//     var27.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.addMonths(1, var27);
//     org.jfree.data.time.SerialDate var31 = var18.getEndOfCurrentMonth(var27);
//     org.jfree.data.time.SerialDate var32 = null;
//     boolean var34 = var1.isInRange(var31, var32, 100);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("20-December-2014");
//     java.lang.Throwable[] var2 = var1.getSuppressed();
//     org.jfree.data.general.SeriesException var4 = new org.jfree.data.general.SeriesException("hi!");
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     var1.addSuppressed((java.lang.Throwable)var4);
//     java.lang.Throwable var7 = null;
//     var4.addSuppressed(var7);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(100);
    var6.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(1, var6);
    org.jfree.data.time.SerialDate var10 = var3.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(100);
    var15.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.SerialDate var19 = var12.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var20 = var10.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays((-598), var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var3 = var2.getDescription();
    java.lang.Comparable var4 = var2.getKey();
    var2.setMaximumItemAge(1412146800000L);
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var8 = var2.getTimePeriodClass();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var8);
    java.lang.ClassLoader var10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var8);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.lang.Comparable var3 = var1.getKey();
    var1.setMaximumItemAge(1412146800000L);
    java.beans.PropertyChangeListener var6 = null;
    var1.removePropertyChangeListener(var6);
    org.jfree.data.general.SeriesChangeListener var8 = null;
    var1.addChangeListener(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var27);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var7 = var6.getDescription();
    java.lang.Comparable var8 = var6.getKey();
    org.jfree.data.time.TimeSeries var9 = var1.addAndOrUpdate(var6);
    org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var11 = var10.next();
    org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 10.0d);
    java.lang.Object var14 = var13.clone();
    java.lang.Object var15 = var13.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.add(var13, true);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)100+ "'", var8.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    java.beans.PropertyChangeListener var6 = null;
    var1.addPropertyChangeListener(var6);
    var1.setDescription("");
    var1.setDescription("Following");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var13 = var1.getDataItem(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var8);
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var11.setMaximumItemCount(0);
    int var14 = var11.getMaximumItemCount();
    java.util.Collection var15 = var1.getTimePeriodsUniqueToOtherSeries(var11);
    java.util.Collection var16 = org.jfree.chart.util.ObjectUtilities.deepClone(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Calendar var4 = null;
    long var5 = var3.getFirstMillisecond(var4);
    int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
    java.util.Date var7 = var3.getTime();
    java.util.TimeZone var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var9 = new org.jfree.data.time.Day(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var2);
//     int var5 = var4.getYear();
//     org.jfree.data.time.RegularTimePeriod var6 = var4.next();
//     java.util.Calendar var7 = null;
//     long var8 = var6.getMiddleMillisecond(var7);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var1.removeChangeListener(var31);
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var34.setMaximumItemCount(0);
//     var34.clear();
//     java.lang.String var38 = var34.getDomainDescription();
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     java.lang.String var41 = var40.toString();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month(1, var40);
//     boolean var43 = var34.equals((java.lang.Object)var40);
//     int var45 = var40.compareTo((java.lang.Object)(short)1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var40, (java.lang.Number)(byte)0, false);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "Time"+ "'", var38.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "2014"+ "'", var41.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("2014");

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("December", var1);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-598));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var2);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    java.lang.String var8 = var1.getDescription();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
    long var11 = var10.getLastMillisecond();
    long var12 = var10.getFirstMillisecond();
    org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var15 = var14.getDescription();
    java.lang.Comparable var16 = var14.getKey();
    var14.setMaximumItemAge(1412146800000L);
    boolean var19 = var10.equals((java.lang.Object)1412146800000L);
    java.util.Calendar var20 = null;
    long var21 = var10.getFirstMillisecond(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(short)1, true);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (byte)100+ "'", var16.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1L);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setKey((java.lang.Comparable)'4');
    org.jfree.data.time.RegularTimePeriod var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var8, 1.0d, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    int var4 = var1.toSerial();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
    org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
    boolean var16 = var1.isOnOrAfter(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var18 = var15.getPreviousDayOfWeek(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-598));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-453));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var0, var1);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var2);
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getLastMillisecond(var8);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 28, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     long var15 = var13.getSerialIndex();
//     int var16 = var13.getYearValue();
//     org.jfree.data.general.SeriesChangeEvent var17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var13);
//     java.util.Calendar var18 = null;
//     var13.peg(var18);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var33 = var27.previous();
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var35.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var38 = null;
//     var35.removeChangeListener(var38);
//     java.lang.Object var40 = var35.clone();
//     int var41 = var27.compareTo((java.lang.Object)var35);
//     java.util.Calendar var42 = null;
//     long var43 = var27.getFirstMillisecond(var42);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var33 = var27.previous();
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var35.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var38 = null;
//     var35.removeChangeListener(var38);
//     java.lang.Object var40 = var35.clone();
//     int var41 = var27.compareTo((java.lang.Object)var35);
//     org.jfree.data.time.TimeSeriesDataItem var42 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var35.add(var42, false);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-598));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     java.lang.String var7 = var1.getRangeDescription();
//     java.lang.String var8 = var1.getDescription();
//     org.jfree.data.time.TimeSeries var9 = null;
//     org.jfree.data.time.TimeSeries var10 = var1.addAndOrUpdate(var9);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     int var3 = var2.getMonth();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     boolean var4 = var2.equals((java.lang.Object)"January");
//     var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var7 = var2.next();
//     java.util.Calendar var8 = null;
//     var2.peg(var8);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getLastMillisecond();
//     long var8 = var6.getLastMillisecond();
//     long var9 = var6.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var6.previous();
//     java.util.Calendar var11 = null;
//     long var12 = var6.getFirstMillisecond(var11);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     var1.removeAgedItems(0L, true);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     var19.clear();
//     java.lang.String var23 = var19.getDomainDescription();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     java.lang.String var26 = var25.toString();
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(1, var25);
//     boolean var28 = var19.equals((java.lang.Object)var25);
//     int var30 = var25.compareTo((java.lang.Object)(short)1);
//     long var31 = var25.getLastMillisecond();
//     int var32 = var25.getYear();
//     java.lang.Number var33 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var25, var33, true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "Time"+ "'", var23.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "2014"+ "'", var26.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 2014);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var33 = var27.previous();
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var35.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var38 = null;
//     var35.removeChangeListener(var38);
//     java.lang.Object var40 = var35.clone();
//     int var41 = var27.compareTo((java.lang.Object)var35);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var35.delete(1, 9);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(31, 5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    long var3 = var1.getLastMillisecond();
    long var4 = var1.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var5 = var1.next();
    org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("October");

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    var1.removeAgedItems(2014L, false);
    var1.setMaximumItemAge(0L);
    java.util.List var9 = var1.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var10 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var9);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
//     java.lang.Class var5 = var4.getTimePeriodClass();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var8 = var7.getStart();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     java.util.TimeZone var10 = null;
//     org.jfree.data.time.RegularTimePeriod var11 = org.jfree.data.time.RegularTimePeriod.createInstance(var5, var8, var10);
//     java.util.TimeZone var12 = null;
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var8, var12);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var2 = var1.getDayOfMonth();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var5 = var1.isBefore(var4);
//     org.jfree.data.time.SerialDate var6 = null;
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     var10.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(1, var10);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(12, var10);
//     boolean var16 = var1.isInRange(var6, var14, 12);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var2 = var1.next();
    org.jfree.data.time.RegularTimePeriod var3 = var1.next();
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var5 = new org.jfree.data.time.Month((-453), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    int var4 = var1.toSerial();
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(12);
    int var7 = var6.getMonth();
    int var8 = var6.toSerial();
    boolean var9 = var1.isBefore((org.jfree.data.time.SerialDate)var6);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(100);
    java.lang.String var13 = var12.getDescription();
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(28, var12);
    boolean var15 = var6.isAfter(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var17 = var14.getNearestDayOfWeek(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     int var3 = var2.getMonth();
//     long var4 = var2.getLastMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Year var5 = var2.getYear();
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-62133062400001L));
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(1, var1);
//     org.jfree.data.time.Year var4 = var3.getYear();
//     long var5 = var3.getLastMillisecond();
//     java.lang.String var6 = var3.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2014"+ "'", var2.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1391241599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "January 2014"+ "'", var6.equals("January 2014"));
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var6 = var5.next();
    org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
    org.jfree.data.time.RegularTimePeriod var10 = var5.next();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
    var1.setDescription("ERROR : Relative To String");
    java.lang.Comparable var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setKey(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     java.util.Calendar var6 = null;
//     long var7 = var5.getLastMillisecond(var6);
// 
//   }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(1, var1);
//     org.jfree.data.time.Year var4 = var3.getYear();
//     long var5 = var3.getLastMillisecond();
//     java.util.Calendar var6 = null;
//     long var7 = var3.getLastMillisecond(var6);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    java.lang.Comparable var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
    int var2 = var1.getDayOfMonth();
    int var3 = var1.getMonth();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var5.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var8 = null;
    var5.removeChangeListener(var8);
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var12 = var11.getDescription();
    java.lang.Comparable var13 = var11.getKey();
    var11.setMaximumItemAge(1412146800000L);
    java.lang.String var16 = var11.getDescription();
    java.util.Collection var17 = var5.getTimePeriodsUniqueToOtherSeries(var11);
    org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var20 = var19.getStart();
    org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var20);
    var5.setKey((java.lang.Comparable)var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var23 = var1.compareTo((java.lang.Object)var5);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (byte)100+ "'", var13.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.util.Calendar var4 = null;
//     var3.peg(var4);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getSerialIndex();
//     long var2 = var0.getLastMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    var7.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
    org.jfree.data.time.SerialDate var11 = var4.getEndOfCurrentMonth(var7);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(100);
    var16.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addMonths(1, var16);
    org.jfree.data.time.SerialDate var20 = var13.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var21 = var11.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var16);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addMonths(9, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-570), var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
    org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var8.setMaximumItemCount(0);
    int var11 = var5.compareTo((java.lang.Object)var8);
    java.lang.Number var12 = var5.getValue();
    org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
    boolean var15 = var5.equals((java.lang.Object)var14);
    boolean var16 = var1.equals((java.lang.Object)var14);
    org.jfree.data.time.TimePeriodFormatException var18 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:00 PST 1969");
    var14.addSuppressed((java.lang.Throwable)var18);
    org.jfree.data.time.TimePeriodFormatException var21 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
    org.jfree.data.general.SeriesException var23 = new org.jfree.data.general.SeriesException("hi!");
    java.lang.Throwable[] var24 = var23.getSuppressed();
    var21.addSuppressed((java.lang.Throwable)var23);
    var18.addSuppressed((java.lang.Throwable)var21);
    java.lang.String var27 = var18.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969"+ "'", var27.equals("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969"));

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.previous();
//     long var8 = var6.getSerialIndex();
//     java.util.Calendar var9 = null;
//     long var10 = var6.getFirstMillisecond(var9);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
    boolean var4 = var2.equals((java.lang.Object)"January");
    var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
    boolean var7 = var1.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var10 = var1.createCopy((-598), 20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    var1.removeAgedItems(2014L, false);
    var1.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var10 = var1.createCopy(1, (-598));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    var1.setDescription("org.jfree.data.general.SeriesException: January");
    var1.setDescription("hi!");
    org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = var1.getNearestDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
//     java.util.Date var4 = var3.getEnd();
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var4, var5);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.RegularTimePeriod var2 = var0.next();
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
    var3.setNotify(true);
    org.jfree.data.time.RegularTimePeriod var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var7 = var3.getDataItem(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Wed Dec 31 16:00:00 PST 1969");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "hi!", "ThreadContext", var11);
//     var12.fireSeriesChanged();
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var15.setMaximumItemCount(0);
//     int var18 = var15.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var19 = null;
//     var15.removeChangeListener(var19);
//     var15.clear();
//     java.util.Collection var22 = var12.getTimePeriodsUniqueToOtherSeries(var15);
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     java.lang.String var26 = var25.toString();
//     int var28 = var25.compareTo((java.lang.Object)"2014");
//     int var29 = var24.getIndex((org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     java.lang.String var35 = var34.toString();
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month(1, var34);
//     java.lang.Number var37 = var24.getValue((org.jfree.data.time.RegularTimePeriod)var36);
//     boolean var38 = var24.getNotify();
//     boolean var39 = var24.isEmpty();
//     org.jfree.data.time.Month var40 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var40, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var43 = var42.getPeriod();
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var45.setMaximumItemCount(0);
//     int var48 = var42.compareTo((java.lang.Object)var45);
//     org.jfree.data.time.TimeSeries var49 = var24.addAndOrUpdate(var45);
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var50, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var55 = var49.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var50, 1.0d);
//     org.jfree.data.time.TimeSeries var56 = var12.addAndOrUpdate(var49);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var58 = var12.getDataItem(28);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "2014"+ "'", var35.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + (-1)+ "'", var37.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.util.List var3 = var1.getItems();
    var1.setMaximumItemAge(2014L);
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(10L);
    org.jfree.data.time.RegularTimePeriod var8 = var7.previous();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
    int var11 = var7.compareTo((java.lang.Object)10L);
    org.jfree.data.time.RegularTimePeriod var12 = var7.previous();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var12, (java.lang.Number)2014L);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
    int var2 = var1.getDayOfMonth();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    var7.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
    org.jfree.data.time.SerialDate var11 = var4.getEndOfCurrentMonth(var7);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(100);
    var16.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addMonths(1, var16);
    org.jfree.data.time.SerialDate var20 = var13.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var21 = var11.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(100);
    var26.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addMonths(1, var26);
    org.jfree.data.time.SerialDate var30 = var23.getEndOfCurrentMonth(var26);
    org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var34 = var33.getStart();
    org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(var34);
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(var34);
    org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addYears(0, var36);
    org.jfree.data.time.SerialDate var39 = var37.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var40 = var30.getEndOfCurrentMonth(var39);
    boolean var42 = var1.isInRange(var21, var30, (-453));
    java.lang.String var43 = var21.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.time.TimePeriodFormatException: ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var6 = var5.getDescription();
    java.lang.Comparable var7 = var5.getKey();
    var5.setMaximumItemAge(1412146800000L);
    java.lang.String var10 = var5.getDescription();
    java.lang.Class var11 = var5.getTimePeriodClass();
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var11);
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", var11);
    java.io.InputStream var14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("December 2014", var11);
    org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var17 = var16.getDescription();
    java.lang.Comparable var18 = var16.getKey();
    var16.setMaximumItemAge(1412146800000L);
    java.lang.String var21 = var16.getDescription();
    java.lang.Class var22 = var16.getTimePeriodClass();
    java.util.Date var23 = null;
    java.util.TimeZone var24 = null;
    org.jfree.data.time.RegularTimePeriod var25 = org.jfree.data.time.RegularTimePeriod.createInstance(var22, var23, var24);
    java.lang.ClassLoader var26 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var22);
    java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=January 2014]", var11, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)100+ "'", var7.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (byte)100+ "'", var18.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-453));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(2014, 0, 1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    java.beans.PropertyChangeListener var6 = null;
    var1.addPropertyChangeListener(var6);
    var1.setDescription("");
    var1.setDescription("Following");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var13 = var1.getTimePeriod(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    int var4 = var1.toSerial();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
    org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
    boolean var16 = var1.isOnOrAfter(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var18 = var15.getPreviousDayOfWeek(12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var7 = var6.getDescription();
    java.lang.Comparable var8 = var6.getKey();
    org.jfree.data.time.TimeSeries var9 = var1.addAndOrUpdate(var6);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
    long var12 = var11.getLastMillisecond();
    long var13 = var11.getLastMillisecond();
    long var14 = var11.getLastMillisecond();
    java.util.Date var15 = var11.getTime();
    org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.add((org.jfree.data.time.RegularTimePeriod)var16, 100.0d);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)100+ "'", var8.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Calendar var2 = null;
    var1.peg(var2);
    java.util.Calendar var4 = null;
    long var5 = var1.getFirstMillisecond(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10L);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var5 = var4.getPeriod();
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var7.setMaximumItemCount(0);
//     int var10 = var4.compareTo((java.lang.Object)var7);
//     java.lang.Number var11 = var4.getValue();
//     java.lang.Number var12 = var4.getValue();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     java.lang.String var14 = var13.toString();
//     boolean var15 = var4.equals((java.lang.Object)var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var4);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + 0.0d+ "'", var11.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "2014"+ "'", var14.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var1);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var5 = null;
//     var4.peg(var5);
//     long var7 = var4.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var4.previous();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate(var8, 0.0d);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 0.0d);
//     int var15 = var13.compareTo((java.lang.Object)(-62167363200000L));
//     var13.setValue((java.lang.Number)(-1.0f));
//     var2.add(var13);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    java.util.Calendar var3 = null;
    var1.peg(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getMiddleMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var1.getFirstMillisecond(var7);
    java.util.Date var9 = var1.getTime();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var9);
    java.util.TimeZone var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var9, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var3.delete(4, (-570));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1418759999999L);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100);
    java.lang.String var4 = var3.getDescription();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addMonths(28, var3);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addYears(2014, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("January 0");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     int var33 = var27.getYear();
//     java.lang.String var34 = var27.toString();
//     long var35 = var27.getLastMillisecond();
//     java.util.Calendar var36 = null;
//     long var37 = var27.getFirstMillisecond(var36);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     java.beans.PropertyChangeListener var6 = null;
//     var1.removePropertyChangeListener(var6);
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.String var11 = var10.toString();
//     int var13 = var10.compareTo((java.lang.Object)"2014");
//     int var14 = var9.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     java.lang.Object var15 = var9.clone();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 10.0d);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(10, var17);
//     org.jfree.data.time.Year var22 = var21.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)(short)(-1), true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "March"+ "'", var1.equals("March"));

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var26 = var25.getLastMillisecond();
//     java.util.Calendar var27 = null;
//     var25.peg(var27);
//     java.util.Calendar var29 = null;
//     long var30 = var25.getMiddleMillisecond(var29);
//     java.util.Calendar var31 = null;
//     long var32 = var25.getFirstMillisecond(var31);
//     java.util.Date var33 = var25.getTime();
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(var33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var34, 0.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.util.List var3 = var1.getItems();
    java.lang.String var4 = var1.getRangeDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Value"+ "'", var4.equals("Value"));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
    int var3 = var2.getMonth();
    int var5 = var2.compareTo((java.lang.Object)100L);
    int var6 = var2.getMonth();
    org.jfree.data.time.RegularTimePeriod var7 = var2.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var1);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-453));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     java.lang.String var5 = var1.getDescription();
//     boolean var6 = var1.getNotify();
//     org.jfree.data.time.TimeSeries var7 = null;
//     java.util.Collection var8 = var1.getTimePeriodsUniqueToOtherSeries(var7);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     long var3 = var1.getLastMillisecond();
//     long var4 = var1.getLastMillisecond();
//     java.util.Date var5 = var1.getTime();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var15 = var12.createCopy(0, 0);
//     java.lang.Class var16 = var15.getTimePeriodClass();
//     java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var10, var16);
//     java.io.InputStream var18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var16);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, "30-April-1900", "December", var16);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var5);
//     int var21 = var20.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1969);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Sunday");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.Object var7 = var1.clone();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 10.0d);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(10, var9);
//     org.jfree.data.time.Year var14 = var13.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var18 = var1.getTimePeriod((-457));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("January 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     int var31 = var1.getItemCount();
//     java.util.List var32 = var1.getItems();
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     java.lang.String var36 = var35.toString();
//     int var38 = var35.compareTo((java.lang.Object)"2014");
//     int var39 = var34.getIndex((org.jfree.data.time.RegularTimePeriod)var35);
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (-1.0d));
//     int var42 = var35.getMonth();
//     int var43 = var35.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var44 = var35.next();
//     long var45 = var44.getMiddleMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update(var44, (java.lang.Number)2014);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "20-December-2014"+ "'", var36.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1419191999999L);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.String var7 = var2.toString();
//     int var8 = var2.getMonth();
//     long var9 = var2.getSerialIndex();
//     java.util.Calendar var10 = null;
//     long var11 = var2.getMiddleMillisecond(var10);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.fireSeriesChanged();
    boolean var5 = var1.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var7 = var1.getDataItem(1969);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var2);
    org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2);
    org.jfree.data.time.SerialDate var6 = var5.getSerialDate();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(10L);
    int var5 = var1.compareTo((java.lang.Object)10L);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    var7.setDescription("org.jfree.data.general.SeriesException: January");
    var7.setDescription("hi!");
    org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var7);
    int var13 = var1.compareTo((java.lang.Object)var7);
    long var14 = var1.getSerialIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 10L);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(var5);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var5);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(0, var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(0, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-41893), var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var8 = var7.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
//     boolean var16 = var1.isOnOrAfter(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var18 = var1.getYYYY();
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getEnd();
//     int var22 = var19.getDayOfMonth();
//     java.lang.String var23 = var19.toString();
//     org.jfree.data.time.SerialDate var24 = var19.getSerialDate();
//     long var25 = var19.getFirstMillisecond();
//     long var26 = var19.getFirstMillisecond();
//     boolean var27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "20-December-2014"+ "'", var23.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     java.lang.String var34 = var33.toString();
//     int var36 = var33.compareTo((java.lang.Object)"2014");
//     int var37 = var32.getIndex((org.jfree.data.time.RegularTimePeriod)var33);
//     org.jfree.data.time.TimeSeriesDataItem var39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, (-1.0d));
//     int var40 = var33.getMonth();
//     int var41 = var33.getDayOfMonth();
//     java.lang.String var42 = var33.toString();
//     org.jfree.data.time.RegularTimePeriod var43 = var33.next();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var30.add((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)(-57600000L));
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var34 + "' != '" + "20-December-2014"+ "'", var34.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "20-December-2014"+ "'", var42.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var5.setMaximumItemCount(0);
    int var8 = var2.compareTo((java.lang.Object)var5);
    java.lang.Number var9 = var2.getValue();
    java.lang.Object var10 = var2.clone();
    java.lang.Object var11 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0.0d+ "'", var9.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     java.lang.Object var31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var30.add((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)0);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: Following");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     int var7 = var2.getYear();
//     int var8 = var2.getMonth();
//     org.jfree.data.time.SerialDate var9 = var2.getSerialDate();
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var11.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var11.addChangeListener(var14);
//     long var16 = var11.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var18.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var21 = null;
//     var18.removeChangeListener(var21);
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var25 = var24.getDescription();
//     java.lang.Comparable var26 = var24.getKey();
//     var24.setMaximumItemAge(1412146800000L);
//     java.lang.String var29 = var24.getDescription();
//     java.util.Collection var30 = var18.getTimePeriodsUniqueToOtherSeries(var24);
//     var24.setDomainDescription("ThreadContext");
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var35 = var34.getLastMillisecond();
//     long var36 = var34.getLastMillisecond();
//     long var37 = var34.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var38 = var34.previous();
//     org.jfree.data.time.TimeSeriesDataItem var40 = var24.addOrUpdate(var38, (java.lang.Number)1.0d);
//     var11.setKey((java.lang.Comparable)var38);
//     int var42 = var2.compareTo((java.lang.Object)var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (byte)100+ "'", var26.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     int var3 = var0.compareTo((java.lang.Object)"2014");
//     int var4 = var0.getMonth();
//     java.util.Calendar var5 = null;
//     var0.peg(var5);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     boolean var3 = var1.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var4 = var1.next();
//     long var5 = var1.getLastMillisecond();
//     int var6 = var1.getDayOfMonth();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var9 = var8.next();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 10.0d);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(10, var8);
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     java.lang.String var15 = var12.toString();
//     org.jfree.data.time.Year var16 = var12.getYear();
//     boolean var17 = var1.equals((java.lang.Object)var16);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(9, var16);
//     java.util.Calendar var19 = null;
//     var18.peg(var19);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     boolean var4 = var2.equals((java.lang.Object)"January");
//     var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
//     boolean var7 = var1.getNotify();
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 10.0d);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var10);
//     org.jfree.data.time.Year var15 = var14.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.previous();
//     long var17 = var15.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     java.util.Calendar var20 = null;
//     var15.peg(var20);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     java.lang.String var18 = var17.toString();
//     int var20 = var17.compareTo((java.lang.Object)"2014");
//     int var21 = var16.getIndex((org.jfree.data.time.RegularTimePeriod)var17);
//     int var22 = var17.getYear();
//     int var23 = var17.getMonth();
//     org.jfree.data.time.SerialDate var24 = var17.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var17, (-1.0d), true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var8 = var7.getDescription();
    java.lang.Comparable var9 = var7.getKey();
    var7.setMaximumItemAge(1412146800000L);
    java.lang.String var12 = var7.getDescription();
    java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
    var7.setDomainDescription("ThreadContext");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setMaximumItemAge((-57600000L));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), 1969);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getPreviousDayOfWeek(1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("31-December-1969");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var26 = var25.getDescription();
//     java.util.List var27 = var25.getItems();
//     var25.setMaximumItemAge(2014L);
//     java.util.Collection var30 = var7.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeriesDataItem var35 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1.0d);
//     java.util.Calendar var36 = null;
//     long var37 = var33.getFirstMillisecond(var36);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
    java.lang.String var4 = var3.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     var1.clear();
//     java.lang.String var11 = var1.getRangeDescription();
//     java.lang.Comparable var12 = var1.getKey();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var15 = var14.getTime();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.Year var20 = var17.getYear();
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, 0.0d);
//     org.jfree.data.time.Year var24 = var21.getYear();
//     int var25 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.RegularTimePeriod var26 = var21.next();
//     var1.delete(var26);
//     java.lang.String var28 = var26.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Value"+ "'", var11.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + (byte)100+ "'", var12.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "January 2015"+ "'", var28.equals("January 2015"));
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setKey((java.lang.Comparable)'4');
    boolean var8 = var1.getNotify();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var11 = var10.getTime();
    java.util.Calendar var12 = null;
    long var13 = var10.getFirstMillisecond(var12);
    var1.setKey((java.lang.Comparable)var10);
    var1.setNotify(true);
    var1.removeAgedItems(false);
    var1.setRangeDescription("Following");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update((-570), (java.lang.Number)4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10L);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     boolean var24 = var1.isEmpty();
//     java.lang.Class var25 = var1.getTimePeriodClass();
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var28 = var27.getStart();
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(var28);
//     java.util.TimeZone var30 = null;
//     org.jfree.data.time.RegularTimePeriod var31 = org.jfree.data.time.RegularTimePeriod.createInstance(var25, var28, var30);
//     java.util.TimeZone var32 = null;
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month(var28, var32);
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var5.setMaximumItemCount((-570));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setKey((java.lang.Comparable)'4');
    boolean var8 = var1.getNotify();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var11 = var10.getTime();
    java.util.Calendar var12 = null;
    long var13 = var10.getFirstMillisecond(var12);
    var1.setKey((java.lang.Comparable)var10);
    var1.setNotify(true);
    var1.removeAgedItems(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var21 = var1.createCopy(12, (-598));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10L);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var32 = var1.getValue((-457));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(100);
    var5.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    org.jfree.data.time.SerialDate var9 = var2.getEndOfCurrentMonth(var5);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(100);
    var14.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addMonths(1, var14);
    org.jfree.data.time.SerialDate var18 = var11.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var19 = var9.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var22 = var14.getFollowingDayOfWeek(1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     var1.setKey((java.lang.Comparable)'4');
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.lang.String var21 = var20.toString();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(1, var20);
//     java.lang.Number var23 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var22);
//     boolean var24 = var10.getNotify();
//     boolean var25 = var10.isEmpty();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var29 = var28.getPeriod();
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var31.setMaximumItemCount(0);
//     int var34 = var28.compareTo((java.lang.Object)var31);
//     org.jfree.data.time.TimeSeries var35 = var10.addAndOrUpdate(var31);
//     var10.setDomainDescription("hi!");
//     org.jfree.data.time.TimeSeries var38 = var1.addAndOrUpdate(var10);
//     java.lang.Object var39 = var1.clone();
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     java.lang.String var43 = var42.toString();
//     int var45 = var42.compareTo((java.lang.Object)"2014");
//     int var46 = var41.getIndex((org.jfree.data.time.RegularTimePeriod)var42);
//     org.jfree.data.time.TimeSeriesDataItem var48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var42, (-1.0d));
//     int var49 = var42.getMonth();
//     int var50 = var42.getDayOfMonth();
//     int var51 = var42.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var42, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var53);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "2014"+ "'", var21.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "20-December-2014"+ "'", var43.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 20);
// 
//   }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.RegularTimePeriod var31 = var23.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(100);
    var8.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(1, var8);
    var8.setDescription("");
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addDays(12, var8);
    java.lang.String var15 = var14.getDescription();
    boolean var16 = var2.isOn(var14);
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(100);
    int var19 = var18.getDayOfMonth();
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(100);
    var24.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addMonths(1, var24);
    org.jfree.data.time.SerialDate var28 = var21.getEndOfCurrentMonth(var24);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(100);
    var33.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.addMonths(1, var33);
    org.jfree.data.time.SerialDate var37 = var30.getEndOfCurrentMonth(var33);
    org.jfree.data.time.SerialDate var38 = var28.getEndOfCurrentMonth(var33);
    org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(100);
    var43.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addMonths(1, var43);
    org.jfree.data.time.SerialDate var47 = var40.getEndOfCurrentMonth(var43);
    org.jfree.data.time.FixedMillisecond var50 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var51 = var50.getStart();
    org.jfree.data.time.FixedMillisecond var52 = new org.jfree.data.time.FixedMillisecond(var51);
    org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var51);
    org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addYears(0, var53);
    org.jfree.data.time.SerialDate var56 = var54.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var57 = var47.getEndOfCurrentMonth(var56);
    boolean var59 = var18.isInRange(var38, var47, (-453));
    int var60 = var18.getDayOfWeek();
    boolean var61 = var2.isAfter((org.jfree.data.time.SerialDate)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var8);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var12 = null;
//     var11.peg(var12);
//     long var14 = var11.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var15 = var11.previous();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var9.addOrUpdate(var15, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var15, (java.lang.Number)0.0d, true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var2, var3);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("October 10");

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.getDayOfWeek();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.RegularTimePeriod var7 = var5.next();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
//     var8.setNotify(true);
//     boolean var11 = var1.equals((java.lang.Object)true);
//     org.jfree.data.time.SerialDate var12 = null;
//     boolean var13 = var1.isOn(var12);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var3 = var2.getStart();
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var3);
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var3);
    org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, 10.0d);
    org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(100);
    int var12 = var11.getDayOfMonth();
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(31);
    boolean var15 = var11.isBefore(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var14);
    int var17 = var8.compareTo((java.lang.Object)var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addYears((-1), var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     int var3 = var0.getDayOfMonth();
//     java.lang.String var4 = var0.toString();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getFirstMillisecond(var5);
// 
//   }

}
