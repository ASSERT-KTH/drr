
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("30-April-1900");

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    int var4 = var2.compareTo((java.lang.Object)(-62167363200000L));
    var2.setValue((java.lang.Number)(-1.0f));
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var9 = var8.getStart();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(var9);
    org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 10.0d);
    java.lang.Object var15 = var14.clone();
    int var16 = var2.compareTo((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, var4);
//     org.jfree.data.general.SeriesChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     java.beans.PropertyChangeListener var8 = null;
//     var5.removePropertyChangeListener(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(1, var1);
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)1418759999999L);
//     java.util.Calendar var6 = null;
//     var3.peg(var6);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.beans.PropertyChangeListener var7 = null;
    var1.removePropertyChangeListener(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(3, (java.lang.Number)1420012800000L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.String var7 = var2.toString();
//     int var8 = var2.getMonth();
//     java.lang.String var9 = var2.toString();
//     java.util.Calendar var10 = null;
//     long var11 = var2.getMiddleMillisecond(var10);
// 
//   }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var5.getFirstMillisecond(var6);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     var1.setDomainDescription("20-December-2014");
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
//     var13.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var13);
//     org.jfree.data.time.SerialDate var17 = var10.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(var21);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var27 = var17.getEndOfCurrentMonth(var26);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day(var17);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var31 = var30.getTime();
//     java.util.Calendar var32 = null;
//     var30.peg(var32);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     boolean var36 = var34.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var37 = var34.next();
//     long var38 = var34.getLastMillisecond();
//     int var39 = var30.compareTo((java.lang.Object)var34);
//     java.lang.String var40 = var34.toString();
//     org.jfree.data.time.TimeSeries var41 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var28, (org.jfree.data.time.RegularTimePeriod)var34);
//     org.jfree.data.time.FixedMillisecond var43 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var44 = var43.getTime();
//     java.util.Calendar var45 = null;
//     var43.peg(var45);
//     java.util.Calendar var47 = null;
//     var43.peg(var47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var43, (java.lang.Number)(short)100, true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "20-December-2014"+ "'", var40.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var26 = var25.getDescription();
//     java.util.List var27 = var25.getItems();
//     var25.setMaximumItemAge(2014L);
//     java.util.Collection var30 = var7.getTimePeriodsUniqueToOtherSeries(var25);
//     java.lang.String var31 = var7.getDomainDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.update(31, (java.lang.Number)1419062400000L);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "Time"+ "'", var31.equals("Time"));
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var30 = var29.getTime();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(var30);
//     int var32 = var25.compareTo((java.lang.Object)var30);
//     org.jfree.data.general.SeriesChangeEvent var33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var25);
//     java.lang.String var34 = var33.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var34 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=January 2014]"+ "'", var34.equals("org.jfree.data.general.SeriesChangeEvent[source=January 2014]"));
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: Following");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     boolean var3 = var1.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var4 = var1.next();
//     long var5 = var1.getLastMillisecond();
//     int var6 = var1.getDayOfMonth();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var9 = var8.next();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 10.0d);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(10, var8);
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     java.lang.String var15 = var12.toString();
//     org.jfree.data.time.Year var16 = var12.getYear();
//     boolean var17 = var1.equals((java.lang.Object)var16);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(9, var16);
//     long var19 = var18.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "October 2014"+ "'", var15.equals("October 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1412146799999L);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
//     long var4 = var1.getLastMillisecond();
//     org.jfree.data.time.Year var5 = var1.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(0, var5);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var3 = var2.getDayOfMonth();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var6 = var2.isBefore(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var2);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     boolean var10 = var8.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var11 = var8.next();
//     long var12 = var8.getLastMillisecond();
//     java.lang.String var13 = var8.toString();
//     org.jfree.data.time.SerialDate var14 = var8.getSerialDate();
//     boolean var15 = var2.isOn(var14);
//     org.jfree.data.time.SerialDate var16 = null;
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(100);
//     var20.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addMonths(1, var20);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(12, var20);
//     java.lang.String var25 = var24.getDescription();
//     boolean var27 = var2.isInRange(var16, var24, 10);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    var4.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
    var4.setDescription("");
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addDays(12, var4);
    org.jfree.data.time.SerialDate var12 = var4.getPreviousDayOfWeek(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(20, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     var1.clear();
//     java.lang.String var11 = var1.getRangeDescription();
//     java.lang.Comparable var12 = var1.getKey();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var15 = var14.getTime();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     java.util.Collection var17 = var1.getTimePeriods();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     java.lang.String var19 = var18.toString();
//     java.util.Date var20 = var18.getEnd();
//     int var21 = var18.getDayOfMonth();
//     java.lang.String var22 = var18.toString();
//     var1.setKey((java.lang.Comparable)var18);
//     java.beans.PropertyChangeListener var24 = null;
//     var1.removePropertyChangeListener(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Value"+ "'", var11.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + (byte)100+ "'", var12.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "20-December-2014"+ "'", var22.equals("20-December-2014"));
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    long var3 = var1.getFirstMillisecond();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var6 = var5.getDescription();
    java.lang.Comparable var7 = var5.getKey();
    var5.setMaximumItemAge(1412146800000L);
    boolean var10 = var1.equals((java.lang.Object)1412146800000L);
    java.util.Calendar var11 = null;
    long var12 = var1.getLastMillisecond(var11);
    long var13 = var1.getMiddleMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)100+ "'", var7.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     java.lang.String var27 = var26.toString();
//     int var29 = var26.compareTo((java.lang.Object)"2014");
//     int var30 = var25.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     int var31 = var26.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var34 = var1.getValue(12);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "20-December-2014"+ "'", var27.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(var5);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var5);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(0, var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(0, var7);
    org.jfree.data.time.Day var10 = new org.jfree.data.time.Day(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1900, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var1);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var5 = null;
//     var4.peg(var5);
//     long var7 = var4.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var4.previous();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate(var8, 0.0d);
//     java.lang.String var11 = var2.getDomainDescription();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "hi!", "ThreadContext", var23);
//     var24.setMaximumItemAge(1420099199999L);
//     java.util.Collection var27 = var2.getTimePeriodsUniqueToOtherSeries(var24);
//     boolean var28 = var2.isEmpty();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Time"+ "'", var11.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var2);
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2, var4);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     var1.clear();
//     java.lang.String var11 = var1.getRangeDescription();
//     java.lang.Comparable var12 = var1.getKey();
//     java.lang.Comparable var13 = var1.getKey();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var16 = var15.getLastMillisecond();
//     long var17 = var15.getLastMillisecond();
//     long var18 = var15.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem(var19, (java.lang.Number)100.0f);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update(var19, (java.lang.Number)41993L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Value"+ "'", var11.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + (byte)100+ "'", var12.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + (byte)100+ "'", var13.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     long var6 = var5.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var11 = var8.createCopy(0, 0);
//     java.lang.Class var12 = var11.getTimePeriodClass();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var15 = var14.getStart();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     java.util.TimeZone var17 = null;
//     org.jfree.data.time.RegularTimePeriod var18 = org.jfree.data.time.RegularTimePeriod.createInstance(var12, var15, var17);
//     boolean var19 = var5.equals((java.lang.Object)var12);
//     java.util.Calendar var20 = null;
//     long var21 = var5.getFirstMillisecond(var20);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("October 10");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(20, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var2.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var2.addChangeListener(var5);
//     var2.setKey((java.lang.Comparable)'4');
//     boolean var9 = var2.getNotify();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var12 = var11.getTime();
//     java.util.Calendar var13 = null;
//     long var14 = var11.getFirstMillisecond(var13);
//     var2.setKey((java.lang.Comparable)var11);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 10.0d);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(10, var17);
//     org.jfree.data.time.RegularTimePeriod var22 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var17);
//     long var24 = var17.getFirstMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(28, var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1388563200000L);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    var1.removeAgedItems(2014L, false);
    var1.setDescription("January 2014");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var1.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    var1.removeAgedItems(2014L, false);
    var1.setMaximumItemAge(0L);
    java.util.List var9 = var1.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var1.getValue(20);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Calendar var2 = null;
    var1.peg(var2);
    long var4 = var1.getSerialIndex();
    org.jfree.data.time.RegularTimePeriod var5 = var1.previous();
    java.util.Calendar var6 = null;
    var1.peg(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var1.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var8);
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var11.setMaximumItemCount(0);
    int var14 = var11.getMaximumItemCount();
    java.util.Collection var15 = var1.getTimePeriodsUniqueToOtherSeries(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var17 = var1.getValue((-41893));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     java.lang.Object var4 = null;
//     int var5 = var0.compareTo(var4);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     java.lang.String var7 = var6.toString();
//     java.util.Date var8 = var6.getEnd();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day(var8);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var8);
//     boolean var12 = org.jfree.chart.util.ObjectUtilities.equal(var4, (java.lang.Object)var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     int var3 = var0.getDayOfMonth();
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.general.SeriesChangeEvent var6 = new org.jfree.data.general.SeriesChangeEvent(var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     int var2 = var0.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     var1.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     var1.add(var17, true);
//     var1.removeAgedItems((-57600000L), false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.delete(0, (-457));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var2);
//     java.util.Calendar var5 = null;
//     long var6 = var4.getLastMillisecond(var5);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var3 = var2.toString();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getLastMillisecond(var4);
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     int var3 = var0.getDayOfMonth();
//     java.lang.String var4 = var0.toString();
//     java.util.Calendar var5 = null;
//     var0.peg(var5);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(100);
    var5.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    org.jfree.data.time.SerialDate var9 = var2.getEndOfCurrentMonth(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-41893), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.previous();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7, var8);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var11.setMaximumItemCount(0);
//     var11.clear();
//     java.lang.String var15 = var11.getDomainDescription();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     java.lang.String var18 = var17.toString();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(1, var17);
//     boolean var20 = var11.equals((java.lang.Object)var17);
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var22.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var26 = null;
//     var22.removeChangeListener(var26);
//     java.beans.PropertyChangeListener var28 = null;
//     var22.removePropertyChangeListener(var28);
//     boolean var30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)var22);
//     org.jfree.data.time.RegularTimePeriod var31 = var17.next();
//     var9.add(var31, (-1.0d), true);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var33 = var27.previous();
//     java.util.Calendar var34 = null;
//     long var35 = var27.getFirstMillisecond(var34);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-88), 2014, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     java.lang.String var27 = var26.toString();
//     int var29 = var26.compareTo((java.lang.Object)"2014");
//     int var30 = var25.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     int var31 = var26.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var26);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var35 = var34.getLastMillisecond();
//     long var36 = var34.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var34.next();
//     org.jfree.data.time.TimeSeriesDataItem var38 = var1.getDataItem(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "20-December-2014"+ "'", var27.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     int var3 = var0.getDayOfMonth();
//     java.lang.String var4 = var0.toString();
//     long var5 = var0.getLastMillisecond();
//     long var6 = var0.getFirstMillisecond();
//     int var7 = var0.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "20-December-2014"+ "'", var4.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 20);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var26 = var25.getDescription();
//     java.util.List var27 = var25.getItems();
//     var25.setMaximumItemAge(2014L);
//     java.util.Collection var30 = var7.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, 10.0d);
//     java.lang.Object var35 = var34.clone();
//     boolean var36 = var25.equals((java.lang.Object)var34);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var39 = var25.createCopy(2014, (-598));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Nearest"+ "'", var1.equals("Nearest"));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    int var5 = var2.toSerial();
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(12);
    int var8 = var7.getMonth();
    int var9 = var7.toSerial();
    boolean var10 = var2.isBefore((org.jfree.data.time.SerialDate)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1969, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     boolean var4 = var2.equals((java.lang.Object)"January");
//     var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
//     boolean var7 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var10 = var9.getStart();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var10);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, 0.0d);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.data.time.Year var21 = var20.getYear();
//     long var22 = var20.getFirstMillisecond();
//     var1.update((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)1388563200000L);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var27 = var26.getLastMillisecond();
//     long var28 = var26.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var31 = var30.getDescription();
//     java.lang.Comparable var32 = var30.getKey();
//     var30.setMaximumItemAge(1412146800000L);
//     boolean var35 = var26.equals((java.lang.Object)1412146800000L);
//     org.jfree.data.time.TimeSeriesDataItem var37 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, 1.0d);
//     java.util.Calendar var38 = null;
//     var26.peg(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + (byte)100+ "'", var32.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
    int var2 = var1.getDayOfMonth();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    var7.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
    org.jfree.data.time.SerialDate var11 = var4.getEndOfCurrentMonth(var7);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(100);
    var16.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addMonths(1, var16);
    org.jfree.data.time.SerialDate var20 = var13.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var21 = var11.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(100);
    var26.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addMonths(1, var26);
    org.jfree.data.time.SerialDate var30 = var23.getEndOfCurrentMonth(var26);
    org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var34 = var33.getStart();
    org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(var34);
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(var34);
    org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addYears(0, var36);
    org.jfree.data.time.SerialDate var39 = var37.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var40 = var30.getEndOfCurrentMonth(var39);
    boolean var42 = var1.isInRange(var21, var30, (-453));
    org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var47 = var46.getStart();
    org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond(var47);
    org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.createInstance(var47);
    org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.addYears(0, var49);
    org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addYears(0, var49);
    boolean var52 = var1.isAfter(var49);
    org.jfree.data.time.SpreadsheetDate var54 = new org.jfree.data.time.SpreadsheetDate(12);
    int var55 = var54.getMonth();
    int var56 = var54.toSerial();
    org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.createInstance(100);
    var60.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.addMonths(1, var60);
    var60.setDescription("");
    org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.addDays(12, var60);
    java.lang.String var67 = var66.getDescription();
    boolean var68 = var54.isOn(var66);
    boolean var69 = var1.isOn((org.jfree.data.time.SerialDate)var54);
    int var70 = var1.getYYYY();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1900);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.util.Calendar var3 = null;
//     var1.peg(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var7 = var5.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var8 = var5.next();
//     long var9 = var5.getLastMillisecond();
//     int var10 = var1.compareTo((java.lang.Object)var5);
//     long var11 = var1.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var12 = var1.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 100);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setMaximumItemCount(0);
//     int var11 = var5.compareTo((java.lang.Object)var8);
//     java.lang.Number var12 = var5.getValue();
//     org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
//     boolean var15 = var5.equals((java.lang.Object)var14);
//     int var16 = var2.compareTo((java.lang.Object)var5);
//     long var17 = var2.getFirstMillisecond();
//     java.lang.Object var18 = null;
//     boolean var19 = var2.equals(var18);
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var21.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var24 = null;
//     var21.addChangeListener(var24);
//     long var26 = var21.getMaximumItemAge();
//     boolean var27 = var2.equals((java.lang.Object)var26);
//     java.util.Calendar var28 = null;
//     long var29 = var2.getFirstMillisecond(var28);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    long var3 = var1.getFirstMillisecond();
    java.util.Date var4 = var1.getEnd();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-41893), (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    java.lang.String var3 = var2.getDescription();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.addMonths(28, var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = var2.getNearestDayOfWeek((-88));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     var1.clear();
//     org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     long var13 = var12.getMiddleMillisecond();
//     int var14 = var12.getYearValue();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)10.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2014);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-41893), 0, (-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     var1.clear();
//     org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
//     java.lang.Object var12 = var11.getSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var7 = var6.getMonth();
//     int var8 = var6.toSerial();
//     boolean var9 = var1.isBefore((org.jfree.data.time.SerialDate)var6);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(100);
//     java.lang.String var13 = var12.getDescription();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(28, var12);
//     boolean var15 = var6.isAfter(var14);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var6);
//     java.util.Calendar var17 = null;
//     long var18 = var16.getMiddleMillisecond(var17);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-41893));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(0, var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(0, var6);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day(var8);
//     long var10 = var9.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-57600000L));
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: ThreadContext");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-452));

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var26 = var25.getDescription();
//     java.util.List var27 = var25.getItems();
//     var25.setMaximumItemAge(2014L);
//     java.util.Collection var30 = var7.getTimePeriodsUniqueToOtherSeries(var25);
//     java.util.Collection var31 = org.jfree.chart.util.ObjectUtilities.deepClone(var30);
//     java.util.Collection var32 = org.jfree.chart.util.ObjectUtilities.deepClone(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     var1.clear();
//     java.lang.String var11 = var1.getRangeDescription();
//     java.lang.Comparable var12 = var1.getKey();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var15 = var14.getTime();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     java.util.Collection var17 = var1.getTimePeriods();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     java.lang.String var19 = var18.toString();
//     java.util.Date var20 = var18.getEnd();
//     int var21 = var18.getDayOfMonth();
//     java.lang.String var22 = var18.toString();
//     var1.setKey((java.lang.Comparable)var18);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var26 = var25.next();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 10.0d);
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(10, var25);
//     org.jfree.data.time.Year var30 = var29.getYear();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var31, (java.lang.Number)1419148799999L, false);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Value"+ "'", var11.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + (byte)100+ "'", var12.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "20-December-2014"+ "'", var22.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)1418759999999L);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "hi!", "ThreadContext", var11);
//     var12.fireSeriesChanged();
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var15.setMaximumItemCount(0);
//     int var18 = var15.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var19 = null;
//     var15.removeChangeListener(var19);
//     var15.clear();
//     java.util.Collection var22 = var12.getTimePeriodsUniqueToOtherSeries(var15);
//     org.jfree.data.time.TimeSeries var23 = null;
//     org.jfree.data.time.TimeSeries var24 = var12.addAndOrUpdate(var23);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     long var15 = var13.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1388563200000L);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-88));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.getYYYY();
    int var4 = var1.getDayOfWeek();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = var1.getNearestDayOfWeek(1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     int var4 = var0.getDayOfMonth();
//     int var5 = var0.getYear();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     var10.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(1, var10);
//     org.jfree.data.time.SerialDate var14 = var7.getEndOfCurrentMonth(var10);
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var18 = var17.getStart();
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(var18);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addYears(0, var20);
//     org.jfree.data.time.SerialDate var23 = var21.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var24 = var14.getEndOfCurrentMonth(var23);
//     int var25 = var0.compareTo((java.lang.Object)var23);
//     int var26 = var0.getYear();
//     java.lang.String var27 = var0.toString();
//     long var28 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "20-December-2014"+ "'", var27.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 41993L);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.util.Calendar var3 = null;
//     var1.peg(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var7 = var5.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var8 = var5.next();
//     long var9 = var5.getLastMillisecond();
//     int var10 = var1.compareTo((java.lang.Object)var5);
//     java.lang.Object var11 = null;
//     int var12 = var5.compareTo(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var5.getLastMillisecond(var13);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(5, 2014, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     java.lang.String var7 = var1.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var11.setMaximumItemCount(0);
//     int var14 = var11.getMaximumItemCount();
//     java.util.Collection var15 = var1.getTimePeriodsUniqueToOtherSeries(var11);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.String var17 = var16.toString();
//     java.util.Date var18 = var16.getEnd();
//     int var19 = var16.getDayOfMonth();
//     java.lang.String var20 = var16.toString();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1414825199999L);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, 0);
//     long var26 = var25.getFirstMillisecond();
//     int var27 = var25.getMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var25, 10.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "20-December-2014"+ "'", var17.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var8 = var7.getDayOfMonth();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var11 = var7.isBefore(var10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var7);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     boolean var15 = var13.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var16 = var13.next();
//     long var17 = var13.getLastMillisecond();
//     java.lang.String var18 = var13.toString();
//     org.jfree.data.time.SerialDate var19 = var13.getSerialDate();
//     boolean var20 = var7.isOn(var19);
//     boolean var21 = var1.isAfter(var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var23 = var19.getNearestDayOfWeek(9);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var7 = var6.getStart();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var7);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(0, var9);
    var10.setDescription("January 2014");
    boolean var13 = var2.equals((java.lang.Object)var10);
    java.lang.Object var14 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var3 = var2.getDescription();
    java.lang.Comparable var4 = var2.getKey();
    var2.setMaximumItemAge(1412146800000L);
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var8 = var2.getTimePeriodClass();
    java.util.Date var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.RegularTimePeriod var11 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var9, var10);
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("20-December-2014", var8);
    java.lang.ClassLoader var13 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var8);
    java.lang.ClassLoader var14 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("March");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-41893), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getFirstMillisecond(var2);
//     long var4 = var1.getFirstMillisecond();
//     long var5 = var1.getMiddleMillisecond();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     long var7 = var6.getSerialIndex();
//     int var8 = var1.compareTo((java.lang.Object)var6);
//     long var9 = var1.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 10L);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    java.beans.PropertyChangeListener var6 = null;
    var1.addPropertyChangeListener(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var1.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-41893));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
//     var4.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
//     org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
//     var13.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var13);
//     org.jfree.data.time.SerialDate var17 = var10.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.SerialDate var18 = var8.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var8);
//     java.lang.String var20 = var19.toString();
//     org.jfree.data.time.SerialDate var21 = var19.getSerialDate();
//     java.util.Calendar var22 = null;
//     long var23 = var19.getLastMillisecond(var22);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-457), (-88), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    int var5 = var2.toSerial();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var9 = var8.getStart();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(0, var11);
    org.jfree.data.time.SerialDate var14 = var12.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var16 = var12.getPreviousDayOfWeek(1);
    boolean var17 = var2.isOnOrAfter(var16);
    org.jfree.data.time.Day var18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addDays((-598), (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.previous();
//     long var8 = var6.getMiddleMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var6.getLastMillisecond(var9);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-453));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    java.util.Date var4 = var3.getEnd();
    org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
    org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("December 2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(100);
    var8.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(1, var8);
    var8.setDescription("");
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addDays(12, var8);
    java.lang.String var15 = var14.getDescription();
    boolean var16 = var2.isOn(var14);
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(100);
    int var19 = var18.getDayOfMonth();
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(100);
    var24.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addMonths(1, var24);
    org.jfree.data.time.SerialDate var28 = var21.getEndOfCurrentMonth(var24);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(100);
    var33.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.addMonths(1, var33);
    org.jfree.data.time.SerialDate var37 = var30.getEndOfCurrentMonth(var33);
    org.jfree.data.time.SerialDate var38 = var28.getEndOfCurrentMonth(var33);
    org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(100);
    var43.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addMonths(1, var43);
    org.jfree.data.time.SerialDate var47 = var40.getEndOfCurrentMonth(var43);
    org.jfree.data.time.FixedMillisecond var50 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var51 = var50.getStart();
    org.jfree.data.time.FixedMillisecond var52 = new org.jfree.data.time.FixedMillisecond(var51);
    org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var51);
    org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addYears(0, var53);
    org.jfree.data.time.SerialDate var56 = var54.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var57 = var47.getEndOfCurrentMonth(var56);
    boolean var59 = var18.isInRange(var38, var47, (-453));
    int var60 = var18.getDayOfWeek();
    boolean var61 = var2.isAfter((org.jfree.data.time.SerialDate)var18);
    java.util.Date var62 = var18.toDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, (org.jfree.data.time.SerialDate)var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, var4);
//     org.jfree.data.general.SeriesChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var9 = var5.getTimePeriod(10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(100, 2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     var1.setKey((java.lang.Comparable)'4');
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var11 = var10.getTime();
//     java.util.Calendar var12 = null;
//     long var13 = var10.getFirstMillisecond(var12);
//     var1.setKey((java.lang.Comparable)var10);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.data.time.RegularTimePeriod var21 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 0.0d);
//     java.lang.String var25 = var16.toString();
//     java.util.Date var26 = var16.getEnd();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "2014"+ "'", var25.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("December 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.beans.PropertyChangeListener var7 = null;
    var1.removePropertyChangeListener(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var10 = var1.getDataItem(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     java.util.Calendar var28 = null;
//     long var29 = var25.getLastMillisecond(var28);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("ERROR : Relative To String");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var7 = var6.getDescription();
    java.lang.Comparable var8 = var6.getKey();
    org.jfree.data.time.TimeSeries var9 = var1.addAndOrUpdate(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var11 = var1.getTimePeriod(1969);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)100+ "'", var8.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    int var4 = var1.toSerial();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
    org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
    boolean var16 = var1.isOnOrAfter(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var18 = var1.getPreviousDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(31, 0, (-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond((-62167363200000L));
    java.util.Calendar var2 = null;
    long var3 = var1.getFirstMillisecond(var2);
    java.util.Calendar var4 = null;
    long var5 = var1.getFirstMillisecond(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-62167363200000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-62167363200000L));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Calendar var4 = null;
    long var5 = var3.getFirstMillisecond(var4);
    int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var7 = var1.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-457), 9);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var8 = var7.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
//     boolean var16 = var1.isOnOrAfter(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var18 = var1.getYYYY();
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var22 = var21.getStart();
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addYears(0, var24);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(100);
//     var30.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addMonths(1, var30);
//     org.jfree.data.time.SerialDate var34 = var27.getEndOfCurrentMonth(var30);
//     org.jfree.data.time.SerialDate var35 = var25.getEndOfCurrentMonth(var34);
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(100);
//     var37.setDescription("org.jfree.data.general.SeriesException: January");
//     java.lang.String var40 = var37.getDescription();
//     org.jfree.data.time.SerialDate var41 = var35.getEndOfCurrentMonth(var37);
//     boolean var42 = var1.isOnOrBefore(var35);
//     org.jfree.data.time.SerialDate var43 = null;
//     boolean var44 = var1.isOnOrBefore(var43);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(100);
    var5.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    org.jfree.data.time.SerialDate var9 = var2.getEndOfCurrentMonth(var5);
    org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var13 = var12.getStart();
    org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(var13);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var13);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addYears(0, var15);
    org.jfree.data.time.SerialDate var18 = var16.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var19 = var9.getEndOfCurrentMonth(var18);
    org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var24 = var23.getStart();
    org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(var24);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var24);
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(0, var26);
    org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addYears(0, var26);
    org.jfree.data.time.SerialDate var29 = var18.getEndOfCurrentMonth(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-452), var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getStart();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var2, var3);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(100);
    var5.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    org.jfree.data.time.SerialDate var9 = var2.getEndOfCurrentMonth(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears((-41893), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-457), 11, 11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var2);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var6 = var5.getLastMillisecond();
//     long var7 = var5.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var10 = var9.getDescription();
//     java.lang.Comparable var11 = var9.getKey();
//     var9.setMaximumItemAge(1412146800000L);
//     boolean var14 = var5.equals((java.lang.Object)1412146800000L);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1391241599999L);
//     var3.setRangeDescription("Wed Dec 31 16:00:00 PST 1969");
//     java.util.Collection var19 = var3.getTimePeriods();
//     org.jfree.data.time.RegularTimePeriod var20 = null;
//     java.lang.Number var21 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var3.update(var20, var21);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + (byte)100+ "'", var11.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     java.lang.String var10 = var2.toString();
//     int var11 = var2.getDayOfMonth();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var16 = var13.createCopy(0, 0);
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var19 = var18.getDescription();
//     java.lang.Comparable var20 = var18.getKey();
//     org.jfree.data.time.TimeSeries var21 = var13.addAndOrUpdate(var18);
//     int var22 = var2.compareTo((java.lang.Object)var18);
//     int var23 = var2.getMonth();
//     java.util.Calendar var24 = null;
//     long var25 = var2.getLastMillisecond(var24);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     var1.setDomainDescription("20-December-2014");
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
//     var13.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var13);
//     org.jfree.data.time.SerialDate var17 = var10.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(var21);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var27 = var17.getEndOfCurrentMonth(var26);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day(var17);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var31 = var30.getTime();
//     java.util.Calendar var32 = null;
//     var30.peg(var32);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     boolean var36 = var34.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var37 = var34.next();
//     long var38 = var34.getLastMillisecond();
//     int var39 = var30.compareTo((java.lang.Object)var34);
//     java.lang.String var40 = var34.toString();
//     org.jfree.data.time.TimeSeries var41 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var28, (org.jfree.data.time.RegularTimePeriod)var34);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var43 = var41.getValue((-570));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "20-December-2014"+ "'", var40.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var7 = var6.getMonth();
//     int var8 = var6.toSerial();
//     boolean var9 = var1.isBefore((org.jfree.data.time.SerialDate)var6);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var11.setMaximumItemCount(0);
//     var11.clear();
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var17 = var16.getLastMillisecond();
//     long var18 = var16.getLastMillisecond();
//     long var19 = var16.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var16.previous();
//     java.util.Calendar var21 = null;
//     long var22 = var16.getFirstMillisecond(var21);
//     org.jfree.data.time.TimeSeriesDataItem var24 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (-1.0d));
//     var11.removeAgedItems(0L, true);
//     var11.setMaximumItemCount(0);
//     boolean var30 = var1.equals((java.lang.Object)0);
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var34 = var33.getDayOfMonth();
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var37 = var33.isBefore(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var33);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var41 = var40.getMonth();
//     int var42 = var40.toSerial();
//     int var43 = var40.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var47 = var46.getDayOfMonth();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var50 = var46.isBefore(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var46);
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day();
//     boolean var54 = var52.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var55 = var52.next();
//     long var56 = var52.getLastMillisecond();
//     java.lang.String var57 = var52.toString();
//     org.jfree.data.time.SerialDate var58 = var52.getSerialDate();
//     boolean var59 = var46.isOn(var58);
//     boolean var60 = var40.isAfter(var58);
//     int var61 = var33.compare(var58);
//     org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var64 = var63.getMonth();
//     int var65 = var63.toSerial();
//     int var66 = var63.toSerial();
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var69 = var68.getMonth();
//     int var70 = var68.toSerial();
//     boolean var71 = var63.isBefore((org.jfree.data.time.SerialDate)var68);
//     org.jfree.data.time.TimeSeries var73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var73.setMaximumItemCount(0);
//     var73.clear();
//     org.jfree.data.time.FixedMillisecond var78 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var79 = var78.getLastMillisecond();
//     long var80 = var78.getLastMillisecond();
//     long var81 = var78.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var82 = var78.previous();
//     java.util.Calendar var83 = null;
//     long var84 = var78.getFirstMillisecond(var83);
//     org.jfree.data.time.TimeSeriesDataItem var86 = var73.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var78, (-1.0d));
//     var73.removeAgedItems(0L, true);
//     var73.setMaximumItemCount(0);
//     boolean var92 = var63.equals((java.lang.Object)0);
//     org.jfree.data.time.SerialDate var93 = var58.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var63);
//     boolean var94 = var1.isBefore(var58);
//     var1.setDescription("Value");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "20-December-2014"+ "'", var57.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == (-41893));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == true);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: 20-December-2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "June"+ "'", var1.equals("June"));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDomainDescription();
    java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    var1.setDescription("January");
    org.jfree.data.time.RegularTimePeriod var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var9, 1.0d, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Time"+ "'", var5.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-452), (-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var1.getValue((-598));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
//     var7.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
//     var7.setDescription("");
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addDays(12, var7);
//     java.lang.String var14 = var13.getDescription();
//     boolean var15 = var1.isOn(var13);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var18 = var17.getDayOfMonth();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
//     var23.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addMonths(1, var23);
//     org.jfree.data.time.SerialDate var27 = var20.getEndOfCurrentMonth(var23);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(100);
//     var32.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(1, var32);
//     org.jfree.data.time.SerialDate var36 = var29.getEndOfCurrentMonth(var32);
//     org.jfree.data.time.SerialDate var37 = var27.getEndOfCurrentMonth(var32);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(100);
//     var42.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addMonths(1, var42);
//     org.jfree.data.time.SerialDate var46 = var39.getEndOfCurrentMonth(var42);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var50 = var49.getStart();
//     org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond(var50);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var50);
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addYears(0, var52);
//     org.jfree.data.time.SerialDate var55 = var53.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var56 = var46.getEndOfCurrentMonth(var55);
//     boolean var58 = var17.isInRange(var37, var46, (-453));
//     int var59 = var17.getDayOfWeek();
//     boolean var60 = var1.isAfter((org.jfree.data.time.SerialDate)var17);
//     java.util.Date var61 = var17.toDate();
//     org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var64 = var63.getMonth();
//     int var65 = var63.toSerial();
//     int var66 = var63.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var69 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var70 = var69.getDayOfMonth();
//     org.jfree.data.time.SerialDate var72 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var73 = var69.isBefore(var72);
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var69);
//     org.jfree.data.time.Day var75 = new org.jfree.data.time.Day();
//     boolean var77 = var75.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var78 = var75.next();
//     long var79 = var75.getLastMillisecond();
//     java.lang.String var80 = var75.toString();
//     org.jfree.data.time.SerialDate var81 = var75.getSerialDate();
//     boolean var82 = var69.isOn(var81);
//     boolean var83 = var63.isAfter(var81);
//     boolean var84 = var17.isOnOrAfter(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var80 + "' != '" + "20-December-2014"+ "'", var80.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var8 = var7.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
//     boolean var16 = var1.isOnOrAfter(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var18 = var1.getYYYY();
//     int var19 = var1.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var24 = var23.getDayOfMonth();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var27 = var23.isBefore(var26);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addMonths(1, var26);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var28);
//     boolean var30 = var1.isAfter(var28);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var33 = var32.getMonth();
//     int var34 = var32.toSerial();
//     int var35 = var32.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var39 = var38.getDayOfMonth();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var42 = var38.isBefore(var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var38);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     boolean var46 = var44.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var47 = var44.next();
//     long var48 = var44.getLastMillisecond();
//     java.lang.String var49 = var44.toString();
//     org.jfree.data.time.SerialDate var50 = var44.getSerialDate();
//     boolean var51 = var38.isOn(var50);
//     boolean var52 = var32.isAfter(var50);
//     int var53 = var1.compare((org.jfree.data.time.SerialDate)var32);
//     org.jfree.data.time.Month var54 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, 0.0d);
//     int var58 = var56.compareTo((java.lang.Object)(-62167363200000L));
//     var56.setValue((java.lang.Number)(-1.0f));
//     org.jfree.data.time.FixedMillisecond var63 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var64 = var63.getStart();
//     org.jfree.data.time.FixedMillisecond var65 = new org.jfree.data.time.FixedMillisecond(var64);
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.createInstance(var64);
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.addYears(0, var66);
//     boolean var68 = var56.equals((java.lang.Object)var67);
//     org.jfree.data.time.SerialDate var69 = null;
//     boolean var70 = var32.isInRange(var67, var69);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var8 = var7.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
//     boolean var16 = var1.isOnOrAfter(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var18 = var1.getYYYY();
//     int var19 = var1.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var24 = var23.getDayOfMonth();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var27 = var23.isBefore(var26);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addMonths(1, var26);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var28);
//     boolean var30 = var1.isAfter(var28);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var33 = var32.getMonth();
//     int var34 = var32.toSerial();
//     int var35 = var32.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var39 = var38.getDayOfMonth();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var42 = var38.isBefore(var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var38);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     boolean var46 = var44.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var47 = var44.next();
//     long var48 = var44.getLastMillisecond();
//     java.lang.String var49 = var44.toString();
//     org.jfree.data.time.SerialDate var50 = var44.getSerialDate();
//     boolean var51 = var38.isOn(var50);
//     boolean var52 = var32.isAfter(var50);
//     int var53 = var1.compare((org.jfree.data.time.SerialDate)var32);
//     int var54 = var1.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "20-December-2014"+ "'", var49.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 11);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.general.SeriesChangeListener var33 = null;
//     var26.removeChangeListener(var33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var36 = var26.getValue(1);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var4 = var3.getDescription();
//     java.lang.Comparable var5 = var3.getKey();
//     var3.setMaximumItemAge(1412146800000L);
//     java.lang.String var8 = var3.getDescription();
//     java.lang.Class var9 = var3.getTimePeriodClass();
//     java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October 10", var9);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     java.util.Date var13 = var11.getEnd();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     java.util.TimeZone var15 = null;
//     org.jfree.data.time.RegularTimePeriod var16 = org.jfree.data.time.RegularTimePeriod.createInstance(var9, var13, var15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries(var0, var9);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + (byte)100+ "'", var5.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    java.lang.Class var5 = var4.getTimePeriodClass();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
    java.util.TimeZone var10 = null;
    org.jfree.data.time.RegularTimePeriod var11 = org.jfree.data.time.RegularTimePeriod.createInstance(var5, var8, var10);
    java.lang.Class var12 = org.jfree.data.time.RegularTimePeriod.downsize(var5);
    java.lang.Class var13 = org.jfree.data.time.RegularTimePeriod.downsize(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     boolean var3 = var1.isEmpty();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     java.lang.String var5 = var4.toString();
//     int var7 = var4.compareTo((java.lang.Object)"2014");
//     int var8 = var4.getMonth();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.String var11 = var4.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "20-December-2014"+ "'", var5.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("December");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getDayOfMonth();
//     int var12 = var2.getYear();
//     org.jfree.data.time.Month var14 = org.jfree.data.time.Month.parseMonth("December 2014");
//     org.jfree.data.time.RegularTimePeriod var15 = var14.previous();
//     java.util.Date var16 = var14.getEnd();
//     boolean var17 = var2.equals((java.lang.Object)var16);
//     java.util.Calendar var18 = null;
//     long var19 = var2.getFirstMillisecond(var18);
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var2);
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     java.lang.String var8 = var6.toString();
//     long var9 = var6.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "31-December-1969"+ "'", var8.equals("31-December-1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 28799999L);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     var1.setDomainDescription("hi!");
//     var1.setNotify(true);
//     var1.setDescription("ThreadContext");
//     org.jfree.data.time.RegularTimePeriod var33 = var1.getNextTimePeriod();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.delete((-88), 5);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    java.lang.String var6 = var1.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.addChangeListener(var5);
    java.lang.Class var7 = var1.getTimePeriodClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var6 = var5.next();
    org.jfree.data.time.RegularTimePeriod var7 = var5.next();
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
    var8.setDomainDescription("Time");
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(100);
    var15.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.SerialDate var19 = var12.getEndOfCurrentMonth(var15);
    var8.setKey((java.lang.Comparable)var15);
    int var21 = var2.compare(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addMonths((-452), var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-88));

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
//     java.beans.PropertyChangeListener var5 = null;
//     var1.removePropertyChangeListener(var5);
//     var1.setRangeDescription("Time");
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     java.lang.String var11 = var10.toString();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(1, var10);
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1418759999999L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var14, true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "2014"+ "'", var11.equals("2014"));
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    var1.setDomainDescription("Following");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var7 = var1.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     int var4 = var0.getDayOfMonth();
//     int var5 = var0.getYear();
//     org.jfree.data.time.RegularTimePeriod var6 = var0.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     long var15 = var13.getSerialIndex();
//     int var16 = var13.getYearValue();
//     java.util.Calendar var17 = null;
//     long var18 = var13.getFirstMillisecond(var17);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }
// 
// 
//     org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("20-December-2014");
//     java.lang.Throwable[] var2 = var1.getSuppressed();
//     org.jfree.data.general.SeriesException var4 = new org.jfree.data.general.SeriesException("hi!");
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     var1.addSuppressed((java.lang.Throwable)var4);
//     java.lang.Throwable var7 = null;
//     var1.addSuppressed(var7);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     java.lang.String var7 = var1.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     java.util.Date var11 = var10.getStart();
//     java.util.TimeZone var12 = null;
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(var11, var12);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var4 = var3.getDescription();
    java.lang.Comparable var5 = var3.getKey();
    var3.setMaximumItemAge(1412146800000L);
    java.lang.String var8 = var3.getDescription();
    java.lang.Class var9 = var3.getTimePeriodClass();
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var9);
    org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
    long var13 = var12.getLastMillisecond();
    long var14 = var12.getLastMillisecond();
    long var15 = var12.getLastMillisecond();
    java.util.Date var16 = var12.getTime();
    java.lang.Class var21 = null;
    org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var26 = var23.createCopy(0, 0);
    java.lang.Class var27 = var26.getTimePeriodClass();
    java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var21, var27);
    java.io.InputStream var29 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var27);
    org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var16, "30-April-1900", "December", var27);
    java.util.TimeZone var31 = null;
    org.jfree.data.time.RegularTimePeriod var32 = org.jfree.data.time.RegularTimePeriod.createInstance(var9, var16, var31);
    java.io.InputStream var33 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Wed Dec 31 16:00:00 PST 1969", var9);
    java.lang.ClassLoader var34 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)100+ "'", var5.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
    int var2 = var1.getDayOfMonth();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(31);
    boolean var5 = var1.isBefore(var4);
    int var6 = var1.getDayOfMonth();
    int var7 = var1.getDayOfWeek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
    org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var8.setMaximumItemCount(0);
    int var11 = var5.compareTo((java.lang.Object)var8);
    java.lang.Number var12 = var5.getValue();
    org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
    boolean var15 = var5.equals((java.lang.Object)var14);
    boolean var16 = var1.equals((java.lang.Object)var14);
    org.jfree.data.time.TimePeriodFormatException var18 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:00 PST 1969");
    var14.addSuppressed((java.lang.Throwable)var18);
    org.jfree.data.time.TimePeriodFormatException var21 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
    org.jfree.data.general.SeriesException var23 = new org.jfree.data.general.SeriesException("hi!");
    java.lang.Throwable[] var24 = var23.getSuppressed();
    var21.addSuppressed((java.lang.Throwable)var23);
    var18.addSuppressed((java.lang.Throwable)var21);
    org.jfree.data.time.TimePeriodFormatException var28 = new org.jfree.data.time.TimePeriodFormatException("20-December-2014");
    java.lang.Throwable[] var29 = var28.getSuppressed();
    org.jfree.data.general.SeriesException var31 = new org.jfree.data.general.SeriesException("hi!");
    java.lang.Throwable[] var32 = var31.getSuppressed();
    var28.addSuppressed((java.lang.Throwable)var31);
    var18.addSuppressed((java.lang.Throwable)var28);
    java.lang.Throwable[] var35 = var18.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     int var33 = var27.getYear();
//     java.util.Calendar var34 = null;
//     long var35 = var27.getFirstMillisecond(var34);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     java.lang.String var28 = var5.toString();
//     java.util.Calendar var29 = null;
//     var5.peg(var29);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-100), (-21), (-88));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(31, (-570), 31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969");

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-41893), 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     java.lang.String var5 = var1.getDomainDescription();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, var7);
//     boolean var10 = var1.equals((java.lang.Object)var7);
//     int var12 = var7.compareTo((java.lang.Object)(short)1);
//     java.lang.String var13 = var7.toString();
//     java.util.Calendar var14 = null;
//     var7.peg(var14);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getSerialIndex();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     java.lang.String var10 = var2.toString();
//     int var11 = var2.getDayOfMonth();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var16 = var13.createCopy(0, 0);
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var19 = var18.getDescription();
//     java.lang.Comparable var20 = var18.getKey();
//     org.jfree.data.time.TimeSeries var21 = var13.addAndOrUpdate(var18);
//     int var22 = var2.compareTo((java.lang.Object)var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var24 = var18.getDataItem((-570));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "20-December-2014"+ "'", var10.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + (byte)100+ "'", var20.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.Year var28 = var25.getYear();
//     java.lang.Object var29 = null;
//     int var30 = var25.compareTo(var29);
//     org.jfree.data.time.Year var31 = var25.getYear();
//     java.util.Calendar var32 = null;
//     var31.peg(var32);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(4, 10);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getLastMillisecond(var3);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }
// 
// 
//     org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("December 2014");
//     org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
//     java.util.Date var3 = var1.getEnd();
//     java.lang.Object var4 = null;
//     int var5 = var1.compareTo(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var1.getLastMillisecond(var6);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(28, 0, 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     long var4 = var0.getLastMillisecond();
//     int var5 = var0.getDayOfMonth();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(10, var7);
//     org.jfree.data.time.Year var12 = var11.getYear();
//     long var13 = var11.getFirstMillisecond();
//     java.lang.String var14 = var11.toString();
//     org.jfree.data.time.Year var15 = var11.getYear();
//     boolean var16 = var0.equals((java.lang.Object)var15);
//     java.util.Calendar var17 = null;
//     long var18 = var0.getMiddleMillisecond(var17);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     java.lang.String var6 = var5.toString();
//     long var7 = var5.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "31-December-2014"+ "'", var6.equals("31-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 42004L);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.lang.String var3 = var1.toString();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var3.equals("Wed Dec 31 16:00:00 PST 1969"));
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     var1.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     var1.add(var17, true);
//     var1.removeAgedItems((-57600000L), false);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var26 = var25.toString();
//     org.jfree.data.time.TimeSeriesDataItem var27 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Year var28 = var25.getYear();
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "January 0"+ "'", var26.equals("January 0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var2);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var6 = var5.getLastMillisecond();
//     long var7 = var5.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var10 = var9.getDescription();
//     java.lang.Comparable var11 = var9.getKey();
//     var9.setMaximumItemAge(1412146800000L);
//     boolean var14 = var5.equals((java.lang.Object)1412146800000L);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1391241599999L);
//     var3.setRangeDescription("Wed Dec 31 16:00:00 PST 1969");
//     java.util.Collection var19 = var3.getTimePeriods();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var20 = org.jfree.chart.util.ObjectUtilities.deepClone(var19);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + (byte)100+ "'", var11.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    var1.removeAgedItems(2014L, false);
    var1.setMaximumItemAge(0L);
    java.util.List var9 = var1.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var10 = var1.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("December 2014");
    org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
    java.util.Date var3 = var1.getEnd();
    org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var3 = var1.previous();
    java.util.Date var4 = var1.getTime();
    java.util.Calendar var5 = null;
    long var6 = var1.getMiddleMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var1.getFirstMillisecond(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("31-December-2014");

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(100);
    var6.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(1, var6);
    org.jfree.data.time.SerialDate var10 = var3.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(100);
    var15.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.SerialDate var19 = var12.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var20 = var10.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-457), var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1969, 2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    java.util.Calendar var3 = null;
    var1.peg(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getMiddleMillisecond(var5);
    long var7 = var1.getLastMillisecond();
    java.util.Calendar var8 = null;
    var1.peg(var8);
    org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var11 = var10.next();
    org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 10.0d);
    org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, 0.0d);
    org.jfree.data.time.RegularTimePeriod var17 = var16.getPeriod();
    boolean var18 = var13.equals((java.lang.Object)var17);
    boolean var19 = var1.equals((java.lang.Object)var13);
    org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Calendar var24 = null;
    long var25 = var23.getFirstMillisecond(var24);
    int var26 = var21.getIndex((org.jfree.data.time.RegularTimePeriod)var23);
    java.util.Date var27 = var23.getTime();
    boolean var28 = var1.equals((java.lang.Object)var23);
    org.jfree.data.time.RegularTimePeriod var29 = var23.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
//     var4.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     boolean var9 = var7.equals((java.lang.Object)"January");
//     var4.add((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     java.lang.String var12 = var7.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     java.util.Calendar var10 = null;
//     long var11 = var2.getFirstMillisecond(var10);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=January 2014]");

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(1969);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.general.SeriesChangeEvent var28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var25);
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var31 = var30.getMonth();
//     int var32 = var30.toSerial();
//     int var33 = var30.toSerial();
//     org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var36 = var35.getMonth();
//     int var37 = var35.toSerial();
//     boolean var38 = var30.isBefore((org.jfree.data.time.SerialDate)var35);
//     int var39 = var30.toSerial();
//     int var40 = var25.compareTo((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(100);
//     java.lang.String var44 = var43.getDescription();
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addMonths(28, var43);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day(var43);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var47 = var30.compareTo((java.lang.Object)var46);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
//     var4.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     boolean var9 = var7.equals((java.lang.Object)"January");
//     var4.add((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var13.getNotify();
//     boolean var28 = var13.isEmpty();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var32 = var31.getPeriod();
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var34.setMaximumItemCount(0);
//     int var37 = var31.compareTo((java.lang.Object)var34);
//     org.jfree.data.time.TimeSeries var38 = var13.addAndOrUpdate(var34);
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var40 = var39.next();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var44 = var38.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var39, 1.0d);
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     java.lang.String var48 = var47.toString();
//     int var50 = var47.compareTo((java.lang.Object)"2014");
//     int var51 = var46.getIndex((org.jfree.data.time.RegularTimePeriod)var47);
//     int var52 = var47.getYear();
//     int var53 = var47.getMonth();
//     int var54 = var47.getMonth();
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day();
//     java.lang.String var58 = var57.toString();
//     int var60 = var57.compareTo((java.lang.Object)"2014");
//     int var61 = var56.getIndex((org.jfree.data.time.RegularTimePeriod)var57);
//     org.jfree.data.time.TimeSeriesDataItem var63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var57, (-1.0d));
//     int var64 = var57.getMonth();
//     int var65 = var57.getDayOfMonth();
//     java.lang.String var66 = var57.toString();
//     org.jfree.data.time.TimeSeries var67 = var38.createCopy((org.jfree.data.time.RegularTimePeriod)var47, (org.jfree.data.time.RegularTimePeriod)var57);
//     boolean var68 = var4.equals((java.lang.Object)var38);
//     var38.setRangeDescription("Wed Dec 31 16:00:00 PST 1969");
//     org.jfree.data.time.Year var71 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var72 = var71.next();
//     org.jfree.data.time.TimeSeriesDataItem var74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var71, 10.0d);
//     org.jfree.data.time.TimePeriodFormatException var76 = new org.jfree.data.time.TimePeriodFormatException("Sunday");
//     boolean var77 = var74.equals((java.lang.Object)var76);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var38.add(var74, true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + "20-December-2014"+ "'", var48.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var58 + "' != '" + "20-December-2014"+ "'", var58.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var66 + "' != '" + "20-December-2014"+ "'", var66.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == false);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var5 = var2.createCopy(0, 0);
    java.lang.Class var6 = var5.getTimePeriodClass();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var9 = var8.getStart();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    java.util.TimeZone var11 = null;
    org.jfree.data.time.RegularTimePeriod var12 = org.jfree.data.time.RegularTimePeriod.createInstance(var6, var9, var11);
    java.net.URL var13 = org.jfree.chart.util.ObjectUtilities.getResource("October 2014", var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var7 = var6.getDescription();
    java.lang.Comparable var8 = var6.getKey();
    org.jfree.data.time.TimeSeries var9 = var1.addAndOrUpdate(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var9.getValue(2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)100+ "'", var8.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getLastMillisecond();
//     long var31 = var29.getLastMillisecond();
//     long var32 = var29.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var33 = var29.previous();
//     int var34 = var5.compareTo((java.lang.Object)var29);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     java.lang.String var36 = var35.toString();
//     java.util.Date var37 = var35.getEnd();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(var37);
//     org.jfree.data.time.Month var39 = new org.jfree.data.time.Month(var37);
//     int var40 = var29.compareTo((java.lang.Object)var39);
//     long var41 = var29.getSerialIndex();
//     long var42 = var29.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "20-December-2014"+ "'", var36.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1L);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var26 = var25.getDescription();
//     java.util.List var27 = var25.getItems();
//     var25.setMaximumItemAge(2014L);
//     java.util.Collection var30 = var7.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, 10.0d);
//     java.lang.Object var35 = var34.clone();
//     boolean var36 = var25.equals((java.lang.Object)var34);
//     java.lang.Object var37 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getLastMillisecond();
//     long var31 = var29.getLastMillisecond();
//     long var32 = var29.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var33 = var29.previous();
//     int var34 = var5.compareTo((java.lang.Object)var29);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     java.lang.String var36 = var35.toString();
//     java.util.Date var37 = var35.getEnd();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(var37);
//     org.jfree.data.time.Month var39 = new org.jfree.data.time.Month(var37);
//     int var40 = var29.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.RegularTimePeriod var41 = var29.previous();
//     long var42 = var29.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "20-December-2014"+ "'", var36.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1L);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     int var7 = var2.getYear();
//     int var8 = var2.getMonth();
//     org.jfree.data.time.SerialDate var9 = var2.getSerialDate();
//     java.util.Calendar var10 = null;
//     long var11 = var2.getFirstMillisecond(var10);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.Year var10 = var9.getYear();
//     long var11 = var9.getFirstMillisecond();
//     java.lang.String var12 = var9.toString();
//     org.jfree.data.time.Year var13 = var9.getYear();
//     boolean var14 = var3.equals((java.lang.Object)var9);
//     java.lang.String var15 = var9.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "October 2014"+ "'", var12.equals("October 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "October 2014"+ "'", var15.equals("October 2014"));
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ThreadContext"+ "'", var2.equals("org.jfree.data.time.TimePeriodFormatException: ThreadContext"));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(2014);
    int var3 = var2.getDayOfMonth();
    int var4 = var2.toSerial();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2014);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var32 = var1.getValue(10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("December 2014");
    org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
    java.util.Date var3 = var1.getEnd();
    java.util.TimeZone var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    java.util.Date var4 = var3.getEnd();
    org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
    java.util.TimeZone var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var4, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    var4.setMaximumItemAge(1412146800000L);
    org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
    boolean var9 = var7.equals((java.lang.Object)"January");
    var4.add((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
    org.jfree.data.time.RegularTimePeriod var12 = null;
    java.lang.Number var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var14 = var4.addOrUpdate(var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     java.util.Calendar var11 = null;
//     var2.peg(var11);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "November"+ "'", var1.equals("November"));

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     java.lang.String var4 = var3.toString();
//     int var6 = var3.compareTo((java.lang.Object)"2014");
//     int var7 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
//     java.util.Collection var8 = var2.getTimePeriods();
//     java.lang.Class var9 = var2.getTimePeriodClass();
//     java.io.InputStream var10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Following", var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "20-December-2014"+ "'", var4.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var30 = var29.getTime();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(var30);
//     int var32 = var25.compareTo((java.lang.Object)var30);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(var30);
//     long var34 = var33.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 10L);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Nearest", var1);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Nearest");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-41893));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("December");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var0);
//     java.lang.String var5 = var4.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2014]"+ "'", var5.equals("org.jfree.data.general.SeriesChangeEvent[source=2014]"));
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     int var3 = var0.compareTo((java.lang.Object)"2014");
//     int var4 = var0.getMonth();
//     int var5 = var0.getMonth();
//     int var6 = var0.getMonth();
//     java.util.Calendar var7 = null;
//     var0.peg(var7);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     long var3 = var1.getLastMillisecond();
//     long var4 = var1.getLastMillisecond();
//     java.util.Date var5 = var1.getTime();
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var5, var6);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     long var7 = var6.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var6.next();
//     boolean var9 = var1.equals((java.lang.Object)var6);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }
// 
// 
//     org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("31-December-1969");
//     java.lang.Throwable[] var2 = var1.getSuppressed();
//     java.lang.Throwable var3 = null;
//     var1.addSuppressed(var3);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var1);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var5 = null;
//     var4.peg(var5);
//     long var7 = var4.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var4.previous();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate(var8, 0.0d);
//     java.lang.String var11 = var2.getDomainDescription();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "hi!", "ThreadContext", var23);
//     var24.setMaximumItemAge(1420099199999L);
//     java.util.Collection var27 = var2.getTimePeriodsUniqueToOtherSeries(var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var29 = var24.getDataItem((-452));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Time"+ "'", var11.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    java.util.Date var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var35 = var34.getTime();
//     java.util.Calendar var36 = null;
//     var34.peg(var36);
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     boolean var40 = var38.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var41 = var38.next();
//     long var42 = var38.getLastMillisecond();
//     int var43 = var34.compareTo((java.lang.Object)var38);
//     java.lang.Object var44 = null;
//     int var45 = var38.compareTo(var44);
//     var26.delete((org.jfree.data.time.RegularTimePeriod)var38);
//     org.jfree.data.time.Month var49 = new org.jfree.data.time.Month(1, 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var26.add((org.jfree.data.time.RegularTimePeriod)var49, 0.0d, true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     int var4 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var5 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem(var5, 10.0d);
//     java.lang.Number var8 = var7.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + 10.0d+ "'", var8.equals(10.0d));
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    long var3 = var1.getLastMillisecond();
    long var4 = var1.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var5 = var1.previous();
    java.util.Calendar var6 = null;
    long var7 = var1.getFirstMillisecond(var6);
    long var8 = var1.getMiddleMillisecond();
    java.util.Date var9 = var1.getEnd();
    long var10 = var1.getSerialIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
//     var1.setDomainDescription("Following");
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     org.jfree.data.time.RegularTimePeriod var9 = var7.next();
//     int var10 = var1.getIndex(var9);
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     java.lang.String var14 = var13.toString();
//     int var16 = var13.compareTo((java.lang.Object)"2014");
//     int var17 = var12.getIndex((org.jfree.data.time.RegularTimePeriod)var13);
//     java.lang.Object var18 = var12.clone();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 10.0d);
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(10, var20);
//     org.jfree.data.time.Year var25 = var24.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var27 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var24, (-1.0d));
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var29.setMaximumItemCount(0);
//     var29.clear();
//     java.lang.String var33 = var29.getDomainDescription();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     java.lang.String var36 = var35.toString();
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month(1, var35);
//     boolean var38 = var29.equals((java.lang.Object)var35);
//     int var40 = var35.compareTo((java.lang.Object)(short)1);
//     org.jfree.data.time.TimeSeriesDataItem var42 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)(-62133062400001L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var35, 100.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "Time"+ "'", var33.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "2014"+ "'", var36.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.removeChangeListener(var4);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var8 = var7.getDescription();
//     java.lang.Comparable var9 = var7.getKey();
//     var7.setMaximumItemAge(1412146800000L);
//     java.lang.String var12 = var7.getDescription();
//     java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     var1.setDomainDescription("Sun Dec 21 11:59:59 PST 2014");
//     java.lang.String var16 = var1.getRangeDescription();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     java.lang.String var21 = var20.toString();
//     long var22 = var20.getMiddleMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update(var20, (java.lang.Number)1389902399999L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "Value"+ "'", var16.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "December 2014"+ "'", var21.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1418759999999L);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    int var4 = var2.compareTo((java.lang.Object)(-62167363200000L));
    var2.setValue((java.lang.Number)(-1.0f));
    var2.setValue((java.lang.Number)10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var1.removeChangeListener(var7);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var11 = var10.getLastMillisecond();
//     long var12 = var10.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var10.next();
//     org.jfree.data.time.RegularTimePeriod var14 = var10.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)1414825199999L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.Year var3 = var0.getYear();
//     long var4 = var3.getLastMillisecond();
//     java.util.Calendar var5 = null;
//     long var6 = var3.getFirstMillisecond(var5);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var5.setMaximumItemCount(0);
    int var8 = var2.compareTo((java.lang.Object)var5);
    org.jfree.data.general.SeriesChangeListener var9 = null;
    var5.removeChangeListener(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setMaximumItemCount((-100));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     var1.setMaximumItemCount(100);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.next();
//     org.jfree.data.general.SeriesChangeEvent var12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)2014L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-453), 0, 1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     var1.setDescription("ERROR : Relative To String");
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.String var17 = var16.toString();
//     int var19 = var16.compareTo((java.lang.Object)"2014");
//     int var20 = var15.getIndex((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (-1.0d));
//     int var23 = var16.getMonth();
//     int var24 = var16.getDayOfMonth();
//     int var25 = var16.getDayOfMonth();
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var33 = var30.createCopy(0, 0);
//     java.lang.Class var34 = var33.getTimePeriodClass();
//     java.lang.Object var35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var28, var34);
//     java.io.InputStream var36 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var34);
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var16, var34);
//     java.beans.PropertyChangeListener var38 = null;
//     var37.addPropertyChangeListener(var38);
//     org.jfree.data.general.SeriesChangeEvent var40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var37);
//     boolean var41 = var1.equals((java.lang.Object)var40);
//     var1.fireSeriesChanged();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "20-December-2014"+ "'", var17.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getDayOfMonth();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var19 = var16.createCopy(0, 0);
//     java.lang.Class var20 = var19.getTimePeriodClass();
//     java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var14, var20);
//     java.io.InputStream var22 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var20);
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var26 = var23.createCopy((-88), (-452));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    long var4 = var3.getMiddleMillisecond();
    long var5 = var3.getSerialIndex();
    java.util.Date var6 = var3.getTime();
    long var7 = var3.getSerialIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setKey((java.lang.Comparable)'4');
    boolean var8 = var1.getNotify();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var11 = var10.getTime();
    java.util.Calendar var12 = null;
    long var13 = var10.getFirstMillisecond(var12);
    var1.setKey((java.lang.Comparable)var10);
    org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var17 = var16.next();
    org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
    org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
    org.jfree.data.time.RegularTimePeriod var21 = var16.next();
    org.jfree.data.time.TimeSeriesDataItem var22 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var16);
    var1.removeAgedItems(true);
    java.lang.Number var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(12, var26);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var3 = var2.getStart();
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays((-41893), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(9, 1, 5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.lang.Comparable var3 = var1.getKey();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
    java.util.Calendar var6 = null;
    long var7 = var5.getFirstMillisecond(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1420012800000L);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1419191999999L);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, var4);
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var9 = var8.getPeriod();
//     java.util.Date var10 = var9.getEnd();
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day(var10);
//     var5.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(short)0, true);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("ThreadContext");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     var1.clear();
//     var1.fireSeriesChanged();
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var11 = var10.getStart();
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var11);
//     org.jfree.data.time.TimeSeriesDataItem var15 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     java.util.Date var16 = var14.getEnd();
//     java.util.Calendar var17 = null;
//     long var18 = var14.getFirstMillisecond(var17);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var1.removeChangeListener(var31);
//     org.jfree.data.general.SeriesChangeListener var33 = null;
//     var1.removeChangeListener(var33);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     java.lang.String var37 = var36.toString();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(1, var36);
//     org.jfree.data.time.Year var39 = var38.getYear();
//     long var40 = var38.getLastMillisecond();
//     long var41 = var38.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var42 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var38);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update(12, (java.lang.Number)1389902399999L);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "2014"+ "'", var37.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1391241599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-88), (-41893), (-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    java.lang.Comparable var0 = null;
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var4 = var3.getDescription();
    java.lang.Comparable var5 = var3.getKey();
    var3.setMaximumItemAge(1412146800000L);
    java.lang.String var8 = var3.getDescription();
    java.lang.Class var9 = var3.getTimePeriodClass();
    java.util.Date var10 = null;
    java.util.TimeZone var11 = null;
    org.jfree.data.time.RegularTimePeriod var12 = org.jfree.data.time.RegularTimePeriod.createInstance(var9, var10, var11);
    java.lang.ClassLoader var13 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var9);
    java.lang.Class var14 = org.jfree.data.time.RegularTimePeriod.downsize(var9);
    java.io.InputStream var15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("December 2014", var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries(var0, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)100+ "'", var5.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-453));
//     org.jfree.data.time.Year var7 = var3.getYear();
//     org.jfree.data.time.RegularTimePeriod var8 = var3.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    var4.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
    org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
    var13.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var13);
    org.jfree.data.time.SerialDate var17 = var10.getEndOfCurrentMonth(var13);
    org.jfree.data.time.SerialDate var18 = var8.getEndOfCurrentMonth(var13);
    java.lang.String var19 = var18.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(2014, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setKey((java.lang.Comparable)'4');
    boolean var8 = var1.getNotify();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var11 = var10.getTime();
    java.util.Calendar var12 = null;
    long var13 = var10.getFirstMillisecond(var12);
    var1.setKey((java.lang.Comparable)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(5, (java.lang.Number)(-62167363200000L));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10L);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var6 = var5.next();
    org.jfree.data.time.RegularTimePeriod var7 = var5.next();
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
    var8.setDomainDescription("Time");
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(100);
    var15.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.SerialDate var19 = var12.getEndOfCurrentMonth(var15);
    var8.setKey((java.lang.Comparable)var15);
    int var21 = var2.compare(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(31, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-88));

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(0, var1);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    long var3 = var1.getLastMillisecond();
    long var4 = var1.getLastMillisecond();
    java.util.Date var5 = var1.getTime();
    java.lang.Class var10 = null;
    org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var15 = var12.createCopy(0, 0);
    java.lang.Class var16 = var15.getTimePeriodClass();
    java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var10, var16);
    java.io.InputStream var18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var16);
    org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, "30-April-1900", "December", var16);
    org.jfree.data.general.SeriesChangeListener var20 = null;
    var19.addChangeListener(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-88), (-88));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     long var3 = var0.getLastMillisecond();
//     org.jfree.data.time.Year var4 = var0.getYear();
//     org.jfree.data.time.Year var5 = var0.getYear();
//     long var6 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 24180L);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    var2.setValue((java.lang.Number)4);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     long var2 = var0.getSerialIndex();
//     int var3 = var0.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     long var6 = var1.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var8.removeChangeListener(var11);
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var15 = var14.getDescription();
//     java.lang.Comparable var16 = var14.getKey();
//     var14.setMaximumItemAge(1412146800000L);
//     java.lang.String var19 = var14.getDescription();
//     java.util.Collection var20 = var8.getTimePeriodsUniqueToOtherSeries(var14);
//     var14.setDomainDescription("ThreadContext");
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var25 = var24.getLastMillisecond();
//     long var26 = var24.getLastMillisecond();
//     long var27 = var24.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var28 = var24.previous();
//     org.jfree.data.time.TimeSeriesDataItem var30 = var14.addOrUpdate(var28, (java.lang.Number)1.0d);
//     var1.setKey((java.lang.Comparable)var28);
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var34 = null;
//     var33.addPropertyChangeListener(var34);
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     java.lang.String var39 = var38.toString();
//     int var41 = var38.compareTo((java.lang.Object)"2014");
//     int var42 = var37.getIndex((org.jfree.data.time.RegularTimePeriod)var38);
//     var37.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     java.lang.String var48 = var47.toString();
//     int var50 = var47.compareTo((java.lang.Object)"2014");
//     int var51 = var46.getIndex((org.jfree.data.time.RegularTimePeriod)var47);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, (-1.0d));
//     var37.add(var53, true);
//     var53.setValue((java.lang.Number)0.0d);
//     java.lang.Object var58 = null;
//     boolean var59 = var53.equals(var58);
//     var33.add(var53, false);
//     org.jfree.data.time.RegularTimePeriod var62 = var53.getPeriod();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update(var62, (java.lang.Number)100L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + (byte)100+ "'", var16.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "20-December-2014"+ "'", var39.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + "20-December-2014"+ "'", var48.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "hi!", "ThreadContext", var11);
//     java.util.List var13 = var12.getItems();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var15 = var14.next();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, 10.0d);
//     long var18 = var14.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var19 = var14.next();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var12.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     int var21 = var14.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2014);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.Object var7 = var1.clone();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 10.0d);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(10, var9);
//     org.jfree.data.time.Year var14 = var13.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     boolean var17 = var1.isEmpty();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.delete(4, 7);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    java.util.TimeZone var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     boolean var24 = var1.isEmpty();
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var27 = var26.next();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, 10.0d);
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month(10, var26);
//     org.jfree.data.time.Year var31 = var30.getYear();
//     long var32 = var30.getFirstMillisecond();
//     java.lang.String var33 = var30.toString();
//     org.jfree.data.time.Year var34 = var30.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var36 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)28);
//     java.lang.String var37 = var34.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "October 2014"+ "'", var33.equals("October 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "2014"+ "'", var37.equals("2014"));
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.Year var3 = var0.getYear();
//     long var4 = var3.getLastMillisecond();
//     java.lang.String var5 = var3.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "2014"+ "'", var5.equals("2014"));
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     long var7 = var6.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var6.next();
//     boolean var9 = var1.equals((java.lang.Object)var6);
//     var1.setRangeDescription("2013");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 100);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setMaximumItemCount(0);
//     int var11 = var5.compareTo((java.lang.Object)var8);
//     java.lang.Number var12 = var5.getValue();
//     org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
//     boolean var15 = var5.equals((java.lang.Object)var14);
//     int var16 = var2.compareTo((java.lang.Object)var5);
//     long var17 = var2.getFirstMillisecond();
//     long var18 = var2.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-58987929600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-58985251200001L));
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2014);
//     int var2 = var1.getDayOfMonth();
//     org.jfree.data.time.SerialDate var3 = null;
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(2014);
//     java.lang.String var6 = var5.getDescription();
//     int var7 = var5.getDayOfWeek();
//     boolean var9 = var1.isInRange(var3, (org.jfree.data.time.SerialDate)var5, 0);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var2, var6);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     int var3 = var0.compareTo((java.lang.Object)"2014");
//     int var4 = var0.getMonth();
//     int var5 = var0.getMonth();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(100);
//     java.lang.String var9 = var8.getDescription();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(28, var8);
//     int var11 = var0.compareTo((java.lang.Object)28);
//     java.util.Calendar var12 = null;
//     long var13 = var0.getFirstMillisecond(var12);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var30 = var29.getTime();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(var30);
//     int var32 = var25.compareTo((java.lang.Object)var30);
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     boolean var35 = var33.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var36 = var33.next();
//     int var37 = var33.getDayOfMonth();
//     boolean var38 = var25.equals((java.lang.Object)var33);
//     long var39 = var25.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1391241599999L);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("28-February-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(31, 6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     long var4 = var0.getLastMillisecond();
//     int var5 = var0.getDayOfMonth();
//     java.lang.String var6 = var0.toString();
//     java.util.Calendar var7 = null;
//     var0.peg(var7);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    int var5 = var2.toSerial();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var9 = var8.getStart();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(0, var11);
    org.jfree.data.time.SerialDate var14 = var12.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var16 = var12.getPreviousDayOfWeek(1);
    boolean var17 = var2.isOnOrAfter(var16);
    org.jfree.data.time.Day var18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var2);
    int var19 = var2.getYYYY();
    int var20 = var2.getDayOfWeek();
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(100);
    int var25 = var24.getDayOfMonth();
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(31);
    boolean var28 = var24.isBefore(var27);
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addMonths(1, var27);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var29);
    boolean var31 = var2.isAfter(var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419148799999L);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }


    org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(100);
    int var6 = var5.getDayOfMonth();
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(31);
    boolean var9 = var5.isBefore(var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var8);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addDays(5, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2147483647, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var2.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var2.addChangeListener(var5);
//     var2.setKey((java.lang.Comparable)'4');
//     boolean var9 = var2.getNotify();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var12 = var11.getTime();
//     java.util.Calendar var13 = null;
//     long var14 = var11.getFirstMillisecond(var13);
//     var2.setKey((java.lang.Comparable)var11);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 10.0d);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(10, var17);
//     org.jfree.data.time.RegularTimePeriod var22 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(100);
//     var27.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.addMonths(1, var27);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.addMonths(12, var27);
//     int var32 = var17.compareTo((java.lang.Object)12);
//     long var33 = var17.getSerialIndex();
//     org.jfree.data.time.Month var34 = new org.jfree.data.time.Month(9, var17);
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)9);
//     var35.removeAgedItems(false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 2014L);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2014);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.util.Calendar var3 = null;
//     var1.peg(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var7 = var5.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var8 = var5.next();
//     long var9 = var5.getLastMillisecond();
//     int var10 = var1.compareTo((java.lang.Object)var5);
//     long var11 = var1.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var1.getMiddleMillisecond(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10L);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     long var3 = var1.getLastMillisecond();
//     long var4 = var1.getLastMillisecond();
//     java.util.Date var5 = var1.getTime();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var15 = var12.createCopy(0, 0);
//     java.lang.Class var16 = var15.getTimePeriodClass();
//     java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var10, var16);
//     java.io.InputStream var18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var16);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, "30-April-1900", "December", var16);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     long var21 = var20.getMiddleMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var19.add((org.jfree.data.time.RegularTimePeriod)var20, 0.0d, true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1418759999999L);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var33 = var27.previous();
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var35.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var38 = null;
//     var35.removeChangeListener(var38);
//     java.lang.Object var40 = var35.clone();
//     int var41 = var27.compareTo((java.lang.Object)var35);
//     int var42 = var27.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 2014);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     boolean var5 = var3.equals((java.lang.Object)"January");
//     var2.add((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     boolean var8 = var2.getNotify();
//     boolean var9 = var2.getNotify();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(10, var11);
//     org.jfree.data.time.Year var16 = var15.getYear();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.previous();
//     long var18 = var16.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.RegularTimePeriod var21 = var16.next();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(6, var16);
//     org.jfree.data.time.RegularTimePeriod var23 = var16.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    java.util.Calendar var3 = null;
    var1.peg(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getMiddleMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var1.getFirstMillisecond(var7);
    java.util.Calendar var9 = null;
    long var10 = var1.getMiddleMillisecond(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "hi!", "ThreadContext", var11);
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     java.lang.String var16 = var15.toString();
//     int var18 = var15.compareTo((java.lang.Object)"2014");
//     int var19 = var14.getIndex((org.jfree.data.time.RegularTimePeriod)var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.lang.String var25 = var24.toString();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month(1, var24);
//     java.lang.Number var27 = var14.getValue((org.jfree.data.time.RegularTimePeriod)var26);
//     long var28 = var26.getSerialIndex();
//     long var29 = var26.getMiddleMillisecond();
//     long var30 = var26.getSerialIndex();
//     int var31 = var26.getYearValue();
//     var12.add((org.jfree.data.time.RegularTimePeriod)var26, 1.0d, false);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var7 = var1.getDataItem(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
//     java.util.Calendar var6 = null;
//     long var7 = var5.getLastMillisecond(var6);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(2014L);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getFirstMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getLastMillisecond(var5);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setMaximumItemCount(0);
//     var8.clear();
//     java.lang.String var12 = var8.getDomainDescription();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     java.lang.String var15 = var14.toString();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(1, var14);
//     boolean var17 = var8.equals((java.lang.Object)var14);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     int var22 = var19.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var23 = null;
//     var19.removeChangeListener(var23);
//     java.beans.PropertyChangeListener var25 = null;
//     var19.removePropertyChangeListener(var25);
//     boolean var27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)var19);
//     org.jfree.data.time.RegularTimePeriod var28 = var14.next();
//     boolean var29 = var1.equals((java.lang.Object)var14);
//     java.util.Calendar var30 = null;
//     long var31 = var14.getFirstMillisecond(var30);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     var1.removeAgedItems(2014L, false);
//     var1.setMaximumItemAge(0L);
//     java.util.List var9 = var1.getItems();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var12);
//     long var14 = var13.getMiddleMillisecond();
//     long var15 = var13.getSerialIndex();
//     java.util.Calendar var16 = null;
//     var13.peg(var16);
//     int var18 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var13);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var22 = var21.getPeriod();
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var24.setMaximumItemCount(0);
//     int var27 = var21.compareTo((java.lang.Object)var24);
//     java.lang.Number var28 = var21.getValue();
//     java.lang.Number var29 = var21.getValue();
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     java.lang.String var31 = var30.toString();
//     boolean var32 = var21.equals((java.lang.Object)var31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var21);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + 0.0d+ "'", var28.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + 0.0d+ "'", var29.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "2014"+ "'", var31.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     int var3 = var0.compareTo((java.lang.Object)"2014");
//     int var4 = var0.getMonth();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(100);
//     var9.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addMonths(1, var9);
//     org.jfree.data.time.SerialDate var13 = var6.getEndOfCurrentMonth(var9);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var17 = var16.getStart();
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addYears(0, var19);
//     org.jfree.data.time.SerialDate var22 = var20.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var23 = var13.getEndOfCurrentMonth(var22);
//     boolean var24 = var0.equals((java.lang.Object)var13);
//     java.util.Calendar var25 = null;
//     var0.peg(var25);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sunday", var1);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     var1.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     var1.add(var17, true);
//     var1.removeAgedItems((-57600000L), false);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var26 = var25.toString();
//     org.jfree.data.time.TimeSeriesDataItem var27 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var25);
//     java.lang.Number var28 = var27.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "January 0"+ "'", var26.equals("January 0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + (-1.0d)+ "'", var28.equals((-1.0d)));
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2014, (-88));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.beans.PropertyChangeListener var7 = null;
    var1.removePropertyChangeListener(var7);
    org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var10 = var9.next();
    org.jfree.data.time.RegularTimePeriod var11 = var9.next();
    org.jfree.data.time.RegularTimePeriod var12 = var9.previous();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(var12, (java.lang.Number)(short)0);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.lang.Comparable var3 = var1.getKey();
    var1.setMaximumItemAge(1412146800000L);
    java.lang.String var6 = var1.getDescription();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    long var9 = var8.getLastMillisecond();
    long var10 = var8.getFirstMillisecond();
    org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var13 = var12.getDescription();
    java.lang.Comparable var14 = var12.getKey();
    var12.setMaximumItemAge(1412146800000L);
    boolean var17 = var8.equals((java.lang.Object)1412146800000L);
    java.util.Calendar var18 = null;
    long var19 = var8.getLastMillisecond(var18);
    org.jfree.data.time.RegularTimePeriod var20 = var8.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var20, (java.lang.Number)24169L, false);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (byte)100+ "'", var14.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var3 = var2.getDescription();
    java.lang.Comparable var4 = var2.getKey();
    var2.setMaximumItemAge(1412146800000L);
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var8 = var2.getTimePeriodClass();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var8);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
    long var12 = var11.getLastMillisecond();
    long var13 = var11.getLastMillisecond();
    long var14 = var11.getLastMillisecond();
    java.util.Date var15 = var11.getTime();
    java.lang.Class var20 = null;
    org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var25 = var22.createCopy(0, 0);
    java.lang.Class var26 = var25.getTimePeriodClass();
    java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var20, var26);
    java.io.InputStream var28 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var26);
    org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var15, "30-April-1900", "December", var26);
    java.util.TimeZone var30 = null;
    org.jfree.data.time.RegularTimePeriod var31 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var15, var30);
    org.jfree.data.general.SeriesChangeEvent var32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var8);
    java.lang.Object var33 = var32.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     boolean var3 = var1.isEmpty();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     java.lang.String var5 = var4.toString();
//     int var7 = var4.compareTo((java.lang.Object)"2014");
//     int var8 = var4.getMonth();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.util.List var11 = var1.getItems();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var12 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var11);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "20-December-2014"+ "'", var5.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, (-21));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     long var7 = var6.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var6.next();
//     boolean var9 = var1.equals((java.lang.Object)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var12 = var1.createCopy(31, (-453));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var2, var3);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    var1.setDescription("hi!");
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var8.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var8.removeChangeListener(var11);
    java.lang.Object var13 = var8.clone();
    java.util.Collection var14 = var1.getTimePeriodsUniqueToOtherSeries(var8);
    java.beans.PropertyChangeListener var15 = null;
    var8.addPropertyChangeListener(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     var1.setKey((java.lang.Comparable)'4');
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.lang.String var21 = var20.toString();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(1, var20);
//     java.lang.Number var23 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var22);
//     boolean var24 = var10.getNotify();
//     boolean var25 = var10.isEmpty();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var29 = var28.getPeriod();
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var31.setMaximumItemCount(0);
//     int var34 = var28.compareTo((java.lang.Object)var31);
//     org.jfree.data.time.TimeSeries var35 = var10.addAndOrUpdate(var31);
//     var10.setDomainDescription("hi!");
//     org.jfree.data.time.TimeSeries var38 = var1.addAndOrUpdate(var10);
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var41 = new org.jfree.data.time.Day();
//     java.lang.String var42 = var41.toString();
//     int var44 = var41.compareTo((java.lang.Object)"2014");
//     int var45 = var40.getIndex((org.jfree.data.time.RegularTimePeriod)var41);
//     org.jfree.data.time.TimeSeriesDataItem var47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var41, (-1.0d));
//     int var48 = var41.getMonth();
//     int var49 = var41.getDayOfMonth();
//     int var50 = var41.getDayOfMonth();
//     int var51 = var41.getYear();
//     java.util.Date var52 = var41.getEnd();
//     int var53 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var41);
//     org.jfree.data.time.TimeSeries var55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.FixedMillisecond var57 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var58 = null;
//     long var59 = var57.getFirstMillisecond(var58);
//     int var60 = var55.getIndex((org.jfree.data.time.RegularTimePeriod)var57);
//     java.util.Date var61 = var57.getTime();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var10.add((org.jfree.data.time.RegularTimePeriod)var57, (-1.0d));
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "2014"+ "'", var21.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "20-December-2014"+ "'", var42.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var1);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var5 = null;
//     var4.peg(var5);
//     long var7 = var4.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var4.previous();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate(var8, 0.0d);
//     java.lang.String var11 = var2.getDomainDescription();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "hi!", "ThreadContext", var23);
//     var24.setMaximumItemAge(1420099199999L);
//     java.util.Collection var27 = var2.getTimePeriodsUniqueToOtherSeries(var24);
//     java.util.List var28 = var2.getItems();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Time"+ "'", var11.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    int var5 = var2.toSerial();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var9 = var8.getStart();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(0, var11);
    org.jfree.data.time.SerialDate var14 = var12.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var16 = var12.getPreviousDayOfWeek(1);
    boolean var17 = var2.isOnOrAfter(var16);
    org.jfree.data.time.Day var18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var2);
    int var19 = var2.getYYYY();
    int var20 = var2.getDayOfWeek();
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(100);
    int var25 = var24.getDayOfMonth();
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(31);
    boolean var28 = var24.isBefore(var27);
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addMonths(1, var27);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var29);
    boolean var31 = var2.isAfter(var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-41893), (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var3 = var2.getDescription();
//     java.lang.Comparable var4 = var2.getKey();
//     var2.setMaximumItemAge(1412146800000L);
//     java.lang.String var7 = var2.getDescription();
//     java.lang.Class var8 = var2.getTimePeriodClass();
//     java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October 10", var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.String var11 = var10.toString();
//     java.util.Date var12 = var10.getEnd();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     java.util.TimeZone var14 = null;
//     org.jfree.data.time.RegularTimePeriod var15 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var12, var14);
//     java.util.TimeZone var16 = null;
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month(var12, var16);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
    org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var8.setMaximumItemCount(0);
    int var11 = var5.compareTo((java.lang.Object)var8);
    java.lang.Number var12 = var5.getValue();
    org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
    boolean var15 = var5.equals((java.lang.Object)var14);
    boolean var16 = var1.equals((java.lang.Object)var14);
    long var17 = var1.getFirstMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-457));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-571));

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     long var3 = var1.getLastMillisecond();
//     long var4 = var1.getLastMillisecond();
//     java.util.Date var5 = var1.getTime();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var5);
//     java.lang.String var7 = var6.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "December 1969"+ "'", var7.equals("December 1969"));
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(11, 6, 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.Object var7 = var1.clone();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 10.0d);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(10, var9);
//     org.jfree.data.time.Year var14 = var13.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     long var17 = var13.getLastMillisecond();
//     int var18 = var13.getYearValue();
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     java.lang.String var22 = var21.toString();
//     int var24 = var21.compareTo((java.lang.Object)"2014");
//     int var25 = var20.getIndex((org.jfree.data.time.RegularTimePeriod)var21);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var28 = var20.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     java.lang.String var31 = var30.toString();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(1, var30);
//     java.lang.Number var33 = var20.getValue((org.jfree.data.time.RegularTimePeriod)var32);
//     boolean var34 = var20.getNotify();
//     var20.setNotify(false);
//     boolean var37 = var13.equals((java.lang.Object)false);
//     org.jfree.data.time.RegularTimePeriod var38 = var13.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1414825199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "20-December-2014"+ "'", var22.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "2014"+ "'", var31.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + (-1)+ "'", var33.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-570));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     org.jfree.data.time.Year var5 = var3.getYear();
//     java.util.Calendar var6 = null;
//     var3.peg(var6);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     java.lang.String var2 = var1.toString();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(31, var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "20-December-2014"+ "'", var2.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var2 = null;
//     var1.addPropertyChangeListener(var2);
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     java.lang.String var7 = var6.toString();
//     int var9 = var6.compareTo((java.lang.Object)"2014");
//     int var10 = var5.getIndex((org.jfree.data.time.RegularTimePeriod)var6);
//     java.util.Date var11 = var6.getStart();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var14 = var13.getLastMillisecond();
//     java.util.Calendar var15 = null;
//     var13.peg(var15);
//     java.util.Calendar var17 = null;
//     long var18 = var13.getMiddleMillisecond(var17);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(10, 100);
//     boolean var22 = var13.equals((java.lang.Object)100);
//     org.jfree.data.time.TimeSeries var23 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var13);
//     java.util.Calendar var24 = null;
//     long var25 = var13.getMiddleMillisecond(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1L);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("28-February-1900");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(9, 28, (-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var11.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var11.removeChangeListener(var14);
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var18 = var17.getDescription();
//     java.lang.Comparable var19 = var17.getKey();
//     var17.setMaximumItemAge(1412146800000L);
//     java.lang.String var22 = var17.getDescription();
//     java.util.Collection var23 = var11.getTimePeriodsUniqueToOtherSeries(var17);
//     var17.setDomainDescription("ThreadContext");
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var28 = var27.getLastMillisecond();
//     long var29 = var27.getLastMillisecond();
//     long var30 = var27.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var31 = var27.previous();
//     org.jfree.data.time.TimeSeriesDataItem var33 = var17.addOrUpdate(var31, (java.lang.Number)1.0d);
//     org.jfree.data.time.TimeSeriesDataItem var35 = var1.addOrUpdate(var31, (java.lang.Number)(short)(-1));
//     var1.setMaximumItemAge(1404331199999L);
//     org.jfree.data.time.RegularTimePeriod var38 = var1.getNextTimePeriod();
//     java.lang.Object var39 = null;
//     boolean var40 = var1.equals(var39);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var42 = var1.getValue(9);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + (byte)100+ "'", var19.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.fireSeriesChanged();
    java.beans.PropertyChangeListener var5 = null;
    var1.removePropertyChangeListener(var5);
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    long var9 = var8.getLastMillisecond();
    long var10 = var8.getLastMillisecond();
    long var11 = var8.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var12 = var8.next();
    org.jfree.data.time.RegularTimePeriod var13 = var8.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var13, (java.lang.Number)28, false);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(2, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Feb"+ "'", var2.equals("Feb"));

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getMiddleMillisecond(var2);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    var4.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
    org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var10.setDomainDescription("January");
    var10.removeAgedItems(2014L, false);
    var10.setMaximumItemAge(0L);
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Following");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var11 = var2.next();
//     java.lang.String var12 = var2.toString();
//     java.util.Calendar var13 = null;
//     long var14 = var2.getFirstMillisecond(var13);
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     var1.setDomainDescription("hi!");
//     var1.setNotify(true);
//     var1.setDescription("ThreadContext");
//     org.jfree.data.time.RegularTimePeriod var33 = var1.getNextTimePeriod();
//     org.jfree.data.time.RegularTimePeriod var34 = var1.getNextTimePeriod();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setMaximumItemAge((-1L));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update(28, (java.lang.Number)(-57600000L));
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Calendar var4 = null;
    long var5 = var3.getFirstMillisecond(var4);
    int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
    java.lang.String var7 = var1.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update((-41893), (java.lang.Number)1414825199999L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, var4);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var2, var6);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     java.lang.String var27 = var22.getDescription();
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     java.lang.String var31 = var30.toString();
//     int var33 = var30.compareTo((java.lang.Object)"2014");
//     int var34 = var29.getIndex((org.jfree.data.time.RegularTimePeriod)var30);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var29.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     java.lang.String var40 = var39.toString();
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(1, var39);
//     java.lang.Number var42 = var29.getValue((org.jfree.data.time.RegularTimePeriod)var41);
//     long var43 = var41.getSerialIndex();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var22.update((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)(-62133062400001L));
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "20-December-2014"+ "'", var31.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "2014"+ "'", var40.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + (-1)+ "'", var42.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 24169L);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.Year var28 = var25.getYear();
//     java.lang.Object var29 = null;
//     int var30 = var25.compareTo(var29);
//     org.jfree.data.time.Year var31 = var25.getYear();
//     java.lang.Object var32 = null;
//     int var33 = var31.compareTo(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.time.TimePeriodFormatException: ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    java.lang.Object var6 = var1.clone();
    var1.setNotify(true);
    long var9 = var1.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var1.addChangeListener(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.Object var7 = var1.clone();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var9 = var1.getDataItem(2);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
    org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("hi!");
    java.lang.Throwable[] var4 = var3.getSuppressed();
    var1.addSuppressed((java.lang.Throwable)var3);
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    long var8 = var7.getLastMillisecond();
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 0.0d);
    org.jfree.data.time.RegularTimePeriod var12 = var11.getPeriod();
    org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var14.setMaximumItemCount(0);
    int var17 = var11.compareTo((java.lang.Object)var14);
    java.lang.Number var18 = var11.getValue();
    org.jfree.data.general.SeriesException var20 = new org.jfree.data.general.SeriesException("January");
    boolean var21 = var11.equals((java.lang.Object)var20);
    boolean var22 = var7.equals((java.lang.Object)var20);
    org.jfree.data.time.TimePeriodFormatException var24 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:00 PST 1969");
    var20.addSuppressed((java.lang.Throwable)var24);
    org.jfree.data.time.TimePeriodFormatException var27 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
    org.jfree.data.general.SeriesException var29 = new org.jfree.data.general.SeriesException("hi!");
    java.lang.Throwable[] var30 = var29.getSuppressed();
    var27.addSuppressed((java.lang.Throwable)var29);
    var24.addSuppressed((java.lang.Throwable)var27);
    var1.addSuppressed((java.lang.Throwable)var24);
    java.lang.String var34 = var24.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + 0.0d+ "'", var18.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969"+ "'", var34.equals("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969"));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var3 = var1.previous();
    java.util.Date var4 = var1.getTime();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     long var3 = var0.getLastMillisecond();
//     org.jfree.data.time.Year var4 = var0.getYear();
//     org.jfree.data.time.Year var5 = var0.getYear();
//     int var6 = var0.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     var7.removeAgedItems(true);
//     var7.setNotify(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var29 = var7.getTimePeriod((-41893));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     java.lang.String var7 = var1.getRangeDescription();
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.String var11 = var10.toString();
//     int var13 = var10.compareTo((java.lang.Object)"2014");
//     int var14 = var9.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.lang.String var20 = var19.toString();
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(1, var19);
//     java.lang.Number var22 = var9.getValue((org.jfree.data.time.RegularTimePeriod)var21);
//     boolean var23 = var9.getNotify();
//     boolean var24 = var9.isEmpty();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var28 = var27.getPeriod();
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var30.setMaximumItemCount(0);
//     int var33 = var27.compareTo((java.lang.Object)var30);
//     org.jfree.data.time.TimeSeries var34 = var9.addAndOrUpdate(var30);
//     org.jfree.data.time.TimeSeries var35 = var1.addAndOrUpdate(var30);
//     org.jfree.data.time.RegularTimePeriod var36 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var38 = var35.addOrUpdate(var36, 10.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "2014"+ "'", var20.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.time.Year var28 = var25.getYear();
//     java.lang.Object var29 = null;
//     int var30 = var25.compareTo(var29);
//     org.jfree.data.time.Year var31 = var25.getYear();
//     org.jfree.data.time.RegularTimePeriod var32 = var25.previous();
//     java.lang.String var33 = var25.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "January 2014"+ "'", var33.equals("January 2014"));
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("December 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     long var15 = var13.getSerialIndex();
//     int var16 = var13.getYearValue();
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var19 = var18.getDayOfMonth();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(100);
//     var24.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addMonths(1, var24);
//     org.jfree.data.time.SerialDate var28 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(100);
//     var33.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.addMonths(1, var33);
//     org.jfree.data.time.SerialDate var37 = var30.getEndOfCurrentMonth(var33);
//     org.jfree.data.time.SerialDate var38 = var28.getEndOfCurrentMonth(var33);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(100);
//     var43.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addMonths(1, var43);
//     org.jfree.data.time.SerialDate var47 = var40.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.FixedMillisecond var50 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var51 = var50.getStart();
//     org.jfree.data.time.FixedMillisecond var52 = new org.jfree.data.time.FixedMillisecond(var51);
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var51);
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addYears(0, var53);
//     org.jfree.data.time.SerialDate var56 = var54.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var57 = var47.getEndOfCurrentMonth(var56);
//     boolean var59 = var18.isInRange(var38, var47, (-453));
//     boolean var60 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)var59);
//     java.util.Calendar var61 = null;
//     long var62 = var13.getFirstMillisecond(var61);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    var1.setDomainDescription("Following");
    org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var8 = var7.next();
    org.jfree.data.time.RegularTimePeriod var9 = var7.next();
    int var10 = var1.getIndex(var9);
    java.lang.Object var11 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("October 10");

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var7 = var6.getMonth();
//     int var8 = var6.toSerial();
//     boolean var9 = var1.isBefore((org.jfree.data.time.SerialDate)var6);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var11.setMaximumItemCount(0);
//     var11.clear();
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var17 = var16.getLastMillisecond();
//     long var18 = var16.getLastMillisecond();
//     long var19 = var16.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var16.previous();
//     java.util.Calendar var21 = null;
//     long var22 = var16.getFirstMillisecond(var21);
//     org.jfree.data.time.TimeSeriesDataItem var24 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (-1.0d));
//     var11.removeAgedItems(0L, true);
//     var11.setMaximumItemCount(0);
//     boolean var30 = var1.equals((java.lang.Object)0);
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var34 = var33.getDayOfMonth();
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var37 = var33.isBefore(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var33);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var41 = var40.getMonth();
//     int var42 = var40.toSerial();
//     int var43 = var40.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var47 = var46.getDayOfMonth();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var50 = var46.isBefore(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var46);
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day();
//     boolean var54 = var52.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var55 = var52.next();
//     long var56 = var52.getLastMillisecond();
//     java.lang.String var57 = var52.toString();
//     org.jfree.data.time.SerialDate var58 = var52.getSerialDate();
//     boolean var59 = var46.isOn(var58);
//     boolean var60 = var40.isAfter(var58);
//     int var61 = var33.compare(var58);
//     org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var64 = var63.getMonth();
//     int var65 = var63.toSerial();
//     int var66 = var63.toSerial();
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var69 = var68.getMonth();
//     int var70 = var68.toSerial();
//     boolean var71 = var63.isBefore((org.jfree.data.time.SerialDate)var68);
//     org.jfree.data.time.TimeSeries var73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var73.setMaximumItemCount(0);
//     var73.clear();
//     org.jfree.data.time.FixedMillisecond var78 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var79 = var78.getLastMillisecond();
//     long var80 = var78.getLastMillisecond();
//     long var81 = var78.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var82 = var78.previous();
//     java.util.Calendar var83 = null;
//     long var84 = var78.getFirstMillisecond(var83);
//     org.jfree.data.time.TimeSeriesDataItem var86 = var73.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var78, (-1.0d));
//     var73.removeAgedItems(0L, true);
//     var73.setMaximumItemCount(0);
//     boolean var92 = var63.equals((java.lang.Object)0);
//     org.jfree.data.time.SerialDate var93 = var58.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var63);
//     boolean var94 = var1.isBefore(var58);
//     java.lang.String var95 = var1.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "20-December-2014"+ "'", var57.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == (-41893));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var95 + "' != '" + "11-January-1900"+ "'", var95.equals("11-January-1900"));
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var1);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var5 = null;
//     var4.peg(var5);
//     long var7 = var4.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var4.previous();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate(var8, 0.0d);
//     java.lang.String var11 = var2.getDomainDescription();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var13.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var13.addChangeListener(var16);
//     var13.setKey((java.lang.Comparable)'4');
//     boolean var20 = var13.getNotify();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     java.lang.String var24 = var23.toString();
//     int var26 = var23.compareTo((java.lang.Object)"2014");
//     int var27 = var22.getIndex((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var30 = var22.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     java.lang.String var33 = var32.toString();
//     org.jfree.data.time.Month var34 = new org.jfree.data.time.Month(1, var32);
//     java.lang.Number var35 = var22.getValue((org.jfree.data.time.RegularTimePeriod)var34);
//     boolean var36 = var22.getNotify();
//     boolean var37 = var22.isEmpty();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var38, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var41 = var40.getPeriod();
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var43.setMaximumItemCount(0);
//     int var46 = var40.compareTo((java.lang.Object)var43);
//     org.jfree.data.time.TimeSeries var47 = var22.addAndOrUpdate(var43);
//     var22.setDomainDescription("hi!");
//     org.jfree.data.time.TimeSeries var50 = var13.addAndOrUpdate(var22);
//     java.util.Collection var51 = var2.getTimePeriodsUniqueToOtherSeries(var13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var53 = var13.getValue(5);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Time"+ "'", var11.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "20-December-2014"+ "'", var24.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "2014"+ "'", var33.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + (-1)+ "'", var35.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-571));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.util.Date var7 = var2.getStart();
//     int var8 = var2.getMonth();
//     int var9 = var2.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 20);
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.util.List var7 = var1.getItems();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.lang.Comparable var3 = var1.getKey();
    var1.setMaximumItemAge(1412146800000L);
    java.beans.PropertyChangeListener var6 = null;
    var1.removePropertyChangeListener(var6);
    java.beans.PropertyChangeListener var8 = null;
    var1.addPropertyChangeListener(var8);
    java.util.Collection var10 = var1.getTimePeriods();
    org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var12.setMaximumItemCount(0);
    int var15 = var12.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var16 = null;
    var12.removeChangeListener(var16);
    java.lang.String var18 = var12.getRangeDescription();
    org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
    var12.delete((org.jfree.data.time.RegularTimePeriod)var19);
    org.jfree.data.time.RegularTimePeriod var21 = var19.next();
    java.util.Date var22 = var19.getTime();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var19);
    java.util.Calendar var24 = null;
    var19.peg(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "Value"+ "'", var18.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var26 = var25.getDescription();
//     java.util.List var27 = var25.getItems();
//     var25.setMaximumItemAge(2014L);
//     java.util.Collection var30 = var7.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, 10.0d);
//     java.lang.Object var35 = var34.clone();
//     boolean var36 = var25.equals((java.lang.Object)var34);
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var39 = var38.next();
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var38, 10.0d);
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month(10, var38);
//     org.jfree.data.time.Year var43 = var42.getYear();
//     org.jfree.data.time.RegularTimePeriod var44 = var43.previous();
//     long var45 = var43.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var47.setMaximumItemCount(0);
//     org.jfree.data.time.Year var51 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var52 = var51.next();
//     org.jfree.data.time.TimeSeriesDataItem var54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var51, 10.0d);
//     org.jfree.data.time.Month var55 = new org.jfree.data.time.Month(10, var51);
//     org.jfree.data.time.RegularTimePeriod var56 = var51.next();
//     var47.delete((org.jfree.data.time.RegularTimePeriod)var51);
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var60 = new org.jfree.data.time.Day();
//     java.lang.String var61 = var60.toString();
//     int var63 = var60.compareTo((java.lang.Object)"2014");
//     int var64 = var59.getIndex((org.jfree.data.time.RegularTimePeriod)var60);
//     org.jfree.data.time.Day var65 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var67 = var59.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var65, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var69 = new org.jfree.data.time.Year();
//     java.lang.String var70 = var69.toString();
//     org.jfree.data.time.Month var71 = new org.jfree.data.time.Month(1, var69);
//     java.lang.Number var72 = var59.getValue((org.jfree.data.time.RegularTimePeriod)var71);
//     boolean var73 = var51.equals((java.lang.Object)var71);
//     org.jfree.data.time.FixedMillisecond var75 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var76 = var75.getLastMillisecond();
//     long var77 = var75.getLastMillisecond();
//     long var78 = var75.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var79 = var75.previous();
//     int var80 = var51.compareTo((java.lang.Object)var75);
//     boolean var81 = var43.equals((java.lang.Object)var51);
//     org.jfree.data.time.RegularTimePeriod var82 = var51.previous();
//     var25.delete(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "20-December-2014"+ "'", var61.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var70 + "' != '" + "2014"+ "'", var70.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var72 + "' != '" + (-1)+ "'", var72.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     java.lang.String var5 = var1.getDomainDescription();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, var7);
//     boolean var10 = var1.equals((java.lang.Object)var7);
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var12.setMaximumItemCount(0);
//     int var15 = var12.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var12.removeChangeListener(var16);
//     java.beans.PropertyChangeListener var18 = null;
//     var12.removePropertyChangeListener(var18);
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)var12);
//     org.jfree.data.time.RegularTimePeriod var21 = var7.next();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, 100.0d);
//     long var24 = var7.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "Time"+ "'", var5.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2014"+ "'", var8.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2014L);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(100);
    int var3 = var2.getDayOfMonth();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(31);
    boolean var6 = var2.isBefore(var5);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(100);
    var11.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(1, var11);
    org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var11);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(100);
    var20.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addMonths(1, var20);
    org.jfree.data.time.SerialDate var24 = var17.getEndOfCurrentMonth(var20);
    org.jfree.data.time.SerialDate var25 = var15.getEndOfCurrentMonth(var20);
    org.jfree.data.time.Day var26 = new org.jfree.data.time.Day(var15);
    java.lang.String var27 = var26.toString();
    org.jfree.data.time.SerialDate var28 = var26.getSerialDate();
    int var29 = var2.compare(var28);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, (org.jfree.data.time.SerialDate)var2);
    java.lang.String var31 = var30.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "30-April-1900"+ "'", var27.equals("30-April-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-21));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     int var4 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var5 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem(var5, 10.0d);
//     java.lang.Object var8 = var7.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-598));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var2);
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2, var4);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    java.lang.Class var2 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var7 = var4.createCopy(0, 0);
    java.lang.Class var8 = var7.getTimePeriodClass();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var2, var8);
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var14 = var11.createCopy(0, 0);
    java.lang.Class var15 = var14.getTimePeriodClass();
    org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var18 = var17.getStart();
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
    java.util.TimeZone var20 = null;
    org.jfree.data.time.RegularTimePeriod var21 = org.jfree.data.time.RegularTimePeriod.createInstance(var15, var18, var20);
    java.util.TimeZone var22 = null;
    org.jfree.data.time.RegularTimePeriod var23 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var18, var22);
    java.lang.Class var24 = org.jfree.data.time.RegularTimePeriod.downsize(var8);
    java.io.InputStream var25 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("December", var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-88), 2, 28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Value");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.previous();
//     java.util.Date var4 = var1.getTime();
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var4, var5);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var4 = null;
//     long var5 = var3.getFirstMillisecond(var4);
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
//     java.util.Date var7 = var3.getTime();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var7);
//     java.util.TimeZone var10 = null;
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var7, var10);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var7 = var6.getMonth();
//     int var8 = var6.toSerial();
//     boolean var9 = var1.isBefore((org.jfree.data.time.SerialDate)var6);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var11.setMaximumItemCount(0);
//     var11.clear();
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var17 = var16.getLastMillisecond();
//     long var18 = var16.getLastMillisecond();
//     long var19 = var16.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var16.previous();
//     java.util.Calendar var21 = null;
//     long var22 = var16.getFirstMillisecond(var21);
//     org.jfree.data.time.TimeSeriesDataItem var24 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (-1.0d));
//     var11.removeAgedItems(0L, true);
//     var11.setMaximumItemCount(0);
//     boolean var30 = var1.equals((java.lang.Object)0);
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var34 = var33.getDayOfMonth();
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var37 = var33.isBefore(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var33);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var41 = var40.getMonth();
//     int var42 = var40.toSerial();
//     int var43 = var40.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var47 = var46.getDayOfMonth();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var50 = var46.isBefore(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var46);
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day();
//     boolean var54 = var52.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var55 = var52.next();
//     long var56 = var52.getLastMillisecond();
//     java.lang.String var57 = var52.toString();
//     org.jfree.data.time.SerialDate var58 = var52.getSerialDate();
//     boolean var59 = var46.isOn(var58);
//     boolean var60 = var40.isAfter(var58);
//     int var61 = var33.compare(var58);
//     org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var64 = var63.getMonth();
//     int var65 = var63.toSerial();
//     int var66 = var63.toSerial();
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var69 = var68.getMonth();
//     int var70 = var68.toSerial();
//     boolean var71 = var63.isBefore((org.jfree.data.time.SerialDate)var68);
//     org.jfree.data.time.TimeSeries var73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var73.setMaximumItemCount(0);
//     var73.clear();
//     org.jfree.data.time.FixedMillisecond var78 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var79 = var78.getLastMillisecond();
//     long var80 = var78.getLastMillisecond();
//     long var81 = var78.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var82 = var78.previous();
//     java.util.Calendar var83 = null;
//     long var84 = var78.getFirstMillisecond(var83);
//     org.jfree.data.time.TimeSeriesDataItem var86 = var73.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var78, (-1.0d));
//     var73.removeAgedItems(0L, true);
//     var73.setMaximumItemCount(0);
//     boolean var92 = var63.equals((java.lang.Object)0);
//     org.jfree.data.time.SerialDate var93 = var58.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var63);
//     boolean var94 = var1.isBefore(var58);
//     org.jfree.data.time.Day var95 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "20-December-2014"+ "'", var57.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == (-41893));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == true);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(100);
    var6.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(1, var6);
    org.jfree.data.time.SerialDate var10 = var3.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(100);
    var15.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.SerialDate var19 = var12.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var20 = var10.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
    org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(100);
    var24.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addMonths(1, var24);
    org.jfree.data.time.SerialDate var28 = var15.getEndOfCurrentMonth(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(28, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    var4.setDescription("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Third"+ "'", var1.equals("Third"));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(28, (-88), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var2, var6);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     long var4 = var0.getLastMillisecond();
//     int var5 = var0.getDayOfMonth();
//     long var6 = var0.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setMaximumItemCount(0);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 10.0d);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(10, var12);
//     org.jfree.data.time.RegularTimePeriod var17 = var12.next();
//     var8.delete((org.jfree.data.time.RegularTimePeriod)var12);
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     java.lang.String var22 = var21.toString();
//     int var24 = var21.compareTo((java.lang.Object)"2014");
//     int var25 = var20.getIndex((org.jfree.data.time.RegularTimePeriod)var21);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var28 = var20.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     java.lang.String var31 = var30.toString();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(1, var30);
//     java.lang.Number var33 = var20.getValue((org.jfree.data.time.RegularTimePeriod)var32);
//     boolean var34 = var12.equals((java.lang.Object)var32);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var37 = var36.getLastMillisecond();
//     long var38 = var36.getLastMillisecond();
//     long var39 = var36.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var40 = var36.previous();
//     int var41 = var12.compareTo((java.lang.Object)var36);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     java.lang.String var43 = var42.toString();
//     java.util.Date var44 = var42.getEnd();
//     org.jfree.data.time.Month var45 = new org.jfree.data.time.Month(var44);
//     org.jfree.data.time.Month var46 = new org.jfree.data.time.Month(var44);
//     int var47 = var36.compareTo((java.lang.Object)var46);
//     int var48 = var0.compareTo((java.lang.Object)var46);
//     java.util.Calendar var49 = null;
//     long var50 = var0.getMiddleMillisecond(var49);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var3.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var6 = null;
//     var3.addChangeListener(var6);
//     long var8 = var3.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     int var18 = var11.getMonth();
//     int var19 = var11.getDayOfMonth();
//     int var20 = var11.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var21 = var11.previous();
//     var3.add(var21, 100.0d, true);
//     var3.setDescription("Time");
//     java.util.Collection var27 = var1.getTimePeriodsUniqueToOtherSeries(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addYears(0, var5);
//     java.lang.String var7 = var6.toString();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(100, var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "31-December-1969"+ "'", var7.equals("31-December-1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var6 = var3.createCopy(0, 0);
//     java.lang.Class var7 = var6.getTimePeriodClass();
//     java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var1, var7);
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var13 = var10.createCopy(0, 0);
//     java.lang.Class var14 = var13.getTimePeriodClass();
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var17 = var16.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     java.util.TimeZone var19 = null;
//     org.jfree.data.time.RegularTimePeriod var20 = org.jfree.data.time.RegularTimePeriod.createInstance(var14, var17, var19);
//     java.util.TimeZone var21 = null;
//     org.jfree.data.time.RegularTimePeriod var22 = org.jfree.data.time.RegularTimePeriod.createInstance(var7, var17, var21);
//     java.util.TimeZone var23 = null;
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(var17, var23);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-41893));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     java.util.Calendar var3 = null;
//     var1.peg(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getMiddleMillisecond(var5);
//     java.util.Calendar var7 = null;
//     long var8 = var1.getFirstMillisecond(var7);
//     java.util.Date var9 = var1.getTime();
//     java.util.TimeZone var10 = null;
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var9, var10);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }
// 
// 
//     org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("");
//     java.lang.Throwable var2 = null;
//     var1.addSuppressed(var2);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     var1.setDomainDescription("hi!");
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var33 = var30.createCopy(0, 0);
//     org.jfree.data.time.TimeSeries var34 = var1.addAndOrUpdate(var33);
//     java.lang.String var35 = var33.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var38 = var37.getLastMillisecond();
//     long var39 = var37.getLastMillisecond();
//     long var40 = var37.getLastMillisecond();
//     java.util.Calendar var41 = null;
//     long var42 = var37.getLastMillisecond(var41);
//     org.jfree.data.time.TimeSeriesDataItem var44 = var33.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)10L);
//     org.jfree.data.time.Month var45 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var45, 0.0d);
//     long var48 = var45.getLastMillisecond();
//     org.jfree.data.time.Year var49 = var45.getYear();
//     long var50 = var45.getLastMillisecond();
//     int var51 = var45.getMonth();
//     org.jfree.data.time.Year var52 = var45.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var33.add((org.jfree.data.time.RegularTimePeriod)var52, 10.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "Value"+ "'", var35.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    long var3 = var1.getFirstMillisecond();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var6 = var5.getDescription();
    java.lang.Comparable var7 = var5.getKey();
    var5.setMaximumItemAge(1412146800000L);
    boolean var10 = var1.equals((java.lang.Object)1412146800000L);
    java.util.Calendar var11 = null;
    long var12 = var1.getLastMillisecond(var11);
    java.util.Calendar var13 = null;
    long var14 = var1.getMiddleMillisecond(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)100+ "'", var7.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Calendar var2 = null;
    var1.peg(var2);
    long var4 = var1.getSerialIndex();
    org.jfree.data.time.RegularTimePeriod var5 = var1.previous();
    java.util.Calendar var6 = null;
    var1.peg(var6);
    java.util.Calendar var8 = null;
    long var9 = var1.getFirstMillisecond(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10L);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
    java.util.TimeZone var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var2, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    long var4 = var3.getMiddleMillisecond();
    long var5 = var3.getSerialIndex();
    java.util.Date var6 = var3.getTime();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var7.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     var1.removeAgedItems(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setMaximumItemCount((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.lang.String var3 = var2.toString();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(1, var2);
//     org.jfree.data.time.Year var5 = var4.getYear();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(7, var5);
//     java.util.Calendar var7 = null;
//     var6.peg(var7);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     var1.clear();
//     var1.fireSeriesChanged();
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var11 = var10.getStart();
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var11);
//     org.jfree.data.time.TimeSeriesDataItem var15 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     boolean var20 = var18.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var21 = var18.next();
//     long var22 = var18.getLastMillisecond();
//     int var23 = var18.getDayOfMonth();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var26 = var25.next();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 10.0d);
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(10, var25);
//     org.jfree.data.time.Year var30 = var29.getYear();
//     long var31 = var29.getFirstMillisecond();
//     java.lang.String var32 = var29.toString();
//     org.jfree.data.time.Year var33 = var29.getYear();
//     boolean var34 = var18.equals((java.lang.Object)var33);
//     org.jfree.data.time.TimeSeriesDataItem var35 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     long var36 = var18.getFirstMillisecond();
//     java.util.Calendar var37 = null;
//     long var38 = var18.getLastMillisecond(var37);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     java.lang.String var7 = var1.getRangeDescription();
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.String var11 = var10.toString();
//     int var13 = var10.compareTo((java.lang.Object)"2014");
//     int var14 = var9.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.lang.String var20 = var19.toString();
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(1, var19);
//     java.lang.Number var22 = var9.getValue((org.jfree.data.time.RegularTimePeriod)var21);
//     boolean var23 = var9.getNotify();
//     boolean var24 = var9.isEmpty();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var28 = var27.getPeriod();
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var30.setMaximumItemCount(0);
//     int var33 = var27.compareTo((java.lang.Object)var30);
//     org.jfree.data.time.TimeSeries var34 = var9.addAndOrUpdate(var30);
//     org.jfree.data.time.TimeSeries var35 = var1.addAndOrUpdate(var30);
//     org.jfree.data.time.RegularTimePeriod var36 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var37 = var30.getIndex(var36);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "2014"+ "'", var20.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.addPropertyChangeListener(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var7 = var2.createCopy((-457), (-100));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     var1.setNotify(false);
//     boolean var18 = var1.getNotify();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var20 = var1.getValue((-452));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     java.lang.Number var9 = var8.getValue();
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.String var13 = var12.toString();
//     int var15 = var12.compareTo((java.lang.Object)"2014");
//     int var16 = var11.getIndex((org.jfree.data.time.RegularTimePeriod)var12);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     java.lang.String var22 = var21.toString();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(1, var21);
//     java.lang.Number var24 = var11.getValue((org.jfree.data.time.RegularTimePeriod)var23);
//     var11.setMaximumItemCount(100);
//     int var27 = var8.compareTo((java.lang.Object)var11);
//     java.lang.Object var28 = var8.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (-1.0d)+ "'", var9.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "2014"+ "'", var22.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + (-1)+ "'", var24.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getDayOfMonth();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var19 = var16.createCopy(0, 0);
//     java.lang.Class var20 = var19.getTimePeriodClass();
//     java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var14, var20);
//     java.io.InputStream var22 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var20);
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, var20);
//     java.beans.PropertyChangeListener var24 = null;
//     var23.addPropertyChangeListener(var24);
//     org.jfree.data.general.SeriesChangeEvent var26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var23);
//     java.lang.String var27 = var26.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var1.removeChangeListener(var31);
//     org.jfree.data.general.SeriesChangeListener var33 = null;
//     var1.removeChangeListener(var33);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     java.lang.String var37 = var36.toString();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(1, var36);
//     org.jfree.data.time.Year var39 = var38.getYear();
//     long var40 = var38.getLastMillisecond();
//     long var41 = var38.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var42 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var38);
//     org.jfree.data.time.FixedMillisecond var44 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var45 = var44.getLastMillisecond();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var44);
//     org.jfree.data.time.Month var47 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var50 = var49.getPeriod();
//     java.util.Date var51 = var50.getEnd();
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day(var51);
//     long var53 = var52.getFirstMillisecond();
//     boolean var54 = var44.equals((java.lang.Object)var52);
//     org.jfree.data.time.FixedMillisecond var58 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var59 = var58.getStart();
//     org.jfree.data.time.FixedMillisecond var60 = new org.jfree.data.time.FixedMillisecond(var59);
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.createInstance(var59);
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.addYears(0, var61);
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.addDays(1969, var62);
//     org.jfree.data.time.Day var64 = new org.jfree.data.time.Day(var62);
//     int var65 = var44.compareTo((java.lang.Object)var64);
//     java.util.Calendar var66 = null;
//     long var67 = var44.getFirstMillisecond(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "2014"+ "'", var37.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1391241599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1420012800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1L);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     var1.setDomainDescription("hi!");
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var33 = var30.createCopy(0, 0);
//     org.jfree.data.time.TimeSeries var34 = var1.addAndOrUpdate(var33);
//     boolean var35 = var1.isEmpty();
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var37 = var36.next();
//     org.jfree.data.time.TimeSeriesDataItem var39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var36, 10.0d);
//     org.jfree.data.time.Month var40 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var40, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var43 = var42.getPeriod();
//     boolean var44 = var39.equals((java.lang.Object)var43);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var39);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
// 
//   }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var8 = var7.getDescription();
//     java.lang.Comparable var9 = var7.getKey();
//     var7.setMaximumItemAge(1412146800000L);
//     java.lang.String var12 = var7.getDescription();
//     java.lang.Class var13 = var7.getTimePeriodClass();
//     java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var13);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     java.lang.String var16 = var15.toString();
//     java.util.Date var17 = var15.getEnd();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var17, var19);
//     java.util.TimeZone var21 = null;
//     org.jfree.data.time.RegularTimePeriod var22 = org.jfree.data.time.RegularTimePeriod.createInstance(var13, var17, var21);
//     java.io.InputStream var23 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var13);
//     java.io.InputStream var24 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sunday", var13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries(var0, "November", "2013", var13);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "20-December-2014"+ "'", var16.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
// 
//   }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var2.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var2.addChangeListener(var5);
//     var2.setKey((java.lang.Comparable)'4');
//     boolean var9 = var2.getNotify();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var12 = var11.getTime();
//     java.util.Calendar var13 = null;
//     long var14 = var11.getFirstMillisecond(var13);
//     var2.setKey((java.lang.Comparable)var11);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 10.0d);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(10, var17);
//     org.jfree.data.time.RegularTimePeriod var22 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(100);
//     var27.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.addMonths(1, var27);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.addMonths(12, var27);
//     int var32 = var17.compareTo((java.lang.Object)12);
//     long var33 = var17.getSerialIndex();
//     org.jfree.data.time.Month var34 = new org.jfree.data.time.Month(9, var17);
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)9);
//     boolean var36 = var35.getNotify();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     java.lang.String var27 = var22.getDescription();
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, 0.0d);
//     long var31 = var28.getMiddleMillisecond();
//     var22.delete((org.jfree.data.time.RegularTimePeriod)var28);
//     java.lang.String var33 = var28.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "December 2014"+ "'", var33.equals("December 2014"));
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var6 = var5.getStart();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(var6);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var6);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(0, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(0, var8);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths((-453), var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-88), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
    int var2 = var1.getDayOfMonth();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    var7.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
    org.jfree.data.time.SerialDate var11 = var4.getEndOfCurrentMonth(var7);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(100);
    var16.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addMonths(1, var16);
    org.jfree.data.time.SerialDate var20 = var13.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var21 = var11.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(100);
    var26.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addMonths(1, var26);
    org.jfree.data.time.SerialDate var30 = var23.getEndOfCurrentMonth(var26);
    org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var34 = var33.getStart();
    org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(var34);
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(var34);
    org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addYears(0, var36);
    org.jfree.data.time.SerialDate var39 = var37.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var40 = var30.getEndOfCurrentMonth(var39);
    boolean var42 = var1.isInRange(var21, var30, (-453));
    org.jfree.data.time.SerialDate var44 = var30.getNearestDayOfWeek(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(5, 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=11-January-1900]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.util.Collection var7 = var1.getTimePeriods();
//     java.beans.PropertyChangeListener var8 = null;
//     var1.removePropertyChangeListener(var8);
//     int var10 = var1.getMaximumItemCount();
//     java.lang.Object var11 = var1.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("20-December-2014");
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.general.SeriesException: 20-December-2014"+ "'", var2.equals("org.jfree.data.general.SeriesException: 20-December-2014"));

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     long var7 = var6.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var6.next();
//     boolean var9 = var1.equals((java.lang.Object)var6);
//     org.jfree.data.time.RegularTimePeriod var10 = var6.next();
//     java.util.Calendar var11 = null;
//     var6.peg(var11);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var3 = var2.getDescription();
    java.lang.Comparable var4 = var2.getKey();
    var2.setMaximumItemAge(1412146800000L);
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var8 = var2.getTimePeriodClass();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var8);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
    long var12 = var11.getLastMillisecond();
    long var13 = var11.getLastMillisecond();
    long var14 = var11.getLastMillisecond();
    java.util.Date var15 = var11.getTime();
    java.lang.Class var20 = null;
    org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var25 = var22.createCopy(0, 0);
    java.lang.Class var26 = var25.getTimePeriodClass();
    java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var20, var26);
    java.io.InputStream var28 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var26);
    org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var15, "30-April-1900", "December", var26);
    java.util.TimeZone var30 = null;
    org.jfree.data.time.RegularTimePeriod var31 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var15, var30);
    java.util.TimeZone var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var33 = new org.jfree.data.time.Day(var15, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
//     var4.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
//     org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
//     var13.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var13);
//     org.jfree.data.time.SerialDate var17 = var10.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.SerialDate var18 = var8.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.SerialDate var19 = null;
//     org.jfree.data.time.SerialDate var20 = var8.getEndOfCurrentMonth(var19);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     java.lang.String var27 = var26.toString();
//     int var29 = var26.compareTo((java.lang.Object)"2014");
//     int var30 = var25.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     int var31 = var26.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var26);
//     long var33 = var26.getSerialIndex();
//     java.util.Calendar var34 = null;
//     long var35 = var26.getFirstMillisecond(var34);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     long var3 = var0.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1388563200000L);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.util.Collection var7 = var1.getTimePeriods();
//     java.lang.String var8 = var1.getDomainDescription();
//     java.util.List var9 = var1.getItems();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "Time"+ "'", var8.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    java.util.Date var4 = var3.getEnd();
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var4);
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var4);
    org.jfree.data.time.RegularTimePeriod var7 = var6.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var5.setMaximumItemCount(0);
    int var8 = var2.compareTo((java.lang.Object)var5);
    java.lang.Number var9 = var2.getValue();
    java.lang.Number var10 = var2.getValue();
    org.jfree.data.time.RegularTimePeriod var11 = var2.getPeriod();
    org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1L);
    long var14 = var13.getLastMillisecond();
    java.util.Calendar var15 = null;
    var13.peg(var15);
    long var17 = var13.getMiddleMillisecond();
    long var18 = var13.getLastMillisecond();
    java.util.Calendar var19 = null;
    var13.peg(var19);
    int var21 = var2.compareTo((java.lang.Object)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0.0d+ "'", var9.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0d+ "'", var10.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.removeChangeListener(var4);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var8 = null;
//     var7.addPropertyChangeListener(var8);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.String var13 = var12.toString();
//     int var15 = var12.compareTo((java.lang.Object)"2014");
//     int var16 = var11.getIndex((org.jfree.data.time.RegularTimePeriod)var12);
//     var11.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     java.lang.String var22 = var21.toString();
//     int var24 = var21.compareTo((java.lang.Object)"2014");
//     int var25 = var20.getIndex((org.jfree.data.time.RegularTimePeriod)var21);
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     var11.add(var27, true);
//     var27.setValue((java.lang.Number)0.0d);
//     java.lang.Object var32 = null;
//     boolean var33 = var27.equals(var32);
//     var7.add(var27, false);
//     var1.add(var27);
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var39.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var42 = null;
//     var39.addChangeListener(var42);
//     var39.setKey((java.lang.Comparable)'4');
//     boolean var46 = var39.getNotify();
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var49 = var48.getTime();
//     java.util.Calendar var50 = null;
//     long var51 = var48.getFirstMillisecond(var50);
//     var39.setKey((java.lang.Comparable)var48);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var55 = var54.next();
//     org.jfree.data.time.TimeSeriesDataItem var57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, 10.0d);
//     org.jfree.data.time.Month var58 = new org.jfree.data.time.Month(10, var54);
//     org.jfree.data.time.RegularTimePeriod var59 = var54.next();
//     org.jfree.data.time.TimeSeriesDataItem var60 = var39.getDataItem((org.jfree.data.time.RegularTimePeriod)var54);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.createInstance(100);
//     var64.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.addMonths(1, var64);
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.addMonths(12, var64);
//     int var69 = var54.compareTo((java.lang.Object)12);
//     long var70 = var54.getSerialIndex();
//     org.jfree.data.time.Month var71 = new org.jfree.data.time.Month(9, var54);
//     java.lang.Number var72 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var54);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var74 = var1.getValue((-571));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "20-December-2014"+ "'", var22.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var72 + "' != '" + 0.0d+ "'", var72.equals(0.0d));
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var8 = var7.getDescription();
    java.lang.Comparable var9 = var7.getKey();
    var7.setMaximumItemAge(1412146800000L);
    java.lang.String var12 = var7.getDescription();
    java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
    var7.setDomainDescription("ThreadContext");
    org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
    long var18 = var17.getLastMillisecond();
    long var19 = var17.getLastMillisecond();
    long var20 = var17.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var21 = var17.previous();
    org.jfree.data.time.TimeSeriesDataItem var23 = var7.addOrUpdate(var21, (java.lang.Number)1.0d);
    java.util.List var24 = var7.getItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 100);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setMaximumItemCount(0);
//     int var11 = var5.compareTo((java.lang.Object)var8);
//     java.lang.Number var12 = var5.getValue();
//     org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
//     boolean var15 = var5.equals((java.lang.Object)var14);
//     int var16 = var2.compareTo((java.lang.Object)var5);
//     long var17 = var2.getFirstMillisecond();
//     java.lang.Object var18 = null;
//     boolean var19 = var2.equals(var18);
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var21.setDomainDescription("January");
//     var21.removeAgedItems(2014L, false);
//     var21.setMaximumItemAge(0L);
//     java.util.List var29 = var21.getItems();
//     boolean var30 = var2.equals((java.lang.Object)var21);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var21.update((-21), (java.lang.Number)(byte)10);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-58987929600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(31, (-598), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    java.lang.Object var0 = null;
    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var3 = var1.previous();
    java.util.Date var4 = var1.getTime();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setKey((java.lang.Comparable)'4');
    boolean var8 = var1.getNotify();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var11 = var10.getTime();
    java.util.Calendar var12 = null;
    long var13 = var10.getFirstMillisecond(var12);
    var1.setKey((java.lang.Comparable)var10);
    org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var17 = var16.next();
    org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
    org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
    org.jfree.data.time.RegularTimePeriod var21 = var16.next();
    org.jfree.data.time.TimeSeriesDataItem var22 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var16);
    java.lang.String var23 = var1.getRangeDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "Value"+ "'", var23.equals("Value"));

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(3, 12, 2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var4 = var3.getDescription();
//     java.lang.Comparable var5 = var3.getKey();
//     var3.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.String var11 = var10.toString();
//     int var13 = var10.compareTo((java.lang.Object)"2014");
//     int var14 = var9.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     java.lang.Object var15 = var9.clone();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 10.0d);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(10, var17);
//     org.jfree.data.time.Year var22 = var21.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     java.util.Collection var25 = var3.getTimePeriodsUniqueToOtherSeries(var9);
//     boolean var26 = var3.isEmpty();
//     java.lang.Class var27 = var3.getTimePeriodClass();
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(var30);
//     java.util.TimeZone var32 = null;
//     org.jfree.data.time.RegularTimePeriod var33 = org.jfree.data.time.RegularTimePeriod.createInstance(var27, var30, var32);
//     java.lang.Object var34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var27);
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var42 = var41.getDescription();
//     java.lang.Comparable var43 = var41.getKey();
//     var41.setMaximumItemAge(1412146800000L);
//     java.lang.String var46 = var41.getDescription();
//     java.lang.Class var47 = var41.getTimePeriodClass();
//     java.lang.Object var48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var47);
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     java.lang.String var50 = var49.toString();
//     java.util.Date var51 = var49.getEnd();
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month(var51);
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var51, var53);
//     java.util.TimeZone var55 = null;
//     org.jfree.data.time.RegularTimePeriod var56 = org.jfree.data.time.RegularTimePeriod.createInstance(var47, var51, var55);
//     java.io.InputStream var57 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var47);
//     java.io.InputStream var58 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sunday", var47);
//     java.io.InputStream var59 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var47);
//     java.lang.Object var60 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969", var47);
//     java.lang.Object var61 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var27, var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + (byte)100+ "'", var5.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + (byte)100+ "'", var43.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "20-December-2014"+ "'", var50.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var61);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var12 = var2.previous();
//     long var13 = var2.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var2.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     var1.setNotify(false);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     var19.clear();
//     java.lang.String var23 = var19.getDomainDescription();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     java.lang.String var26 = var25.toString();
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(1, var25);
//     boolean var28 = var19.equals((java.lang.Object)var25);
//     int var30 = var25.compareTo((java.lang.Object)(short)1);
//     java.lang.String var31 = var25.toString();
//     long var32 = var25.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     java.lang.String var36 = var35.toString();
//     int var38 = var35.compareTo((java.lang.Object)"2014");
//     int var39 = var34.getIndex((org.jfree.data.time.RegularTimePeriod)var35);
//     java.lang.Object var40 = var34.clone();
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var42, 10.0d);
//     org.jfree.data.time.Month var46 = new org.jfree.data.time.Month(10, var42);
//     org.jfree.data.time.Year var47 = var46.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var49 = var34.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var46, (-1.0d));
//     org.jfree.data.time.TimeSeries var51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var51.setMaximumItemCount(0);
//     int var54 = var51.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var55 = null;
//     var51.removeChangeListener(var55);
//     java.lang.String var57 = var51.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var58 = new org.jfree.data.time.FixedMillisecond();
//     var51.delete((org.jfree.data.time.RegularTimePeriod)var58);
//     org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var61.setMaximumItemCount(0);
//     int var64 = var61.getMaximumItemCount();
//     java.util.Collection var65 = var51.getTimePeriodsUniqueToOtherSeries(var61);
//     var61.removeAgedItems(true);
//     boolean var68 = var46.equals((java.lang.Object)true);
//     org.jfree.data.time.TimeSeries var69 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var25, (org.jfree.data.time.RegularTimePeriod)var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "Time"+ "'", var23.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "2014"+ "'", var26.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "2014"+ "'", var31.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "20-December-2014"+ "'", var36.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "Value"+ "'", var57.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    var4.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
    org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var12 = var11.getStart();
    org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var12);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var12);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addYears(0, var14);
    org.jfree.data.time.SerialDate var17 = var15.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var18 = var8.getEndOfCurrentMonth(var17);
    java.lang.String var19 = var17.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var5.setMaximumItemCount(0);
    int var8 = var2.compareTo((java.lang.Object)var5);
    java.lang.Number var9 = var2.getValue();
    java.lang.Number var10 = var2.getValue();
    org.jfree.data.time.RegularTimePeriod var11 = var2.getPeriod();
    java.util.Date var12 = var11.getStart();
    java.util.TimeZone var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0.0d+ "'", var9.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0d+ "'", var10.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     boolean var4 = var2.equals((java.lang.Object)"January");
//     var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
//     boolean var7 = var1.getNotify();
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 10.0d);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var10);
//     org.jfree.data.time.Year var15 = var14.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.previous();
//     long var17 = var15.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     java.lang.String var20 = var15.toString();
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var23 = var22.getMonth();
//     int var24 = var22.toSerial();
//     int var25 = var22.toSerial();
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(var29);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addYears(0, var31);
//     org.jfree.data.time.SerialDate var34 = var32.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var36 = var32.getPreviousDayOfWeek(1);
//     boolean var37 = var22.isOnOrAfter(var36);
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var22);
//     int var39 = var22.getYYYY();
//     int var40 = var22.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var45 = var44.getDayOfMonth();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var48 = var44.isBefore(var47);
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addMonths(1, var47);
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var49);
//     boolean var51 = var22.isAfter(var49);
//     org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var54 = var53.getMonth();
//     int var55 = var53.toSerial();
//     int var56 = var53.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var60 = var59.getDayOfMonth();
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var63 = var59.isBefore(var62);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var59);
//     org.jfree.data.time.Day var65 = new org.jfree.data.time.Day();
//     boolean var67 = var65.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var68 = var65.next();
//     long var69 = var65.getLastMillisecond();
//     java.lang.String var70 = var65.toString();
//     org.jfree.data.time.SerialDate var71 = var65.getSerialDate();
//     boolean var72 = var59.isOn(var71);
//     boolean var73 = var53.isAfter(var71);
//     int var74 = var22.compare((org.jfree.data.time.SerialDate)var53);
//     int var75 = var15.compareTo((java.lang.Object)var74);
//     long var76 = var15.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "2014"+ "'", var20.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var70 + "' != '" + "20-December-2014"+ "'", var70.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 1420099199999L);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(20, 31, 11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     var1.setKey((java.lang.Comparable)'4');
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.lang.String var21 = var20.toString();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(1, var20);
//     java.lang.Number var23 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var22);
//     boolean var24 = var10.getNotify();
//     boolean var25 = var10.isEmpty();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var29 = var28.getPeriod();
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var31.setMaximumItemCount(0);
//     int var34 = var28.compareTo((java.lang.Object)var31);
//     org.jfree.data.time.TimeSeries var35 = var10.addAndOrUpdate(var31);
//     var10.setDomainDescription("hi!");
//     org.jfree.data.time.TimeSeries var38 = var1.addAndOrUpdate(var10);
//     java.lang.Object var39 = var1.clone();
//     java.lang.Comparable var40 = var1.getKey();
//     int var41 = var1.getMaximumItemCount();
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var43.setMaximumItemCount(0);
//     int var46 = var43.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var47 = null;
//     var43.removeChangeListener(var47);
//     var43.clear();
//     var43.fireSeriesChanged();
//     org.jfree.data.time.FixedMillisecond var52 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var53 = var52.getStart();
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond(var53);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(var53);
//     org.jfree.data.time.Day var56 = new org.jfree.data.time.Day(var53);
//     org.jfree.data.time.TimeSeriesDataItem var57 = var43.getDataItem((org.jfree.data.time.RegularTimePeriod)var56);
//     var43.setMaximumItemCount(0);
//     org.jfree.data.time.Day var60 = new org.jfree.data.time.Day();
//     boolean var62 = var60.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var63 = var60.next();
//     long var64 = var60.getLastMillisecond();
//     int var65 = var60.getDayOfMonth();
//     org.jfree.data.time.Year var67 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var68 = var67.next();
//     org.jfree.data.time.TimeSeriesDataItem var70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var67, 10.0d);
//     org.jfree.data.time.Month var71 = new org.jfree.data.time.Month(10, var67);
//     org.jfree.data.time.Year var72 = var71.getYear();
//     long var73 = var71.getFirstMillisecond();
//     java.lang.String var74 = var71.toString();
//     org.jfree.data.time.Year var75 = var71.getYear();
//     boolean var76 = var60.equals((java.lang.Object)var75);
//     org.jfree.data.time.TimeSeriesDataItem var77 = var43.getDataItem((org.jfree.data.time.RegularTimePeriod)var60);
//     java.lang.Number var78 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "2014"+ "'", var21.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + '4'+ "'", var40.equals('4'));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var74 + "' != '" + "October 2014"+ "'", var74.equals("October 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var78 + "' != '" + (-1)+ "'", var78.equals((-1)));
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("March");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     java.lang.String var27 = var26.toString();
//     int var29 = var26.compareTo((java.lang.Object)"2014");
//     int var30 = var25.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     int var31 = var26.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var26);
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, 0.0d);
//     long var36 = var33.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var33);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(10L);
//     org.jfree.data.time.RegularTimePeriod var40 = var39.previous();
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond(10L);
//     int var43 = var39.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(100);
//     var45.setDescription("org.jfree.data.general.SeriesException: January");
//     var45.setDescription("hi!");
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day(var45);
//     int var51 = var39.compareTo((java.lang.Object)var45);
//     boolean var52 = var1.equals((java.lang.Object)var45);
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     java.lang.String var56 = var55.toString();
//     int var58 = var55.compareTo((java.lang.Object)"2014");
//     int var59 = var54.getIndex((org.jfree.data.time.RegularTimePeriod)var55);
//     org.jfree.data.time.TimeSeriesDataItem var61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, (-1.0d));
//     int var62 = var55.getMonth();
//     int var63 = var55.getDayOfMonth();
//     int var64 = var55.getDayOfMonth();
//     java.lang.Class var67 = null;
//     org.jfree.data.time.TimeSeries var69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var72 = var69.createCopy(0, 0);
//     java.lang.Class var73 = var72.getTimePeriodClass();
//     java.lang.Object var74 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var67, var73);
//     java.io.InputStream var75 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var73);
//     org.jfree.data.time.TimeSeries var76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var55, var73);
//     java.beans.PropertyChangeListener var77 = null;
//     var76.addPropertyChangeListener(var77);
//     java.util.Collection var79 = var1.getTimePeriodsUniqueToOtherSeries(var76);
//     java.lang.Object var80 = null;
//     boolean var81 = var76.equals(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "20-December-2014"+ "'", var27.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var56 + "' != '" + "20-December-2014"+ "'", var56.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == false);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.addYears((-453), (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     long var15 = var13.getSerialIndex();
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     java.lang.String var19 = var18.toString();
//     int var21 = var18.compareTo((java.lang.Object)"2014");
//     int var22 = var17.getIndex((org.jfree.data.time.RegularTimePeriod)var18);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var17.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     java.lang.String var28 = var27.toString();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(1, var27);
//     java.lang.Number var30 = var17.getValue((org.jfree.data.time.RegularTimePeriod)var29);
//     boolean var31 = var17.getNotify();
//     boolean var32 = var17.isEmpty();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var36 = var35.getPeriod();
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var38.setMaximumItemCount(0);
//     int var41 = var35.compareTo((java.lang.Object)var38);
//     org.jfree.data.time.TimeSeries var42 = var17.addAndOrUpdate(var38);
//     var17.setDomainDescription("hi!");
//     var17.setNotify(true);
//     var17.setDescription("ThreadContext");
//     org.jfree.data.time.RegularTimePeriod var49 = var17.getNextTimePeriod();
//     int var50 = var13.compareTo((java.lang.Object)var49);
//     java.util.Calendar var51 = null;
//     long var52 = var13.getLastMillisecond(var51);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.lang.Comparable var3 = var1.getKey();
    var1.setMaximumItemAge(1412146800000L);
    java.beans.PropertyChangeListener var6 = null;
    var1.removePropertyChangeListener(var6);
    var1.removeAgedItems(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var8 = var7.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
//     boolean var16 = var1.isOnOrAfter(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var18 = var1.getYYYY();
//     int var19 = var1.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var24 = var23.getDayOfMonth();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var27 = var23.isBefore(var26);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addMonths(1, var26);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var28);
//     boolean var30 = var1.isAfter(var28);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var33 = var32.getMonth();
//     int var34 = var32.toSerial();
//     int var35 = var32.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var39 = var38.getDayOfMonth();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var42 = var38.isBefore(var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var38);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     boolean var46 = var44.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var47 = var44.next();
//     long var48 = var44.getLastMillisecond();
//     java.lang.String var49 = var44.toString();
//     org.jfree.data.time.SerialDate var50 = var44.getSerialDate();
//     boolean var51 = var38.isOn(var50);
//     boolean var52 = var32.isAfter(var50);
//     int var53 = var1.compare((org.jfree.data.time.SerialDate)var32);
//     int var54 = var32.toSerial();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "20-December-2014"+ "'", var49.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 12);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeEvent var5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(1, 0);
//     long var9 = var8.getFirstMillisecond();
//     long var10 = var8.getLastMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var8, 10.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-62133062400001L));
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     var1.setNotify(false);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     java.lang.String var21 = var20.toString();
//     int var23 = var20.compareTo((java.lang.Object)"2014");
//     int var24 = var19.getIndex((org.jfree.data.time.RegularTimePeriod)var20);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (-1.0d));
//     int var27 = var20.getMonth();
//     int var28 = var20.getDayOfMonth();
//     int var29 = var20.getDayOfMonth();
//     int var30 = var20.getYear();
//     java.util.Date var31 = var20.getEnd();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var31);
//     long var33 = var32.getSerialIndex();
//     boolean var34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var33);
//     org.jfree.data.general.SeriesChangeListener var35 = null;
//     var1.removeChangeListener(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "20-December-2014"+ "'", var21.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    long var7 = var6.getLastMillisecond();
    long var8 = var6.getLastMillisecond();
    long var9 = var6.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var10 = var6.previous();
    java.util.Calendar var11 = null;
    long var12 = var6.getFirstMillisecond(var11);
    org.jfree.data.time.TimeSeriesDataItem var14 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
    var1.removeAgedItems(0L, true);
    int var18 = var1.getMaximumItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var2);
//     org.jfree.data.time.Year var4 = var0.getYear();
//     long var5 = var4.getFirstMillisecond();
//     java.util.Calendar var6 = null;
//     var4.peg(var6);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.removeChangeListener(var4);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var8 = var7.getDescription();
//     java.lang.Comparable var9 = var7.getKey();
//     var7.setMaximumItemAge(1412146800000L);
//     java.lang.String var12 = var7.getDescription();
//     java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     var7.setDomainDescription("ThreadContext");
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var18 = var17.getLastMillisecond();
//     long var19 = var17.getLastMillisecond();
//     long var20 = var17.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var21 = var17.previous();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var7.addOrUpdate(var21, (java.lang.Number)1.0d);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var25.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var28 = null;
//     var25.addChangeListener(var28);
//     var25.setKey((java.lang.Comparable)'4');
//     boolean var32 = var25.getNotify();
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var35 = var34.getTime();
//     java.util.Calendar var36 = null;
//     long var37 = var34.getFirstMillisecond(var36);
//     var25.setKey((java.lang.Comparable)var34);
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var41 = null;
//     var40.addPropertyChangeListener(var41);
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     java.lang.String var46 = var45.toString();
//     int var48 = var45.compareTo((java.lang.Object)"2014");
//     int var49 = var44.getIndex((org.jfree.data.time.RegularTimePeriod)var45);
//     java.util.Date var50 = var45.getStart();
//     org.jfree.data.time.FixedMillisecond var52 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var53 = var52.getLastMillisecond();
//     java.util.Calendar var54 = null;
//     var52.peg(var54);
//     java.util.Calendar var56 = null;
//     long var57 = var52.getMiddleMillisecond(var56);
//     org.jfree.data.time.Month var60 = new org.jfree.data.time.Month(10, 100);
//     boolean var61 = var52.equals((java.lang.Object)100);
//     org.jfree.data.time.TimeSeries var62 = var40.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var52);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var63 = var7.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var52);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "20-December-2014"+ "'", var46.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var3 = var2.toString();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var6 = var2.getYear();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "January 0"+ "'", var3.equals("January 0"));

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1969);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(9, (-598), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(100);
    var5.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(12, var5);
    java.lang.String var10 = var5.getDescription();
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(11, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addMonths((-571), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "org.jfree.data.general.SeriesException: January"+ "'", var10.equals("org.jfree.data.general.SeriesException: January"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
    var1.delete((org.jfree.data.time.RegularTimePeriod)var8);
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var11.setMaximumItemCount(0);
    int var14 = var11.getMaximumItemCount();
    java.util.Collection var15 = var1.getTimePeriodsUniqueToOtherSeries(var11);
    java.beans.PropertyChangeListener var16 = null;
    var1.addPropertyChangeListener(var16);
    java.beans.PropertyChangeListener var18 = null;
    var1.removePropertyChangeListener(var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(5, (java.lang.Number)1418759999999L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var11.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var11.removeChangeListener(var14);
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var18 = var17.getDescription();
//     java.lang.Comparable var19 = var17.getKey();
//     var17.setMaximumItemAge(1412146800000L);
//     java.lang.String var22 = var17.getDescription();
//     java.util.Collection var23 = var11.getTimePeriodsUniqueToOtherSeries(var17);
//     var17.setDomainDescription("ThreadContext");
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var28 = var27.getLastMillisecond();
//     long var29 = var27.getLastMillisecond();
//     long var30 = var27.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var31 = var27.previous();
//     org.jfree.data.time.TimeSeriesDataItem var33 = var17.addOrUpdate(var31, (java.lang.Number)1.0d);
//     org.jfree.data.time.TimeSeriesDataItem var35 = var1.addOrUpdate(var31, (java.lang.Number)(short)(-1));
//     java.lang.Comparable var36 = var1.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + (byte)100+ "'", var19.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + (byte)100+ "'", var36.equals((byte)100));
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     boolean var4 = var2.equals((java.lang.Object)"January");
//     var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
//     boolean var7 = var1.getNotify();
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 10.0d);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var10);
//     org.jfree.data.time.Year var15 = var14.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.previous();
//     long var17 = var15.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     java.lang.String var20 = var15.toString();
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var23 = var22.getMonth();
//     int var24 = var22.toSerial();
//     int var25 = var22.toSerial();
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(var29);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addYears(0, var31);
//     org.jfree.data.time.SerialDate var34 = var32.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var36 = var32.getPreviousDayOfWeek(1);
//     boolean var37 = var22.isOnOrAfter(var36);
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var22);
//     int var39 = var22.getYYYY();
//     int var40 = var22.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var45 = var44.getDayOfMonth();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var48 = var44.isBefore(var47);
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addMonths(1, var47);
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var49);
//     boolean var51 = var22.isAfter(var49);
//     org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var54 = var53.getMonth();
//     int var55 = var53.toSerial();
//     int var56 = var53.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var60 = var59.getDayOfMonth();
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var63 = var59.isBefore(var62);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var59);
//     org.jfree.data.time.Day var65 = new org.jfree.data.time.Day();
//     boolean var67 = var65.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var68 = var65.next();
//     long var69 = var65.getLastMillisecond();
//     java.lang.String var70 = var65.toString();
//     org.jfree.data.time.SerialDate var71 = var65.getSerialDate();
//     boolean var72 = var59.isOn(var71);
//     boolean var73 = var53.isAfter(var71);
//     int var74 = var22.compare((org.jfree.data.time.SerialDate)var53);
//     int var75 = var15.compareTo((java.lang.Object)var74);
//     java.util.Calendar var76 = null;
//     long var77 = var15.getFirstMillisecond(var76);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2014, (-453), (-453));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-598), (-460), (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    java.beans.PropertyChangeListener var6 = null;
    var1.addPropertyChangeListener(var6);
    org.jfree.data.general.SeriesChangeListener var8 = null;
    var1.addChangeListener(var8);
    var1.removeAgedItems(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var13 = var1.getTimePeriod((-100));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     var1.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     var1.add(var17, true);
//     var1.removeAgedItems((-57600000L), false);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var26 = var25.toString();
//     org.jfree.data.time.TimeSeriesDataItem var27 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     java.lang.String var31 = var30.toString();
//     int var33 = var30.compareTo((java.lang.Object)"2014");
//     int var34 = var29.getIndex((org.jfree.data.time.RegularTimePeriod)var30);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var29.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     java.lang.String var40 = var39.toString();
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(1, var39);
//     java.lang.Number var42 = var29.getValue((org.jfree.data.time.RegularTimePeriod)var41);
//     boolean var43 = var29.getNotify();
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var47.setMaximumItemCount(0);
//     org.jfree.data.time.Year var51 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var52 = var51.next();
//     org.jfree.data.time.TimeSeriesDataItem var54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var51, 10.0d);
//     org.jfree.data.time.Month var55 = new org.jfree.data.time.Month(10, var51);
//     org.jfree.data.time.RegularTimePeriod var56 = var51.next();
//     var47.delete((org.jfree.data.time.RegularTimePeriod)var51);
//     org.jfree.data.time.TimeSeries var58 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var45, (org.jfree.data.time.RegularTimePeriod)var51);
//     long var59 = var51.getSerialIndex();
//     var1.update((org.jfree.data.time.RegularTimePeriod)var51, (java.lang.Number)9);
//     var1.removeAgedItems(1412146799999L, false);
//     org.jfree.data.time.TimeSeries var66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var67 = new org.jfree.data.time.Day();
//     java.lang.String var68 = var67.toString();
//     int var70 = var67.compareTo((java.lang.Object)"2014");
//     int var71 = var66.getIndex((org.jfree.data.time.RegularTimePeriod)var67);
//     org.jfree.data.time.TimeSeriesDataItem var73 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var67, (-1.0d));
//     int var74 = var67.getMonth();
//     int var75 = var67.getDayOfMonth();
//     int var76 = var67.getDayOfMonth();
//     int var77 = var67.getYear();
//     var1.update((org.jfree.data.time.RegularTimePeriod)var67, (java.lang.Number)(byte)100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "January 0"+ "'", var26.equals("January 0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "20-December-2014"+ "'", var31.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "2014"+ "'", var40.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + (-1)+ "'", var42.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var68 + "' != '" + "20-December-2014"+ "'", var68.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 2014);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.lang.Comparable var3 = var1.getKey();
    var1.setMaximumItemAge(1412146800000L);
    java.lang.String var6 = var1.getDescription();
    java.lang.Class var7 = var1.getTimePeriodClass();
    org.jfree.data.time.RegularTimePeriod var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var8, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(42004L);
    long var2 = var1.getMiddleMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 42004L);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
    org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var8.setMaximumItemCount(0);
    int var11 = var5.compareTo((java.lang.Object)var8);
    java.lang.Number var12 = var5.getValue();
    org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
    boolean var15 = var5.equals((java.lang.Object)var14);
    boolean var16 = var1.equals((java.lang.Object)var14);
    long var17 = var1.getMiddleMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.util.Collection var7 = var1.getTimePeriods();
//     java.lang.String var8 = var1.getDomainDescription();
//     java.util.Collection var9 = var1.getTimePeriods();
//     var1.setRangeDescription("9-April-1900");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "Time"+ "'", var8.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     long var6 = var1.getMaximumItemAge();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var14 = var13.getPeriod();
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     org.jfree.data.time.TimeSeriesDataItem var17 = var1.addOrUpdate(var14, 0.0d);
//     int var18 = var1.getMaximumItemCount();
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     boolean var21 = var19.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     long var23 = var19.getLastMillisecond();
//     int var24 = var19.getDayOfMonth();
//     long var25 = var19.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var27.setMaximumItemCount(0);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, 10.0d);
//     org.jfree.data.time.Month var35 = new org.jfree.data.time.Month(10, var31);
//     org.jfree.data.time.RegularTimePeriod var36 = var31.next();
//     var27.delete((org.jfree.data.time.RegularTimePeriod)var31);
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var40 = new org.jfree.data.time.Day();
//     java.lang.String var41 = var40.toString();
//     int var43 = var40.compareTo((java.lang.Object)"2014");
//     int var44 = var39.getIndex((org.jfree.data.time.RegularTimePeriod)var40);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var47 = var39.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var45, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var49 = new org.jfree.data.time.Year();
//     java.lang.String var50 = var49.toString();
//     org.jfree.data.time.Month var51 = new org.jfree.data.time.Month(1, var49);
//     java.lang.Number var52 = var39.getValue((org.jfree.data.time.RegularTimePeriod)var51);
//     boolean var53 = var31.equals((java.lang.Object)var51);
//     org.jfree.data.time.FixedMillisecond var55 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var56 = var55.getLastMillisecond();
//     long var57 = var55.getLastMillisecond();
//     long var58 = var55.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var59 = var55.previous();
//     int var60 = var31.compareTo((java.lang.Object)var55);
//     org.jfree.data.time.Day var61 = new org.jfree.data.time.Day();
//     java.lang.String var62 = var61.toString();
//     java.util.Date var63 = var61.getEnd();
//     org.jfree.data.time.Month var64 = new org.jfree.data.time.Month(var63);
//     org.jfree.data.time.Month var65 = new org.jfree.data.time.Month(var63);
//     int var66 = var55.compareTo((java.lang.Object)var65);
//     int var67 = var19.compareTo((java.lang.Object)var65);
//     org.jfree.data.time.RegularTimePeriod var68 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var69 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var65, var68);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "20-December-2014"+ "'", var41.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "2014"+ "'", var50.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + (-1)+ "'", var52.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "20-December-2014"+ "'", var62.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 0);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var1);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var5 = null;
//     var4.peg(var5);
//     long var7 = var4.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var8 = var4.previous();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate(var8, 0.0d);
//     java.lang.String var11 = var2.getDomainDescription();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "hi!", "ThreadContext", var23);
//     var24.setMaximumItemAge(1420099199999L);
//     java.util.Collection var27 = var2.getTimePeriodsUniqueToOtherSeries(var24);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var29 = var28.next();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.next();
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var28);
//     var31.setNotify(true);
//     boolean var34 = var2.equals((java.lang.Object)var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Time"+ "'", var11.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getDayOfMonth();
//     int var12 = var2.getYear();
//     java.util.Calendar var13 = null;
//     var2.peg(var13);
// 
//   }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }
// 
// 
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var5 = var4.getDescription();
//     java.lang.Comparable var6 = var4.getKey();
//     var4.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     java.lang.Object var16 = var10.clone();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, 10.0d);
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(10, var18);
//     org.jfree.data.time.Year var23 = var22.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, (-1.0d));
//     java.util.Collection var26 = var4.getTimePeriodsUniqueToOtherSeries(var10);
//     boolean var27 = var4.isEmpty();
//     java.lang.Class var28 = var4.getTimePeriodClass();
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var32 = var31.getDescription();
//     java.lang.Comparable var33 = var31.getKey();
//     var31.setMaximumItemAge(1412146800000L);
//     java.lang.String var36 = var31.getDescription();
//     java.lang.Class var37 = var31.getTimePeriodClass();
//     java.lang.Object var38 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October 10", var37);
//     org.jfree.data.time.Day var39 = new org.jfree.data.time.Day();
//     java.lang.String var40 = var39.toString();
//     java.util.Date var41 = var39.getEnd();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     java.util.TimeZone var43 = null;
//     org.jfree.data.time.RegularTimePeriod var44 = org.jfree.data.time.RegularTimePeriod.createInstance(var37, var41, var43);
//     java.lang.Object var45 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", var28, var37);
//     java.net.URL var46 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var37);
//     java.io.InputStream var47 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (byte)100+ "'", var6.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + (byte)100+ "'", var33.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "20-December-2014"+ "'", var40.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4, (-41893), (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    long var3 = var1.getFirstMillisecond();
    java.util.Date var4 = var1.getTime();
    java.lang.Class var5 = null;
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1, var5);
    var6.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    java.lang.Comparable var0 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var5 = var4.getDescription();
    java.lang.Comparable var6 = var4.getKey();
    var4.setMaximumItemAge(1412146800000L);
    java.lang.String var9 = var4.getDescription();
    java.lang.Class var10 = var4.getTimePeriodClass();
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var10);
    org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1L);
    long var14 = var13.getLastMillisecond();
    long var15 = var13.getLastMillisecond();
    long var16 = var13.getLastMillisecond();
    java.util.Date var17 = var13.getTime();
    java.lang.Class var22 = null;
    org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var27 = var24.createCopy(0, 0);
    java.lang.Class var28 = var27.getTimePeriodClass();
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var22, var28);
    java.io.InputStream var30 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var28);
    org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var17, "30-April-1900", "December", var28);
    java.util.TimeZone var32 = null;
    org.jfree.data.time.RegularTimePeriod var33 = org.jfree.data.time.RegularTimePeriod.createInstance(var10, var17, var32);
    java.io.InputStream var34 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Wed Dec 31 16:00:00 PST 1969", var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries(var0, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)100+ "'", var6.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var7 = var4.createCopy(0, 0);
//     java.lang.Class var8 = var7.getTimePeriodClass();
//     java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var2, var8);
//     java.io.InputStream var10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("January 2014", var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.util.Calendar var4 = null;
//     long var5 = var3.getFirstMillisecond(var4);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var2);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getLastMillisecond(var7);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     long var3 = var1.getLastMillisecond();
//     long var4 = var1.getLastMillisecond();
//     java.util.Date var5 = var1.getTime();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var15 = var12.createCopy(0, 0);
//     java.lang.Class var16 = var15.getTimePeriodClass();
//     java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var10, var16);
//     java.io.InputStream var18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var16);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, "30-April-1900", "December", var16);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var5);
//     java.util.Calendar var21 = null;
//     var20.peg(var21);
// 
//   }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     long var15 = var13.getSerialIndex();
//     java.util.Calendar var16 = null;
//     long var17 = var13.getLastMillisecond(var16);
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     int var7 = var2.getYear();
//     int var8 = var2.getMonth();
//     long var9 = var2.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.String var13 = var12.toString();
//     int var15 = var12.compareTo((java.lang.Object)"2014");
//     int var16 = var11.getIndex((org.jfree.data.time.RegularTimePeriod)var12);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     java.lang.String var22 = var21.toString();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(1, var21);
//     java.lang.Number var24 = var11.getValue((org.jfree.data.time.RegularTimePeriod)var23);
//     boolean var25 = var11.getNotify();
//     boolean var26 = var11.isEmpty();
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var30 = var29.getPeriod();
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var32.setMaximumItemCount(0);
//     int var35 = var29.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.TimeSeries var36 = var11.addAndOrUpdate(var32);
//     int var37 = var2.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var40 = var39.getStart();
//     long var41 = var39.getSerialIndex();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var32.add((org.jfree.data.time.RegularTimePeriod)var39, 10.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "2014"+ "'", var22.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + (-1)+ "'", var24.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1L);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    int var4 = var1.toSerial();
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(12);
    int var7 = var6.getMonth();
    int var8 = var6.toSerial();
    boolean var9 = var1.isBefore((org.jfree.data.time.SerialDate)var6);
    int var10 = var6.getDayOfWeek();
    org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var16 = var15.getStart();
    org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(var16);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var16);
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addYears(0, var18);
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addYears(0, var18);
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addMonths((-453), var20);
    org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 0.0d);
    org.jfree.data.time.RegularTimePeriod var25 = var24.getPeriod();
    org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var27.setMaximumItemCount(0);
    int var30 = var24.compareTo((java.lang.Object)var27);
    java.lang.Object var31 = var24.clone();
    org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var36 = var35.getStart();
    org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond(var36);
    org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var36);
    org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.addYears(0, var38);
    org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addYears(0, var38);
    boolean var41 = var24.equals((java.lang.Object)var40);
    boolean var42 = var6.isInRange(var21, var40);
    org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
    boolean var45 = var43.equals((java.lang.Object)"January");
    org.jfree.data.time.RegularTimePeriod var46 = var43.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var47 = var6.compareTo((java.lang.Object)var43);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var4 = null;
//     long var5 = var3.getFirstMillisecond(var4);
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
//     java.util.Date var7 = var3.getTime();
//     java.util.TimeZone var8 = null;
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year(var7, var8);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    boolean var6 = var1.getNotify();
    org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(12);
    int var9 = var8.getMonth();
    int var10 = var8.toSerial();
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(100);
    var14.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addMonths(1, var14);
    var14.setDescription("");
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addDays(12, var14);
    java.lang.String var21 = var20.getDescription();
    boolean var22 = var8.isOn(var20);
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(100);
    int var25 = var24.getDayOfMonth();
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(100);
    var30.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addMonths(1, var30);
    org.jfree.data.time.SerialDate var34 = var27.getEndOfCurrentMonth(var30);
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(100);
    var39.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths(1, var39);
    org.jfree.data.time.SerialDate var43 = var36.getEndOfCurrentMonth(var39);
    org.jfree.data.time.SerialDate var44 = var34.getEndOfCurrentMonth(var39);
    org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.createInstance(100);
    var49.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.addMonths(1, var49);
    org.jfree.data.time.SerialDate var53 = var46.getEndOfCurrentMonth(var49);
    org.jfree.data.time.FixedMillisecond var56 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var57 = var56.getStart();
    org.jfree.data.time.FixedMillisecond var58 = new org.jfree.data.time.FixedMillisecond(var57);
    org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.createInstance(var57);
    org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.addYears(0, var59);
    org.jfree.data.time.SerialDate var62 = var60.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var63 = var53.getEndOfCurrentMonth(var62);
    boolean var65 = var24.isInRange(var44, var53, (-453));
    int var66 = var24.getDayOfWeek();
    boolean var67 = var8.isAfter((org.jfree.data.time.SerialDate)var24);
    boolean var68 = var1.equals((java.lang.Object)var24);
    var1.setMaximumItemAge(0L);
    var1.setDomainDescription("Feb");
    org.jfree.data.time.TimeSeries var74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var74.setMaximumItemCount(0);
    int var77 = var74.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var78 = null;
    var74.removeChangeListener(var78);
    java.lang.String var80 = var74.getRangeDescription();
    org.jfree.data.time.FixedMillisecond var81 = new org.jfree.data.time.FixedMillisecond();
    var74.delete((org.jfree.data.time.RegularTimePeriod)var81);
    org.jfree.data.time.RegularTimePeriod var83 = var81.next();
    java.util.Date var84 = var81.getTime();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update((org.jfree.data.time.RegularTimePeriod)var81, (java.lang.Number)(-598));
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var80 + "' != '" + "Value"+ "'", var80.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var3 = var2.toString();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
    java.lang.Object var6 = var5.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "January 0"+ "'", var3.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-571));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var3 = var2.getDayOfMonth();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var6 = var2.isBefore(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var2);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var10 = var9.getMonth();
//     int var11 = var9.toSerial();
//     int var12 = var9.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var16 = var15.getDayOfMonth();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var19 = var15.isBefore(var18);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var15);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     boolean var23 = var21.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var24 = var21.next();
//     long var25 = var21.getLastMillisecond();
//     java.lang.String var26 = var21.toString();
//     org.jfree.data.time.SerialDate var27 = var21.getSerialDate();
//     boolean var28 = var15.isOn(var27);
//     boolean var29 = var9.isAfter(var27);
//     int var30 = var2.compare(var27);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var33 = var32.getMonth();
//     int var34 = var32.toSerial();
//     int var35 = var32.toSerial();
//     org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var38 = var37.getMonth();
//     int var39 = var37.toSerial();
//     boolean var40 = var32.isBefore((org.jfree.data.time.SerialDate)var37);
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var42.setMaximumItemCount(0);
//     var42.clear();
//     org.jfree.data.time.FixedMillisecond var47 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var48 = var47.getLastMillisecond();
//     long var49 = var47.getLastMillisecond();
//     long var50 = var47.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var51 = var47.previous();
//     java.util.Calendar var52 = null;
//     long var53 = var47.getFirstMillisecond(var52);
//     org.jfree.data.time.TimeSeriesDataItem var55 = var42.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var47, (-1.0d));
//     var42.removeAgedItems(0L, true);
//     var42.setMaximumItemCount(0);
//     boolean var61 = var32.equals((java.lang.Object)0);
//     org.jfree.data.time.SerialDate var62 = var27.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var32);
//     java.lang.String var63 = var32.toString();
//     org.jfree.data.time.SpreadsheetDate var65 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var66 = var65.getMonth();
//     int var67 = var65.toSerial();
//     int var68 = var65.toSerial();
//     org.jfree.data.time.FixedMillisecond var71 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var72 = var71.getStart();
//     org.jfree.data.time.FixedMillisecond var73 = new org.jfree.data.time.FixedMillisecond(var72);
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(var72);
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.addYears(0, var74);
//     org.jfree.data.time.SerialDate var77 = var75.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var79 = var75.getPreviousDayOfWeek(1);
//     boolean var80 = var65.isOnOrAfter(var79);
//     org.jfree.data.time.Day var81 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var65);
//     int var82 = var65.getYYYY();
//     boolean var83 = var32.isOnOrAfter((org.jfree.data.time.SerialDate)var65);
//     org.jfree.data.time.SpreadsheetDate var85 = new org.jfree.data.time.SpreadsheetDate(11);
//     boolean var86 = var65.isOnOrBefore((org.jfree.data.time.SerialDate)var85);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var88 = var85.getNearestDayOfWeek((-452));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-41893));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "11-January-1900"+ "'", var63.equals("11-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == false);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.Year var3 = var0.getYear();
//     long var4 = var3.getLastMillisecond();
//     java.util.Calendar var5 = null;
//     var3.peg(var5);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     java.lang.String var6 = var1.getDescription();
//     int var7 = var1.getItemCount();
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.String var11 = var10.toString();
//     int var13 = var10.compareTo((java.lang.Object)"2014");
//     int var14 = var9.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (-1.0d));
//     var1.add(var16, true);
//     java.beans.PropertyChangeListener var19 = null;
//     var1.removePropertyChangeListener(var19);
//     boolean var21 = var1.getNotify();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     var1.clear();
//     java.lang.String var11 = var1.getRangeDescription();
//     int var12 = var1.getMaximumItemCount();
//     java.lang.String var13 = var1.getRangeDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Value"+ "'", var11.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "Value"+ "'", var13.equals("Value"));
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     java.lang.Object var4 = var3.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.fireSeriesChanged();
//     boolean var5 = var1.getNotify();
//     java.lang.Object var6 = var1.clone();
//     java.lang.Object var7 = var1.clone();
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 0.0d);
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var12.setMaximumItemCount(0);
//     var12.clear();
//     java.lang.String var16 = var12.getDomainDescription();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     java.lang.String var19 = var18.toString();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(1, var18);
//     boolean var21 = var12.equals((java.lang.Object)var18);
//     int var23 = var18.compareTo((java.lang.Object)(short)1);
//     long var24 = var18.getLastMillisecond();
//     int var25 = var10.compareTo((java.lang.Object)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var10);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "Time"+ "'", var16.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "2014"+ "'", var19.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    var1.fireSeriesChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-458));

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 10.0d);
    java.lang.Object var4 = var3.clone();
    java.lang.Object var5 = var3.clone();
    java.lang.Object var6 = var3.clone();
    java.lang.Object var7 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     var1.clear();
//     java.lang.String var11 = var1.getRangeDescription();
//     java.lang.Comparable var12 = var1.getKey();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var15 = var14.getTime();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.Year var20 = var17.getYear();
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, 0.0d);
//     org.jfree.data.time.Year var24 = var21.getYear();
//     int var25 = var17.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.RegularTimePeriod var26 = var21.next();
//     var1.delete(var26);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.lang.String var30 = var29.toString();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month(1, var29);
//     org.jfree.data.time.Year var32 = var31.getYear();
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var35 = var34.getLastMillisecond();
//     java.util.Calendar var36 = null;
//     var34.peg(var36);
//     java.util.Date var38 = var34.getTime();
//     boolean var39 = var32.equals((java.lang.Object)var38);
//     org.jfree.data.time.Month var40 = new org.jfree.data.time.Month(var38);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var40, 1.0d, true);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Value"+ "'", var11.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + (byte)100+ "'", var12.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "2014"+ "'", var30.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
//     java.lang.String var4 = var3.toString();
//     long var5 = var3.getMiddleMillisecond();
//     java.util.Date var6 = var3.getStart();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "December 2014"+ "'", var4.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var12 = var2.previous();
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     java.lang.String var16 = var15.toString();
//     int var18 = var15.compareTo((java.lang.Object)"2014");
//     int var19 = var14.getIndex((org.jfree.data.time.RegularTimePeriod)var15);
//     var14.setDomainDescription("20-December-2014");
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(100);
//     var26.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addMonths(1, var26);
//     org.jfree.data.time.SerialDate var30 = var23.getEndOfCurrentMonth(var26);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var34 = var33.getStart();
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(var34);
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(var34);
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addYears(0, var36);
//     org.jfree.data.time.SerialDate var39 = var37.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var40 = var30.getEndOfCurrentMonth(var39);
//     org.jfree.data.time.Day var41 = new org.jfree.data.time.Day(var30);
//     org.jfree.data.time.FixedMillisecond var43 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var44 = var43.getTime();
//     java.util.Calendar var45 = null;
//     var43.peg(var45);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     boolean var49 = var47.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var50 = var47.next();
//     long var51 = var47.getLastMillisecond();
//     int var52 = var43.compareTo((java.lang.Object)var47);
//     java.lang.String var53 = var47.toString();
//     org.jfree.data.time.TimeSeries var54 = var14.createCopy((org.jfree.data.time.RegularTimePeriod)var41, (org.jfree.data.time.RegularTimePeriod)var47);
//     boolean var55 = var2.equals((java.lang.Object)var54);
//     java.util.Calendar var56 = null;
//     long var57 = var2.getLastMillisecond(var56);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var2 = null;
//     var1.addPropertyChangeListener(var2);
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     java.lang.String var7 = var6.toString();
//     int var9 = var6.compareTo((java.lang.Object)"2014");
//     int var10 = var5.getIndex((org.jfree.data.time.RegularTimePeriod)var6);
//     var5.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     java.lang.String var16 = var15.toString();
//     int var18 = var15.compareTo((java.lang.Object)"2014");
//     int var19 = var14.getIndex((org.jfree.data.time.RegularTimePeriod)var15);
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, (-1.0d));
//     var5.add(var21, true);
//     var21.setValue((java.lang.Number)0.0d);
//     java.lang.Object var26 = null;
//     boolean var27 = var21.equals(var26);
//     var1.add(var21, false);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     java.lang.String var31 = var30.toString();
//     java.util.Date var32 = var30.getEnd();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month(var32);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var33, 1.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "20-December-2014"+ "'", var16.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "20-December-2014"+ "'", var31.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var2);
//     long var4 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 24180L);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    var7.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
    var7.setDescription("");
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addDays(12, var7);
    java.lang.String var14 = var13.getDescription();
    boolean var15 = var1.isOn(var13);
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(100);
    int var18 = var17.getDayOfMonth();
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
    var23.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addMonths(1, var23);
    org.jfree.data.time.SerialDate var27 = var20.getEndOfCurrentMonth(var23);
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(100);
    var32.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(1, var32);
    org.jfree.data.time.SerialDate var36 = var29.getEndOfCurrentMonth(var32);
    org.jfree.data.time.SerialDate var37 = var27.getEndOfCurrentMonth(var32);
    org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(100);
    var42.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addMonths(1, var42);
    org.jfree.data.time.SerialDate var46 = var39.getEndOfCurrentMonth(var42);
    org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var50 = var49.getStart();
    org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond(var50);
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var50);
    org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addYears(0, var52);
    org.jfree.data.time.SerialDate var55 = var53.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var56 = var46.getEndOfCurrentMonth(var55);
    boolean var58 = var17.isInRange(var37, var46, (-453));
    int var59 = var17.getDayOfWeek();
    boolean var60 = var1.isAfter((org.jfree.data.time.SerialDate)var17);
    int var61 = var1.toSerial();
    org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(100);
    int var65 = var64.getDayOfMonth();
    org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(31);
    boolean var68 = var64.isBefore(var67);
    org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.addMonths(1, var67);
    org.jfree.data.time.SerialDate var70 = var1.getEndOfCurrentMonth(var67);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var72 = var67.getPreviousDayOfWeek((-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(1, var1);
//     org.jfree.data.time.Year var4 = var3.getYear();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2014"+ "'", var2.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(12, 4, (-571));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var5 = var2.createCopy(0, 0);
    java.lang.Class var6 = var5.getTimePeriodClass();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var9 = var8.getStart();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    java.util.TimeZone var11 = null;
    org.jfree.data.time.RegularTimePeriod var12 = org.jfree.data.time.RegularTimePeriod.createInstance(var6, var9, var11);
    java.lang.ClassLoader var13 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var6);
    java.net.URL var14 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=January 2014]", var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 100);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     java.util.Calendar var4 = null;
//     var2.peg(var4);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)10.0f);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     java.lang.String var7 = var1.getRangeDescription();
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.String var11 = var10.toString();
//     int var13 = var10.compareTo((java.lang.Object)"2014");
//     int var14 = var9.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.lang.String var20 = var19.toString();
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(1, var19);
//     java.lang.Number var22 = var9.getValue((org.jfree.data.time.RegularTimePeriod)var21);
//     boolean var23 = var9.getNotify();
//     boolean var24 = var9.isEmpty();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var28 = var27.getPeriod();
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var30.setMaximumItemCount(0);
//     int var33 = var27.compareTo((java.lang.Object)var30);
//     org.jfree.data.time.TimeSeries var34 = var9.addAndOrUpdate(var30);
//     org.jfree.data.time.TimeSeries var35 = var1.addAndOrUpdate(var30);
//     var30.setDescription("Sunday");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "2014"+ "'", var20.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var2 = null;
//     var1.addPropertyChangeListener(var2);
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     java.lang.String var7 = var6.toString();
//     int var9 = var6.compareTo((java.lang.Object)"2014");
//     int var10 = var5.getIndex((org.jfree.data.time.RegularTimePeriod)var6);
//     var5.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     java.lang.String var16 = var15.toString();
//     int var18 = var15.compareTo((java.lang.Object)"2014");
//     int var19 = var14.getIndex((org.jfree.data.time.RegularTimePeriod)var15);
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, (-1.0d));
//     var5.add(var21, true);
//     var21.setValue((java.lang.Number)0.0d);
//     java.lang.Object var26 = null;
//     boolean var27 = var21.equals(var26);
//     var1.add(var21, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var31 = var1.getDataItem((-453));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "20-December-2014"+ "'", var16.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var2 = var1.getDayOfMonth();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(0, var7);
//     java.lang.String var9 = var8.toString();
//     boolean var10 = var1.isAfter(var8);
//     var1.setDescription("org.jfree.data.general.SeriesException: 20-December-2014");
//     int var13 = var1.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "31-December-1969"+ "'", var9.equals("31-December-1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var8 = var7.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
//     boolean var16 = var1.isOnOrAfter(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(100);
//     var19.setDescription("org.jfree.data.general.SeriesException: January");
//     java.lang.String var22 = var19.getDescription();
//     boolean var23 = var1.isOnOrBefore(var19);
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, 0.0d);
//     long var27 = var24.getLastMillisecond();
//     org.jfree.data.time.Year var28 = var24.getYear();
//     long var29 = var24.getLastMillisecond();
//     int var30 = var24.getMonth();
//     org.jfree.data.time.Year var31 = var24.getYear();
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     java.lang.String var35 = var34.toString();
//     int var37 = var34.compareTo((java.lang.Object)"2014");
//     int var38 = var33.getIndex((org.jfree.data.time.RegularTimePeriod)var34);
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (-1.0d));
//     java.lang.Number var41 = null;
//     var40.setValue(var41);
//     int var43 = var24.compareTo((java.lang.Object)var41);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var44 = var1.compareTo((java.lang.Object)var24);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "org.jfree.data.general.SeriesException: January"+ "'", var22.equals("org.jfree.data.general.SeriesException: January"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "20-December-2014"+ "'", var35.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     int var4 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var5 = var0.next();
//     java.util.Calendar var6 = null;
//     var0.peg(var6);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    var1.clear();
    var1.fireSeriesChanged();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var11 = var10.getStart();
    org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var11);
    org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var11);
    org.jfree.data.time.TimeSeriesDataItem var15 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
    java.util.Date var16 = var14.getEnd();
    java.util.TimeZone var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var16, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     long var6 = var5.getFirstMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getFirstMillisecond(var7);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     java.lang.String var27 = var26.toString();
//     int var29 = var26.compareTo((java.lang.Object)"2014");
//     int var30 = var25.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     int var31 = var26.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var26);
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, 0.0d);
//     long var36 = var33.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var33);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(10L);
//     org.jfree.data.time.RegularTimePeriod var40 = var39.previous();
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond(10L);
//     int var43 = var39.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(100);
//     var45.setDescription("org.jfree.data.general.SeriesException: January");
//     var45.setDescription("hi!");
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day(var45);
//     int var51 = var39.compareTo((java.lang.Object)var45);
//     boolean var52 = var1.equals((java.lang.Object)var45);
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     java.lang.String var56 = var55.toString();
//     int var58 = var55.compareTo((java.lang.Object)"2014");
//     int var59 = var54.getIndex((org.jfree.data.time.RegularTimePeriod)var55);
//     org.jfree.data.time.TimeSeriesDataItem var61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, (-1.0d));
//     int var62 = var55.getMonth();
//     int var63 = var55.getDayOfMonth();
//     int var64 = var55.getDayOfMonth();
//     java.lang.Class var67 = null;
//     org.jfree.data.time.TimeSeries var69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var72 = var69.createCopy(0, 0);
//     java.lang.Class var73 = var72.getTimePeriodClass();
//     java.lang.Object var74 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var67, var73);
//     java.io.InputStream var75 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var73);
//     org.jfree.data.time.TimeSeries var76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var55, var73);
//     java.beans.PropertyChangeListener var77 = null;
//     var76.addPropertyChangeListener(var77);
//     java.util.Collection var79 = var1.getTimePeriodsUniqueToOtherSeries(var76);
//     var1.setDescription("");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "20-December-2014"+ "'", var27.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var56 + "' != '" + "20-December-2014"+ "'", var56.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
// 
//   }

}
