
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, var4);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var8.addChangeListener(var11);
//     var8.setKey((java.lang.Comparable)'4');
//     boolean var15 = var8.getNotify();
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     java.lang.String var19 = var18.toString();
//     int var21 = var18.compareTo((java.lang.Object)"2014");
//     int var22 = var17.getIndex((org.jfree.data.time.RegularTimePeriod)var18);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var17.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     java.lang.String var28 = var27.toString();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(1, var27);
//     java.lang.Number var30 = var17.getValue((org.jfree.data.time.RegularTimePeriod)var29);
//     boolean var31 = var17.getNotify();
//     boolean var32 = var17.isEmpty();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var36 = var35.getPeriod();
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var38.setMaximumItemCount(0);
//     int var41 = var35.compareTo((java.lang.Object)var38);
//     org.jfree.data.time.TimeSeries var42 = var17.addAndOrUpdate(var38);
//     var17.setDomainDescription("hi!");
//     org.jfree.data.time.TimeSeries var45 = var8.addAndOrUpdate(var17);
//     boolean var46 = var45.isEmpty();
//     org.jfree.data.time.TimeSeries var48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     java.lang.String var50 = var49.toString();
//     int var52 = var49.compareTo((java.lang.Object)"2014");
//     int var53 = var48.getIndex((org.jfree.data.time.RegularTimePeriod)var49);
//     org.jfree.data.time.TimeSeriesDataItem var55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, (-1.0d));
//     org.jfree.data.time.RegularTimePeriod var56 = var55.getPeriod();
//     org.jfree.data.general.SeriesChangeEvent var57 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var55);
//     var45.add(var55, false);
//     boolean var60 = var6.equals((java.lang.Object)var45);
//     java.lang.String var61 = var45.getRangeDescription();
//     java.beans.PropertyChangeListener var62 = null;
//     var45.removePropertyChangeListener(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "2014"+ "'", var28.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + (-1)+ "'", var30.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "20-December-2014"+ "'", var50.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "Value"+ "'", var61.equals("Value"));
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     java.lang.String var5 = var1.getDescription();
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var7.setMaximumItemCount(0);
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(10, var11);
//     org.jfree.data.time.RegularTimePeriod var16 = var11.next();
//     var7.delete((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     java.lang.String var21 = var20.toString();
//     int var23 = var20.compareTo((java.lang.Object)"2014");
//     int var24 = var19.getIndex((org.jfree.data.time.RegularTimePeriod)var20);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var27 = var19.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.lang.String var30 = var29.toString();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month(1, var29);
//     java.lang.Number var32 = var19.getValue((org.jfree.data.time.RegularTimePeriod)var31);
//     boolean var33 = var11.equals((java.lang.Object)var31);
//     org.jfree.data.time.Year var34 = var31.getYear();
//     java.lang.Object var35 = null;
//     int var36 = var31.compareTo(var35);
//     org.jfree.data.time.Year var37 = var31.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var38 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var37);
//     java.lang.Object var39 = null;
//     boolean var40 = var37.equals(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "20-December-2014"+ "'", var21.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "2014"+ "'", var30.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + (-1)+ "'", var32.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.previous();
//     org.jfree.data.time.RegularTimePeriod var8 = var6.next();
//     long var9 = var6.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014L);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var7 = var4.createCopy(0, 0);
    java.lang.Class var8 = var7.getTimePeriodClass();
    java.io.InputStream var9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesException: hi!", var8);
    java.util.Date var10 = null;
    java.util.TimeZone var11 = null;
    org.jfree.data.time.RegularTimePeriod var12 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var10, var11);
    java.net.URL var13 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", var8);
    org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var16 = var15.getTime();
    org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(var16);
    long var18 = var17.getFirstMillisecond();
    java.util.Date var19 = var17.getTime();
    java.util.TimeZone var20 = null;
    org.jfree.data.time.RegularTimePeriod var21 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var19, var20);
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Fourth", var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
//     int var6 = var5.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    int var5 = var2.toSerial();
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(12);
    int var8 = var7.getMonth();
    int var9 = var7.toSerial();
    boolean var10 = var2.isBefore((org.jfree.data.time.SerialDate)var7);
    int var11 = var2.toSerial();
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, (org.jfree.data.time.SerialDate)var2);
    org.jfree.data.general.SeriesChangeEvent var13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
    org.jfree.data.time.Day var14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var4 = null;
//     long var5 = var3.getFirstMillisecond(var4);
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
//     java.util.Date var7 = var3.getTime();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day(var7);
//     long var10 = var9.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 28799999L);
// 
//   }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var26 = var25.getDescription();
//     java.util.List var27 = var25.getItems();
//     var25.setMaximumItemAge(2014L);
//     java.util.Collection var30 = var7.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, 10.0d);
//     java.lang.Object var35 = var34.clone();
//     boolean var36 = var25.equals((java.lang.Object)var34);
//     java.lang.String var37 = var25.getDomainDescription();
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var40 = new org.jfree.data.time.Day();
//     java.lang.String var41 = var40.toString();
//     int var43 = var40.compareTo((java.lang.Object)"2014");
//     int var44 = var39.getIndex((org.jfree.data.time.RegularTimePeriod)var40);
//     java.lang.Object var45 = var39.clone();
//     java.util.Collection var46 = var25.getTimePeriodsUniqueToOtherSeries(var39);
//     var25.setDomainDescription("January 2014");
//     var25.setDomainDescription("October");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "Time"+ "'", var37.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "20-December-2014"+ "'", var41.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     java.lang.Object var3 = null;
//     boolean var4 = var0.equals(var3);
//     org.jfree.data.time.RegularTimePeriod var5 = var0.next();
//     int var6 = var0.getYearValue();
//     long var7 = var0.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1417420800000L);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 10.0d);
    java.lang.Number var4 = var3.getValue();
    java.lang.Number var5 = null;
    var3.setValue(var5);
    var3.setValue((java.lang.Number)(-2649600000L));
    java.lang.Object var9 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10.0d+ "'", var4.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     var1.setDomainDescription("hi!");
//     var1.setNotify(true);
//     java.lang.Class var31 = var1.getTimePeriodClass();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update((-23554), (java.lang.Number)(-2208009600001L));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    long var3 = var1.getLastMillisecond();
    long var4 = var1.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var5 = var1.next();
    java.util.Calendar var6 = null;
    var1.peg(var6);
    java.util.Calendar var8 = null;
    long var9 = var1.getMiddleMillisecond(var8);
    long var10 = var1.getSerialIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.util.Calendar var3 = null;
//     var1.peg(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var7 = var5.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var8 = var5.next();
//     long var9 = var5.getLastMillisecond();
//     int var10 = var1.compareTo((java.lang.Object)var5);
//     long var11 = var1.getSerialIndex();
//     long var12 = var1.getLastMillisecond();
//     java.util.Date var13 = var1.getTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    java.lang.Object var6 = var1.clone();
    var1.setNotify(true);
    long var9 = var1.getMaximumItemAge();
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var11.setDomainDescription("January");
    var11.removeAgedItems(2014L, false);
    var11.setMaximumItemAge(0L);
    java.util.List var19 = var11.getItems();
    long var20 = var11.getMaximumItemAge();
    var11.fireSeriesChanged();
    boolean var22 = var1.equals((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getTime();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getFirstMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getLastMillisecond(var5);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setMaximumItemCount(0);
//     var8.clear();
//     java.lang.String var12 = var8.getDomainDescription();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     java.lang.String var15 = var14.toString();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(1, var14);
//     boolean var17 = var8.equals((java.lang.Object)var14);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     int var22 = var19.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var23 = null;
//     var19.removeChangeListener(var23);
//     java.beans.PropertyChangeListener var25 = null;
//     var19.removePropertyChangeListener(var25);
//     boolean var27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)var19);
//     org.jfree.data.time.RegularTimePeriod var28 = var14.next();
//     boolean var29 = var1.equals((java.lang.Object)var14);
//     long var30 = var14.getFirstMillisecond();
//     long var31 = var14.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var32 = var14.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "Time"+ "'", var12.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "2014"+ "'", var15.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setMaximumItemCount(0);
//     int var11 = var5.compareTo((java.lang.Object)var8);
//     java.lang.Number var12 = var5.getValue();
//     org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
//     boolean var15 = var5.equals((java.lang.Object)var14);
//     boolean var16 = var1.equals((java.lang.Object)var14);
//     org.jfree.data.time.TimePeriodFormatException var18 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:00 PST 1969");
//     var14.addSuppressed((java.lang.Throwable)var18);
//     java.lang.Throwable[] var20 = var14.getSuppressed();
//     java.lang.Throwable[] var21 = var14.getSuppressed();
//     java.lang.Throwable[] var22 = var14.getSuppressed();
//     java.lang.Throwable[] var23 = var14.getSuppressed();
//     java.lang.String var24 = var14.toString();
//     java.lang.Throwable var25 = null;
//     var14.addSuppressed(var25);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     java.lang.String var30 = var29.toString();
//     int var32 = var29.compareTo((java.lang.Object)"2014");
//     int var33 = var28.getIndex((org.jfree.data.time.RegularTimePeriod)var29);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var36 = var28.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     java.lang.String var39 = var38.toString();
//     org.jfree.data.time.Month var40 = new org.jfree.data.time.Month(1, var38);
//     java.lang.Number var41 = var28.getValue((org.jfree.data.time.RegularTimePeriod)var40);
//     boolean var42 = var28.getNotify();
//     boolean var43 = var28.isEmpty();
//     org.jfree.data.time.Month var44 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var44, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var47 = var46.getPeriod();
//     org.jfree.data.time.TimeSeries var49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var49.setMaximumItemCount(0);
//     int var52 = var46.compareTo((java.lang.Object)var49);
//     org.jfree.data.time.TimeSeries var53 = var28.addAndOrUpdate(var49);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var55 = var54.next();
//     org.jfree.data.time.TimeSeriesDataItem var57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var59 = var53.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var54, 1.0d);
//     org.jfree.data.time.FixedMillisecond var61 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var62 = var61.getStart();
//     org.jfree.data.time.FixedMillisecond var63 = new org.jfree.data.time.FixedMillisecond(var62);
//     org.jfree.data.time.Day var64 = new org.jfree.data.time.Day(var62);
//     boolean var65 = var54.equals((java.lang.Object)var64);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var22.update((org.jfree.data.time.RegularTimePeriod)var54, (java.lang.Number)12L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "20-December-2014"+ "'", var30.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "2014"+ "'", var39.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + (-1)+ "'", var41.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var2 = var1.getDayOfMonth();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var5 = var1.isBefore(var4);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var7.setMaximumItemCount(0);
//     int var10 = var7.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var7.removeChangeListener(var11);
//     java.lang.String var13 = var7.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     var7.delete((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var17.setMaximumItemCount(0);
//     int var20 = var17.getMaximumItemCount();
//     java.util.Collection var21 = var7.getTimePeriodsUniqueToOtherSeries(var17);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     java.lang.String var23 = var22.toString();
//     java.util.Date var24 = var22.getEnd();
//     int var25 = var22.getDayOfMonth();
//     java.lang.String var26 = var22.toString();
//     org.jfree.data.time.TimeSeriesDataItem var28 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)1414825199999L);
//     org.jfree.data.time.SerialDate var29 = var22.getSerialDate();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.createInstance(100);
//     var34.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addMonths(1, var34);
//     org.jfree.data.time.SerialDate var38 = var31.getEndOfCurrentMonth(var34);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(100);
//     var43.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addMonths(1, var43);
//     org.jfree.data.time.SerialDate var47 = var40.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var48 = var38.getEndOfCurrentMonth(var43);
//     boolean var49 = var1.isInRange(var29, var43);
//     org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var52 = var51.getMonth();
//     boolean var53 = var1.isOnOrAfter((org.jfree.data.time.SerialDate)var51);
//     java.lang.String var54 = var51.toString();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(100);
//     var56.setDescription("org.jfree.data.general.SeriesException: January");
//     var56.setDescription("hi!");
//     org.jfree.data.time.Day var61 = new org.jfree.data.time.Day(var56);
//     boolean var62 = var51.isBefore(var56);
//     org.jfree.data.time.TimeSeries var65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var66 = var65.getDescription();
//     java.lang.Comparable var67 = var65.getKey();
//     var65.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var72 = new org.jfree.data.time.Day();
//     java.lang.String var73 = var72.toString();
//     int var75 = var72.compareTo((java.lang.Object)"2014");
//     int var76 = var71.getIndex((org.jfree.data.time.RegularTimePeriod)var72);
//     java.lang.Object var77 = var71.clone();
//     org.jfree.data.time.Year var79 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var80 = var79.next();
//     org.jfree.data.time.TimeSeriesDataItem var82 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var79, 10.0d);
//     org.jfree.data.time.Month var83 = new org.jfree.data.time.Month(10, var79);
//     org.jfree.data.time.Year var84 = var83.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var86 = var71.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var83, (-1.0d));
//     java.util.Collection var87 = var65.getTimePeriodsUniqueToOtherSeries(var71);
//     boolean var88 = var65.isEmpty();
//     java.lang.Class var89 = var65.getTimePeriodClass();
//     org.jfree.data.time.FixedMillisecond var91 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var92 = var91.getStart();
//     org.jfree.data.time.FixedMillisecond var93 = new org.jfree.data.time.FixedMillisecond(var92);
//     java.util.TimeZone var94 = null;
//     org.jfree.data.time.RegularTimePeriod var95 = org.jfree.data.time.RegularTimePeriod.createInstance(var89, var92, var94);
//     java.lang.Object var96 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", var89);
//     java.lang.Class var97 = org.jfree.data.time.RegularTimePeriod.downsize(var89);
//     org.jfree.data.time.TimeSeries var98 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var62, var97);
//     int var99 = var98.getItemCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "Value"+ "'", var13.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "20-December-2014"+ "'", var23.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "11-January-1900"+ "'", var54.equals("11-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var67 + "' != '" + (byte)100+ "'", var67.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var73 + "' != '" + "20-December-2014"+ "'", var73.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var99 == 0);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     int var3 = var0.getDayOfMonth();
//     java.lang.String var4 = var0.toString();
//     java.lang.String var5 = var0.toString();
//     long var6 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var7 = var0.next();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(1, 0);
//     int var11 = var10.getMonth();
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var14 = var13.getMonth();
//     int var15 = var13.toSerial();
//     int var16 = var13.toSerial();
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(var20);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addYears(0, var22);
//     org.jfree.data.time.SerialDate var25 = var23.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var27 = var23.getPreviousDayOfWeek(1);
//     boolean var28 = var13.isOnOrAfter(var27);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var13);
//     java.util.Date var30 = var13.toDate();
//     int var31 = var10.compareTo((java.lang.Object)var13);
//     java.util.Date var32 = var13.toDate();
//     boolean var33 = var0.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var34 = null;
//     boolean var35 = var13.isOnOrBefore(var34);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2014);
//     int var2 = var1.getDayOfMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.getDayOfMonth();
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(2014);
//     int var8 = var7.getDayOfMonth();
//     int var9 = var7.getMonth();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate)var7);
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var14 = var13.getDayOfMonth();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var18 = var17.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addYears(0, var19);
//     java.lang.String var21 = var20.toString();
//     boolean var22 = var13.isAfter(var20);
//     java.lang.Object var23 = null;
//     boolean var24 = var13.equals(var23);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addDays(2014, (org.jfree.data.time.SerialDate)var13);
//     boolean var26 = var1.isInRange((org.jfree.data.time.SerialDate)var7, var25);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var29 = var28.getMonth();
//     int var30 = var28.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var33 = var32.getMonth();
//     int var34 = var32.getDayOfMonth();
//     var32.setDescription("January 0");
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var39 = var38.getMonth();
//     int var40 = var38.toSerial();
//     int var41 = var38.toSerial();
//     org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var44 = var43.getMonth();
//     int var45 = var43.toSerial();
//     boolean var46 = var38.isBefore((org.jfree.data.time.SerialDate)var43);
//     int var47 = var38.toSerial();
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(12);
//     boolean var50 = var38.isOnOrAfter((org.jfree.data.time.SerialDate)var49);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(100);
//     var52.setDescription("org.jfree.data.general.SeriesException: January");
//     var52.setDescription("hi!");
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day(var52);
//     int var58 = var38.compare(var52);
//     org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var61 = var60.getDayOfMonth();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var64 = var60.isBefore(var63);
//     int var65 = var60.getYYYY();
//     boolean var67 = var32.isInRange((org.jfree.data.time.SerialDate)var38, (org.jfree.data.time.SerialDate)var60, 0);
//     org.jfree.data.time.TimeSeries var69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var70 = new org.jfree.data.time.Day();
//     java.lang.String var71 = var70.toString();
//     int var73 = var70.compareTo((java.lang.Object)"2014");
//     int var74 = var69.getIndex((org.jfree.data.time.RegularTimePeriod)var70);
//     org.jfree.data.time.TimeSeriesDataItem var76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var70, (-1.0d));
//     int var77 = var70.getMonth();
//     int var78 = var70.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var79 = var70.next();
//     org.jfree.data.time.SerialDate var80 = var70.getSerialDate();
//     boolean var81 = var60.isOnOrBefore(var80);
//     java.util.Date var82 = var60.toDate();
//     int var83 = var28.compare((org.jfree.data.time.SerialDate)var60);
//     boolean var84 = var1.isOn((org.jfree.data.time.SerialDate)var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "31-December-1969"+ "'", var21.equals("31-December-1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == (-88));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var71 + "' != '" + "20-December-2014"+ "'", var71.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == (-88));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     int var4 = var0.getDayOfMonth();
//     int var5 = var0.getYear();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     var10.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(1, var10);
//     org.jfree.data.time.SerialDate var14 = var7.getEndOfCurrentMonth(var10);
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var18 = var17.getStart();
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(var18);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addYears(0, var20);
//     org.jfree.data.time.SerialDate var23 = var21.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var24 = var14.getEndOfCurrentMonth(var23);
//     int var25 = var0.compareTo((java.lang.Object)var23);
//     long var26 = var0.getLastMillisecond();
//     int var27 = var0.getYear();
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var30.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var33 = null;
//     var30.addChangeListener(var33);
//     var30.setKey((java.lang.Comparable)'4');
//     boolean var37 = var30.getNotify();
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var40 = var39.getTime();
//     java.util.Calendar var41 = null;
//     long var42 = var39.getFirstMillisecond(var41);
//     var30.setKey((java.lang.Comparable)var39);
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var46 = var45.next();
//     org.jfree.data.time.TimeSeriesDataItem var48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var45, 10.0d);
//     org.jfree.data.time.Month var49 = new org.jfree.data.time.Month(10, var45);
//     org.jfree.data.time.RegularTimePeriod var50 = var45.next();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var30.getDataItem((org.jfree.data.time.RegularTimePeriod)var45);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(100);
//     var55.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addMonths(1, var55);
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.addMonths(12, var55);
//     int var60 = var45.compareTo((java.lang.Object)12);
//     long var61 = var45.getSerialIndex();
//     org.jfree.data.time.Month var62 = new org.jfree.data.time.Month(9, var45);
//     org.jfree.data.time.TimeSeries var63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)9);
//     int var64 = var0.compareTo((java.lang.Object)var63);
//     org.jfree.data.time.RegularTimePeriod var65 = var0.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.removeChangeListener(var4);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var8 = null;
//     var7.addPropertyChangeListener(var8);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.String var13 = var12.toString();
//     int var15 = var12.compareTo((java.lang.Object)"2014");
//     int var16 = var11.getIndex((org.jfree.data.time.RegularTimePeriod)var12);
//     var11.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     java.lang.String var22 = var21.toString();
//     int var24 = var21.compareTo((java.lang.Object)"2014");
//     int var25 = var20.getIndex((org.jfree.data.time.RegularTimePeriod)var21);
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     var11.add(var27, true);
//     var27.setValue((java.lang.Number)0.0d);
//     java.lang.Object var32 = null;
//     boolean var33 = var27.equals(var32);
//     var7.add(var27, false);
//     var1.add(var27);
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var41 = var38.createCopy(0, 0);
//     java.lang.Class var42 = var41.getTimePeriodClass();
//     var41.removeAgedItems(false);
//     java.lang.String var45 = var41.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var47 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var48 = var47.getTime();
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(var48);
//     long var50 = var49.getFirstMillisecond();
//     long var51 = var49.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var53 = var41.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)2);
//     org.jfree.data.time.RegularTimePeriod var54 = var49.previous();
//     java.lang.Number var55 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var49, var55, false);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "20-December-2014"+ "'", var22.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "Value"+ "'", var45.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.addChangeListener(var5);
    var1.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var1.getTimePeriod((-605));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(30);
//     int var2 = var1.getYYYY();
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.String var6 = var5.toString();
//     int var8 = var5.compareTo((java.lang.Object)"2014");
//     int var9 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     org.jfree.data.time.RegularTimePeriod var12 = var11.getPeriod();
//     org.jfree.data.general.SeriesChangeEvent var13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var11);
//     java.lang.String var14 = var13.toString();
//     boolean var15 = var1.equals((java.lang.Object)var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "20-December-2014"+ "'", var6.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100);
    var3.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var3);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(12, var3);
    java.lang.String var8 = var7.getDescription();
    org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var15 = var14.getDescription();
    java.lang.Comparable var16 = var14.getKey();
    var14.setMaximumItemAge(1412146800000L);
    java.lang.String var19 = var14.getDescription();
    java.lang.Class var20 = var14.getTimePeriodClass();
    org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"", "30-April-1900", "Time", var20);
    org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var25 = var24.getDescription();
    java.lang.Comparable var26 = var24.getKey();
    var24.setMaximumItemAge(1412146800000L);
    java.lang.String var29 = var24.getDescription();
    java.lang.Class var30 = var24.getTimePeriodClass();
    java.lang.Object var31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var30);
    org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
    long var34 = var33.getLastMillisecond();
    long var35 = var33.getLastMillisecond();
    long var36 = var33.getLastMillisecond();
    java.util.Date var37 = var33.getTime();
    java.lang.Class var42 = null;
    org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var47 = var44.createCopy(0, 0);
    java.lang.Class var48 = var47.getTimePeriodClass();
    java.lang.Object var49 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var42, var48);
    java.io.InputStream var50 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var48);
    org.jfree.data.time.TimeSeries var51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var37, "30-April-1900", "December", var48);
    java.util.TimeZone var52 = null;
    org.jfree.data.time.RegularTimePeriod var53 = org.jfree.data.time.RegularTimePeriod.createInstance(var30, var37, var52);
    java.lang.Object var54 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var20, var30);
    org.jfree.data.time.TimeSeries var55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7, var30);
    java.lang.ClassLoader var56 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var30);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (byte)100+ "'", var16.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (byte)100+ "'", var26.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    java.beans.PropertyChangeListener var6 = null;
    var1.addPropertyChangeListener(var6);
    var1.setDescription("");
    java.lang.String var10 = var1.getDomainDescription();
    org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 0.0d);
    int var15 = var13.compareTo((java.lang.Object)(-62167363200000L));
    var13.setValue((java.lang.Number)(-1.0f));
    org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var21 = var20.getStart();
    org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(var21);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var21);
    org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(0, var23);
    boolean var25 = var13.equals((java.lang.Object)var24);
    java.lang.Number var26 = var13.getValue();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var13);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Time"+ "'", var10.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1.0f)+ "'", var26.equals((-1.0f)));

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var5 = var2.createCopy(0, 0);
//     java.lang.Class var6 = var5.getTimePeriodClass();
//     int var7 = var5.getMaximumItemCount();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.previous();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     org.jfree.data.time.RegularTimePeriod var14 = var12.next();
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var12);
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var12.next();
//     boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)var12);
//     org.jfree.data.time.RegularTimePeriod var19 = var12.next();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, 0.0d);
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(3, var12);
//     int var23 = var22.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2014);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var3 = var2.getDescription();
    java.lang.Comparable var4 = var2.getKey();
    var2.setMaximumItemAge(1412146800000L);
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var8 = var2.getTimePeriodClass();
    java.util.Date var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.RegularTimePeriod var11 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var9, var10);
    java.lang.ClassLoader var12 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var8);
    java.lang.Class var13 = org.jfree.data.time.RegularTimePeriod.downsize(var8);
    org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(1L);
    long var16 = var15.getLastMillisecond();
    long var17 = var15.getLastMillisecond();
    long var18 = var15.getLastMillisecond();
    java.util.Date var19 = var15.getTime();
    org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var19);
    java.util.TimeZone var21 = null;
    org.jfree.data.time.RegularTimePeriod var22 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var19, var21);
    java.lang.Class var23 = org.jfree.data.time.RegularTimePeriod.downsize(var8);
    java.io.InputStream var24 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("September", var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.Object var7 = var1.clone();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 10.0d);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(10, var9);
//     org.jfree.data.time.Year var14 = var13.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var18.setMaximumItemCount(0);
//     var18.clear();
//     java.lang.String var22 = var18.getDomainDescription();
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.lang.String var25 = var24.toString();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month(1, var24);
//     boolean var27 = var18.equals((java.lang.Object)var24);
//     int var29 = var24.compareTo((java.lang.Object)(short)1);
//     org.jfree.data.time.TimeSeriesDataItem var31 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)(-62133062400001L));
//     org.jfree.data.general.SeriesChangeListener var32 = null;
//     var1.removeChangeListener(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "Time"+ "'", var22.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "2014"+ "'", var25.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     java.lang.String var4 = var3.toString();
//     int var6 = var3.compareTo((java.lang.Object)"2014");
//     int var7 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     java.lang.String var13 = var12.toString();
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(1, var12);
//     java.lang.Number var15 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var14);
//     boolean var16 = var2.getNotify();
//     boolean var17 = var2.isEmpty();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var21 = var20.getPeriod();
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var23.setMaximumItemCount(0);
//     int var26 = var20.compareTo((java.lang.Object)var23);
//     org.jfree.data.time.TimeSeries var27 = var2.addAndOrUpdate(var23);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var29 = var28.next();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var33 = var27.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var28, 1.0d);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var36 = var35.getStart();
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond(var36);
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day(var36);
//     boolean var39 = var28.equals((java.lang.Object)var38);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var40 = new org.jfree.data.time.Month((-23554), var28);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "20-December-2014"+ "'", var4.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "2014"+ "'", var13.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + (-1)+ "'", var15.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.String var7 = var2.toString();
//     int var8 = var2.getMonth();
//     long var9 = var2.getSerialIndex();
//     int var10 = var2.getMonth();
//     org.jfree.data.time.SerialDate var11 = var2.getSerialDate();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     int var4 = var0.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var7 = var0.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var3 = var2.getDescription();
    java.lang.Comparable var4 = var2.getKey();
    var2.setMaximumItemAge(1412146800000L);
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var8 = var2.getTimePeriodClass();
    java.util.Date var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.RegularTimePeriod var11 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var9, var10);
    java.lang.ClassLoader var12 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var8);
    java.lang.Class var13 = org.jfree.data.time.RegularTimePeriod.downsize(var8);
    java.net.URL var14 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("October 10", var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     int var3 = var2.getMonth();
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var6 = var5.getMonth();
//     int var7 = var5.toSerial();
//     int var8 = var5.toSerial();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var12);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addYears(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var19 = var15.getPreviousDayOfWeek(1);
//     boolean var20 = var5.isOnOrAfter(var19);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var5);
//     java.util.Date var22 = var5.toDate();
//     int var23 = var2.compareTo((java.lang.Object)var5);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     boolean var26 = var24.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var27 = var24.next();
//     long var28 = var24.getLastMillisecond();
//     java.lang.String var29 = var24.toString();
//     org.jfree.data.time.SerialDate var30 = var24.getSerialDate();
//     boolean var31 = var5.isAfter(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "20-December-2014"+ "'", var29.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-25556));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.util.Collection var7 = var1.getTimePeriods();
//     java.beans.PropertyChangeListener var8 = null;
//     var1.removePropertyChangeListener(var8);
//     int var10 = var1.getMaximumItemCount();
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var12.setMaximumItemCount(0);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.data.time.RegularTimePeriod var21 = var16.next();
//     var12.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     java.lang.String var26 = var25.toString();
//     int var28 = var25.compareTo((java.lang.Object)"2014");
//     int var29 = var24.getIndex((org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     java.lang.String var35 = var34.toString();
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month(1, var34);
//     java.lang.Number var37 = var24.getValue((org.jfree.data.time.RegularTimePeriod)var36);
//     boolean var38 = var16.equals((java.lang.Object)var36);
//     java.lang.String var39 = var16.toString();
//     int var40 = var16.getYear();
//     int var41 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var16);
//     long var42 = var16.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "2014"+ "'", var35.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + (-1)+ "'", var37.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "2014"+ "'", var39.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1420099199999L);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }
// 
// 
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.String var6 = var5.toString();
//     int var8 = var5.compareTo((java.lang.Object)"2014");
//     int var9 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     java.lang.String var15 = var14.toString();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(1, var14);
//     java.lang.Number var17 = var4.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     var4.setDescription("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969");
//     java.lang.Comparable var20 = var4.getKey();
//     java.lang.Class var21 = var4.getTimePeriodClass();
//     java.io.InputStream var22 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=11-January-1900]", var21);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.lang.String var25 = var24.toString();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month(1, var24);
//     org.jfree.data.time.Year var27 = var26.getYear();
//     int var28 = var26.getMonth();
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var31 = var30.getDescription();
//     java.lang.Comparable var32 = var30.getKey();
//     var30.setMaximumItemAge(1412146800000L);
//     java.lang.String var35 = var30.getDescription();
//     java.lang.Class var36 = var30.getTimePeriodClass();
//     java.util.Date var37 = null;
//     java.util.TimeZone var38 = null;
//     org.jfree.data.time.RegularTimePeriod var39 = org.jfree.data.time.RegularTimePeriod.createInstance(var36, var37, var38);
//     java.lang.ClassLoader var40 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var36);
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var28, var36);
//     java.lang.ClassLoader var42 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var36);
//     java.lang.Object var43 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("9-April-1900", var21, var36);
//     java.io.InputStream var44 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("January", var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "20-December-2014"+ "'", var6.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "2014"+ "'", var15.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1)+ "'", var17.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + (byte)100+ "'", var20.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "2014"+ "'", var25.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + (byte)100+ "'", var32.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    var2.setDescription("org.jfree.data.general.SeriesException: January");
    var2.setDescription("hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-455), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var8 = var7.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
//     boolean var16 = var1.isOnOrAfter(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     java.util.Date var18 = var1.toDate();
//     int var19 = var1.toSerial();
//     org.jfree.data.time.SerialDate var20 = null;
//     boolean var21 = var1.isAfter(var20);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getLastMillisecond();
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 0.0d);
    org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var8.setMaximumItemCount(0);
    int var11 = var5.compareTo((java.lang.Object)var8);
    java.lang.Number var12 = var5.getValue();
    org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("January");
    boolean var15 = var5.equals((java.lang.Object)var14);
    boolean var16 = var1.equals((java.lang.Object)var14);
    org.jfree.data.time.TimePeriodFormatException var18 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:00 PST 1969");
    var14.addSuppressed((java.lang.Throwable)var18);
    java.lang.Throwable[] var20 = var14.getSuppressed();
    java.lang.Throwable[] var21 = var14.getSuppressed();
    java.lang.Throwable[] var22 = var14.getSuppressed();
    java.lang.Throwable[] var23 = var14.getSuppressed();
    java.lang.Throwable[] var24 = var14.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(var6);
//     long var8 = var7.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var9 = var7.next();
//     int var11 = var7.compareTo((java.lang.Object)0.0f);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, 10.0d);
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month(10, var13);
//     org.jfree.data.time.Year var18 = var17.getYear();
//     long var19 = var17.getFirstMillisecond();
//     java.lang.String var20 = var17.toString();
//     org.jfree.data.time.Year var21 = var17.getYear();
//     org.jfree.data.time.TimeSeries var22 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var21);
//     boolean var23 = var22.isEmpty();
//     java.lang.String var24 = var22.getDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "October 2014"+ "'", var20.equals("October 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.previous();
//     int var5 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var6 = var0.previous();
//     long var7 = var6.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419019199999L);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     java.lang.String var36 = var35.toString();
//     int var38 = var35.compareTo((java.lang.Object)"2014");
//     int var39 = var34.getIndex((org.jfree.data.time.RegularTimePeriod)var35);
//     int var40 = var35.getYear();
//     int var41 = var35.getMonth();
//     int var42 = var35.getMonth();
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     java.lang.String var46 = var45.toString();
//     int var48 = var45.compareTo((java.lang.Object)"2014");
//     int var49 = var44.getIndex((org.jfree.data.time.RegularTimePeriod)var45);
//     org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var45, (-1.0d));
//     int var52 = var45.getMonth();
//     int var53 = var45.getDayOfMonth();
//     java.lang.String var54 = var45.toString();
//     org.jfree.data.time.TimeSeries var55 = var26.createCopy((org.jfree.data.time.RegularTimePeriod)var35, (org.jfree.data.time.RegularTimePeriod)var45);
//     org.jfree.data.time.TimeSeries var58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var61 = var58.createCopy(0, 0);
//     java.lang.Class var62 = var61.getTimePeriodClass();
//     java.io.InputStream var63 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesException: hi!", var62);
//     org.jfree.data.time.TimeSeries var64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var35, var62);
//     int var65 = var35.getMonth();
//     int var66 = var35.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "20-December-2014"+ "'", var36.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "20-December-2014"+ "'", var46.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "20-December-2014"+ "'", var54.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 12);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var3 = var2.getDescription();
    java.lang.Comparable var4 = var2.getKey();
    var2.setMaximumItemAge(1412146800000L);
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var8 = var2.getTimePeriodClass();
    java.util.Date var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.RegularTimePeriod var11 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var9, var10);
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("20-December-2014", var8);
    java.lang.ClassLoader var13 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var8);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var13);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     long var6 = var5.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var11 = var8.createCopy(0, 0);
//     java.lang.Class var12 = var11.getTimePeriodClass();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var15 = var14.getStart();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     java.util.TimeZone var17 = null;
//     org.jfree.data.time.RegularTimePeriod var18 = org.jfree.data.time.RegularTimePeriod.createInstance(var12, var15, var17);
//     boolean var19 = var5.equals((java.lang.Object)var12);
//     int var20 = var5.getMonth();
//     int var21 = var5.getDayOfMonth();
//     org.jfree.data.time.TimePeriodFormatException var23 = new org.jfree.data.time.TimePeriodFormatException("20-December-2014");
//     java.lang.String var24 = var23.toString();
//     java.lang.Throwable[] var25 = var23.getSuppressed();
//     java.lang.String var26 = var23.toString();
//     boolean var27 = var5.equals((java.lang.Object)var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1420012800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 20-December-2014"+ "'", var24.equals("org.jfree.data.time.TimePeriodFormatException: 20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 20-December-2014"+ "'", var26.equals("org.jfree.data.time.TimePeriodFormatException: 20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     var1.clear();
//     java.lang.String var11 = var1.getRangeDescription();
//     java.lang.Comparable var12 = var1.getKey();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var15 = var14.getTime();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     java.util.Collection var17 = var1.getTimePeriods();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     java.lang.String var19 = var18.toString();
//     java.util.Date var20 = var18.getEnd();
//     int var21 = var18.getDayOfMonth();
//     java.lang.String var22 = var18.toString();
//     var1.setKey((java.lang.Comparable)var18);
//     java.util.Collection var24 = var1.getTimePeriods();
//     int var25 = var1.getMaximumItemCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Value"+ "'", var11.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + (byte)100+ "'", var12.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "20-December-2014"+ "'", var22.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2147483647);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     boolean var4 = var2.equals((java.lang.Object)"January");
//     var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
//     boolean var7 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var10 = var9.getStart();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var10);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var15 = var12.next();
//     java.util.Calendar var16 = null;
//     long var17 = var12.getMiddleMillisecond(var16);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(28, (-2), 28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.addChangeListener(var5);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var8.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var8.addChangeListener(var11);
//     var8.setKey((java.lang.Comparable)'4');
//     boolean var15 = var8.getNotify();
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     java.lang.String var19 = var18.toString();
//     int var21 = var18.compareTo((java.lang.Object)"2014");
//     int var22 = var17.getIndex((org.jfree.data.time.RegularTimePeriod)var18);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var17.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     java.lang.String var28 = var27.toString();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(1, var27);
//     java.lang.Number var30 = var17.getValue((org.jfree.data.time.RegularTimePeriod)var29);
//     boolean var31 = var17.getNotify();
//     boolean var32 = var17.isEmpty();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var36 = var35.getPeriod();
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var38.setMaximumItemCount(0);
//     int var41 = var35.compareTo((java.lang.Object)var38);
//     org.jfree.data.time.TimeSeries var42 = var17.addAndOrUpdate(var38);
//     var17.setDomainDescription("hi!");
//     org.jfree.data.time.TimeSeries var45 = var8.addAndOrUpdate(var17);
//     var8.setMaximumItemAge(1420099199999L);
//     org.jfree.data.time.TimeSeries var48 = var1.addAndOrUpdate(var8);
//     long var49 = var8.getMaximumItemAge();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "2014"+ "'", var28.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + (-1)+ "'", var30.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1420099199999L);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var3 = var2.getDescription();
    java.lang.Comparable var4 = var2.getKey();
    var2.setMaximumItemAge(1412146800000L);
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var8 = var2.getTimePeriodClass();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var8);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
    long var12 = var11.getLastMillisecond();
    long var13 = var11.getLastMillisecond();
    long var14 = var11.getLastMillisecond();
    java.util.Date var15 = var11.getTime();
    java.lang.Class var20 = null;
    org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var25 = var22.createCopy(0, 0);
    java.lang.Class var26 = var25.getTimePeriodClass();
    java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var20, var26);
    java.io.InputStream var28 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var26);
    org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var15, "30-April-1900", "December", var26);
    java.util.TimeZone var30 = null;
    org.jfree.data.time.RegularTimePeriod var31 = org.jfree.data.time.RegularTimePeriod.createInstance(var8, var15, var30);
    org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    int var3 = var2.getMonth();
    int var4 = var2.toSerial();
    int var5 = var2.toSerial();
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(12);
    int var8 = var7.getMonth();
    int var9 = var7.toSerial();
    boolean var10 = var2.isBefore((org.jfree.data.time.SerialDate)var7);
    org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var12.setMaximumItemCount(0);
    var12.clear();
    org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
    long var18 = var17.getLastMillisecond();
    long var19 = var17.getLastMillisecond();
    long var20 = var17.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var21 = var17.previous();
    java.util.Calendar var22 = null;
    long var23 = var17.getFirstMillisecond(var22);
    org.jfree.data.time.TimeSeriesDataItem var25 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, (-1.0d));
    var12.removeAgedItems(0L, true);
    var12.setMaximumItemCount(0);
    boolean var31 = var2.equals((java.lang.Object)0);
    org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(12);
    int var34 = var33.getMonth();
    int var35 = var33.toSerial();
    int var36 = var33.getDayOfWeek();
    java.lang.String var37 = var33.toString();
    java.util.Date var38 = var33.toDate();
    boolean var39 = var2.isAfter((org.jfree.data.time.SerialDate)var33);
    var2.setDescription("");
    org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths(7, (org.jfree.data.time.SerialDate)var2);
    int var43 = var2.toSerial();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "11-January-1900"+ "'", var37.equals("11-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 12);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     var1.setDomainDescription("20-December-2014");
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
//     var13.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var13);
//     org.jfree.data.time.SerialDate var17 = var10.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(var21);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var27 = var17.getEndOfCurrentMonth(var26);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day(var17);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var31 = var30.getTime();
//     java.util.Calendar var32 = null;
//     var30.peg(var32);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     boolean var36 = var34.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var37 = var34.next();
//     long var38 = var34.getLastMillisecond();
//     int var39 = var30.compareTo((java.lang.Object)var34);
//     java.lang.String var40 = var34.toString();
//     org.jfree.data.time.TimeSeries var41 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var28, (org.jfree.data.time.RegularTimePeriod)var34);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var43 = var41.getDataItem(12);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "20-December-2014"+ "'", var40.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var4 = var3.getDayOfMonth();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var7 = var3.isBefore(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var3);
//     org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var11 = var10.getMonth();
//     int var12 = var10.toSerial();
//     int var13 = var10.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var17 = var16.getDayOfMonth();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var20 = var16.isBefore(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var16);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     boolean var24 = var22.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var25 = var22.next();
//     long var26 = var22.getLastMillisecond();
//     java.lang.String var27 = var22.toString();
//     org.jfree.data.time.SerialDate var28 = var22.getSerialDate();
//     boolean var29 = var16.isOn(var28);
//     boolean var30 = var10.isAfter(var28);
//     int var31 = var3.compare(var28);
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var34 = var33.getMonth();
//     int var35 = var33.toSerial();
//     int var36 = var33.toSerial();
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var39 = var38.getMonth();
//     int var40 = var38.toSerial();
//     boolean var41 = var33.isBefore((org.jfree.data.time.SerialDate)var38);
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var43.setMaximumItemCount(0);
//     var43.clear();
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var49 = var48.getLastMillisecond();
//     long var50 = var48.getLastMillisecond();
//     long var51 = var48.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var52 = var48.previous();
//     java.util.Calendar var53 = null;
//     long var54 = var48.getFirstMillisecond(var53);
//     org.jfree.data.time.TimeSeriesDataItem var56 = var43.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var48, (-1.0d));
//     var43.removeAgedItems(0L, true);
//     var43.setMaximumItemCount(0);
//     boolean var62 = var33.equals((java.lang.Object)0);
//     org.jfree.data.time.SerialDate var63 = var28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var33);
//     java.lang.String var64 = var33.toString();
//     org.jfree.data.time.SpreadsheetDate var66 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var67 = var66.getMonth();
//     int var68 = var66.toSerial();
//     int var69 = var66.toSerial();
//     org.jfree.data.time.FixedMillisecond var72 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var73 = var72.getStart();
//     org.jfree.data.time.FixedMillisecond var74 = new org.jfree.data.time.FixedMillisecond(var73);
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.createInstance(var73);
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.addYears(0, var75);
//     org.jfree.data.time.SerialDate var78 = var76.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var80 = var76.getPreviousDayOfWeek(1);
//     boolean var81 = var66.isOnOrAfter(var80);
//     org.jfree.data.time.Day var82 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var66);
//     int var83 = var66.getYYYY();
//     boolean var84 = var33.isOnOrAfter((org.jfree.data.time.SerialDate)var66);
//     org.jfree.data.time.SerialDate var86 = org.jfree.data.time.SerialDate.createInstance(6);
//     boolean var87 = var66.isOnOrBefore(var86);
//     org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.addMonths(93, (org.jfree.data.time.SerialDate)var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "20-December-2014"+ "'", var27.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-41893));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var64 + "' != '" + "11-January-1900"+ "'", var64.equals("11-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     long var15 = var13.getSerialIndex();
//     long var16 = var13.getMiddleMillisecond();
//     long var17 = var13.getSerialIndex();
//     int var18 = var13.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var19 = var13.previous();
//     org.jfree.data.time.RegularTimePeriod var20 = var13.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1389902399999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-41981));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     java.lang.String var10 = var2.toString();
//     int var11 = var2.getDayOfMonth();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var16 = var13.createCopy(0, 0);
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var19 = var18.getDescription();
//     java.lang.Comparable var20 = var18.getKey();
//     org.jfree.data.time.TimeSeries var21 = var13.addAndOrUpdate(var18);
//     int var22 = var2.compareTo((java.lang.Object)var18);
//     org.jfree.data.time.RegularTimePeriod var23 = var2.next();
//     java.util.Calendar var24 = null;
//     var2.peg(var24);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     java.lang.String var10 = var2.toString();
//     int var11 = var2.getDayOfMonth();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var16 = var13.createCopy(0, 0);
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var19 = var18.getDescription();
//     java.lang.Comparable var20 = var18.getKey();
//     org.jfree.data.time.TimeSeries var21 = var13.addAndOrUpdate(var18);
//     int var22 = var2.compareTo((java.lang.Object)var18);
//     org.jfree.data.time.RegularTimePeriod var23 = var2.next();
//     org.jfree.data.time.RegularTimePeriod var24 = var2.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "20-December-2014"+ "'", var10.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + (byte)100+ "'", var20.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     long var31 = var17.getLastMillisecond();
//     org.jfree.data.time.Month var34 = new org.jfree.data.time.Month(10, 10);
//     int var35 = var17.compareTo((java.lang.Object)var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1419191999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var2);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var11 = var10.getDescription();
//     java.lang.Comparable var12 = var10.getKey();
//     var10.setMaximumItemAge(1412146800000L);
//     java.lang.String var15 = var10.getDescription();
//     java.lang.Class var16 = var10.getTimePeriodClass();
//     java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var16);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var20 = var19.getLastMillisecond();
//     long var21 = var19.getLastMillisecond();
//     long var22 = var19.getLastMillisecond();
//     java.util.Date var23 = var19.getTime();
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var33 = var30.createCopy(0, 0);
//     java.lang.Class var34 = var33.getTimePeriodClass();
//     java.lang.Object var35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var28, var34);
//     java.io.InputStream var36 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var34);
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var23, "30-April-1900", "December", var34);
//     java.util.TimeZone var38 = null;
//     org.jfree.data.time.RegularTimePeriod var39 = org.jfree.data.time.RegularTimePeriod.createInstance(var16, var23, var38);
//     org.jfree.data.general.SeriesChangeEvent var40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var16);
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2, "October 10", "org.jfree.data.general.SeriesException: January", var16);
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var43.setMaximumItemCount(0);
//     var43.clear();
//     java.lang.String var47 = var43.getDomainDescription();
//     java.lang.Object var48 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var43);
//     var43.setDescription("January");
//     java.util.Collection var51 = var41.getTimePeriodsUniqueToOtherSeries(var43);
//     org.jfree.data.time.FixedMillisecond var53 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var54 = var53.getTime();
//     java.util.Calendar var55 = null;
//     var53.peg(var55);
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day();
//     boolean var59 = var57.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var60 = var57.next();
//     long var61 = var57.getLastMillisecond();
//     int var62 = var53.compareTo((java.lang.Object)var57);
//     java.lang.String var63 = var57.toString();
//     var41.setKey((java.lang.Comparable)var63);
//     var41.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=11-January-1900]");
//     java.util.Collection var67 = var41.getTimePeriods();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + (byte)100+ "'", var12.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "Time"+ "'", var47.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "20-December-2014"+ "'", var63.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    var7.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
    var7.setDescription("");
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addDays(12, var7);
    java.lang.String var14 = var13.getDescription();
    boolean var15 = var1.isOn(var13);
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(100);
    int var18 = var17.getDayOfMonth();
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
    var23.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addMonths(1, var23);
    org.jfree.data.time.SerialDate var27 = var20.getEndOfCurrentMonth(var23);
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(100);
    var32.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(1, var32);
    org.jfree.data.time.SerialDate var36 = var29.getEndOfCurrentMonth(var32);
    org.jfree.data.time.SerialDate var37 = var27.getEndOfCurrentMonth(var32);
    org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(100);
    var42.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addMonths(1, var42);
    org.jfree.data.time.SerialDate var46 = var39.getEndOfCurrentMonth(var42);
    org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var50 = var49.getStart();
    org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond(var50);
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var50);
    org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addYears(0, var52);
    org.jfree.data.time.SerialDate var55 = var53.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var56 = var46.getEndOfCurrentMonth(var55);
    boolean var58 = var17.isInRange(var37, var46, (-453));
    int var59 = var17.getDayOfWeek();
    boolean var60 = var1.isAfter((org.jfree.data.time.SerialDate)var17);
    java.util.Date var61 = var17.toDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var63 = var17.getFollowingDayOfWeek((-20));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setMaximumItemCount(100);
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var10 = var9.getDescription();
    java.lang.Comparable var11 = var9.getKey();
    var9.setMaximumItemAge(1412146800000L);
    java.lang.String var14 = var9.getDescription();
    java.lang.Class var15 = var9.getTimePeriodClass();
    boolean var16 = var1.equals((java.lang.Object)var9);
    org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
    var1.delete((org.jfree.data.time.RegularTimePeriod)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (byte)100+ "'", var11.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.addChangeListener(var4);
    var1.setMaximumItemCount(100);
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var10 = var9.getDescription();
    java.lang.Comparable var11 = var9.getKey();
    var9.setMaximumItemAge(1412146800000L);
    java.lang.String var14 = var9.getDescription();
    java.lang.Class var15 = var9.getTimePeriodClass();
    boolean var16 = var1.equals((java.lang.Object)var9);
    var1.setNotify(false);
    var1.fireSeriesChanged();
    org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var24 = var21.createCopy(0, 0);
    org.jfree.data.general.SeriesChangeListener var25 = null;
    var21.addChangeListener(var25);
    java.util.Collection var27 = var1.getTimePeriodsUniqueToOtherSeries(var21);
    int var28 = var21.getMaximumItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (byte)100+ "'", var11.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2147483647);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     boolean var4 = var2.equals((java.lang.Object)"January");
//     var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(-1.0f));
//     boolean var7 = var1.getNotify();
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 10.0d);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var10);
//     org.jfree.data.time.Year var15 = var14.getYear();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.previous();
//     long var17 = var15.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var15.next();
//     int var21 = var15.getYear();
//     long var22 = var15.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2014L);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    org.jfree.data.time.Day var2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    var7.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
    org.jfree.data.time.SerialDate var11 = var4.getEndOfCurrentMonth(var7);
    org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var15 = var14.getStart();
    org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(var15);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var15);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addYears(0, var17);
    org.jfree.data.time.SerialDate var20 = var18.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var21 = var11.getEndOfCurrentMonth(var20);
    org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var26 = var25.getStart();
    org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(var26);
    org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var26);
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addYears(0, var28);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.addYears(0, var28);
    org.jfree.data.time.SerialDate var31 = var20.getEndOfCurrentMonth(var28);
    boolean var32 = var1.isOnOrAfter(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond((-62167363200000L));
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     java.lang.String var4 = var3.toString();
//     java.util.Date var5 = var3.getEnd();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(-453));
//     org.jfree.data.time.RegularTimePeriod var10 = var6.previous();
//     boolean var11 = var1.equals((java.lang.Object)var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "20-December-2014"+ "'", var4.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     int var3 = var2.getMonth();
//     int var5 = var2.compareTo((java.lang.Object)100L);
//     int var6 = var2.getMonth();
//     java.util.Calendar var7 = null;
//     long var8 = var2.getFirstMillisecond(var7);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, 0.0d);
//     long var14 = var2.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419105599999L);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(10, var1);
//     org.jfree.data.time.Year var6 = var5.getYear();
//     long var7 = var5.getFirstMillisecond();
//     java.lang.String var8 = var5.toString();
//     org.jfree.data.time.RegularTimePeriod var9 = var5.next();
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
//     org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var10);
//     java.lang.Object var12 = var11.getSource();
//     java.lang.Object var13 = var11.getSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "October 2014"+ "'", var8.equals("October 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     java.lang.String var5 = var1.getDescription();
//     java.beans.PropertyChangeListener var6 = null;
//     var1.addPropertyChangeListener(var6);
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var1.addChangeListener(var8);
//     var1.removeAgedItems(true);
//     java.lang.String var12 = var1.getRangeDescription();
//     var1.setDescription("2014");
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var17 = var16.getStart();
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day(var17);
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var21);
//     long var23 = var21.getSerialIndex();
//     int var24 = var21.getYear();
//     var1.add((org.jfree.data.time.RegularTimePeriod)var21, 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "Value"+ "'", var12.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 25568L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1969);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.fireSeriesChanged();
//     boolean var5 = var1.getNotify();
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     int var13 = var8.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, 1.0d);
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var2 = null;
//     var1.addPropertyChangeListener(var2);
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     java.lang.String var7 = var6.toString();
//     int var9 = var6.compareTo((java.lang.Object)"2014");
//     int var10 = var5.getIndex((org.jfree.data.time.RegularTimePeriod)var6);
//     java.util.Date var11 = var6.getStart();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var14 = var13.getLastMillisecond();
//     java.util.Calendar var15 = null;
//     var13.peg(var15);
//     java.util.Calendar var17 = null;
//     long var18 = var13.getMiddleMillisecond(var17);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(10, 100);
//     boolean var22 = var13.equals((java.lang.Object)100);
//     org.jfree.data.time.TimeSeries var23 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update((-605), (java.lang.Number)(-26407));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-453));
//     org.jfree.data.time.Year var7 = var3.getYear();
//     org.jfree.data.time.RegularTimePeriod var8 = var3.previous();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem(var8, (java.lang.Number)1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "20-December-2014"+ "'", var1.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.removeChangeListener(var4);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var8 = var7.getDescription();
//     java.lang.Comparable var9 = var7.getKey();
//     var7.setMaximumItemAge(1412146800000L);
//     java.lang.String var12 = var7.getDescription();
//     java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     var7.setDomainDescription("ThreadContext");
//     java.util.List var16 = var7.getItems();
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var18.setMaximumItemCount(0);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var23 = var22.next();
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month(10, var22);
//     org.jfree.data.time.RegularTimePeriod var27 = var22.next();
//     var18.delete((org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     java.lang.String var32 = var31.toString();
//     int var34 = var31.compareTo((java.lang.Object)"2014");
//     int var35 = var30.getIndex((org.jfree.data.time.RegularTimePeriod)var31);
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var38 = var30.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var36, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     java.lang.String var41 = var40.toString();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month(1, var40);
//     java.lang.Number var43 = var30.getValue((org.jfree.data.time.RegularTimePeriod)var42);
//     boolean var44 = var22.equals((java.lang.Object)var42);
//     org.jfree.data.general.SeriesChangeEvent var45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var42);
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var48 = var47.getMonth();
//     int var49 = var47.toSerial();
//     int var50 = var47.toSerial();
//     org.jfree.data.time.SpreadsheetDate var52 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var53 = var52.getMonth();
//     int var54 = var52.toSerial();
//     boolean var55 = var47.isBefore((org.jfree.data.time.SerialDate)var52);
//     int var56 = var47.toSerial();
//     int var57 = var42.compareTo((java.lang.Object)var47);
//     long var58 = var42.getSerialIndex();
//     var7.setKey((java.lang.Comparable)var58);
//     java.util.Collection var60 = var7.getTimePeriods();
//     boolean var61 = var7.getNotify();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "20-December-2014"+ "'", var32.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "2014"+ "'", var41.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + (-1)+ "'", var43.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     long var3 = var0.getMiddleMillisecond();
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var6 = var5.getMonth();
//     int var7 = var5.toSerial();
//     int var8 = var5.toSerial();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var12);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addYears(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var19 = var15.getPreviousDayOfWeek(1);
//     boolean var20 = var5.isOnOrAfter(var19);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var5);
//     int var22 = var0.compareTo((java.lang.Object)var21);
//     long var23 = var21.getFirstMillisecond();
//     long var24 = var21.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-2208096000000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-2208009600001L));
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.removeChangeListener(var4);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var8 = null;
//     var7.addPropertyChangeListener(var8);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.String var13 = var12.toString();
//     int var15 = var12.compareTo((java.lang.Object)"2014");
//     int var16 = var11.getIndex((org.jfree.data.time.RegularTimePeriod)var12);
//     var11.setDomainDescription("20-December-2014");
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     java.lang.String var22 = var21.toString();
//     int var24 = var21.compareTo((java.lang.Object)"2014");
//     int var25 = var20.getIndex((org.jfree.data.time.RegularTimePeriod)var21);
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     var11.add(var27, true);
//     var27.setValue((java.lang.Number)0.0d);
//     java.lang.Object var32 = null;
//     boolean var33 = var27.equals(var32);
//     var7.add(var27, false);
//     var1.add(var27);
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var39.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var42 = null;
//     var39.addChangeListener(var42);
//     var39.setKey((java.lang.Comparable)'4');
//     boolean var46 = var39.getNotify();
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var49 = var48.getTime();
//     java.util.Calendar var50 = null;
//     long var51 = var48.getFirstMillisecond(var50);
//     var39.setKey((java.lang.Comparable)var48);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var55 = var54.next();
//     org.jfree.data.time.TimeSeriesDataItem var57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, 10.0d);
//     org.jfree.data.time.Month var58 = new org.jfree.data.time.Month(10, var54);
//     org.jfree.data.time.RegularTimePeriod var59 = var54.next();
//     org.jfree.data.time.TimeSeriesDataItem var60 = var39.getDataItem((org.jfree.data.time.RegularTimePeriod)var54);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.createInstance(100);
//     var64.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.addMonths(1, var64);
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.addMonths(12, var64);
//     int var69 = var54.compareTo((java.lang.Object)12);
//     long var70 = var54.getSerialIndex();
//     org.jfree.data.time.Month var71 = new org.jfree.data.time.Month(9, var54);
//     java.lang.Number var72 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var54);
//     long var73 = var54.getFirstMillisecond();
//     java.util.Calendar var74 = null;
//     long var75 = var54.getLastMillisecond(var74);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test78"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    java.lang.String var7 = var1.getRangeDescription();
    boolean var8 = var1.isEmpty();
    var1.removeAgedItems(true);
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var1.removeChangeListener(var11);
    org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond((-62167363200000L));
    org.jfree.data.general.SeriesChangeEvent var15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var14);
    long var16 = var14.getLastMillisecond();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-62167363200000L));

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test79"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
    org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
    org.jfree.data.time.RegularTimePeriod var7 = var6.getPeriod();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var11 = var10.getStart();
    org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var11);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addYears(0, var13);
    var14.setDescription("January 2014");
    boolean var17 = var6.equals((java.lang.Object)var14);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addDays((-598), var14);
    boolean var19 = var2.isAfter(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addYears((-20), (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test80"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     var1.setNotify(false);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var20 = var19.getTime();
//     java.lang.String var21 = var19.toString();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, 0.0d);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var26 = var25.getLastMillisecond();
//     long var27 = var25.getFirstMillisecond();
//     java.util.Date var28 = var25.getTime();
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(var28);
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, (-1.0d));
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var34 = var33.getDescription();
//     java.lang.Comparable var35 = var33.getKey();
//     var33.setMaximumItemAge(1412146800000L);
//     java.lang.String var38 = var33.getDescription();
//     java.lang.Class var39 = var33.getTimePeriodClass();
//     java.util.Date var40 = null;
//     java.util.TimeZone var41 = null;
//     org.jfree.data.time.RegularTimePeriod var42 = org.jfree.data.time.RegularTimePeriod.createInstance(var39, var40, var41);
//     java.lang.ClassLoader var43 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var39);
//     java.lang.Class var44 = org.jfree.data.time.RegularTimePeriod.downsize(var39);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var47 = var46.getLastMillisecond();
//     long var48 = var46.getLastMillisecond();
//     long var49 = var46.getLastMillisecond();
//     java.util.Date var50 = var46.getTime();
//     org.jfree.data.time.Month var51 = new org.jfree.data.time.Month(var50);
//     java.util.TimeZone var52 = null;
//     org.jfree.data.time.RegularTimePeriod var53 = org.jfree.data.time.RegularTimePeriod.createInstance(var39, var50, var52);
//     java.lang.Class var54 = org.jfree.data.time.RegularTimePeriod.downsize(var39);
//     org.jfree.data.time.TimeSeries var55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var29, var39);
//     boolean var56 = var23.equals((java.lang.Object)var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var21.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + (byte)100+ "'", var35.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test81"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    int var4 = var1.toSerial();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
    org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
    boolean var16 = var1.isOnOrAfter(var15);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(100);
    var19.setDescription("org.jfree.data.general.SeriesException: January");
    java.lang.String var22 = var19.getDescription();
    boolean var23 = var1.isOnOrBefore(var19);
    int var24 = var1.getDayOfMonth();
    org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(12);
    int var27 = var26.getMonth();
    int var28 = var26.toSerial();
    org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var30 = var29.next();
    org.jfree.data.time.RegularTimePeriod var31 = var29.next();
    org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var29);
    var32.setDomainDescription("Time");
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(100);
    var39.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths(1, var39);
    org.jfree.data.time.SerialDate var43 = var36.getEndOfCurrentMonth(var39);
    var32.setKey((java.lang.Comparable)var39);
    int var45 = var26.compare(var39);
    org.jfree.data.time.SerialDate var46 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var26);
    java.util.Date var47 = var1.toDate();
    org.jfree.data.time.Day var48 = new org.jfree.data.time.Day(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "org.jfree.data.general.SeriesException: January"+ "'", var22.equals("org.jfree.data.general.SeriesException: January"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-88));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test82"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(100);
//     var4.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var4);
//     org.jfree.data.time.SerialDate var8 = var1.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
//     var13.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var13);
//     org.jfree.data.time.SerialDate var17 = var10.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.SerialDate var18 = var8.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var8);
//     java.lang.String var20 = var19.toString();
//     java.util.Calendar var21 = null;
//     var19.peg(var21);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test83"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-41981));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test84"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var26 = var25.getDescription();
//     java.util.List var27 = var25.getItems();
//     var25.setMaximumItemAge(2014L);
//     java.util.Collection var30 = var7.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, 10.0d);
//     java.lang.Object var35 = var34.clone();
//     boolean var36 = var25.equals((java.lang.Object)var34);
//     java.lang.String var37 = var25.getDomainDescription();
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var40 = new org.jfree.data.time.Day();
//     java.lang.String var41 = var40.toString();
//     int var43 = var40.compareTo((java.lang.Object)"2014");
//     int var44 = var39.getIndex((org.jfree.data.time.RegularTimePeriod)var40);
//     java.lang.Object var45 = var39.clone();
//     java.util.Collection var46 = var25.getTimePeriodsUniqueToOtherSeries(var39);
//     var25.removeAgedItems(true);
//     org.jfree.data.time.FixedMillisecond var50 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var51 = var50.getTime();
//     java.util.Calendar var52 = null;
//     long var53 = var50.getFirstMillisecond(var52);
//     java.util.Calendar var54 = null;
//     long var55 = var50.getLastMillisecond(var54);
//     long var56 = var50.getFirstMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var25.add((org.jfree.data.time.RegularTimePeriod)var50, (java.lang.Number)(short)1, false);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "Time"+ "'", var37.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "20-December-2014"+ "'", var41.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 10L);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test85"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     java.util.List var33 = var26.getItems();
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     java.lang.String var35 = var34.toString();
//     org.jfree.data.time.RegularTimePeriod var36 = var34.next();
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var43 = var40.createCopy(0, 0);
//     java.lang.Class var44 = var43.getTimePeriodClass();
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var47 = var46.getStart();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     java.util.TimeZone var49 = null;
//     org.jfree.data.time.RegularTimePeriod var50 = org.jfree.data.time.RegularTimePeriod.createInstance(var44, var47, var49);
//     java.lang.Class var51 = org.jfree.data.time.RegularTimePeriod.downsize(var44);
//     org.jfree.data.time.TimeSeries var52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var36, "org.jfree.data.general.SeriesChangeEvent[source=January 2014]", "org.jfree.data.general.SeriesException: hi!", var51);
//     org.jfree.data.time.TimeSeriesDataItem var54 = var26.addOrUpdate(var36, (java.lang.Number)(-1L));
//     org.jfree.data.time.RegularTimePeriod var55 = var26.getNextTimePeriod();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "2014"+ "'", var35.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test86"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     int var9 = var2.getMonth();
//     int var10 = var2.getDayOfMonth();
//     int var11 = var2.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var12 = var2.previous();
//     long var13 = var2.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var2.previous();
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     java.lang.String var18 = var17.toString();
//     int var20 = var17.compareTo((java.lang.Object)"2014");
//     int var21 = var16.getIndex((org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, (-1.0d));
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "hi!", "ThreadContext", var26);
//     java.util.List var28 = var27.getItems();
//     boolean var29 = var2.equals((java.lang.Object)var27);
//     long var30 = var27.getMaximumItemAge();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 9223372036854775807L);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test87"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test88"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var2);
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(var2, var7);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test89"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-109));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test90"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    long var7 = var6.getLastMillisecond();
    long var8 = var6.getLastMillisecond();
    long var9 = var6.getLastMillisecond();
    org.jfree.data.time.RegularTimePeriod var10 = var6.previous();
    java.util.Calendar var11 = null;
    long var12 = var6.getFirstMillisecond(var11);
    org.jfree.data.time.TimeSeriesDataItem var14 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
    var1.removeAgedItems(0L, true);
    var1.setMaximumItemCount(0);
    org.jfree.data.general.SeriesChangeListener var20 = null;
    var1.addChangeListener(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test91"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    var1.removeAgedItems(2014L, false);
    var1.fireSeriesChanged();
    java.lang.String var8 = var1.getDomainDescription();
    java.util.Collection var9 = var1.getTimePeriods();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "January"+ "'", var8.equals("January"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test92"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var3 = var2.getMonth();
//     int var4 = var2.toSerial();
//     int var5 = var2.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var9 = var8.getDayOfMonth();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(31);
//     boolean var12 = var8.isBefore(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate)var8);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     boolean var16 = var14.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var17 = var14.next();
//     long var18 = var14.getLastMillisecond();
//     java.lang.String var19 = var14.toString();
//     org.jfree.data.time.SerialDate var20 = var14.getSerialDate();
//     boolean var21 = var8.isOn(var20);
//     boolean var22 = var2.isAfter(var20);
//     int var23 = var2.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var26 = var25.getDayOfMonth();
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addYears(0, var31);
//     java.lang.String var33 = var32.toString();
//     boolean var34 = var25.isAfter(var32);
//     org.jfree.data.time.SerialDate var36 = var32.getPreviousDayOfWeek(6);
//     boolean var37 = var2.isOnOrBefore(var36);
//     int var38 = var2.getMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-598), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "31-December-1969"+ "'", var33.equals("31-December-1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test93"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     int var7 = var2.getYear();
//     int var8 = var2.getMonth();
//     int var9 = var2.getDayOfMonth();
//     java.lang.String var10 = var2.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "20-December-2014"+ "'", var10.equals("20-December-2014"));
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test94"); }
// 
// 
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var6 = var5.getDescription();
//     java.lang.Comparable var7 = var5.getKey();
//     var5.setMaximumItemAge(1412146800000L);
//     java.lang.String var10 = var5.getDescription();
//     java.lang.Class var11 = var5.getTimePeriodClass();
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"", "30-April-1900", "Time", var11);
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var16 = var15.getDescription();
//     java.lang.Comparable var17 = var15.getKey();
//     var15.setMaximumItemAge(1412146800000L);
//     java.lang.String var20 = var15.getDescription();
//     java.lang.Class var21 = var15.getTimePeriodClass();
//     java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var21);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var25 = var24.getLastMillisecond();
//     long var26 = var24.getLastMillisecond();
//     long var27 = var24.getLastMillisecond();
//     java.util.Date var28 = var24.getTime();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var38 = var35.createCopy(0, 0);
//     java.lang.Class var39 = var38.getTimePeriodClass();
//     java.lang.Object var40 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var33, var39);
//     java.io.InputStream var41 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var39);
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var28, "30-April-1900", "December", var39);
//     java.util.TimeZone var43 = null;
//     org.jfree.data.time.RegularTimePeriod var44 = org.jfree.data.time.RegularTimePeriod.createInstance(var21, var28, var43);
//     java.lang.Object var45 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var11, var21);
//     org.jfree.data.time.Month var47 = org.jfree.data.time.Month.parseMonth("December 2014");
//     org.jfree.data.time.RegularTimePeriod var48 = var47.previous();
//     java.util.Date var49 = var47.getEnd();
//     java.util.TimeZone var50 = null;
//     org.jfree.data.time.RegularTimePeriod var51 = org.jfree.data.time.RegularTimePeriod.createInstance(var11, var49, var50);
//     java.util.TimeZone var52 = null;
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year(var49, var52);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test95"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var2 = var1.getTime();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    java.util.Calendar var4 = null;
    var3.peg(var4);
    java.util.Calendar var6 = null;
    long var7 = var3.getLastMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var3.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test96"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
    var7.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
    var7.setDescription("");
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addDays(12, var7);
    java.lang.String var14 = var13.getDescription();
    boolean var15 = var1.isOn(var13);
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(100);
    int var18 = var17.getDayOfMonth();
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
    var23.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addMonths(1, var23);
    org.jfree.data.time.SerialDate var27 = var20.getEndOfCurrentMonth(var23);
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(100);
    var32.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(1, var32);
    org.jfree.data.time.SerialDate var36 = var29.getEndOfCurrentMonth(var32);
    org.jfree.data.time.SerialDate var37 = var27.getEndOfCurrentMonth(var32);
    org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(100);
    var42.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addMonths(1, var42);
    org.jfree.data.time.SerialDate var46 = var39.getEndOfCurrentMonth(var42);
    org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var50 = var49.getStart();
    org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond(var50);
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var50);
    org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addYears(0, var52);
    org.jfree.data.time.SerialDate var55 = var53.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var56 = var46.getEndOfCurrentMonth(var55);
    boolean var58 = var17.isInRange(var37, var46, (-453));
    int var59 = var17.getDayOfWeek();
    boolean var60 = var1.isAfter((org.jfree.data.time.SerialDate)var17);
    java.util.Date var61 = var17.toDate();
    org.jfree.data.time.Year var62 = new org.jfree.data.time.Year(var61);
    org.jfree.data.time.RegularTimePeriod var63 = var62.next();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test97"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1L, var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.addPropertyChangeListener(var3);
    var2.clear();
    var2.setDescription("Value");

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test98"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     var1.setKey((java.lang.Comparable)'4');
//     boolean var8 = var1.getNotify();
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     java.lang.String var12 = var11.toString();
//     int var14 = var11.compareTo((java.lang.Object)"2014");
//     int var15 = var10.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.lang.String var21 = var20.toString();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(1, var20);
//     java.lang.Number var23 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var22);
//     boolean var24 = var10.getNotify();
//     boolean var25 = var10.isEmpty();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var29 = var28.getPeriod();
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var31.setMaximumItemCount(0);
//     int var34 = var28.compareTo((java.lang.Object)var31);
//     org.jfree.data.time.TimeSeries var35 = var10.addAndOrUpdate(var31);
//     var10.setDomainDescription("hi!");
//     org.jfree.data.time.TimeSeries var38 = var1.addAndOrUpdate(var10);
//     java.lang.Object var39 = var1.clone();
//     java.lang.String var40 = var1.getDomainDescription();
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond(10L);
//     org.jfree.data.time.RegularTimePeriod var43 = var42.previous();
//     java.util.Calendar var44 = null;
//     var42.peg(var44);
//     java.util.Date var46 = var42.getEnd();
//     org.jfree.data.time.RegularTimePeriod var47 = var42.next();
//     var1.update((org.jfree.data.time.RegularTimePeriod)var42, (java.lang.Number)1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "2014"+ "'", var21.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "January"+ "'", var40.equals("January"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test99"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     java.lang.String var27 = var26.toString();
//     int var29 = var26.compareTo((java.lang.Object)"2014");
//     int var30 = var25.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     int var31 = var26.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var26);
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, 0.0d);
//     long var36 = var33.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var33);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(10L);
//     org.jfree.data.time.RegularTimePeriod var40 = var39.previous();
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond(10L);
//     int var43 = var39.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(100);
//     var45.setDescription("org.jfree.data.general.SeriesException: January");
//     var45.setDescription("hi!");
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day(var45);
//     int var51 = var39.compareTo((java.lang.Object)var45);
//     boolean var52 = var1.equals((java.lang.Object)var45);
//     int var53 = var1.getMaximumItemCount();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var55 = var1.getTimePeriod((-435));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "20-December-2014"+ "'", var27.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 2147483647);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test100"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("31-December-1969");
    org.jfree.data.time.TimePeriodFormatException var3 = new org.jfree.data.time.TimePeriodFormatException("20-December-2014");
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.jfree.data.general.SeriesException var6 = new org.jfree.data.general.SeriesException("hi!");
    java.lang.Throwable[] var7 = var6.getSuppressed();
    var3.addSuppressed((java.lang.Throwable)var6);
    var1.addSuppressed((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test101"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var8 = var7.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
//     boolean var16 = var1.isOnOrAfter(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     java.util.Date var18 = var1.toDate();
//     int var19 = var1.toSerial();
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     java.lang.String var23 = var22.toString();
//     int var25 = var22.compareTo((java.lang.Object)"2014");
//     int var26 = var21.getIndex((org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, (-1.0d));
//     org.jfree.data.time.RegularTimePeriod var29 = var28.getPeriod();
//     org.jfree.data.general.SeriesChangeEvent var30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var28);
//     boolean var31 = var1.equals((java.lang.Object)var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "20-December-2014"+ "'", var23.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
// 
//   }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test102"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"Following");
//     java.beans.PropertyChangeListener var2 = null;
//     var1.addPropertyChangeListener(var2);
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     java.lang.String var7 = var6.toString();
//     int var9 = var6.compareTo((java.lang.Object)"2014");
//     int var10 = var5.getIndex((org.jfree.data.time.RegularTimePeriod)var6);
//     java.util.Date var11 = var6.getStart();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var14 = var13.getLastMillisecond();
//     java.util.Calendar var15 = null;
//     var13.peg(var15);
//     java.util.Calendar var17 = null;
//     long var18 = var13.getMiddleMillisecond(var17);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(10, 100);
//     boolean var22 = var13.equals((java.lang.Object)100);
//     org.jfree.data.time.TimeSeries var23 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var13);
//     long var24 = var13.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test103"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     long var4 = var0.getLastMillisecond();
//     int var5 = var0.getDayOfMonth();
//     java.lang.String var6 = var0.toString();
//     long var7 = var0.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "20-December-2014"+ "'", var6.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419062400000L);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test104"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.general.SeriesChangeEvent var28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var25);
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var31 = var30.getMonth();
//     int var32 = var30.toSerial();
//     int var33 = var30.toSerial();
//     org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var36 = var35.getMonth();
//     int var37 = var35.toSerial();
//     boolean var38 = var30.isBefore((org.jfree.data.time.SerialDate)var35);
//     int var39 = var30.toSerial();
//     int var40 = var25.compareTo((java.lang.Object)var30);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var43 = var42.getMonth();
//     int var44 = var42.toSerial();
//     int var45 = var42.toSerial();
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var49 = var48.getStart();
//     org.jfree.data.time.FixedMillisecond var50 = new org.jfree.data.time.FixedMillisecond(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var49);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.addYears(0, var51);
//     org.jfree.data.time.SerialDate var54 = var52.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var56 = var52.getPreviousDayOfWeek(1);
//     boolean var57 = var42.isOnOrAfter(var56);
//     org.jfree.data.time.Day var58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var42);
//     org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.createInstance(100);
//     var60.setDescription("org.jfree.data.general.SeriesException: January");
//     java.lang.String var63 = var60.getDescription();
//     boolean var64 = var42.isOnOrBefore(var60);
//     int var65 = var42.getDayOfMonth();
//     org.jfree.data.time.SpreadsheetDate var67 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var68 = var67.getMonth();
//     int var69 = var67.toSerial();
//     org.jfree.data.time.Year var70 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var71 = var70.next();
//     org.jfree.data.time.RegularTimePeriod var72 = var70.next();
//     org.jfree.data.time.TimeSeries var73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var70);
//     var73.setDomainDescription("Time");
//     org.jfree.data.time.SerialDate var77 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.createInstance(100);
//     var80.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var83 = org.jfree.data.time.SerialDate.addMonths(1, var80);
//     org.jfree.data.time.SerialDate var84 = var77.getEndOfCurrentMonth(var80);
//     var73.setKey((java.lang.Comparable)var80);
//     int var86 = var67.compare(var80);
//     org.jfree.data.time.SerialDate var87 = var42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var67);
//     boolean var88 = var30.isOn(var87);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var90 = var87.getFollowingDayOfWeek(2014);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "org.jfree.data.general.SeriesException: January"+ "'", var63.equals("org.jfree.data.general.SeriesException: January"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == (-88));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == false);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test105"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     long var6 = var5.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)2147483647);
//     java.util.Calendar var9 = null;
//     var5.peg(var9);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test106"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    java.beans.PropertyChangeListener var5 = null;
    var1.removePropertyChangeListener(var5);
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var1.removeChangeListener(var7);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var10.setDomainDescription("January");
    var10.removeAgedItems(2014L, false);
    var10.removeAgedItems(false);
    org.jfree.data.time.TimeSeries var18 = var1.addAndOrUpdate(var10);
    org.jfree.data.general.SeriesChangeEvent var19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test107"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.previous();
//     int var5 = var0.getDayOfMonth();
//     long var6 = var0.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419148799999L);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test108"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     long var6 = var1.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     java.lang.String var10 = var9.toString();
//     int var12 = var9.compareTo((java.lang.Object)"2014");
//     int var13 = var8.getIndex((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (-1.0d));
//     int var16 = var9.getMonth();
//     int var17 = var9.getDayOfMonth();
//     int var18 = var9.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var19 = var9.previous();
//     var1.add(var19, 100.0d, true);
//     var1.clear();
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var25.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var28 = null;
//     var25.addChangeListener(var28);
//     var25.setKey((java.lang.Comparable)'4');
//     boolean var32 = var25.getNotify();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var34 = var33.next();
//     org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, 10.0d);
//     long var37 = var33.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var38 = var33.next();
//     java.util.Date var39 = var38.getEnd();
//     org.jfree.data.time.TimeSeriesDataItem var40 = var25.getDataItem(var38);
//     java.lang.Number var41 = var1.getValue(var38);
//     var1.setNotify(true);
//     var1.fireSeriesChanged();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "20-December-2014"+ "'", var10.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test109"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     var1.clear();
//     var1.fireSeriesChanged();
//     var1.setDescription("31-December-1969");
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var12.setMaximumItemCount(0);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.data.time.RegularTimePeriod var21 = var16.next();
//     var12.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     java.lang.String var26 = var25.toString();
//     int var28 = var25.compareTo((java.lang.Object)"2014");
//     int var29 = var24.getIndex((org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     java.lang.String var35 = var34.toString();
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month(1, var34);
//     java.lang.Number var37 = var24.getValue((org.jfree.data.time.RegularTimePeriod)var36);
//     boolean var38 = var16.equals((java.lang.Object)var36);
//     org.jfree.data.time.Year var39 = var36.getYear();
//     java.lang.Object var40 = null;
//     int var41 = var36.compareTo(var40);
//     org.jfree.data.time.RegularTimePeriod var42 = var36.next();
//     org.jfree.data.time.RegularTimePeriod var43 = var36.next();
//     java.lang.String var44 = var36.toString();
//     org.jfree.data.time.RegularTimePeriod var45 = var36.next();
//     java.lang.Number var46 = var1.getValue(var45);
//     java.lang.String var47 = var1.getDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "2014"+ "'", var35.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + (-1)+ "'", var37.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "January 2014"+ "'", var44.equals("January 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "31-December-1969"+ "'", var47.equals("31-December-1969"));
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test110"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getLastMillisecond();
//     long var3 = var1.getLastMillisecond();
//     long var4 = var1.getLastMillisecond();
//     java.util.Date var5 = var1.getTime();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var15 = var12.createCopy(0, 0);
//     java.lang.Class var16 = var15.getTimePeriodClass();
//     java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 0", var10, var16);
//     java.io.InputStream var18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October 2014", var16);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, "30-April-1900", "December", var16);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     long var21 = var20.getMiddleMillisecond();
//     var19.setKey((java.lang.Comparable)var20);
//     java.lang.String var23 = var20.toString();
//     int var24 = var20.getMonth();
//     java.util.Calendar var25 = null;
//     long var26 = var20.getLastMillisecond(var25);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test111"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     boolean var2 = var0.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     int var4 = var0.getDayOfMonth();
//     int var5 = var0.getYear();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(100);
//     var10.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(1, var10);
//     org.jfree.data.time.SerialDate var14 = var7.getEndOfCurrentMonth(var10);
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var18 = var17.getStart();
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(var18);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addYears(0, var20);
//     org.jfree.data.time.SerialDate var23 = var21.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var24 = var14.getEndOfCurrentMonth(var23);
//     int var25 = var0.compareTo((java.lang.Object)var23);
//     long var26 = var0.getLastMillisecond();
//     int var27 = var0.getYear();
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var30.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var33 = null;
//     var30.addChangeListener(var33);
//     var30.setKey((java.lang.Comparable)'4');
//     boolean var37 = var30.getNotify();
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var40 = var39.getTime();
//     java.util.Calendar var41 = null;
//     long var42 = var39.getFirstMillisecond(var41);
//     var30.setKey((java.lang.Comparable)var39);
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var46 = var45.next();
//     org.jfree.data.time.TimeSeriesDataItem var48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var45, 10.0d);
//     org.jfree.data.time.Month var49 = new org.jfree.data.time.Month(10, var45);
//     org.jfree.data.time.RegularTimePeriod var50 = var45.next();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var30.getDataItem((org.jfree.data.time.RegularTimePeriod)var45);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(100);
//     var55.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addMonths(1, var55);
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.addMonths(12, var55);
//     int var60 = var45.compareTo((java.lang.Object)12);
//     long var61 = var45.getSerialIndex();
//     org.jfree.data.time.Month var62 = new org.jfree.data.time.Month(9, var45);
//     org.jfree.data.time.TimeSeries var63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)9);
//     int var64 = var0.compareTo((java.lang.Object)var63);
//     int var65 = var0.getMonth();
//     org.jfree.data.time.TimeSeries var66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 12);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test112"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "April"+ "'", var1.equals("April"));

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test113"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     java.lang.String var5 = var4.toString();
//     java.util.Date var6 = var4.getEnd();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day(var6);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(100);
//     var14.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addMonths(1, var14);
//     org.jfree.data.time.SerialDate var18 = var11.getEndOfCurrentMonth(var14);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
//     var23.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addMonths(1, var23);
//     org.jfree.data.time.SerialDate var27 = var20.getEndOfCurrentMonth(var23);
//     org.jfree.data.time.SerialDate var28 = var18.getEndOfCurrentMonth(var23);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day(var18);
//     org.jfree.data.time.SerialDate var31 = var18.getFollowingDayOfWeek(1);
//     boolean var33 = var1.isInRange(var9, var18, 1900);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var37 = var36.getStart();
//     org.jfree.data.time.FixedMillisecond var38 = new org.jfree.data.time.FixedMillisecond(var37);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var37);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addYears(0, var39);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(100);
//     var45.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.addMonths(1, var45);
//     org.jfree.data.time.SerialDate var49 = var42.getEndOfCurrentMonth(var45);
//     org.jfree.data.time.SerialDate var50 = var40.getEndOfCurrentMonth(var49);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(100);
//     var52.setDescription("org.jfree.data.general.SeriesException: January");
//     java.lang.String var55 = var52.getDescription();
//     org.jfree.data.time.SerialDate var56 = var50.getEndOfCurrentMonth(var52);
//     java.lang.String var57 = var50.getDescription();
//     java.lang.String var58 = var50.getDescription();
//     org.jfree.data.time.SerialDate var59 = var18.getEndOfCurrentMonth(var50);
//     org.jfree.data.time.SerialDate var61 = var18.getPreviousDayOfWeek(3);
//     org.jfree.data.time.Day var62 = new org.jfree.data.time.Day(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "20-December-2014"+ "'", var5.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + "org.jfree.data.general.SeriesException: January"+ "'", var55.equals("org.jfree.data.general.SeriesException: January"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test114"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getEnd();
//     int var3 = var0.getDayOfMonth();
//     java.lang.String var4 = var0.toString();
//     org.jfree.data.time.SerialDate var5 = var0.getSerialDate();
//     long var6 = var0.getFirstMillisecond();
//     long var7 = var0.getFirstMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var0.getLastMillisecond(var8);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test115"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     var1.setMaximumItemCount(100);
//     int var17 = var1.getItemCount();
//     java.lang.Comparable var18 = var1.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + (byte)100+ "'", var18.equals((byte)100));
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test116"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
//     var4.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     boolean var9 = var7.equals((java.lang.Object)"January");
//     var4.add((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var13.getNotify();
//     boolean var28 = var13.isEmpty();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var32 = var31.getPeriod();
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var34.setMaximumItemCount(0);
//     int var37 = var31.compareTo((java.lang.Object)var34);
//     org.jfree.data.time.TimeSeries var38 = var13.addAndOrUpdate(var34);
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var40 = var39.next();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var44 = var38.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var39, 1.0d);
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     java.lang.String var48 = var47.toString();
//     int var50 = var47.compareTo((java.lang.Object)"2014");
//     int var51 = var46.getIndex((org.jfree.data.time.RegularTimePeriod)var47);
//     int var52 = var47.getYear();
//     int var53 = var47.getMonth();
//     int var54 = var47.getMonth();
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day();
//     java.lang.String var58 = var57.toString();
//     int var60 = var57.compareTo((java.lang.Object)"2014");
//     int var61 = var56.getIndex((org.jfree.data.time.RegularTimePeriod)var57);
//     org.jfree.data.time.TimeSeriesDataItem var63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var57, (-1.0d));
//     int var64 = var57.getMonth();
//     int var65 = var57.getDayOfMonth();
//     java.lang.String var66 = var57.toString();
//     org.jfree.data.time.TimeSeries var67 = var38.createCopy((org.jfree.data.time.RegularTimePeriod)var47, (org.jfree.data.time.RegularTimePeriod)var57);
//     boolean var68 = var4.equals((java.lang.Object)var38);
//     org.jfree.data.time.Day var69 = new org.jfree.data.time.Day();
//     boolean var71 = var69.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var72 = var69.next();
//     int var73 = var69.getDayOfMonth();
//     int var74 = var69.getYear();
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.createInstance(100);
//     var79.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var82 = org.jfree.data.time.SerialDate.addMonths(1, var79);
//     org.jfree.data.time.SerialDate var83 = var76.getEndOfCurrentMonth(var79);
//     org.jfree.data.time.FixedMillisecond var86 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var87 = var86.getStart();
//     org.jfree.data.time.FixedMillisecond var88 = new org.jfree.data.time.FixedMillisecond(var87);
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.createInstance(var87);
//     org.jfree.data.time.SerialDate var90 = org.jfree.data.time.SerialDate.addYears(0, var89);
//     org.jfree.data.time.SerialDate var92 = var90.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var93 = var83.getEndOfCurrentMonth(var92);
//     int var94 = var69.compareTo((java.lang.Object)var92);
//     long var95 = var69.getLastMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var69);
//     java.lang.Class var97 = var4.getTimePeriodClass();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + "20-December-2014"+ "'", var48.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var58 + "' != '" + "20-December-2014"+ "'", var58.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var66 + "' != '" + "20-December-2014"+ "'", var66.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var97);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test117"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getMiddleMillisecond();
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Calendar var5 = null;
    var4.peg(var5);
    long var7 = var4.getSerialIndex();
    boolean var8 = var1.equals((java.lang.Object)var4);
    java.util.Date var9 = var1.getStart();
    long var10 = var1.getLastMillisecond();
    long var11 = var1.getMiddleMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test118"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     int var4 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var7 = var6.getMonth();
//     int var8 = var6.toSerial();
//     int var9 = var6.getDayOfWeek();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(100);
//     var14.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addMonths(1, var14);
//     org.jfree.data.time.SerialDate var18 = var11.getEndOfCurrentMonth(var14);
//     boolean var19 = var6.isOnOrAfter(var14);
//     boolean var20 = var1.isOnOrAfter(var14);
//     java.lang.String var21 = var1.toString();
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     java.lang.String var25 = var24.toString();
//     int var27 = var24.compareTo((java.lang.Object)"2014");
//     int var28 = var23.getIndex((org.jfree.data.time.RegularTimePeriod)var24);
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (-1.0d));
//     int var31 = var24.getMonth();
//     int var32 = var24.getDayOfMonth();
//     int var33 = var24.getDayOfMonth();
//     int var34 = var24.getYear();
//     java.util.Date var35 = var24.getEnd();
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day(var35);
//     org.jfree.data.time.SerialDate var37 = var36.getSerialDate();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(100);
//     var42.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addMonths(1, var42);
//     org.jfree.data.time.SerialDate var46 = var39.getEndOfCurrentMonth(var42);
//     var46.setDescription("January 2014");
//     org.jfree.data.time.SerialDate var49 = var37.getEndOfCurrentMonth(var46);
//     boolean var50 = var1.isOnOrAfter(var46);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var52 = var46.getNearestDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "11-January-1900"+ "'", var21.equals("11-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "20-December-2014"+ "'", var25.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test119"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var1.removeChangeListener(var31);
//     org.jfree.data.general.SeriesChangeListener var33 = null;
//     var1.removeChangeListener(var33);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     java.lang.String var37 = var36.toString();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(1, var36);
//     org.jfree.data.time.Year var39 = var38.getYear();
//     long var40 = var38.getLastMillisecond();
//     long var41 = var38.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var42 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var38);
//     org.jfree.data.time.FixedMillisecond var44 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var45 = var44.getLastMillisecond();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var44);
//     long var47 = var44.getSerialIndex();
//     long var48 = var44.getSerialIndex();
//     java.util.Date var49 = var44.getStart();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "2014"+ "'", var37.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1391241599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test120"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var8 = var7.getDescription();
    java.lang.Comparable var9 = var7.getKey();
    var7.setMaximumItemAge(1412146800000L);
    java.lang.String var12 = var7.getDescription();
    java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
    org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var16 = var15.getStart();
    org.jfree.data.time.Month var17 = new org.jfree.data.time.Month(var16);
    var1.setKey((java.lang.Comparable)var17);
    org.jfree.data.general.SeriesChangeEvent var19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test121"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     long var6 = var1.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     java.lang.String var10 = var9.toString();
//     int var12 = var9.compareTo((java.lang.Object)"2014");
//     int var13 = var8.getIndex((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (-1.0d));
//     int var16 = var9.getMonth();
//     int var17 = var9.getDayOfMonth();
//     int var18 = var9.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var19 = var9.previous();
//     var1.add(var19, 100.0d, true);
//     var1.clear();
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var25.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var28 = null;
//     var25.addChangeListener(var28);
//     var25.setKey((java.lang.Comparable)'4');
//     boolean var32 = var25.getNotify();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var34 = var33.next();
//     org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, 10.0d);
//     long var37 = var33.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var38 = var33.next();
//     java.util.Date var39 = var38.getEnd();
//     org.jfree.data.time.TimeSeriesDataItem var40 = var25.getDataItem(var38);
//     java.lang.Number var41 = var1.getValue(var38);
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var43.setMaximumItemCount(0);
//     var43.clear();
//     java.lang.String var47 = var43.getDomainDescription();
//     int var48 = var43.getMaximumItemCount();
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     java.lang.String var52 = var51.toString();
//     int var54 = var51.compareTo((java.lang.Object)"2014");
//     int var55 = var50.getIndex((org.jfree.data.time.RegularTimePeriod)var51);
//     org.jfree.data.time.Day var56 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var58 = var50.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var56, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var60 = new org.jfree.data.time.Year();
//     java.lang.String var61 = var60.toString();
//     org.jfree.data.time.Month var62 = new org.jfree.data.time.Month(1, var60);
//     java.lang.Number var63 = var50.getValue((org.jfree.data.time.RegularTimePeriod)var62);
//     boolean var64 = var50.getNotify();
//     org.jfree.data.time.FixedMillisecond var66 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var68.setMaximumItemCount(0);
//     org.jfree.data.time.Year var72 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var73 = var72.next();
//     org.jfree.data.time.TimeSeriesDataItem var75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var72, 10.0d);
//     org.jfree.data.time.Month var76 = new org.jfree.data.time.Month(10, var72);
//     org.jfree.data.time.RegularTimePeriod var77 = var72.next();
//     var68.delete((org.jfree.data.time.RegularTimePeriod)var72);
//     org.jfree.data.time.TimeSeries var79 = var50.createCopy((org.jfree.data.time.RegularTimePeriod)var66, (org.jfree.data.time.RegularTimePeriod)var72);
//     long var80 = var72.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var81 = var72.next();
//     org.jfree.data.time.TimeSeriesDataItem var83 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var72, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var85 = var43.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var72, 0.0d);
//     long var86 = var72.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var87 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "20-December-2014"+ "'", var10.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "Time"+ "'", var47.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + "20-December-2014"+ "'", var52.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "2014"+ "'", var61.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + (-1)+ "'", var63.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var87);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test122"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    var1.clear();
    java.lang.String var5 = var1.getDescription();
    java.beans.PropertyChangeListener var6 = null;
    var1.addPropertyChangeListener(var6);
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var10 = var9.getTime();
    java.util.Calendar var11 = null;
    var9.peg(var11);
    java.util.Calendar var13 = null;
    var9.peg(var13);
    java.util.Calendar var15 = null;
    long var16 = var9.getFirstMillisecond(var15);
    org.jfree.data.time.TimeSeriesDataItem var18 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)(-100));
    org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond((-2649600000L));
    org.jfree.data.time.TimeSeriesDataItem var22 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test123"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var4 = var1.createCopy(0, 0);
    var1.setDomainDescription("Following");
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var8.setDomainDescription("January");
    var8.removeAgedItems(2014L, false);
    boolean var14 = var1.equals((java.lang.Object)2014L);
    boolean var15 = var1.isEmpty();
    var1.setRangeDescription("30-April-1900");
    org.jfree.data.general.SeriesChangeListener var18 = null;
    var1.removeChangeListener(var18);
    java.lang.String var20 = var1.getRangeDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "30-April-1900"+ "'", var20.equals("30-April-1900"));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test124"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-435));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test125"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getLastMillisecond();
//     long var8 = var6.getLastMillisecond();
//     long var9 = var6.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var6.previous();
//     java.util.Calendar var11 = null;
//     long var12 = var6.getFirstMillisecond(var11);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.data.time.Year var21 = var20.getYear();
//     long var22 = var20.getFirstMillisecond();
//     java.lang.Number var23 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var20);
//     org.jfree.data.time.RegularTimePeriod var24 = var20.previous();
//     org.jfree.data.time.RegularTimePeriod var25 = var20.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1412146800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test126"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var11.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var11.removeChangeListener(var14);
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var18 = var17.getDescription();
//     java.lang.Comparable var19 = var17.getKey();
//     var17.setMaximumItemAge(1412146800000L);
//     java.lang.String var22 = var17.getDescription();
//     java.util.Collection var23 = var11.getTimePeriodsUniqueToOtherSeries(var17);
//     var17.setDomainDescription("ThreadContext");
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var28 = var27.getLastMillisecond();
//     long var29 = var27.getLastMillisecond();
//     long var30 = var27.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var31 = var27.previous();
//     org.jfree.data.time.TimeSeriesDataItem var33 = var17.addOrUpdate(var31, (java.lang.Number)1.0d);
//     org.jfree.data.time.TimeSeriesDataItem var35 = var1.addOrUpdate(var31, (java.lang.Number)(short)(-1));
//     java.lang.Object var36 = null;
//     boolean var37 = var1.equals(var36);
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var40 = var39.getDescription();
//     java.lang.Comparable var41 = var39.getKey();
//     var39.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     java.lang.String var47 = var46.toString();
//     int var49 = var46.compareTo((java.lang.Object)"2014");
//     int var50 = var45.getIndex((org.jfree.data.time.RegularTimePeriod)var46);
//     java.lang.Object var51 = var45.clone();
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var54 = var53.next();
//     org.jfree.data.time.TimeSeriesDataItem var56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var53, 10.0d);
//     org.jfree.data.time.Month var57 = new org.jfree.data.time.Month(10, var53);
//     org.jfree.data.time.Year var58 = var57.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var60 = var45.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var57, (-1.0d));
//     java.util.Collection var61 = var39.getTimePeriodsUniqueToOtherSeries(var45);
//     org.jfree.data.time.TimeSeries var63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var64 = var63.getDescription();
//     java.util.List var65 = var63.getItems();
//     var63.setMaximumItemAge(2014L);
//     java.util.Collection var68 = var45.getTimePeriodsUniqueToOtherSeries(var63);
//     org.jfree.data.time.Day var69 = new org.jfree.data.time.Day();
//     java.lang.String var70 = var69.toString();
//     java.util.Date var71 = var69.getEnd();
//     int var72 = var69.getDayOfMonth();
//     java.lang.Object var73 = null;
//     boolean var74 = var69.equals(var73);
//     long var75 = var69.getLastMillisecond();
//     java.lang.Number var76 = var63.getValue((org.jfree.data.time.RegularTimePeriod)var69);
//     org.jfree.data.time.TimeSeries var77 = var1.addAndOrUpdate(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + (byte)100+ "'", var19.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + (byte)100+ "'", var41.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "20-December-2014"+ "'", var47.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var70 + "' != '" + "20-December-2014"+ "'", var70.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test127"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Following");
    java.lang.String var2 = var1.toString();
    org.jfree.data.time.TimePeriodFormatException var4 = new org.jfree.data.time.TimePeriodFormatException("20-December-2014");
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.jfree.data.general.SeriesException var7 = new org.jfree.data.general.SeriesException("hi!");
    java.lang.Throwable[] var8 = var7.getSuppressed();
    var4.addSuppressed((java.lang.Throwable)var7);
    var1.addSuppressed((java.lang.Throwable)var4);
    java.lang.String var11 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.general.SeriesException: Following"+ "'", var2.equals("org.jfree.data.general.SeriesException: Following"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "org.jfree.data.general.SeriesException: Following"+ "'", var11.equals("org.jfree.data.general.SeriesException: Following"));

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test128"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var19.setMaximumItemCount(0);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(10, var23);
//     org.jfree.data.time.RegularTimePeriod var28 = var23.next();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var30 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var1.removeChangeListener(var31);
//     org.jfree.data.general.SeriesChangeListener var33 = null;
//     var1.removeChangeListener(var33);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     java.lang.String var37 = var36.toString();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(1, var36);
//     org.jfree.data.time.Year var39 = var38.getYear();
//     long var40 = var38.getLastMillisecond();
//     long var41 = var38.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var42 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var38);
//     org.jfree.data.time.FixedMillisecond var44 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var45 = var44.getLastMillisecond();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var44);
//     org.jfree.data.time.Month var47 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var50 = var49.getPeriod();
//     java.util.Date var51 = var50.getEnd();
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day(var51);
//     long var53 = var52.getFirstMillisecond();
//     boolean var54 = var44.equals((java.lang.Object)var52);
//     long var55 = var44.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "2014"+ "'", var37.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1391241599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1420012800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1L);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test129"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.removeChangeListener(var4);
//     java.lang.Object var6 = var1.clone();
//     var1.setNotify(true);
//     long var9 = var1.getMaximumItemAge();
//     var1.clear();
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var12.setMaximumItemCount(0);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.data.time.RegularTimePeriod var21 = var16.next();
//     var12.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     java.lang.String var26 = var25.toString();
//     int var28 = var25.compareTo((java.lang.Object)"2014");
//     int var29 = var24.getIndex((org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     java.lang.String var35 = var34.toString();
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month(1, var34);
//     java.lang.Number var37 = var24.getValue((org.jfree.data.time.RegularTimePeriod)var36);
//     boolean var38 = var16.equals((java.lang.Object)var36);
//     org.jfree.data.time.Year var39 = var36.getYear();
//     java.lang.Object var40 = null;
//     int var41 = var36.compareTo(var40);
//     org.jfree.data.time.RegularTimePeriod var42 = var36.next();
//     java.lang.Class var43 = null;
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var42, var43);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.update(var42, (java.lang.Number)1391241599999L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "2014"+ "'", var35.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + (-1)+ "'", var37.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test130"); }


    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(0, var6);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(1969, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var7.getFollowingDayOfWeek(11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test131"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     int var4 = var1.getItemCount();
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     java.lang.String var8 = var7.toString();
//     int var10 = var7.compareTo((java.lang.Object)"2014");
//     int var11 = var6.getIndex((org.jfree.data.time.RegularTimePeriod)var7);
//     java.util.Date var12 = var7.getStart();
//     boolean var13 = var1.equals((java.lang.Object)var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "20-December-2014"+ "'", var8.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test132"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     java.lang.Comparable var3 = var1.getKey();
//     var1.setMaximumItemAge(1412146800000L);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.String var9 = var8.toString();
//     int var11 = var8.compareTo((java.lang.Object)"2014");
//     int var12 = var7.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var15);
//     org.jfree.data.time.Year var20 = var19.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     java.util.Collection var23 = var1.getTimePeriodsUniqueToOtherSeries(var7);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var26 = var25.getDescription();
//     java.util.List var27 = var25.getItems();
//     var25.setMaximumItemAge(2014L);
//     java.util.Collection var30 = var7.getTimePeriodsUniqueToOtherSeries(var25);
//     var25.removeAgedItems(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var34 = var25.getTimePeriod((-2002));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)100+ "'", var3.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test133"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.clear();
//     java.lang.String var5 = var1.getDomainDescription();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, var7);
//     boolean var10 = var1.equals((java.lang.Object)var7);
//     int var12 = var7.compareTo((java.lang.Object)(short)1);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(0L);
//     int var15 = var7.compareTo((java.lang.Object)0L);
//     java.lang.String var16 = var7.toString();
//     long var17 = var7.getLastMillisecond();
//     int var18 = var7.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "Time"+ "'", var5.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2014"+ "'", var8.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "2014"+ "'", var16.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2014);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test134"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     java.lang.String var2 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2014"+ "'", var2.equals("2014"));
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test135"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     int var4 = var1.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     java.lang.String var7 = var1.getRangeDescription();
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.String var11 = var10.toString();
//     int var13 = var10.compareTo((java.lang.Object)"2014");
//     int var14 = var9.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.lang.String var20 = var19.toString();
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(1, var19);
//     java.lang.Number var22 = var9.getValue((org.jfree.data.time.RegularTimePeriod)var21);
//     boolean var23 = var9.getNotify();
//     boolean var24 = var9.isEmpty();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var28 = var27.getPeriod();
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var30.setMaximumItemCount(0);
//     int var33 = var27.compareTo((java.lang.Object)var30);
//     org.jfree.data.time.TimeSeries var34 = var9.addAndOrUpdate(var30);
//     org.jfree.data.time.TimeSeries var35 = var1.addAndOrUpdate(var30);
//     var30.setDescription("20-December-2014");
//     int var38 = var30.getItemCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "2014"+ "'", var20.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test136"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("October 10");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test137"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, var5);
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     int var17 = var14.compareTo((java.lang.Object)"2014");
//     int var18 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.lang.String var24 = var23.toString();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(1, var23);
//     java.lang.Number var26 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.data.general.SeriesChangeEvent var28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var25);
//     long var29 = var25.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1388563200000L);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test138"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Calendar var4 = null;
    long var5 = var3.getFirstMillisecond(var4);
    int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
    java.lang.String var7 = var1.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var1.getValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test139"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    org.jfree.data.time.TimeSeries var6 = var3.createCopy(0, 0);
    java.lang.Class var7 = var6.getTimePeriodClass();
    java.io.InputStream var8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesException: hi!", var7);
    java.util.Date var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.RegularTimePeriod var11 = org.jfree.data.time.RegularTimePeriod.createInstance(var7, var9, var10);
    java.net.URL var12 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", var7);
    org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var15 = var14.getTime();
    org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(var15);
    long var17 = var16.getFirstMillisecond();
    java.util.Date var18 = var16.getTime();
    java.util.TimeZone var19 = null;
    org.jfree.data.time.RegularTimePeriod var20 = org.jfree.data.time.RegularTimePeriod.createInstance(var7, var18, var19);
    org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test140"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var1.removeChangeListener(var4);
//     java.lang.Object var6 = var1.clone();
//     var1.setNotify(true);
//     java.lang.String var9 = var1.getRangeDescription();
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var1.addChangeListener(var10);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var13.setMaximumItemCount(0);
//     var13.clear();
//     java.lang.String var17 = var13.getDomainDescription();
//     java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
//     var13.setDescription("January");
//     org.jfree.data.time.TimeSeries var23 = var13.createCopy(31, 1900);
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, 0.0d);
//     org.jfree.data.time.Year var27 = var24.getYear();
//     int var28 = var24.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var29 = var24.next();
//     java.lang.Number var30 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var24);
//     java.util.Collection var31 = var1.getTimePeriodsUniqueToOtherSeries(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "Value"+ "'", var9.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "Time"+ "'", var17.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test141"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var8 = var7.getDescription();
    java.lang.Comparable var9 = var7.getKey();
    var7.setMaximumItemAge(1412146800000L);
    java.lang.String var12 = var7.getDescription();
    java.util.Collection var13 = var1.getTimePeriodsUniqueToOtherSeries(var7);
    var1.setDomainDescription("Sun Dec 21 11:59:59 PST 2014");
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (byte)100+ "'", var9.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test142"); }
// 
// 
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var5 = var4.getDescription();
//     java.lang.Comparable var6 = var4.getKey();
//     var4.setMaximumItemAge(1412146800000L);
//     java.lang.String var9 = var4.getDescription();
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var10);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.String var13 = var12.toString();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var14, var16);
//     java.util.TimeZone var18 = null;
//     org.jfree.data.time.RegularTimePeriod var19 = org.jfree.data.time.RegularTimePeriod.createInstance(var10, var14, var18);
//     java.io.InputStream var20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var10);
//     java.io.InputStream var21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sunday", var10);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var24 = var23.getLastMillisecond();
//     java.util.Calendar var25 = null;
//     var23.peg(var25);
//     java.util.Date var27 = var23.getTime();
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month(var27);
//     java.util.TimeZone var29 = null;
//     org.jfree.data.time.RegularTimePeriod var30 = org.jfree.data.time.RegularTimePeriod.createInstance(var10, var27, var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (byte)100+ "'", var6.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test143"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    int var4 = var1.getDayOfWeek();
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(2014);
    java.lang.String var7 = var6.getDescription();
    int var8 = var6.getDayOfWeek();
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 0.0d);
    org.jfree.data.time.RegularTimePeriod var12 = var11.getPeriod();
    org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var14.setMaximumItemCount(0);
    int var17 = var11.compareTo((java.lang.Object)var14);
    java.lang.Object var18 = var11.clone();
    org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var23 = var22.getStart();
    org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(var23);
    org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var23);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addYears(0, var25);
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(0, var25);
    boolean var28 = var11.equals((java.lang.Object)var27);
    boolean var29 = var6.isOnOrBefore(var27);
    boolean var30 = var1.isBefore((org.jfree.data.time.SerialDate)var6);
    org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(12);
    int var33 = var32.getMonth();
    int var34 = var32.toSerial();
    org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var36 = var35.next();
    org.jfree.data.time.RegularTimePeriod var37 = var35.next();
    org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var35);
    var38.setDomainDescription("Time");
    org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(100);
    var45.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.addMonths(1, var45);
    org.jfree.data.time.SerialDate var49 = var42.getEndOfCurrentMonth(var45);
    var38.setKey((java.lang.Comparable)var45);
    int var51 = var32.compare(var45);
    org.jfree.data.time.SerialDate var53 = var32.getNearestDayOfWeek(4);
    org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(12);
    int var56 = var55.getMonth();
    int var57 = var55.toSerial();
    int var58 = var55.toSerial();
    org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(12);
    int var61 = var60.getMonth();
    int var62 = var60.toSerial();
    boolean var63 = var55.isBefore((org.jfree.data.time.SerialDate)var60);
    boolean var65 = var1.isInRange((org.jfree.data.time.SerialDate)var32, (org.jfree.data.time.SerialDate)var55, 2147483647);
    org.jfree.data.time.SpreadsheetDate var67 = new org.jfree.data.time.SpreadsheetDate(12);
    org.jfree.data.time.Day var68 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var67);
    org.jfree.data.time.FixedMillisecond var71 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var72 = var71.getStart();
    org.jfree.data.time.FixedMillisecond var73 = new org.jfree.data.time.FixedMillisecond(var72);
    org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(var72);
    org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.addYears(0, var74);
    org.jfree.data.time.SerialDate var77 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.createInstance(100);
    var80.setDescription("org.jfree.data.general.SeriesException: January");
    org.jfree.data.time.SerialDate var83 = org.jfree.data.time.SerialDate.addMonths(1, var80);
    org.jfree.data.time.SerialDate var84 = var77.getEndOfCurrentMonth(var80);
    org.jfree.data.time.SerialDate var85 = var75.getEndOfCurrentMonth(var84);
    org.jfree.data.time.SerialDate var87 = org.jfree.data.time.SerialDate.createInstance(100);
    var87.setDescription("org.jfree.data.general.SeriesException: January");
    java.lang.String var90 = var87.getDescription();
    org.jfree.data.time.SerialDate var91 = var85.getEndOfCurrentMonth(var87);
    boolean var93 = var32.isInRange((org.jfree.data.time.SerialDate)var67, var85, 93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-88));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var90 + "' != '" + "org.jfree.data.general.SeriesException: January"+ "'", var90.equals("org.jfree.data.general.SeriesException: January"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test144"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var1.removeChangeListener(var4);
    java.lang.Object var6 = var1.clone();
    var1.setNotify(true);
    long var9 = var1.getMaximumItemAge();
    java.lang.Comparable var10 = var1.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (byte)100+ "'", var10.equals((byte)100));

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test145"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.addDays(1, var3);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addDays(1969, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test146"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    java.util.List var3 = var1.getItems();
    var1.setMaximumItemAge(2014L);
    java.lang.Comparable var6 = var1.getKey();
    var1.setRangeDescription("Second");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)100+ "'", var6.equals((byte)100));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test147"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test148"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setMaximumItemCount(0);
//     var1.fireSeriesChanged();
//     boolean var5 = var1.getNotify();
//     java.lang.Comparable var6 = var1.getKey();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     java.lang.String var10 = var9.toString();
//     int var12 = var9.compareTo((java.lang.Object)"2014");
//     int var13 = var8.getIndex((org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.Object var14 = var8.clone();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 10.0d);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.data.time.Year var21 = var20.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, (-1.0d));
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var25.setMaximumItemCount(0);
//     int var28 = var25.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var29 = null;
//     var25.removeChangeListener(var29);
//     java.lang.String var31 = var25.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond();
//     var25.delete((org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var35.setMaximumItemCount(0);
//     int var38 = var35.getMaximumItemCount();
//     java.util.Collection var39 = var25.getTimePeriodsUniqueToOtherSeries(var35);
//     var35.removeAgedItems(true);
//     boolean var42 = var20.equals((java.lang.Object)true);
//     var1.setKey((java.lang.Comparable)var20);
//     org.jfree.data.time.RegularTimePeriod var44 = var20.previous();
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var46.setMaximumItemCount(0);
//     var46.clear();
//     java.lang.String var50 = var46.getDomainDescription();
//     java.lang.Object var51 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var46);
//     var46.setDescription("March");
//     int var54 = var46.getItemCount();
//     int var55 = var20.compareTo((java.lang.Object)var46);
//     int var56 = var46.getMaximumItemCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (byte)100+ "'", var6.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "20-December-2014"+ "'", var10.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "Value"+ "'", var31.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "Time"+ "'", var50.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test149"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test150"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     java.lang.Class var7 = var1.getTimePeriodClass();
//     java.lang.String var8 = var1.getDomainDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "Time"+ "'", var8.equals("Time"));
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test151"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     int var2 = var1.getMonth();
//     int var3 = var1.toSerial();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(100);
//     var7.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(1, var7);
//     var7.setDescription("");
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addDays(12, var7);
//     java.lang.String var14 = var13.getDescription();
//     boolean var15 = var1.isOn(var13);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var18 = var17.getDayOfMonth();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(100);
//     var23.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addMonths(1, var23);
//     org.jfree.data.time.SerialDate var27 = var20.getEndOfCurrentMonth(var23);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(100);
//     var32.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(1, var32);
//     org.jfree.data.time.SerialDate var36 = var29.getEndOfCurrentMonth(var32);
//     org.jfree.data.time.SerialDate var37 = var27.getEndOfCurrentMonth(var32);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(100);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(100);
//     var42.setDescription("org.jfree.data.general.SeriesException: January");
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addMonths(1, var42);
//     org.jfree.data.time.SerialDate var46 = var39.getEndOfCurrentMonth(var42);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Date var50 = var49.getStart();
//     org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond(var50);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var50);
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addYears(0, var52);
//     org.jfree.data.time.SerialDate var55 = var53.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var56 = var46.getEndOfCurrentMonth(var55);
//     boolean var58 = var17.isInRange(var37, var46, (-453));
//     int var59 = var17.getDayOfWeek();
//     boolean var60 = var1.isAfter((org.jfree.data.time.SerialDate)var17);
//     java.util.Date var61 = var17.toDate();
//     org.jfree.data.time.TimeSeries var63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var64 = new org.jfree.data.time.Day();
//     java.lang.String var65 = var64.toString();
//     int var67 = var64.compareTo((java.lang.Object)"2014");
//     int var68 = var63.getIndex((org.jfree.data.time.RegularTimePeriod)var64);
//     org.jfree.data.time.TimeSeriesDataItem var70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var64, (-1.0d));
//     int var71 = var64.getMonth();
//     int var72 = var64.getDayOfMonth();
//     int var73 = var64.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var74 = var64.previous();
//     long var75 = var64.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var76 = var64.previous();
//     org.jfree.data.time.SerialDate var77 = var64.getSerialDate();
//     java.lang.String var78 = var77.getDescription();
//     boolean var79 = var17.isOnOrBefore(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var65 + "' != '" + "20-December-2014"+ "'", var65.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == true);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test152"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("January");
    var1.removeAgedItems(2014L, false);
    var1.setMaximumItemAge(0L);
    java.util.List var9 = var1.getItems();
    long var10 = var1.getMaximumItemAge();
    var1.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var13 = var1.getDataItem(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0L);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test153"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setMaximumItemCount(0);
    int var4 = var1.getMaximumItemCount();
    var1.setDescription("hi!");
    java.lang.String var7 = var1.getRangeDescription();
    java.lang.Comparable var8 = var1.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)100+ "'", var8.equals((byte)100));

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test154"); }
// 
// 
//     java.lang.Object var0 = null;
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.previous();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     org.jfree.data.time.RegularTimePeriod var7 = var5.next();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
//     long var9 = var5.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var5.next();
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)var5);
//     boolean var12 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test155"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test156"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-25556), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test157"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var0.next();
//     java.lang.String var6 = var0.toString();
//     int var7 = var0.getYear();
//     java.lang.String var8 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "2014"+ "'", var6.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2014"+ "'", var8.equals("2014"));
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test158"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Date var35 = var34.getTime();
//     java.util.Calendar var36 = null;
//     var34.peg(var36);
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     boolean var40 = var38.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var41 = var38.next();
//     long var42 = var38.getLastMillisecond();
//     int var43 = var34.compareTo((java.lang.Object)var38);
//     java.lang.Object var44 = null;
//     int var45 = var38.compareTo(var44);
//     var26.delete((org.jfree.data.time.RegularTimePeriod)var38);
//     java.util.Calendar var47 = null;
//     long var48 = var38.getMiddleMillisecond(var47);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test159"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     boolean var9 = var7.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var10 = var7.next();
//     long var11 = var7.getLastMillisecond();
//     int var12 = var7.getDayOfMonth();
//     long var13 = var7.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var15.setDomainDescription("January");
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var15.removeChangeListener(var18);
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var22 = var21.getDescription();
//     java.lang.Comparable var23 = var21.getKey();
//     var21.setMaximumItemAge(1412146800000L);
//     java.lang.String var26 = var21.getDescription();
//     java.util.Collection var27 = var15.getTimePeriodsUniqueToOtherSeries(var21);
//     java.util.Collection var28 = org.jfree.chart.util.ObjectUtilities.deepClone(var27);
//     int var29 = var7.compareTo((java.lang.Object)var28);
//     var1.add((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-570), false);
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var34.setMaximumItemCount(0);
//     int var37 = var34.getMaximumItemCount();
//     org.jfree.data.general.SeriesChangeListener var38 = null;
//     var34.removeChangeListener(var38);
//     java.lang.String var40 = var34.getRangeDescription();
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     java.lang.String var44 = var43.toString();
//     int var46 = var43.compareTo((java.lang.Object)"2014");
//     int var47 = var42.getIndex((org.jfree.data.time.RegularTimePeriod)var43);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var50 = var42.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var48, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var52 = new org.jfree.data.time.Year();
//     java.lang.String var53 = var52.toString();
//     org.jfree.data.time.Month var54 = new org.jfree.data.time.Month(1, var52);
//     java.lang.Number var55 = var42.getValue((org.jfree.data.time.RegularTimePeriod)var54);
//     boolean var56 = var42.getNotify();
//     boolean var57 = var42.isEmpty();
//     org.jfree.data.time.Month var58 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var58, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var61 = var60.getPeriod();
//     org.jfree.data.time.TimeSeries var63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var63.setMaximumItemCount(0);
//     int var66 = var60.compareTo((java.lang.Object)var63);
//     org.jfree.data.time.TimeSeries var67 = var42.addAndOrUpdate(var63);
//     org.jfree.data.time.TimeSeries var68 = var34.addAndOrUpdate(var63);
//     org.jfree.data.time.TimeSeries var69 = var1.addAndOrUpdate(var68);
//     java.lang.String var70 = var69.getRangeDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + (byte)100+ "'", var23.equals((byte)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "Value"+ "'", var40.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "20-December-2014"+ "'", var44.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var53 + "' != '" + "2014"+ "'", var53.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + (-1)+ "'", var55.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var70 + "' != '" + "Value"+ "'", var70.equals("Value"));
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test160"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
    org.jfree.data.time.RegularTimePeriod var3 = var2.getPeriod();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var6 = var5.getTime();
    java.util.Calendar var7 = null;
    var5.peg(var7);
    java.util.Calendar var9 = null;
    var5.peg(var9);
    java.util.Calendar var11 = null;
    long var12 = var5.getFirstMillisecond(var11);
    long var13 = var5.getFirstMillisecond();
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var18 = var17.getDescription();
    java.lang.Comparable var19 = var17.getKey();
    var17.setMaximumItemAge(1412146800000L);
    java.beans.PropertyChangeListener var22 = null;
    var17.removePropertyChangeListener(var22);
    java.beans.PropertyChangeListener var24 = null;
    var17.addPropertyChangeListener(var24);
    java.util.Collection var26 = var17.getTimePeriods();
    java.lang.Class var27 = var17.getTimePeriodClass();
    java.io.InputStream var28 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sun Dec 21 11:59:59 PST 2014", var27);
    java.io.InputStream var29 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var27);
    boolean var30 = var5.equals((java.lang.Object)"");
    boolean var31 = var2.equals((java.lang.Object)"");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (byte)100+ "'", var19.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test161"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    int var2 = var1.getMonth();
    int var3 = var1.toSerial();
    int var4 = var1.toSerial();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
    org.jfree.data.time.SerialDate var13 = var11.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var15 = var11.getPreviousDayOfWeek(1);
    boolean var16 = var1.isOnOrAfter(var15);
    int var17 = var1.toSerial();
    int var18 = var1.getDayOfMonth();
    java.util.Date var19 = var1.toDate();
    int var20 = var1.toSerial();
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(2014);
    int var23 = var22.getDayOfWeek();
    org.jfree.data.time.SerialDate var24 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test162"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
    java.util.Date var2 = var1.getTime();
    java.util.Calendar var3 = null;
    var1.peg(var3);
    java.util.Calendar var5 = null;
    var1.peg(var5);
    java.util.Calendar var7 = null;
    long var8 = var1.getFirstMillisecond(var7);
    long var9 = var1.getFirstMillisecond();
    long var10 = var1.getLastMillisecond();
    java.util.Date var11 = var1.getTime();
    long var12 = var1.getSerialIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 10L);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test163"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     java.util.Calendar var4 = null;
//     var0.peg(var4);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test164"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(10L);
//     java.util.Calendar var4 = null;
//     long var5 = var3.getFirstMillisecond(var4);
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var3);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     boolean var9 = var7.equals((java.lang.Object)"January");
//     org.jfree.data.time.RegularTimePeriod var10 = var7.next();
//     java.lang.Number var11 = null;
//     var1.add((org.jfree.data.time.RegularTimePeriod)var7, var11);
//     long var13 = var7.getLastMillisecond();
//     int var14 = var7.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2014);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test165"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesException: 20-December-2014");

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test166"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.String var3 = var2.toString();
//     int var5 = var2.compareTo((java.lang.Object)"2014");
//     int var6 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var2);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(1, var11);
//     java.lang.Number var14 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     boolean var15 = var1.getNotify();
//     boolean var16 = var1.isEmpty();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var19.getPeriod();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var22.setMaximumItemCount(0);
//     int var25 = var19.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var26 = var1.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     java.lang.String var36 = var35.toString();
//     int var38 = var35.compareTo((java.lang.Object)"2014");
//     int var39 = var34.getIndex((org.jfree.data.time.RegularTimePeriod)var35);
//     int var40 = var35.getYear();
//     int var41 = var35.getMonth();
//     int var42 = var35.getMonth();
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     java.lang.String var46 = var45.toString();
//     int var48 = var45.compareTo((java.lang.Object)"2014");
//     int var49 = var44.getIndex((org.jfree.data.time.RegularTimePeriod)var45);
//     org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var45, (-1.0d));
//     int var52 = var45.getMonth();
//     int var53 = var45.getDayOfMonth();
//     java.lang.String var54 = var45.toString();
//     org.jfree.data.time.TimeSeries var55 = var26.createCopy((org.jfree.data.time.RegularTimePeriod)var35, (org.jfree.data.time.RegularTimePeriod)var45);
//     java.lang.String var56 = var35.toString();
//     int var57 = var35.getYear();
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     org.jfree.data.time.Day var60 = new org.jfree.data.time.Day();
//     java.lang.String var61 = var60.toString();
//     int var63 = var60.compareTo((java.lang.Object)"2014");
//     int var64 = var59.getIndex((org.jfree.data.time.RegularTimePeriod)var60);
//     org.jfree.data.time.Day var65 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var67 = var59.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var65, (java.lang.Number)(-1));
//     org.jfree.data.time.Year var69 = new org.jfree.data.time.Year();
//     java.lang.String var70 = var69.toString();
//     org.jfree.data.time.Month var71 = new org.jfree.data.time.Month(1, var69);
//     java.lang.Number var72 = var59.getValue((org.jfree.data.time.RegularTimePeriod)var71);
//     boolean var73 = var59.getNotify();
//     org.jfree.data.time.FixedMillisecond var75 = new org.jfree.data.time.FixedMillisecond(1419191999999L);
//     org.jfree.data.time.TimeSeries var77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var77.setMaximumItemCount(0);
//     org.jfree.data.time.Year var81 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var82 = var81.next();
//     org.jfree.data.time.TimeSeriesDataItem var84 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var81, 10.0d);
//     org.jfree.data.time.Month var85 = new org.jfree.data.time.Month(10, var81);
//     org.jfree.data.time.RegularTimePeriod var86 = var81.next();
//     var77.delete((org.jfree.data.time.RegularTimePeriod)var81);
//     org.jfree.data.time.TimeSeries var88 = var59.createCopy((org.jfree.data.time.RegularTimePeriod)var75, (org.jfree.data.time.RegularTimePeriod)var81);
//     boolean var89 = var35.equals((java.lang.Object)var88);
//     java.beans.PropertyChangeListener var90 = null;
//     var88.removePropertyChangeListener(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "20-December-2014"+ "'", var36.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "20-December-2014"+ "'", var46.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "20-December-2014"+ "'", var54.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var56 + "' != '" + "20-December-2014"+ "'", var56.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "20-December-2014"+ "'", var61.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var70 + "' != '" + "2014"+ "'", var70.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var72 + "' != '" + (-1)+ "'", var72.equals((-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == false);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test167"); }


    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(2014);
    int var4 = var3.getDayOfMonth();
    int var5 = var3.toSerial();
    int var6 = var3.getDayOfMonth();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate)var3);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(100, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

}
