
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, Double.NaN, Double.NaN);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var14 = var12.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var17 = new org.jfree.chart.entity.CategoryItemEntity(var2, "hi!", "", (org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var21 = var18.getLegendItem((-1), 100);
//     var18.setBaseShapesFilled(false);
//     java.awt.Paint var25 = var18.getSeriesOutlinePaint((-1));
//     java.awt.Paint var27 = var18.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic(var2, var27);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     org.jfree.chart.plot.Plot var31 = var30.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getInsets();
//     double var34 = var32.calculateBottomOutset(100.0d);
//     var28.setPadding(var32);
//     java.awt.Paint var36 = var28.getOutlinePaint();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
//     org.jfree.data.Range var41 = var40.getHeightRange();
//     org.jfree.data.Range var44 = new org.jfree.data.Range(1.0d, 100.0d);
//     double var45 = var44.getCentralValue();
//     double var46 = var44.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var47 = var40.toRangeWidth(var44);
//     org.jfree.chart.util.Size2D var48 = var28.arrange(var37, var40);
//     java.awt.Stroke var49 = var28.getLineStroke();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 50.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     java.awt.Color var4 = java.awt.Color.getColor("ThreadContext", 10);
//     boolean var5 = org.jfree.chart.util.PaintUtilities.equal(var1, (java.awt.Paint)var4);
//     java.lang.String var6 = var4.toString();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var12 = var9.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var16 = null;
//     var14.axisChanged(var16);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var12, (org.jfree.chart.plot.Plot)var14, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var23 = var20.getLegendItem((-1), 100);
//     var20.setBaseShapesFilled(false);
//     java.awt.Paint var27 = var20.getSeriesOutlinePaint((-1));
//     boolean var28 = var19.equals((java.lang.Object)var20);
//     var19.setTitle("ThreadContext");
//     org.jfree.chart.renderer.category.StackedAreaRenderer var32 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var33 = var32.getEndType();
//     java.awt.Stroke var36 = var32.getItemStroke(0, 0);
//     var19.setBorderStroke(var36);
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month();
//     long var39 = var38.getSerialIndex();
//     java.util.Date var40 = var38.getEnd();
//     org.jfree.chart.text.TextBlock var41 = null;
//     org.jfree.chart.text.TextBlockAnchor var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D("");
//     var45.configure();
//     org.jfree.chart.util.RectangleInsets var47 = var45.getLabelInsets();
//     var43.setAxisOffset(var47);
//     org.jfree.chart.plot.CategoryMarker var50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Stroke var51 = var50.getOutlineStroke();
//     var43.addDomainMarker((org.jfree.chart.plot.Marker)var50);
//     var50.setLabel("org.jfree.chart.event.RendererChangeEvent[source=false]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var55 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var56.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var60 = var56.getBaseLinesVisible();
//     java.lang.Boolean var62 = var56.getSeriesVisibleInLegend(10);
//     java.awt.Paint var63 = var56.getBaseItemLabelPaint();
//     java.awt.Color var66 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var67 = null;
//     float[] var68 = var66.getRGBColorComponents(var67);
//     var56.setBaseItemLabelPaint((java.awt.Paint)var66);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var71 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var72 = var71.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var73 = var71.getBaseNegativeItemLabelPosition();
//     var56.setBasePositiveItemLabelPosition(var73, true);
//     var55.setPositiveItemLabelPositionFallback(var73);
//     org.jfree.chart.text.TextAnchor var77 = var73.getRotationAnchor();
//     var50.setLabelTextAnchor(var77);
//     org.jfree.chart.axis.CategoryTick var80 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)var40, var41, var42, var77, 2.0d);
//     org.jfree.chart.axis.DateAxis var81 = new org.jfree.chart.axis.DateAxis();
//     double var82 = var81.getLabelAngle();
//     org.jfree.chart.axis.DateAxis var83 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var84 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var87 = var84.getLegendItem((-1), 100);
//     var84.setBaseShapesFilled(false);
//     java.awt.Paint var91 = var84.getSeriesOutlinePaint((-1));
//     java.awt.Paint var93 = var84.lookupSeriesOutlinePaint(0);
//     var83.setLabelPaint(var93);
//     org.jfree.chart.axis.DateTickMarkPosition var95 = var83.getTickMarkPosition();
//     var81.setTickMarkPosition(var95);
//     org.jfree.chart.util.RectangleInsets var97 = var81.getTickLabelInsets();
//     org.jfree.data.KeyedObject var98 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var97);
//     org.jfree.chart.block.LineBorder var99 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var4, var36, var97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "java.awt.Color[r=0,g=0,b=10]"+ "'", var6.equals("java.awt.Color[r=0,g=0,b=10]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var97);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.configure();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
//     double var5 = var3.calculateBottomOutset(4.0d);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, Double.NaN, Double.NaN);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var18 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var20 = var18.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var23 = new org.jfree.chart.entity.CategoryItemEntity(var8, "hi!", "", (org.jfree.data.category.CategoryDataset)var18, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var27 = var24.getLegendItem((-1), 100);
//     var24.setBaseShapesFilled(false);
//     java.awt.Paint var31 = var24.getSeriesOutlinePaint((-1));
//     java.awt.Paint var33 = var24.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var8, var33);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     org.jfree.chart.plot.Plot var37 = var36.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getInsets();
//     double var40 = var38.calculateBottomOutset(100.0d);
//     var34.setPadding(var38);
//     org.jfree.chart.util.RectangleAnchor var42 = var34.getShapeLocation();
//     var34.setLineVisible(false);
//     boolean var45 = var34.isLineVisible();
//     java.awt.geom.Rectangle2D var46 = var34.getBounds();
//     java.awt.geom.Rectangle2D var47 = var3.createOutsetRectangle(var46);
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D("");
//     var50.configure();
//     org.jfree.chart.util.RectangleInsets var52 = var50.getLabelInsets();
//     var48.setAxisOffset(var52);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var55 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var56 = var55.getEndType();
//     java.awt.Stroke var59 = var55.getItemStroke(0, 0);
//     var48.setRangeZeroBaselineStroke(var59);
//     org.jfree.chart.util.Layer var61 = null;
//     java.util.Collection var62 = var48.getDomainMarkers(var61);
//     org.jfree.chart.util.RectangleInsets var63 = var48.getInsets();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var65 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var66 = var65.getEndType();
//     java.awt.Stroke var69 = var65.getItemStroke(0, 0);
//     var48.setDomainZeroBaselineStroke(var69);
//     org.jfree.chart.util.RectangleEdge var71 = var48.getDomainAxisEdge();
//     double var72 = org.jfree.chart.util.RectangleEdge.coordinate(var47, var71);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var73 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var76 = var73.getLegendItem((-1), 100);
//     boolean var77 = var73.getBaseLinesVisible();
//     java.lang.Boolean var79 = var73.getSeriesLinesVisible(0);
//     java.awt.Shape var81 = null;
//     var73.setSeriesShape(100, var81);
//     org.jfree.chart.title.LegendTitle var83 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var73);
//     org.jfree.chart.util.RectangleAnchor var84 = var83.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var85 = org.jfree.chart.util.RectangleAnchor.coordinates(var47, var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.data.KeyToGroupMap var9 = new org.jfree.data.KeyToGroupMap();
    java.util.List var10 = var9.getGroups();
    org.jfree.data.statistics.BoxAndWhiskerItem var11 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)1.0d, (java.lang.Number)100.0f, (java.lang.Number)(short)1, (java.lang.Number)1.0f, (java.lang.Number)(byte)(-1), (java.lang.Number)(-1), (java.lang.Number)(byte)100, var10);
    java.lang.Comparable var12 = null;
    var0.setObject((java.lang.Object)var10, var12, (java.lang.Comparable)1);
    var0.removeObject((java.lang.Comparable)10, (java.lang.Comparable)(short)100);
    int var19 = var0.getColumnIndex((java.lang.Comparable)(byte)100);
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("");
    var21.configure();
    org.jfree.chart.axis.NumberTickUnit var23 = var21.getTickUnit();
    org.jfree.chart.text.TextLine var24 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("PlotOrientation.VERTICAL");
    var24.addFragment(var26);
    int var28 = var23.compareTo((java.lang.Object)var24);
    org.jfree.chart.text.TextFragment var29 = var24.getFirstTextFragment();
    boolean var30 = var0.equals((java.lang.Object)var29);
    java.util.List var31 = var0.getColumnKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLabelAngle();
    var0.setTickMarkInsideLength(10.0f);
    java.util.Date var4 = var0.getMaximumDate();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }
// 
// 
//     java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     var1.setDomainCrosshairValue(0.05d);
//     java.awt.Paint var4 = var1.getDomainCrosshairPaint();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     java.awt.Paint var7 = var6.getBaseSectionPaint();
//     boolean var8 = var6.isOutlineVisible();
//     java.awt.Color var12 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var13 = null;
//     float[] var14 = var12.getRGBColorComponents(var13);
//     var6.setSectionOutlinePaint((java.lang.Comparable)"", (java.awt.Paint)var12);
//     java.awt.Color var18 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var19 = null;
//     float[] var20 = var18.getRGBColorComponents(var19);
//     float[] var21 = var12.getRGBComponents(var19);
//     var1.setOutlinePaint((java.awt.Paint)var12);
//     int var23 = var12.getRed();
//     java.lang.String var24 = var12.toString();
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var12};
//     java.awt.Paint[] var26 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot(var27);
//     org.jfree.chart.plot.Plot var29 = var28.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var30 = var28.getInsets();
//     java.awt.Stroke var31 = var28.getLabelOutlineStroke();
//     java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var36 = var33.getLegendItem((-1), 100);
//     java.awt.Stroke var37 = var33.getBaseOutlineStroke();
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Shape[] var39 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var25, var26, var32, var38, var39);
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement();
//     var41.clear();
//     boolean var43 = var40.equals((java.lang.Object)var41);
//     java.awt.Shape var44 = var40.getNextShape();
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    boolean var4 = var3.getAntiAlias();
    java.awt.Stroke var5 = var3.getBorderStroke();
    org.jfree.chart.entity.EntityCollection var9 = null;
    org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo(var9);
    org.jfree.chart.plot.PlotRenderingInfo var11 = var10.getPlotInfo();
    java.lang.Object var12 = var10.clone();
    java.awt.image.BufferedImage var13 = var3.createBufferedImage(12, 15, 10, var10);
    org.jfree.chart.entity.EntityCollection var16 = null;
    org.jfree.chart.ChartRenderingInfo var17 = new org.jfree.chart.ChartRenderingInfo(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var18 = var3.createBufferedImage((-1), 10, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     double var1 = var0.getLabelLinkMargin();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
//     java.util.List var3 = var2.getGroups();
//     java.util.List var4 = var2.getGroups();
//     java.lang.Object var5 = var2.clone();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     int var7 = var2.getGroupIndex((java.lang.Comparable)var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var6.next();
//     boolean var9 = var0.equals((java.lang.Object)var6);
//     java.lang.Object var10 = var0.clone();
//     java.awt.Paint var11 = var0.getLabelLinkPaint();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var17 = var14.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
//     org.jfree.chart.plot.Plot var20 = var19.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var21 = null;
//     var19.axisChanged(var21);
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("hi!", var17, (org.jfree.chart.plot.Plot)var19, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var28 = var25.getLegendItem((-1), 100);
//     var25.setBaseShapesFilled(false);
//     java.awt.Paint var32 = var25.getSeriesOutlinePaint((-1));
//     boolean var33 = var24.equals((java.lang.Object)var25);
//     org.jfree.chart.title.TextTitle var34 = var24.getTitle();
//     org.jfree.chart.util.HorizontalAlignment var35 = var34.getTextAlignment();
//     java.awt.Graphics2D var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.rotateShape(var39, 50.5d, (-1.0f), (-1.0f));
//     java.lang.Object var44 = var34.draw(var36, var37, (java.lang.Object)var39);
//     org.jfree.chart.util.HorizontalAlignment var45 = var34.getTextAlignment();
//     boolean var46 = var0.equals((java.lang.Object)var45);
//     org.jfree.data.category.DefaultCategoryDataset var47 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var48 = var47.getColumnCount();
//     int var49 = var47.getRowCount();
//     org.jfree.data.KeyedObjects2D var50 = new org.jfree.data.KeyedObjects2D();
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month();
//     org.jfree.data.gantt.Task var53 = new org.jfree.data.gantt.Task("ThreadContext", (org.jfree.data.time.TimePeriod)var52);
//     var53.setDescription("poly");
//     org.jfree.data.time.Month var56 = new org.jfree.data.time.Month();
//     long var57 = var56.getSerialIndex();
//     java.util.Date var58 = var56.getEnd();
//     var53.setDuration((org.jfree.data.time.TimePeriod)var56);
//     org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var64 = var61.getLegendItem((-1), 100);
//     var61.setBaseShapesFilled(false);
//     java.awt.Paint var68 = var61.getSeriesOutlinePaint((-1));
//     java.awt.Paint var70 = var61.lookupSeriesOutlinePaint(0);
//     var60.setLabelPaint(var70);
//     double var72 = var60.getFixedAutoRange();
//     var60.setNegativeArrowVisible(true);
//     java.text.DateFormat var77 = null;
//     org.jfree.chart.axis.DateTickUnit var78 = new org.jfree.chart.axis.DateTickUnit(2, 1, var77);
//     var60.setTickUnit(var78, true, false);
//     org.jfree.data.time.Year var82 = new org.jfree.data.time.Year();
//     var50.setObject((java.lang.Object)var53, (java.lang.Comparable)true, (java.lang.Comparable)var82);
//     java.lang.String var84 = var82.toString();
//     int var85 = var47.getColumnIndex((java.lang.Comparable)var82);
//     org.jfree.data.time.Year var86 = new org.jfree.data.time.Year();
//     java.util.Date var87 = var86.getEnd();
//     long var88 = var86.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var89 = var86.next();
//     int var90 = var47.getRowIndex((java.lang.Comparable)var89);
//     boolean var91 = var45.equals((java.lang.Object)var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var84 + "' != '" + "2014"+ "'", var84.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == false);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getInteriorGap();
//     double var3 = var1.getShadowYOffset();
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
//     var6.configure();
//     org.jfree.chart.util.RectangleInsets var8 = var6.getLabelInsets();
//     var4.setAxisOffset(var8);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var12 = var11.getEndType();
//     java.awt.Stroke var15 = var11.getItemStroke(0, 0);
//     var4.setRangeZeroBaselineStroke(var15);
//     var1.setLabelOutlineStroke(var15);
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var1.setLegendLabelURLGenerator(var18);
//     org.jfree.chart.util.StrokeList var20 = new org.jfree.chart.util.StrokeList();
//     org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var25 = var22.getLegendItem((-1), 100);
//     var22.setBaseShapesFilled(false);
//     java.awt.Paint var29 = var22.getSeriesOutlinePaint((-1));
//     java.awt.Paint var31 = var22.lookupSeriesOutlinePaint(0);
//     var21.setLabelPaint(var31);
//     boolean var33 = var21.isNegativeArrowVisible();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var35 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var36 = var35.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var37 = var35.getBaseNegativeItemLabelPosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var38 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var40 = var38.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var43 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var46 = var43.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     org.jfree.chart.plot.Plot var49 = var48.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var50 = null;
//     var48.axisChanged(var50);
//     org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("hi!", var46, (org.jfree.chart.plot.Plot)var48, true);
//     boolean var54 = var38.equals((java.lang.Object)var46);
//     var38.validateObject();
//     org.jfree.data.Range var56 = var35.findRangeBounds((org.jfree.data.category.CategoryDataset)var38);
//     org.jfree.data.general.DatasetChangeEvent var57 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var33, (org.jfree.data.general.Dataset)var38);
//     boolean var58 = var20.equals((java.lang.Object)var57);
//     org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var61 = var60.getTickLabelPaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var62 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var65 = var62.getLegendItem(2, 0);
//     double var66 = var62.getBase();
//     java.awt.Color var69 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var70 = null;
//     float[] var71 = var69.getRGBColorComponents(var70);
//     java.awt.Color var74 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var75 = null;
//     float[] var76 = var74.getRGBColorComponents(var75);
//     float[] var77 = var69.getColorComponents(var75);
//     var62.setErrorIndicatorPaint((java.awt.Paint)var69);
//     org.jfree.chart.plot.XYPlot var79 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var81 = new org.jfree.chart.axis.NumberAxis3D("");
//     var81.configure();
//     org.jfree.chart.util.RectangleInsets var83 = var81.getLabelInsets();
//     var79.setAxisOffset(var83);
//     org.jfree.chart.plot.CategoryMarker var86 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Stroke var87 = var86.getOutlineStroke();
//     var79.addDomainMarker((org.jfree.chart.plot.Marker)var86);
//     java.awt.geom.Point2D var89 = var79.getQuadrantOrigin();
//     java.awt.Paint var90 = var79.getDomainCrosshairPaint();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var92 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var93 = var92.getEndType();
//     java.awt.Paint var94 = var92.getBaseFillPaint();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var95 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var61, (java.awt.Paint)var69, var90, var94);
//     boolean var96 = var20.equals((java.lang.Object)var94);
//     var1.setBaseSectionPaint(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.25d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == false);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.configure();
    org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
    var1.setLabelToolTip("org.jfree.data.UnknownKeyException: ");
    var1.setAutoRangeMinimumSize(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.util.PaintList var1 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var3 = var1.getPaint(2);
    org.jfree.data.KeyToGroupMap var4 = new org.jfree.data.KeyToGroupMap();
    java.util.List var5 = var4.getGroups();
    java.util.List var6 = var4.getGroups();
    java.lang.Object var7 = var4.clone();
    boolean var8 = var1.equals((java.lang.Object)var4);
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    var11.configure();
    java.lang.Object var13 = var11.clone();
    java.lang.Number var16 = null;
    java.util.List var22 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var23 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)0L, var16, (java.lang.Number)100.0f, (java.lang.Number)0L, (java.lang.Number)0, (java.lang.Number)(short)(-1), (java.lang.Number)1.0d, var22);
    boolean var24 = var11.equals((java.lang.Object)0);
    boolean var25 = var11.isAutoRange();
    java.awt.Font var26 = var11.getLabelFont();
    org.jfree.chart.plot.CategoryMarker var28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)1L);
    java.lang.Object var29 = var28.clone();
    java.awt.Paint var30 = var28.getOutlinePaint();
    org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("Size2D[width=50.5, height=10.0]", var26, var30);
    var31.setURLText("");
    boolean var34 = var4.equals((java.lang.Object)"");
    int var35 = var4.getGroupCount();
    org.jfree.data.Range var36 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    var2.setRenderer(var3);
    org.jfree.data.general.WaferMapDataset var5 = var2.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }
// 
// 
//     org.jfree.data.KeyToGroupMap var0 = new org.jfree.data.KeyToGroupMap();
//     java.util.List var1 = var0.getGroups();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
//     var4.configure();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getLabelInsets();
//     var2.setAxisOffset(var6);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var10 = var9.getEndType();
//     java.awt.Stroke var13 = var9.getItemStroke(0, 0);
//     var2.setRangeZeroBaselineStroke(var13);
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var2.getDomainMarkers(var15);
//     var2.setForegroundAlpha(100.0f);
//     var2.setRangeCrosshairVisible(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var22 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var21};
//     var2.setRenderers(var22);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
//     var26.configure();
//     org.jfree.chart.util.RectangleInsets var28 = var26.getLabelInsets();
//     var24.setAxisOffset(var28);
//     org.jfree.chart.plot.CategoryMarker var31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Stroke var32 = var31.getOutlineStroke();
//     var24.addDomainMarker((org.jfree.chart.plot.Marker)var31);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = var24.getRenderer();
//     org.jfree.chart.axis.ValueAxis var36 = var24.getDomainAxis(1);
//     java.awt.Stroke var37 = var24.getDomainCrosshairStroke();
//     var2.setRangeGridlineStroke(var37);
//     boolean var39 = var0.equals((java.lang.Object)var37);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var43, Double.NaN, Double.NaN);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.rotateShape(var43, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var53 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var55 = var53.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var58 = new org.jfree.chart.entity.CategoryItemEntity(var43, "hi!", "", (org.jfree.data.category.CategoryDataset)var53, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     java.lang.Comparable var59 = var58.getRowKey();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var60 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var61 = var60.getColumnCount();
//     org.jfree.chart.axis.NumberAxis3D var63 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.NumberAxis3D var65 = new org.jfree.chart.axis.NumberAxis3D("");
//     boolean var66 = var65.isTickMarksVisible();
//     org.jfree.data.Range var69 = new org.jfree.data.Range(1.0d, 100.0d);
//     var65.setRangeWithMargins(var69, false, false);
//     var63.setRangeWithMargins(var69);
//     var63.configure();
//     org.jfree.chart.axis.NumberTickUnit var75 = var63.getTickUnit();
//     org.jfree.data.time.Year var76 = new org.jfree.data.time.Year();
//     java.util.Date var77 = var76.getEnd();
//     java.util.Date var78 = var76.getEnd();
//     java.lang.Number var79 = var60.getMeanValue((java.lang.Comparable)var75, (java.lang.Comparable)var76);
//     var58.setRowKey((java.lang.Comparable)var75);
//     var0.mapKeyToGroup((java.lang.Comparable)7, (java.lang.Comparable)var75);
//     java.lang.Object var82 = var0.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + 100.0f+ "'", var59.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)"");
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var5);
    java.lang.Number var9 = var0.getMaxRegularValue((java.lang.Comparable)100.0f, (java.lang.Comparable)10);
    org.jfree.data.general.DatasetGroup var10 = var0.getGroup();
    java.lang.Object var11 = var10.clone();
    java.lang.String var12 = var10.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "NOID"+ "'", var12.equals("NOID"));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var2 = var1.getColumnCount();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var7 = var6.isTickMarksVisible();
    org.jfree.data.Range var10 = new org.jfree.data.Range(1.0d, 100.0d);
    var6.setRangeWithMargins(var10, false, false);
    var4.setRangeWithMargins(var10);
    var4.configure();
    org.jfree.chart.axis.NumberTickUnit var16 = var4.getTickUnit();
    org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
    java.util.Date var18 = var17.getEnd();
    java.util.Date var19 = var17.getEnd();
    java.lang.Number var20 = var1.getMeanValue((java.lang.Comparable)var16, (java.lang.Comparable)var17);
    org.jfree.data.time.RegularTimePeriod var21 = var17.next();
    int var22 = var0.indexOf((java.lang.Comparable)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(255);
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(255);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var4, (java.lang.Comparable)"");
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
//     var4.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var9);
//     java.lang.Comparable var11 = null;
//     java.lang.Number var13 = var4.getMeanValue(var11, (java.lang.Comparable)100.0f);
//     org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
//     java.lang.Comparable var15 = null;
//     org.jfree.data.DefaultKeyedValues var16 = new org.jfree.data.DefaultKeyedValues();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var19.setUpperMargin(0.0d);
//     int var22 = var19.getMaximumCategoryLabelLines();
//     java.lang.Object var23 = var19.clone();
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var28 = var25.getLegendItem((-1), 100);
//     var25.setBaseShapesFilled(false);
//     java.awt.Paint var32 = var25.getSeriesOutlinePaint((-1));
//     java.awt.Paint var34 = var25.lookupSeriesOutlinePaint(0);
//     var24.setLabelPaint(var34);
//     double var36 = var24.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var40 = var37.getLegendItem(2, 0);
//     double var41 = var37.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var44 = var37.getPositiveItemLabelPosition(2, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var48 = var45.getLegendItem((-1), 100);
//     var45.setBaseShapesFilled(false);
//     java.awt.Paint var53 = var45.getItemOutlinePaint(10, 1);
//     var37.setErrorIndicatorPaint(var53);
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var17, var19, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     var55.setRangeCrosshairValue(50.5d);
//     org.jfree.chart.axis.CategoryAxis var59 = var55.getDomainAxis(0);
//     var55.setDrawSharedDomainAxis(true);
//     org.jfree.chart.util.SortOrder var62 = var55.getColumnRenderingOrder();
//     var16.sortByValues(var62);
//     org.jfree.data.time.Month var64 = new org.jfree.data.time.Month();
//     long var65 = var64.getSerialIndex();
//     java.util.Date var66 = var64.getEnd();
//     var16.setValue((java.lang.Comparable)var66, (java.lang.Number)1.0E-5d);
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.createInstance(var66);
//     java.lang.Number var70 = var4.getValue(var15, (java.lang.Comparable)var69);
//     org.jfree.data.time.SerialDate var72 = var69.getFollowingDayOfWeek(2);
//     boolean var73 = var1.isInRange((org.jfree.data.time.SerialDate)var3, var72);
//     int var74 = var1.getDayOfWeek();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 3);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    double var1 = var0.getYOffset();
    java.awt.Paint var2 = var0.getWallPaint();
    java.awt.Paint var5 = var0.getItemLabelPaint(0, 2);
    double var6 = var0.getXOffset();
    var0.setXOffset((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    var11.configure();
    java.lang.Object var13 = var11.clone();
    java.lang.Number var16 = null;
    java.util.List var22 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var23 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)0L, var16, (java.lang.Number)100.0f, (java.lang.Number)0L, (java.lang.Number)0, (java.lang.Number)(short)(-1), (java.lang.Number)1.0d, var22);
    boolean var24 = var11.equals((java.lang.Object)0);
    boolean var25 = var11.isAutoRange();
    java.awt.Font var26 = var11.getLabelFont();
    org.jfree.chart.text.TextLine var27 = new org.jfree.chart.text.TextLine("Size2D[width=50.5, height=10.0]", var26);
    org.jfree.data.DefaultKeyedValues2D var29 = new org.jfree.data.DefaultKeyedValues2D(false);
    var29.clear();
    java.util.List var31 = var29.getColumnKeys();
    boolean var32 = var27.equals((java.lang.Object)var29);
    org.jfree.chart.renderer.category.StackedAreaRenderer var35 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var38 = var35.getItemLabelFont((-1), 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var39.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var43 = var39.getBaseLinesVisible();
    java.lang.Boolean var45 = var39.getSeriesVisibleInLegend(10);
    java.awt.Paint var46 = var39.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var47 = new org.jfree.chart.text.TextFragment("", var38, var46);
    var27.removeFragment(var47);
    java.lang.String var49 = var47.getText();
    org.jfree.chart.renderer.category.StackedAreaRenderer var52 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var55 = var52.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var56 = null;
    org.jfree.chart.plot.RingPlot var57 = new org.jfree.chart.plot.RingPlot(var56);
    org.jfree.chart.plot.Plot var58 = var57.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var59 = null;
    var57.axisChanged(var59);
    org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("hi!", var55, (org.jfree.chart.plot.Plot)var57, true);
    java.lang.Object var63 = var57.clone();
    org.jfree.chart.util.HorizontalAlignment var64 = null;
    org.jfree.chart.util.VerticalAlignment var65 = null;
    org.jfree.chart.block.FlowArrangement var68 = new org.jfree.chart.block.FlowArrangement(var64, var65, 100.0d, 10.0d);
    var68.clear();
    org.jfree.chart.block.Arrangement var70 = null;
    org.jfree.chart.title.LegendTitle var71 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57, (org.jfree.chart.block.Arrangement)var68, var70);
    org.jfree.data.UnknownKeyException var73 = new org.jfree.data.UnknownKeyException("");
    java.lang.Throwable[] var74 = var73.getSuppressed();
    java.lang.Throwable[] var75 = var73.getSuppressed();
    boolean var76 = var71.equals((java.lang.Object)var75);
    boolean var77 = var47.equals((java.lang.Object)var75);
    boolean var78 = var0.equals((java.lang.Object)var75);
    java.awt.Paint var79 = var0.getWallPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + ""+ "'", var49.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var1 = var0.getPlotType();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberTickUnit var4 = var3.getTickUnit();
//     java.awt.Paint var5 = var0.getSectionPaint((java.lang.Comparable)var4);
//     org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var6.setNotify(true);
//     org.jfree.chart.entity.EntityCollection var13 = null;
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo(var13);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = var14.getPlotInfo();
//     org.jfree.chart.entity.EntityCollection var16 = var14.getEntityCollection();
//     var14.clear();
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, Double.NaN, Double.NaN);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var32 = var30.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var35 = new org.jfree.chart.entity.CategoryItemEntity(var20, "hi!", "", (org.jfree.data.category.CategoryDataset)var30, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var39 = var36.getLegendItem((-1), 100);
//     var36.setBaseShapesFilled(false);
//     java.awt.Paint var43 = var36.getSeriesOutlinePaint((-1));
//     java.awt.Paint var45 = var36.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var46 = new org.jfree.chart.title.LegendGraphic(var20, var45);
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     org.jfree.chart.plot.Plot var49 = var48.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var50 = var48.getInsets();
//     double var52 = var50.calculateBottomOutset(100.0d);
//     var46.setPadding(var50);
//     org.jfree.chart.util.RectangleAnchor var54 = var46.getShapeLocation();
//     var46.setLineVisible(false);
//     boolean var57 = var46.isLineVisible();
//     java.awt.geom.Rectangle2D var58 = var46.getBounds();
//     var14.setChartArea(var58);
//     org.jfree.chart.entity.EntityCollection var60 = var14.getEntityCollection();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.awt.image.BufferedImage var61 = var6.createBufferedImage((-241), 156, 0.0d, 1.05d, var14);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var60);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var6 = var3.getLegendItem(2, 0);
    double var7 = var3.getBase();
    java.awt.Color var10 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var11 = null;
    float[] var12 = var10.getRGBColorComponents(var11);
    java.awt.Color var15 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var16 = null;
    float[] var17 = var15.getRGBColorComponents(var16);
    float[] var18 = var10.getColorComponents(var16);
    var3.setErrorIndicatorPaint((java.awt.Paint)var10);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
    var22.configure();
    org.jfree.chart.util.RectangleInsets var24 = var22.getLabelInsets();
    var20.setAxisOffset(var24);
    org.jfree.chart.plot.CategoryMarker var27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var28 = var27.getOutlineStroke();
    var20.addDomainMarker((org.jfree.chart.plot.Marker)var27);
    java.awt.geom.Point2D var30 = var20.getQuadrantOrigin();
    java.awt.Paint var31 = var20.getDomainCrosshairPaint();
    org.jfree.chart.renderer.category.StackedAreaRenderer var33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var34 = var33.getEndType();
    java.awt.Paint var35 = var33.getBaseFillPaint();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var36 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var2, (java.awt.Paint)var10, var31, var35);
    java.awt.Paint var37 = var36.getLastBarPaint();
    org.jfree.chart.event.RendererChangeEvent var38 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var36);
    boolean var39 = var36.getAutoPopulateSeriesOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     var2.configure();
//     org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
//     var0.setAxisOffset(var4);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
//     java.awt.Stroke var11 = var7.getItemStroke(0, 0);
//     var0.setRangeZeroBaselineStroke(var11);
//     org.jfree.chart.util.Layer var13 = null;
//     java.util.Collection var14 = var0.getDomainMarkers(var13);
//     org.jfree.chart.util.RectangleInsets var15 = var0.getInsets();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
//     java.awt.Stroke var21 = var17.getItemStroke(0, 0);
//     var0.setDomainZeroBaselineStroke(var21);
//     org.jfree.chart.util.RectangleEdge var24 = var0.getDomainAxisEdge(1);
//     java.awt.Paint var26 = var0.getQuadrantPaint(0);
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement();
//     var27.clear();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var30 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var31 = var30.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var32 = var30.getBaseNegativeItemLabelPosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var33 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var35 = var33.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var38 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var41 = var38.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot(var42);
//     org.jfree.chart.plot.Plot var44 = var43.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var45 = null;
//     var43.axisChanged(var45);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("hi!", var41, (org.jfree.chart.plot.Plot)var43, true);
//     boolean var49 = var33.equals((java.lang.Object)var41);
//     var33.validateObject();
//     org.jfree.data.Range var51 = var30.findRangeBounds((org.jfree.data.category.CategoryDataset)var33);
//     java.awt.Stroke var53 = var30.lookupSeriesStroke(10);
//     boolean var54 = var27.equals((java.lang.Object)var53);
//     var0.setDomainGridlineStroke(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.renderer.category.GanttRenderer var1 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 100);
    var2.setBaseShapesFilled(false);
    java.awt.Paint var9 = var2.getSeriesOutlinePaint((-1));
    org.jfree.chart.renderer.category.StackedAreaRenderer var11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var12 = var11.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var13 = var11.getBaseNegativeItemLabelPosition();
    var2.setBaseNegativeItemLabelPosition(var13);
    var1.setPositiveItemLabelPositionFallback(var13);
    var0.setPositiveItemLabelPositionFallback(var13);
    var0.setBase(3.0d);
    var0.setDrawBarOutline(true);
    var0.setItemMargin((-5.949999999999999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var7 = var6.isTickMarksVisible();
    org.jfree.data.Range var10 = new org.jfree.data.Range(1.0d, 100.0d);
    var6.setRangeWithMargins(var10, false, false);
    var4.setRangeWithMargins(var10);
    var1.setDefaultAutoRange(var10);
    float var16 = var1.getTickMarkOutsideLength();
    var1.setLabelToolTip("({0}, {1}) = {3} - {4}");
    var1.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var16 = var13.getLegendItem((-1), 100);
    var13.setBaseShapesFilled(false);
    java.awt.Paint var20 = var13.getSeriesOutlinePaint((-1));
    boolean var21 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var13.setBaseToolTipGenerator(var22, false);
    java.awt.Paint var27 = var13.getItemFillPaint(0, 10);
    boolean var28 = var13.getUseOutlinePaint();
    java.awt.Paint var31 = var13.getItemOutlinePaint((-1), 255);
    var13.setBaseItemLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    var0.setSeriesToGroupMap(var1);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }
// 
// 
//     org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("");
//     java.lang.Comparable var2 = var1.getKey();
//     java.util.List var3 = var1.getTasks();
//     org.jfree.data.gantt.Task var5 = var1.get("DateTickUnit[DAY, 1]");
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.util.Date var7 = var6.getEnd();
//     long var8 = var6.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var9 = var6.next();
//     var1.setKey((java.lang.Comparable)var6);
//     java.lang.Object var11 = var1.clone();
//     boolean var12 = var1.getNotify();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.plot.CategoryMarker var3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Paint var4 = var3.getLabelPaint();
    java.lang.Comparable var5 = var3.getKey();
    java.lang.String var6 = var3.getLabel();
    org.jfree.chart.renderer.category.StackedAreaRenderer var9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var12 = var9.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var16 = null;
    var14.axisChanged(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var12, (org.jfree.chart.plot.Plot)var14, true);
    var3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var14);
    java.lang.Comparable var21 = var3.getKey();
    org.jfree.chart.text.TextAnchor var22 = var3.getLabelTextAnchor();
    var1.setLabelTextAnchor(var22);
    java.awt.Stroke var24 = var1.getOutlineStroke();
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    var26.configure();
    java.lang.Object var28 = var26.clone();
    var26.resizeRange((-8.0d), (-8.0d));
    boolean var32 = var1.equals((java.lang.Object)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + true+ "'", var5.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + true+ "'", var21.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.configure();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
//     double var5 = var3.calculateBottomOutset(4.0d);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, Double.NaN, Double.NaN);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var18 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var20 = var18.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var23 = new org.jfree.chart.entity.CategoryItemEntity(var8, "hi!", "", (org.jfree.data.category.CategoryDataset)var18, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var27 = var24.getLegendItem((-1), 100);
//     var24.setBaseShapesFilled(false);
//     java.awt.Paint var31 = var24.getSeriesOutlinePaint((-1));
//     java.awt.Paint var33 = var24.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var8, var33);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     org.jfree.chart.plot.Plot var37 = var36.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getInsets();
//     double var40 = var38.calculateBottomOutset(100.0d);
//     var34.setPadding(var38);
//     org.jfree.chart.util.RectangleAnchor var42 = var34.getShapeLocation();
//     var34.setLineVisible(false);
//     boolean var45 = var34.isLineVisible();
//     java.awt.geom.Rectangle2D var46 = var34.getBounds();
//     java.awt.geom.Rectangle2D var47 = var3.createOutsetRectangle(var46);
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D("");
//     var50.configure();
//     org.jfree.chart.util.RectangleInsets var52 = var50.getLabelInsets();
//     var48.setAxisOffset(var52);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var55 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var56 = var55.getEndType();
//     java.awt.Stroke var59 = var55.getItemStroke(0, 0);
//     var48.setRangeZeroBaselineStroke(var59);
//     org.jfree.chart.util.Layer var61 = null;
//     java.util.Collection var62 = var48.getDomainMarkers(var61);
//     org.jfree.chart.util.RectangleInsets var63 = var48.getInsets();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var65 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var66 = var65.getEndType();
//     java.awt.Stroke var69 = var65.getItemStroke(0, 0);
//     var48.setDomainZeroBaselineStroke(var69);
//     org.jfree.chart.util.RectangleEdge var71 = var48.getDomainAxisEdge();
//     double var72 = org.jfree.chart.util.RectangleEdge.coordinate(var47, var71);
//     boolean var73 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == true);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.configure();
    var1.setAutoTickUnitSelection(false);
    org.jfree.data.Range var7 = new org.jfree.data.Range(1.0d, 100.0d);
    java.lang.String var8 = var7.toString();
    org.jfree.data.Range var10 = org.jfree.data.Range.shift(var7, 0.0d);
    org.jfree.data.Range var13 = org.jfree.data.Range.expand(var10, 0.0d, 0.2d);
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange(var10);
    var1.setRangeWithMargins(var10, true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Range[1.0,100.0]"+ "'", var8.equals("Range[1.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem((-1), 100);
    boolean var4 = var0.getBaseCreateEntities();
    org.jfree.chart.renderer.category.GanttRenderer var6 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var10 = var7.getLegendItem((-1), 100);
    var7.setBaseShapesFilled(false);
    java.awt.Paint var14 = var7.getSeriesOutlinePaint((-1));
    org.jfree.chart.renderer.category.StackedAreaRenderer var16 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var17 = var16.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getBaseNegativeItemLabelPosition();
    var7.setBaseNegativeItemLabelPosition(var18);
    var6.setPositiveItemLabelPositionFallback(var18);
    org.jfree.chart.text.TextAnchor var21 = var18.getTextAnchor();
    var0.setSeriesPositiveItemLabelPosition(7, var18, true);
    double var24 = var18.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    boolean var4 = var3.getAntiAlias();
    var3.setAntiAlias(true);
    java.lang.Object var7 = null;
    boolean var8 = var3.equals(var7);
    var3.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.axis.CategoryAnchor var39 = var38.getDomainGridlinePosition();
    var38.setAnchorValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(12, 12, 5);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var16 = var13.getLegendItem((-1), 100);
    var13.setBaseShapesFilled(false);
    java.awt.Paint var20 = var13.getSeriesOutlinePaint((-1));
    boolean var21 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.title.TextTitle var22 = var12.getTitle();
    org.jfree.chart.util.HorizontalAlignment var23 = var22.getTextAlignment();
    var22.setText("hi!");
    java.lang.String var26 = var22.getText();
    java.lang.Object var27 = var22.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "hi!"+ "'", var26.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    java.lang.Object var13 = var7.clone();
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var14, var15, 100.0d, 10.0d);
    var18.clear();
    org.jfree.chart.block.Arrangement var20 = null;
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var18, var20);
    org.jfree.chart.util.RectangleInsets var22 = var21.getLegendItemGraphicPadding();
    java.lang.Object var23 = var21.clone();
    boolean var24 = var21.getNotify();
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
    var27.configure();
    org.jfree.chart.util.RectangleInsets var29 = var27.getLabelInsets();
    var25.setAxisOffset(var29);
    org.jfree.chart.util.RectangleInsets var31 = var25.getAxisOffset();
    var21.setPadding(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("org.jfree.data.UnknownKeyException: ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    java.awt.Paint var5 = null;
    var4.setRadiusGridlinePaint(var5);
    org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("Pie Plot");
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    double var12 = var11.getInteriorGap();
    org.jfree.chart.renderer.category.StackedAreaRenderer var15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var18 = var15.getItemLabelFont((-1), 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var19.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var23 = var19.getBaseLinesVisible();
    java.lang.Boolean var25 = var19.getSeriesVisibleInLegend(10);
    java.awt.Paint var26 = var19.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("", var18, var26);
    var11.setLabelFont(var18);
    var8.setTickLabelFont((java.lang.Comparable)1L, var18);
    var4.setAngleLabelFont(var18);
    java.awt.Paint var31 = null;
    var4.setAngleGridlinePaint(var31);
    org.jfree.chart.LegendItemCollection var33 = var4.getLegendItems();
    var4.setRadiusGridlinesVisible(false);
    java.awt.Font var36 = var4.getAngleLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.setDomainCrosshairValue(0.05d);
    org.jfree.data.xy.XYDataset var3 = null;
    var0.setDataset(var3);
    var0.setDomainZeroBaselineVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var14.setUpperMargin(0.0d);
    int var17 = var14.getMaximumCategoryLabelLines();
    java.lang.Object var18 = var14.clone();
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem((-1), 100);
    var20.setBaseShapesFilled(false);
    java.awt.Paint var27 = var20.getSeriesOutlinePaint((-1));
    java.awt.Paint var29 = var20.lookupSeriesOutlinePaint(0);
    var19.setLabelPaint(var29);
    double var31 = var19.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var35 = var32.getLegendItem(2, 0);
    double var36 = var32.getBase();
    org.jfree.chart.labels.ItemLabelPosition var39 = var32.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var43 = var40.getLegendItem((-1), 100);
    var40.setBaseShapesFilled(false);
    java.awt.Paint var48 = var40.getItemOutlinePaint(10, 1);
    var32.setErrorIndicatorPaint(var48);
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var12, var14, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
    var50.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.CategoryAxis var54 = var50.getDomainAxis(0);
    var50.setDrawSharedDomainAxis(true);
    org.jfree.chart.util.SortOrder var57 = var50.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotOrientation var58 = var50.getOrientation();
    org.jfree.chart.LegendItemCollection var59 = var50.getLegendItems();
    org.jfree.chart.axis.AxisLocation var60 = var50.getRangeAxisLocation();
    org.jfree.chart.entity.EntityCollection var62 = null;
    org.jfree.chart.ChartRenderingInfo var63 = new org.jfree.chart.ChartRenderingInfo(var62);
    org.jfree.chart.plot.PlotRenderingInfo var64 = var63.getPlotInfo();
    org.jfree.chart.plot.PlotRenderingInfo var65 = var63.getPlotInfo();
    org.jfree.chart.renderer.category.CategoryItemRendererState var66 = var9.initialise(var10, var11, var50, (-457), var65);
    var0.handleClick(15, (-1), var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var69 = var65.getSubplotInfo((-41749));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, Double.NaN, Double.NaN);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, Double.NaN, Double.NaN);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 10.0d, 0.0f, 0.0f);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var9, var19);
    org.jfree.chart.renderer.category.StackedAreaRenderer var23 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var26 = var23.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot(var27);
    org.jfree.chart.plot.Plot var29 = var28.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var30 = null;
    var28.axisChanged(var30);
    org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("hi!", var26, (org.jfree.chart.plot.Plot)var28, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var37 = var34.getLegendItem((-1), 100);
    var34.setBaseShapesFilled(false);
    java.awt.Paint var41 = var34.getSeriesOutlinePaint((-1));
    boolean var42 = var33.equals((java.lang.Object)var34);
    org.jfree.chart.title.TextTitle var43 = var33.getTitle();
    org.jfree.chart.renderer.category.StackedAreaRenderer var45 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var46 = var45.getEndType();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var50 = var47.getLegendItem((-1), 100);
    var47.setBaseShapesFilled(false);
    java.awt.Paint var55 = var47.getItemOutlinePaint(10, 1);
    java.awt.Paint var57 = var47.getSeriesOutlinePaint(10);
    var47.setAutoPopulateSeriesShape(false);
    boolean var60 = var45.equals((java.lang.Object)var47);
    java.awt.Paint var63 = var45.getItemPaint(1, 0);
    var43.setPaint(var63);
    org.jfree.chart.title.LegendGraphic var65 = new org.jfree.chart.title.LegendGraphic(var19, var63);
    java.awt.Paint var66 = var65.getOutlinePaint();
    org.jfree.chart.util.GradientPaintTransformer var67 = var65.getFillPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var4 = var1.getLegendItem((-1), 100);
//     boolean var5 = var1.getBaseLinesVisible();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
//     java.awt.Paint var9 = var8.getErrorIndicatorPaint();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     var8.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var10);
//     var1.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var10);
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     var13.clear();
//     boolean var15 = var10.equals((java.lang.Object)var13);
//     org.jfree.chart.block.CenterArrangement var16 = new org.jfree.chart.block.CenterArrangement();
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, Double.NaN, Double.NaN);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var29 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var31 = var29.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var34 = new org.jfree.chart.entity.CategoryItemEntity(var19, "hi!", "", (org.jfree.data.category.CategoryDataset)var29, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var38 = var35.getLegendItem((-1), 100);
//     var35.setBaseShapesFilled(false);
//     java.awt.Paint var42 = var35.getSeriesOutlinePaint((-1));
//     java.awt.Paint var44 = var35.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var45 = new org.jfree.chart.title.LegendGraphic(var19, var44);
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.RingPlot var47 = new org.jfree.chart.plot.RingPlot(var46);
//     org.jfree.chart.plot.Plot var48 = var47.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var49 = var47.getInsets();
//     double var51 = var49.calculateBottomOutset(100.0d);
//     var45.setPadding(var49);
//     org.jfree.chart.util.RectangleInsets var53 = var45.getMargin();
//     var45.setShapeFilled(false);
//     org.jfree.data.resources.DataPackageResources var56 = new org.jfree.data.resources.DataPackageResources();
//     var16.add((org.jfree.chart.block.Block)var45, (java.lang.Object)var56);
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var13, (org.jfree.chart.block.Arrangement)var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    double var1 = var0.getYOffset();
    var0.setDrawOutlines(true);
    java.awt.Paint var4 = var0.getWallPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)"");
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var5);
    java.lang.Number var9 = var0.getMaxRegularValue((java.lang.Comparable)100.0f, (java.lang.Comparable)10);
    java.util.List var10 = var0.getRowKeys();
    java.util.List var11 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var12 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var11);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var16 = var13.getLegendItem((-1), 100);
    var13.setBaseShapesFilled(false);
    java.awt.Paint var20 = var13.getSeriesOutlinePaint((-1));
    boolean var21 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.title.TextTitle var22 = var12.getTitle();
    var22.setText("LengthConstraintType.FIXED");
    org.jfree.chart.util.HorizontalAlignment var25 = var22.getTextAlignment();
    var22.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    var0.setItemMargin(90.0d);
    java.lang.Object var3 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    org.jfree.chart.plot.PlotRenderingInfo var2 = var1.getPlotInfo();
    org.jfree.chart.renderer.category.CategoryItemRendererState var3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var2);
    double var4 = var3.getBarWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }


    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(10, var2);
    org.jfree.data.gantt.Task var4 = new org.jfree.data.gantt.Task("PlotOrientation.VERTICAL", (org.jfree.data.time.TimePeriod)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var6 = var4.getSubtask((-41749));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLabelAngle();
    var0.setTickLabelsVisible(false);
    var0.configure();
    java.util.TimeZone var5 = var0.getTimeZone();
    org.jfree.chart.axis.DateTickUnit var6 = var0.getTickUnit();
    org.jfree.data.Range var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("org.jfree.data.UnknownKeyException: ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    java.awt.Paint var5 = null;
    var4.setRadiusGridlinePaint(var5);
    org.jfree.chart.plot.PlotOrientation var7 = var4.getOrientation();
    boolean var8 = var4.isRadiusGridlinesVisible();
    var4.setRadiusGridlinesVisible(false);
    org.jfree.chart.renderer.PolarItemRenderer var11 = null;
    var4.setRenderer(var11);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var13.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var17 = var13.getBaseLinesVisible();
    boolean var19 = var13.equals((java.lang.Object)100.0f);
    org.jfree.chart.event.RendererChangeEvent var20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var19);
    java.lang.String var21 = var20.toString();
    org.jfree.chart.event.ChartChangeEventType var22 = null;
    var20.setType(var22);
    var4.rendererChanged(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=false]"+ "'", var21.equals("org.jfree.chart.event.RendererChangeEvent[source=false]"));

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
    java.awt.Stroke var11 = var7.getItemStroke(0, 0);
    var0.setRangeZeroBaselineStroke(var11);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var0.getDomainMarkers(var13);
    org.jfree.chart.util.RectangleInsets var15 = var0.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
    java.awt.Stroke var21 = var17.getItemStroke(0, 0);
    var0.setDomainZeroBaselineStroke(var21);
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var28 = var27.isTickMarksVisible();
    org.jfree.data.Range var31 = new org.jfree.data.Range(1.0d, 100.0d);
    var27.setRangeWithMargins(var31, false, false);
    var25.setRangeWithMargins(var31);
    var25.configure();
    org.jfree.chart.axis.NumberTickUnit var37 = var25.getTickUnit();
    var0.setDomainAxis(5, (org.jfree.chart.axis.ValueAxis)var25);
    org.jfree.chart.axis.NumberTickUnit var39 = var25.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    var1.setMaximumBarWidth(4.0d);
    boolean var4 = var1.getRenderAsPercentages();
    java.awt.Stroke var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseStroke(var5, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Paint var4 = var3.getBaseSectionPaint();
    boolean var5 = var3.isOutlineVisible();
    java.awt.Color var9 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var10 = null;
    float[] var11 = var9.getRGBColorComponents(var10);
    var3.setSectionOutlinePaint((java.lang.Comparable)"", (java.awt.Paint)var9);
    int var13 = var9.getRed();
    boolean var14 = var1.equals((java.lang.Object)var9);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.Range var18 = var17.getDefaultAutoRange();
    org.jfree.data.Range var21 = new org.jfree.data.Range(1.0d, 100.0d);
    var17.setRangeWithMargins(var21);
    org.jfree.chart.renderer.PolarItemRenderer var23 = null;
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot(var16, (org.jfree.chart.axis.ValueAxis)var17, var23);
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    var26.configure();
    org.jfree.chart.axis.NumberTickUnit var28 = var26.getTickUnit();
    org.jfree.data.Range var29 = var26.getRange();
    var26.setLowerMargin(100.0d);
    double var32 = var26.getFixedAutoRange();
    org.jfree.chart.axis.MarkerAxisBand var33 = null;
    var26.setMarkerBand(var33);
    org.jfree.data.Range var35 = var24.getDataRange((org.jfree.chart.axis.ValueAxis)var26);
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
    double var37 = var36.getLabelAngle();
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var42 = var39.getLegendItem((-1), 100);
    var39.setBaseShapesFilled(false);
    java.awt.Paint var46 = var39.getSeriesOutlinePaint((-1));
    java.awt.Paint var48 = var39.lookupSeriesOutlinePaint(0);
    var38.setLabelPaint(var48);
    org.jfree.chart.axis.DateTickMarkPosition var50 = var38.getTickMarkPosition();
    var36.setTickMarkPosition(var50);
    org.jfree.chart.renderer.category.StackedAreaRenderer var53 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var54 = var53.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var55 = var53.getBaseNegativeItemLabelPosition();
    boolean var56 = var36.equals((java.lang.Object)var55);
    var24.setAxis((org.jfree.chart.axis.ValueAxis)var36);
    var1.set(0, (java.lang.Object)var24);
    java.awt.Paint var59 = var24.getBackgroundPaint();
    java.lang.String var60 = var24.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + "Polar Plot"+ "'", var60.equals("Polar Plot"));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
    double var42 = var41.getLeft();
    var38.setFixedRangeAxisSpace(var41);
    org.jfree.chart.axis.AxisSpace var44 = new org.jfree.chart.axis.AxisSpace();
    double var45 = var44.getLeft();
    var38.setFixedRangeAxisSpace(var44);
    var38.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.Layer var50 = null;
    java.util.Collection var51 = var38.getDomainMarkers(100, var50);
    var38.setAnchorValue(0.25d, false);
    var38.mapDatasetToDomainAxis(10, (-241));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var3 = var1.getTimeFromLong(2014L);
    int var4 = var1.getSegmentsIncluded();
    int var5 = var1.getSegmentsExcluded();
    var0.setBaseTimeline(var1);
    org.jfree.chart.axis.SegmentedTimeline.Segment var8 = var0.getSegment(24180L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2014L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.axis.CategoryAnchor var39 = var38.getDomainGridlinePosition();
    org.jfree.data.category.CategoryDataset var40 = var38.getDataset();
    org.jfree.chart.LegendItemCollection var41 = var38.getLegendItems();
    var38.clearDomainAxes();
    org.jfree.chart.util.SortOrder var43 = var38.getRowRenderingOrder();
    boolean var44 = var38.isDomainGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D("#ffff9c");
    boolean var47 = var46.isAxisLineVisible();
    var38.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var46);
    var46.configure();
    var46.addCategoryLabelToolTip((java.lang.Comparable)' ', "Polar Plot");
    boolean var53 = var46.isTickLabelsVisible();
    var46.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }


    org.jfree.data.KeyToGroupMap var0 = new org.jfree.data.KeyToGroupMap();
    java.util.List var1 = var0.getGroups();
    java.util.List var2 = var0.getGroups();
    java.lang.Object var3 = var0.clone();
    org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
    int var5 = var0.getGroupIndex((java.lang.Comparable)var4);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var8.setUpperMargin(0.0d);
    int var11 = var8.getMaximumCategoryLabelLines();
    java.lang.Object var12 = var8.clone();
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var17 = var14.getLegendItem((-1), 100);
    var14.setBaseShapesFilled(false);
    java.awt.Paint var21 = var14.getSeriesOutlinePaint((-1));
    java.awt.Paint var23 = var14.lookupSeriesOutlinePaint(0);
    var13.setLabelPaint(var23);
    double var25 = var13.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var29 = var26.getLegendItem(2, 0);
    double var30 = var26.getBase();
    org.jfree.chart.labels.ItemLabelPosition var33 = var26.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var37 = var34.getLegendItem((-1), 100);
    var34.setBaseShapesFilled(false);
    java.awt.Paint var42 = var34.getItemOutlinePaint(10, 1);
    var26.setErrorIndicatorPaint(var42);
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var6, var8, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var26);
    var44.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.CategoryAxis var48 = var44.getDomainAxisForDataset(1);
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis();
    var44.setDomainAxis(0, var50, false);
    org.jfree.chart.renderer.category.StackedAreaRenderer var54 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var55 = var54.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var56 = var54.getBaseNegativeItemLabelPosition();
    java.awt.Paint var59 = var54.getItemFillPaint(4, (-457));
    java.awt.Shape var61 = var54.lookupSeriesShape(2);
    org.jfree.chart.entity.AxisLabelEntity var64 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var50, var61, "", "Pie 3D Plot");
    org.jfree.chart.entity.CategoryLabelEntity var67 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)var4, var61, "DateTickUnit[YEAR, 2]", "Category Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(2.0d, 100.0d);
    double var3 = var2.getYOffset();
    double var4 = var2.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.0d);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var2 = var0.getTimeFromLong(2014L);
//     int var3 = var0.getSegmentsIncluded();
//     int var4 = var0.getSegmentsExcluded();
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var6 = var5.getMaximumDate();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var7 = var0.getSegment(var6);
//     long var8 = var0.getSegmentsIncludedSize();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     java.util.Date var10 = var9.getEnd();
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var15 = var12.getLegendItem((-1), 100);
//     var12.setBaseShapesFilled(false);
//     java.awt.Paint var19 = var12.getSeriesOutlinePaint((-1));
//     java.awt.Paint var21 = var12.lookupSeriesOutlinePaint(0);
//     var11.setLabelPaint(var21);
//     double var23 = var11.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var29 = var26.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
//     org.jfree.chart.plot.Plot var32 = var31.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var33 = null;
//     var31.axisChanged(var33);
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", var29, (org.jfree.chart.plot.Plot)var31, true);
//     java.awt.Paint var37 = var31.getBackgroundPaint();
//     java.awt.Paint var38 = var31.getLabelOutlinePaint();
//     var11.setTickMarkPaint(var38);
//     java.text.DateFormat var42 = null;
//     org.jfree.chart.axis.DateTickUnit var43 = new org.jfree.chart.axis.DateTickUnit(2, 1, var42);
//     var11.setTickUnit(var43, false, false);
//     org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var48 = var47.getMaximumDate();
//     java.lang.String var49 = var43.dateToString(var48);
//     int var50 = var43.getCount();
//     double var51 = var43.getSize();
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month();
//     long var53 = var52.getSerialIndex();
//     java.util.Date var54 = var52.getEnd();
//     org.jfree.data.time.Month var55 = new org.jfree.data.time.Month();
//     long var56 = var55.getSerialIndex();
//     java.util.Date var57 = var55.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var58 = new org.jfree.data.time.SimpleTimePeriod(var54, var57);
//     java.lang.String var59 = var43.dateToString(var54);
//     boolean var60 = var0.containsDomainRange(var10, var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "12/31/69"+ "'", var49.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 8.64E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + "12/31/14"+ "'", var59.equals("12/31/14"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == true);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var1.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var5 = var1.getBaseLinesVisible();
    java.lang.Boolean var7 = var1.getSeriesVisibleInLegend(10);
    java.awt.Paint var8 = var1.getBaseItemLabelPaint();
    java.awt.Color var11 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var12 = null;
    float[] var13 = var11.getRGBColorComponents(var12);
    var1.setBaseItemLabelPaint((java.awt.Paint)var11);
    org.jfree.chart.renderer.category.StackedAreaRenderer var16 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var17 = var16.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getBaseNegativeItemLabelPosition();
    var1.setBasePositiveItemLabelPosition(var18, true);
    var0.setPositiveItemLabelPositionFallback(var18);
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    boolean var23 = var22.isRangeGridlinesVisible();
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var22);
    double var25 = var22.getDomainCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.25d);
    double var3 = var2.getEndValue();
    double var4 = var2.getEndValue();
    org.jfree.chart.util.GradientPaintTransformer var5 = null;
    var2.setGradientPaintTransformer(var5);
    org.jfree.chart.util.RectangleInsets var7 = var2.getLabelOffset();
    org.jfree.data.KeyToGroupMap var8 = new org.jfree.data.KeyToGroupMap();
    java.util.List var9 = var8.getGroups();
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    var12.configure();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    var10.setAxisOffset(var14);
    org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
    java.awt.Stroke var21 = var17.getItemStroke(0, 0);
    var10.setRangeZeroBaselineStroke(var21);
    org.jfree.chart.util.Layer var23 = null;
    java.util.Collection var24 = var10.getDomainMarkers(var23);
    var10.setForegroundAlpha(100.0f);
    var10.setRangeCrosshairVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var30 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var29};
    var10.setRenderers(var30);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D("");
    var34.configure();
    org.jfree.chart.util.RectangleInsets var36 = var34.getLabelInsets();
    var32.setAxisOffset(var36);
    org.jfree.chart.plot.CategoryMarker var39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var40 = var39.getOutlineStroke();
    var32.addDomainMarker((org.jfree.chart.plot.Marker)var39);
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = var32.getRenderer();
    org.jfree.chart.axis.ValueAxis var44 = var32.getDomainAxis(1);
    java.awt.Stroke var45 = var32.getDomainCrosshairStroke();
    var10.setRangeGridlineStroke(var45);
    boolean var47 = var8.equals((java.lang.Object)var45);
    var2.setStroke(var45);
    float var49 = var2.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.8f);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     var2.configure();
//     org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
//     var0.setAxisOffset(var4);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
//     java.awt.Stroke var11 = var7.getItemStroke(0, 0);
//     var0.setRangeZeroBaselineStroke(var11);
//     org.jfree.chart.util.Layer var13 = null;
//     java.util.Collection var14 = var0.getDomainMarkers(var13);
//     var0.setForegroundAlpha(100.0f);
//     var0.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisLocation var20 = null;
//     var0.setDomainAxisLocation(1, var20, false);
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
//     var25.configure();
//     var25.setAutoTickUnitSelection(false);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D("");
//     var31.configure();
//     org.jfree.chart.util.RectangleInsets var33 = var31.getLabelInsets();
//     var29.setAxisOffset(var33);
//     org.jfree.chart.util.RectangleInsets var35 = var29.getAxisOffset();
//     java.awt.Graphics2D var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     org.jfree.chart.plot.CrosshairState var40 = null;
//     boolean var41 = var29.render(var36, var37, 1, var39, var40);
//     var25.setPlot((org.jfree.chart.plot.Plot)var29);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var46 = var43.getLegendItem((-1), 100);
//     boolean var47 = var43.getBaseLinesVisible();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
//     java.awt.Paint var51 = var50.getErrorIndicatorPaint();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var52 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     var50.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var52);
//     var43.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var52);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var56 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var59 = var56.getItemLabelFont((-1), 0);
//     var43.setBaseItemLabelFont(var59);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var61 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var63 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var61, (java.lang.Comparable)"");
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.RingPlot var65 = new org.jfree.chart.plot.RingPlot(var64);
//     org.jfree.chart.plot.Plot var66 = var65.getRootPlot();
//     var61.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var66);
//     java.util.List var68 = var61.getRowKeys();
//     java.util.List var69 = var61.getRowKeys();
//     org.jfree.data.general.DatasetChangeEvent var70 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var43, (org.jfree.data.general.Dataset)var61);
//     var29.datasetChanged(var70);
//     var0.datasetChanged(var70);
//     org.jfree.data.general.PieDataset var73 = null;
//     org.jfree.chart.plot.RingPlot var74 = new org.jfree.chart.plot.RingPlot(var73);
//     org.jfree.chart.plot.Plot var75 = var74.getRootPlot();
//     org.jfree.chart.JFreeChart var76 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var74);
//     boolean var77 = var76.getAntiAlias();
//     java.awt.Stroke var78 = var76.getBorderStroke();
//     java.awt.Stroke var79 = var76.getBorderStroke();
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var76);
//     
//     // Checks the contract:  equals-hashcode on var65 and var74
//     assertTrue("Contract failed: equals-hashcode on var65 and var74", var65.equals(var74) ? var65.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var65
//     assertTrue("Contract failed: equals-hashcode on var74 and var65", var74.equals(var65) ? var74.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var75
//     assertTrue("Contract failed: equals-hashcode on var66 and var75", var66.equals(var75) ? var66.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var66
//     assertTrue("Contract failed: equals-hashcode on var75 and var66", var75.equals(var66) ? var75.hashCode() == var66.hashCode() : true);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlockAnchor var4 = null;
//     var0.draw(var1, 0.0f, 1.0f, var4, (-1.0f), (-1.0f), 3.0d);
//     org.jfree.chart.util.HorizontalAlignment var9 = var0.getLineAlignment();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.util.Size2D var11 = var0.calculateDimensions(var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.util.Size2D var13 = var0.calculateDimensions(var12);
//     
//     // Checks the contract:  equals-hashcode on var11 and var13
//     assertTrue("Contract failed: equals-hashcode on var11 and var13", var11.equals(var13) ? var11.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var11
//     assertTrue("Contract failed: equals-hashcode on var13 and var11", var13.equals(var11) ? var13.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.chart.renderer.category.StackedAreaRenderer var5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var8 = var5.getItemLabelFont((-1), 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var13 = var9.getBaseLinesVisible();
    java.lang.Boolean var15 = var9.getSeriesVisibleInLegend(10);
    java.awt.Paint var16 = var9.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("", var8, var16);
    var1.setLabelFont(var8);
    var1.setNoDataMessage("Pie Plot");
    java.awt.Stroke var22 = var1.getSectionOutlineStroke((java.lang.Comparable)100);
    java.awt.Font var23 = var1.getLabelFont();
    org.jfree.chart.labels.PieToolTipGenerator var24 = var1.getToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, Double.NaN, Double.NaN);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 10.0d, 0.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, (-15.99999d), 10.0f, (-1.0f));
    var0.setBaseShape(var14);
    org.jfree.chart.labels.ItemLabelPosition var16 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.Arrangement var17 = null;
    org.jfree.chart.block.Arrangement var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var2 = var1.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var1.getSeriesNegativeItemLabelPosition((-1));
//     org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var7 = var6.getLimit();
//     double var8 = var6.getLimit();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var9 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var9, (java.lang.Comparable)"");
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     org.jfree.chart.plot.Plot var14 = var13.getRootPlot();
//     var9.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var14);
//     java.lang.Comparable var16 = null;
//     java.lang.Number var18 = var9.getMeanValue(var16, (java.lang.Comparable)100.0f);
//     var6.setDataset((org.jfree.data.category.CategoryDataset)var9);
//     org.jfree.data.general.DatasetGroup var20 = var9.getGroup();
//     double var22 = var9.getRangeLowerBound(true);
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
//     var25.configure();
//     org.jfree.chart.util.RectangleInsets var27 = var25.getLabelInsets();
//     var23.setAxisOffset(var27);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var30 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var31 = var30.getEndType();
//     java.awt.Stroke var34 = var30.getItemStroke(0, 0);
//     var23.setRangeZeroBaselineStroke(var34);
//     org.jfree.chart.util.Layer var36 = null;
//     java.util.Collection var37 = var23.getDomainMarkers(var36);
//     var23.setForegroundAlpha(100.0f);
//     boolean var40 = var9.hasListener((java.util.EventListener)var23);
//     org.jfree.data.general.PieDataset var42 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var9, (-16777206));
//     org.jfree.data.Range var43 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var9);
//     java.util.EventListener var44 = null;
//     boolean var45 = var9.hasListener(var44);
//     org.jfree.data.Range var46 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var9);
//     org.jfree.data.general.DatasetGroup var47 = var9.getGroup();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var50);
//     boolean var52 = var47.equals((java.lang.Object)1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, Double.NaN, Double.NaN);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var14 = var12.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var17 = new org.jfree.chart.entity.CategoryItemEntity(var2, "hi!", "", (org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var21 = var18.getLegendItem((-1), 100);
//     var18.setBaseShapesFilled(false);
//     java.awt.Paint var25 = var18.getSeriesOutlinePaint((-1));
//     java.awt.Paint var27 = var18.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic(var2, var27);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     org.jfree.chart.plot.Plot var31 = var30.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getInsets();
//     double var34 = var32.calculateBottomOutset(100.0d);
//     var28.setPadding(var32);
//     org.jfree.chart.util.RectangleInsets var36 = var28.getMargin();
//     org.jfree.chart.util.GradientPaintTransformer var37 = var28.getFillPaintTransformer();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var1 = var0.getLimit();
//     double var2 = var0.getLimit();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var3 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var3, (java.lang.Comparable)"");
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     var3.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
//     java.lang.Comparable var10 = null;
//     java.lang.Number var12 = var3.getMeanValue(var10, (java.lang.Comparable)100.0f);
//     var0.setDataset((org.jfree.data.category.CategoryDataset)var3);
//     org.jfree.data.general.DatasetGroup var14 = var3.getGroup();
//     double var16 = var3.getRangeLowerBound(true);
//     int var18 = var3.getColumnIndex((java.lang.Comparable)true);
//     org.jfree.data.general.PieDataset var20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var3, 156);
//     org.jfree.data.general.PieDataset var22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var3, (java.lang.Comparable)"December 2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var1.axisChanged(var3);
    var1.setShadowYOffset(0.0d);
    org.jfree.chart.renderer.category.StackedAreaRenderer var10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var13 = var10.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
    org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var15.axisChanged(var17);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("hi!", var13, (org.jfree.chart.plot.Plot)var15, true);
    java.util.List var21 = var20.getSubtitles();
    java.awt.Stroke var22 = var20.getBorderStroke();
    var1.setSectionOutlineStroke((java.lang.Comparable)0.0d, var22);
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    var26.configure();
    org.jfree.chart.util.RectangleInsets var28 = var26.getLabelInsets();
    var24.setAxisOffset(var28);
    org.jfree.chart.renderer.category.StackedAreaRenderer var31 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var32 = var31.getEndType();
    java.awt.Stroke var35 = var31.getItemStroke(0, 0);
    var24.setRangeZeroBaselineStroke(var35);
    org.jfree.chart.util.Layer var37 = null;
    java.util.Collection var38 = var24.getDomainMarkers(var37);
    org.jfree.chart.util.RectangleInsets var39 = var24.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var41 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var42 = var41.getEndType();
    java.awt.Stroke var45 = var41.getItemStroke(0, 0);
    var24.setDomainZeroBaselineStroke(var45);
    org.jfree.chart.util.RectangleEdge var48 = var24.getDomainAxisEdge(1);
    var24.setRangeCrosshairValue((-1.0d), false);
    org.jfree.chart.axis.AxisSpace var52 = new org.jfree.chart.axis.AxisSpace();
    double var53 = var52.getBottom();
    var24.setFixedRangeAxisSpace(var52);
    var24.setRangeCrosshairVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
    var24.setRenderer(11, var58, true);
    java.awt.Stroke var61 = var24.getRangeGridlineStroke();
    var1.setSeparatorStroke(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var1.getLegendLabelGenerator();
    org.jfree.chart.util.Rotation var5 = var1.getDirection();
    java.awt.Stroke var6 = var1.getSeparatorStroke();
    java.awt.Paint var7 = var1.getLabelOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-241), (java.lang.Number)432000000L);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     int var2 = var0.getIndex((java.lang.Comparable)0.25d);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getSerialIndex();
//     int var5 = var0.getIndex((java.lang.Comparable)var4);
//     org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.25d);
//     org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
//     boolean var10 = var8.equals((java.lang.Object)var9);
//     org.jfree.chart.util.RectangleInsets var11 = var8.getLabelOffset();
//     org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Paint var14 = var13.getLabelPaint();
//     java.lang.Comparable var15 = var13.getKey();
//     java.lang.String var16 = var13.getLabel();
//     var13.setDrawAsLine(true);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, Double.NaN, Double.NaN);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var33 = var31.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var36 = new org.jfree.chart.entity.CategoryItemEntity(var21, "hi!", "", (org.jfree.data.category.CategoryDataset)var31, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var40 = var37.getLegendItem((-1), 100);
//     var37.setBaseShapesFilled(false);
//     java.awt.Paint var44 = var37.getSeriesOutlinePaint((-1));
//     java.awt.Paint var46 = var37.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var21, var46);
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.RingPlot var49 = new org.jfree.chart.plot.RingPlot(var48);
//     org.jfree.chart.plot.Plot var50 = var49.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var51 = var49.getInsets();
//     double var53 = var51.calculateBottomOutset(100.0d);
//     var47.setPadding(var51);
//     org.jfree.chart.util.RectangleInsets var55 = var47.getMargin();
//     org.jfree.chart.util.RectangleAnchor var56 = var47.getShapeAnchor();
//     var13.setLabelAnchor(var56);
//     var8.setLabelAnchor(var56);
//     boolean var59 = var0.equals((java.lang.Object)var8);
//     java.lang.Comparable var61 = var0.getKey(15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + true+ "'", var15.equals(true));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var61);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
    java.awt.Stroke var11 = var7.getItemStroke(0, 0);
    var0.setRangeZeroBaselineStroke(var11);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var0.getDomainMarkers(var13);
    var0.setForegroundAlpha(100.0f);
    java.awt.Graphics2D var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.data.KeyToGroupMap var19 = new org.jfree.data.KeyToGroupMap();
    java.util.List var20 = var19.getGroups();
    var0.drawDomainTickBands(var17, var18, var20);
    org.jfree.chart.axis.ValueAxis var23 = var0.getRangeAxis(156);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }


    org.jfree.data.KeyToGroupMap var8 = new org.jfree.data.KeyToGroupMap();
    java.util.List var9 = var8.getGroups();
    org.jfree.data.statistics.BoxAndWhiskerItem var10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)1.0d, (java.lang.Number)100.0f, (java.lang.Number)(short)1, (java.lang.Number)1.0f, (java.lang.Number)(byte)(-1), (java.lang.Number)(-1), (java.lang.Number)(byte)100, var9);
    java.lang.Number var11 = var10.getMinRegularValue();
    java.lang.Number var12 = var10.getMinRegularValue();
    java.lang.Number var13 = var10.getMaxOutlier();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 1.0f+ "'", var11.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1.0f+ "'", var12.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (byte)100+ "'", var13.equals((byte)100));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }


    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.lang.Object var7 = var6.clone();
    int var8 = var6.getSubtitleCount();
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var11.setUpperMargin(0.0d);
    int var14 = var11.getMaximumCategoryLabelLines();
    java.lang.Object var15 = var11.clone();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var20 = var17.getLegendItem((-1), 100);
    var17.setBaseShapesFilled(false);
    java.awt.Paint var24 = var17.getSeriesOutlinePaint((-1));
    java.awt.Paint var26 = var17.lookupSeriesOutlinePaint(0);
    var16.setLabelPaint(var26);
    double var28 = var16.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var32 = var29.getLegendItem(2, 0);
    double var33 = var29.getBase();
    org.jfree.chart.labels.ItemLabelPosition var36 = var29.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var40 = var37.getLegendItem((-1), 100);
    var37.setBaseShapesFilled(false);
    java.awt.Paint var45 = var37.getItemOutlinePaint(10, 1);
    var29.setErrorIndicatorPaint(var45);
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var9, var11, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29);
    var47.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.AxisSpace var50 = new org.jfree.chart.axis.AxisSpace();
    double var51 = var50.getLeft();
    var47.setFixedRangeAxisSpace(var50);
    org.jfree.chart.axis.AxisSpace var53 = new org.jfree.chart.axis.AxisSpace();
    double var54 = var53.getLeft();
    var47.setFixedRangeAxisSpace(var53);
    var47.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.CategoryAxis var58 = var47.getDomainAxis();
    boolean var59 = var6.equals((java.lang.Object)var58);
    org.jfree.chart.title.LegendTitle var60 = var6.getLegend();
    java.awt.image.BufferedImage var63 = var6.createBufferedImage(100, 5);
    org.jfree.chart.ui.ProjectInfo var67 = new org.jfree.chart.ui.ProjectInfo("UnitType.ABSOLUTE", "", "ThreadContext", (java.awt.Image)var63, "", "AreaRendererEndType.TAPER", "org.jfree.data.general.DatasetChangeEvent[source=false]");
    var67.addOptionalLibrary("Pie 3D Plot");
    java.awt.Image var70 = var67.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
    java.awt.Paint var3 = var2.getErrorIndicatorPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var4.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var8 = var4.getBaseLinesVisible();
    java.lang.Boolean var10 = var4.getSeriesVisibleInLegend(10);
    java.awt.Paint var11 = var4.getBaseItemLabelPaint();
    java.awt.Color var14 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var15 = null;
    float[] var16 = var14.getRGBColorComponents(var15);
    var4.setBaseItemLabelPaint((java.awt.Paint)var14);
    org.jfree.chart.renderer.category.StackedAreaRenderer var19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var20 = var19.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var21 = var19.getBaseNegativeItemLabelPosition();
    var4.setBasePositiveItemLabelPosition(var21, true);
    var2.setBaseNegativeItemLabelPosition(var21);
    org.jfree.chart.text.TextAnchor var25 = var21.getTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem((-1), 100);
    var0.setBaseShapesFilled(false);
    java.awt.Paint var8 = var0.getItemOutlinePaint(10, 1);
    java.lang.Object var9 = var0.clone();
    var0.setSeriesShapesVisible(1, false);
    var0.setDrawOutlines(false);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var19 = var16.getLegendItem(2, 0);
    java.awt.Font var20 = var16.getBaseItemLabelFont();
    var15.setItemFont(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    int var1 = var0.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test78"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.configure();
    var1.setAutoTickUnitSelection(false);
    double var5 = var1.getUpperMargin();
    boolean var6 = var1.isTickLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test79"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
    java.awt.Stroke var11 = var7.getItemStroke(0, 0);
    var0.setRangeZeroBaselineStroke(var11);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var0.getDomainMarkers(var13);
    var0.setForegroundAlpha(100.0f);
    var0.setRangeCrosshairVisible(true);
    boolean var19 = var0.isRangeZoomable();
    org.jfree.chart.util.RectangleEdge var21 = var0.getDomainAxisEdge(1);
    boolean var22 = var0.isRangeZoomable();
    float var23 = var0.getBackgroundAlpha();
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    var26.configure();
    org.jfree.chart.util.RectangleInsets var28 = var26.getLabelInsets();
    var24.setAxisOffset(var28);
    org.jfree.chart.renderer.category.StackedAreaRenderer var31 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var32 = var31.getEndType();
    java.awt.Stroke var35 = var31.getItemStroke(0, 0);
    var24.setRangeZeroBaselineStroke(var35);
    org.jfree.chart.util.Layer var37 = null;
    java.util.Collection var38 = var24.getDomainMarkers(var37);
    org.jfree.chart.util.RectangleInsets var39 = var24.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var41 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var42 = var41.getEndType();
    java.awt.Stroke var45 = var41.getItemStroke(0, 0);
    var24.setDomainZeroBaselineStroke(var45);
    org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var51 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var52 = var51.isTickMarksVisible();
    org.jfree.data.Range var55 = new org.jfree.data.Range(1.0d, 100.0d);
    var51.setRangeWithMargins(var55, false, false);
    var49.setRangeWithMargins(var55);
    var49.configure();
    org.jfree.chart.axis.NumberTickUnit var61 = var49.getTickUnit();
    var24.setDomainAxis(5, (org.jfree.chart.axis.ValueAxis)var49);
    org.jfree.data.general.PieDataset var63 = null;
    org.jfree.chart.plot.RingPlot var64 = new org.jfree.chart.plot.RingPlot(var63);
    org.jfree.chart.plot.Plot var65 = var64.getRootPlot();
    org.jfree.chart.util.RectangleInsets var66 = var64.getInsets();
    double var67 = var66.getRight();
    var24.setInsets(var66, false);
    org.jfree.chart.plot.SeriesRenderingOrder var70 = var24.getSeriesRenderingOrder();
    org.jfree.chart.LegendItemCollection var71 = var24.getLegendItems();
    var0.setFixedLegendItems(var71);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var74 = var71.get(11);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

//  public void test80() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest7.test80"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("31-December-2014", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test81"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, Double.NaN, 4.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
//     org.jfree.chart.util.Size2D var10 = var4.arrange(var5, var6, var9);
//     org.jfree.chart.util.RectangleInsets var11 = var5.getMargin();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var17 = var14.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
//     org.jfree.chart.plot.Plot var20 = var19.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var21 = null;
//     var19.axisChanged(var21);
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("hi!", var17, (org.jfree.chart.plot.Plot)var19, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var28 = var25.getLegendItem((-1), 100);
//     var25.setBaseShapesFilled(false);
//     java.awt.Paint var32 = var25.getSeriesOutlinePaint((-1));
//     boolean var33 = var24.equals((java.lang.Object)var25);
//     org.jfree.chart.title.TextTitle var34 = var24.getTitle();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var36 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var37 = var36.getEndType();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var41 = var38.getLegendItem((-1), 100);
//     var38.setBaseShapesFilled(false);
//     java.awt.Paint var46 = var38.getItemOutlinePaint(10, 1);
//     java.awt.Paint var48 = var38.getSeriesOutlinePaint(10);
//     var38.setAutoPopulateSeriesShape(false);
//     boolean var51 = var36.equals((java.lang.Object)var38);
//     java.awt.Paint var54 = var36.getItemPaint(1, 0);
//     var34.setPaint(var54);
//     org.jfree.data.time.Month var56 = new org.jfree.data.time.Month();
//     long var57 = var56.getSerialIndex();
//     java.util.Date var58 = var56.getEnd();
//     org.jfree.data.time.Month var59 = new org.jfree.data.time.Month();
//     long var60 = var59.getSerialIndex();
//     java.util.Date var61 = var59.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var62 = new org.jfree.data.time.SimpleTimePeriod(var58, var61);
//     boolean var63 = var34.equals((java.lang.Object)var58);
//     boolean var64 = var34.getExpandToFitSpace();
//     var34.setID("Other");
//     java.awt.Paint var67 = null;
//     var34.setBackgroundPaint(var67);
//     var5.add((org.jfree.chart.block.Block)var34);
//     java.lang.String var70 = var34.getText();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var70 + "' != '" + "hi!"+ "'", var70.equals("hi!"));
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test82"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setUpperMargin(0.0d);
//     int var5 = var2.getMaximumCategoryLabelLines();
//     java.lang.Object var6 = var2.clone();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
//     var8.setBaseShapesFilled(false);
//     java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
//     java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
//     var7.setLabelPaint(var17);
//     double var19 = var7.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
//     double var24 = var20.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
//     var28.setBaseShapesFilled(false);
//     java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
//     var20.setErrorIndicatorPaint(var36);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     org.jfree.chart.axis.CategoryAnchor var39 = var38.getDomainGridlinePosition();
//     org.jfree.data.category.CategoryDataset var40 = var38.getDataset();
//     org.jfree.chart.LegendItemCollection var41 = var38.getLegendItems();
//     var38.clearDomainAxes();
//     org.jfree.chart.util.SortOrder var43 = var38.getRowRenderingOrder();
//     int var44 = var38.getRangeAxisCount();
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var45 = null;
//     var38.setRenderers(var45);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test83"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, Double.NaN, Double.NaN);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var14 = var12.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var17 = new org.jfree.chart.entity.CategoryItemEntity(var2, "hi!", "", (org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var21 = var18.getLegendItem((-1), 100);
//     var18.setBaseShapesFilled(false);
//     java.awt.Paint var25 = var18.getSeriesOutlinePaint((-1));
//     java.awt.Paint var27 = var18.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic(var2, var27);
//     org.jfree.chart.entity.LegendItemEntity var29 = new org.jfree.chart.entity.LegendItemEntity(var2);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.data.general.Dataset var31 = var29.getDataset();
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D("org.jfree.data.UnknownKeyException: ");
//     org.jfree.chart.renderer.PolarItemRenderer var35 = null;
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var32, (org.jfree.chart.axis.ValueAxis)var34, var35);
//     java.awt.Paint var37 = null;
//     var36.setRadiusGridlinePaint(var37);
//     org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D("Pie Plot");
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot(var42);
//     double var44 = var43.getInteriorGap();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var47 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var50 = var47.getItemLabelFont((-1), 0);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var51.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var55 = var51.getBaseLinesVisible();
//     java.lang.Boolean var57 = var51.getSeriesVisibleInLegend(10);
//     java.awt.Paint var58 = var51.getBaseItemLabelPaint();
//     org.jfree.chart.text.TextFragment var59 = new org.jfree.chart.text.TextFragment("", var50, var58);
//     var43.setLabelFont(var50);
//     var40.setTickLabelFont((java.lang.Comparable)1L, var50);
//     var36.setAngleLabelFont(var50);
//     java.awt.Paint var63 = null;
//     var36.setAngleGridlinePaint(var63);
//     org.jfree.chart.LegendItemCollection var65 = var36.getLegendItems();
//     boolean var66 = var29.equals((java.lang.Object)var65);
//     java.lang.Object var67 = var29.clone();
//     
//     // Checks the contract:  equals-hashcode on var30 and var67
//     assertTrue("Contract failed: equals-hashcode on var30 and var67", var30.equals(var67) ? var30.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var30
//     assertTrue("Contract failed: equals-hashcode on var67 and var30", var67.equals(var30) ? var67.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test84"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, 0.0f, 1.0f, var4, (-1.0f), (-1.0f), 3.0d);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var0.calculateBounds(var9, (-1.0f), 0.5f, var12, 100.0f, (-1.0f), 4.0d);
    org.jfree.chart.util.HorizontalAlignment var17 = var0.getLineAlignment();
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLineAlignment(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test85"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var1 = var0.getItemMargin();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var4);
    java.lang.String var6 = var5.getURLText();
    var5.setToolTipText("");
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
    org.jfree.chart.util.RectangleInsets var12 = var10.getInsets();
    boolean var13 = var5.equals((java.lang.Object)var10);
    boolean var14 = var0.equals((java.lang.Object)var5);
    boolean var15 = var0.getFillBox();
    double var16 = var0.getItemMargin();
    double var17 = var0.getItemMargin();
    var0.setBaseSeriesVisible(false, false);
    var0.setFillBox(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test86"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var4 = var1.getLegendItem((-1), 100);
//     var1.setBaseShapesFilled(false);
//     java.awt.Paint var8 = var1.getSeriesOutlinePaint((-1));
//     java.awt.Paint var10 = var1.lookupSeriesOutlinePaint(0);
//     var0.setLabelPaint(var10);
//     double var12 = var0.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var18 = var15.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
//     org.jfree.chart.plot.Plot var21 = var20.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var20.axisChanged(var22);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", var18, (org.jfree.chart.plot.Plot)var20, true);
//     java.awt.Paint var26 = var20.getBackgroundPaint();
//     java.awt.Paint var27 = var20.getLabelOutlinePaint();
//     var0.setTickMarkPaint(var27);
//     java.text.DateFormat var31 = null;
//     org.jfree.chart.axis.DateTickUnit var32 = new org.jfree.chart.axis.DateTickUnit(2, 1, var31);
//     var0.setTickUnit(var32, false, false);
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var37 = var36.getMaximumDate();
//     java.lang.String var38 = var32.dateToString(var37);
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var40 = var39.getMaximumDate();
//     org.jfree.data.time.SimpleTimePeriod var41 = new org.jfree.data.time.SimpleTimePeriod(var37, var40);
//     org.jfree.data.time.Month var43 = new org.jfree.data.time.Month();
//     long var44 = var43.getSerialIndex();
//     java.util.Date var45 = var43.getEnd();
//     org.jfree.chart.text.TextBlock var46 = null;
//     org.jfree.chart.text.TextBlockAnchor var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D("");
//     var50.configure();
//     org.jfree.chart.util.RectangleInsets var52 = var50.getLabelInsets();
//     var48.setAxisOffset(var52);
//     org.jfree.chart.plot.CategoryMarker var55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Stroke var56 = var55.getOutlineStroke();
//     var48.addDomainMarker((org.jfree.chart.plot.Marker)var55);
//     var55.setLabel("org.jfree.chart.event.RendererChangeEvent[source=false]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var60 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var61.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var65 = var61.getBaseLinesVisible();
//     java.lang.Boolean var67 = var61.getSeriesVisibleInLegend(10);
//     java.awt.Paint var68 = var61.getBaseItemLabelPaint();
//     java.awt.Color var71 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var72 = null;
//     float[] var73 = var71.getRGBColorComponents(var72);
//     var61.setBaseItemLabelPaint((java.awt.Paint)var71);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var76 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var77 = var76.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var78 = var76.getBaseNegativeItemLabelPosition();
//     var61.setBasePositiveItemLabelPosition(var78, true);
//     var60.setPositiveItemLabelPositionFallback(var78);
//     org.jfree.chart.text.TextAnchor var82 = var78.getRotationAnchor();
//     var55.setLabelTextAnchor(var82);
//     org.jfree.chart.axis.CategoryTick var85 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)var45, var46, var47, var82, 2.0d);
//     org.jfree.chart.text.TextBlock var86 = var85.getLabel();
//     org.jfree.chart.text.TextAnchor var87 = var85.getRotationAnchor();
//     org.jfree.chart.plot.CategoryMarker var89 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Paint var90 = var89.getLabelPaint();
//     org.jfree.chart.text.TextAnchor var91 = var89.getLabelTextAnchor();
//     org.jfree.chart.axis.DateTick var93 = new org.jfree.chart.axis.DateTick(var37, "Pie 3D Plot", var87, var91, 0.25d);
//     java.util.Date var94 = var93.getDate();
//     java.util.Date var95 = var93.getDate();
//     double var96 = var93.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "12/31/69"+ "'", var38.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == 1.0d);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test87"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(1.0d, 100.0d);
    java.lang.String var3 = var2.toString();
    org.jfree.data.Range var5 = org.jfree.data.Range.shift(var2, 0.0d);
    org.jfree.data.Range var8 = org.jfree.data.Range.expand(var5, 0.0d, 0.2d);
    org.jfree.data.Range var11 = new org.jfree.data.Range(1.0d, 100.0d);
    java.lang.String var12 = var11.toString();
    org.jfree.data.Range var14 = org.jfree.data.Range.shift(var11, 0.0d);
    org.jfree.data.Range var17 = org.jfree.data.Range.expand(var14, 0.0d, 0.2d);
    java.lang.String var18 = var14.toString();
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var8, var14);
    double var20 = var19.getHeight();
    java.lang.String var21 = var19.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Range[1.0,100.0]"+ "'", var3.equals("Range[1.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Range[1.0,100.0]"+ "'", var12.equals("Range[1.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "Range[1.0,100.0]"+ "'", var18.equals("Range[1.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"+ "'", var21.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test88"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getInteriorGap();
    double var3 = var1.getShadowYOffset();
    org.jfree.chart.urls.PieURLGenerator var4 = var1.getLegendLabelURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test89"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     var0.clear();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var4 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var7 = var4.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var11 = null;
//     var9.axisChanged(var11);
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", var7, (org.jfree.chart.plot.Plot)var9, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var18 = var15.getLegendItem((-1), 100);
//     var15.setBaseShapesFilled(false);
//     java.awt.Paint var22 = var15.getSeriesOutlinePaint((-1));
//     boolean var23 = var14.equals((java.lang.Object)var15);
//     org.jfree.chart.title.TextTitle var24 = var14.getTitle();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var27 = var26.getEndType();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
//     var28.setBaseShapesFilled(false);
//     java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
//     java.awt.Paint var38 = var28.getSeriesOutlinePaint(10);
//     var28.setAutoPopulateSeriesShape(false);
//     boolean var41 = var26.equals((java.lang.Object)var28);
//     java.awt.Paint var44 = var26.getItemPaint(1, 0);
//     var24.setPaint(var44);
//     java.lang.String var46 = var24.getURLText();
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D("");
//     var49.configure();
//     org.jfree.chart.util.RectangleInsets var51 = var49.getLabelInsets();
//     var47.setAxisOffset(var51);
//     org.jfree.chart.plot.CategoryMarker var54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Stroke var55 = var54.getOutlineStroke();
//     var47.addDomainMarker((org.jfree.chart.plot.Marker)var54);
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = var47.getRenderer();
//     org.jfree.chart.axis.ValueAxis var59 = var47.getDomainAxis(1);
//     java.awt.Stroke var60 = var47.getDomainCrosshairStroke();
//     var0.add((org.jfree.chart.block.Block)var24, (java.lang.Object)var60);
//     org.jfree.data.DefaultKeyedValues2D var63 = new org.jfree.data.DefaultKeyedValues2D(false);
//     var63.clear();
//     java.util.List var65 = var63.getColumnKeys();
//     java.lang.Object var66 = null;
//     boolean var67 = var63.equals(var66);
//     int var69 = var63.getRowIndex((java.lang.Comparable)' ');
//     org.jfree.data.general.PieDataset var70 = null;
//     org.jfree.chart.plot.RingPlot var71 = new org.jfree.chart.plot.RingPlot(var70);
//     org.jfree.chart.plot.Plot var72 = var71.getRootPlot();
//     org.jfree.chart.JFreeChart var73 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var71);
//     boolean var74 = var73.getAntiAlias();
//     org.jfree.chart.util.RectangleInsets var75 = var73.getPadding();
//     org.jfree.chart.event.ChartChangeEventType var76 = null;
//     org.jfree.chart.event.ChartChangeEvent var77 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)' ', var73, var76);
//     var73.setTitle("12/31/69");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var80 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var80.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var84 = var80.getBaseLinesVisible();
//     boolean var86 = var80.equals((java.lang.Object)100.0f);
//     org.jfree.chart.event.RendererChangeEvent var87 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var86);
//     java.lang.String var88 = var87.toString();
//     org.jfree.chart.event.ChartChangeEventType var89 = var87.getType();
//     org.jfree.chart.event.ChartChangeEvent var90 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var73, var89);
//     
//     // Checks the contract:  equals-hashcode on var9 and var71
//     assertTrue("Contract failed: equals-hashcode on var9 and var71", var9.equals(var71) ? var9.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var9
//     assertTrue("Contract failed: equals-hashcode on var71 and var9", var71.equals(var9) ? var71.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var72
//     assertTrue("Contract failed: equals-hashcode on var10 and var72", var10.equals(var72) ? var10.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var10
//     assertTrue("Contract failed: equals-hashcode on var72 and var10", var72.equals(var10) ? var72.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test90"); }


    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var6 = var5.getTickLabelPaint();
    java.awt.Shape var7 = var5.getDownArrow();
    org.jfree.chart.entity.TickLabelEntity var10 = new org.jfree.chart.entity.TickLabelEntity(var7, "#ffff9c", "");
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
    var13.configure();
    org.jfree.chart.util.RectangleInsets var15 = var13.getLabelInsets();
    var11.setAxisOffset(var15);
    org.jfree.chart.plot.CategoryMarker var18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var19 = var18.getOutlineStroke();
    var11.addDomainMarker((org.jfree.chart.plot.Marker)var18);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = var11.getRenderer();
    org.jfree.chart.axis.ValueAxis var23 = var11.getDomainAxis(1);
    java.awt.Stroke var24 = var11.getDomainCrosshairStroke();
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = var11.getRenderer(15);
    java.awt.Stroke var27 = var11.getRangeCrosshairStroke();
    org.jfree.chart.renderer.category.StackedAreaRenderer var30 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var33 = var30.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.plot.RingPlot var35 = new org.jfree.chart.plot.RingPlot(var34);
    org.jfree.chart.plot.Plot var36 = var35.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var37 = null;
    var35.axisChanged(var37);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", var33, (org.jfree.chart.plot.Plot)var35, true);
    java.lang.Object var41 = var35.clone();
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    org.jfree.chart.util.VerticalAlignment var43 = null;
    org.jfree.chart.block.FlowArrangement var46 = new org.jfree.chart.block.FlowArrangement(var42, var43, 100.0d, 10.0d);
    var46.clear();
    org.jfree.chart.block.Arrangement var48 = null;
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35, (org.jfree.chart.block.Arrangement)var46, var48);
    java.lang.String var50 = var35.getNoDataMessage();
    java.awt.Paint var51 = var35.getBaseSectionOutlinePaint();
    org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("Category Plot", "Default Group", "CONTRACT", "Category Plot", var7, var27, var51);
    java.awt.Stroke var53 = var52.getLineStroke();
    java.lang.String var54 = var52.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "Default Group"+ "'", var54.equals("Default Group"));

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test91"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     int var2 = var0.getIndex((java.lang.Comparable)0.25d);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     long var4 = var3.getSerialIndex();
//     int var5 = var0.getIndex((java.lang.Comparable)var4);
//     org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.25d);
//     org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
//     boolean var10 = var8.equals((java.lang.Object)var9);
//     org.jfree.chart.util.RectangleInsets var11 = var8.getLabelOffset();
//     org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Paint var14 = var13.getLabelPaint();
//     java.lang.Comparable var15 = var13.getKey();
//     java.lang.String var16 = var13.getLabel();
//     var13.setDrawAsLine(true);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, Double.NaN, Double.NaN);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var33 = var31.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var36 = new org.jfree.chart.entity.CategoryItemEntity(var21, "hi!", "", (org.jfree.data.category.CategoryDataset)var31, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var40 = var37.getLegendItem((-1), 100);
//     var37.setBaseShapesFilled(false);
//     java.awt.Paint var44 = var37.getSeriesOutlinePaint((-1));
//     java.awt.Paint var46 = var37.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var21, var46);
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.RingPlot var49 = new org.jfree.chart.plot.RingPlot(var48);
//     org.jfree.chart.plot.Plot var50 = var49.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var51 = var49.getInsets();
//     double var53 = var51.calculateBottomOutset(100.0d);
//     var47.setPadding(var51);
//     org.jfree.chart.util.RectangleInsets var55 = var47.getMargin();
//     org.jfree.chart.util.RectangleAnchor var56 = var47.getShapeAnchor();
//     var13.setLabelAnchor(var56);
//     var8.setLabelAnchor(var56);
//     boolean var59 = var0.equals((java.lang.Object)var8);
//     org.jfree.chart.event.MarkerChangeEvent var60 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + true+ "'", var15.equals(true));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test92"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.Range var2 = var1.getDefaultAutoRange();
//     org.jfree.data.Range var5 = new org.jfree.data.Range(1.0d, 100.0d);
//     var1.setRangeWithMargins(var5);
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var7);
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     var10.configure();
//     org.jfree.chart.axis.NumberTickUnit var12 = var10.getTickUnit();
//     org.jfree.data.Range var13 = var10.getRange();
//     var10.setLowerMargin(100.0d);
//     double var16 = var10.getFixedAutoRange();
//     org.jfree.chart.axis.MarkerAxisBand var17 = null;
//     var10.setMarkerBand(var17);
//     org.jfree.data.Range var19 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     double var21 = var20.getLabelAngle();
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var26 = var23.getLegendItem((-1), 100);
//     var23.setBaseShapesFilled(false);
//     java.awt.Paint var30 = var23.getSeriesOutlinePaint((-1));
//     java.awt.Paint var32 = var23.lookupSeriesOutlinePaint(0);
//     var22.setLabelPaint(var32);
//     org.jfree.chart.axis.DateTickMarkPosition var34 = var22.getTickMarkPosition();
//     var20.setTickMarkPosition(var34);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var38 = var37.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var39 = var37.getBaseNegativeItemLabelPosition();
//     boolean var40 = var20.equals((java.lang.Object)var39);
//     var8.setAxis((org.jfree.chart.axis.ValueAxis)var20);
//     var8.setAngleGridlinesVisible(false);
//     float var44 = var8.getBackgroundAlpha();
//     boolean var45 = var8.isRadiusGridlinesVisible();
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var52, Double.NaN, Double.NaN);
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.rotateShape(var52, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var62 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var64 = var62.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var67 = new org.jfree.chart.entity.CategoryItemEntity(var52, "hi!", "", (org.jfree.data.category.CategoryDataset)var62, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var68 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var71 = var68.getLegendItem((-1), 100);
//     var68.setBaseShapesFilled(false);
//     java.awt.Paint var75 = var68.getSeriesOutlinePaint((-1));
//     java.awt.Paint var77 = var68.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var78 = new org.jfree.chart.title.LegendGraphic(var52, var77);
//     org.jfree.data.general.PieDataset var79 = null;
//     org.jfree.chart.plot.RingPlot var80 = new org.jfree.chart.plot.RingPlot(var79);
//     org.jfree.chart.plot.Plot var81 = var80.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var82 = var80.getInsets();
//     double var84 = var82.calculateBottomOutset(100.0d);
//     var78.setPadding(var82);
//     org.jfree.chart.util.RectangleAnchor var86 = var78.getShapeLocation();
//     var78.setLineVisible(false);
//     boolean var89 = var78.isLineVisible();
//     java.awt.geom.Rectangle2D var90 = var78.getBounds();
//     java.awt.geom.Point2D var91 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-15.99999d), 8.0d, var90);
//     java.awt.Point var92 = var8.translateValueThetaRadiusToJava2D((-15.99999d), 4.0d, var90);
//     java.io.ObjectOutputStream var93 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.util.SerialUtilities.writePoint2D((java.awt.geom.Point2D)var92, var93);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test93"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    java.util.List var13 = var12.getSubtitles();
    java.awt.Stroke var14 = var12.getBorderStroke();
    org.jfree.chart.event.ChartProgressListener var15 = null;
    var12.addProgressListener(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test94"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setUpperMargin(0.0d);
//     int var5 = var2.getMaximumCategoryLabelLines();
//     java.lang.Object var6 = var2.clone();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
//     var8.setBaseShapesFilled(false);
//     java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
//     java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
//     var7.setLabelPaint(var17);
//     double var19 = var7.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
//     double var24 = var20.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
//     var28.setBaseShapesFilled(false);
//     java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
//     var20.setErrorIndicatorPaint(var36);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     org.jfree.chart.axis.CategoryAnchor var39 = var38.getDomainGridlinePosition();
//     org.jfree.data.category.CategoryDataset var40 = var38.getDataset();
//     org.jfree.chart.LegendItemCollection var41 = var38.getLegendItems();
//     var38.clearDomainAxes();
//     org.jfree.chart.plot.CategoryMarker var44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Paint var45 = var44.getLabelPaint();
//     java.lang.Comparable var46 = var44.getKey();
//     java.lang.String var47 = var44.getLabel();
//     java.awt.Stroke var48 = var44.getOutlineStroke();
//     var38.addDomainMarker(var44);
//     org.jfree.chart.block.BorderArrangement var50 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var52.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var56 = var52.getBaseLinesVisible();
//     java.lang.Boolean var58 = var52.getSeriesVisibleInLegend(10);
//     java.awt.Paint var59 = var52.getBaseItemLabelPaint();
//     java.awt.Color var62 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var63 = null;
//     float[] var64 = var62.getRGBColorComponents(var63);
//     var52.setBaseItemLabelPaint((java.awt.Paint)var62);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var67 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var68 = var67.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var69 = var67.getBaseNegativeItemLabelPosition();
//     var52.setBasePositiveItemLabelPosition(var69, true);
//     var51.setPositiveItemLabelPositionFallback(var69);
//     boolean var73 = var50.equals((java.lang.Object)var51);
//     int var74 = var38.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var51);
//     org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var77 = new org.jfree.chart.axis.NumberAxis3D("");
//     var77.configure();
//     org.jfree.chart.util.RectangleInsets var79 = var77.getLabelInsets();
//     var75.setAxisOffset(var79);
//     org.jfree.chart.plot.CategoryMarker var82 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Stroke var83 = var82.getOutlineStroke();
//     var75.addDomainMarker((org.jfree.chart.plot.Marker)var82);
//     java.awt.geom.Point2D var85 = var75.getQuadrantOrigin();
//     org.jfree.chart.plot.DatasetRenderingOrder var86 = var75.getDatasetRenderingOrder();
//     int var87 = var75.getDatasetCount();
//     boolean var88 = var75.isDomainZeroBaselineVisible();
//     java.awt.Stroke var89 = var75.getDomainCrosshairStroke();
//     org.jfree.chart.util.RectangleEdge var90 = var75.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisLocation var91 = var75.getRangeAxisLocation();
//     var38.setDomainAxisLocation(var91);
//     
//     // Checks the contract:  equals-hashcode on var44 and var82
//     assertTrue("Contract failed: equals-hashcode on var44 and var82", var44.equals(var82) ? var44.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var44
//     assertTrue("Contract failed: equals-hashcode on var82 and var44", var82.equals(var44) ? var82.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test95"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var1 = var0.getMaximumDate();
    org.jfree.data.Range var4 = new org.jfree.data.Range(1.0d, 100.0d);
    var0.setRange(var4, true, false);
    var0.resizeRange(10.0d, 90.0d);
    java.awt.Paint var11 = var0.getTickMarkPaint();
    double var12 = var0.getAutoRangeMinimumSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test96"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var1 = var0.getColumnCount();
    int var2 = var0.getRowCount();
    int var4 = var0.getRowIndex((java.lang.Comparable)Double.NaN);
    org.jfree.data.general.DatasetGroup var5 = var0.getGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test97"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var3 = var2.getTickLabelPaint();
    java.awt.Shape var4 = var2.getUpArrow();
    boolean var5 = var2.isAxisLineVisible();
    var2.setTickMarkOutsideLength(10.0f);
    var2.setLabelToolTip("ThreadContext");
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var14 = var13.isTickMarksVisible();
    org.jfree.data.Range var17 = new org.jfree.data.Range(1.0d, 100.0d);
    var13.setRangeWithMargins(var17, false, false);
    var11.setRangeWithMargins(var17);
    var11.configure();
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var11, var23);
    java.awt.Shape var25 = var11.getDownArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test98"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.String var3 = var1.getCategoryLabelToolTip((java.lang.Comparable)10);
    var1.setUpperMargin(4.0d);
    var1.setTickLabelsVisible(true);
    var1.setCategoryLabelPositionOffset(2);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var11.setUpperMargin(0.0d);
    int var14 = var11.getMaximumCategoryLabelLines();
    java.lang.Object var15 = var11.clone();
    var11.setLowerMargin(2.0d);
    org.jfree.chart.axis.CategoryLabelPositions var18 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.renderer.category.StackedAreaRenderer var21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var24 = var21.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
    org.jfree.chart.plot.Plot var27 = var26.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var28 = null;
    var26.axisChanged(var28);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("hi!", var24, (org.jfree.chart.plot.Plot)var26, true);
    java.lang.Object var32 = var26.clone();
    org.jfree.chart.util.HorizontalAlignment var33 = null;
    org.jfree.chart.util.VerticalAlignment var34 = null;
    org.jfree.chart.block.FlowArrangement var37 = new org.jfree.chart.block.FlowArrangement(var33, var34, 100.0d, 10.0d);
    var37.clear();
    org.jfree.chart.block.Arrangement var39 = null;
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26, (org.jfree.chart.block.Arrangement)var37, var39);
    org.jfree.data.UnknownKeyException var42 = new org.jfree.data.UnknownKeyException("");
    java.lang.Throwable[] var43 = var42.getSuppressed();
    java.lang.Throwable[] var44 = var42.getSuppressed();
    boolean var45 = var40.equals((java.lang.Object)var44);
    org.jfree.chart.util.RectangleInsets var46 = var40.getItemLabelPadding();
    java.awt.Graphics2D var47 = null;
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint(50.5d, 10.0d);
    double var51 = var50.getWidth();
    org.jfree.chart.util.Size2D var52 = var40.arrange(var47, var50);
    org.jfree.chart.util.RectangleEdge var53 = var40.getLegendItemGraphicEdge();
    boolean var54 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var53);
    org.jfree.chart.axis.CategoryLabelPosition var55 = var18.getLabelPosition(var53);
    var11.setCategoryLabelPositions(var18);
    var1.setCategoryLabelPositions(var18);
    var1.setTickMarkOutsideLength(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 50.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test99"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
    double var42 = var41.getLeft();
    var38.setFixedRangeAxisSpace(var41);
    org.jfree.chart.axis.AxisSpace var44 = new org.jfree.chart.axis.AxisSpace();
    double var45 = var44.getLeft();
    var38.setFixedRangeAxisSpace(var44);
    var38.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.Layer var50 = null;
    java.util.Collection var51 = var38.getDomainMarkers(100, var50);
    org.jfree.chart.util.RectangleInsets var52 = var38.getInsets();
    var38.setRangeCrosshairValue(3.0d);
    org.jfree.chart.util.RectangleEdge var55 = var38.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test100"); }
// 
// 
//     java.text.AttributedString var0 = null;
//     java.awt.Shape var4 = null;
//     org.jfree.chart.block.ColumnArrangement var5 = new org.jfree.chart.block.ColumnArrangement();
//     var5.clear();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var9 = var8.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var11 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var13 = var11.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var16 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var19 = var16.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
//     org.jfree.chart.plot.Plot var22 = var21.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var23 = null;
//     var21.axisChanged(var23);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", var19, (org.jfree.chart.plot.Plot)var21, true);
//     boolean var27 = var11.equals((java.lang.Object)var19);
//     var11.validateObject();
//     org.jfree.data.Range var29 = var8.findRangeBounds((org.jfree.data.category.CategoryDataset)var11);
//     java.awt.Stroke var31 = var8.lookupSeriesStroke(10);
//     boolean var32 = var5.equals((java.lang.Object)var31);
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var33 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     java.awt.Paint var34 = var33.getArtifactPaint();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem(var0, "November", "November", "ItemLabelAnchor.OUTSIDE6", var4, var31, var34);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test101"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("");
    java.lang.Comparable var2 = var1.getKey();
    boolean var3 = var1.getNotify();
    java.lang.String[] var5 = new java.lang.String[] { "org.jfree.data.UnknownKeyException: org.jfree.chart.event.RendererChangeEvent[source=false]"};
    java.lang.Number[][] var6 = null;
    java.lang.Number[] var7 = null;
    java.lang.Number[][] var8 = new java.lang.Number[][] { var7};
    org.jfree.data.category.DefaultIntervalCategoryDataset var9 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var5, var6, var8);
    var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var9);
    java.util.List var11 = var9.getRowKeys();
    java.util.List var12 = var9.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setEndValue(12, (java.lang.Comparable)15, (java.lang.Number)(byte)10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test102"); }


    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var6 = var5.isTickMarksVisible();
    java.awt.Shape var7 = var5.getDownArrow();
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, 100.0d, 0.2d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var11.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var15 = var11.getBaseLinesVisible();
    java.lang.Boolean var17 = var11.getSeriesVisibleInLegend(10);
    java.awt.Paint var18 = var11.getBaseItemLabelPaint();
    java.awt.Color var21 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var22 = null;
    float[] var23 = var21.getRGBColorComponents(var22);
    var11.setBaseItemLabelPaint((java.awt.Paint)var21);
    int var25 = var21.getGreen();
    java.lang.String var26 = var21.toString();
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("hi!", "ThreadContext", "Pie Plot", "Range[1.0,100.0]", var10, (java.awt.Paint)var21);
    org.jfree.chart.util.GradientPaintTransformer var28 = var27.getFillPaintTransformer();
    java.lang.String var29 = var27.getDescription();
    java.awt.Shape var30 = var27.getLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "java.awt.Color[r=0,g=0,b=10]"+ "'", var26.equals("java.awt.Color[r=0,g=0,b=10]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "ThreadContext"+ "'", var29.equals("ThreadContext"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test103"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    var3.configure();
    org.jfree.chart.util.RectangleInsets var5 = var3.getLabelInsets();
    var1.setAxisOffset(var5);
    org.jfree.chart.plot.CategoryMarker var8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var9 = var8.getOutlineStroke();
    var1.addDomainMarker((org.jfree.chart.plot.Marker)var8);
    java.awt.geom.Point2D var11 = var1.getQuadrantOrigin();
    org.jfree.chart.plot.DatasetRenderingOrder var12 = var1.getDatasetRenderingOrder();
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
    var17.configure();
    org.jfree.chart.util.RectangleInsets var19 = var17.getLabelInsets();
    var15.setAxisOffset(var19);
    org.jfree.chart.renderer.category.StackedAreaRenderer var22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var23 = var22.getEndType();
    java.awt.Stroke var26 = var22.getItemStroke(0, 0);
    var15.setRangeZeroBaselineStroke(var26);
    org.jfree.chart.util.Layer var28 = null;
    java.util.Collection var29 = var15.getDomainMarkers(var28);
    org.jfree.chart.util.RectangleInsets var30 = var15.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var32 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var33 = var32.getEndType();
    java.awt.Stroke var36 = var32.getItemStroke(0, 0);
    var15.setDomainZeroBaselineStroke(var36);
    org.jfree.chart.util.RectangleEdge var39 = var15.getDomainAxisEdge(1);
    org.jfree.data.xy.XYDataset var40 = null;
    var15.setDataset(var40);
    var15.setRangeCrosshairValue(1.0d);
    org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var46 = var45.isTickMarksVisible();
    org.jfree.chart.axis.NumberTickUnit var47 = var45.getTickUnit();
    int var48 = var15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var45);
    java.awt.geom.Point2D var49 = var15.getQuadrantOrigin();
    var1.zoomRangeAxes(2.0d, var14, var49);
    java.awt.Font var51 = var1.getNoDataMessageFont();
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var52 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    org.jfree.data.general.PieDataset var53 = null;
    org.jfree.chart.plot.RingPlot var54 = new org.jfree.chart.plot.RingPlot(var53);
    org.jfree.chart.plot.Plot var55 = var54.getRootPlot();
    org.jfree.chart.util.RectangleInsets var56 = var54.getInsets();
    java.awt.Stroke var57 = var54.getLabelOutlineStroke();
    java.awt.Paint var58 = var54.getLabelShadowPaint();
    boolean var59 = var52.equals((java.lang.Object)var54);
    org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart("November", var51, (org.jfree.chart.plot.Plot)var54, false);
    var61.fireChartChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test104"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    java.awt.Paint var1 = var0.getArtifactPaint();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    var4.configure();
    org.jfree.chart.util.RectangleInsets var6 = var4.getLabelInsets();
    var2.setAxisOffset(var6);
    org.jfree.chart.renderer.category.StackedAreaRenderer var9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var10 = var9.getEndType();
    java.awt.Stroke var13 = var9.getItemStroke(0, 0);
    var2.setRangeZeroBaselineStroke(var13);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var2.getDomainMarkers(var15);
    var2.setForegroundAlpha(100.0f);
    var2.setRangeCrosshairVisible(true);
    boolean var21 = var2.isRangeZoomable();
    org.jfree.chart.util.RectangleEdge var23 = var2.getDomainAxisEdge(1);
    boolean var24 = var0.hasListener((java.util.EventListener)var2);
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    var26.configure();
    org.jfree.chart.axis.NumberTickUnit var28 = var26.getTickUnit();
    var2.setRangeAxis((org.jfree.chart.axis.ValueAxis)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test105"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var2 = var1.getEndType();
    java.awt.Stroke var5 = var1.getItemStroke(0, 0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var7 = null;
    var1.setSeriesItemLabelGenerator(100, var7, true);
    boolean var10 = var1.getRenderAsPercentages();
    org.jfree.chart.renderer.category.StackedAreaRenderer var12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var13 = var12.getEndType();
    java.lang.String var14 = var13.toString();
    var1.setEndType(var13);
    boolean var18 = var1.getItemVisible(4, 10);
    var1.setRenderAsPercentages(false);
    org.jfree.chart.renderer.category.StackedAreaRenderer var22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var23 = var22.getEndType();
    java.awt.Stroke var26 = var22.getItemStroke(0, 0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var28 = null;
    var22.setSeriesItemLabelGenerator(100, var28, true);
    boolean var31 = var22.getRenderAsPercentages();
    org.jfree.chart.renderer.category.StackedAreaRenderer var33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var34 = var33.getEndType();
    java.lang.String var35 = var34.toString();
    var22.setEndType(var34);
    java.lang.String var37 = var34.toString();
    java.lang.String var38 = var34.toString();
    var1.setEndType(var34);
    org.jfree.chart.renderer.category.StackedAreaRenderer var42 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var45 = var42.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var46 = null;
    org.jfree.chart.plot.RingPlot var47 = new org.jfree.chart.plot.RingPlot(var46);
    org.jfree.chart.plot.Plot var48 = var47.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var49 = null;
    var47.axisChanged(var49);
    org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart("hi!", var45, (org.jfree.chart.plot.Plot)var47, true);
    java.awt.Paint var53 = var47.getBackgroundPaint();
    java.awt.Paint var54 = var47.getLabelOutlinePaint();
    var47.setOuterSeparatorExtension(10.0d);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var58 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var60 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var58, (java.lang.Comparable)"");
    org.jfree.data.category.CategoryDataset var61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"hi!", (org.jfree.data.KeyedValues)var60);
    org.jfree.data.general.PieDataset var64 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var60, (java.lang.Comparable)10.0f, 0.35d);
    var47.setDataset(var64);
    double var66 = var47.getMinimumArcAngleToDraw();
    boolean var67 = var34.equals((java.lang.Object)var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AreaRendererEndType.TAPER"+ "'", var14.equals("AreaRendererEndType.TAPER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AreaRendererEndType.TAPER"+ "'", var35.equals("AreaRendererEndType.TAPER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "AreaRendererEndType.TAPER"+ "'", var37.equals("AreaRendererEndType.TAPER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "AreaRendererEndType.TAPER"+ "'", var38.equals("AreaRendererEndType.TAPER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test106"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 0.0f, (-1.0f), var4);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test107"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.awt.Paint var2 = var0.getPaint(2);
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var7 = var4.getLegendItem((-1), 100);
//     var4.setBaseShapesFilled(false);
//     java.awt.Paint var11 = var4.getSeriesOutlinePaint((-1));
//     java.awt.Paint var13 = var4.lookupSeriesOutlinePaint(0);
//     var3.setLabelPaint(var13);
//     boolean var15 = var3.isNegativeArrowVisible();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var17.getBaseNegativeItemLabelPosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var20 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var22 = var20.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var28 = var25.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     org.jfree.chart.plot.Plot var31 = var30.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var32 = null;
//     var30.axisChanged(var32);
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("hi!", var28, (org.jfree.chart.plot.Plot)var30, true);
//     boolean var36 = var20.equals((java.lang.Object)var28);
//     var20.validateObject();
//     org.jfree.data.Range var38 = var17.findRangeBounds((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.data.general.DatasetChangeEvent var39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var15, (org.jfree.data.general.Dataset)var20);
//     org.jfree.data.Range var40 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var20);
//     java.lang.Number var43 = var20.getQ1Value((java.lang.Comparable)0L, (java.lang.Comparable)"");
//     boolean var44 = var0.equals((java.lang.Object)"");
//     java.awt.Paint var46 = var0.getPaint((-1));
//     java.lang.Object var47 = var0.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var49.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var53 = var49.getBaseLinesVisible();
//     java.lang.Boolean var55 = var49.getSeriesVisibleInLegend(10);
//     java.awt.Paint var56 = var49.getBaseItemLabelPaint();
//     java.awt.Color var59 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var60 = null;
//     float[] var61 = var59.getRGBColorComponents(var60);
//     var49.setBaseItemLabelPaint((java.awt.Paint)var59);
//     java.awt.Color var63 = var59.brighter();
//     org.jfree.chart.block.BlockBorder var64 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var59);
//     var0.setPaint(5, (java.awt.Paint)var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test108"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.gantt.Task var3 = new org.jfree.data.gantt.Task("ThreadContext", (org.jfree.data.time.TimePeriod)var2);
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     var4.setDomainCrosshairValue(0.05d);
//     java.awt.Paint var7 = var4.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.25d);
//     double var12 = var11.getEndValue();
//     var11.setStartValue(0.2d);
//     org.jfree.chart.util.Layer var15 = null;
//     var4.addRangeMarker(0, (org.jfree.chart.plot.Marker)var11, var15);
//     boolean var17 = var3.equals((java.lang.Object)var4);
//     boolean var18 = var0.equals((java.lang.Object)var17);
//     org.jfree.chart.labels.ItemLabelPosition var19 = new org.jfree.chart.labels.ItemLabelPosition();
//     var0.setPositiveItemLabelPositionFallback(var19);
//     org.jfree.chart.labels.ItemLabelAnchor var21 = var19.getItemLabelAnchor();
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var24.setUpperMargin(0.0d);
//     int var27 = var24.getMaximumCategoryLabelLines();
//     java.lang.Object var28 = var24.clone();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var33 = var30.getLegendItem((-1), 100);
//     var30.setBaseShapesFilled(false);
//     java.awt.Paint var37 = var30.getSeriesOutlinePaint((-1));
//     java.awt.Paint var39 = var30.lookupSeriesOutlinePaint(0);
//     var29.setLabelPaint(var39);
//     double var41 = var29.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var45 = var42.getLegendItem(2, 0);
//     double var46 = var42.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var49 = var42.getPositiveItemLabelPosition(2, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var53 = var50.getLegendItem((-1), 100);
//     var50.setBaseShapesFilled(false);
//     java.awt.Paint var58 = var50.getItemOutlinePaint(10, 1);
//     var42.setErrorIndicatorPaint(var58);
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var22, var24, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.renderer.category.CategoryItemRenderer)var42);
//     var60.setRangeCrosshairValue(50.5d);
//     org.jfree.chart.axis.CategoryAxis var64 = var60.getDomainAxis(0);
//     var60.setDrawSharedDomainAxis(true);
//     org.jfree.chart.plot.PlotRenderingInfo var69 = null;
//     org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var72 = new org.jfree.chart.axis.NumberAxis3D("");
//     var72.configure();
//     org.jfree.chart.util.RectangleInsets var74 = var72.getLabelInsets();
//     var70.setAxisOffset(var74);
//     org.jfree.chart.plot.CategoryMarker var77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Stroke var78 = var77.getOutlineStroke();
//     var70.addDomainMarker((org.jfree.chart.plot.Marker)var77);
//     java.awt.geom.Point2D var80 = var70.getQuadrantOrigin();
//     var60.zoomRangeAxes(0.0d, 90.0d, var69, var80);
//     java.awt.Stroke var82 = var60.getRangeGridlineStroke();
//     org.jfree.chart.axis.CategoryAxis var84 = var60.getDomainAxisForDataset(10);
//     org.jfree.chart.plot.PlotOrientation var85 = var60.getOrientation();
//     var60.setRangeCrosshairValue(2.0d, true);
//     org.jfree.chart.renderer.category.AreaRenderer var89 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.LegendItem var92 = var89.getLegendItem(15, 1);
//     var60.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var89);
//     boolean var94 = var19.equals((java.lang.Object)var60);
//     
//     // Checks the contract:  equals-hashcode on var19 and var49
//     assertTrue("Contract failed: equals-hashcode on var19 and var49", var19.equals(var49) ? var19.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var19
//     assertTrue("Contract failed: equals-hashcode on var49 and var19", var49.equals(var19) ? var49.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test109"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(2.0d, 100.0d);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = var2.getSeriesCreateEntities(156);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test110"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, var1);
//     int var3 = var2.getMonth();
//     int var4 = var2.getMonth();
//     long var5 = var2.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 24178L);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test111"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var1.getColumnCount();
    int var3 = var1.getRowCount();
    int var5 = var1.getColumnIndex((java.lang.Comparable)(byte)0);
    java.lang.Object var6 = var1.clone();
    var1.clear();
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var9 = var8.previous();
    org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)var8);
    org.jfree.data.time.RegularTimePeriod var11 = var8.previous();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(100, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test112"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     int var2 = var0.getIndex((java.lang.Comparable)0.25d);
//     int var4 = var0.getIndex((java.lang.Comparable)(byte)10);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(10, var6);
//     int var8 = var0.getIndex((java.lang.Comparable)var7);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var13 = var10.getLegendItem((-1), 100);
//     var10.setBaseShapesFilled(false);
//     java.awt.Paint var17 = var10.getSeriesOutlinePaint((-1));
//     java.awt.Paint var19 = var10.lookupSeriesOutlinePaint(0);
//     var9.setLabelPaint(var19);
//     boolean var21 = var9.isNegativeArrowVisible();
//     org.jfree.data.Range var24 = new org.jfree.data.Range(1.0d, 100.0d);
//     java.lang.String var25 = var24.toString();
//     org.jfree.data.Range var27 = org.jfree.data.Range.shift(var24, 0.0d);
//     var9.setRange(var27);
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     long var30 = var29.getSerialIndex();
//     java.util.Date var31 = var29.getEnd();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     long var33 = var32.getSerialIndex();
//     java.util.Date var34 = var32.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var35 = new org.jfree.data.time.SimpleTimePeriod(var31, var34);
//     var9.setMaximumDate(var31);
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month();
//     long var38 = var37.getSerialIndex();
//     java.util.Date var39 = var37.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var40 = new org.jfree.data.time.SimpleTimePeriod(var31, var39);
//     int var41 = var0.getIndex((java.lang.Comparable)var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "Range[1.0,100.0]"+ "'", var25.equals("Range[1.0,100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == (-1));
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test113"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var4 = var1.getLegendItem((-1), 100);
//     var1.setBaseShapesFilled(false);
//     java.awt.Paint var8 = var1.getSeriesOutlinePaint((-1));
//     java.awt.Paint var10 = var1.lookupSeriesOutlinePaint(0);
//     var0.setLabelPaint(var10);
//     boolean var12 = var0.isNegativeArrowVisible();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var15 = var14.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getBaseNegativeItemLabelPosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var19 = var17.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var25 = var22.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot(var26);
//     org.jfree.chart.plot.Plot var28 = var27.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var29 = null;
//     var27.axisChanged(var29);
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("hi!", var25, (org.jfree.chart.plot.Plot)var27, true);
//     boolean var33 = var17.equals((java.lang.Object)var25);
//     var17.validateObject();
//     org.jfree.data.Range var35 = var14.findRangeBounds((org.jfree.data.category.CategoryDataset)var17);
//     org.jfree.data.general.DatasetChangeEvent var36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var12, (org.jfree.data.general.Dataset)var17);
//     org.jfree.data.Range var37 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var17);
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var40.setUpperMargin(0.0d);
//     int var43 = var40.getMaximumCategoryLabelLines();
//     java.lang.Object var44 = var40.clone();
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var49 = var46.getLegendItem((-1), 100);
//     var46.setBaseShapesFilled(false);
//     java.awt.Paint var53 = var46.getSeriesOutlinePaint((-1));
//     java.awt.Paint var55 = var46.lookupSeriesOutlinePaint(0);
//     var45.setLabelPaint(var55);
//     double var57 = var45.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var58 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var61 = var58.getLegendItem(2, 0);
//     double var62 = var58.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var65 = var58.getPositiveItemLabelPosition(2, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var69 = var66.getLegendItem((-1), 100);
//     var66.setBaseShapesFilled(false);
//     java.awt.Paint var74 = var66.getItemOutlinePaint(10, 1);
//     var58.setErrorIndicatorPaint(var74);
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot(var38, var40, (org.jfree.chart.axis.ValueAxis)var45, (org.jfree.chart.renderer.category.CategoryItemRenderer)var58);
//     var76.setRangeCrosshairValue(50.5d);
//     boolean var79 = var17.hasListener((java.util.EventListener)var76);
//     var76.mapDatasetToRangeAxis(2, (-1));
//     var76.setAnchorValue(90.0d);
//     org.jfree.chart.util.Layer var86 = null;
//     java.util.Collection var87 = var76.getDomainMarkers(0, var86);
//     java.awt.Paint var88 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var76.setDomainGridlinePaint(var88);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var87);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test114"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test115"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var3 = var2.getTickLabelPaint();
    java.awt.Shape var4 = var2.getDownArrow();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    var6.configure();
    org.jfree.chart.axis.NumberTickUnit var8 = var6.getTickUnit();
    var2.setTickUnit(var8);
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    var12.configure();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    var10.setAxisOffset(var14);
    org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
    java.awt.Stroke var21 = var17.getItemStroke(0, 0);
    var10.setRangeZeroBaselineStroke(var21);
    org.jfree.chart.util.Layer var23 = null;
    java.util.Collection var24 = var10.getDomainMarkers(var23);
    org.jfree.chart.util.RectangleInsets var25 = var10.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var27 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var28 = var27.getEndType();
    java.awt.Stroke var31 = var27.getItemStroke(0, 0);
    var10.setDomainZeroBaselineStroke(var31);
    org.jfree.chart.util.RectangleEdge var33 = var10.getDomainAxisEdge();
    var0.add((org.jfree.chart.axis.Axis)var2, var33);
    double var35 = var2.getFixedAutoRange();
    var2.setAutoRangeStickyZero(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test116"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var2 = var1.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getBaseNegativeItemLabelPosition();
    var1.setAutoPopulateSeriesShape(false);
    boolean var6 = var1.getAutoPopulateSeriesShape();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var10 = var7.getLegendItem(2, 0);
    double var11 = var7.getBase();
    org.jfree.chart.labels.ItemLabelPosition var14 = var7.getPositiveItemLabelPosition(2, (-1));
    double var15 = var7.getMaximumBarWidth();
    double var16 = var7.getBase();
    boolean var17 = var7.getIncludeBaseInRange();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
    java.awt.Paint var21 = var20.getErrorIndicatorPaint();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var22 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    var20.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var22);
    var7.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var22);
    java.lang.Object var25 = var22.clone();
    var1.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var22);
    var1.setAutoPopulateSeriesFillPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test117"); }
// 
// 
//     org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.gantt.Task var3 = new org.jfree.data.gantt.Task("ThreadContext", (org.jfree.data.time.TimePeriod)var2);
//     var3.setDescription("poly");
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     long var7 = var6.getSerialIndex();
//     java.util.Date var8 = var6.getEnd();
//     var3.setDuration((org.jfree.data.time.TimePeriod)var6);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var14 = var11.getLegendItem((-1), 100);
//     var11.setBaseShapesFilled(false);
//     java.awt.Paint var18 = var11.getSeriesOutlinePaint((-1));
//     java.awt.Paint var20 = var11.lookupSeriesOutlinePaint(0);
//     var10.setLabelPaint(var20);
//     double var22 = var10.getFixedAutoRange();
//     var10.setNegativeArrowVisible(true);
//     java.text.DateFormat var27 = null;
//     org.jfree.chart.axis.DateTickUnit var28 = new org.jfree.chart.axis.DateTickUnit(2, 1, var27);
//     var10.setTickUnit(var28, true, false);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     var0.setObject((java.lang.Object)var3, (java.lang.Comparable)true, (java.lang.Comparable)var32);
//     org.jfree.data.time.Month var35 = new org.jfree.data.time.Month();
//     org.jfree.data.gantt.Task var36 = new org.jfree.data.gantt.Task("ThreadContext", (org.jfree.data.time.TimePeriod)var35);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     var37.setDomainCrosshairValue(0.05d);
//     java.awt.Paint var40 = var37.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var44 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.25d);
//     double var45 = var44.getEndValue();
//     var44.setStartValue(0.2d);
//     org.jfree.chart.util.Layer var48 = null;
//     var37.addRangeMarker(0, (org.jfree.chart.plot.Marker)var44, var48);
//     boolean var50 = var36.equals((java.lang.Object)var37);
//     var3.addSubtask(var36);
//     var36.setPercentComplete((java.lang.Double)1.0E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.25d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test118"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(50.5d, 10.0d);
    double var3 = var2.getWidth();
    double var4 = var2.getWidth();
    org.jfree.chart.block.RectangleConstraint var6 = var2.toFixedHeight(Double.NaN);
    org.jfree.chart.block.LengthConstraintType var7 = var6.getWidthConstraintType();
    org.jfree.chart.renderer.category.StackedAreaRenderer var10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var13 = var10.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
    org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var15.axisChanged(var17);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("hi!", var13, (org.jfree.chart.plot.Plot)var15, true);
    java.lang.Object var21 = var15.clone();
    org.jfree.chart.util.HorizontalAlignment var22 = null;
    org.jfree.chart.util.VerticalAlignment var23 = null;
    org.jfree.chart.block.FlowArrangement var26 = new org.jfree.chart.block.FlowArrangement(var22, var23, 100.0d, 10.0d);
    var26.clear();
    org.jfree.chart.block.Arrangement var28 = null;
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15, (org.jfree.chart.block.Arrangement)var26, var28);
    org.jfree.data.UnknownKeyException var31 = new org.jfree.data.UnknownKeyException("");
    java.lang.Throwable[] var32 = var31.getSuppressed();
    java.lang.Throwable[] var33 = var31.getSuppressed();
    boolean var34 = var29.equals((java.lang.Object)var33);
    org.jfree.chart.util.RectangleInsets var35 = var29.getItemLabelPadding();
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.block.RectangleConstraint var39 = new org.jfree.chart.block.RectangleConstraint(50.5d, 10.0d);
    double var40 = var39.getWidth();
    org.jfree.chart.util.Size2D var41 = var29.arrange(var36, var39);
    var41.setHeight(0.0d);
    org.jfree.chart.util.Size2D var44 = var6.calculateConstrainedSize(var41);
    java.lang.String var45 = var41.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 50.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 50.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 50.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var45.equals("Size2D[width=0.0, height=0.0]"));

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test119"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setTickMarkInsideLength(0.0f);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test120"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.Range var2 = var1.getDefaultAutoRange();
    org.jfree.data.Range var5 = new org.jfree.data.Range(1.0d, 100.0d);
    var1.setRangeWithMargins(var5);
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var7);
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    var10.configure();
    org.jfree.chart.axis.NumberTickUnit var12 = var10.getTickUnit();
    org.jfree.data.Range var13 = var10.getRange();
    var10.setLowerMargin(100.0d);
    double var16 = var10.getFixedAutoRange();
    org.jfree.chart.axis.MarkerAxisBand var17 = null;
    var10.setMarkerBand(var17);
    org.jfree.data.Range var19 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
    double var21 = var20.getLabelAngle();
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var26 = var23.getLegendItem((-1), 100);
    var23.setBaseShapesFilled(false);
    java.awt.Paint var30 = var23.getSeriesOutlinePaint((-1));
    java.awt.Paint var32 = var23.lookupSeriesOutlinePaint(0);
    var22.setLabelPaint(var32);
    org.jfree.chart.axis.DateTickMarkPosition var34 = var22.getTickMarkPosition();
    var20.setTickMarkPosition(var34);
    org.jfree.chart.renderer.category.StackedAreaRenderer var37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var38 = var37.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var39 = var37.getBaseNegativeItemLabelPosition();
    boolean var40 = var20.equals((java.lang.Object)var39);
    var8.setAxis((org.jfree.chart.axis.ValueAxis)var20);
    var8.setAngleGridlinesVisible(false);
    int var44 = var8.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test121"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    org.jfree.data.general.WaferMapDataset var3 = null;
    var1.setDataset(var3);
    org.jfree.data.general.WaferMapDataset var5 = null;
    var1.setDataset(var5);
    org.jfree.data.general.WaferMapDataset var7 = null;
    var1.setDataset(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test122"); }


    org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod((-1L), 10L);
    java.util.Date var3 = var2.getStart();
    java.util.Date var4 = var2.getEnd();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var11 = var10.isTickMarksVisible();
    java.awt.Shape var12 = var10.getDownArrow();
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 100.0d, 0.2d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var16.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var20 = var16.getBaseLinesVisible();
    java.lang.Boolean var22 = var16.getSeriesVisibleInLegend(10);
    java.awt.Paint var23 = var16.getBaseItemLabelPaint();
    java.awt.Color var26 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var27 = null;
    float[] var28 = var26.getRGBColorComponents(var27);
    var16.setBaseItemLabelPaint((java.awt.Paint)var26);
    int var30 = var26.getGreen();
    java.lang.String var31 = var26.toString();
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("hi!", "ThreadContext", "Pie Plot", "Range[1.0,100.0]", var15, (java.awt.Paint)var26);
    java.lang.Comparable var33 = var32.getSeriesKey();
    int var34 = var32.getSeriesIndex();
    boolean var35 = var32.isLineVisible();
    boolean var36 = var32.isShapeFilled();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var37 = var2.compareTo((java.lang.Object)var32);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "java.awt.Color[r=0,g=0,b=10]"+ "'", var31.equals("java.awt.Color[r=0,g=0,b=10]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test123"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
    java.awt.Stroke var11 = var7.getItemStroke(0, 0);
    var0.setRangeZeroBaselineStroke(var11);
    boolean var13 = var0.isRangeCrosshairVisible();
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.data.KeyToGroupMap var16 = new org.jfree.data.KeyToGroupMap();
    java.util.List var17 = var16.getGroups();
    java.util.List var18 = var16.getGroups();
    var0.drawRangeTickBands(var14, var15, var18);
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    java.awt.Shape var23 = var21.getDownArrow();
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
    var25.configure();
    org.jfree.chart.axis.NumberTickUnit var27 = var25.getTickUnit();
    var21.setTickUnit(var27);
    var21.setTickLabelsVisible(true);
    var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var21);
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = var0.getRenderer(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test124"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    java.lang.Object var4 = var2.clone();
    java.lang.Number var7 = null;
    java.util.List var13 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var14 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)0L, var7, (java.lang.Number)100.0f, (java.lang.Number)0L, (java.lang.Number)0, (java.lang.Number)(short)(-1), (java.lang.Number)1.0d, var13);
    boolean var15 = var2.equals((java.lang.Object)0);
    boolean var16 = var2.isAutoRange();
    java.awt.Font var17 = var2.getLabelFont();
    org.jfree.chart.plot.CategoryMarker var19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)1L);
    java.lang.Object var20 = var19.clone();
    java.awt.Paint var21 = var19.getOutlinePaint();
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("Size2D[width=50.5, height=10.0]", var17, var21);
    java.lang.Object var23 = var22.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test125"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(3.0d, 0.05d, 0.05d, 8.64E7d);
    org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
    double var6 = var5.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.0d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test126"); }


    org.jfree.chart.renderer.category.LevelRenderer var0 = new org.jfree.chart.renderer.category.LevelRenderer();
    double var1 = var0.getItemMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test127"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    int var3 = var1.getColumnIndex((java.lang.Comparable)'4');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test128"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    org.jfree.chart.urls.PieURLGenerator var13 = var7.getURLGenerator();
    org.jfree.chart.labels.PieSectionLabelGenerator var14 = var7.getLegendLabelToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test129"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.axis.CategoryAnchor var39 = var38.getDomainGridlinePosition();
    org.jfree.data.category.CategoryDataset var40 = var38.getDataset();
    org.jfree.chart.LegendItemCollection var41 = var38.getLegendItems();
    var38.clearDomainAxes();
    org.jfree.chart.util.SortOrder var43 = var38.getRowRenderingOrder();
    boolean var44 = var38.isDomainGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D("#ffff9c");
    boolean var47 = var46.isAxisLineVisible();
    var38.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var46);
    org.jfree.chart.event.AxisChangeEvent var49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var46);
    org.jfree.chart.JFreeChart var50 = var49.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test130"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)"");
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
    org.jfree.chart.plot.Plot var6 = var5.getRootPlot();
    var1.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var6);
    org.jfree.data.KeyToGroupMap var16 = new org.jfree.data.KeyToGroupMap();
    java.util.List var17 = var16.getGroups();
    org.jfree.data.statistics.BoxAndWhiskerItem var18 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)1.0d, (java.lang.Number)100.0f, (java.lang.Number)(short)1, (java.lang.Number)1.0f, (java.lang.Number)(byte)(-1), (java.lang.Number)(-1), (java.lang.Number)(byte)100, var17);
    var1.add(var18, (java.lang.Comparable)0.0f, (java.lang.Comparable)"hi!");
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)false);
    java.lang.Comparable var24 = var23.getSeriesKey();
    org.jfree.chart.block.BlockFrame var25 = var23.getFrame();
    org.jfree.data.general.Dataset var26 = var23.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + false+ "'", var24.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test131"); }
// 
// 
//     org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 10L);
//     java.util.Date var4 = var3.getStart();
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var9 = var6.getLegendItem((-1), 100);
//     var6.setBaseShapesFilled(false);
//     java.awt.Paint var13 = var6.getSeriesOutlinePaint((-1));
//     java.awt.Paint var15 = var6.lookupSeriesOutlinePaint(0);
//     var5.setLabelPaint(var15);
//     boolean var17 = var5.isNegativeArrowVisible();
//     org.jfree.data.Range var20 = new org.jfree.data.Range(1.0d, 100.0d);
//     java.lang.String var21 = var20.toString();
//     org.jfree.data.Range var23 = org.jfree.data.Range.shift(var20, 0.0d);
//     var5.setRange(var23);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     long var26 = var25.getSerialIndex();
//     java.util.Date var27 = var25.getEnd();
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month();
//     long var29 = var28.getSerialIndex();
//     java.util.Date var30 = var28.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var31 = new org.jfree.data.time.SimpleTimePeriod(var27, var30);
//     var5.setMaximumDate(var27);
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     long var34 = var33.getSerialIndex();
//     java.util.Date var35 = var33.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var36 = new org.jfree.data.time.SimpleTimePeriod(var27, var35);
//     org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var41 = var38.getLegendItem((-1), 100);
//     var38.setBaseShapesFilled(false);
//     java.awt.Paint var45 = var38.getSeriesOutlinePaint((-1));
//     java.awt.Paint var47 = var38.lookupSeriesOutlinePaint(0);
//     var37.setLabelPaint(var47);
//     boolean var49 = var37.isNegativeArrowVisible();
//     org.jfree.data.Range var52 = new org.jfree.data.Range(1.0d, 100.0d);
//     java.lang.String var53 = var52.toString();
//     org.jfree.data.Range var55 = org.jfree.data.Range.shift(var52, 0.0d);
//     var37.setRange(var55);
//     org.jfree.data.time.Month var57 = new org.jfree.data.time.Month();
//     long var58 = var57.getSerialIndex();
//     java.util.Date var59 = var57.getEnd();
//     org.jfree.data.time.Month var60 = new org.jfree.data.time.Month();
//     long var61 = var60.getSerialIndex();
//     java.util.Date var62 = var60.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var63 = new org.jfree.data.time.SimpleTimePeriod(var59, var62);
//     var37.setMaximumDate(var59);
//     org.jfree.data.time.SimpleTimePeriod var65 = new org.jfree.data.time.SimpleTimePeriod(var35, var59);
//     org.jfree.data.gantt.Task var66 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_RIGHT", var4, var59);
//     org.jfree.data.time.TimePeriod var67 = null;
//     var66.setDuration(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "Range[1.0,100.0]"+ "'", var21.equals("Range[1.0,100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var53 + "' != '" + "Range[1.0,100.0]"+ "'", var53.equals("Range[1.0,100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test132"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("org.jfree.data.UnknownKeyException: ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    java.awt.Paint var5 = null;
    var4.setRadiusGridlinePaint(var5);
    org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("Pie Plot");
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    double var12 = var11.getInteriorGap();
    org.jfree.chart.renderer.category.StackedAreaRenderer var15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var18 = var15.getItemLabelFont((-1), 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var19.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var23 = var19.getBaseLinesVisible();
    java.lang.Boolean var25 = var19.getSeriesVisibleInLegend(10);
    java.awt.Paint var26 = var19.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("", var18, var26);
    var11.setLabelFont(var18);
    var8.setTickLabelFont((java.lang.Comparable)1L, var18);
    var4.setAngleLabelFont(var18);
    java.awt.Paint var31 = null;
    var4.setAngleGridlinePaint(var31);
    org.jfree.chart.LegendItemCollection var33 = var4.getLegendItems();
    var4.setRadiusGridlinesVisible(false);
    java.lang.String var36 = var4.getPlotType();
    boolean var37 = var4.isAngleLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "Polar Plot"+ "'", var36.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test133"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var16 = var13.getLegendItem((-1), 100);
    var13.setBaseShapesFilled(false);
    java.awt.Paint var20 = var13.getSeriesOutlinePaint((-1));
    boolean var21 = var12.equals((java.lang.Object)var13);
    var12.setTitle("ThreadContext");
    var12.setBackgroundImageAlignment(4);
    var12.clearSubtitles();
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
    var29.configure();
    org.jfree.chart.util.RectangleInsets var31 = var29.getLabelInsets();
    var27.setAxisOffset(var31);
    org.jfree.chart.renderer.category.StackedAreaRenderer var34 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var35 = var34.getEndType();
    java.awt.Stroke var38 = var34.getItemStroke(0, 0);
    var27.setRangeZeroBaselineStroke(var38);
    org.jfree.chart.util.Layer var40 = null;
    java.util.Collection var41 = var27.getDomainMarkers(var40);
    org.jfree.chart.util.RectangleInsets var42 = var27.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var45 = var44.getEndType();
    java.awt.Stroke var48 = var44.getItemStroke(0, 0);
    var27.setDomainZeroBaselineStroke(var48);
    org.jfree.chart.util.RectangleEdge var51 = var27.getDomainAxisEdge(1);
    org.jfree.data.xy.XYDataset var52 = null;
    var27.setDataset(var52);
    var27.setRangeCrosshairValue(1.0d);
    org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var58 = var57.isTickMarksVisible();
    org.jfree.chart.axis.NumberTickUnit var59 = var57.getTickUnit();
    int var60 = var27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var57);
    java.awt.geom.Point2D var61 = var27.getQuadrantOrigin();
    org.jfree.chart.util.RectangleInsets var62 = var27.getInsets();
    var12.setPadding(var62);
    var12.removeLegend();
    java.awt.Paint var65 = var12.getBackgroundPaint();
    org.jfree.chart.plot.Plot var66 = var12.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test134"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 4.0d);
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var7 = var4.getLegendItem((-1), 100);
//     var4.setBaseShapesFilled(false);
//     java.awt.Paint var11 = var4.getSeriesOutlinePaint((-1));
//     java.awt.Paint var13 = var4.lookupSeriesOutlinePaint(0);
//     var3.setLabelPaint(var13);
//     boolean var15 = var3.isNegativeArrowVisible();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var17.getBaseNegativeItemLabelPosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var20 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var22 = var20.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var28 = var25.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     org.jfree.chart.plot.Plot var31 = var30.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var32 = null;
//     var30.axisChanged(var32);
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("hi!", var28, (org.jfree.chart.plot.Plot)var30, true);
//     boolean var36 = var20.equals((java.lang.Object)var28);
//     var20.validateObject();
//     org.jfree.data.Range var38 = var17.findRangeBounds((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.data.general.DatasetChangeEvent var39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var15, (org.jfree.data.general.Dataset)var20);
//     org.jfree.data.Range var40 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.chart.plot.MultiplePiePlot var41 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.data.Range var42 = var2.findRangeBounds((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var43.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var47 = var43.getBaseLinesVisible();
//     boolean var49 = var43.equals((java.lang.Object)100.0f);
//     boolean var50 = var2.equals((java.lang.Object)var49);
//     org.jfree.data.DefaultKeyedValues2D var52 = new org.jfree.data.DefaultKeyedValues2D(false);
//     var52.clear();
//     java.util.List var54 = var52.getColumnKeys();
//     boolean var55 = var2.equals((java.lang.Object)var54);
//     java.awt.Stroke var56 = var2.getBaseOutlineStroke();
//     var2.setAutoPopulateSeriesOutlineStroke(false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test135"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
//     var5.configure();
//     org.jfree.chart.util.RectangleInsets var7 = var5.getLabelInsets();
//     var3.setAxisOffset(var7);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var11 = var10.getEndType();
//     java.awt.Stroke var14 = var10.getItemStroke(0, 0);
//     var3.setRangeZeroBaselineStroke(var14);
//     org.jfree.chart.util.Layer var16 = null;
//     java.util.Collection var17 = var3.getDomainMarkers(var16);
//     var3.setForegroundAlpha(100.0f);
//     var3.setRangeCrosshairVisible(true);
//     boolean var22 = var3.isRangeZoomable();
//     org.jfree.chart.util.RectangleEdge var24 = var3.getDomainAxisEdge(1);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     java.awt.Paint var27 = var26.getBaseSectionPaint();
//     double var28 = var26.getLabelGap();
//     double var29 = var26.getInnerSeparatorExtension();
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
//     org.jfree.chart.plot.Plot var32 = var31.getRootPlot();
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
//     boolean var34 = var33.getAntiAlias();
//     java.awt.Stroke var35 = var33.getBorderStroke();
//     var26.setOutlineStroke(var35);
//     var3.setRangeGridlineStroke(var35);
//     java.awt.geom.Point2D var38 = var3.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var39 = new org.jfree.chart.plot.PlotState();
//     java.util.Map var40 = var39.getSharedAxisStates();
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D("");
//     var43.configure();
//     org.jfree.chart.util.RectangleInsets var45 = var43.getLabelInsets();
//     var41.setAxisOffset(var45);
//     org.jfree.chart.util.RectangleInsets var47 = var41.getAxisOffset();
//     boolean var48 = var41.isRangeCrosshairVisible();
//     org.jfree.chart.entity.EntityCollection var51 = null;
//     org.jfree.chart.ChartRenderingInfo var52 = new org.jfree.chart.ChartRenderingInfo(var51);
//     org.jfree.chart.plot.PlotRenderingInfo var53 = var52.getPlotInfo();
//     org.jfree.chart.renderer.category.CategoryItemRendererState var54 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var53);
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleAnchor var56 = null;
//     java.awt.geom.Point2D var57 = org.jfree.chart.util.RectangleAnchor.coordinates(var55, var56);
//     var41.zoomRangeAxes(10.0d, 10.0d, var53, var57);
//     var0.draw(var1, var2, var38, var39, var53);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test136"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.plot.CategoryMarker var7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var8 = var7.getOutlineStroke();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var7);
    java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
    org.jfree.chart.plot.DatasetRenderingOrder var11 = var0.getDatasetRenderingOrder();
    int var12 = var0.getDatasetCount();
    boolean var13 = var0.isDomainZeroBaselineVisible();
    java.awt.Stroke var14 = var0.getDomainCrosshairStroke();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var16, (java.lang.Comparable)"");
    org.jfree.data.category.CategoryDataset var19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"hi!", (org.jfree.data.KeyedValues)var18);
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var18);
    java.awt.Paint var21 = var20.getLabelLinkPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var25 = var22.getLegendItem((-1), 100);
    var22.setBaseShapesFilled(false);
    java.awt.Paint var30 = var22.getItemOutlinePaint(10, 1);
    boolean var31 = var22.getUseOutlinePaint();
    boolean var34 = var22.getItemShapeFilled(100, 10);
    java.awt.Stroke var35 = var22.getBaseStroke();
    var20.setLabelLinkStroke(var35);
    var0.setRangeZeroBaselineStroke(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test137"); }
// 
// 
//     org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.gantt.TaskSeries var2 = new org.jfree.data.gantt.TaskSeries("");
//     java.lang.Comparable var3 = var2.getKey();
//     org.jfree.data.gantt.Task var4 = null;
//     var2.remove(var4);
//     java.lang.Object var6 = var2.clone();
//     var2.removeAll();
//     var0.add(var2);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var13 = var10.getLegendItem((-1), 100);
//     var10.setBaseShapesFilled(false);
//     java.awt.Paint var17 = var10.getSeriesOutlinePaint((-1));
//     java.awt.Paint var19 = var10.lookupSeriesOutlinePaint(0);
//     var9.setLabelPaint(var19);
//     double var21 = var9.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var24 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var27 = var24.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
//     org.jfree.chart.plot.Plot var30 = var29.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var31 = null;
//     var29.axisChanged(var31);
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("hi!", var27, (org.jfree.chart.plot.Plot)var29, true);
//     java.awt.Paint var35 = var29.getBackgroundPaint();
//     java.awt.Paint var36 = var29.getLabelOutlinePaint();
//     var9.setTickMarkPaint(var36);
//     java.text.DateFormat var40 = null;
//     org.jfree.chart.axis.DateTickUnit var41 = new org.jfree.chart.axis.DateTickUnit(2, 1, var40);
//     var9.setTickUnit(var41, false, false);
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var46 = var45.getMaximumDate();
//     java.lang.String var47 = var41.dateToString(var46);
//     int var48 = var41.getCount();
//     double var49 = var41.getSize();
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month();
//     long var51 = var50.getSerialIndex();
//     java.util.Date var52 = var50.getEnd();
//     org.jfree.data.time.Month var53 = new org.jfree.data.time.Month();
//     long var54 = var53.getSerialIndex();
//     java.util.Date var55 = var53.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var56 = new org.jfree.data.time.SimpleTimePeriod(var52, var55);
//     java.lang.String var57 = var41.dateToString(var52);
//     org.jfree.chart.axis.NumberAxis3D var59 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var60 = var59.getTickLabelPaint();
//     java.awt.Shape var61 = var59.getDownArrow();
//     var59.setUpperMargin(0.2d);
//     org.jfree.chart.axis.NumberAxis3D var65 = new org.jfree.chart.axis.NumberAxis3D("");
//     var65.configure();
//     org.jfree.chart.axis.NumberTickUnit var67 = var65.getTickUnit();
//     org.jfree.chart.text.TextLine var68 = new org.jfree.chart.text.TextLine();
//     org.jfree.chart.text.TextFragment var70 = new org.jfree.chart.text.TextFragment("PlotOrientation.VERTICAL");
//     var68.addFragment(var70);
//     int var72 = var67.compareTo((java.lang.Object)var68);
//     var59.setTickUnit(var67);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var74 = var0.getStartValue((java.lang.Comparable)var52, (java.lang.Comparable)var67);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "12/31/69"+ "'", var47.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 8.64E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "12/31/14"+ "'", var57.equals("12/31/14"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == (-1));
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test138"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     var2.configure();
//     org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
//     var0.setAxisOffset(var4);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
//     java.awt.Stroke var11 = var7.getItemStroke(0, 0);
//     var0.setRangeZeroBaselineStroke(var11);
//     org.jfree.chart.util.Layer var13 = null;
//     java.util.Collection var14 = var0.getDomainMarkers(var13);
//     org.jfree.chart.util.RectangleInsets var15 = var0.getInsets();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
//     java.awt.Stroke var21 = var17.getItemStroke(0, 0);
//     var0.setDomainZeroBaselineStroke(var21);
//     org.jfree.chart.util.RectangleEdge var24 = var0.getDomainAxisEdge(1);
//     org.jfree.data.xy.XYDataset var25 = null;
//     var0.setDataset(var25);
//     var0.setRangeCrosshairValue(1.0d);
//     var0.setRangeCrosshairValue((-8.0d), true);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D("");
//     var34.configure();
//     org.jfree.chart.util.RectangleInsets var36 = var34.getLabelInsets();
//     var32.setAxisOffset(var36);
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var42 = var39.getLegendItem((-1), 100);
//     var39.setBaseShapesFilled(false);
//     java.awt.Paint var46 = var39.getSeriesOutlinePaint((-1));
//     java.awt.Paint var48 = var39.lookupSeriesOutlinePaint(0);
//     var38.setLabelPaint(var48);
//     boolean var50 = var38.isNegativeArrowVisible();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var52 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var53 = var52.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var54 = var52.getBaseNegativeItemLabelPosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var55 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var57 = var55.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var60 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var63 = var60.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.RingPlot var65 = new org.jfree.chart.plot.RingPlot(var64);
//     org.jfree.chart.plot.Plot var66 = var65.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var67 = null;
//     var65.axisChanged(var67);
//     org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart("hi!", var63, (org.jfree.chart.plot.Plot)var65, true);
//     boolean var71 = var55.equals((java.lang.Object)var63);
//     var55.validateObject();
//     org.jfree.data.Range var73 = var52.findRangeBounds((org.jfree.data.category.CategoryDataset)var55);
//     org.jfree.data.general.DatasetChangeEvent var74 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var50, (org.jfree.data.general.Dataset)var55);
//     var32.datasetChanged(var74);
//     org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var77 = new org.jfree.chart.LegendItemCollection();
//     int var78 = var77.getItemCount();
//     var76.setFixedLegendItems(var77);
//     org.jfree.chart.axis.AxisLocation var81 = var76.getRangeAxisLocation(10);
//     var32.setDomainAxisLocation(var81);
//     var0.setRangeAxisLocation(var81);
//     var0.clearRangeMarkers();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test139"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
    double var42 = var41.getLeft();
    var38.setFixedRangeAxisSpace(var41);
    org.jfree.chart.axis.AxisSpace var44 = new org.jfree.chart.axis.AxisSpace();
    double var45 = var44.getLeft();
    var38.setFixedRangeAxisSpace(var44);
    org.jfree.chart.axis.AxisCollection var48 = new org.jfree.chart.axis.AxisCollection();
    org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var51 = var50.getTickLabelPaint();
    java.awt.Shape var52 = var50.getDownArrow();
    org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D("");
    var54.configure();
    org.jfree.chart.axis.NumberTickUnit var56 = var54.getTickUnit();
    var50.setTickUnit(var56);
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D("");
    var60.configure();
    org.jfree.chart.util.RectangleInsets var62 = var60.getLabelInsets();
    var58.setAxisOffset(var62);
    org.jfree.chart.renderer.category.StackedAreaRenderer var65 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var66 = var65.getEndType();
    java.awt.Stroke var69 = var65.getItemStroke(0, 0);
    var58.setRangeZeroBaselineStroke(var69);
    org.jfree.chart.util.Layer var71 = null;
    java.util.Collection var72 = var58.getDomainMarkers(var71);
    org.jfree.chart.util.RectangleInsets var73 = var58.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var75 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var76 = var75.getEndType();
    java.awt.Stroke var79 = var75.getItemStroke(0, 0);
    var58.setDomainZeroBaselineStroke(var79);
    org.jfree.chart.util.RectangleEdge var81 = var58.getDomainAxisEdge();
    var48.add((org.jfree.chart.axis.Axis)var50, var81);
    org.jfree.chart.util.RectangleEdge var83 = org.jfree.chart.util.RectangleEdge.opposite(var81);
    var44.add(3.0d, var83);
    double var85 = var44.getTop();
    java.lang.Object var86 = var44.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test140"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var1 = var0.getLimit();
//     double var2 = var0.getLimit();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var3 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var3, (java.lang.Comparable)"");
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     var3.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
//     java.lang.Comparable var10 = null;
//     java.lang.Number var12 = var3.getMeanValue(var10, (java.lang.Comparable)100.0f);
//     var0.setDataset((org.jfree.data.category.CategoryDataset)var3);
//     org.jfree.data.general.DatasetGroup var14 = var3.getGroup();
//     double var16 = var3.getRangeLowerBound(true);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
//     var19.configure();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
//     var17.setAxisOffset(var21);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var24 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var25 = var24.getEndType();
//     java.awt.Stroke var28 = var24.getItemStroke(0, 0);
//     var17.setRangeZeroBaselineStroke(var28);
//     org.jfree.chart.util.Layer var30 = null;
//     java.util.Collection var31 = var17.getDomainMarkers(var30);
//     var17.setForegroundAlpha(100.0f);
//     boolean var34 = var3.hasListener((java.util.EventListener)var17);
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var39 = var36.getLegendItem((-1), 100);
//     var36.setBaseShapesFilled(false);
//     java.awt.Paint var43 = var36.getSeriesOutlinePaint((-1));
//     java.awt.Paint var45 = var36.lookupSeriesOutlinePaint(0);
//     var35.setLabelPaint(var45);
//     boolean var47 = var35.isNegativeArrowVisible();
//     org.jfree.data.Range var50 = new org.jfree.data.Range(1.0d, 100.0d);
//     java.lang.String var51 = var50.toString();
//     org.jfree.data.Range var53 = org.jfree.data.Range.shift(var50, 0.0d);
//     var35.setRange(var53);
//     var35.setInverted(false);
//     boolean var57 = var35.isNegativeArrowVisible();
//     org.jfree.chart.axis.TickUnitSource var58 = var35.getStandardTickUnits();
//     int var59 = var17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.chart.axis.AxisLocation var61 = var17.getRangeAxisLocation(15);
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot();
//     var62.setDomainCrosshairValue(0.05d);
//     java.awt.Paint var65 = var62.getDomainCrosshairPaint();
//     org.jfree.data.general.PieDataset var66 = null;
//     org.jfree.chart.plot.RingPlot var67 = new org.jfree.chart.plot.RingPlot(var66);
//     java.awt.Paint var68 = var67.getBaseSectionPaint();
//     boolean var69 = var67.isOutlineVisible();
//     java.awt.Color var73 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var74 = null;
//     float[] var75 = var73.getRGBColorComponents(var74);
//     var67.setSectionOutlinePaint((java.lang.Comparable)"", (java.awt.Paint)var73);
//     java.awt.Color var79 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var80 = null;
//     float[] var81 = var79.getRGBColorComponents(var80);
//     float[] var82 = var73.getRGBComponents(var80);
//     var62.setOutlinePaint((java.awt.Paint)var73);
//     int var84 = var73.getRed();
//     java.lang.String var85 = var73.toString();
//     int var86 = var73.getRGB();
//     var17.setBackgroundPaint((java.awt.Paint)var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var51 + "' != '" + "Range[1.0,100.0]"+ "'", var51.equals("Range[1.0,100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var85 + "' != '" + "java.awt.Color[r=0,g=0,b=10]"+ "'", var85.equals("java.awt.Color[r=0,g=0,b=10]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == (-16777206));
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test141"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var3 = var0.getLegendItem(2, 0);
//     double var4 = var0.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPosition(2, (-1));
//     double var8 = var0.getMaximumBarWidth();
//     double var9 = var0.getBase();
//     java.awt.Paint var10 = var0.getErrorIndicatorPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var12.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var16 = var12.getBaseLinesVisible();
//     boolean var18 = var12.equals((java.lang.Object)100.0f);
//     java.awt.Paint var20 = var12.lookupSeriesFillPaint(0);
//     org.jfree.chart.labels.StandardCategoryToolTipGenerator var21 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
//     var12.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator)var21, false);
//     var0.setSeriesToolTipGenerator(4, (org.jfree.chart.labels.CategoryToolTipGenerator)var21);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var25 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var27 = var25.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var30 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var33 = var30.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.RingPlot var35 = new org.jfree.chart.plot.RingPlot(var34);
//     org.jfree.chart.plot.Plot var36 = var35.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var37 = null;
//     var35.axisChanged(var37);
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", var33, (org.jfree.chart.plot.Plot)var35, true);
//     boolean var41 = var25.equals((java.lang.Object)var33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var43 = var21.generateRowLabel((org.jfree.data.category.CategoryDataset)var25, 15);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test142"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var3.setUpperMargin(0.0d);
    int var6 = var3.getMaximumCategoryLabelLines();
    java.lang.Object var7 = var3.clone();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var12 = var9.getLegendItem((-1), 100);
    var9.setBaseShapesFilled(false);
    java.awt.Paint var16 = var9.getSeriesOutlinePaint((-1));
    java.awt.Paint var18 = var9.lookupSeriesOutlinePaint(0);
    var8.setLabelPaint(var18);
    double var20 = var8.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var24 = var21.getLegendItem(2, 0);
    double var25 = var21.getBase();
    org.jfree.chart.labels.ItemLabelPosition var28 = var21.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var32 = var29.getLegendItem((-1), 100);
    var29.setBaseShapesFilled(false);
    java.awt.Paint var37 = var29.getItemOutlinePaint(10, 1);
    var21.setErrorIndicatorPaint(var37);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    var39.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.AxisSpace var42 = new org.jfree.chart.axis.AxisSpace();
    double var43 = var42.getLeft();
    var39.setFixedRangeAxisSpace(var42);
    org.jfree.chart.axis.AxisSpace var45 = new org.jfree.chart.axis.AxisSpace();
    double var46 = var45.getLeft();
    var39.setFixedRangeAxisSpace(var45);
    var39.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.CategoryAxis var50 = var39.getDomainAxis();
    java.awt.Paint var51 = var50.getTickMarkPaint();
    org.jfree.chart.axis.ValueAxis var52 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var53 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var56 = var53.getLegendItem((-1), 100);
    java.awt.Stroke var57 = var53.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var0, var50, var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var53);
    org.jfree.chart.LegendItemCollection var59 = var58.getFixedLegendItems();
    org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var63 = new org.jfree.chart.axis.NumberAxis3D("");
    var63.configure();
    org.jfree.chart.util.RectangleInsets var65 = var63.getLabelInsets();
    var61.setAxisOffset(var65);
    org.jfree.chart.renderer.category.StackedAreaRenderer var68 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var69 = var68.getEndType();
    java.awt.Stroke var72 = var68.getItemStroke(0, 0);
    var61.setRangeZeroBaselineStroke(var72);
    boolean var74 = var61.isRangeCrosshairVisible();
    java.awt.Graphics2D var75 = null;
    java.awt.geom.Rectangle2D var76 = null;
    org.jfree.data.KeyToGroupMap var77 = new org.jfree.data.KeyToGroupMap();
    java.util.List var78 = var77.getGroups();
    java.util.List var79 = var77.getGroups();
    var61.drawRangeTickBands(var75, var76, var79);
    org.jfree.chart.axis.NumberAxis3D var82 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var83 = var82.getTickLabelPaint();
    java.awt.Shape var84 = var82.getDownArrow();
    org.jfree.chart.axis.NumberAxis3D var86 = new org.jfree.chart.axis.NumberAxis3D("");
    var86.configure();
    org.jfree.chart.axis.NumberTickUnit var88 = var86.getTickUnit();
    var82.setTickUnit(var88);
    var82.setTickLabelsVisible(true);
    var61.setDomainAxis((org.jfree.chart.axis.ValueAxis)var82);
    org.jfree.chart.axis.AxisLocation var94 = var61.getDomainAxisLocation(0);
    var58.setDomainAxisLocation(4, var94);
    var58.setRangeCrosshairVisible(false);
    org.jfree.chart.util.SortOrder var98 = var58.getColumnRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test143"); }


    java.awt.Color var3 = java.awt.Color.getColor("org.jfree.data.UnknownKeyException: ", 12);
    java.awt.Color var4 = java.awt.Color.getColor("org.jfree.data.UnknownKeyException: org.jfree.chart.event.RendererChangeEvent[source=false]", var3);
    int var5 = var3.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test144"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    java.awt.Paint var2 = var0.getRangeTickBandPaint();
    java.lang.Object var3 = var0.clone();
    org.jfree.chart.util.Layer var4 = null;
    java.util.Collection var5 = var0.getRangeMarkers(var4);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    java.awt.Paint var8 = var7.getBaseSectionPaint();
    double var9 = var7.getMaximumLabelWidth();
    org.jfree.chart.event.PlotChangeEvent var10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var7);
    var0.notifyListeners(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test145"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
    double var42 = var41.getLeft();
    var38.setFixedRangeAxisSpace(var41);
    boolean var44 = var38.isRangeCrosshairLockedOnData();
    org.jfree.chart.annotations.CategoryAnnotation var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var46 = var38.removeAnnotation(var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test146"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(86.0d, (-11.95d), 1.0d, 1.0E-8d);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test147"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLabelAngle();
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, Double.NaN, Double.NaN);
//     var0.setDownArrow(var4);
//     java.text.DateFormat var9 = var0.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
//     double var11 = var10.getLabelAngle();
//     var10.setTickLabelsVisible(false);
//     var10.setTickMarkOutsideLength(1.0f);
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var20 = var17.getLegendItem((-1), 100);
//     var17.setBaseShapesFilled(false);
//     java.awt.Paint var24 = var17.getSeriesOutlinePaint((-1));
//     java.awt.Paint var26 = var17.lookupSeriesOutlinePaint(0);
//     var16.setLabelPaint(var26);
//     double var28 = var16.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var31 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var34 = var31.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     org.jfree.chart.plot.Plot var37 = var36.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var38 = null;
//     var36.axisChanged(var38);
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("hi!", var34, (org.jfree.chart.plot.Plot)var36, true);
//     java.awt.Paint var42 = var36.getBackgroundPaint();
//     java.awt.Paint var43 = var36.getLabelOutlinePaint();
//     var16.setTickMarkPaint(var43);
//     java.text.DateFormat var47 = null;
//     org.jfree.chart.axis.DateTickUnit var48 = new org.jfree.chart.axis.DateTickUnit(2, 1, var47);
//     var16.setTickUnit(var48, false, false);
//     org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var53 = var52.getMaximumDate();
//     java.lang.String var54 = var48.dateToString(var53);
//     int var55 = var48.getUnit();
//     java.util.Date var56 = var10.calculateHighestVisibleTickValue(var48);
//     org.jfree.data.time.Year var57 = new org.jfree.data.time.Year();
//     long var58 = var57.getSerialIndex();
//     java.util.Date var59 = var57.getEnd();
//     var0.setRange(var56, var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "12/31/69"+ "'", var54.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test148"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.chart.renderer.category.StackedAreaRenderer var5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var8 = var5.getItemLabelFont((-1), 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var13 = var9.getBaseLinesVisible();
    java.lang.Boolean var15 = var9.getSeriesVisibleInLegend(10);
    java.awt.Paint var16 = var9.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("", var8, var16);
    var1.setLabelFont(var8);
    var1.setNoDataMessage("Pie Plot");
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var27 = var26.isTickMarksVisible();
    java.awt.Shape var28 = var26.getDownArrow();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var28, 100.0d, 0.2d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var32.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var36 = var32.getBaseLinesVisible();
    java.lang.Boolean var38 = var32.getSeriesVisibleInLegend(10);
    java.awt.Paint var39 = var32.getBaseItemLabelPaint();
    java.awt.Color var42 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var43 = null;
    float[] var44 = var42.getRGBColorComponents(var43);
    var32.setBaseItemLabelPaint((java.awt.Paint)var42);
    int var46 = var42.getGreen();
    java.lang.String var47 = var42.toString();
    org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem("hi!", "ThreadContext", "Pie Plot", "Range[1.0,100.0]", var31, (java.awt.Paint)var42);
    java.lang.Comparable var49 = var48.getSeriesKey();
    int var50 = var48.getSeriesIndex();
    boolean var51 = var48.isLineVisible();
    boolean var52 = var1.equals((java.lang.Object)var51);
    java.awt.Stroke var53 = var1.getBaseSectionOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "java.awt.Color[r=0,g=0,b=10]"+ "'", var47.equals("java.awt.Color[r=0,g=0,b=10]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test149"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var6 = var3.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var8.axisChanged(var10);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", var6, (org.jfree.chart.plot.Plot)var8, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var17 = var14.getLegendItem((-1), 100);
//     var14.setBaseShapesFilled(false);
//     java.awt.Paint var21 = var14.getSeriesOutlinePaint((-1));
//     boolean var22 = var13.equals((java.lang.Object)var14);
//     org.jfree.chart.title.TextTitle var23 = var13.getTitle();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var26 = var25.getEndType();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var30 = var27.getLegendItem((-1), 100);
//     var27.setBaseShapesFilled(false);
//     java.awt.Paint var35 = var27.getItemOutlinePaint(10, 1);
//     java.awt.Paint var37 = var27.getSeriesOutlinePaint(10);
//     var27.setAutoPopulateSeriesShape(false);
//     boolean var40 = var25.equals((java.lang.Object)var27);
//     java.awt.Paint var43 = var25.getItemPaint(1, 0);
//     var23.setPaint(var43);
//     org.jfree.data.time.Month var45 = new org.jfree.data.time.Month();
//     long var46 = var45.getSerialIndex();
//     java.util.Date var47 = var45.getEnd();
//     org.jfree.data.time.Month var48 = new org.jfree.data.time.Month();
//     long var49 = var48.getSerialIndex();
//     java.util.Date var50 = var48.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var51 = new org.jfree.data.time.SimpleTimePeriod(var47, var50);
//     boolean var52 = var23.equals((java.lang.Object)var47);
//     java.lang.Object var53 = var23.clone();
//     java.lang.Object var54 = null;
//     var0.add((org.jfree.chart.block.Block)var23, var54);
//     var0.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test150"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("PlotOrientation.VERTICAL");
    var1.addFragment(var3);
    org.jfree.chart.text.TextFragment var5 = var1.getLastTextFragment();
    var0.addLine(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test151"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(0);
    double var3 = var0.getLowerClip();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.setUpperMargin(0.0d);
    int var9 = var6.getMaximumCategoryLabelLines();
    java.lang.Object var10 = var6.clone();
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var15 = var12.getLegendItem((-1), 100);
    var12.setBaseShapesFilled(false);
    java.awt.Paint var19 = var12.getSeriesOutlinePaint((-1));
    java.awt.Paint var21 = var12.lookupSeriesOutlinePaint(0);
    var11.setLabelPaint(var21);
    double var23 = var11.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var27 = var24.getLegendItem(2, 0);
    double var28 = var24.getBase();
    org.jfree.chart.labels.ItemLabelPosition var31 = var24.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var35 = var32.getLegendItem((-1), 100);
    var32.setBaseShapesFilled(false);
    java.awt.Paint var40 = var32.getItemOutlinePaint(10, 1);
    var24.setErrorIndicatorPaint(var40);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var4, var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    var42.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.AxisSpace var45 = new org.jfree.chart.axis.AxisSpace();
    double var46 = var45.getLeft();
    var42.setFixedRangeAxisSpace(var45);
    org.jfree.chart.axis.AxisSpace var48 = new org.jfree.chart.axis.AxisSpace();
    double var49 = var48.getLeft();
    var42.setFixedRangeAxisSpace(var48);
    var42.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.CategoryAxis var54 = var42.getDomainAxis((-1));
    org.jfree.chart.axis.AxisLocation var56 = var42.getDomainAxisLocation((-457));
    boolean var57 = var0.hasListener((java.util.EventListener)var42);
    boolean var58 = var42.isRangeGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test152"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var2);
    java.lang.Object var4 = var3.clone();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "ChartEntity: tooltip = null"+ "'", var5.equals("ChartEntity: tooltip = null"));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test153"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var7 = var6.isTickMarksVisible();
    org.jfree.data.Range var10 = new org.jfree.data.Range(1.0d, 100.0d);
    var6.setRangeWithMargins(var10, false, false);
    var4.setRangeWithMargins(var10);
    var1.setDefaultAutoRange(var10);
    java.awt.Font var16 = var1.getTickLabelFont();
    boolean var17 = var1.isNegativeArrowVisible();
    var1.setLowerMargin(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test154"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var2 = var0.getTimeFromLong(2014L);
//     int var3 = var0.getSegmentsIncluded();
//     int var4 = var0.getSegmentsExcluded();
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var9 = var6.getLegendItem((-1), 100);
//     var6.setBaseShapesFilled(false);
//     java.awt.Paint var13 = var6.getSeriesOutlinePaint((-1));
//     java.awt.Paint var15 = var6.lookupSeriesOutlinePaint(0);
//     var5.setLabelPaint(var15);
//     boolean var17 = var5.isNegativeArrowVisible();
//     org.jfree.data.Range var20 = new org.jfree.data.Range(1.0d, 100.0d);
//     java.lang.String var21 = var20.toString();
//     org.jfree.data.Range var23 = org.jfree.data.Range.shift(var20, 0.0d);
//     var5.setRange(var23);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     long var26 = var25.getSerialIndex();
//     java.util.Date var27 = var25.getEnd();
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month();
//     long var29 = var28.getSerialIndex();
//     java.util.Date var30 = var28.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var31 = new org.jfree.data.time.SimpleTimePeriod(var27, var30);
//     var5.setMaximumDate(var27);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var34 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var34, (java.lang.Comparable)"");
//     org.jfree.data.category.CategoryDataset var37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"hi!", (org.jfree.data.KeyedValues)var36);
//     org.jfree.data.general.PieDataset var40 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var36, (java.lang.Comparable)(byte)100, (-1.0d));
//     org.jfree.chart.plot.PiePlot3D var41 = new org.jfree.chart.plot.PiePlot3D(var36);
//     org.jfree.data.general.PieDataset var45 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var36, (java.lang.Comparable)1L, 0.2d, 100);
//     org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var50 = var47.getLegendItem((-1), 100);
//     var47.setBaseShapesFilled(false);
//     java.awt.Paint var54 = var47.getSeriesOutlinePaint((-1));
//     java.awt.Paint var56 = var47.lookupSeriesOutlinePaint(0);
//     var46.setLabelPaint(var56);
//     double var58 = var46.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var61 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var64 = var61.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var65 = null;
//     org.jfree.chart.plot.RingPlot var66 = new org.jfree.chart.plot.RingPlot(var65);
//     org.jfree.chart.plot.Plot var67 = var66.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var68 = null;
//     var66.axisChanged(var68);
//     org.jfree.chart.JFreeChart var71 = new org.jfree.chart.JFreeChart("hi!", var64, (org.jfree.chart.plot.Plot)var66, true);
//     java.awt.Paint var72 = var66.getBackgroundPaint();
//     java.awt.Paint var73 = var66.getLabelOutlinePaint();
//     var46.setTickMarkPaint(var73);
//     java.text.DateFormat var77 = null;
//     org.jfree.chart.axis.DateTickUnit var78 = new org.jfree.chart.axis.DateTickUnit(2, 1, var77);
//     var46.setTickUnit(var78, false, false);
//     org.jfree.chart.axis.DateAxis var82 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var83 = var82.getMaximumDate();
//     java.lang.String var84 = var78.dateToString(var83);
//     int var85 = var78.getCount();
//     double var86 = var78.getSize();
//     org.jfree.data.time.Month var87 = new org.jfree.data.time.Month();
//     long var88 = var87.getSerialIndex();
//     java.util.Date var89 = var87.getEnd();
//     org.jfree.data.time.Month var90 = new org.jfree.data.time.Month();
//     long var91 = var90.getSerialIndex();
//     java.util.Date var92 = var90.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var93 = new org.jfree.data.time.SimpleTimePeriod(var89, var92);
//     java.lang.String var94 = var78.dateToString(var89);
//     org.jfree.data.general.PieDataset var97 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var45, (java.lang.Comparable)var89, 1.05d, 12);
//     boolean var98 = var0.containsDomainRange(var27, var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "Range[1.0,100.0]"+ "'", var21.equals("Range[1.0,100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var84 + "' != '" + "12/31/69"+ "'", var84.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 8.64E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var94 + "' != '" + "12/31/14"+ "'", var94.equals("12/31/14"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == true);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test155"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.CategoryAxis var42 = var38.getDomainAxis(0);
    var38.setDrawSharedDomainAxis(true);
    org.jfree.chart.plot.PlotRenderingInfo var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D("");
    var50.configure();
    org.jfree.chart.util.RectangleInsets var52 = var50.getLabelInsets();
    var48.setAxisOffset(var52);
    org.jfree.chart.plot.CategoryMarker var55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var56 = var55.getOutlineStroke();
    var48.addDomainMarker((org.jfree.chart.plot.Marker)var55);
    java.awt.geom.Point2D var58 = var48.getQuadrantOrigin();
    var38.zoomRangeAxes(0.0d, 90.0d, var47, var58);
    java.awt.Stroke var60 = var38.getRangeGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var62 = var38.getDomainAxisForDataset(10);
    org.jfree.chart.plot.PlotOrientation var63 = var38.getOrientation();
    var38.setRangeCrosshairValue(2.0d, true);
    org.jfree.data.category.CategoryDataset var67 = var38.getDataset();
    var38.clearAnnotations();
    var38.clearRangeMarkers((-41749));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test156"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-8.0d), 4.0d);
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var6 = var5.getTickLabelPaint();
    java.awt.Shape var7 = var5.getUpArrow();
    boolean var8 = var5.isAxisLineVisible();
    var5.setTickMarkOutsideLength(10.0f);
    var5.setLabelToolTip("ThreadContext");
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var17 = var16.isTickMarksVisible();
    org.jfree.data.Range var20 = new org.jfree.data.Range(1.0d, 100.0d);
    var16.setRangeWithMargins(var20, false, false);
    var14.setRangeWithMargins(var20);
    var14.configure();
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var14, var26);
    var2.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var27);
    var2.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test157"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var16 = var13.getLegendItem((-1), 100);
    var13.setBaseShapesFilled(false);
    java.awt.Paint var20 = var13.getSeriesOutlinePaint((-1));
    boolean var21 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var13.setBaseToolTipGenerator(var22, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var13.getPositiveItemLabelPosition(10, 100);
    org.jfree.chart.text.TextAnchor var28 = var27.getRotationAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test158"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.List var1 = var0.getColumnKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test159"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLabelAngle();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, Double.NaN, Double.NaN);
    var0.setDownArrow(var4);
    java.text.DateFormat var9 = var0.getDateFormatOverride();
    double var10 = var0.getAutoRangeMinimumSize();
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    var11.setDomainCrosshairValue(0.05d);
    java.awt.Paint var14 = var11.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var18 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.25d);
    double var19 = var18.getEndValue();
    var18.setStartValue(0.2d);
    org.jfree.chart.util.Layer var22 = null;
    var11.addRangeMarker(0, (org.jfree.chart.plot.Marker)var18, var22);
    org.jfree.chart.util.RectangleInsets var24 = var18.getLabelOffset();
    boolean var25 = var0.equals((java.lang.Object)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test160"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.CategoryAxis var42 = var38.getDomainAxis(0);
    var38.setDrawSharedDomainAxis(true);
    org.jfree.chart.util.SortOrder var45 = var38.getColumnRenderingOrder();
    var38.setRangeGridlinesVisible(true);
    org.jfree.chart.util.Layer var49 = null;
    java.util.Collection var50 = var38.getDomainMarkers(3, var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test161"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("java.awt.Color[r=0,g=0,b=10]");
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    var2.setDomainCrosshairValue(0.05d);
    java.awt.Paint var5 = var2.getDomainCrosshairPaint();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    java.awt.Paint var8 = var7.getBaseSectionPaint();
    boolean var9 = var7.isOutlineVisible();
    java.awt.Color var13 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var14 = null;
    float[] var15 = var13.getRGBColorComponents(var14);
    var7.setSectionOutlinePaint((java.lang.Comparable)"", (java.awt.Paint)var13);
    java.awt.Color var19 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var20 = null;
    float[] var21 = var19.getRGBColorComponents(var20);
    float[] var22 = var13.getRGBComponents(var20);
    var2.setOutlinePaint((java.awt.Paint)var13);
    var1.setTickMarkPaint((java.awt.Paint)var13);
    float var25 = var1.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0f);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test162"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setGenerateEntities(false);
    var0.setTranslateY(0.0d);
    double var5 = var0.getTranslateY();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test163"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var4 = var0.getBaseLinesVisible();
    boolean var6 = var0.equals((java.lang.Object)100.0f);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getBaseToolTipGenerator();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var15 = var14.isTickMarksVisible();
    java.awt.Shape var16 = var14.getDownArrow();
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 0.2d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var20.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var24 = var20.getBaseLinesVisible();
    java.lang.Boolean var26 = var20.getSeriesVisibleInLegend(10);
    java.awt.Paint var27 = var20.getBaseItemLabelPaint();
    java.awt.Color var30 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var31 = null;
    float[] var32 = var30.getRGBColorComponents(var31);
    var20.setBaseItemLabelPaint((java.awt.Paint)var30);
    int var34 = var30.getGreen();
    java.lang.String var35 = var30.toString();
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "ThreadContext", "Pie Plot", "Range[1.0,100.0]", var19, (java.awt.Paint)var30);
    java.lang.Comparable var37 = var36.getSeriesKey();
    int var38 = var36.getSeriesIndex();
    java.awt.Shape var39 = var36.getShape();
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var39, 8.0d, 1.0E-8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-457), var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "java.awt.Color[r=0,g=0,b=10]"+ "'", var35.equals("java.awt.Color[r=0,g=0,b=10]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test164"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem((-1), 100);
    var0.setBaseShapesFilled(false);
    java.awt.Paint var8 = var0.getItemOutlinePaint(10, 1);
    java.lang.Object var9 = var0.clone();
    var0.setSeriesShapesVisible(1, false);
    var0.setDrawOutlines(false);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    var0.setBaseLinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test165"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.configure();
    org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
    org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("PlotOrientation.VERTICAL");
    var4.addFragment(var6);
    int var8 = var3.compareTo((java.lang.Object)var4);
    org.jfree.chart.text.TextFragment var9 = var4.getFirstTextFragment();
    org.jfree.data.KeyedObjects2D var10 = new org.jfree.data.KeyedObjects2D();
    org.jfree.data.KeyToGroupMap var19 = new org.jfree.data.KeyToGroupMap();
    java.util.List var20 = var19.getGroups();
    org.jfree.data.statistics.BoxAndWhiskerItem var21 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)1.0d, (java.lang.Number)100.0f, (java.lang.Number)(short)1, (java.lang.Number)1.0f, (java.lang.Number)(byte)(-1), (java.lang.Number)(-1), (java.lang.Number)(byte)100, var20);
    java.lang.Comparable var22 = null;
    var10.setObject((java.lang.Object)var20, var22, (java.lang.Comparable)1);
    var10.removeObject((java.lang.Comparable)10, (java.lang.Comparable)(short)100);
    int var29 = var10.getColumnIndex((java.lang.Comparable)(byte)100);
    org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D("");
    var31.configure();
    org.jfree.chart.axis.NumberTickUnit var33 = var31.getTickUnit();
    org.jfree.chart.text.TextLine var34 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("PlotOrientation.VERTICAL");
    var34.addFragment(var36);
    int var38 = var33.compareTo((java.lang.Object)var34);
    org.jfree.chart.text.TextFragment var39 = var34.getFirstTextFragment();
    boolean var40 = var10.equals((java.lang.Object)var39);
    var4.addFragment(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test166"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem((-1), 100);
    var0.setBaseShapesFilled(false);
    boolean var6 = var0.getAutoPopulateSeriesStroke();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    java.awt.Paint var9 = var8.getBaseSectionPaint();
    boolean var10 = var8.isOutlineVisible();
    java.awt.Color var14 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var15 = null;
    float[] var16 = var14.getRGBColorComponents(var15);
    var8.setSectionOutlinePaint((java.lang.Comparable)"", (java.awt.Paint)var14);
    var0.setBaseItemLabelPaint((java.awt.Paint)var14, false);
    boolean var20 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseCreateEntities(true, true);
    boolean var24 = var0.getBaseShapesFilled();
    boolean var25 = var0.getAutoPopulateSeriesStroke();
    var0.setSeriesLinesVisible(156, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test167"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var3 = var2.getTickLabelPaint();
    java.awt.Shape var4 = var2.getUpArrow();
    boolean var5 = var2.isAxisLineVisible();
    var2.setTickMarkOutsideLength(10.0f);
    var2.setLabelToolTip("ThreadContext");
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var14 = var13.isTickMarksVisible();
    org.jfree.data.Range var17 = new org.jfree.data.Range(1.0d, 100.0d);
    var13.setRangeWithMargins(var17, false, false);
    var11.setRangeWithMargins(var17);
    var11.configure();
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var11, var23);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var26, 50.5d, (-1.0f), (-1.0f));
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, var26, "DatasetRenderingOrder.REVERSE", "UnitType.ABSOLUTE");
    org.jfree.chart.axis.Axis var34 = var33.getAxis();
    org.jfree.chart.axis.Axis var35 = var33.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test168"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test169"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)"");
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var5);
    org.jfree.data.KeyToGroupMap var15 = new org.jfree.data.KeyToGroupMap();
    java.util.List var16 = var15.getGroups();
    org.jfree.data.statistics.BoxAndWhiskerItem var17 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)1.0d, (java.lang.Number)100.0f, (java.lang.Number)(short)1, (java.lang.Number)1.0f, (java.lang.Number)(byte)(-1), (java.lang.Number)(-1), (java.lang.Number)(byte)100, var16);
    var0.add(var17, (java.lang.Comparable)0.0f, (java.lang.Comparable)"hi!");
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
    java.awt.Paint var23 = var22.getBaseSectionPaint();
    boolean var24 = var22.isOutlineVisible();
    var22.setMaximumLabelWidth(100.0d);
    boolean var27 = var0.hasListener((java.util.EventListener)var22);
    java.awt.Paint var28 = var22.getShadowPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test170"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setUpperMargin(0.0d);
//     int var5 = var2.getMaximumCategoryLabelLines();
//     java.lang.Object var6 = var2.clone();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
//     var8.setBaseShapesFilled(false);
//     java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
//     java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
//     var7.setLabelPaint(var17);
//     double var19 = var7.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
//     double var24 = var20.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
//     var28.setBaseShapesFilled(false);
//     java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
//     var20.setErrorIndicatorPaint(var36);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     var38.setRangeCrosshairValue(50.5d);
//     org.jfree.chart.axis.CategoryAxis var42 = var38.getDomainAxis(0);
//     var38.setDrawSharedDomainAxis(true);
//     org.jfree.chart.util.SortOrder var45 = var38.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotOrientation var46 = var38.getOrientation();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = var38.getRenderer(4);
//     java.awt.Paint var49 = var38.getRangeCrosshairPaint();
//     boolean var50 = var38.isRangeZoomable();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
//     int var52 = var38.getDomainAxisIndex(var51);
//     var38.setRangeGridlinesVisible(false);
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.Range var57 = var56.getDefaultAutoRange();
//     org.jfree.data.Range var60 = new org.jfree.data.Range(1.0d, 100.0d);
//     var56.setRangeWithMargins(var60);
//     org.jfree.chart.renderer.PolarItemRenderer var62 = null;
//     org.jfree.chart.plot.PolarPlot var63 = new org.jfree.chart.plot.PolarPlot(var55, (org.jfree.chart.axis.ValueAxis)var56, var62);
//     java.awt.Paint var64 = null;
//     var63.setRadiusGridlinePaint(var64);
//     var63.setRadiusGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var68 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var71 = var68.getLegendItem(2, 0);
//     double var72 = var68.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var75 = var68.getPositiveItemLabelPosition(2, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var76 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var79 = var76.getLegendItem((-1), 100);
//     var76.setBaseShapesFilled(false);
//     java.awt.Paint var84 = var76.getItemOutlinePaint(10, 1);
//     var68.setErrorIndicatorPaint(var84);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var86 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var86.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var90 = var86.getBaseLinesVisible();
//     boolean var92 = var86.equals((java.lang.Object)100.0f);
//     org.jfree.chart.event.RendererChangeEvent var93 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var92);
//     java.lang.String var94 = var93.toString();
//     var68.notifyListeners(var93);
//     var63.rendererChanged(var93);
//     var38.rendererChanged(var93);
//     
//     // Checks the contract:  equals-hashcode on var27 and var75
//     assertTrue("Contract failed: equals-hashcode on var27 and var75", var27.equals(var75) ? var27.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var27
//     assertTrue("Contract failed: equals-hashcode on var75 and var27", var75.equals(var27) ? var75.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test171"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var1.axisChanged(var3);
    var1.setShadowYOffset(0.0d);
    double var7 = var1.getStartAngle();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    var10.configure();
    java.lang.Object var12 = var10.clone();
    java.lang.Number var15 = null;
    java.util.List var21 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var22 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)0L, var15, (java.lang.Number)100.0f, (java.lang.Number)0L, (java.lang.Number)0, (java.lang.Number)(short)(-1), (java.lang.Number)1.0d, var21);
    boolean var23 = var10.equals((java.lang.Object)0);
    boolean var24 = var10.isAutoRange();
    java.awt.Font var25 = var10.getLabelFont();
    org.jfree.chart.text.TextLine var26 = new org.jfree.chart.text.TextLine("Size2D[width=50.5, height=10.0]", var25);
    org.jfree.data.DefaultKeyedValues2D var28 = new org.jfree.data.DefaultKeyedValues2D(false);
    var28.clear();
    java.util.List var30 = var28.getColumnKeys();
    boolean var31 = var26.equals((java.lang.Object)var28);
    org.jfree.chart.renderer.category.StackedAreaRenderer var34 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var37 = var34.getItemLabelFont((-1), 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var38.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var42 = var38.getBaseLinesVisible();
    java.lang.Boolean var44 = var38.getSeriesVisibleInLegend(10);
    java.awt.Paint var45 = var38.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var46 = new org.jfree.chart.text.TextFragment("", var37, var45);
    var26.removeFragment(var46);
    java.awt.Font var48 = var46.getFont();
    var1.setNoDataMessageFont(var48);
    org.jfree.chart.event.PlotChangeEvent var50 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test172"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 4.0d);
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var7 = var4.getLegendItem((-1), 100);
//     var4.setBaseShapesFilled(false);
//     java.awt.Paint var11 = var4.getSeriesOutlinePaint((-1));
//     java.awt.Paint var13 = var4.lookupSeriesOutlinePaint(0);
//     var3.setLabelPaint(var13);
//     boolean var15 = var3.isNegativeArrowVisible();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var17.getBaseNegativeItemLabelPosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var20 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var22 = var20.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var28 = var25.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     org.jfree.chart.plot.Plot var31 = var30.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var32 = null;
//     var30.axisChanged(var32);
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("hi!", var28, (org.jfree.chart.plot.Plot)var30, true);
//     boolean var36 = var20.equals((java.lang.Object)var28);
//     var20.validateObject();
//     org.jfree.data.Range var38 = var17.findRangeBounds((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.data.general.DatasetChangeEvent var39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var15, (org.jfree.data.general.Dataset)var20);
//     org.jfree.data.Range var40 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.chart.plot.MultiplePiePlot var41 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.data.Range var42 = var2.findRangeBounds((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var43.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var47 = var43.getBaseLinesVisible();
//     boolean var49 = var43.equals((java.lang.Object)100.0f);
//     boolean var50 = var2.equals((java.lang.Object)var49);
//     var2.setRenderAsPercentages(false);
//     java.awt.Paint var53 = var2.getWallPaint();
//     org.jfree.chart.labels.ItemLabelPosition var54 = var2.getNegativeItemLabelPositionFallback();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var55 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var57 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var55, (java.lang.Comparable)"");
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.RingPlot var59 = new org.jfree.chart.plot.RingPlot(var58);
//     org.jfree.chart.plot.Plot var60 = var59.getRootPlot();
//     var55.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var60);
//     java.util.List var62 = var55.getRowKeys();
//     org.jfree.data.Range var63 = var2.findRangeBounds((org.jfree.data.category.CategoryDataset)var55);
//     
//     // Checks the contract:  equals-hashcode on var20 and var55
//     assertTrue("Contract failed: equals-hashcode on var20 and var55", var20.equals(var55) ? var20.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var20
//     assertTrue("Contract failed: equals-hashcode on var55 and var20", var55.equals(var20) ? var55.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var59
//     assertTrue("Contract failed: equals-hashcode on var30 and var59", var30.equals(var59) ? var30.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var30
//     assertTrue("Contract failed: equals-hashcode on var59 and var30", var59.equals(var30) ? var59.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var60
//     assertTrue("Contract failed: equals-hashcode on var31 and var60", var31.equals(var60) ? var31.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var31
//     assertTrue("Contract failed: equals-hashcode on var60 and var31", var60.equals(var31) ? var60.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test173"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.awt.Shape var3 = var1.getDownArrow();
    var1.setUpperMargin(0.2d);
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
    var7.configure();
    org.jfree.chart.axis.NumberTickUnit var9 = var7.getTickUnit();
    org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("PlotOrientation.VERTICAL");
    var10.addFragment(var12);
    int var14 = var9.compareTo((java.lang.Object)var10);
    var1.setTickUnit(var9);
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var17 = var16.getMaximumDate();
    org.jfree.data.Range var20 = new org.jfree.data.Range(1.0d, 100.0d);
    var16.setRange(var20, true, false);
    var16.resizeRange(10.0d, 90.0d);
    java.awt.Paint var27 = var16.getTickMarkPaint();
    var1.setTickLabelPaint(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test174"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var4 = var1.getLegendItem((-1), 100);
    var1.setBaseShapesFilled(false);
    java.awt.Paint var8 = var1.getSeriesOutlinePaint((-1));
    java.awt.Paint var10 = var1.lookupSeriesOutlinePaint(0);
    var0.setLabelPaint(var10);
    double var12 = var0.getFixedAutoRange();
    var0.setNegativeArrowVisible(true);
    var0.setAutoRangeMinimumSize(90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test175"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.axis.NumberTickUnit var4 = var2.getTickUnit();
    org.jfree.data.Range var5 = var2.getRange();
    var2.setLowerMargin(100.0d);
    var2.setAutoRange(true);
    java.awt.Paint var10 = var2.getAxisLinePaint();
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
    var17.configure();
    org.jfree.chart.util.RectangleInsets var19 = var17.getLabelInsets();
    var15.setAxisOffset(var19);
    org.jfree.chart.plot.CategoryMarker var22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var23 = var22.getOutlineStroke();
    var15.addDomainMarker((org.jfree.chart.plot.Marker)var22);
    var22.setLabel("org.jfree.chart.event.RendererChangeEvent[source=false]");
    java.awt.Font var27 = var22.getLabelFont();
    org.jfree.chart.axis.MarkerAxisBand var28 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var2, 50.5d, 100.0d, (-7.75d), 0.0d, var27);
    org.jfree.data.category.CategoryDataset var29 = null;
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var31.setUpperMargin(0.0d);
    int var34 = var31.getMaximumCategoryLabelLines();
    java.lang.Object var35 = var31.clone();
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var40 = var37.getLegendItem((-1), 100);
    var37.setBaseShapesFilled(false);
    java.awt.Paint var44 = var37.getSeriesOutlinePaint((-1));
    java.awt.Paint var46 = var37.lookupSeriesOutlinePaint(0);
    var36.setLabelPaint(var46);
    double var48 = var36.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var49 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var52 = var49.getLegendItem(2, 0);
    double var53 = var49.getBase();
    org.jfree.chart.labels.ItemLabelPosition var56 = var49.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var60 = var57.getLegendItem((-1), 100);
    var57.setBaseShapesFilled(false);
    java.awt.Paint var65 = var57.getItemOutlinePaint(10, 1);
    var49.setErrorIndicatorPaint(var65);
    org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot(var29, var31, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.renderer.category.CategoryItemRenderer)var49);
    var67.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.CategoryAxis var71 = var67.getDomainAxis(0);
    var67.setDrawSharedDomainAxis(true);
    org.jfree.chart.plot.PlotRenderingInfo var76 = null;
    org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var79 = new org.jfree.chart.axis.NumberAxis3D("");
    var79.configure();
    org.jfree.chart.util.RectangleInsets var81 = var79.getLabelInsets();
    var77.setAxisOffset(var81);
    org.jfree.chart.plot.CategoryMarker var84 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var85 = var84.getOutlineStroke();
    var77.addDomainMarker((org.jfree.chart.plot.Marker)var84);
    java.awt.geom.Point2D var87 = var77.getQuadrantOrigin();
    var67.zoomRangeAxes(0.0d, 90.0d, var76, var87);
    java.awt.Stroke var89 = var67.getRangeGridlineStroke();
    org.jfree.chart.util.RectangleEdge var90 = var67.getDomainAxisEdge();
    org.jfree.chart.LegendItemCollection var91 = null;
    var67.setFixedLegendItems(var91);
    org.jfree.chart.JFreeChart var94 = new org.jfree.chart.JFreeChart("TextBlockAnchor.BOTTOM_CENTER", var27, (org.jfree.chart.plot.Plot)var67, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test176"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem(2, 0);
    double var4 = var0.getBase();
    org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPosition(2, (-1));
    double var8 = var0.getMaximumBarWidth();
    var0.setBase(4.0d);
    var0.setMinimumBarLength(50.5d);
    org.jfree.chart.urls.StandardCategoryURLGenerator var15 = new org.jfree.chart.urls.StandardCategoryURLGenerator("WMAP_Plot");
    var0.setSeriesURLGenerator(10, (org.jfree.chart.urls.CategoryURLGenerator)var15, true);
    org.jfree.chart.LegendItem var20 = var0.getLegendItem(0, 7);
    var0.setSeriesItemLabelsVisible(0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test177"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var6 = var3.getLegendItem(2, 0);
    double var7 = var3.getBase();
    java.awt.Color var10 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var11 = null;
    float[] var12 = var10.getRGBColorComponents(var11);
    java.awt.Color var15 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var16 = null;
    float[] var17 = var15.getRGBColorComponents(var16);
    float[] var18 = var10.getColorComponents(var16);
    var3.setErrorIndicatorPaint((java.awt.Paint)var10);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
    var22.configure();
    org.jfree.chart.util.RectangleInsets var24 = var22.getLabelInsets();
    var20.setAxisOffset(var24);
    org.jfree.chart.plot.CategoryMarker var27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var28 = var27.getOutlineStroke();
    var20.addDomainMarker((org.jfree.chart.plot.Marker)var27);
    java.awt.geom.Point2D var30 = var20.getQuadrantOrigin();
    java.awt.Paint var31 = var20.getDomainCrosshairPaint();
    org.jfree.chart.renderer.category.StackedAreaRenderer var33 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var34 = var33.getEndType();
    java.awt.Paint var35 = var33.getBaseFillPaint();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var36 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var2, (java.awt.Paint)var10, var31, var35);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var37 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var37, (java.lang.Comparable)"");
    org.jfree.data.general.PieDataset var40 = null;
    org.jfree.chart.plot.RingPlot var41 = new org.jfree.chart.plot.RingPlot(var40);
    org.jfree.chart.plot.Plot var42 = var41.getRootPlot();
    var37.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var42);
    java.lang.Number var46 = var37.getMaxRegularValue((java.lang.Comparable)100.0f, (java.lang.Comparable)10);
    int var48 = var37.getRowIndex((java.lang.Comparable)Double.NaN);
    int var49 = var37.getColumnCount();
    org.jfree.data.Range var50 = var36.findRangeBounds((org.jfree.data.category.CategoryDataset)var37);
    boolean var51 = var36.isDrawBarOutline();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var52.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var56 = var52.getBaseLinesVisible();
    boolean var58 = var52.equals((java.lang.Object)100.0f);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var60 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var60.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var64 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var67 = var64.getLegendItem((-1), 100);
    var64.setBaseShapesFilled(false);
    java.awt.Paint var72 = var64.getItemOutlinePaint(10, 1);
    var60.setBaseItemLabelPaint(var72);
    var52.setSeriesFillPaint(100, var72, false);
    org.jfree.chart.labels.ItemLabelPosition var76 = var52.getBaseNegativeItemLabelPosition();
    var36.setBasePositiveItemLabelPosition(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test178"); }
// 
// 
//     org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.gantt.Task var3 = new org.jfree.data.gantt.Task("ThreadContext", (org.jfree.data.time.TimePeriod)var2);
//     var3.setDescription("poly");
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     long var7 = var6.getSerialIndex();
//     java.util.Date var8 = var6.getEnd();
//     var3.setDuration((org.jfree.data.time.TimePeriod)var6);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var14 = var11.getLegendItem((-1), 100);
//     var11.setBaseShapesFilled(false);
//     java.awt.Paint var18 = var11.getSeriesOutlinePaint((-1));
//     java.awt.Paint var20 = var11.lookupSeriesOutlinePaint(0);
//     var10.setLabelPaint(var20);
//     double var22 = var10.getFixedAutoRange();
//     var10.setNegativeArrowVisible(true);
//     java.text.DateFormat var27 = null;
//     org.jfree.chart.axis.DateTickUnit var28 = new org.jfree.chart.axis.DateTickUnit(2, 1, var27);
//     var10.setTickUnit(var28, true, false);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     var0.setObject((java.lang.Object)var3, (java.lang.Comparable)true, (java.lang.Comparable)var32);
//     java.lang.String var34 = var32.toString();
//     long var35 = var32.getLastMillisecond();
//     java.lang.String var36 = var32.toString();
//     long var37 = var32.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var34 + "' != '" + "2014"+ "'", var34.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "2014"+ "'", var36.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 2014L);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test179"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.25d);
//     double var3 = var2.getEndValue();
//     var2.setStartValue(0.2d);
//     java.awt.Stroke var6 = var2.getStroke();
//     var2.setEndValue(4.0d);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
//     boolean var13 = var12.getAntiAlias();
//     java.awt.Stroke var14 = var12.getBorderStroke();
//     org.jfree.chart.util.RectangleInsets var15 = var12.getPadding();
//     double var17 = var15.calculateTopInset(4.0d);
//     var2.setLabelOffset(var15);
//     org.jfree.chart.util.UnitType var19 = var15.getUnitType();
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, Double.NaN, Double.NaN);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var32 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var34 = var32.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var37 = new org.jfree.chart.entity.CategoryItemEntity(var22, "hi!", "", (org.jfree.data.category.CategoryDataset)var32, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var41 = var38.getLegendItem((-1), 100);
//     var38.setBaseShapesFilled(false);
//     java.awt.Paint var45 = var38.getSeriesOutlinePaint((-1));
//     java.awt.Paint var47 = var38.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var48 = new org.jfree.chart.title.LegendGraphic(var22, var47);
//     boolean var49 = var48.isShapeVisible();
//     boolean var50 = var48.isShapeFilled();
//     java.awt.geom.Rectangle2D var51 = var48.getBounds();
//     java.awt.geom.Rectangle2D var54 = var15.createOutsetRectangle(var51, true, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.25d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test180"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    java.lang.Object var13 = var7.clone();
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var14, var15, 100.0d, 10.0d);
    var18.clear();
    org.jfree.chart.block.Arrangement var20 = null;
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var18, var20);
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
    var24.configure();
    org.jfree.chart.util.RectangleInsets var26 = var24.getLabelInsets();
    var22.setAxisOffset(var26);
    org.jfree.chart.renderer.category.StackedAreaRenderer var29 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var30 = var29.getEndType();
    java.awt.Stroke var33 = var29.getItemStroke(0, 0);
    var22.setRangeZeroBaselineStroke(var33);
    org.jfree.chart.util.Layer var35 = null;
    java.util.Collection var36 = var22.getDomainMarkers(var35);
    org.jfree.chart.util.RectangleInsets var37 = var22.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var39 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var40 = var39.getEndType();
    java.awt.Stroke var43 = var39.getItemStroke(0, 0);
    var22.setDomainZeroBaselineStroke(var43);
    org.jfree.chart.util.RectangleEdge var46 = var22.getDomainAxisEdge(1);
    var21.setLegendItemGraphicEdge(var46);
    java.awt.Font var48 = var21.getItemFont();
    java.awt.geom.Rectangle2D var49 = var21.getBounds();
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
    var50.setDomainCrosshairValue(0.05d);
    java.awt.Paint var53 = var50.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var57 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.25d);
    double var58 = var57.getEndValue();
    var57.setStartValue(0.2d);
    org.jfree.chart.util.Layer var61 = null;
    var50.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var61);
    org.jfree.chart.util.RectangleInsets var63 = var57.getLabelOffset();
    double var65 = var63.calculateBottomInset(4.0d);
    var21.setLegendItemGraphicPadding(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 3.0d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test181"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var4 = var1.getLegendItem((-1), 100);
    var1.setBaseShapesFilled(false);
    java.awt.Paint var8 = var1.getSeriesOutlinePaint((-1));
    java.awt.Paint var10 = var1.lookupSeriesOutlinePaint(0);
    var0.setLabelPaint(var10);
    double var12 = var0.getFixedAutoRange();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var15 = var14.getTickLabelPaint();
    java.awt.Shape var16 = var14.getDownArrow();
    var0.setLeftArrow(var16);
    java.text.DateFormat var20 = null;
    org.jfree.chart.axis.DateTickUnit var21 = new org.jfree.chart.axis.DateTickUnit(0, 2, var20);
    var0.setTickUnit(var21);
    org.jfree.data.Range var23 = var0.getRange();
    org.jfree.data.Range var26 = org.jfree.data.Range.expand(var23, 8.0d, 104.95d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test182"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var2.equals("GradientPaintTransformType.VERTICAL"));

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test183"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.CategoryAxis var42 = var38.getDomainAxisForDataset(1);
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var45 = var44.isTickMarksVisible();
    org.jfree.data.Range var48 = new org.jfree.data.Range(1.0d, 100.0d);
    var44.setRangeWithMargins(var48, false, false);
    org.jfree.chart.axis.ValueAxis[] var52 = new org.jfree.chart.axis.ValueAxis[] { var44};
    var38.setRangeAxes(var52);
    int var54 = var38.getDomainAxisCount();
    org.jfree.data.general.PieDataset var55 = null;
    org.jfree.chart.plot.RingPlot var56 = new org.jfree.chart.plot.RingPlot(var55);
    double var57 = var56.getInteriorGap();
    org.jfree.chart.renderer.category.StackedAreaRenderer var60 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var63 = var60.getItemLabelFont((-1), 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var64 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var64.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var68 = var64.getBaseLinesVisible();
    java.lang.Boolean var70 = var64.getSeriesVisibleInLegend(10);
    java.awt.Paint var71 = var64.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var72 = new org.jfree.chart.text.TextFragment("", var63, var71);
    var56.setLabelFont(var63);
    var56.setNoDataMessage("Pie Plot");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var76 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var76.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var80 = var76.getBaseLinesVisible();
    java.lang.Boolean var82 = var76.getSeriesVisibleInLegend(10);
    java.awt.Paint var83 = var76.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var84 = new org.jfree.chart.block.BlockBorder(var83);
    var56.setLabelLinkPaint(var83);
    var38.setParent((org.jfree.chart.plot.Plot)var56);
    org.jfree.chart.labels.PieSectionLabelGenerator var87 = var56.getLegendLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test184"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.Range var2 = var1.getDefaultAutoRange();
    org.jfree.data.Range var5 = new org.jfree.data.Range(1.0d, 100.0d);
    var1.setRangeWithMargins(var5);
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var7);
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    var10.configure();
    org.jfree.chart.axis.NumberTickUnit var12 = var10.getTickUnit();
    org.jfree.data.Range var13 = var10.getRange();
    var10.setLowerMargin(100.0d);
    double var16 = var10.getFixedAutoRange();
    org.jfree.chart.axis.MarkerAxisBand var17 = null;
    var10.setMarkerBand(var17);
    org.jfree.data.Range var19 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
    double var21 = var20.getLabelAngle();
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var26 = var23.getLegendItem((-1), 100);
    var23.setBaseShapesFilled(false);
    java.awt.Paint var30 = var23.getSeriesOutlinePaint((-1));
    java.awt.Paint var32 = var23.lookupSeriesOutlinePaint(0);
    var22.setLabelPaint(var32);
    org.jfree.chart.axis.DateTickMarkPosition var34 = var22.getTickMarkPosition();
    var20.setTickMarkPosition(var34);
    org.jfree.chart.renderer.category.StackedAreaRenderer var37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var38 = var37.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var39 = var37.getBaseNegativeItemLabelPosition();
    boolean var40 = var20.equals((java.lang.Object)var39);
    var8.setAxis((org.jfree.chart.axis.ValueAxis)var20);
    org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D("");
    var43.configure();
    org.jfree.chart.axis.NumberTickUnit var45 = var43.getTickUnit();
    org.jfree.data.Range var46 = var43.getRange();
    boolean var47 = var43.isTickLabelsVisible();
    var43.setAutoTickUnitSelection(false);
    org.jfree.data.Range var50 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
    boolean var51 = var8.isRadiusGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test185"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
    java.awt.Stroke var11 = var7.getItemStroke(0, 0);
    var0.setRangeZeroBaselineStroke(var11);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var0.getDomainMarkers(var13);
    org.jfree.chart.util.RectangleInsets var15 = var0.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
    java.awt.Stroke var21 = var17.getItemStroke(0, 0);
    var0.setDomainZeroBaselineStroke(var21);
    org.jfree.chart.util.RectangleEdge var24 = var0.getDomainAxisEdge(1);
    org.jfree.data.xy.XYDataset var25 = null;
    var0.setDataset(var25);
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D("");
    var31.configure();
    org.jfree.chart.util.RectangleInsets var33 = var31.getLabelInsets();
    var29.setAxisOffset(var33);
    org.jfree.chart.util.RectangleInsets var35 = var29.getAxisOffset();
    boolean var36 = var29.isRangeCrosshairVisible();
    org.jfree.chart.entity.EntityCollection var39 = null;
    org.jfree.chart.ChartRenderingInfo var40 = new org.jfree.chart.ChartRenderingInfo(var39);
    org.jfree.chart.plot.PlotRenderingInfo var41 = var40.getPlotInfo();
    org.jfree.chart.renderer.category.CategoryItemRendererState var42 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var41);
    java.awt.geom.Rectangle2D var43 = null;
    org.jfree.chart.util.RectangleAnchor var44 = null;
    java.awt.geom.Point2D var45 = org.jfree.chart.util.RectangleAnchor.coordinates(var43, var44);
    var29.zoomRangeAxes(10.0d, 10.0d, var41, var45);
    var0.handleClick(10, 0, var41);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.event.AxisChangeListener var51 = null;
    var50.removeChangeListener(var51);
    java.text.NumberFormat var53 = var50.getNumberFormatOverride();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-457), (org.jfree.chart.axis.ValueAxis)var50, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test186"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem(2, 0);
    double var4 = var0.getBase();
    var0.setItemLabelAnchorOffset(50.5d);
    org.jfree.chart.urls.CategoryURLGenerator var7 = var0.getBaseURLGenerator();
    double var8 = var0.getMaximumBarWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test187"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var2 = var0.getTimeFromLong(2014L);
//     int var3 = var0.getSegmentsIncluded();
//     int var4 = var0.getSegmentsExcluded();
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var6 = var5.getMaximumDate();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var7 = var0.getSegment(var6);
//     long var8 = var0.getSegmentsIncludedSize();
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var13 = var10.getLegendItem((-1), 100);
//     var10.setBaseShapesFilled(false);
//     java.awt.Paint var17 = var10.getSeriesOutlinePaint((-1));
//     java.awt.Paint var19 = var10.lookupSeriesOutlinePaint(0);
//     var9.setLabelPaint(var19);
//     boolean var21 = var9.isNegativeArrowVisible();
//     org.jfree.data.Range var24 = new org.jfree.data.Range(1.0d, 100.0d);
//     java.lang.String var25 = var24.toString();
//     org.jfree.data.Range var27 = org.jfree.data.Range.shift(var24, 0.0d);
//     var9.setRange(var27);
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     long var30 = var29.getSerialIndex();
//     java.util.Date var31 = var29.getEnd();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     long var33 = var32.getSerialIndex();
//     java.util.Date var34 = var32.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var35 = new org.jfree.data.time.SimpleTimePeriod(var31, var34);
//     var9.setMaximumDate(var31);
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month();
//     long var38 = var37.getSerialIndex();
//     java.util.Date var39 = var37.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var40 = new org.jfree.data.time.SimpleTimePeriod(var31, var39);
//     long var41 = var0.getTime(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "Range[1.0,100.0]"+ "'", var25.equals("Range[1.0,100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1420099199999L);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test188"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, Double.NaN, Double.NaN);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var14 = var12.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var17 = new org.jfree.chart.entity.CategoryItemEntity(var2, "hi!", "", (org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var21 = var18.getLegendItem((-1), 100);
//     var18.setBaseShapesFilled(false);
//     java.awt.Paint var25 = var18.getSeriesOutlinePaint((-1));
//     java.awt.Paint var27 = var18.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic(var2, var27);
//     org.jfree.chart.entity.LegendItemEntity var29 = new org.jfree.chart.entity.LegendItemEntity(var2);
//     java.lang.Comparable var30 = var29.getSeriesKey();
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var35 = var32.getLegendItem((-1), 100);
//     var32.setBaseShapesFilled(false);
//     java.awt.Paint var39 = var32.getSeriesOutlinePaint((-1));
//     java.awt.Paint var41 = var32.lookupSeriesOutlinePaint(0);
//     var31.setLabelPaint(var41);
//     double var43 = var31.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var46 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var49 = var46.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var50 = null;
//     org.jfree.chart.plot.RingPlot var51 = new org.jfree.chart.plot.RingPlot(var50);
//     org.jfree.chart.plot.Plot var52 = var51.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var53 = null;
//     var51.axisChanged(var53);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("hi!", var49, (org.jfree.chart.plot.Plot)var51, true);
//     java.awt.Paint var57 = var51.getBackgroundPaint();
//     java.awt.Paint var58 = var51.getLabelOutlinePaint();
//     var31.setTickMarkPaint(var58);
//     java.text.DateFormat var62 = null;
//     org.jfree.chart.axis.DateTickUnit var63 = new org.jfree.chart.axis.DateTickUnit(2, 1, var62);
//     var31.setTickUnit(var63, false, false);
//     var29.setSeriesKey((java.lang.Comparable)var63);
//     var29.setSeriesKey((java.lang.Comparable)"hi!");
//     org.jfree.data.gantt.TaskSeries var71 = new org.jfree.data.gantt.TaskSeries("");
//     java.lang.Comparable var72 = var71.getKey();
//     boolean var73 = var71.getNotify();
//     java.lang.String[] var75 = new java.lang.String[] { "org.jfree.data.UnknownKeyException: org.jfree.chart.event.RendererChangeEvent[source=false]"};
//     java.lang.Number[][] var76 = null;
//     java.lang.Number[] var77 = null;
//     java.lang.Number[][] var78 = new java.lang.Number[][] { var77};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var79 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var75, var76, var78);
//     var71.addChangeListener((org.jfree.data.general.SeriesChangeListener)var79);
//     java.util.List var81 = var79.getRowKeys();
//     java.util.List var82 = var79.getRowKeys();
//     var29.setDataset((org.jfree.data.general.Dataset)var79);
//     org.jfree.data.general.SeriesChangeEvent var85 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)'4');
//     java.lang.String var86 = var85.toString();
//     var79.seriesChanged(var85);
//     int var89 = var79.getCategoryIndex((java.lang.Comparable)(-3.95d));
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test189"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, Double.NaN, Double.NaN);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var14 = var12.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var17 = new org.jfree.chart.entity.CategoryItemEntity(var2, "hi!", "", (org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var21 = var18.getLegendItem((-1), 100);
//     var18.setBaseShapesFilled(false);
//     java.awt.Paint var25 = var18.getSeriesOutlinePaint((-1));
//     java.awt.Paint var27 = var18.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic(var2, var27);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     org.jfree.chart.plot.Plot var31 = var30.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getInsets();
//     double var34 = var32.calculateBottomOutset(100.0d);
//     var28.setPadding(var32);
//     org.jfree.chart.util.RectangleInsets var36 = var28.getMargin();
//     org.jfree.chart.util.RectangleAnchor var37 = var28.getShapeAnchor();
//     var28.setShapeFilled(false);
//     var28.setShapeOutlineVisible(false);
//     java.awt.Paint var42 = var28.getLinePaint();
//     org.jfree.chart.util.RectangleAnchor var43 = var28.getShapeLocation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test190"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var16 = var13.getLegendItem((-1), 100);
    var13.setBaseShapesFilled(false);
    java.awt.Paint var20 = var13.getSeriesOutlinePaint((-1));
    boolean var21 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.title.TextTitle var22 = var12.getTitle();
    org.jfree.chart.renderer.category.StackedAreaRenderer var24 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var25 = var24.getEndType();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var29 = var26.getLegendItem((-1), 100);
    var26.setBaseShapesFilled(false);
    java.awt.Paint var34 = var26.getItemOutlinePaint(10, 1);
    java.awt.Paint var36 = var26.getSeriesOutlinePaint(10);
    var26.setAutoPopulateSeriesShape(false);
    boolean var39 = var24.equals((java.lang.Object)var26);
    java.awt.Paint var42 = var24.getItemPaint(1, 0);
    var22.setPaint(var42);
    java.awt.Paint var44 = null;
    var22.setBackgroundPaint(var44);
    boolean var46 = var22.getExpandToFitSpace();
    boolean var47 = var22.getExpandToFitSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test191"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.axis.CategoryAnchor var39 = var38.getDomainGridlinePosition();
    org.jfree.data.category.CategoryDataset var40 = var38.getDataset();
    org.jfree.chart.LegendItemCollection var41 = var38.getLegendItems();
    var38.clearDomainAxes();
    org.jfree.chart.plot.CategoryMarker var44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Paint var45 = var44.getLabelPaint();
    java.lang.Comparable var46 = var44.getKey();
    java.lang.String var47 = var44.getLabel();
    java.awt.Stroke var48 = var44.getOutlineStroke();
    var38.addDomainMarker(var44);
    org.jfree.chart.block.BorderArrangement var50 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var52.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var56 = var52.getBaseLinesVisible();
    java.lang.Boolean var58 = var52.getSeriesVisibleInLegend(10);
    java.awt.Paint var59 = var52.getBaseItemLabelPaint();
    java.awt.Color var62 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var63 = null;
    float[] var64 = var62.getRGBColorComponents(var63);
    var52.setBaseItemLabelPaint((java.awt.Paint)var62);
    org.jfree.chart.renderer.category.StackedAreaRenderer var67 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var68 = var67.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var69 = var67.getBaseNegativeItemLabelPosition();
    var52.setBasePositiveItemLabelPosition(var69, true);
    var51.setPositiveItemLabelPositionFallback(var69);
    boolean var73 = var50.equals((java.lang.Object)var51);
    int var74 = var38.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var51);
    java.awt.Stroke var75 = var38.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var76 = null;
    org.jfree.chart.plot.RingPlot var77 = new org.jfree.chart.plot.RingPlot(var76);
    org.jfree.chart.plot.Plot var78 = var77.getRootPlot();
    org.jfree.chart.JFreeChart var79 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var77);
    boolean var80 = var79.getAntiAlias();
    org.jfree.chart.util.RectangleInsets var81 = var79.getPadding();
    double var83 = var81.extendHeight(10.0d);
    double var85 = var81.calculateRightInset(3.0d);
    var38.setAxisOffset(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + true+ "'", var46.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test192"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var2 = var1.getEndType();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var6 = var3.getLegendItem((-1), 100);
    var3.setBaseShapesFilled(false);
    java.awt.Paint var11 = var3.getItemOutlinePaint(10, 1);
    java.awt.Paint var13 = var3.getSeriesOutlinePaint(10);
    var3.setAutoPopulateSeriesShape(false);
    boolean var16 = var1.equals((java.lang.Object)var3);
    java.lang.Boolean var18 = var3.getSeriesCreateEntities(2);
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    org.jfree.chart.plot.Plot var21 = var20.getRootPlot();
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var20);
    org.jfree.chart.plot.CategoryMarker var24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var25 = var24.getOutlineStroke();
    var22.setBorderStroke(var25);
    var3.setBaseOutlineStroke(var25, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test193"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
    java.awt.Stroke var11 = var7.getItemStroke(0, 0);
    var0.setRangeZeroBaselineStroke(var11);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var0.getDomainMarkers(var13);
    org.jfree.chart.util.RectangleInsets var15 = var0.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
    java.awt.Stroke var21 = var17.getItemStroke(0, 0);
    var0.setDomainZeroBaselineStroke(var21);
    org.jfree.chart.util.RectangleEdge var24 = var0.getDomainAxisEdge(1);
    org.jfree.data.xy.XYDataset var25 = null;
    var0.setDataset(var25);
    int var27 = var0.getBackgroundImageAlignment();
    org.jfree.chart.axis.AxisSpace var28 = var0.getFixedRangeAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test194"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var2 = var0.getSeriesBarWidth((-457));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test195"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("-100,0,0,0,0,100,0,100,0,0,100,0,100,0,0,0,0,-100,0,-100,0,0,-100,0,-100,0");
    boolean var3 = var1.isHiddenValue(1L);
    java.awt.Shape var4 = var1.getDownArrow();
    org.jfree.chart.entity.TickLabelEntity var7 = new org.jfree.chart.entity.TickLabelEntity(var4, "Pie Plot", "");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test196"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, Double.NaN, Double.NaN);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var14 = var12.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var17 = new org.jfree.chart.entity.CategoryItemEntity(var2, "hi!", "", (org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var21 = var18.getLegendItem((-1), 100);
//     var18.setBaseShapesFilled(false);
//     java.awt.Paint var25 = var18.getSeriesOutlinePaint((-1));
//     java.awt.Paint var27 = var18.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic(var2, var27);
//     org.jfree.chart.entity.LegendItemEntity var29 = new org.jfree.chart.entity.LegendItemEntity(var2);
//     java.lang.Comparable var30 = var29.getSeriesKey();
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var35 = var32.getLegendItem((-1), 100);
//     var32.setBaseShapesFilled(false);
//     java.awt.Paint var39 = var32.getSeriesOutlinePaint((-1));
//     java.awt.Paint var41 = var32.lookupSeriesOutlinePaint(0);
//     var31.setLabelPaint(var41);
//     double var43 = var31.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var46 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var49 = var46.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var50 = null;
//     org.jfree.chart.plot.RingPlot var51 = new org.jfree.chart.plot.RingPlot(var50);
//     org.jfree.chart.plot.Plot var52 = var51.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var53 = null;
//     var51.axisChanged(var53);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("hi!", var49, (org.jfree.chart.plot.Plot)var51, true);
//     java.awt.Paint var57 = var51.getBackgroundPaint();
//     java.awt.Paint var58 = var51.getLabelOutlinePaint();
//     var31.setTickMarkPaint(var58);
//     java.text.DateFormat var62 = null;
//     org.jfree.chart.axis.DateTickUnit var63 = new org.jfree.chart.axis.DateTickUnit(2, 1, var62);
//     var31.setTickUnit(var63, false, false);
//     var29.setSeriesKey((java.lang.Comparable)var63);
//     var29.setSeriesKey((java.lang.Comparable)"hi!");
//     org.jfree.data.gantt.TaskSeries var71 = new org.jfree.data.gantt.TaskSeries("");
//     java.lang.Comparable var72 = var71.getKey();
//     boolean var73 = var71.getNotify();
//     java.lang.String[] var75 = new java.lang.String[] { "org.jfree.data.UnknownKeyException: org.jfree.chart.event.RendererChangeEvent[source=false]"};
//     java.lang.Number[][] var76 = null;
//     java.lang.Number[] var77 = null;
//     java.lang.Number[][] var78 = new java.lang.Number[][] { var77};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var79 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var75, var76, var78);
//     var71.addChangeListener((org.jfree.data.general.SeriesChangeListener)var79);
//     java.util.List var81 = var79.getRowKeys();
//     java.util.List var82 = var79.getRowKeys();
//     var29.setDataset((org.jfree.data.general.Dataset)var79);
//     org.jfree.data.general.SeriesChangeEvent var85 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)'4');
//     java.lang.String var86 = var85.toString();
//     var79.seriesChanged(var85);
//     int var88 = var79.getCategoryCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var72 + "' != '" + ""+ "'", var72.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var86 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=4]"+ "'", var86.equals("org.jfree.data.general.SeriesChangeEvent[source=4]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 0);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test197"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem((-1), 100);
    var0.setBaseShapesFilled(false);
    java.awt.Paint var8 = var0.getItemOutlinePaint(10, 1);
    java.lang.Object var9 = var0.clone();
    double var10 = var0.getItemLabelAnchorOffset();
    int var11 = var0.getPassCount();
    java.lang.Boolean var13 = var0.getSeriesShapesFilled(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test198"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getBaseSectionPaint();
    double var3 = var1.getMaximumLabelWidth();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.JFreeChart var5 = var4.getChart();
    org.jfree.chart.plot.Plot var6 = var4.getPlot();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    double var8 = var7.getLabelAngle();
    org.jfree.chart.plot.Plot var9 = var7.getPlot();
    java.text.DateFormat var10 = var7.getDateFormatOverride();
    org.jfree.chart.axis.Timeline var11 = var7.getTimeline();
    java.text.DateFormat var12 = var7.getDateFormatOverride();
    var7.setRange(8.0d, Double.NaN);
    org.jfree.chart.event.AxisChangeEvent var16 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var7);
    var6.axisChanged(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test199"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var4 = var3.isTickMarksVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(1.0d, 100.0d);
    var3.setRangeWithMargins(var7, false, false);
    var1.setRangeWithMargins(var7);
    var1.configure();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var15 = var14.getTickLabelPaint();
    java.awt.Shape var16 = var14.getDownArrow();
    var14.setUpperMargin(0.2d);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D("");
    var20.configure();
    org.jfree.chart.axis.NumberTickUnit var22 = var20.getTickUnit();
    org.jfree.chart.text.TextLine var23 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("PlotOrientation.VERTICAL");
    var23.addFragment(var25);
    int var27 = var22.compareTo((java.lang.Object)var23);
    var14.setTickUnit(var22);
    var1.setTickUnit(var22);
    java.lang.String var31 = var22.valueToString(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "1"+ "'", var31.equals("1"));

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test200"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, Double.NaN, Double.NaN);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var14 = var12.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var17 = new org.jfree.chart.entity.CategoryItemEntity(var2, "hi!", "", (org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var21 = var18.getLegendItem((-1), 100);
//     var18.setBaseShapesFilled(false);
//     java.awt.Paint var25 = var18.getSeriesOutlinePaint((-1));
//     java.awt.Paint var27 = var18.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic(var2, var27);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     org.jfree.chart.plot.Plot var31 = var30.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getInsets();
//     double var34 = var32.calculateBottomOutset(100.0d);
//     var28.setPadding(var32);
//     org.jfree.chart.util.RectangleInsets var36 = var28.getMargin();
//     var28.setShapeFilled(false);
//     java.awt.Stroke var39 = var28.getOutlineStroke();
//     java.lang.Object var40 = var28.clone();
//     java.lang.Object var41 = var28.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test201"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.configure();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setFixedAutoRange(0.2d);
    var1.setLabelAngle(0.0d);
    org.jfree.chart.axis.MarkerAxisBand var8 = var1.getMarkerBand();
    boolean var9 = var1.isAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test202"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    int var2 = var0.getMaximumCategoryLabelLines();
    org.jfree.data.time.SimpleTimePeriod var5 = new org.jfree.data.time.SimpleTimePeriod((-1L), 10L);
    java.util.Date var6 = var5.getStart();
    java.util.Date var7 = var5.getEnd();
    var0.removeCategoryLabelToolTip((java.lang.Comparable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test203"); }
// 
// 
//     org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("");
//     var1.fireSeriesChanged();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var5.setUpperMargin(0.0d);
//     int var8 = var5.getMaximumCategoryLabelLines();
//     java.lang.Object var9 = var5.clone();
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var14 = var11.getLegendItem((-1), 100);
//     var11.setBaseShapesFilled(false);
//     java.awt.Paint var18 = var11.getSeriesOutlinePaint((-1));
//     java.awt.Paint var20 = var11.lookupSeriesOutlinePaint(0);
//     var10.setLabelPaint(var20);
//     double var22 = var10.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var26 = var23.getLegendItem(2, 0);
//     double var27 = var23.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var30 = var23.getPositiveItemLabelPosition(2, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var34 = var31.getLegendItem((-1), 100);
//     var31.setBaseShapesFilled(false);
//     java.awt.Paint var39 = var31.getItemOutlinePaint(10, 1);
//     var23.setErrorIndicatorPaint(var39);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var3, var5, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     var41.setRangeCrosshairValue(50.5d);
//     org.jfree.chart.axis.CategoryAxis var45 = var41.getDomainAxis(0);
//     var41.setDrawSharedDomainAxis(true);
//     org.jfree.chart.util.SortOrder var48 = var41.getColumnRenderingOrder();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var49 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var51 = var49.getRangeLowerBound(false);
//     org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var55 = var54.getMaximumDate();
//     org.jfree.data.time.Year var56 = new org.jfree.data.time.Year();
//     java.lang.String var57 = var56.toString();
//     var49.add(90.0d, 0.25d, (java.lang.Comparable)var55, (java.lang.Comparable)var56);
//     boolean var59 = var48.equals((java.lang.Object)var56);
//     var1.setKey((java.lang.Comparable)var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "2014"+ "'", var57.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test204"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     java.util.List var2 = var1.getGroups();
//     org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     double var5 = var4.getLabelAngle();
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var10 = var7.getLegendItem((-1), 100);
//     var7.setBaseShapesFilled(false);
//     java.awt.Paint var14 = var7.getSeriesOutlinePaint((-1));
//     java.awt.Paint var16 = var7.lookupSeriesOutlinePaint(0);
//     var6.setLabelPaint(var16);
//     org.jfree.chart.axis.DateTickMarkPosition var18 = var6.getTickMarkPosition();
//     var4.setTickMarkPosition(var18);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var22 = var21.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var23 = var21.getBaseNegativeItemLabelPosition();
//     boolean var24 = var4.equals((java.lang.Object)var23);
//     boolean var25 = var1.equals((java.lang.Object)var4);
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var30 = var27.getLegendItem((-1), 100);
//     var27.setBaseShapesFilled(false);
//     java.awt.Paint var34 = var27.getSeriesOutlinePaint((-1));
//     java.awt.Paint var36 = var27.lookupSeriesOutlinePaint(0);
//     var26.setLabelPaint(var36);
//     boolean var38 = var26.isNegativeArrowVisible();
//     org.jfree.data.Range var41 = new org.jfree.data.Range(1.0d, 100.0d);
//     java.lang.String var42 = var41.toString();
//     org.jfree.data.Range var44 = org.jfree.data.Range.shift(var41, 0.0d);
//     var26.setRange(var44);
//     org.jfree.data.time.Month var46 = new org.jfree.data.time.Month();
//     long var47 = var46.getSerialIndex();
//     java.util.Date var48 = var46.getEnd();
//     org.jfree.data.time.Month var49 = new org.jfree.data.time.Month();
//     long var50 = var49.getSerialIndex();
//     java.util.Date var51 = var49.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var52 = new org.jfree.data.time.SimpleTimePeriod(var48, var51);
//     var26.setMaximumDate(var48);
//     org.jfree.chart.axis.NumberAxis3D var55 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var56 = var55.getTickLabelPaint();
//     org.jfree.chart.axis.NumberAxis3D var58 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D("");
//     boolean var61 = var60.isTickMarksVisible();
//     org.jfree.data.Range var64 = new org.jfree.data.Range(1.0d, 100.0d);
//     var60.setRangeWithMargins(var64, false, false);
//     var58.setRangeWithMargins(var64);
//     var55.setDefaultAutoRange(var64);
//     org.jfree.chart.block.RectangleConstraint var71 = new org.jfree.chart.block.RectangleConstraint(var64, 10.0d);
//     var26.setRangeWithMargins(var64);
//     var4.setRange(var64, false, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "Range[1.0,100.0]"+ "'", var42.equals("Range[1.0,100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test205"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var7.axisChanged(var9);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
    java.lang.Object var13 = var7.clone();
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var14, var15, 100.0d, 10.0d);
    var18.clear();
    org.jfree.chart.block.Arrangement var20 = null;
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var18, var20);
    org.jfree.data.UnknownKeyException var23 = new org.jfree.data.UnknownKeyException("");
    java.lang.Throwable[] var24 = var23.getSuppressed();
    java.lang.Throwable[] var25 = var23.getSuppressed();
    boolean var26 = var21.equals((java.lang.Object)var25);
    org.jfree.chart.util.RectangleInsets var27 = var21.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var28 = var21.getVerticalAlignment();
    org.jfree.chart.LegendItemSource[] var29 = var21.getSources();
    org.jfree.chart.block.BlockFrame var30 = var21.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test206"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.util.RectangleInsets var6 = var0.getAxisOffset();
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.CrosshairState var11 = null;
    boolean var12 = var0.render(var7, var8, 1, var10, var11);
    org.jfree.chart.renderer.category.StackedAreaRenderer var14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var15 = var14.getEndType();
    java.awt.Stroke var18 = var14.getItemStroke(0, 0);
    var0.setDomainGridlineStroke(var18);
    int var20 = var0.getSeriesCount();
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
    org.jfree.chart.plot.Plot var23 = var22.getRootPlot();
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
    boolean var25 = var24.getAntiAlias();
    org.jfree.chart.util.RectangleInsets var26 = var24.getPadding();
    double var28 = var26.extendHeight(10.0d);
    var0.setAxisOffset(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 10.0d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test207"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    var0.setAdjustForDaylightSaving(true);
    long var5 = var0.getExceptionSegmentCount(1L, 0L);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var6 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
    org.jfree.chart.util.RectangleInsets var10 = var8.getInsets();
    java.awt.Stroke var11 = var8.getLabelOutlineStroke();
    java.awt.Paint var12 = var8.getLabelShadowPaint();
    boolean var13 = var6.equals((java.lang.Object)var8);
    boolean var14 = var8.isCircular();
    boolean var15 = var0.equals((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test208"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getLabelLinkMargin();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var2.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var6 = var2.getBaseLinesVisible();
    java.lang.Boolean var8 = var2.getSeriesVisibleInLegend(10);
    java.awt.Paint var9 = var2.getBaseItemLabelPaint();
    java.awt.Color var12 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var13 = null;
    float[] var14 = var12.getRGBColorComponents(var13);
    var2.setBaseItemLabelPaint((java.awt.Paint)var12);
    int var16 = var12.getRGB();
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
    var19.configure();
    org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
    var17.setAxisOffset(var21);
    org.jfree.chart.plot.CategoryMarker var24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var25 = var24.getOutlineStroke();
    var17.addDomainMarker((org.jfree.chart.plot.Marker)var24);
    java.awt.geom.Point2D var27 = var17.getQuadrantOrigin();
    org.jfree.chart.plot.DatasetRenderingOrder var28 = var17.getDatasetRenderingOrder();
    var17.setDomainCrosshairValue(1.0d, true);
    java.awt.Paint var32 = var17.getDomainGridlinePaint();
    org.jfree.data.category.CategoryDataset var33 = null;
    org.jfree.chart.plot.MultiplePiePlot var34 = new org.jfree.chart.plot.MultiplePiePlot(var33);
    java.awt.Paint var35 = var34.getAggregatedItemsPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var36.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var40 = var36.getBaseLinesVisible();
    java.lang.Boolean var42 = var36.getSeriesVisibleInLegend(10);
    java.awt.Paint var43 = var36.getBaseItemLabelPaint();
    java.awt.Color var46 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var47 = null;
    float[] var48 = var46.getRGBColorComponents(var47);
    var36.setBaseItemLabelPaint((java.awt.Paint)var46);
    int var50 = var46.getGreen();
    java.lang.String var51 = var46.toString();
    java.awt.Color var54 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var55 = null;
    float[] var56 = var54.getRGBColorComponents(var55);
    float[] var57 = var46.getRGBColorComponents(var56);
    org.jfree.chart.renderer.category.WaterfallBarRenderer var58 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint)var12, var32, var35, (java.awt.Paint)var46);
    var0.setLabelShadowPaint((java.awt.Paint)var12);
    org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.event.AxisChangeListener var62 = null;
    var61.removeChangeListener(var62);
    java.text.NumberFormat var64 = var61.getNumberFormatOverride();
    java.awt.Paint var65 = var61.getTickMarkPaint();
    var0.setLabelShadowPaint(var65);
    org.jfree.chart.labels.PieSectionLabelGenerator var67 = var0.getLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-16777206));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "java.awt.Color[r=0,g=0,b=10]"+ "'", var51.equals("java.awt.Color[r=0,g=0,b=10]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test209"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, Double.NaN, Double.NaN);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var13 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var15 = var13.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var18 = new org.jfree.chart.entity.CategoryItemEntity(var3, "hi!", "", (org.jfree.data.category.CategoryDataset)var13, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var22 = var19.getLegendItem((-1), 100);
//     var19.setBaseShapesFilled(false);
//     java.awt.Paint var26 = var19.getSeriesOutlinePaint((-1));
//     java.awt.Paint var28 = var19.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var29 = new org.jfree.chart.title.LegendGraphic(var3, var28);
//     org.jfree.chart.entity.LegendItemEntity var30 = new org.jfree.chart.entity.LegendItemEntity(var3);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 12.0d, 1.0f, 10.0f);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test210"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = new org.jfree.chart.LegendItemCollection();
    int var2 = var1.getItemCount();
    var0.setFixedLegendItems(var1);
    org.jfree.chart.axis.AxisLocation var5 = var0.getRangeAxisLocation(10);
    org.jfree.chart.axis.AxisLocation var6 = org.jfree.chart.axis.AxisLocation.getOpposite(var5);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var9.setUpperMargin(0.0d);
    int var12 = var9.getMaximumCategoryLabelLines();
    java.lang.Object var13 = var9.clone();
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var18 = var15.getLegendItem((-1), 100);
    var15.setBaseShapesFilled(false);
    java.awt.Paint var22 = var15.getSeriesOutlinePaint((-1));
    java.awt.Paint var24 = var15.lookupSeriesOutlinePaint(0);
    var14.setLabelPaint(var24);
    double var26 = var14.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var30 = var27.getLegendItem(2, 0);
    double var31 = var27.getBase();
    org.jfree.chart.labels.ItemLabelPosition var34 = var27.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var38 = var35.getLegendItem((-1), 100);
    var35.setBaseShapesFilled(false);
    java.awt.Paint var43 = var35.getItemOutlinePaint(10, 1);
    var27.setErrorIndicatorPaint(var43);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var7, var9, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var27);
    var45.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.CategoryAxis var49 = var45.getDomainAxis(0);
    var45.setDrawSharedDomainAxis(true);
    org.jfree.chart.plot.PlotRenderingInfo var54 = null;
    org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D("");
    var57.configure();
    org.jfree.chart.util.RectangleInsets var59 = var57.getLabelInsets();
    var55.setAxisOffset(var59);
    org.jfree.chart.plot.CategoryMarker var62 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var63 = var62.getOutlineStroke();
    var55.addDomainMarker((org.jfree.chart.plot.Marker)var62);
    java.awt.geom.Point2D var65 = var55.getQuadrantOrigin();
    var45.zoomRangeAxes(0.0d, 90.0d, var54, var65);
    java.awt.Stroke var67 = var45.getRangeGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var69 = var45.getDomainAxisForDataset(10);
    org.jfree.chart.plot.PlotOrientation var70 = var45.getOrientation();
    org.jfree.chart.util.RectangleEdge var71 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var6, var70);
    java.lang.String var72 = var70.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var72.equals("PlotOrientation.VERTICAL"));

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test211"); }
// 
// 
//     org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(false);
//     int var2 = var1.getColumnCount();
//     org.jfree.data.DefaultKeyedValues var3 = new org.jfree.data.DefaultKeyedValues();
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var6.setUpperMargin(0.0d);
//     int var9 = var6.getMaximumCategoryLabelLines();
//     java.lang.Object var10 = var6.clone();
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var15 = var12.getLegendItem((-1), 100);
//     var12.setBaseShapesFilled(false);
//     java.awt.Paint var19 = var12.getSeriesOutlinePaint((-1));
//     java.awt.Paint var21 = var12.lookupSeriesOutlinePaint(0);
//     var11.setLabelPaint(var21);
//     double var23 = var11.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var27 = var24.getLegendItem(2, 0);
//     double var28 = var24.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var31 = var24.getPositiveItemLabelPosition(2, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var35 = var32.getLegendItem((-1), 100);
//     var32.setBaseShapesFilled(false);
//     java.awt.Paint var40 = var32.getItemOutlinePaint(10, 1);
//     var24.setErrorIndicatorPaint(var40);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var4, var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
//     var42.setRangeCrosshairValue(50.5d);
//     org.jfree.chart.axis.CategoryAxis var46 = var42.getDomainAxis(0);
//     var42.setDrawSharedDomainAxis(true);
//     org.jfree.chart.util.SortOrder var49 = var42.getColumnRenderingOrder();
//     var3.sortByValues(var49);
//     org.jfree.data.time.Month var51 = new org.jfree.data.time.Month();
//     long var52 = var51.getSerialIndex();
//     java.util.Date var53 = var51.getEnd();
//     var3.setValue((java.lang.Comparable)var53, (java.lang.Number)1.0E-5d);
//     int var56 = var1.getColumnIndex((java.lang.Comparable)var53);
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
//     var57.setDomainCrosshairValue(0.05d);
//     java.awt.Paint var60 = var57.getDomainCrosshairPaint();
//     org.jfree.data.general.PieDataset var61 = null;
//     org.jfree.chart.plot.RingPlot var62 = new org.jfree.chart.plot.RingPlot(var61);
//     java.awt.Paint var63 = var62.getBaseSectionPaint();
//     boolean var64 = var62.isOutlineVisible();
//     java.awt.Color var68 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var69 = null;
//     float[] var70 = var68.getRGBColorComponents(var69);
//     var62.setSectionOutlinePaint((java.lang.Comparable)"", (java.awt.Paint)var68);
//     java.awt.Color var74 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var75 = null;
//     float[] var76 = var74.getRGBColorComponents(var75);
//     float[] var77 = var68.getRGBComponents(var75);
//     var57.setOutlinePaint((java.awt.Paint)var68);
//     int var79 = var68.getRed();
//     boolean var80 = var1.equals((java.lang.Object)var68);
//     int var81 = var1.getRowCount();
//     int var82 = var1.getColumnCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 0);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test212"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test213"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, 0.0f, 1.0f, var4, (-1.0f), (-1.0f), 3.0d);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var0.calculateBounds(var9, (-1.0f), 0.5f, var12, 100.0f, (-1.0f), 4.0d);
    java.awt.Color var19 = java.awt.Color.getColor("ThreadContext", 10);
    org.jfree.chart.title.LegendGraphic var20 = new org.jfree.chart.title.LegendGraphic(var16, (java.awt.Paint)var19);
    java.awt.Paint var21 = var20.getLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test214"); }


    org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod((-1L), 10L);
    org.jfree.chart.text.TextBlock var3 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.text.TextBlockAnchor var7 = null;
    var3.draw(var4, 0.0f, 1.0f, var7, (-1.0f), (-1.0f), 3.0d);
    org.jfree.chart.util.HorizontalAlignment var12 = var3.getLineAlignment();
    org.jfree.chart.text.TextBlockAnchor var13 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var17 = var14.getLegendItem((-1), 100);
    var14.setBaseShapesFilled(false);
    java.awt.Paint var21 = var14.getSeriesOutlinePaint((-1));
    org.jfree.chart.renderer.category.StackedAreaRenderer var23 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var24 = var23.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var25 = var23.getBaseNegativeItemLabelPosition();
    var14.setBaseNegativeItemLabelPosition(var25);
    org.jfree.chart.text.TextAnchor var27 = var25.getTextAnchor();
    org.jfree.chart.axis.CategoryTick var29 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)10L, var3, var13, var27, 1.0d);
    double var30 = var29.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test215"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    java.awt.Paint var1 = var0.getArtifactPaint();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    var4.configure();
    org.jfree.chart.util.RectangleInsets var6 = var4.getLabelInsets();
    var2.setAxisOffset(var6);
    org.jfree.chart.renderer.category.StackedAreaRenderer var9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var10 = var9.getEndType();
    java.awt.Stroke var13 = var9.getItemStroke(0, 0);
    var2.setRangeZeroBaselineStroke(var13);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var2.getDomainMarkers(var15);
    var2.setForegroundAlpha(100.0f);
    var2.setRangeCrosshairVisible(true);
    boolean var21 = var2.isRangeZoomable();
    org.jfree.chart.util.RectangleEdge var23 = var2.getDomainAxisEdge(1);
    boolean var24 = var0.hasListener((java.util.EventListener)var2);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var26 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot(var27);
    org.jfree.chart.plot.Plot var29 = var28.getRootPlot();
    org.jfree.chart.util.RectangleInsets var30 = var28.getInsets();
    java.awt.Stroke var31 = var28.getLabelOutlineStroke();
    java.awt.Paint var32 = var28.getLabelShadowPaint();
    boolean var33 = var26.equals((java.lang.Object)var28);
    var0.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var26, true);
    java.awt.Paint var38 = var0.getItemFillPaint(7, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test216"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(1.0d, 100.0d);
    double var3 = var2.getCentralValue();
    double var4 = var2.getUpperBound();
    org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange(var2);
    java.util.Date var6 = var5.getUpperDate();
    java.util.Date var7 = var5.getUpperDate();
    java.util.Date var8 = var5.getUpperDate();
    java.util.Date var9 = var5.getUpperDate();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 50.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test217"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.renderer.category.StackedAreaRenderer var3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var6 = var3.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var8.axisChanged(var10);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", var6, (org.jfree.chart.plot.Plot)var8, true);
    java.lang.Object var14 = var8.clone();
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.FlowArrangement var19 = new org.jfree.chart.block.FlowArrangement(var15, var16, 100.0d, 10.0d);
    var19.clear();
    org.jfree.chart.block.Arrangement var21 = null;
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8, (org.jfree.chart.block.Arrangement)var19, var21);
    org.jfree.data.UnknownKeyException var24 = new org.jfree.data.UnknownKeyException("");
    java.lang.Throwable[] var25 = var24.getSuppressed();
    java.lang.Throwable[] var26 = var24.getSuppressed();
    boolean var27 = var22.equals((java.lang.Object)var26);
    org.jfree.chart.util.RectangleInsets var28 = var22.getItemLabelPadding();
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(50.5d, 10.0d);
    double var33 = var32.getWidth();
    org.jfree.chart.util.Size2D var34 = var22.arrange(var29, var32);
    org.jfree.chart.util.RectangleEdge var35 = var22.getLegendItemGraphicEdge();
    boolean var36 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var35);
    org.jfree.chart.axis.CategoryLabelPosition var37 = var0.getLabelPosition(var35);
    org.jfree.chart.text.TextBlockAnchor var38 = var37.getLabelAnchor();
    float var39 = var37.getWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 50.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.95f);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test218"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
    double var42 = var41.getLeft();
    var38.setFixedRangeAxisSpace(var41);
    org.jfree.chart.axis.AxisSpace var44 = new org.jfree.chart.axis.AxisSpace();
    double var45 = var44.getLeft();
    var38.setFixedRangeAxisSpace(var44);
    var38.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.Layer var50 = null;
    java.util.Collection var51 = var38.getDomainMarkers(100, var50);
    org.jfree.chart.util.RectangleInsets var52 = var38.getInsets();
    org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var55 = var54.getTickLabelPaint();
    java.awt.Shape var56 = var54.getUpArrow();
    boolean var57 = var54.isAxisLineVisible();
    double var58 = var54.getAutoRangeMinimumSize();
    org.jfree.data.Range var59 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var54);
    org.jfree.chart.axis.AxisLocation var61 = var38.getRangeAxisLocation((-457));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test219"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)"");
    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0E-5d, false);
    boolean var7 = var0.equals((java.lang.Object)var6);
    boolean var9 = var6.isSeriesVisibleInLegend(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test220"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var4 = var0.getBaseLinesVisible();
    java.lang.Boolean var6 = var0.getSeriesVisibleInLegend(10);
    java.awt.Paint var7 = var0.getBaseItemLabelPaint();
    java.awt.Color var10 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var11 = null;
    float[] var12 = var10.getRGBColorComponents(var11);
    var0.setBaseItemLabelPaint((java.awt.Paint)var10);
    org.jfree.chart.renderer.category.StackedAreaRenderer var15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var16 = var15.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getBaseNegativeItemLabelPosition();
    var0.setBasePositiveItemLabelPosition(var17, true);
    org.jfree.chart.labels.ItemLabelAnchor var20 = var17.getItemLabelAnchor();
    org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var22 = null;
    org.jfree.chart.util.VerticalAlignment var23 = null;
    org.jfree.chart.block.FlowArrangement var26 = new org.jfree.chart.block.FlowArrangement(var22, var23, Double.NaN, 4.0d);
    org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var32 = var26.arrange(var27, var28, var31);
    var27.clear();
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(50.5d, 10.0d);
    org.jfree.chart.util.Size2D var38 = var21.arrange(var27, var34, var37);
    double var39 = var37.getWidth();
    org.jfree.chart.block.LengthConstraintType var40 = var37.getHeightConstraintType();
    boolean var41 = var20.equals((java.lang.Object)var40);
    java.lang.String var42 = var20.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 50.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "ItemLabelAnchor.OUTSIDE6"+ "'", var42.equals("ItemLabelAnchor.OUTSIDE6"));

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test221"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test222"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    double var1 = var0.getLeft();
    org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
    double var3 = var2.getLeft();
    var0.ensureAtLeast(var2);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    var8.configure();
    org.jfree.chart.util.RectangleInsets var10 = var8.getLabelInsets();
    var6.setAxisOffset(var10);
    org.jfree.chart.renderer.category.StackedAreaRenderer var13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var14 = var13.getEndType();
    java.awt.Stroke var17 = var13.getItemStroke(0, 0);
    var6.setRangeZeroBaselineStroke(var17);
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var6.getDomainMarkers(var19);
    var6.setForegroundAlpha(100.0f);
    var6.setRangeCrosshairVisible(true);
    boolean var25 = var6.isRangeZoomable();
    org.jfree.chart.util.RectangleEdge var27 = var6.getDomainAxisEdge(1);
    var2.add(0.0d, var27);
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    boolean var31 = var30.isRangeGridlinesVisible();
    java.awt.Paint var32 = var30.getRangeTickBandPaint();
    java.lang.Object var33 = var30.clone();
    org.jfree.chart.util.RectangleEdge var35 = var30.getRangeAxisEdge(1);
    var2.ensureAtLeast(12.0d, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test223"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var4 = var0.getBaseLinesVisible();
    java.lang.Boolean var6 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    var0.setSeriesItemLabelGenerator(3, var8, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test224"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem((-16777206), (-457));
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var6 = var5.getTickLabelPaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var10 = var7.getLegendItem(2, 0);
    double var11 = var7.getBase();
    java.awt.Color var14 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var15 = null;
    float[] var16 = var14.getRGBColorComponents(var15);
    java.awt.Color var19 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var20 = null;
    float[] var21 = var19.getRGBColorComponents(var20);
    float[] var22 = var14.getColorComponents(var20);
    var7.setErrorIndicatorPaint((java.awt.Paint)var14);
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    var26.configure();
    org.jfree.chart.util.RectangleInsets var28 = var26.getLabelInsets();
    var24.setAxisOffset(var28);
    org.jfree.chart.plot.CategoryMarker var31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var32 = var31.getOutlineStroke();
    var24.addDomainMarker((org.jfree.chart.plot.Marker)var31);
    java.awt.geom.Point2D var34 = var24.getQuadrantOrigin();
    java.awt.Paint var35 = var24.getDomainCrosshairPaint();
    org.jfree.chart.renderer.category.StackedAreaRenderer var37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var38 = var37.getEndType();
    java.awt.Paint var39 = var37.getBaseFillPaint();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var40 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var6, (java.awt.Paint)var14, var35, var39);
    var0.setArtifactPaint(var6);
    double var42 = var0.getItemMargin();
    java.awt.Paint var43 = var0.getArtifactPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test225"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem(2, 0);
    double var4 = var0.getBase();
    org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPosition(2, (-1));
    double var8 = var0.getMaximumBarWidth();
    double var9 = var0.getBase();
    boolean var10 = var0.getIncludeBaseInRange();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
    java.awt.Paint var14 = var13.getErrorIndicatorPaint();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var15 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    var13.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var15);
    var0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var15);
    org.jfree.data.category.DefaultCategoryDataset var18 = new org.jfree.data.category.DefaultCategoryDataset();
    int var19 = var18.getColumnCount();
    org.jfree.data.Range var20 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var18);
    java.awt.Stroke var22 = var0.lookupSeriesStroke(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test226"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.labels.PieSectionLabelGenerator var4 = var1.getLegendLabelGenerator();
//     org.jfree.chart.util.Rotation var5 = var1.getDirection();
//     java.awt.Shape var6 = var1.getLegendItemShape();
//     double var7 = var1.getLabelLinkMargin();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     
//     // Checks the contract:  equals-hashcode on var3 and var8
//     assertTrue("Contract failed: equals-hashcode on var3 and var8", var3.equals(var8) ? var3.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var3
//     assertTrue("Contract failed: equals-hashcode on var8 and var3", var8.equals(var3) ? var8.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test227"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, Double.NaN, Double.NaN);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var14 = var12.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var17 = new org.jfree.chart.entity.CategoryItemEntity(var2, "hi!", "", (org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     java.lang.Comparable var18 = var17.getRowKey();
//     java.lang.Comparable var19 = var17.getRowKey();
//     var17.setURLText("DateTickMarkPosition.START");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var22 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var23 = null;
//     java.lang.String var24 = var17.getImageMapAreaTag(var22, var23);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test228"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(2.0d, 100.0d);
    double var3 = var2.getYOffset();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    var2.setBaseItemLabelGenerator(var4);
    java.awt.Shape var7 = var2.lookupSeriesShape(5);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.renderer.category.GanttRenderer var9 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var13 = var10.getLegendItem((-1), 100);
    var10.setBaseShapesFilled(false);
    java.awt.Paint var17 = var10.getSeriesOutlinePaint((-1));
    org.jfree.chart.renderer.category.StackedAreaRenderer var19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var20 = var19.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var21 = var19.getBaseNegativeItemLabelPosition();
    var10.setBaseNegativeItemLabelPosition(var21);
    var9.setPositiveItemLabelPositionFallback(var21);
    org.jfree.chart.labels.ItemLabelPosition var25 = var9.getSeriesPositiveItemLabelPosition(0);
    var8.setBasePositiveItemLabelPosition(var25, true);
    var2.setPositiveItemLabelPositionFallback(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test229"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var4 = var3.isTickMarksVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(1.0d, 100.0d);
    var3.setRangeWithMargins(var7, false, false);
    var1.setRangeWithMargins(var7);
    var1.configure();
    boolean var13 = var1.getAutoRangeStickyZero();
    org.jfree.chart.util.RectangleInsets var14 = var1.getTickLabelInsets();
    double var16 = var14.extendWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 8.0d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test230"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.axis.CategoryAnchor var39 = var38.getDomainGridlinePosition();
    org.jfree.data.category.CategoryDataset var40 = var38.getDataset();
    org.jfree.chart.LegendItemCollection var41 = var38.getLegendItems();
    var38.clearDomainAxes();
    org.jfree.chart.util.SortOrder var43 = var38.getRowRenderingOrder();
    boolean var44 = var38.isDomainGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D("#ffff9c");
    boolean var47 = var46.isAxisLineVisible();
    var38.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var46);
    int var49 = var46.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test231"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)"");
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
    org.jfree.chart.plot.Plot var6 = var5.getRootPlot();
    var1.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var6);
    org.jfree.data.KeyToGroupMap var16 = new org.jfree.data.KeyToGroupMap();
    java.util.List var17 = var16.getGroups();
    org.jfree.data.statistics.BoxAndWhiskerItem var18 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)1.0d, (java.lang.Number)100.0f, (java.lang.Number)(short)1, (java.lang.Number)1.0f, (java.lang.Number)(byte)(-1), (java.lang.Number)(-1), (java.lang.Number)(byte)100, var17);
    var1.add(var18, (java.lang.Comparable)0.0f, (java.lang.Comparable)"hi!");
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)false);
    java.lang.Comparable var24 = var23.getSeriesKey();
    double var25 = var23.getContentYOffset();
    org.jfree.chart.util.RectangleInsets var26 = var23.getPadding();
    java.lang.Comparable var27 = var23.getSeriesKey();
    var23.setURLText("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + false+ "'", var24.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + false+ "'", var27.equals(false));

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test232"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, Double.NaN, Double.NaN);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 10.0d, 0.0f, 0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, Double.NaN, Double.NaN);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 0.0f, 0.0f);
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var14, var24);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var28, Double.NaN, Double.NaN);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var38 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var40 = var38.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var43 = new org.jfree.chart.entity.CategoryItemEntity(var28, "hi!", "", (org.jfree.data.category.CategoryDataset)var38, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var47 = var44.getLegendItem((-1), 100);
//     var44.setBaseShapesFilled(false);
//     java.awt.Paint var51 = var44.getSeriesOutlinePaint((-1));
//     java.awt.Paint var53 = var44.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var54 = new org.jfree.chart.title.LegendGraphic(var28, var53);
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.RingPlot var56 = new org.jfree.chart.plot.RingPlot(var55);
//     org.jfree.chart.plot.Plot var57 = var56.getRootPlot();
//     org.jfree.chart.util.RectangleInsets var58 = var56.getInsets();
//     double var60 = var58.calculateBottomOutset(100.0d);
//     var54.setPadding(var58);
//     org.jfree.chart.util.RectangleInsets var62 = var54.getMargin();
//     org.jfree.chart.util.RectangleAnchor var63 = var54.getShapeAnchor();
//     java.lang.Object var64 = var54.clone();
//     org.jfree.chart.util.RectangleAnchor var65 = var54.getShapeAnchor();
//     java.awt.Shape var68 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, var65, 1.0d, Double.NaN);
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var69 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     org.jfree.chart.LegendItem var72 = var69.getLegendItem((-16777206), (-457));
//     java.awt.Paint var73 = var69.getArtifactPaint();
//     org.jfree.chart.LegendItem var74 = new org.jfree.chart.LegendItem("CONTRACT", "org.jfree.data.UnknownKeyException: org.jfree.chart.event.RendererChangeEvent[source=false]", "CategoryAnchor.MIDDLE", "#ffff9c", var68, var73);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var68, 0.0d, (-1.0f), 0.0f);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test233"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-459));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test234"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem(2, 0);
    double var4 = var0.getBase();
    org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var16 = var8.getItemOutlinePaint(10, 1);
    var0.setErrorIndicatorPaint(var16);
    var0.setMaximumBarWidth(8.6399984E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test235"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
    double var3 = var2.getLimit();
    double var4 = var2.getLimit();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)"");
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
    var5.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var10);
    java.lang.Comparable var12 = null;
    java.lang.Number var14 = var5.getMeanValue(var12, (java.lang.Comparable)100.0f);
    var2.setDataset((org.jfree.data.category.CategoryDataset)var5);
    org.jfree.data.Range var16 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Color var20 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var21 = null;
    float[] var22 = var20.getRGBColorComponents(var21);
    java.awt.Color var25 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var26 = null;
    float[] var27 = var25.getRGBColorComponents(var26);
    float[] var28 = var20.getColorComponents(var26);
    var17.setBaseItemLabelPaint((java.awt.Paint)var20);
    var1.setBaseFillPaint((java.awt.Paint)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test236"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var2 = var1.getEndType();
    java.awt.Paint var4 = var1.getSeriesFillPaint((-1));
    var1.setRenderAsPercentages(true);
    org.jfree.chart.LegendItem var9 = var1.getLegendItem(12, (-457));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test237"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
    double var42 = var41.getLeft();
    var38.setFixedRangeAxisSpace(var41);
    int var44 = var38.getWeight();
    org.jfree.chart.plot.PlotOrientation var45 = var38.getOrientation();
    org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis();
    double var47 = var46.getLabelAngle();
    org.jfree.chart.plot.Plot var48 = var46.getPlot();
    java.text.DateFormat var49 = var46.getDateFormatOverride();
    org.jfree.chart.axis.Timeline var50 = var46.getTimeline();
    java.text.DateFormat var51 = var46.getDateFormatOverride();
    var46.setRange(8.0d, Double.NaN);
    org.jfree.chart.event.AxisChangeEvent var55 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var46);
    java.lang.String var56 = var55.toString();
    var38.axisChanged(var55);
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis();
    double var59 = var58.getLabelAngle();
    org.jfree.data.Range var62 = new org.jfree.data.Range(1.0d, 100.0d);
    double var63 = var62.getCentralValue();
    double var64 = var62.getUpperBound();
    var58.setRange(var62, true, false);
    org.jfree.chart.axis.TickUnitSource var68 = var58.getStandardTickUnits();
    boolean var69 = var38.equals((java.lang.Object)var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 50.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test238"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "ThreadContext", "", "hi!");
    var4.setName("2014");
    var4.setVersion("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test239"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    var3.configure();
    org.jfree.chart.util.RectangleInsets var5 = var3.getLabelInsets();
    var1.setAxisOffset(var5);
    org.jfree.chart.renderer.category.StackedAreaRenderer var8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var9 = var8.getEndType();
    java.awt.Stroke var12 = var8.getItemStroke(0, 0);
    var1.setRangeZeroBaselineStroke(var12);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var1.getDomainMarkers(var14);
    org.jfree.chart.util.RectangleInsets var16 = var1.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var18 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var19 = var18.getEndType();
    java.awt.Stroke var22 = var18.getItemStroke(0, 0);
    var1.setDomainZeroBaselineStroke(var22);
    org.jfree.chart.util.RectangleEdge var24 = var1.getDomainAxisEdge();
    double var25 = var1.getRangeCrosshairValue();
    java.lang.String var26 = var1.getNoDataMessage();
    boolean var27 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.plot.DatasetRenderingOrder var28 = var1.getDatasetRenderingOrder();
    org.jfree.chart.axis.AxisLocation var30 = var1.getRangeAxisLocation((-241));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test240"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    int var2 = var0.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test241"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-10.0d), 6.0d);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test242"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.LegendItem var3 = var0.getLegendItem(2, 0);
//     double var4 = var0.getBase();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPosition(2, (-1));
//     double var8 = var0.getMaximumBarWidth();
//     double var9 = var0.getBase();
//     java.awt.Paint var10 = var0.getErrorIndicatorPaint();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var11 = var0.getLegendItemURLGenerator();
//     org.jfree.data.category.DefaultCategoryDataset var12 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var13 = var12.getColumnCount();
//     int var14 = var12.getRowCount();
//     var12.removeColumn((java.lang.Comparable)10.0d);
//     int var17 = var12.getColumnCount();
//     java.lang.Object var18 = var12.clone();
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var24 = var21.getLegendItem((-1), 100);
//     var21.setBaseShapesFilled(false);
//     java.awt.Paint var28 = var21.getSeriesOutlinePaint((-1));
//     java.awt.Paint var30 = var21.lookupSeriesOutlinePaint(0);
//     var20.setLabelPaint(var30);
//     double var32 = var20.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var35 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var38 = var35.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot(var39);
//     org.jfree.chart.plot.Plot var41 = var40.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var42 = null;
//     var40.axisChanged(var42);
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("hi!", var38, (org.jfree.chart.plot.Plot)var40, true);
//     java.awt.Paint var46 = var40.getBackgroundPaint();
//     java.awt.Paint var47 = var40.getLabelOutlinePaint();
//     var20.setTickMarkPaint(var47);
//     java.text.DateFormat var51 = null;
//     org.jfree.chart.axis.DateTickUnit var52 = new org.jfree.chart.axis.DateTickUnit(2, 1, var51);
//     var20.setTickUnit(var52, false, false);
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var57 = var56.getMaximumDate();
//     java.lang.String var58 = var52.dateToString(var57);
//     org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var60 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var63 = var60.getLegendItem((-1), 100);
//     var60.setBaseShapesFilled(false);
//     java.awt.Paint var67 = var60.getSeriesOutlinePaint((-1));
//     java.awt.Paint var69 = var60.lookupSeriesOutlinePaint(0);
//     var59.setLabelPaint(var69);
//     boolean var71 = var59.isNegativeArrowVisible();
//     org.jfree.data.Range var74 = new org.jfree.data.Range(1.0d, 100.0d);
//     java.lang.String var75 = var74.toString();
//     org.jfree.data.Range var77 = org.jfree.data.Range.shift(var74, 0.0d);
//     var59.setRange(var77);
//     org.jfree.data.time.Month var79 = new org.jfree.data.time.Month();
//     long var80 = var79.getSerialIndex();
//     java.util.Date var81 = var79.getEnd();
//     org.jfree.data.time.Month var82 = new org.jfree.data.time.Month();
//     long var83 = var82.getSerialIndex();
//     java.util.Date var84 = var82.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var85 = new org.jfree.data.time.SimpleTimePeriod(var81, var84);
//     var59.setMaximumDate(var81);
//     org.jfree.data.time.Month var87 = new org.jfree.data.time.Month();
//     long var88 = var87.getSerialIndex();
//     java.util.Date var89 = var87.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var90 = new org.jfree.data.time.SimpleTimePeriod(var81, var89);
//     java.util.Date var91 = var52.addToDate(var89);
//     var12.removeValue((java.lang.Comparable)10.0d, (java.lang.Comparable)var89);
//     org.jfree.data.Range var93 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var58 + "' != '" + "12/31/69"+ "'", var58.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var75 + "' != '" + "Range[1.0,100.0]"+ "'", var75.equals("Range[1.0,100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var93);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test243"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    int var1 = var0.getItemCount();
    int var2 = var0.getItemCount();
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var4 = var3.getPlotType();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberTickUnit var7 = var6.getTickUnit();
    java.awt.Paint var8 = var3.getSectionPaint((java.lang.Comparable)var7);
    var0.setValue((java.lang.Comparable)var7, (java.lang.Number)5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var12 = var0.getKey(3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Pie 3D Plot"+ "'", var4.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test244"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var5.setUpperMargin(0.0d);
    int var8 = var5.getMaximumCategoryLabelLines();
    java.lang.Object var9 = var5.clone();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var14 = var11.getLegendItem((-1), 100);
    var11.setBaseShapesFilled(false);
    java.awt.Paint var18 = var11.getSeriesOutlinePaint((-1));
    java.awt.Paint var20 = var11.lookupSeriesOutlinePaint(0);
    var10.setLabelPaint(var20);
    double var22 = var10.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var26 = var23.getLegendItem(2, 0);
    double var27 = var23.getBase();
    org.jfree.chart.labels.ItemLabelPosition var30 = var23.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var34 = var31.getLegendItem((-1), 100);
    var31.setBaseShapesFilled(false);
    java.awt.Paint var39 = var31.getItemOutlinePaint(10, 1);
    var23.setErrorIndicatorPaint(var39);
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var3, var5, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    var41.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.CategoryAxis var45 = var41.getDomainAxis(0);
    var41.setDrawSharedDomainAxis(true);
    org.jfree.chart.util.SortOrder var48 = var41.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotOrientation var49 = var41.getOrientation();
    org.jfree.chart.LegendItemCollection var50 = var41.getLegendItems();
    org.jfree.chart.axis.AxisLocation var51 = var41.getRangeAxisLocation();
    org.jfree.chart.entity.EntityCollection var53 = null;
    org.jfree.chart.ChartRenderingInfo var54 = new org.jfree.chart.ChartRenderingInfo(var53);
    org.jfree.chart.plot.PlotRenderingInfo var55 = var54.getPlotInfo();
    org.jfree.chart.plot.PlotRenderingInfo var56 = var54.getPlotInfo();
    org.jfree.chart.renderer.category.CategoryItemRendererState var57 = var0.initialise(var1, var2, var41, (-457), var56);
    org.jfree.chart.axis.CategoryAxis var59 = var41.getDomainAxis(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test245"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = var38.getRenderer((-457));
    var38.setDrawSharedDomainAxis(true);
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var46 = new org.jfree.chart.LegendItemCollection();
    int var47 = var46.getItemCount();
    var45.setFixedLegendItems(var46);
    org.jfree.chart.axis.AxisLocation var50 = var45.getRangeAxisLocation(10);
    org.jfree.chart.plot.CategoryMarker var52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)1L);
    java.lang.Object var53 = var52.clone();
    java.awt.Paint var54 = var52.getOutlinePaint();
    var45.setDomainGridlinePaint(var54);
    org.jfree.chart.event.MarkerChangeEvent var56 = null;
    var45.markerChanged(var56);
    org.jfree.chart.axis.AxisLocation var59 = var45.getRangeAxisLocation(10);
    var38.setDomainAxisLocation(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test246"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.plot.CategoryMarker var7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var8 = var7.getOutlineStroke();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var7);
    java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
    org.jfree.chart.plot.DatasetRenderingOrder var11 = var0.getDatasetRenderingOrder();
    var0.setDomainCrosshairValue(1.0d, true);
    java.awt.Paint var15 = var0.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleEdge var17 = var0.getDomainAxisEdge(2);
    org.jfree.chart.util.RectangleEdge var19 = var0.getRangeAxisEdge(2);
    org.jfree.chart.plot.DatasetRenderingOrder var20 = var0.getDatasetRenderingOrder();
    java.lang.String var21 = var20.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var21.equals("DatasetRenderingOrder.REVERSE"));

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test247"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     var2.configure();
//     org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
//     var0.setAxisOffset(var4);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var8 = var7.getEndType();
//     java.awt.Stroke var11 = var7.getItemStroke(0, 0);
//     var0.setRangeZeroBaselineStroke(var11);
//     org.jfree.chart.util.Layer var13 = null;
//     java.util.Collection var14 = var0.getDomainMarkers(var13);
//     org.jfree.chart.util.RectangleInsets var15 = var0.getInsets();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
//     java.awt.Stroke var21 = var17.getItemStroke(0, 0);
//     var0.setDomainZeroBaselineStroke(var21);
//     org.jfree.chart.util.RectangleEdge var24 = var0.getDomainAxisEdge(1);
//     var0.setRangeCrosshairValue((-1.0d), false);
//     org.jfree.chart.axis.AxisSpace var28 = new org.jfree.chart.axis.AxisSpace();
//     double var29 = var28.getBottom();
//     var0.setFixedRangeAxisSpace(var28);
//     var0.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D("");
//     var35.configure();
//     org.jfree.chart.util.RectangleInsets var37 = var35.getLabelInsets();
//     var33.setAxisOffset(var37);
//     org.jfree.chart.plot.CategoryMarker var40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Stroke var41 = var40.getOutlineStroke();
//     var33.addDomainMarker((org.jfree.chart.plot.Marker)var40);
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = var33.getRenderer();
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var48 = var45.getLegendItem((-1), 100);
//     var45.setBaseShapesFilled(false);
//     java.awt.Paint var52 = var45.getSeriesOutlinePaint((-1));
//     java.awt.Paint var54 = var45.lookupSeriesOutlinePaint(0);
//     var44.setLabelPaint(var54);
//     boolean var56 = var44.isNegativeArrowVisible();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var58 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var59 = var58.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var60 = var58.getBaseNegativeItemLabelPosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var61 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var63 = var61.getRangeUpperBound(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var66 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var69 = var66.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var70 = null;
//     org.jfree.chart.plot.RingPlot var71 = new org.jfree.chart.plot.RingPlot(var70);
//     org.jfree.chart.plot.Plot var72 = var71.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var73 = null;
//     var71.axisChanged(var73);
//     org.jfree.chart.JFreeChart var76 = new org.jfree.chart.JFreeChart("hi!", var69, (org.jfree.chart.plot.Plot)var71, true);
//     boolean var77 = var61.equals((java.lang.Object)var69);
//     var61.validateObject();
//     org.jfree.data.Range var79 = var58.findRangeBounds((org.jfree.data.category.CategoryDataset)var61);
//     org.jfree.data.general.DatasetChangeEvent var80 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var56, (org.jfree.data.general.Dataset)var61);
//     var33.datasetChanged(var80);
//     var0.datasetChanged(var80);
//     org.jfree.data.xy.XYDataset var83 = null;
//     var0.setDataset(var83);
//     var0.setBackgroundImageAlignment(2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var79);
// 
//   }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test248"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     var0.setRenderAsPercentages(true);
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var4 = var3.getLimit();
//     double var5 = var3.getLimit();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)"");
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     var6.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var11);
//     java.lang.Comparable var13 = null;
//     java.lang.Number var15 = var6.getMeanValue(var13, (java.lang.Comparable)100.0f);
//     var3.setDataset((org.jfree.data.category.CategoryDataset)var6);
//     org.jfree.data.general.DatasetGroup var17 = var6.getGroup();
//     double var19 = var6.getRangeLowerBound(true);
//     int var21 = var6.getColumnIndex((java.lang.Comparable)true);
//     java.util.List var22 = var6.getRowKeys();
//     org.jfree.data.Range var23 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test249"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    var3.configure();
    org.jfree.chart.util.RectangleInsets var5 = var3.getLabelInsets();
    var1.setAxisOffset(var5);
    org.jfree.chart.renderer.category.StackedAreaRenderer var8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var9 = var8.getEndType();
    java.awt.Stroke var12 = var8.getItemStroke(0, 0);
    var1.setRangeZeroBaselineStroke(var12);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var1.getDomainMarkers(var14);
    org.jfree.chart.util.RectangleInsets var16 = var1.getInsets();
    org.jfree.chart.renderer.category.StackedAreaRenderer var18 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var19 = var18.getEndType();
    java.awt.Stroke var22 = var18.getItemStroke(0, 0);
    var1.setDomainZeroBaselineStroke(var22);
    org.jfree.chart.util.RectangleEdge var24 = var1.getDomainAxisEdge();
    double var25 = var1.getRangeCrosshairValue();
    java.lang.String var26 = var1.getNoDataMessage();
    boolean var27 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var32 = var29.getLegendItem((-1), 100);
    var29.setBaseShapesFilled(false);
    java.awt.Paint var36 = var29.getSeriesOutlinePaint((-1));
    java.awt.Paint var38 = var29.lookupSeriesOutlinePaint(0);
    var28.setLabelPaint(var38);
    org.jfree.chart.axis.DateTickMarkPosition var40 = var28.getTickMarkPosition();
    org.jfree.data.Range var41 = var28.getDefaultAutoRange();
    boolean var42 = var0.equals((java.lang.Object)var28);
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D("org.jfree.data.UnknownKeyException: ");
    org.jfree.chart.renderer.PolarItemRenderer var46 = null;
    org.jfree.chart.plot.PolarPlot var47 = new org.jfree.chart.plot.PolarPlot(var43, (org.jfree.chart.axis.ValueAxis)var45, var46);
    var45.setLabelURL("ChartEntity: tooltip = org.jfree.data.UnknownKeyException: ");
    org.jfree.data.Range var52 = new org.jfree.data.Range(1.0d, 100.0d);
    java.lang.String var53 = var52.toString();
    org.jfree.data.Range var55 = org.jfree.data.Range.shift(var52, 0.0d);
    org.jfree.data.Range var58 = org.jfree.data.Range.expand(var55, 0.0d, 0.2d);
    var45.setDefaultAutoRange(var55);
    var28.setRangeWithMargins(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "Range[1.0,100.0]"+ "'", var53.equals("Range[1.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test250"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var4 = var1.getLegendItem((-1), 100);
    var1.setBaseShapesFilled(false);
    java.awt.Paint var8 = var1.getSeriesOutlinePaint((-1));
    org.jfree.chart.renderer.category.StackedAreaRenderer var10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var11 = var10.getEndType();
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getBaseNegativeItemLabelPosition();
    var1.setBaseNegativeItemLabelPosition(var12);
    var0.setPositiveItemLabelPositionFallback(var12);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
    org.jfree.chart.renderer.category.StackedAreaRenderer var21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var24 = var21.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
    org.jfree.chart.plot.Plot var27 = var26.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var28 = null;
    var26.axisChanged(var28);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("hi!", var24, (org.jfree.chart.plot.Plot)var26, true);
    java.awt.Paint var32 = var26.getBackgroundPaint();
    var17.setSeriesItemLabelPaint(0, var32, true);
    var0.setCompletePaint(var32);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var36.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var40 = var36.getBaseLinesVisible();
    java.lang.Boolean var42 = var36.getSeriesVisibleInLegend(10);
    java.awt.Paint var43 = var36.getBaseItemLabelPaint();
    var0.setIncompletePaint(var43);
    org.jfree.chart.labels.CategoryItemLabelGenerator var45 = null;
    var0.setBaseItemLabelGenerator(var45);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var51 = var48.getLegendItem((-1), 100);
    var48.setBaseShapesFilled(false);
    java.awt.Paint var55 = var48.getSeriesOutlinePaint((-1));
    java.awt.Paint var57 = var48.lookupSeriesOutlinePaint(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlinePaint((-457), var57, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test251"); }
// 
// 
//     org.jfree.data.KeyToGroupMap var0 = new org.jfree.data.KeyToGroupMap();
//     org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.data.DefaultKeyedValues2D var3 = new org.jfree.data.DefaultKeyedValues2D(false);
//     var3.clear();
//     java.util.List var5 = var3.getColumnKeys();
//     var1.setExceptionSegments(var5);
//     long var7 = var1.getSegmentsExcludedSize();
//     org.jfree.chart.axis.SegmentedTimeline var8 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.data.DefaultKeyedValues2D var10 = new org.jfree.data.DefaultKeyedValues2D(false);
//     var10.clear();
//     java.util.List var12 = var10.getColumnKeys();
//     var8.setExceptionSegments(var12);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(10, var17);
//     org.jfree.data.gantt.Task var19 = new org.jfree.data.gantt.Task("PlotOrientation.VERTICAL", (org.jfree.data.time.TimePeriod)var17);
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var24 = var21.getLegendItem((-1), 100);
//     var21.setBaseShapesFilled(false);
//     java.awt.Paint var28 = var21.getSeriesOutlinePaint((-1));
//     java.awt.Paint var30 = var21.lookupSeriesOutlinePaint(0);
//     var20.setLabelPaint(var30);
//     double var32 = var20.getFixedAutoRange();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var35 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var38 = var35.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot(var39);
//     org.jfree.chart.plot.Plot var41 = var40.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var42 = null;
//     var40.axisChanged(var42);
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("hi!", var38, (org.jfree.chart.plot.Plot)var40, true);
//     java.awt.Paint var46 = var40.getBackgroundPaint();
//     java.awt.Paint var47 = var40.getLabelOutlinePaint();
//     var20.setTickMarkPaint(var47);
//     java.text.DateFormat var51 = null;
//     org.jfree.chart.axis.DateTickUnit var52 = new org.jfree.chart.axis.DateTickUnit(2, 1, var51);
//     var20.setTickUnit(var52, false, false);
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var57 = var56.getMaximumDate();
//     java.lang.String var58 = var52.dateToString(var57);
//     java.lang.Number var59 = var14.getStdDevValue((java.lang.Comparable)var17, (java.lang.Comparable)var58);
//     org.jfree.data.Range var61 = var14.getRangeBounds(false);
//     org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var66 = var63.getLegendItem((-1), 100);
//     var63.setBaseShapesFilled(false);
//     java.awt.Paint var70 = var63.getSeriesOutlinePaint((-1));
//     java.awt.Paint var72 = var63.lookupSeriesOutlinePaint(0);
//     var62.setLabelPaint(var72);
//     boolean var74 = var62.isNegativeArrowVisible();
//     org.jfree.data.Range var77 = new org.jfree.data.Range(1.0d, 100.0d);
//     java.lang.String var78 = var77.toString();
//     org.jfree.data.Range var80 = org.jfree.data.Range.shift(var77, 0.0d);
//     var62.setRange(var80);
//     org.jfree.data.time.Month var82 = new org.jfree.data.time.Month();
//     long var83 = var82.getSerialIndex();
//     java.util.Date var84 = var82.getEnd();
//     org.jfree.data.time.Month var85 = new org.jfree.data.time.Month();
//     long var86 = var85.getSerialIndex();
//     java.util.Date var87 = var85.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var88 = new org.jfree.data.time.SimpleTimePeriod(var84, var87);
//     var62.setMaximumDate(var84);
//     org.jfree.data.time.Month var90 = new org.jfree.data.time.Month();
//     long var91 = var90.getSerialIndex();
//     java.util.Date var92 = var90.getEnd();
//     org.jfree.data.time.SimpleTimePeriod var93 = new org.jfree.data.time.SimpleTimePeriod(var84, var92);
//     java.lang.Number var95 = var14.getValue((java.lang.Comparable)var92, (java.lang.Comparable)"SortOrder.ASCENDING");
//     org.jfree.chart.axis.SegmentedTimeline.Segment var96 = var8.getSegment(var92);
//     long var97 = var1.toTimelineValue(var92);
//     int var98 = var0.getGroupIndex((java.lang.Comparable)var97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 172800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var58 + "' != '" + "12/31/69"+ "'", var58.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var78 + "' != '" + "Range[1.0,100.0]"+ "'", var78.equals("Range[1.0,100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var97 == 2592259199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == (-1));
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test252"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var4 = var0.getBaseLinesVisible();
    var0.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var12 = var9.getLegendItem((-1), 100);
    var9.setBaseShapesFilled(false);
    java.awt.Paint var17 = var9.getItemOutlinePaint(10, 1);
    org.jfree.chart.labels.ItemLabelPosition var18 = new org.jfree.chart.labels.ItemLabelPosition();
    var9.setBaseNegativeItemLabelPosition(var18, false);
    var0.setSeriesPositiveItemLabelPosition(15, var18, false);
    boolean var25 = var0.isItemLabelVisible(7, 156);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test253"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.plot.CategoryMarker var7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var8 = var7.getOutlineStroke();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var7);
    java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
    org.jfree.chart.plot.DatasetRenderingOrder var11 = var0.getDatasetRenderingOrder();
    var0.setDomainCrosshairValue(1.0d, true);
    java.awt.Paint var15 = var0.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleEdge var17 = var0.getDomainAxisEdge(2);
    org.jfree.chart.util.RectangleEdge var19 = var0.getRangeAxisEdge(2);
    org.jfree.chart.plot.DatasetRenderingOrder var20 = var0.getDatasetRenderingOrder();
    org.jfree.chart.plot.CategoryMarker var22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Paint var23 = var22.getLabelPaint();
    java.lang.Comparable var24 = var22.getKey();
    java.lang.String var25 = var22.getLabel();
    var22.setDrawAsLine(true);
    java.lang.Comparable var28 = var22.getKey();
    org.jfree.chart.util.Layer var29 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var22, var29);
    org.jfree.chart.util.RectangleEdge var31 = var0.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + true+ "'", var24.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + true+ "'", var28.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test254"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.plot.CategoryMarker var7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var8 = var7.getOutlineStroke();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var7);
    org.jfree.chart.renderer.category.StackedAreaRenderer var12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var15 = var12.getItemLabelFont((-1), 0);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
    org.jfree.chart.event.AxisChangeEvent var19 = null;
    var17.axisChanged(var19);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("hi!", var15, (org.jfree.chart.plot.Plot)var17, true);
    java.awt.Paint var23 = var17.getBackgroundPaint();
    java.awt.Paint var24 = var17.getLabelOutlinePaint();
    var0.setRangeTickBandPaint(var24);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var0.getRangeMarkers(var26);
    org.jfree.chart.plot.PlotOrientation var28 = var0.getOrientation();
    org.jfree.chart.util.RectangleInsets var29 = var0.getAxisOffset();
    double var31 = var29.calculateTopOutset(0.35d);
    double var32 = var29.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 3.0d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test255"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setUpperMargin(0.0d);
    int var5 = var2.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var11 = var8.getLegendItem((-1), 100);
    var8.setBaseShapesFilled(false);
    java.awt.Paint var15 = var8.getSeriesOutlinePaint((-1));
    java.awt.Paint var17 = var8.lookupSeriesOutlinePaint(0);
    var7.setLabelPaint(var17);
    double var19 = var7.getFixedAutoRange();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 0);
    double var24 = var20.getBase();
    org.jfree.chart.labels.ItemLabelPosition var27 = var20.getPositiveItemLabelPosition(2, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem((-1), 100);
    var28.setBaseShapesFilled(false);
    java.awt.Paint var36 = var28.getItemOutlinePaint(10, 1);
    var20.setErrorIndicatorPaint(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var38.setRangeCrosshairValue(50.5d);
    org.jfree.chart.axis.CategoryAxis var42 = var38.getDomainAxisForDataset(1);
    org.jfree.chart.plot.CategoryMarker var45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)1L);
    org.jfree.chart.util.Layer var46 = null;
    var38.addRangeMarker(4, (org.jfree.chart.plot.Marker)var45, var46);
    var38.setRangeCrosshairValue(4.0d, true);
    org.jfree.chart.axis.CategoryAnchor var51 = var38.getDomainGridlinePosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test256"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var0.setAdjustForDaylightSaving(true);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     long var4 = var3.getSerialIndex();
//     java.util.Date var5 = var3.getEnd();
//     org.jfree.chart.text.TextBlock var6 = null;
//     org.jfree.chart.text.TextBlockAnchor var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     var10.configure();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getLabelInsets();
//     var8.setAxisOffset(var12);
//     org.jfree.chart.plot.CategoryMarker var15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
//     java.awt.Stroke var16 = var15.getOutlineStroke();
//     var8.addDomainMarker((org.jfree.chart.plot.Marker)var15);
//     var15.setLabel("org.jfree.chart.event.RendererChangeEvent[source=false]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var21.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     boolean var25 = var21.getBaseLinesVisible();
//     java.lang.Boolean var27 = var21.getSeriesVisibleInLegend(10);
//     java.awt.Paint var28 = var21.getBaseItemLabelPaint();
//     java.awt.Color var31 = java.awt.Color.getColor("ThreadContext", 10);
//     float[] var32 = null;
//     float[] var33 = var31.getRGBColorComponents(var32);
//     var21.setBaseItemLabelPaint((java.awt.Paint)var31);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var36 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.AreaRendererEndType var37 = var36.getEndType();
//     org.jfree.chart.labels.ItemLabelPosition var38 = var36.getBaseNegativeItemLabelPosition();
//     var21.setBasePositiveItemLabelPosition(var38, true);
//     var20.setPositiveItemLabelPositionFallback(var38);
//     org.jfree.chart.text.TextAnchor var42 = var38.getRotationAnchor();
//     var15.setLabelTextAnchor(var42);
//     org.jfree.chart.axis.CategoryTick var45 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)var5, var6, var7, var42, 2.0d);
//     boolean var46 = var0.containsDomainValue(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test257"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    var0.setAxisOffset(var4);
    org.jfree.chart.plot.CategoryMarker var7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var8 = var7.getOutlineStroke();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var7);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = var0.getRenderer();
    org.jfree.chart.axis.ValueAxis var12 = var0.getDomainAxis(1);
    org.jfree.chart.renderer.category.StackedAreaRenderer var15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var18 = var15.getItemLabelFont((-1), 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var19.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var23 = var19.getBaseLinesVisible();
    java.lang.Boolean var25 = var19.getSeriesVisibleInLegend(10);
    java.awt.Paint var26 = var19.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("", var18, var26);
    var0.setRangeZeroBaselinePaint(var26);
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
    org.jfree.chart.plot.Plot var31 = var30.getRootPlot();
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var30);
    boolean var33 = var32.getAntiAlias();
    java.awt.Stroke var34 = var32.getBorderStroke();
    org.jfree.chart.util.RectangleInsets var35 = var32.getPadding();
    double var37 = var35.calculateTopInset(0.25d);
    var0.setInsets(var35);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    double var40 = var39.getItemMargin();
    org.jfree.chart.LegendItemCollection var41 = var39.getLegendItems();
    java.lang.Object var42 = var41.clone();
    int var43 = var41.getItemCount();
    var0.setFixedLegendItems(var41);
    java.lang.String var45 = var0.getNoDataMessage();
    java.lang.Object var46 = var0.clone();
    org.jfree.chart.plot.SeriesRenderingOrder var47 = var0.getSeriesRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test258"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.configure();
    java.lang.Object var4 = var2.clone();
    java.lang.Number var7 = null;
    java.util.List var13 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var14 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1.0d, (java.lang.Number)0L, var7, (java.lang.Number)100.0f, (java.lang.Number)0L, (java.lang.Number)0, (java.lang.Number)(short)(-1), (java.lang.Number)1.0d, var13);
    boolean var15 = var2.equals((java.lang.Object)0);
    boolean var16 = var2.isAutoRange();
    java.awt.Font var17 = var2.getLabelFont();
    org.jfree.chart.text.TextLine var18 = new org.jfree.chart.text.TextLine("Size2D[width=50.5, height=10.0]", var17);
    org.jfree.data.DefaultKeyedValues2D var20 = new org.jfree.data.DefaultKeyedValues2D(false);
    var20.clear();
    java.util.List var22 = var20.getColumnKeys();
    boolean var23 = var18.equals((java.lang.Object)var20);
    org.jfree.chart.renderer.category.StackedAreaRenderer var26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Font var29 = var26.getItemLabelFont((-1), 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var30.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var34 = var30.getBaseLinesVisible();
    java.lang.Boolean var36 = var30.getSeriesVisibleInLegend(10);
    java.awt.Paint var37 = var30.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("", var29, var37);
    var18.removeFragment(var38);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var43 = var40.getLegendItem((-1), 100);
    var40.setBaseShapesFilled(false);
    boolean var46 = var18.equals((java.lang.Object)false);
    org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var51 = var48.getLegendItem((-1), 100);
    var48.setBaseShapesFilled(false);
    java.awt.Paint var55 = var48.getSeriesOutlinePaint((-1));
    java.awt.Paint var57 = var48.lookupSeriesOutlinePaint(0);
    var47.setLabelPaint(var57);
    double var59 = var47.getFixedAutoRange();
    var47.setNegativeArrowVisible(true);
    java.text.DateFormat var64 = null;
    org.jfree.chart.axis.DateTickUnit var65 = new org.jfree.chart.axis.DateTickUnit(2, 1, var64);
    var47.setTickUnit(var65, true, false);
    boolean var69 = var18.equals((java.lang.Object)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test259"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (-1));
    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var7 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var8 = var7.getItemMargin();
    java.awt.Paint var9 = var7.getArtifactPaint();
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var12 = var11.getTickLabelPaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.LegendItem var16 = var13.getLegendItem(2, 0);
    double var17 = var13.getBase();
    java.awt.Color var20 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var21 = null;
    float[] var22 = var20.getRGBColorComponents(var21);
    java.awt.Color var25 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var26 = null;
    float[] var27 = var25.getRGBColorComponents(var26);
    float[] var28 = var20.getColorComponents(var26);
    var13.setErrorIndicatorPaint((java.awt.Paint)var20);
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D("");
    var32.configure();
    org.jfree.chart.util.RectangleInsets var34 = var32.getLabelInsets();
    var30.setAxisOffset(var34);
    org.jfree.chart.plot.CategoryMarker var37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)true);
    java.awt.Stroke var38 = var37.getOutlineStroke();
    var30.addDomainMarker((org.jfree.chart.plot.Marker)var37);
    java.awt.geom.Point2D var40 = var30.getQuadrantOrigin();
    java.awt.Paint var41 = var30.getDomainCrosshairPaint();
    org.jfree.chart.renderer.category.StackedAreaRenderer var43 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.AreaRendererEndType var44 = var43.getEndType();
    java.awt.Paint var45 = var43.getBaseFillPaint();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var46 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var12, (java.awt.Paint)var20, var41, var45);
    java.awt.Paint var47 = var46.getLastBarPaint();
    boolean var48 = var7.equals((java.lang.Object)var47);
    org.jfree.chart.block.BlockBorder var49 = new org.jfree.chart.block.BlockBorder(0.2d, 0.0d, 3.0d, Double.NaN, var47);
    boolean var50 = var0.equals((java.lang.Object)0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test260"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    double var1 = var0.getLimit();
    double var2 = var0.getLimit();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var3.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var7 = var3.getBaseLinesVisible();
    java.lang.Boolean var9 = var3.getSeriesVisibleInLegend(10);
    java.awt.Paint var10 = var3.getBaseItemLabelPaint();
    java.awt.Color var13 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var14 = null;
    float[] var15 = var13.getRGBColorComponents(var14);
    var3.setBaseItemLabelPaint((java.awt.Paint)var13);
    var0.setAggregatedItemsPaint((java.awt.Paint)var13);
    org.jfree.data.category.CategoryDataset var18 = var0.getDataset();
    org.jfree.chart.util.RectangleInsets var19 = var0.getInsets();
    var0.setLimit((-11.95d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test261"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Font var5 = var2.getItemLabelFont((-1), 0);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var7.axisChanged(var9);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", var5, (org.jfree.chart.plot.Plot)var7, true);
//     java.lang.Object var13 = var7.clone();
//     org.jfree.chart.util.HorizontalAlignment var14 = null;
//     org.jfree.chart.util.VerticalAlignment var15 = null;
//     org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var14, var15, 100.0d, 10.0d);
//     var18.clear();
//     org.jfree.chart.block.Arrangement var20 = null;
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var18, var20);
//     org.jfree.data.UnknownKeyException var23 = new org.jfree.data.UnknownKeyException("");
//     java.lang.Throwable[] var24 = var23.getSuppressed();
//     java.lang.Throwable[] var25 = var23.getSuppressed();
//     boolean var26 = var21.equals((java.lang.Object)var25);
//     org.jfree.chart.util.RectangleInsets var27 = var21.getLegendItemGraphicPadding();
//     java.awt.Graphics2D var28 = null;
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 0.0f);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var31, Double.NaN, Double.NaN);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 10.0d, 0.0f, 0.0f);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var41 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     double var43 = var41.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var46 = new org.jfree.chart.entity.CategoryItemEntity(var31, "hi!", "", (org.jfree.data.category.CategoryDataset)var41, (java.lang.Comparable)100.0f, (java.lang.Comparable)10L);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.LegendItem var50 = var47.getLegendItem((-1), 100);
//     var47.setBaseShapesFilled(false);
//     java.awt.Paint var54 = var47.getSeriesOutlinePaint((-1));
//     java.awt.Paint var56 = var47.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.title.LegendGraphic var57 = new org.jfree.chart.title.LegendGraphic(var31, var56);
//     java.awt.Graphics2D var58 = null;
//     org.jfree.chart.block.ColumnArrangement var59 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var60 = null;
//     org.jfree.chart.util.VerticalAlignment var61 = null;
//     org.jfree.chart.block.FlowArrangement var64 = new org.jfree.chart.block.FlowArrangement(var60, var61, Double.NaN, 4.0d);
//     org.jfree.chart.block.BlockContainer var65 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var66 = null;
//     org.jfree.chart.block.RectangleConstraint var69 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
//     org.jfree.chart.util.Size2D var70 = var64.arrange(var65, var66, var69);
//     var65.clear();
//     java.awt.Graphics2D var72 = null;
//     org.jfree.chart.block.RectangleConstraint var75 = new org.jfree.chart.block.RectangleConstraint(50.5d, 10.0d);
//     org.jfree.chart.util.Size2D var76 = var59.arrange(var65, var72, var75);
//     org.jfree.chart.util.Size2D var77 = var57.arrange(var58, var75);
//     org.jfree.chart.block.RectangleConstraint var79 = var75.toFixedWidth(Double.NaN);
//     org.jfree.chart.block.RectangleConstraint var80 = var75.toUnconstrainedWidth();
//     double var81 = var80.getHeight();
//     org.jfree.chart.util.Size2D var82 = var21.arrange(var28, var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test262"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    float var2 = var1.getForegroundAlpha();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var11 = var10.isTickMarksVisible();
    java.awt.Shape var12 = var10.getDownArrow();
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 100.0d, 0.2d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var16.setSeriesCreateEntities(1, (java.lang.Boolean)false);
    boolean var20 = var16.getBaseLinesVisible();
    java.lang.Boolean var22 = var16.getSeriesVisibleInLegend(10);
    java.awt.Paint var23 = var16.getBaseItemLabelPaint();
    java.awt.Color var26 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var27 = null;
    float[] var28 = var26.getRGBColorComponents(var27);
    var16.setBaseItemLabelPaint((java.awt.Paint)var26);
    int var30 = var26.getGreen();
    java.lang.String var31 = var26.toString();
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("hi!", "ThreadContext", "Pie Plot", "Range[1.0,100.0]", var15, (java.awt.Paint)var26);
    var3.setTickLabelPaint((java.lang.Comparable)10.0d, (java.awt.Paint)var26);
    var1.setBackgroundPaint((java.awt.Paint)var26);
    java.awt.Color var35 = java.awt.Color.getColor("LengthConstraintType.FIXED", var26);
    java.awt.Color var38 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var39 = null;
    float[] var40 = var38.getRGBColorComponents(var39);
    java.awt.Color var43 = java.awt.Color.getColor("ThreadContext", 10);
    float[] var44 = null;
    float[] var45 = var43.getRGBColorComponents(var44);
    float[] var46 = var38.getColorComponents(var44);
    java.awt.color.ColorSpace var47 = var38.getColorSpace();
    float[] var51 = null;
    float[] var52 = java.awt.Color.RGBtoHSB(2, 15, (-460), var51);
    float[] var53 = var38.getRGBColorComponents(var51);
    float[] var54 = var26.getColorComponents(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "java.awt.Color[r=0,g=0,b=10]"+ "'", var31.equals("java.awt.Color[r=0,g=0,b=10]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

}
