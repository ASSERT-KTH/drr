
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, 1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, 1.0f, var4, 10.0d, var6);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!", var1);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "");

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, true);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var5, var7);
    java.awt.Stroke var9 = null;
    java.awt.Paint var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "hi!", "", var7, var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePaint(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkPaint(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "", "", "");
    boolean var6 = var4.equals((java.lang.Object)(short)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var3 = var2.getRootPlot();
    java.awt.Paint var4 = var2.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("hi!", var1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(0.05d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.awt.Paint var2 = var0.getBackgroundPaint();
    org.jfree.chart.axis.AxisLocation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("hi!", var1, var2, var3);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.plot.DatasetRenderingOrder var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.awt.Font var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var4 = var3.getTickMarkOutsideLength();
    java.awt.Paint var5 = var3.getAxisLinePaint();
    java.awt.Paint var6 = var3.getTickLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("", var1, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    java.lang.Object var0 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var3 = var2.getRootPlot();
    java.awt.Paint var4 = var2.getBackgroundPaint();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent(var0, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var1);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    org.jfree.chart.event.ChartChangeListener var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.removeChangeListener(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + ""+ "'", var0.equals(""));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0.05d);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
//     int var3 = var0.getBackgroundImageAlignment();
//     boolean var4 = var0.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var7 = var6.getTickMarkOutsideLength();
//     java.awt.Paint var8 = var6.getAxisLinePaint();
//     java.awt.Paint var9 = var6.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
//     java.awt.Paint var13 = var11.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var11);
//     boolean var15 = var14.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var9, var14, 100, 10);
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var2 = var1.getID();
    org.jfree.chart.block.BlockFrame var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setFrame(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    boolean var5 = var4.isNotify();
    var4.clearSubtitles();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var8 = var4.getSubtitle(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.CategoryAxis[] var3 = null;
//     var0.setDomainAxes(var3);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    org.jfree.data.category.CategoryDataset var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataset((-16777216), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, (-1.0d));
//     org.jfree.chart.block.BlockContainer var5 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, 10.0d);
//     org.jfree.chart.util.Size2D var10 = var4.arrange(var5, var6, var9);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent(var1);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
//     java.awt.Paint var6 = var4.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var4);
//     boolean var8 = var7.isNotify();
//     var7.clearSubtitles();
//     var2.setChart(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var14 = var9.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     org.jfree.data.statistics.MeanAndStandardDeviation var4 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     java.lang.Number var5 = var4.getStandardDeviation();
//     var0.setObject((java.lang.Comparable)100, (java.lang.Object)var5);
//     org.jfree.data.statistics.MeanAndStandardDeviation var10 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     java.lang.Number var11 = var10.getStandardDeviation();
//     var0.addObject((java.lang.Comparable)100.0d, (java.lang.Object)var11);
//     
//     // Checks the contract:  equals-hashcode on var4 and var10
//     assertTrue("Contract failed: equals-hashcode on var4 and var10", var4.equals(var10) ? var4.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var4
//     assertTrue("Contract failed: equals-hashcode on var10 and var4", var10.equals(var4) ? var10.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
//     java.awt.Paint var17 = var15.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var15);
//     boolean var19 = var18.isNotify();
//     var13.setChart(var18);
//     
//     // Checks the contract:  equals-hashcode on var6 and var15
//     assertTrue("Contract failed: equals-hashcode on var6 and var15", var6.equals(var15) ? var6.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var16
//     assertTrue("Contract failed: equals-hashcode on var7 and var16", var7.equals(var16) ? var7.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var7
//     assertTrue("Contract failed: equals-hashcode on var16 and var7", var16.equals(var7) ? var16.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var18
//     assertTrue("Contract failed: equals-hashcode on var9 and var18", var9.equals(var18) ? var9.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var9
//     assertTrue("Contract failed: equals-hashcode on var18 and var9", var18.equals(var9) ? var18.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    var1.setAxisLineVisible(true);
    var1.configure();
    java.awt.Font var11 = var1.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.util.RectangleInsets var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelInsets(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.data.statistics.MeanAndStandardDeviation var4 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
    java.lang.Number var5 = var4.getStandardDeviation();
    var0.setObject((java.lang.Comparable)100, (java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)100.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100.0d+ "'", var5.equals(100.0d));

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Stroke var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var6 = var5.getRootPlot();
    java.util.List var7 = var5.getCategories();
    org.jfree.chart.util.RectangleInsets var8 = var5.getInsets();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var9 = new org.jfree.chart.block.LineBorder(var3, var4, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 10.0f, 0.0f, var4, (-1.0d), var6);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    boolean var5 = var4.isNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var8 = var4.createBufferedImage((-16777216), 15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.event.ChartProgressListener var5 = null;
    var4.removeProgressListener(var5);
    org.jfree.chart.event.ChartChangeListener var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addChangeListener(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 0.05d, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxisForDataset(0);
    var0.setAnchorValue(0.2d);
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)10.0f, "", var2, var3, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var3 = var0.getDomainAxisEdge();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
//     java.awt.Paint var6 = var4.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     var0.setRowRenderingOrder(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    boolean var2 = var0.equals((java.lang.Object)(short)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var4 = var2.getRangeAxisForDataset(0);
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var9 = var6.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     org.jfree.chart.axis.AxisSpace var11 = var0.reserveSpace(var1, (org.jfree.chart.plot.Plot)var2, var5, var9, var10);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { (byte)1};
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, (-1.0f), 10.0f, var4, 4.0d, var6);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var2 = var0.removeAnnotation(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.ChartRenderingInfo var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var8 = var4.createBufferedImage(100, (-16777216), var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.event.ChartProgressListener var5 = null;
//     var4.removeProgressListener(var5);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     java.awt.Paint var11 = var9.getBackgroundPaint();
//     var8.setPaint(var11);
//     var4.setBackgroundPaint(var11);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxisForDataset(0);
    var0.mapDatasetToRangeAxis(0, 0);
    org.jfree.chart.axis.CategoryAxis var6 = var0.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-1), var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
    java.awt.Paint var10 = var8.getBackgroundPaint();
    var7.setPaint(var10);
    java.awt.Stroke var12 = null;
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var19 = var18.getTickMarkOutsideLength();
    java.awt.Paint var20 = var18.getAxisLinePaint();
    org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder(0.05d, 0.0d, 1.0d, 0.2d, var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "", "", "hi!", var5, var10, var12, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
    java.awt.Paint var10 = var8.getBackgroundPaint();
    var7.setPaint(var10);
    java.awt.Font var12 = var7.getFont();
    double var13 = var7.getContentYOffset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addSubtitle(100, (org.jfree.chart.title.Title)var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var5 = org.jfree.chart.util.ShapeUtilities.equal(var2, var4);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var2, 0.2d, (-1.0f), 0.0f);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var3 = var0.getDomainAxisEdge();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotOrientation var7 = var4.getOrientation();
//     java.lang.String var8 = var7.toString();
//     var0.setOrientation(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
//     int var14 = var13.getPercent();
//     java.lang.Object var15 = var13.getSource();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var18 = var17.getTickMarkOutsideLength();
//     java.awt.Paint var19 = var17.getAxisLinePaint();
//     java.awt.Paint var20 = var17.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var23 = var22.getRootPlot();
//     java.awt.Paint var24 = var22.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var22);
//     boolean var26 = var25.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var29 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var20, var25, 100, 10);
//     java.awt.Stroke var30 = null;
//     var25.setBorderStroke(var30);
//     var25.fireChartChanged();
//     var13.setChart(var25);
//     
//     // Checks the contract:  equals-hashcode on var6 and var22
//     assertTrue("Contract failed: equals-hashcode on var6 and var22", var6.equals(var22) ? var6.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var6
//     assertTrue("Contract failed: equals-hashcode on var22 and var6", var22.equals(var6) ? var22.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var23
//     assertTrue("Contract failed: equals-hashcode on var7 and var23", var7.equals(var23) ? var7.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var7
//     assertTrue("Contract failed: equals-hashcode on var23 and var7", var23.equals(var7) ? var23.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.centerRange(0.05d);
//     double var3 = var0.getUpperMargin();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var5, var7);
//     org.jfree.chart.entity.TickLabelEntity var11 = new org.jfree.chart.entity.TickLabelEntity(var7, "", "");
//     var0.setUpArrow(var7);
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var18 = var15.getDomainAxisEdge();
//     boolean var19 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var18);
//     double var20 = var0.valueToJava2D(1.0d, var14, var18);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
    int var3 = var0.getBackgroundImageAlignment();
    var0.setRangeCrosshairVisible(true);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var0.getDomainMarkers(10, var7);
    org.jfree.chart.plot.CategoryMarker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((-16777216), var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var4 = var3.getRootPlot();
    java.awt.Paint var5 = var3.getBackgroundPaint();
    var2.setPaint(var5);
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder(var5);
    java.awt.Stroke var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(0.0d, var5, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    java.awt.Color var1 = java.awt.Color.getColor("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var5 = null;
//     var3.setTickLabelPaint((java.lang.Comparable)10L, var5);
//     var3.setCategoryLabelPositionOffset(0);
//     var3.setAxisLineVisible(true);
//     var3.configure();
//     java.awt.Font var13 = var3.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var16 = var15.getTickMarkOutsideLength();
//     java.awt.Paint var17 = var15.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("", var13, var17);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var13);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.data.Range var21 = null;
//     org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(var21, 10.0d);
//     org.jfree.chart.util.Size2D var24 = var19.arrange(var20, var23);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.2d, 1.0d, var2);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.centerRange(0.05d);
    var0.setNegativeArrowVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRange(10.0d, 8.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var3 = null;
//     var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
//     var1.setCategoryLabelPositionOffset(0);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.getCategoryStart(10, (-16777216), var9, var10);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     var17.setRenderer(var19);
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     java.awt.geom.Point2D var24 = null;
//     var17.zoomRangeAxes(100.0d, var23, var24);
//     org.jfree.chart.axis.AxisState var26 = var1.draw(var12, 4.0d, var14, var15, var16, var23);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(-1L));
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var1, 2.0f, 1.0f, var4, 10.0d, var6);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var1);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var6, "hi!", "hi!");
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var6, var11);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var19 = var18.getTickMarkOutsideLength();
    java.awt.Paint var20 = var18.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var24 = var23.getTickMarkOutsideLength();
    java.awt.Paint var25 = var23.getAxisLinePaint();
    java.awt.Paint var26 = var23.getTickLabelPaint();
    org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var29 = var28.getTickMarkOutsideLength();
    boolean var30 = var28.isAxisLineVisible();
    java.awt.Stroke var31 = var28.getTickMarkStroke();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.entity.ChartEntity var37 = new org.jfree.chart.entity.ChartEntity(var34, "hi!", "hi!");
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var39, var41);
    boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var34, var39);
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var46 = var45.getTickMarkOutsideLength();
    boolean var47 = var45.isAxisLineVisible();
    java.awt.Stroke var48 = var45.getTickMarkStroke();
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var50 = var49.getRootPlot();
    org.jfree.chart.util.Layer var52 = null;
    java.util.Collection var53 = var49.getDomainMarkers(0, var52);
    java.awt.Paint var54 = var49.getRangeGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem(var0, "", "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", true, var6, true, var20, true, var26, var31, false, var34, var48, var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.2d, 8.0d, 10, (java.lang.Comparable)(short)(-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent(var1);
//     org.jfree.chart.JFreeChart var3 = var2.getChart();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var6 = var5.getRootPlot();
//     java.awt.Paint var7 = var5.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
//     boolean var9 = var8.isNotify();
//     var8.clearSubtitles();
//     java.awt.Image var11 = var8.getBackgroundImage();
//     var2.setChart(var8);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0d, 0.05d, 0, (java.lang.Comparable)' ');
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 10.0d};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 0};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var5 = var4.getBackgroundPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.util.List var8 = var6.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var6.getRenderer((-16777216));
//     java.util.List var11 = var6.getAnnotations();
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     var6.setRangeAxis(0, var13);
//     org.jfree.chart.ChartRenderingInfo var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = new org.jfree.chart.plot.PlotRenderingInfo(var17);
//     java.awt.geom.Rectangle2D var19 = null;
//     var18.setPlotArea(var19);
//     java.awt.geom.Point2D var21 = null;
//     var6.zoomRangeAxes(1.0d, 0.0d, var18, var21);
//     boolean var23 = var4.equals((java.lang.Object)var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    double var3 = var1.getHeight();
    java.awt.Font var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setFont(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
//     var9.setNotify(true);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var19 = var18.getRootPlot();
//     java.awt.Paint var20 = var18.getBackgroundPaint();
//     var17.setPaint(var20);
//     org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder(var20);
//     var9.setBackgroundPaint(var20);
//     
//     // Checks the contract:  equals-hashcode on var6 and var18
//     assertTrue("Contract failed: equals-hashcode on var6 and var18", var6.equals(var18) ? var6.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var6
//     assertTrue("Contract failed: equals-hashcode on var18 and var6", var18.equals(var6) ? var18.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var19
//     assertTrue("Contract failed: equals-hashcode on var7 and var19", var7.equals(var19) ? var7.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var7
//     assertTrue("Contract failed: equals-hashcode on var19 and var7", var19.equals(var7) ? var19.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var6 = var5.getLeftArrow();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
    java.awt.Paint var12 = var10.getBackgroundPaint();
    var9.setPaint(var12);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var21 = var20.getTickMarkOutsideLength();
    java.awt.Paint var22 = var20.getAxisLinePaint();
    org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder(0.05d, 0.0d, 1.0d, 0.2d, var22);
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var26 = var25.getTickMarkOutsideLength();
    boolean var27 = var25.isAxisLineVisible();
    java.awt.Stroke var28 = var25.getTickMarkStroke();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.entity.ChartEntity var34 = new org.jfree.chart.entity.ChartEntity(var31, "hi!", "hi!");
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var37 = var36.getTickMarkOutsideLength();
    boolean var38 = var36.isAxisLineVisible();
    java.awt.Stroke var39 = var36.getTickMarkStroke();
    org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var43 = var42.getRootPlot();
    java.awt.Paint var44 = var42.getBackgroundPaint();
    var41.setPaint(var44);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var47 = new org.jfree.chart.LegendItem(var0, "100", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", false, var6, false, var12, false, var22, var28, false, var31, var39, var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent(var1);
//     org.jfree.chart.JFreeChart var3 = var2.getChart();
//     org.jfree.chart.JFreeChart var4 = var2.getChart();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     var9.clearSubtitles();
//     java.awt.Image var12 = var9.getBackgroundImage();
//     var2.setChart(var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.event.ChartProgressListener var5 = null;
    var4.removeProgressListener(var5);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var10 = var9.getToolTipText();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addSubtitle((-1), (org.jfree.chart.title.Title)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
    boolean var6 = var0.equals((java.lang.Object)var5);
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.Comparable var9 = null;
    var0.addObject((java.lang.Object)100.0d, var9, (java.lang.Comparable)(byte)10);
    java.lang.Comparable var13 = var0.getRowKey(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var15 = var0.getRowKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "100", "PlotOrientation.VERTICAL", "ChartEntity: tooltip = ");

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", "hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)8.0d, (-1.0d), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.ProjectInfo var1 = new org.jfree.chart.ui.ProjectInfo();
    var0.addLibrary((org.jfree.chart.ui.Library)var1);
    var0.addOptionalLibrary("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    java.lang.String var5 = var0.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(short)10);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.util.List var2 = var0.getCategories();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var4 = var3.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var5 = new org.jfree.chart.event.PlotChangeEvent(var4);
//     org.jfree.chart.JFreeChart var6 = null;
//     var5.setChart(var6);
//     var0.notifyListeners(var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var4
//     assertTrue("Contract failed: equals-hashcode on var1 and var4", var1.equals(var4) ? var1.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var6, "hi!", "hi!");
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
    java.awt.Paint var14 = var12.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var17 = var16.getLeftArrow();
    java.awt.Paint var18 = var16.getLabelPaint();
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var21 = var20.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var24 = var23.getTickMarkOutsideLength();
    boolean var25 = var23.isAxisLineVisible();
    java.awt.Stroke var26 = var23.getTickMarkStroke();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var28 = var27.getRootPlot();
    java.util.List var29 = var27.getCategories();
    org.jfree.chart.util.RectangleInsets var30 = var27.getInsets();
    double var32 = var30.calculateBottomInset((-1.0d));
    org.jfree.chart.block.LineBorder var33 = new org.jfree.chart.block.LineBorder(var21, var26, var30);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var36 = var35.getDownArrow();
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var43 = var42.getTickMarkOutsideLength();
    java.awt.Paint var44 = var42.getAxisLinePaint();
    java.awt.Paint[] var45 = new java.awt.Paint[] { var44};
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var47 = var46.getRootPlot();
    org.jfree.chart.util.Layer var49 = null;
    java.util.Collection var50 = var46.getDomainMarkers(0, var49);
    java.awt.Paint var51 = var46.getRangeGridlinePaint();
    java.awt.Paint[] var52 = new java.awt.Paint[] { var51};
    java.awt.Paint[] var53 = null;
    java.awt.Stroke var54 = null;
    java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
    java.awt.Stroke var56 = null;
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var59, var61);
    java.awt.Shape[] var63 = new java.awt.Shape[] { var61};
    org.jfree.chart.plot.DefaultDrawingSupplier var64 = new org.jfree.chart.plot.DefaultDrawingSupplier(var45, var52, var53, var55, var57, var63);
    java.awt.Shape var65 = var64.getNextShape();
    org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var68 = var67.getTickMarkOutsideLength();
    boolean var69 = var67.isAxisLineVisible();
    java.awt.Stroke var70 = var67.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var73 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var75 = null;
    var73.setTickLabelPaint((java.lang.Comparable)10L, var75);
    var73.setCategoryLabelPositionOffset(0);
    var73.setAxisLineVisible(true);
    var73.configure();
    java.awt.Font var83 = var73.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var85 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var86 = var85.getTickMarkOutsideLength();
    java.awt.Paint var87 = var85.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var88 = new org.jfree.chart.text.TextFragment("", var83, var87);
    org.jfree.chart.LegendItem var89 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var65, var70, var87);
    org.jfree.chart.axis.NumberAxis var90 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var91 = var90.getLeftArrow();
    java.awt.Paint var92 = var90.getLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var93 = new org.jfree.chart.LegendItem(var0, "hi!", "100", "", true, var10, false, var14, false, var18, var26, false, var36, var70, var92);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.util.List var2 = var0.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
//     org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var6 = var0.getDomainAxis();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     java.awt.Paint var9 = var7.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var10 = var7.getRowRenderingOrder();
//     var0.setRowRenderingOrder(var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.getAutoRangeIncludesZero();
    org.jfree.chart.axis.MarkerAxisBand var2 = null;
    var0.setMarkerBand(var2);
    var0.setTickMarkOutsideLength(0.0f);
    double var6 = var0.getLabelAngle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRange(0.05d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.labels.ItemLabelPosition var1 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.text.TextAnchor var2 = var1.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var3 = new org.jfree.chart.labels.ItemLabelPosition(var0, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    java.lang.Class var0 = null;
    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    float var5 = var1.getBackgroundAlpha();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var8 = var7.getTickMarkOutsideLength();
    java.awt.Paint var9 = var7.getAxisLinePaint();
    java.awt.Paint var10 = var7.getTickLabelPaint();
    var7.setLabelAngle(0.0d);
    java.util.List var13 = var1.getCategoriesForAxis(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBackgroundImageAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var2 = var1.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    double var5 = var1.getCategoryMargin();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    org.jfree.chart.util.Layer var9 = null;
    java.util.Collection var10 = var6.getDomainMarkers(0, var9);
    java.awt.Paint var11 = var6.getRangeGridlinePaint();
    var1.setPlot((org.jfree.chart.plot.Plot)var6);
    org.jfree.data.general.Dataset var13 = null;
    org.jfree.data.general.DatasetChangeEvent var14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var1, var13);
    java.lang.String var16 = var1.getCategoryLabelToolTip((java.lang.Comparable)0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var1.getRangeMarkers(0, var6);
    org.jfree.chart.plot.CategoryMarker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addDomainMarker((-16777216), var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxisForDataset(0);
    var0.setAnchorValue(0.2d);
    org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis();
    int var10 = var7.getBackgroundImageAlignment();
    var7.setRangeCrosshairVisible(true);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var7.getDomainMarkers(10, var14);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
    java.util.List var19 = var17.getCategories();
    org.jfree.chart.util.RectangleInsets var20 = var17.getInsets();
    double var22 = var20.calculateBottomInset((-1.0d));
    double var23 = var20.getTop();
    var16.setPadding(var20);
    var0.setInsets(var20);
    java.awt.geom.Rectangle2D var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var27 = var20.createInsetRectangle(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4.0d);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var8 = var7.getTickMarkOutsideLength();
//     java.awt.Paint var9 = var7.getAxisLinePaint();
//     java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
//     org.jfree.chart.util.Layer var14 = null;
//     java.util.Collection var15 = var11.getDomainMarkers(0, var14);
//     java.awt.Paint var16 = var11.getRangeGridlinePaint();
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Paint[] var18 = null;
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Stroke var21 = null;
//     java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
//     java.awt.Shape[] var28 = new java.awt.Shape[] { var26};
//     org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var17, var18, var20, var22, var28);
//     java.awt.Shape var30 = var29.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var33 = var32.getTickMarkOutsideLength();
//     boolean var34 = var32.isAxisLineVisible();
//     java.awt.Stroke var35 = var32.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var40 = null;
//     var38.setTickLabelPaint((java.lang.Comparable)10L, var40);
//     var38.setCategoryLabelPositionOffset(0);
//     var38.setAxisLineVisible(true);
//     var38.configure();
//     java.awt.Font var48 = var38.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var51 = var50.getTickMarkOutsideLength();
//     java.awt.Paint var52 = var50.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var48, var52);
//     org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var30, var35, var52);
//     var1.setStroke(var35);
//     java.lang.Class var56 = null;
//     java.util.EventListener[] var57 = var1.getListeners(var56);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 0.05d);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.util.Layer var3 = null;
    java.util.Collection var4 = var0.getDomainMarkers(0, var3);
    org.jfree.chart.util.SortOrder var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRowRenderingOrder(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var9 = var8.getTickMarkOutsideLength();
//     boolean var10 = var8.isAxisLineVisible();
//     var4.setDomainAxis(10, var8);
//     java.awt.Paint var12 = var8.getLabelPaint();
//     var8.setTickMarksVisible(true);
//     int var15 = var0.getDomainAxisIndex(var8);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var4.", var0.equals(var4) == var4.equals(var0));
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var5.", var1.equals(var5) == var5.equals(var1));
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.plot.Plot var2 = var1.getParent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
//     int var4 = var1.getBackgroundImageAlignment();
//     var1.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var8 = null;
//     java.util.Collection var9 = var1.getDomainMarkers(10, var8);
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
//     java.util.List var13 = var11.getCategories();
//     org.jfree.chart.util.RectangleInsets var14 = var11.getInsets();
//     double var16 = var14.calculateBottomInset((-1.0d));
//     double var17 = var14.getTop();
//     var10.setPadding(var14);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     var10.draw(var19, var20);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("PlotOrientation.VERTICAL", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 15);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxisForDataset(0);
//     var0.mapDatasetToRangeAxis(0, 0);
//     var0.clearDomainMarkers(1);
//     var0.zoom(8.0d);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    double var5 = var1.getCategoryMargin();
    java.lang.Comparable var6 = null;
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var13 = var12.getTickMarkOutsideLength();
    java.awt.Paint var14 = var12.getAxisLinePaint();
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var17 = var16.getRootPlot();
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var16.getDomainMarkers(0, var19);
    java.awt.Paint var21 = var16.getRangeGridlinePaint();
    java.awt.Paint[] var22 = new java.awt.Paint[] { var21};
    java.awt.Paint[] var23 = null;
    java.awt.Stroke var24 = null;
    java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
    java.awt.Stroke var26 = null;
    java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var29, var31);
    java.awt.Shape[] var33 = new java.awt.Shape[] { var31};
    org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier(var15, var22, var23, var25, var27, var33);
    java.awt.Shape var35 = var34.getNextShape();
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var38 = var37.getTickMarkOutsideLength();
    boolean var39 = var37.isAxisLineVisible();
    java.awt.Stroke var40 = var37.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var45 = null;
    var43.setTickLabelPaint((java.lang.Comparable)10L, var45);
    var43.setCategoryLabelPositionOffset(0);
    var43.setAxisLineVisible(true);
    var43.configure();
    java.awt.Font var53 = var43.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var56 = var55.getTickMarkOutsideLength();
    java.awt.Paint var57 = var55.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var58 = new org.jfree.chart.text.TextFragment("", var53, var57);
    org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var35, var40, var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelPaint(var6, var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var4 = null;
//     var2.setTickLabelPaint((java.lang.Comparable)10L, var4);
//     var2.setCategoryLabelPositionOffset(0);
//     var2.setAxisLineVisible(true);
//     var2.configure();
//     java.awt.Font var12 = var2.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var15 = var14.getTickMarkOutsideLength();
//     java.awt.Paint var16 = var14.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("", var12, var16);
//     java.awt.Graphics2D var18 = null;
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.labels.ItemLabelPosition var23 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var24 = var23.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var20, (-1.0f), 100.0f, var24, 100.0d, 2.0f, 2.0f);
//     float var29 = var17.calculateBaselineOffset(var18, var24);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var8 = var7.getTickMarkOutsideLength();
    java.awt.Paint var9 = var7.getAxisLinePaint();
    java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var11.getDomainMarkers(0, var14);
    java.awt.Paint var16 = var11.getRangeGridlinePaint();
    java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
    java.awt.Paint[] var18 = null;
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
    java.awt.Shape[] var28 = new java.awt.Shape[] { var26};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var17, var18, var20, var22, var28);
    java.awt.Shape var30 = var29.getNextShape();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var33 = var32.getTickMarkOutsideLength();
    boolean var34 = var32.isAxisLineVisible();
    java.awt.Stroke var35 = var32.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var40 = null;
    var38.setTickLabelPaint((java.lang.Comparable)10L, var40);
    var38.setCategoryLabelPositionOffset(0);
    var38.setAxisLineVisible(true);
    var38.configure();
    java.awt.Font var48 = var38.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var51 = var50.getTickMarkOutsideLength();
    java.awt.Paint var52 = var50.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var48, var52);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var30, var35, var52);
    var1.setStroke(var35);
    org.jfree.chart.util.RectangleAnchor var56 = var1.getLabelAnchor();
    org.jfree.chart.text.TextBlockAnchor var57 = null;
    org.jfree.chart.labels.ItemLabelPosition var58 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.text.TextAnchor var59 = var58.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var63 = new org.jfree.chart.axis.CategoryLabelPosition(var56, var57, var59, 8.0d, var61, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var3 = var2.getID();
    java.awt.Font var4 = var2.getFont();
    org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("", var4);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var12 = var11.getTickMarkOutsideLength();
    java.awt.Paint var13 = var11.getAxisLinePaint();
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(0.05d, 0.0d, 1.0d, 0.2d, var13);
    boolean var15 = var5.equals((java.lang.Object)0.2d);
    java.lang.String var16 = var5.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
    boolean var6 = var0.equals((java.lang.Object)var5);
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.Comparable var9 = null;
    var0.addObject((java.lang.Object)100.0d, var9, (java.lang.Comparable)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)100.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var0.markerChanged(var3);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var3 = var2.getID();
//     java.awt.Font var4 = var2.getFont();
//     org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("", var4);
//     var5.setURLText("PlotOrientation.VERTICAL");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var13 = var12.getTickMarkOutsideLength();
//     java.awt.Paint var14 = var12.getAxisLinePaint();
//     java.awt.Paint var15 = var12.getTickLabelPaint();
//     double var16 = var12.getCategoryMargin();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var17.getDomainMarkers(0, var20);
//     java.awt.Paint var22 = var17.getRangeGridlinePaint();
//     var12.setPlot((org.jfree.chart.plot.Plot)var17);
//     java.lang.Object var24 = var5.draw(var9, var10, (java.lang.Object)var17);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     boolean var1 = var0.getAutoRangeIncludesZero();
//     org.jfree.chart.axis.MarkerAxisBand var2 = null;
//     var0.setMarkerBand(var2);
//     var0.setTickMarkOutsideLength(0.0f);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var10 = var7.getDomainAxisEdge();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
//     java.util.List var14 = var12.getCategories();
//     org.jfree.chart.util.RectangleInsets var15 = var12.getInsets();
//     java.awt.Stroke var16 = null;
//     var12.setOutlineStroke(var16);
//     org.jfree.data.category.CategoryDataset var19 = var12.getDataset(0);
//     org.jfree.chart.util.RectangleEdge var21 = var12.getDomainAxisEdge(0);
//     org.jfree.chart.axis.AxisSpace var22 = null;
//     org.jfree.chart.axis.AxisSpace var23 = var0.reserveSpace(var6, (org.jfree.chart.plot.Plot)var7, var11, var21, var22);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-16777216));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("AxisLabelEntity: label = hi!", var1, var2);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.util.Layer var3 = null;
    java.util.Collection var4 = var0.getDomainMarkers(0, var3);
    java.awt.Paint var5 = var0.getRangeGridlinePaint();
    boolean var6 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    boolean var9 = var8.getAutoRangeIncludesZero();
    org.jfree.chart.axis.MarkerAxisBand var10 = null;
    var8.setMarkerBand(var10);
    var8.setTickMarkOutsideLength(0.0f);
    double var14 = var8.getLabelAngle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-16777216), (org.jfree.chart.axis.ValueAxis)var8, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairLockedOnData(true);
//     var0.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
//     java.util.List var10 = var8.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var8.getRenderer((-16777216));
//     java.util.List var13 = var8.getAnnotations();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     var8.setRangeAxis(0, var15);
//     org.jfree.chart.ChartRenderingInfo var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     java.awt.geom.Rectangle2D var21 = null;
//     var20.setPlotArea(var21);
//     java.awt.geom.Point2D var23 = null;
//     var8.zoomRangeAxes(1.0d, 0.0d, var20, var23);
//     var0.handleClick((-1), 0, var20);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var5 = var4.getBackgroundPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.util.List var8 = var6.getCategories();
//     org.jfree.chart.util.RectangleInsets var9 = var6.getInsets();
//     double var11 = var9.calculateBottomInset((-1.0d));
//     double var12 = var9.getTop();
//     var4.setLegendItemGraphicPadding(var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var9 = var8.getTickMarkOutsideLength();
//     java.awt.Paint var10 = var8.getAxisLinePaint();
//     java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var12.getDomainMarkers(0, var15);
//     java.awt.Paint var17 = var12.getRangeGridlinePaint();
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var17};
//     java.awt.Paint[] var19 = null;
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var25, var27);
//     java.awt.Shape[] var29 = new java.awt.Shape[] { var27};
//     org.jfree.chart.plot.DefaultDrawingSupplier var30 = new org.jfree.chart.plot.DefaultDrawingSupplier(var11, var18, var19, var21, var23, var29);
//     java.awt.Shape var31 = var30.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var34 = var33.getTickMarkOutsideLength();
//     boolean var35 = var33.isAxisLineVisible();
//     java.awt.Stroke var36 = var33.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var41 = null;
//     var39.setTickLabelPaint((java.lang.Comparable)10L, var41);
//     var39.setCategoryLabelPositionOffset(0);
//     var39.setAxisLineVisible(true);
//     var39.configure();
//     java.awt.Font var49 = var39.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var52 = var51.getTickMarkOutsideLength();
//     java.awt.Paint var53 = var51.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("", var49, var53);
//     org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var31, var36, var53);
//     var2.setStroke(var36);
//     org.jfree.chart.util.RectangleAnchor var57 = var2.getLabelAnchor();
//     java.awt.geom.Point2D var58 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var57);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.text.TextAnchor var5 = var4.getRotationAnchor();
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, (-1.0f), 100.0f, var5, 100.0d, 2.0f, 2.0f);
    java.lang.String var10 = var5.toString();
    java.lang.String var11 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "TextAnchor.CENTER"+ "'", var10.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "TextAnchor.CENTER"+ "'", var11.equals("TextAnchor.CENTER"));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
    java.lang.Number var3 = var2.getMean();
    java.lang.Number var4 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10.0d+ "'", var4.equals(10.0d));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.LegendTitle var5 = var4.getLegend();
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var14 = var13.getTickMarkOutsideLength();
//     java.awt.Paint var15 = var13.getAxisLinePaint();
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var17.getDomainMarkers(0, var20);
//     java.awt.Paint var22 = var17.getRangeGridlinePaint();
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
//     java.awt.Paint[] var24 = null;
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var30, var32);
//     java.awt.Shape[] var34 = new java.awt.Shape[] { var32};
//     org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var23, var24, var26, var28, var34);
//     java.awt.Shape var36 = var35.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var39 = var38.getTickMarkOutsideLength();
//     boolean var40 = var38.isAxisLineVisible();
//     java.awt.Stroke var41 = var38.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var46 = null;
//     var44.setTickLabelPaint((java.lang.Comparable)10L, var46);
//     var44.setCategoryLabelPositionOffset(0);
//     var44.setAxisLineVisible(true);
//     var44.configure();
//     java.awt.Font var54 = var44.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var57 = var56.getTickMarkOutsideLength();
//     java.awt.Paint var58 = var56.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var59 = new org.jfree.chart.text.TextFragment("", var54, var58);
//     org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var36, var41, var58);
//     var7.setStroke(var41);
//     org.jfree.chart.util.RectangleAnchor var62 = var7.getLabelAnchor();
//     var5.setLegendItemGraphicLocation(var62);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     float var2 = var1.getBaselineOffset();
//     java.awt.Graphics2D var3 = null;
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.labels.ItemLabelPosition var8 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var9 = var8.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var5, (-1.0f), 100.0f, var9, 100.0d, 2.0f, 2.0f);
//     float var14 = var1.calculateBaselineOffset(var3, var9);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    var1.setAxisLineVisible(true);
    var1.configure();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
    java.util.List var12 = var10.getCategories();
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var10.getRenderer((-16777216));
    org.jfree.chart.util.SortOrder var15 = var10.getColumnRenderingOrder();
    var1.setPlot((org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.annotations.CategoryAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("100", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "hi!", var3, "", "hi!", "PlotOrientation.VERTICAL");
    org.jfree.chart.ui.Library[] var8 = var7.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Font var5 = var4.getItemFont();
//     org.jfree.chart.block.BlockContainer var6 = var4.getItemContainer();
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var12 = null;
//     var10.setTickLabelPaint((java.lang.Comparable)10L, var12);
//     var10.setCategoryLabelPositionOffset(0);
//     var10.setAxisLineVisible(true);
//     var10.configure();
//     java.awt.Font var20 = var10.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var23 = var22.getTickMarkOutsideLength();
//     java.awt.Paint var24 = var22.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("", var20, var24);
//     org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var20);
//     var4.setItemFont(var20);
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     java.lang.Object var31 = var4.draw(var28, var29, (java.lang.Object)(-1));
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.labels.ItemLabelPosition var8 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var9 = var8.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var5, (-1.0f), 100.0f, var9, 100.0d, 2.0f, 2.0f);
//     java.lang.String var14 = var9.toString();
//     java.awt.geom.Rectangle2D var15 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var1, 100.0f, 0.0f, var9);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var5 = var3.calculateBottomInset((-1.0d));
    double var6 = var3.getTop();
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var3.createOutsetRectangle(var7, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4.0d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 100.0f, 0.5f, 8.0d, (-1.0f), 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var3 = null;
//     var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
//     var1.setCategoryLabelPositionOffset(0);
//     var1.setAxisLineVisible(true);
//     var1.configure();
//     java.awt.Font var11 = var1.getTickLabelFont((java.lang.Comparable)0.0f);
//     java.lang.String var12 = var1.getLabelURL();
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var17 = var16.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var19 = var16.getDomainAxisEdge();
//     double var20 = var1.getCategoryStart(0, (-16777216), var15, var19);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.draw(var3, var4);
    boolean var6 = var1.getExpandToFitSpace();
    double var7 = var1.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var4 = var3.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var7 = var6.getTickMarkOutsideLength();
    boolean var8 = var6.isAxisLineVisible();
    java.awt.Stroke var9 = var6.getTickMarkStroke();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
    java.util.List var12 = var10.getCategories();
    org.jfree.chart.util.RectangleInsets var13 = var10.getInsets();
    double var15 = var13.calculateBottomInset((-1.0d));
    org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder(var4, var9, var13);
    var1.setPaint(var4);
    org.jfree.chart.text.TextAnchor var18 = var1.getLabelTextAnchor();
    var1.setValue(100.0d);
    org.jfree.chart.util.LengthAdjustmentType var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffsetType(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     var0.setAutoPopulateSeriesStroke(false);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var6 = var5.getRootPlot();
//     java.awt.Paint var7 = var5.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
//     org.jfree.chart.plot.Plot var9 = var5.getParent();
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.renderer.category.CategoryItemRendererState var14 = var0.initialise(var3, var4, var5, 1, var12);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
//     java.awt.Stroke var14 = null;
//     var9.setBorderStroke(var14);
//     org.jfree.chart.util.RectangleInsets var16 = var9.getPadding();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
//     java.awt.Paint var19 = var17.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var20 = var17.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     java.awt.Font var22 = var21.getItemFont();
//     var9.addLegend(var21);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var18
//     assertTrue("Contract failed: equals-hashcode on var7 and var18", var7.equals(var18) ? var7.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var7
//     assertTrue("Contract failed: equals-hashcode on var18 and var7", var18.equals(var7) ? var18.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.event.ChartProgressListener var5 = null;
    var4.removeProgressListener(var5);
    java.awt.Paint var7 = var4.getBorderPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var8 = var4.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
    boolean var6 = var0.equals((java.lang.Object)var5);
    int var7 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var0.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 4.0d, var2);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var1 = var0.getBaseItemLabelGenerator();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var6 = var5.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var7 = var5.getDomainAxis();
//     int var8 = var5.getBackgroundImageAlignment();
//     var5.setRangeCrosshairVisible(true);
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     java.awt.geom.Point2D var15 = null;
//     var5.zoomRangeAxes(10.0d, 0.0d, var14, var15);
//     org.jfree.chart.axis.ValueAxis var17 = var5.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var21 = null;
//     var19.setTickLabelPaint((java.lang.Comparable)10L, var21);
//     var19.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Shape var26 = var25.getDownArrow();
//     org.jfree.chart.axis.NumberTickUnit var28 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     java.lang.String var30 = var28.valueToString(100.0d);
//     var25.setTickUnit(var28);
//     org.jfree.data.category.CategoryDataset var32 = null;
//     var0.drawItem(var2, var3, var4, var5, var19, (org.jfree.chart.axis.ValueAxis)var25, var32, 0, 1, (-1));
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     java.lang.String var4 = var2.valueToString(100.0d);
//     java.lang.String var6 = var2.valueToString(8.0d);
//     org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)var2);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.axis.TickType var0 = null;
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.labels.ItemLabelPosition var7 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var4, (-1.0f), 100.0f, var8, 100.0d, 2.0f, 2.0f);
    org.jfree.chart.text.TextAnchor var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var15 = new org.jfree.chart.axis.NumberTick(var0, 1.0d, "", var8, var13, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    java.awt.Stroke var14 = null;
    var9.setBorderStroke(var14);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var20 = var19.getRootPlot();
    java.awt.Paint var21 = var19.getBackgroundPaint();
    var18.setPaint(var21);
    java.awt.Font var23 = var18.getFont();
    java.awt.Paint var24 = var18.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.addSubtitle(10, (org.jfree.chart.title.Title)var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var2 = var1.getLabel();
    java.awt.Paint var3 = var1.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Shape var1 = var0.getDownArrow();
//     var0.resizeRange(0.0d);
//     boolean var4 = var0.isPositiveArrowVisible();
//     java.lang.String var5 = var0.getLabelURL();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotOrientation var10 = var7.getOrientation();
//     var7.setBackgroundImageAlignment(1);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var17 = var16.getID();
//     java.awt.Font var18 = var16.getFont();
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("", var18);
//     var19.setURLText("PlotOrientation.VERTICAL");
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var23 = var22.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var24 = var22.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var25 = var22.getDomainAxisEdge();
//     boolean var26 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var25);
//     boolean var27 = var19.equals((java.lang.Object)var25);
//     org.jfree.chart.axis.AxisSpace var28 = null;
//     org.jfree.chart.axis.AxisSpace var29 = var0.reserveSpace(var6, (org.jfree.chart.plot.Plot)var7, var13, var25, var28);
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedRangeAxisSpace(var3);
//     org.jfree.chart.plot.Marker var5 = null;
//     var0.addRangeMarker(var5);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)false);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
//     boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
//     boolean var6 = var0.equals((java.lang.Object)var5);
//     org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     java.lang.Comparable var9 = null;
//     var0.addObject((java.lang.Object)100.0d, var9, (java.lang.Comparable)(byte)10);
//     java.lang.Comparable var13 = var0.getRowKey(0);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.setRangeCrosshairLockedOnData(true);
//     var14.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     java.lang.String var24 = var22.valueToString(100.0d);
//     java.lang.String var25 = var22.toString();
//     var0.addObject((java.lang.Object)true, (java.lang.Comparable)false, (java.lang.Comparable)var25);
//     
//     // Checks the contract:  equals-hashcode on var1 and var14
//     assertTrue("Contract failed: equals-hashcode on var1 and var14", var1.equals(var14) ? var1.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var1
//     assertTrue("Contract failed: equals-hashcode on var14 and var1", var14.equals(var1) ? var14.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.getAutoRangeIncludesZero();
    org.jfree.data.RangeType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var0.setBaseToolTipGenerator(var3, true);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var9 = var8.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var12 = var11.getTickMarkOutsideLength();
    boolean var13 = var11.isAxisLineVisible();
    java.awt.Stroke var14 = var11.getTickMarkStroke();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
    java.util.List var17 = var15.getCategories();
    org.jfree.chart.util.RectangleInsets var18 = var15.getInsets();
    double var20 = var18.calculateBottomInset((-1.0d));
    org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder(var9, var14, var18);
    var0.setSeriesPaint(10, var9, true);
    boolean var24 = var0.getAutoPopulateSeriesOutlinePaint();
    org.jfree.chart.urls.CategoryURLGenerator var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-1), var26, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     boolean var5 = var4.isNotify();
//     var4.clearSubtitles();
//     java.awt.Image var7 = var4.getBackgroundImage();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     java.awt.Paint var12 = var10.getBackgroundPaint();
//     var9.setPaint(var12);
//     var4.setBackgroundPaint(var12);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var1.getCategoryStart(10, (-16777216), var9, var10);
    var1.setTickMarkInsideLength(2.0f);
    java.lang.String var14 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "hi!"+ "'", var14.equals("hi!"));

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(var2);
//     org.jfree.chart.ChartRenderingInfo var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
//     java.awt.geom.Point2D var7 = null;
//     var0.zoomRangeAxes(100.0d, var6, var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     org.jfree.chart.plot.PlotState var12 = null;
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     var0.draw(var9, var10, var11, var12, var14);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var10 = var9.getID();
//     java.awt.Font var11 = var9.getFont();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var11);
//     var12.setURLText("PlotOrientation.VERTICAL");
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var18 = var15.getDomainAxisEdge();
//     boolean var19 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var18);
//     boolean var20 = var12.equals((java.lang.Object)var18);
//     double var21 = var1.getCategoryEnd(15, 1, var6, var18);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     float var5 = var1.getBackgroundAlpha();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var8 = var7.getTickMarkOutsideLength();
//     java.awt.Paint var9 = var7.getAxisLinePaint();
//     java.awt.Paint var10 = var7.getTickLabelPaint();
//     var7.setLabelAngle(0.0d);
//     java.util.List var13 = var1.getCategoriesForAxis(var7);
//     boolean var14 = var7.isVisible();
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var22 = null;
//     var20.setTickLabelPaint((java.lang.Comparable)10L, var22);
//     var20.setCategoryLabelPositionOffset(0);
//     var20.setAxisLineVisible(true);
//     var20.configure();
//     java.awt.Font var30 = var20.getTickLabelFont((java.lang.Comparable)0.0f);
//     var20.setTickMarkInsideLength(1.0f);
//     org.jfree.chart.axis.CategoryLabelPositions var34 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
//     var20.setCategoryLabelPositions(var34);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var37 = var36.getRootPlot();
//     java.util.List var38 = var36.getCategories();
//     org.jfree.chart.util.RectangleInsets var39 = var36.getInsets();
//     java.awt.Stroke var40 = null;
//     var36.setOutlineStroke(var40);
//     org.jfree.data.category.CategoryDataset var43 = var36.getDataset(0);
//     org.jfree.chart.util.RectangleEdge var45 = var36.getDomainAxisEdge(0);
//     org.jfree.chart.axis.CategoryLabelPosition var46 = var34.getLabelPosition(var45);
//     org.jfree.chart.ChartRenderingInfo var47 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var48 = new org.jfree.chart.plot.PlotRenderingInfo(var47);
//     java.awt.geom.Rectangle2D var49 = null;
//     var48.setPlotArea(var49);
//     java.awt.geom.Rectangle2D var51 = var48.getPlotArea();
//     org.jfree.chart.axis.AxisState var52 = var7.draw(var15, 0.0d, var17, var18, var45, var48);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    java.awt.Shape var0 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.NumberTickUnit var5 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    double var6 = var5.getSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var8 = new org.jfree.chart.entity.CategoryItemEntity(var0, "8", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var3, (java.lang.Comparable)var5, (java.lang.Comparable)0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    java.awt.Stroke var4 = null;
    var0.setOutlineStroke(var4);
    org.jfree.data.category.CategoryDataset var7 = var0.getDataset(0);
    org.jfree.chart.util.Layer var9 = null;
    java.util.Collection var10 = var0.getDomainMarkers(10, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var8 = var7.getTickMarkOutsideLength();
    java.awt.Paint var9 = var7.getAxisLinePaint();
    java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var11.getDomainMarkers(0, var14);
    java.awt.Paint var16 = var11.getRangeGridlinePaint();
    java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
    java.awt.Paint[] var18 = null;
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
    java.awt.Shape[] var28 = new java.awt.Shape[] { var26};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var17, var18, var20, var22, var28);
    java.awt.Shape var30 = var29.getNextShape();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var33 = var32.getTickMarkOutsideLength();
    boolean var34 = var32.isAxisLineVisible();
    java.awt.Stroke var35 = var32.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var40 = null;
    var38.setTickLabelPaint((java.lang.Comparable)10L, var40);
    var38.setCategoryLabelPositionOffset(0);
    var38.setAxisLineVisible(true);
    var38.configure();
    java.awt.Font var48 = var38.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var51 = var50.getTickMarkOutsideLength();
    java.awt.Paint var52 = var50.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var48, var52);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var30, var35, var52);
    var0.setSeriesPaint(100, var52, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-16777216), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var8 = var7.getTickMarkOutsideLength();
    java.awt.Paint var9 = var7.getAxisLinePaint();
    java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var11.getDomainMarkers(0, var14);
    java.awt.Paint var16 = var11.getRangeGridlinePaint();
    java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
    java.awt.Paint[] var18 = null;
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
    java.awt.Shape[] var28 = new java.awt.Shape[] { var26};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var17, var18, var20, var22, var28);
    java.awt.Shape var30 = var29.getNextShape();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var33 = var32.getTickMarkOutsideLength();
    boolean var34 = var32.isAxisLineVisible();
    java.awt.Stroke var35 = var32.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var40 = null;
    var38.setTickLabelPaint((java.lang.Comparable)10L, var40);
    var38.setCategoryLabelPositionOffset(0);
    var38.setAxisLineVisible(true);
    var38.configure();
    java.awt.Font var48 = var38.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var51 = var50.getTickMarkOutsideLength();
    java.awt.Paint var52 = var50.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var48, var52);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var30, var35, var52);
    var1.setStroke(var35);
    org.jfree.chart.util.RectangleAnchor var56 = var1.getLabelAnchor();
    org.jfree.chart.text.TextBlockAnchor var57 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var58 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var60 = new org.jfree.chart.axis.CategoryLabelPosition(var56, var57, var58, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var2 = var1.getLeftArrow();
    org.jfree.chart.entity.CategoryLabelEntity var5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var2, "hi!", "");
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var2, "hi!", "PlotOrientation.VERTICAL");
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var2, "AxisLabelEntity: label = hi!");
    java.lang.String var11 = var10.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "poly"+ "'", var11.equals("poly"));

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.category.CategoryDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.generateLabel(var1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    java.util.List var1 = var0.getTicks();
    java.util.Collection var2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.block.BlockFrame var5 = var4.getFrame();
    org.jfree.chart.event.TitleChangeEvent var6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var4);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var9 = var8.getToolTipText();
    java.lang.Object var10 = var8.clone();
    org.jfree.chart.util.HorizontalAlignment var11 = var8.getTextAlignment();
    var4.setTextAlignment(var11);
    boolean var13 = var2.equals((java.lang.Object)var4);
    double var14 = var2.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    int var3 = java.awt.Color.HSBtoRGB(0.5f, 0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    int var3 = java.awt.Color.HSBtoRGB(2.0f, 0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-100));

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var3 = var2.getURLText();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
//     org.jfree.chart.util.Layer var7 = null;
//     java.util.Collection var8 = var4.getDomainMarkers(0, var7);
//     java.awt.Paint var9 = var4.getRangeGridlinePaint();
//     var2.setBackgroundPaint(var9);
//     java.awt.Paint var11 = var2.getPaint();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var15 = null;
//     var13.setTickLabelPaint((java.lang.Comparable)10L, var15);
//     var13.setCategoryLabelPositionOffset(0);
//     var13.setAxisLineVisible(true);
//     var13.configure();
//     java.awt.Font var23 = var13.getTickLabelFont((java.lang.Comparable)0.0f);
//     var2.setFont(var23);
//     org.jfree.chart.text.TextLine var25 = new org.jfree.chart.text.TextLine("UnitType.ABSOLUTE", var23);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.util.Size2D var27 = var25.calculateDimensions(var26);
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var4 = var3.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var7 = var6.getTickMarkOutsideLength();
//     boolean var8 = var6.isAxisLineVisible();
//     java.awt.Stroke var9 = var6.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     java.util.List var12 = var10.getCategories();
//     org.jfree.chart.util.RectangleInsets var13 = var10.getInsets();
//     double var15 = var13.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder(var4, var9, var13);
//     var1.setPaint(var4);
//     org.jfree.chart.text.TextAnchor var18 = var1.getLabelTextAnchor();
//     var1.setValue(100.0d);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var23 = var22.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var24 = var22.getDomainAxis();
//     int var25 = var22.getBackgroundImageAlignment();
//     var22.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var22.getDomainMarkers(10, var29);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var22);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var33 = var32.getRootPlot();
//     java.util.List var34 = var32.getCategories();
//     org.jfree.chart.util.RectangleInsets var35 = var32.getInsets();
//     double var37 = var35.calculateBottomInset((-1.0d));
//     double var38 = var35.getTop();
//     var31.setPadding(var35);
//     var1.setLabelOffset(var35);
//     
//     // Checks the contract:  equals-hashcode on var10 and var32
//     assertTrue("Contract failed: equals-hashcode on var10 and var32", var10.equals(var32) ? var10.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var10
//     assertTrue("Contract failed: equals-hashcode on var32 and var10", var32.equals(var10) ? var32.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var33
//     assertTrue("Contract failed: equals-hashcode on var11 and var33", var11.equals(var33) ? var11.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var11
//     assertTrue("Contract failed: equals-hashcode on var33 and var11", var33.equals(var11) ? var33.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBaseNegativeItemLabelPosition();
    var0.setSeriesCreateEntities(10, (java.lang.Boolean)true);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Image var1 = var0.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     boolean var5 = var4.isNotify();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
//     java.awt.Paint var10 = var8.getBackgroundPaint();
//     var7.setPaint(var10);
//     java.awt.Font var12 = var7.getFont();
//     double var13 = var7.getContentYOffset();
//     var7.setURLText("PlotOrientation.VERTICAL");
//     var4.removeSubtitle((org.jfree.chart.title.Title)var7);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    java.awt.Color var1 = java.awt.Color.getColor("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var7 = var6.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var10 = var9.getTickMarkOutsideLength();
//     boolean var11 = var9.isAxisLineVisible();
//     java.awt.Stroke var12 = var9.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var14 = var13.getRootPlot();
//     java.util.List var15 = var13.getCategories();
//     org.jfree.chart.util.RectangleInsets var16 = var13.getInsets();
//     double var18 = var16.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder(var7, var12, var16);
//     var1.setRangeGridlineStroke(var12);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var24 = var23.getRootPlot();
//     java.util.List var25 = var23.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = var23.getRenderer((-16777216));
//     java.util.List var28 = var23.getAnnotations();
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     var23.setRangeAxis(0, var30);
//     org.jfree.chart.ChartRenderingInfo var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
//     java.awt.geom.Rectangle2D var36 = null;
//     var35.setPlotArea(var36);
//     java.awt.geom.Point2D var38 = null;
//     var23.zoomRangeAxes(1.0d, 0.0d, var35, var38);
//     java.awt.geom.Point2D var40 = null;
//     var1.zoomRangeAxes(104.0d, 4.0d, var35, var40);
//     
//     // Checks the contract:  equals-hashcode on var13 and var23
//     assertTrue("Contract failed: equals-hashcode on var13 and var23", var13.equals(var23) ? var13.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var13
//     assertTrue("Contract failed: equals-hashcode on var23 and var13", var23.equals(var13) ? var23.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var24
//     assertTrue("Contract failed: equals-hashcode on var14 and var24", var14.equals(var24) ? var14.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var14
//     assertTrue("Contract failed: equals-hashcode on var24 and var14", var24.equals(var14) ? var24.hashCode() == var14.hashCode() : true);
// 
//   }

//  public void test221() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
//
//
//    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var0 == true);
//
//  }
//
  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    java.awt.Color var1 = java.awt.Color.getColor("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape(15);
    java.awt.Paint var4 = var0.getSeriesFillPaint(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-16777216), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var9 = var8.getTickMarkOutsideLength();
//     java.awt.Paint var10 = var8.getAxisLinePaint();
//     java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var12.getDomainMarkers(0, var15);
//     java.awt.Paint var17 = var12.getRangeGridlinePaint();
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var17};
//     java.awt.Paint[] var19 = null;
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var25, var27);
//     java.awt.Shape[] var29 = new java.awt.Shape[] { var27};
//     org.jfree.chart.plot.DefaultDrawingSupplier var30 = new org.jfree.chart.plot.DefaultDrawingSupplier(var11, var18, var19, var21, var23, var29);
//     java.awt.Shape var31 = var30.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var34 = var33.getTickMarkOutsideLength();
//     boolean var35 = var33.isAxisLineVisible();
//     java.awt.Stroke var36 = var33.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var41 = null;
//     var39.setTickLabelPaint((java.lang.Comparable)10L, var41);
//     var39.setCategoryLabelPositionOffset(0);
//     var39.setAxisLineVisible(true);
//     var39.configure();
//     java.awt.Font var49 = var39.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var52 = var51.getTickMarkOutsideLength();
//     java.awt.Paint var53 = var51.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("", var49, var53);
//     org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var31, var36, var53);
//     var1.setSeriesPaint(100, var53, true);
//     boolean var58 = var1.getIncludeBaseInRange();
//     var1.setAutoPopulateSeriesOutlinePaint(true);
//     boolean var61 = var1.getIncludeBaseInRange();
//     org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var67 = null;
//     var65.setTickLabelPaint((java.lang.Comparable)10L, var67);
//     var65.setCategoryLabelPositionOffset(0);
//     var65.setAxisLineVisible(true);
//     var65.configure();
//     java.awt.Font var75 = var65.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var77 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var78 = var77.getTickMarkOutsideLength();
//     java.awt.Paint var79 = var77.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var80 = new org.jfree.chart.text.TextFragment("", var75, var79);
//     org.jfree.chart.block.LabelBlock var81 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var75);
//     var1.setBaseItemLabelFont(var75, false);
//     org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var86 = var85.getURLText();
//     org.jfree.chart.plot.CategoryPlot var87 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var88 = var87.getRootPlot();
//     org.jfree.chart.util.Layer var90 = null;
//     java.util.Collection var91 = var87.getDomainMarkers(0, var90);
//     java.awt.Paint var92 = var87.getRangeGridlinePaint();
//     var85.setBackgroundPaint(var92);
//     java.awt.Paint var94 = var85.getPaint();
//     org.jfree.chart.text.TextLine var95 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ", var75, var94);
//     
//     // Checks the contract:  equals-hashcode on var12 and var87
//     assertTrue("Contract failed: equals-hashcode on var12 and var87", var12.equals(var87) ? var12.hashCode() == var87.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var87 and var12
//     assertTrue("Contract failed: equals-hashcode on var87 and var12", var87.equals(var12) ? var87.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var88
//     assertTrue("Contract failed: equals-hashcode on var13 and var88", var13.equals(var88) ? var13.hashCode() == var88.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var88 and var13
//     assertTrue("Contract failed: equals-hashcode on var88 and var13", var88.equals(var13) ? var88.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    java.awt.Stroke var14 = null;
    var9.setBorderStroke(var14);
    var9.setBorderVisible(true);
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var22 = var21.getRootPlot();
    java.awt.Paint var23 = var21.getBackgroundPaint();
    var20.setPaint(var23);
    java.awt.Font var25 = var20.getFont();
    double var26 = var20.getContentYOffset();
    var20.setURLText("PlotOrientation.VERTICAL");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.addSubtitle(15, (org.jfree.chart.title.Title)var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var6 = var5.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var9 = var8.getTickMarkOutsideLength();
    boolean var10 = var8.isAxisLineVisible();
    java.awt.Stroke var11 = var8.getTickMarkStroke();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
    java.util.List var14 = var12.getCategories();
    org.jfree.chart.util.RectangleInsets var15 = var12.getInsets();
    double var17 = var15.calculateBottomInset((-1.0d));
    org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder(var6, var11, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-1), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 4.0d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.data.statistics.MeanAndStandardDeviation var4 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
    java.lang.Number var5 = var4.getStandardDeviation();
    var0.setObject((java.lang.Comparable)100, (java.lang.Object)var5);
    java.lang.Object var7 = var0.clone();
    java.util.List var8 = var0.getKeys();
    java.lang.Comparable var10 = var0.getKey(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100.0d+ "'", var5.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 100+ "'", var10.equals(100));

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(2.0f, (-1.0f), 0.0f);
    int var4 = var3.getRed();
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement();
    float[] var12 = new float[] { 100.0f, 0.0f, (-1.0f)};
    float[] var13 = java.awt.Color.RGBtoHSB(0, 1, (-16777216), var12);
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var15 = var3.getComponents(var13);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 84.0d, 0.2d, 1, (java.lang.Comparable)"RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     java.awt.Paint var2 = var0.getPaint();
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var6 = var5.getTickMarkOutsideLength();
//     java.awt.Paint var7 = var5.getAxisLinePaint();
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     org.jfree.chart.util.Layer var12 = null;
//     java.util.Collection var13 = var9.getDomainMarkers(0, var12);
//     java.awt.Paint var14 = var9.getRangeGridlinePaint();
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Paint[] var16 = null;
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
//     java.awt.Shape[] var26 = new java.awt.Shape[] { var24};
//     org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var15, var16, var18, var20, var26);
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var30 = var29.getTickMarkOutsideLength();
//     java.awt.Paint var31 = var29.getAxisLinePaint();
//     java.awt.Paint[] var32 = new java.awt.Paint[] { var31};
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var34 = var33.getRootPlot();
//     org.jfree.chart.util.Layer var36 = null;
//     java.util.Collection var37 = var33.getDomainMarkers(0, var36);
//     java.awt.Paint var38 = var33.getRangeGridlinePaint();
//     java.awt.Paint[] var39 = new java.awt.Paint[] { var38};
//     java.awt.Paint[] var40 = null;
//     java.awt.Stroke var41 = null;
//     java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
//     java.awt.Stroke var43 = null;
//     java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var46, var48);
//     java.awt.Shape[] var50 = new java.awt.Shape[] { var48};
//     org.jfree.chart.plot.DefaultDrawingSupplier var51 = new org.jfree.chart.plot.DefaultDrawingSupplier(var32, var39, var40, var42, var44, var50);
//     java.awt.Stroke[] var52 = null;
//     org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var55 = var53.lookupSeriesShape(15);
//     java.awt.Shape[] var56 = new java.awt.Shape[] { var55};
//     org.jfree.chart.plot.DefaultDrawingSupplier var57 = new org.jfree.chart.plot.DefaultDrawingSupplier(var3, var8, var42, var52, var56);
//     
//     // Checks the contract:  equals-hashcode on var9 and var33
//     assertTrue("Contract failed: equals-hashcode on var9 and var33", var9.equals(var33) ? var9.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var9
//     assertTrue("Contract failed: equals-hashcode on var33 and var9", var33.equals(var9) ? var33.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var34
//     assertTrue("Contract failed: equals-hashcode on var10 and var34", var10.equals(var34) ? var10.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var10
//     assertTrue("Contract failed: equals-hashcode on var34 and var10", var34.equals(var10) ? var34.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var51
//     assertTrue("Contract failed: equals-hashcode on var27 and var51", var27.equals(var51) ? var27.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var27
//     assertTrue("Contract failed: equals-hashcode on var51 and var27", var51.equals(var27) ? var51.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    var0.clear();
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    org.jfree.chart.event.ChartChangeEventType var3 = null;
    var2.setType(var3);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var5 = var4.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var6 = var4.getLegendItemGraphicLocation();
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var11 = var10.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var14 = var13.getTickMarkOutsideLength();
//     boolean var15 = var13.isAxisLineVisible();
//     java.awt.Stroke var16 = var13.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
//     java.util.List var19 = var17.getCategories();
//     org.jfree.chart.util.RectangleInsets var20 = var17.getInsets();
//     double var22 = var20.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var23 = new org.jfree.chart.block.LineBorder(var11, var16, var20);
//     var8.setPaint(var11);
//     boolean var25 = var6.equals((java.lang.Object)var11);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    boolean var5 = var1.isRangeGridlinesVisible();
    java.awt.Font var6 = var1.getNoDataMessageFont();
    boolean var7 = var1.isDomainZoomable();
    org.jfree.chart.axis.CategoryAnchor var8 = var1.getDomainGridlinePosition();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
    java.awt.Paint var12 = var10.getBackgroundPaint();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var10.getRangeMarkers(0, var15);
    org.jfree.chart.plot.Plot var17 = var10.getRootPlot();
    boolean var18 = var10.isDomainZoomable();
    var10.setRangeGridlinesVisible(false);
    boolean var21 = var8.equals((java.lang.Object)var10);
    var10.setAnchorValue(104.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
//     int var4 = var1.getBackgroundImageAlignment();
//     var1.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var8 = null;
//     java.util.Collection var9 = var1.getDomainMarkers(10, var8);
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
//     java.util.List var13 = var11.getCategories();
//     org.jfree.chart.util.RectangleInsets var14 = var11.getInsets();
//     double var16 = var14.calculateBottomInset((-1.0d));
//     double var17 = var14.getTop();
//     var10.setPadding(var14);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var20 = var19.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var21 = new org.jfree.chart.event.PlotChangeEvent(var20);
//     org.jfree.chart.JFreeChart var22 = null;
//     var21.setChart(var22);
//     org.jfree.chart.plot.Plot var24 = var21.getPlot();
//     var10.plotChanged(var21);
//     
//     // Checks the contract:  equals-hashcode on var11 and var19
//     assertTrue("Contract failed: equals-hashcode on var11 and var19", var11.equals(var19) ? var11.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var11
//     assertTrue("Contract failed: equals-hashcode on var19 and var11", var19.equals(var11) ? var19.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var20
//     assertTrue("Contract failed: equals-hashcode on var12 and var20", var12.equals(var20) ? var12.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var24
//     assertTrue("Contract failed: equals-hashcode on var12 and var24", var12.equals(var24) ? var12.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var12
//     assertTrue("Contract failed: equals-hashcode on var20 and var12", var20.equals(var12) ? var20.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var12
//     assertTrue("Contract failed: equals-hashcode on var24 and var12", var24.equals(var12) ? var24.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(var2);
    org.jfree.chart.ChartRenderingInfo var5 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
    java.awt.geom.Point2D var7 = null;
    var0.zoomRangeAxes(100.0d, var6, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var10 = var6.getSubplotInfo(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Font var5 = var4.getItemFont();
//     org.jfree.chart.block.BlockContainer var6 = var4.getItemContainer();
//     java.util.List var7 = var6.getBlocks();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     var6.setArrangement((org.jfree.chart.block.Arrangement)var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.util.Size2D var13 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var24 = var23.getTickMarkOutsideLength();
//     java.awt.Paint var25 = var23.getAxisLinePaint();
//     java.awt.Paint[] var26 = new java.awt.Paint[] { var25};
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var28 = var27.getRootPlot();
//     org.jfree.chart.util.Layer var30 = null;
//     java.util.Collection var31 = var27.getDomainMarkers(0, var30);
//     java.awt.Paint var32 = var27.getRangeGridlinePaint();
//     java.awt.Paint[] var33 = new java.awt.Paint[] { var32};
//     java.awt.Paint[] var34 = null;
//     java.awt.Stroke var35 = null;
//     java.awt.Stroke[] var36 = new java.awt.Stroke[] { var35};
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var40, var42);
//     java.awt.Shape[] var44 = new java.awt.Shape[] { var42};
//     org.jfree.chart.plot.DefaultDrawingSupplier var45 = new org.jfree.chart.plot.DefaultDrawingSupplier(var26, var33, var34, var36, var38, var44);
//     java.awt.Shape var46 = var45.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var49 = var48.getTickMarkOutsideLength();
//     boolean var50 = var48.isAxisLineVisible();
//     java.awt.Stroke var51 = var48.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var56 = null;
//     var54.setTickLabelPaint((java.lang.Comparable)10L, var56);
//     var54.setCategoryLabelPositionOffset(0);
//     var54.setAxisLineVisible(true);
//     var54.configure();
//     java.awt.Font var64 = var54.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var66 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var67 = var66.getTickMarkOutsideLength();
//     java.awt.Paint var68 = var66.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var69 = new org.jfree.chart.text.TextFragment("", var64, var68);
//     org.jfree.chart.LegendItem var70 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var46, var51, var68);
//     var17.setStroke(var51);
//     org.jfree.chart.util.RectangleAnchor var72 = var17.getLabelAnchor();
//     java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var13, 100.0d, (-1.0d), var72);
//     org.jfree.chart.axis.CategoryAxis var75 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var76 = var75.getTickMarkOutsideLength();
//     double var77 = var75.getUpperMargin();
//     java.lang.Object var78 = var6.draw(var10, var73, (java.lang.Object)var75);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.lang.Object var5 = null;
//     boolean var6 = var4.equals(var5);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var10 = var7.getRangeAxisEdge();
//     var4.setLegendItemGraphicEdge(var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var3 = var2.getURLText();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
//     org.jfree.chart.util.Layer var7 = null;
//     java.util.Collection var8 = var4.getDomainMarkers(0, var7);
//     java.awt.Paint var9 = var4.getRangeGridlinePaint();
//     var2.setBackgroundPaint(var9);
//     java.awt.Paint var11 = var2.getPaint();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var15 = null;
//     var13.setTickLabelPaint((java.lang.Comparable)10L, var15);
//     var13.setCategoryLabelPositionOffset(0);
//     var13.setAxisLineVisible(true);
//     var13.configure();
//     java.awt.Font var23 = var13.getTickLabelFont((java.lang.Comparable)0.0f);
//     var2.setFont(var23);
//     org.jfree.chart.text.TextLine var25 = new org.jfree.chart.text.TextLine("UnitType.ABSOLUTE", var23);
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var33 = null;
//     var31.setTickLabelPaint((java.lang.Comparable)10L, var33);
//     var31.setCategoryLabelPositionOffset(0);
//     var31.setAxisLineVisible(true);
//     var31.configure();
//     java.awt.Font var41 = var31.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var44 = var43.getTickMarkOutsideLength();
//     java.awt.Paint var45 = var43.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var46 = new org.jfree.chart.text.TextFragment("", var41, var45);
//     org.jfree.chart.block.LabelBlock var47 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var41);
//     org.jfree.chart.text.TextFragment var48 = new org.jfree.chart.text.TextFragment("", var41);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var51 = var49.getRangeAxisForDataset(0);
//     java.awt.Paint var52 = var49.getBackgroundPaint();
//     org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var41, var52);
//     var25.addFragment(var53);
//     
//     // Checks the contract:  equals-hashcode on var4 and var49
//     assertTrue("Contract failed: equals-hashcode on var4 and var49", var4.equals(var49) ? var4.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var4
//     assertTrue("Contract failed: equals-hashcode on var49 and var4", var49.equals(var4) ? var49.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    var1.setAxisLineVisible(true);
    org.jfree.chart.util.RectangleInsets var9 = var1.getTickLabelInsets();
    java.lang.String var10 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"+ "'", var10.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var1.getRangeMarkers(0, var6);
//     org.jfree.chart.plot.Plot var8 = var1.getRootPlot();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     java.awt.Paint var12 = var10.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var10);
//     boolean var14 = var10.isRangeGridlinesVisible();
//     java.awt.Font var15 = var10.getNoDataMessageFont();
//     boolean var16 = var10.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAnchor var17 = var10.getDomainGridlinePosition();
//     var1.setDomainGridlinePosition(var17);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var11
//     assertTrue("Contract failed: equals-hashcode on var8 and var11", var8.equals(var11) ? var8.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var8
//     assertTrue("Contract failed: equals-hashcode on var11 and var8", var11.equals(var8) ? var11.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 0);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var4 = var3.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var7 = var6.getTickMarkOutsideLength();
//     boolean var8 = var6.isAxisLineVisible();
//     java.awt.Stroke var9 = var6.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     java.util.List var12 = var10.getCategories();
//     org.jfree.chart.util.RectangleInsets var13 = var10.getInsets();
//     double var15 = var13.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder(var4, var9, var13);
//     var1.setPaint(var4);
//     org.jfree.chart.text.TextAnchor var18 = var1.getLabelTextAnchor();
//     var1.setValue(100.0d);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var23 = var22.getURLText();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var25 = var24.getRootPlot();
//     org.jfree.chart.util.Layer var27 = null;
//     java.util.Collection var28 = var24.getDomainMarkers(0, var27);
//     java.awt.Paint var29 = var24.getRangeGridlinePaint();
//     var22.setBackgroundPaint(var29);
//     java.awt.Paint var31 = var22.getPaint();
//     var1.setLabelPaint(var31);
//     
//     // Checks the contract:  equals-hashcode on var10 and var24
//     assertTrue("Contract failed: equals-hashcode on var10 and var24", var10.equals(var24) ? var10.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var10
//     assertTrue("Contract failed: equals-hashcode on var24 and var10", var24.equals(var10) ? var24.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var25
//     assertTrue("Contract failed: equals-hashcode on var11 and var25", var11.equals(var25) ? var11.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var11
//     assertTrue("Contract failed: equals-hashcode on var25 and var11", var25.equals(var11) ? var25.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var5 = var4.getTickMarkOutsideLength();
//     boolean var6 = var4.isAxisLineVisible();
//     var0.setDomainAxis(10, var4);
//     org.jfree.chart.axis.AxisSpace var8 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     var11.setRenderer(var13);
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     java.awt.geom.Point2D var18 = null;
//     var11.zoomRangeAxes(100.0d, var17, var18);
//     java.awt.geom.Rectangle2D var20 = null;
//     var17.setPlotArea(var20);
//     var0.handleClick(15, (-16777216), var17);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var0.", var11.equals(var0) == var0.equals(var11));
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var1.", var12.equals(var1) == var1.equals(var12));
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    var1.setAxisLineVisible(true);
    var1.configure();
    java.awt.Font var11 = var1.getTickLabelFont((java.lang.Comparable)0.0f);
    java.lang.String var12 = var1.getLabelURL();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var14, var16);
    org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity(var16, "", "hi!");
    org.jfree.chart.entity.AxisLabelEntity var23 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var16, "hi!", "PlotOrientation.VERTICAL");
    org.jfree.chart.axis.Axis var24 = var23.getAxis();
    java.lang.String var25 = var23.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AxisLabelEntity: label = hi!"+ "'", var25.equals("AxisLabelEntity: label = hi!"));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
    java.util.List var5 = var0.getAnnotations();
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    org.jfree.chart.ChartRenderingInfo var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
    java.awt.geom.Rectangle2D var13 = null;
    var12.setPlotArea(var13);
    java.awt.geom.Point2D var15 = null;
    var0.zoomRangeAxes(1.0d, 0.0d, var12, var15);
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var20 = var18.lookupSeriesShape(15);
    var0.setRenderer(15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.labels.ItemLabelPosition var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setBaseNegativeItemLabelPosition(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var10 = var4.createBufferedImage(0, 0, 8.0d, 100.0d, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var5 = var4.getTickMarkOutsideLength();
    boolean var6 = var4.isAxisLineVisible();
    var0.setDomainAxis(10, var4);
    java.awt.Paint var8 = var4.getLabelPaint();
    var4.setTickMarksVisible(true);
    var4.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.util.List var2 = var0.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
//     java.util.List var5 = var0.getAnnotations();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var0.setRangeAxis(0, var7);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = null;
//     var12.setPlotArea(var13);
//     java.awt.geom.Point2D var15 = null;
//     var0.zoomRangeAxes(1.0d, 0.0d, var12, var15);
//     org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var20 = var18.lookupSeriesShape(15);
//     var0.setRenderer(15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var22 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     var18.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var22);
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.annotations.CategoryAnnotation var25 = null;
//     boolean var26 = var24.removeAnnotation(var25);
//     org.jfree.chart.labels.CategoryToolTipGenerator var27 = null;
//     var24.setBaseToolTipGenerator(var27, true);
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var33 = var32.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var36 = var35.getTickMarkOutsideLength();
//     boolean var37 = var35.isAxisLineVisible();
//     java.awt.Stroke var38 = var35.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var40 = var39.getRootPlot();
//     java.util.List var41 = var39.getCategories();
//     org.jfree.chart.util.RectangleInsets var42 = var39.getInsets();
//     double var44 = var42.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var45 = new org.jfree.chart.block.LineBorder(var33, var38, var42);
//     var24.setSeriesPaint(10, var33, true);
//     boolean var48 = var24.getAutoPopulateSeriesOutlinePaint();
//     java.awt.Font var51 = var24.getItemLabelFont((-1), 10);
//     var18.setBaseItemLabelFont(var51, true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var0
//     assertTrue("Contract failed: equals-hashcode on var39 and var0", var39.equals(var0) ? var39.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var39 and var0.", var39.equals(var0) == var0.equals(var39));
//     
//     // Checks the contract:  equals-hashcode on var40 and var1
//     assertTrue("Contract failed: equals-hashcode on var40 and var1", var40.equals(var1) ? var40.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var40 and var1.", var40.equals(var1) == var1.equals(var40));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var24.", var18.equals(var24) == var24.equals(var18));
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, (-1.0f));
    org.jfree.data.category.CategoryDataset var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var8 = new org.jfree.chart.entity.CategoryItemEntity(var2, "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "ChartEntity: tooltip = ", var5, (java.lang.Comparable)(byte)0, (java.lang.Comparable)84.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    boolean var2 = var0.containsKey("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
//     int var3 = var0.getBackgroundImageAlignment();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var6 = var5.getTickMarkOutsideLength();
//     java.awt.Paint var7 = var5.getAxisLinePaint();
//     java.awt.Paint var8 = var5.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     java.awt.Paint var12 = var10.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var10);
//     boolean var14 = var13.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var8, var13, 100, 10);
//     java.awt.Stroke var18 = null;
//     var13.setBorderStroke(var18);
//     var13.setBorderVisible(true);
//     org.jfree.chart.event.ChartChangeEvent var22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var11
//     assertTrue("Contract failed: equals-hashcode on var1 and var11", var1.equals(var11) ? var1.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var1
//     assertTrue("Contract failed: equals-hashcode on var11 and var1", var11.equals(var1) ? var11.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.util.List var2 = var0.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
//     org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var8 = var7.getTickMarkOutsideLength();
//     java.awt.Paint var9 = var7.getAxisLinePaint();
//     java.awt.Paint var10 = var7.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
//     java.awt.Paint var14 = var12.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var12);
//     boolean var16 = var15.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var10, var15, 100, 10);
//     var15.setNotify(true);
//     boolean var22 = var5.equals((java.lang.Object)true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
//     java.awt.Stroke var14 = null;
//     var9.setBorderStroke(var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var19 = var18.getRootPlot();
//     java.awt.Paint var20 = var18.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var18);
//     org.jfree.chart.util.Layer var23 = null;
//     java.util.Collection var24 = var18.getRangeMarkers(0, var23);
//     org.jfree.chart.plot.Plot var25 = var18.getRootPlot();
//     boolean var26 = var18.isDomainZoomable();
//     var18.setRangeGridlinesVisible(false);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.util.Size2D var32 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var43 = var42.getTickMarkOutsideLength();
//     java.awt.Paint var44 = var42.getAxisLinePaint();
//     java.awt.Paint[] var45 = new java.awt.Paint[] { var44};
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var47 = var46.getRootPlot();
//     org.jfree.chart.util.Layer var49 = null;
//     java.util.Collection var50 = var46.getDomainMarkers(0, var49);
//     java.awt.Paint var51 = var46.getRangeGridlinePaint();
//     java.awt.Paint[] var52 = new java.awt.Paint[] { var51};
//     java.awt.Paint[] var53 = null;
//     java.awt.Stroke var54 = null;
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
//     java.awt.Stroke var56 = null;
//     java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var59, var61);
//     java.awt.Shape[] var63 = new java.awt.Shape[] { var61};
//     org.jfree.chart.plot.DefaultDrawingSupplier var64 = new org.jfree.chart.plot.DefaultDrawingSupplier(var45, var52, var53, var55, var57, var63);
//     java.awt.Shape var65 = var64.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var68 = var67.getTickMarkOutsideLength();
//     boolean var69 = var67.isAxisLineVisible();
//     java.awt.Stroke var70 = var67.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var73 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var75 = null;
//     var73.setTickLabelPaint((java.lang.Comparable)10L, var75);
//     var73.setCategoryLabelPositionOffset(0);
//     var73.setAxisLineVisible(true);
//     var73.configure();
//     java.awt.Font var83 = var73.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var85 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var86 = var85.getTickMarkOutsideLength();
//     java.awt.Paint var87 = var85.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var88 = new org.jfree.chart.text.TextFragment("", var83, var87);
//     org.jfree.chart.LegendItem var89 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var65, var70, var87);
//     var36.setStroke(var70);
//     org.jfree.chart.util.RectangleAnchor var91 = var36.getLabelAnchor();
//     java.awt.geom.Rectangle2D var92 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 100.0d, (-1.0d), var91);
//     var18.drawBackgroundImage(var29, var92);
//     var9.draw(var16, var92);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var4 = var1.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     java.awt.Paint var6 = var5.getBackgroundPaint();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 10.0d);
//     org.jfree.chart.util.Size2D var11 = var5.arrange(var7, var10);
//     org.jfree.data.Range var14 = new org.jfree.data.Range(0.0d, 4.0d);
//     org.jfree.chart.block.RectangleConstraint var15 = var10.toRangeHeight(var14);
//     org.jfree.data.KeyedObject var16 = new org.jfree.data.KeyedObject((java.lang.Comparable)"8", (java.lang.Object)var10);
//     java.lang.Object var17 = var16.clone();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var19 = var18.getRootPlot();
//     java.awt.Paint var20 = var18.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var21 = var18.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     java.awt.Paint var23 = var22.getBackgroundPaint();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.data.Range var25 = null;
//     org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var25, 10.0d);
//     org.jfree.chart.util.Size2D var28 = var22.arrange(var24, var27);
//     boolean var29 = var16.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var28
//     assertTrue("Contract failed: equals-hashcode on var11 and var28", var11.equals(var28) ? var11.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var11
//     assertTrue("Contract failed: equals-hashcode on var28 and var11", var28.equals(var11) ? var28.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var1.getRangeMarkers(0, var6);
//     org.jfree.chart.plot.Plot var8 = var1.getRootPlot();
//     boolean var9 = var1.isDomainZoomable();
//     var1.setRangeGridlinesVisible(false);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.util.Size2D var15 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var26 = var25.getTickMarkOutsideLength();
//     java.awt.Paint var27 = var25.getAxisLinePaint();
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var30 = var29.getRootPlot();
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var29.getDomainMarkers(0, var32);
//     java.awt.Paint var34 = var29.getRangeGridlinePaint();
//     java.awt.Paint[] var35 = new java.awt.Paint[] { var34};
//     java.awt.Paint[] var36 = null;
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var42, var44);
//     java.awt.Shape[] var46 = new java.awt.Shape[] { var44};
//     org.jfree.chart.plot.DefaultDrawingSupplier var47 = new org.jfree.chart.plot.DefaultDrawingSupplier(var28, var35, var36, var38, var40, var46);
//     java.awt.Shape var48 = var47.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var51 = var50.getTickMarkOutsideLength();
//     boolean var52 = var50.isAxisLineVisible();
//     java.awt.Stroke var53 = var50.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var58 = null;
//     var56.setTickLabelPaint((java.lang.Comparable)10L, var58);
//     var56.setCategoryLabelPositionOffset(0);
//     var56.setAxisLineVisible(true);
//     var56.configure();
//     java.awt.Font var66 = var56.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var68 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var69 = var68.getTickMarkOutsideLength();
//     java.awt.Paint var70 = var68.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var71 = new org.jfree.chart.text.TextFragment("", var66, var70);
//     org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var48, var53, var70);
//     var19.setStroke(var53);
//     org.jfree.chart.util.RectangleAnchor var74 = var19.getLabelAnchor();
//     java.awt.geom.Rectangle2D var75 = org.jfree.chart.util.RectangleAnchor.createRectangle(var15, 100.0d, (-1.0d), var74);
//     var1.drawBackgroundImage(var12, var75);
//     org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var78 = var77.getRootPlot();
//     java.awt.Paint var79 = var77.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var80 = var77.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var81 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var77);
//     java.awt.Paint var82 = var81.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var83 = var81.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var84 = org.jfree.chart.util.RectangleAnchor.coordinates(var75, var83);
//     
//     // Checks the contract:  equals-hashcode on var29 and var77
//     assertTrue("Contract failed: equals-hashcode on var29 and var77", var29.equals(var77) ? var29.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var29
//     assertTrue("Contract failed: equals-hashcode on var77 and var29", var77.equals(var29) ? var77.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var78
//     assertTrue("Contract failed: equals-hashcode on var30 and var78", var30.equals(var78) ? var30.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var30
//     assertTrue("Contract failed: equals-hashcode on var78 and var30", var78.equals(var30) ? var78.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
//     boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
//     boolean var6 = var0.equals((java.lang.Object)var5);
//     int var7 = var0.getColumnCount();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var10 = var9.getTickMarkOutsideLength();
//     java.awt.Paint var11 = var9.getAxisLinePaint();
//     java.awt.Paint var12 = var9.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
//     java.awt.Paint var16 = var14.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var14);
//     boolean var18 = var17.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var12, var17, 100, 10);
//     var17.setNotify(true);
//     org.jfree.data.KeyedObjects var24 = new org.jfree.data.KeyedObjects();
//     org.jfree.data.statistics.MeanAndStandardDeviation var28 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     java.lang.Number var29 = var28.getStandardDeviation();
//     var24.setObject((java.lang.Comparable)100, (java.lang.Object)var29);
//     java.lang.Object var31 = var24.clone();
//     java.util.List var32 = var24.getKeys();
//     boolean var33 = var17.equals((java.lang.Object)var24);
//     boolean var34 = var0.equals((java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var1 and var14
//     assertTrue("Contract failed: equals-hashcode on var1 and var14", var1.equals(var14) ? var1.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var1
//     assertTrue("Contract failed: equals-hashcode on var14 and var1", var14.equals(var1) ? var14.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    var0.clear();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var3 = var2.getRootPlot();
    java.awt.Paint var4 = var2.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var5 = var2.getRowRenderingOrder();
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    java.awt.Font var7 = var6.getItemFont();
    org.jfree.chart.block.BlockContainer var8 = var6.getItemContainer();
    java.util.List var9 = var8.getBlocks();
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement();
    var8.setArrangement((org.jfree.chart.block.Arrangement)var10);
    java.awt.Graphics2D var12 = null;
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 4.0d);
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 0.0d);
    org.jfree.data.Range var18 = null;
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var20 = var0.arrange(var8, var12, var19);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
    int var4 = var1.getBackgroundImageAlignment();
    var1.setRangeCrosshairVisible(true);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var1.getDomainMarkers(10, var8);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
    java.util.List var13 = var11.getCategories();
    org.jfree.chart.util.RectangleInsets var14 = var11.getInsets();
    double var16 = var14.calculateBottomInset((-1.0d));
    double var17 = var14.getTop();
    var10.setPadding(var14);
    org.jfree.chart.event.ChartChangeListener var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addChangeListener(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 4.0d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("[size=100]", var1);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxisForDataset(0);
//     var0.setAnchorValue(0.2d);
//     org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis();
//     int var10 = var7.getBackgroundImageAlignment();
//     var7.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var14 = null;
//     java.util.Collection var15 = var7.getDomainMarkers(10, var14);
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
//     java.util.List var19 = var17.getCategories();
//     org.jfree.chart.util.RectangleInsets var20 = var17.getInsets();
//     double var22 = var20.calculateBottomInset((-1.0d));
//     double var23 = var20.getTop();
//     var16.setPadding(var20);
//     var0.setInsets(var20);
//     org.jfree.chart.axis.AxisLocation var27 = var0.getDomainAxisLocation(0);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotOrientation var31 = var28.getOrientation();
//     org.jfree.chart.util.RectangleEdge var32 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var27, var31);
//     
//     // Checks the contract:  equals-hashcode on var17 and var28
//     assertTrue("Contract failed: equals-hashcode on var17 and var28", var17.equals(var28) ? var17.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var17
//     assertTrue("Contract failed: equals-hashcode on var28 and var17", var28.equals(var17) ? var28.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var1);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var3 = var2.getID();
//     java.awt.Font var4 = var2.getFont();
//     org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("", var4);
//     var5.setURLText("PlotOrientation.VERTICAL");
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var11 = var8.getDomainAxisEdge();
//     boolean var12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var11);
//     boolean var13 = var5.equals((java.lang.Object)var11);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var5.draw(var14, var15);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("");

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var5, "hi!", "hi!");
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var16 = var15.getTickMarkOutsideLength();
    java.awt.Paint var17 = var15.getAxisLinePaint();
    java.awt.Paint[] var18 = new java.awt.Paint[] { var17};
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var20 = var19.getRootPlot();
    org.jfree.chart.util.Layer var22 = null;
    java.util.Collection var23 = var19.getDomainMarkers(0, var22);
    java.awt.Paint var24 = var19.getRangeGridlinePaint();
    java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
    java.awt.Paint[] var26 = null;
    java.awt.Stroke var27 = null;
    java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
    java.awt.Stroke var29 = null;
    java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var32, var34);
    java.awt.Shape[] var36 = new java.awt.Shape[] { var34};
    org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var18, var25, var26, var28, var30, var36);
    java.awt.Shape var38 = var37.getNextShape();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var41 = var40.getTickMarkOutsideLength();
    boolean var42 = var40.isAxisLineVisible();
    java.awt.Stroke var43 = var40.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var48 = null;
    var46.setTickLabelPaint((java.lang.Comparable)10L, var48);
    var46.setCategoryLabelPositionOffset(0);
    var46.setAxisLineVisible(true);
    var46.configure();
    java.awt.Font var56 = var46.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var59 = var58.getTickMarkOutsideLength();
    java.awt.Paint var60 = var58.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var61 = new org.jfree.chart.text.TextFragment("", var56, var60);
    org.jfree.chart.LegendItem var62 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var38, var43, var60);
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var64 = var63.getRootPlot();
    org.jfree.chart.util.Layer var66 = null;
    java.util.Collection var67 = var63.getDomainMarkers(0, var66);
    java.awt.Paint var68 = var63.getRangeGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var69 = new org.jfree.chart.LegendItem(var0, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "", "ChartEntity: tooltip = ", var9, var43, var68);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.annotations.CategoryAnnotation var1 = null;
//     boolean var2 = var0.removeAnnotation(var1);
//     org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
//     var0.setBaseToolTipGenerator(var3, true);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var9 = var8.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var12 = var11.getTickMarkOutsideLength();
//     boolean var13 = var11.isAxisLineVisible();
//     java.awt.Stroke var14 = var11.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
//     java.util.List var17 = var15.getCategories();
//     org.jfree.chart.util.RectangleInsets var18 = var15.getInsets();
//     double var20 = var18.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder(var9, var14, var18);
//     var0.setSeriesPaint(10, var9, true);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = var0.getLegendItemURLGenerator();
//     org.jfree.chart.urls.CategoryURLGenerator var26 = var0.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var29 = var28.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var33 = var32.getTickMarkOutsideLength();
//     boolean var34 = var32.isAxisLineVisible();
//     var28.setDomainAxis(10, var32);
//     java.awt.Paint var36 = var32.getLabelPaint();
//     var0.setSeriesOutlinePaint(10, var36);
//     
//     // Checks the contract:  equals-hashcode on var15 and var28
//     assertTrue("Contract failed: equals-hashcode on var15 and var28", var15.equals(var28) ? var15.hashCode() == var28.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var28.", var15.equals(var28) == var28.equals(var15));
//     
//     // Checks the contract:  equals-hashcode on var16 and var29
//     assertTrue("Contract failed: equals-hashcode on var16 and var29", var16.equals(var29) ? var16.hashCode() == var29.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var29.", var16.equals(var29) == var29.equals(var16));
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var2 = var1.getLabel();
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var11 = var10.getTickMarkOutsideLength();
    java.awt.Paint var12 = var10.getAxisLinePaint();
    java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var14.getDomainMarkers(0, var17);
    java.awt.Paint var19 = var14.getRangeGridlinePaint();
    java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
    java.awt.Paint[] var21 = null;
    java.awt.Stroke var22 = null;
    java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
    java.awt.Stroke var24 = null;
    java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var27, var29);
    java.awt.Shape[] var31 = new java.awt.Shape[] { var29};
    org.jfree.chart.plot.DefaultDrawingSupplier var32 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var20, var21, var23, var25, var31);
    java.awt.Shape var33 = var32.getNextShape();
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var36 = var35.getTickMarkOutsideLength();
    boolean var37 = var35.isAxisLineVisible();
    java.awt.Stroke var38 = var35.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var43 = null;
    var41.setTickLabelPaint((java.lang.Comparable)10L, var43);
    var41.setCategoryLabelPositionOffset(0);
    var41.setAxisLineVisible(true);
    var41.configure();
    java.awt.Font var51 = var41.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var54 = var53.getTickMarkOutsideLength();
    java.awt.Paint var55 = var53.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var56 = new org.jfree.chart.text.TextFragment("", var51, var55);
    org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var33, var38, var55);
    var4.setStroke(var38);
    org.jfree.chart.util.RectangleAnchor var59 = var4.getLabelAnchor();
    var1.setLabelAnchor(var59);
    org.jfree.chart.text.TextBlockAnchor var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var62 = new org.jfree.chart.axis.CategoryLabelPosition(var59, var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
//     var9.setNotify(true);
//     org.jfree.data.KeyedObjects var16 = new org.jfree.data.KeyedObjects();
//     org.jfree.data.statistics.MeanAndStandardDeviation var20 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     java.lang.Number var21 = var20.getStandardDeviation();
//     var16.setObject((java.lang.Comparable)100, (java.lang.Object)var21);
//     java.lang.Object var23 = var16.clone();
//     java.util.List var24 = var16.getKeys();
//     boolean var25 = var9.equals((java.lang.Object)var16);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var28 = var27.getRootPlot();
//     java.awt.Paint var29 = var27.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var27);
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var33 = var32.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var36 = var35.getTickMarkOutsideLength();
//     boolean var37 = var35.isAxisLineVisible();
//     java.awt.Stroke var38 = var35.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var40 = var39.getRootPlot();
//     java.util.List var41 = var39.getCategories();
//     org.jfree.chart.util.RectangleInsets var42 = var39.getInsets();
//     double var44 = var42.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var45 = new org.jfree.chart.block.LineBorder(var33, var38, var42);
//     var27.setRangeGridlineStroke(var38);
//     var9.setBorderStroke(var38);
//     
//     // Checks the contract:  equals-hashcode on var6 and var39
//     assertTrue("Contract failed: equals-hashcode on var6 and var39", var6.equals(var39) ? var6.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var6
//     assertTrue("Contract failed: equals-hashcode on var39 and var6", var39.equals(var6) ? var39.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var40
//     assertTrue("Contract failed: equals-hashcode on var7 and var40", var7.equals(var40) ? var7.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var7
//     assertTrue("Contract failed: equals-hashcode on var40 and var7", var40.equals(var7) ? var40.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.LegendTitle var5 = var4.getLegend();
//     java.awt.Paint var6 = var5.getItemPaint();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
//     java.awt.Paint var10 = var8.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.data.Range var15 = null;
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(var15, 10.0d);
//     org.jfree.chart.util.Size2D var18 = var12.arrange(var14, var17);
//     org.jfree.data.Range var21 = new org.jfree.data.Range(0.0d, 4.0d);
//     org.jfree.chart.block.RectangleConstraint var22 = var17.toRangeHeight(var21);
//     org.jfree.chart.util.Size2D var23 = var5.arrange(var7, var17);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var23
//     assertTrue("Contract failed: equals-hashcode on var18 and var23", var18.equals(var23) ? var18.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var18
//     assertTrue("Contract failed: equals-hashcode on var23 and var18", var23.equals(var18) ? var23.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.awt.Paint var2 = var0.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Font var5 = var4.getItemFont();
    org.jfree.chart.block.BlockContainer var6 = var4.getItemContainer();
    java.util.List var7 = var6.getBlocks();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    var6.setArrangement((org.jfree.chart.block.Arrangement)var8);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var13 = null;
    var11.setTickLabelPaint((java.lang.Comparable)10L, var13);
    var11.setCategoryLabelPositionOffset(0);
    var11.setAxisLineVisible(true);
    var11.configure();
    java.awt.Font var21 = var11.getTickLabelFont((java.lang.Comparable)0.0f);
    java.lang.String var22 = var11.getLabelURL();
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
    org.jfree.chart.entity.ChartEntity var30 = new org.jfree.chart.entity.ChartEntity(var26, "", "hi!");
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var11, var26, "hi!", "PlotOrientation.VERTICAL");
    java.lang.Object var34 = var11.clone();
    boolean var35 = var8.equals((java.lang.Object)var11);
    var8.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape(15);
    java.awt.Paint var4 = var0.getSeriesFillPaint(10);
    java.lang.Boolean var6 = null;
    var0.setSeriesVisibleInLegend(15, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    float[] var7 = new float[] { 100.0f, 0.0f, (-1.0f)};
    float[] var8 = java.awt.Color.RGBtoHSB(0, 1, (-16777216), var7);
    boolean var9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var8);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
    java.awt.Paint var12 = var10.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var13 = var10.getRowRenderingOrder();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
    java.awt.Font var15 = var14.getItemFont();
    org.jfree.chart.block.BlockContainer var16 = var14.getItemContainer();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var19 = var18.getTickMarkOutsideLength();
    java.awt.Paint var20 = var18.getAxisLinePaint();
    java.awt.Paint var21 = var18.getTickLabelPaint();
    var0.add((org.jfree.chart.block.Block)var16, (java.lang.Object)var18);
    double var23 = var18.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.getAutoRangeIncludesZero();
    org.jfree.chart.axis.MarkerAxisBand var2 = null;
    var0.setMarkerBand(var2);
    var0.setLowerMargin(0.2d);
    org.jfree.data.Range var8 = new org.jfree.data.Range(0.0d, 4.0d);
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
    var0.setRangeWithMargins(var8);
    double var13 = var8.constrain(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4.0d);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
//     int var4 = var1.getBackgroundImageAlignment();
//     var1.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var8 = null;
//     java.util.Collection var9 = var1.getDomainMarkers(10, var8);
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var14 = var13.getRootPlot();
//     java.awt.Paint var15 = var13.getBackgroundPaint();
//     var12.setPaint(var15);
//     java.awt.Font var17 = var12.getFont();
//     double var18 = var12.getContentYOffset();
//     var12.setURLText("PlotOrientation.VERTICAL");
//     var10.removeSubtitle((org.jfree.chart.title.Title)var12);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var24 = var23.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var25 = var23.getDomainAxis();
//     int var26 = var23.getBackgroundImageAlignment();
//     var23.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var30 = null;
//     java.util.Collection var31 = var23.getDomainMarkers(10, var30);
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var23);
//     var32.removeLegend();
//     java.awt.Paint var34 = var32.getBorderPaint();
//     var12.setPaint(var34);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var24
//     assertTrue("Contract failed: equals-hashcode on var2 and var24", var2.equals(var24) ? var2.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var2
//     assertTrue("Contract failed: equals-hashcode on var24 and var2", var24.equals(var2) ? var24.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    java.lang.String var2 = var1.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var2.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.awt.Paint var2 = var0.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Paint var5 = var4.getBackgroundPaint();
    org.jfree.chart.util.RectangleAnchor var6 = var4.getLegendItemGraphicLocation();
    java.lang.String var7 = var6.toString();
    org.jfree.chart.text.TextBlockAnchor var8 = null;
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var12 = null;
    var10.setTickLabelPaint((java.lang.Comparable)10L, var12);
    var10.setCategoryLabelPositionOffset(0);
    var10.setAxisLineVisible(true);
    var10.configure();
    java.awt.Font var20 = var10.getTickLabelFont((java.lang.Comparable)0.0f);
    var10.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var10.setCategoryLabelPositions(var24);
    org.jfree.chart.axis.CategoryLabelPositions var27 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPosition var28 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var29 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var27, var28);
    org.jfree.chart.axis.CategoryLabelPositions var30 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var24, var28);
    org.jfree.chart.text.TextAnchor var31 = var28.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var35 = new org.jfree.chart.axis.CategoryLabelPosition(var6, var8, var31, 1.0d, var33, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "RectangleAnchor.CENTER"+ "'", var7.equals("RectangleAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape(15);
    org.jfree.chart.annotations.CategoryAnnotation var3 = null;
    boolean var4 = var0.removeAnnotation(var3);
    org.jfree.data.category.CategoryDataset var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var6 = var0.findRangeBounds(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    java.awt.Stroke var14 = null;
    var9.setBorderStroke(var14);
    org.jfree.chart.event.ChartProgressListener var16 = null;
    var9.addProgressListener(var16);
    java.awt.Image var18 = null;
    var9.setBackgroundImage(var18);
    var9.setAntiAlias(false);
    org.jfree.chart.event.ChartChangeListener var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.removeChangeListener(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedRangeAxisSpace(var3);
    var0.clearDomainMarkers(0);
    org.jfree.chart.plot.DatasetRenderingOrder var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)true);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    java.awt.Stroke var14 = null;
    var9.setBorderStroke(var14);
    var9.setBorderVisible(true);
    var9.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var4 = var3.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var7 = var6.getTickMarkOutsideLength();
    boolean var8 = var6.isAxisLineVisible();
    java.awt.Stroke var9 = var6.getTickMarkStroke();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
    java.util.List var12 = var10.getCategories();
    org.jfree.chart.util.RectangleInsets var13 = var10.getInsets();
    double var15 = var13.calculateBottomInset((-1.0d));
    org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder(var4, var9, var13);
    var1.setPaint(var4);
    org.jfree.chart.text.TextAnchor var18 = var1.getLabelTextAnchor();
    org.jfree.chart.util.LengthAdjustmentType var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffsetType(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var3 = var0.getDomainAxisEdge();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var6 = var5.getDownArrow();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.String var10 = var8.valueToString(100.0d);
    var5.setTickUnit(var8);
    var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var5);
    java.lang.String var13 = var0.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "100"+ "'", var10.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    java.awt.Color var2 = java.awt.Color.getColor("TextAnchor.CENTER", 0);
    float[] var9 = new float[] { 100.0f, 0.0f, (-1.0f)};
    float[] var10 = java.awt.Color.RGBtoHSB(0, 1, (-16777216), var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var11 = var2.getRGBComponents(var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("poly");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     boolean var5 = var4.isNotify();
//     var4.clearSubtitles();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     java.awt.Paint var11 = var9.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.util.Layer var14 = null;
//     java.util.Collection var15 = var9.getRangeMarkers(0, var14);
//     org.jfree.chart.plot.Plot var16 = var9.getRootPlot();
//     boolean var17 = var9.isDomainZoomable();
//     var9.setRangeGridlinesVisible(false);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.util.Size2D var23 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var34 = var33.getTickMarkOutsideLength();
//     java.awt.Paint var35 = var33.getAxisLinePaint();
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var38 = var37.getRootPlot();
//     org.jfree.chart.util.Layer var40 = null;
//     java.util.Collection var41 = var37.getDomainMarkers(0, var40);
//     java.awt.Paint var42 = var37.getRangeGridlinePaint();
//     java.awt.Paint[] var43 = new java.awt.Paint[] { var42};
//     java.awt.Paint[] var44 = null;
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Stroke var47 = null;
//     java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var53 = org.jfree.chart.util.ShapeUtilities.equal(var50, var52);
//     java.awt.Shape[] var54 = new java.awt.Shape[] { var52};
//     org.jfree.chart.plot.DefaultDrawingSupplier var55 = new org.jfree.chart.plot.DefaultDrawingSupplier(var36, var43, var44, var46, var48, var54);
//     java.awt.Shape var56 = var55.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var59 = var58.getTickMarkOutsideLength();
//     boolean var60 = var58.isAxisLineVisible();
//     java.awt.Stroke var61 = var58.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var66 = null;
//     var64.setTickLabelPaint((java.lang.Comparable)10L, var66);
//     var64.setCategoryLabelPositionOffset(0);
//     var64.setAxisLineVisible(true);
//     var64.configure();
//     java.awt.Font var74 = var64.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var76 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var77 = var76.getTickMarkOutsideLength();
//     java.awt.Paint var78 = var76.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var79 = new org.jfree.chart.text.TextFragment("", var74, var78);
//     org.jfree.chart.LegendItem var80 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var56, var61, var78);
//     var27.setStroke(var61);
//     org.jfree.chart.util.RectangleAnchor var82 = var27.getLabelAnchor();
//     java.awt.geom.Rectangle2D var83 = org.jfree.chart.util.RectangleAnchor.createRectangle(var23, 100.0d, (-1.0d), var82);
//     var9.drawBackgroundImage(var20, var83);
//     var4.draw(var7, var83);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = var0.getRendererForDataset(var4);
    java.lang.String var6 = var0.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var6 = var5.getTickMarkOutsideLength();
    java.awt.Paint var7 = var5.getAxisLinePaint();
    java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
    org.jfree.chart.util.Layer var12 = null;
    java.util.Collection var13 = var9.getDomainMarkers(0, var12);
    java.awt.Paint var14 = var9.getRangeGridlinePaint();
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    java.awt.Paint[] var16 = null;
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var24};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var15, var16, var18, var20, var26);
    java.awt.Shape var28 = var27.getNextShape();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var31 = var30.getTickMarkOutsideLength();
    boolean var32 = var30.isAxisLineVisible();
    java.awt.Stroke var33 = var30.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var38 = null;
    var36.setTickLabelPaint((java.lang.Comparable)10L, var38);
    var36.setCategoryLabelPositionOffset(0);
    var36.setAxisLineVisible(true);
    var36.configure();
    java.awt.Font var46 = var36.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var49 = var48.getTickMarkOutsideLength();
    java.awt.Paint var50 = var48.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("", var46, var50);
    org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var28, var33, var50);
    boolean var53 = var52.isShapeVisible();
    java.text.AttributedString var54 = var52.getAttributedLabel();
    java.awt.Stroke var55 = var52.getLineStroke();
    boolean var56 = var52.isShapeOutlineVisible();
    java.lang.String var57 = var52.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var57.equals("PlotOrientation.VERTICAL"));

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    var1.draw(var2, var3);
    org.jfree.chart.util.HorizontalAlignment var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var4 = var3.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var7 = var6.getTickMarkOutsideLength();
//     boolean var8 = var6.isAxisLineVisible();
//     java.awt.Stroke var9 = var6.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     java.util.List var12 = var10.getCategories();
//     org.jfree.chart.util.RectangleInsets var13 = var10.getInsets();
//     double var15 = var13.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder(var4, var9, var13);
//     var1.setPaint(var4);
//     org.jfree.chart.text.TextAnchor var18 = var1.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var21 = var20.getTickMarkOutsideLength();
//     java.awt.Paint var22 = var20.getAxisLinePaint();
//     java.awt.Paint var23 = var20.getTickLabelPaint();
//     double var24 = var20.getCategoryMargin();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var26 = var25.getRootPlot();
//     org.jfree.chart.util.Layer var28 = null;
//     java.util.Collection var29 = var25.getDomainMarkers(0, var28);
//     java.awt.Paint var30 = var25.getRangeGridlinePaint();
//     var20.setPlot((org.jfree.chart.plot.Plot)var25);
//     org.jfree.data.general.Dataset var32 = null;
//     org.jfree.data.general.DatasetChangeEvent var33 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var20, var32);
//     var20.configure();
//     java.awt.Font var36 = var20.getTickLabelFont((java.lang.Comparable)"PlotOrientation.VERTICAL");
//     var1.setLabelFont(var36);
//     
//     // Checks the contract:  equals-hashcode on var10 and var25
//     assertTrue("Contract failed: equals-hashcode on var10 and var25", var10.equals(var25) ? var10.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var10
//     assertTrue("Contract failed: equals-hashcode on var25 and var10", var25.equals(var10) ? var25.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var26
//     assertTrue("Contract failed: equals-hashcode on var11 and var26", var11.equals(var26) ? var11.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var11
//     assertTrue("Contract failed: equals-hashcode on var26 and var11", var26.equals(var11) ? var26.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var5.setLabel("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull");
//     var5.setLabel("");
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.labels.ItemLabelPosition var14 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var15 = var14.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var11, (-1.0f), 100.0f, var15, 100.0d, 2.0f, 2.0f);
//     java.lang.String var20 = var15.toString();
//     var5.setLabelTextAnchor(var15);
//     org.jfree.chart.axis.CategoryLabelPositions var23 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
//     boolean var24 = var15.equals((java.lang.Object)10.0d);
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var34 = var33.getTickMarkOutsideLength();
//     java.awt.Paint var35 = var33.getAxisLinePaint();
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var38 = var37.getRootPlot();
//     org.jfree.chart.util.Layer var40 = null;
//     java.util.Collection var41 = var37.getDomainMarkers(0, var40);
//     java.awt.Paint var42 = var37.getRangeGridlinePaint();
//     java.awt.Paint[] var43 = new java.awt.Paint[] { var42};
//     java.awt.Paint[] var44 = null;
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Stroke var47 = null;
//     java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var53 = org.jfree.chart.util.ShapeUtilities.equal(var50, var52);
//     java.awt.Shape[] var54 = new java.awt.Shape[] { var52};
//     org.jfree.chart.plot.DefaultDrawingSupplier var55 = new org.jfree.chart.plot.DefaultDrawingSupplier(var36, var43, var44, var46, var48, var54);
//     java.awt.Shape var56 = var55.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var59 = var58.getTickMarkOutsideLength();
//     boolean var60 = var58.isAxisLineVisible();
//     java.awt.Stroke var61 = var58.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var66 = null;
//     var64.setTickLabelPaint((java.lang.Comparable)10L, var66);
//     var64.setCategoryLabelPositionOffset(0);
//     var64.setAxisLineVisible(true);
//     var64.configure();
//     java.awt.Font var74 = var64.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var76 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var77 = var76.getTickMarkOutsideLength();
//     java.awt.Paint var78 = var76.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var79 = new org.jfree.chart.text.TextFragment("", var74, var78);
//     org.jfree.chart.LegendItem var80 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var56, var61, var78);
//     var27.setStroke(var61);
//     org.jfree.chart.util.RectangleAnchor var82 = var27.getLabelAnchor();
//     org.jfree.chart.text.TextAnchor var83 = var27.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("100", var1, 100.0f, 0.5f, var15, (-1.0d), var83);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var1.getRangeMarkers(0, var6);
//     org.jfree.chart.plot.Plot var8 = var1.getRootPlot();
//     boolean var9 = var1.isDomainZoomable();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     java.awt.Paint var12 = var10.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var13 = var10.getRowRenderingOrder();
//     var1.setRowRenderingOrder(var13);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var11
//     assertTrue("Contract failed: equals-hashcode on var8 and var11", var8.equals(var11) ? var8.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var8
//     assertTrue("Contract failed: equals-hashcode on var11 and var8", var11.equals(var8) ? var11.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var1 = var0.getDownArrow();
    var0.resizeRange(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(0.05d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "hi!", "hi!");
    var4.setToolTipText("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    java.lang.String var7 = var4.getURLText();
    java.lang.String var8 = var4.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "hi!"+ "'", var7.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var8.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var4 = null;
//     var2.setTickLabelPaint((java.lang.Comparable)10L, var4);
//     var2.setCategoryLabelPositionOffset(0);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var2.getCategoryStart(10, (-16777216), var10, var11);
//     var2.setTickMarkInsideLength(2.0f);
//     java.awt.Font var15 = var2.getTickLabelFont();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var18 = var17.getTickMarkOutsideLength();
//     java.awt.Paint var19 = var17.getAxisLinePaint();
//     java.awt.Paint var20 = var17.getTickLabelPaint();
//     org.jfree.chart.text.TextLine var21 = new org.jfree.chart.text.TextLine("AxisLabelEntity: label = hi!", var15, var20);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.util.Size2D var23 = var21.calculateDimensions(var22);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.centerRange(0.05d);
    double var3 = var0.getUpperMargin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(84.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
//     org.jfree.chart.JFreeChart var14 = var13.getChart();
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var17 = var16.getTickMarkOutsideLength();
//     java.awt.Paint var18 = var16.getAxisLinePaint();
//     java.awt.Paint var19 = var16.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var22 = var21.getRootPlot();
//     java.awt.Paint var23 = var21.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var21);
//     boolean var25 = var24.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var19, var24, 100, 10);
//     var24.setNotify(true);
//     org.jfree.data.KeyedObjects var31 = new org.jfree.data.KeyedObjects();
//     org.jfree.data.statistics.MeanAndStandardDeviation var35 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     java.lang.Number var36 = var35.getStandardDeviation();
//     var31.setObject((java.lang.Comparable)100, (java.lang.Object)var36);
//     java.lang.Object var38 = var31.clone();
//     java.util.List var39 = var31.getKeys();
//     boolean var40 = var24.equals((java.lang.Object)var31);
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.block.BlockFrame var43 = var42.getFrame();
//     org.jfree.chart.event.TitleChangeEvent var44 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var42);
//     org.jfree.chart.JFreeChart var45 = var44.getChart();
//     var24.titleChanged(var44);
//     var14.titleChanged(var44);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var22
//     assertTrue("Contract failed: equals-hashcode on var7 and var22", var7.equals(var22) ? var7.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var7
//     assertTrue("Contract failed: equals-hashcode on var22 and var7", var22.equals(var7) ? var22.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var24
//     assertTrue("Contract failed: equals-hashcode on var9 and var24", var9.equals(var24) ? var9.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var24
//     assertTrue("Contract failed: equals-hashcode on var14 and var24", var14.equals(var24) ? var14.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var9
//     assertTrue("Contract failed: equals-hashcode on var24 and var9", var24.equals(var9) ? var24.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var14
//     assertTrue("Contract failed: equals-hashcode on var24 and var14", var24.equals(var14) ? var24.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var3 = var0.getDomainAxisEdge();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var6 = var5.getDownArrow();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.String var10 = var8.valueToString(100.0d);
    var5.setTickUnit(var8);
    var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var5);
    int var13 = var0.getDomainAxisCount();
    int var14 = var0.getWeight();
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Point2D var18 = null;
    var0.zoomRangeAxes(0.0d, var17, var18);
    org.jfree.chart.plot.CategoryMarker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var20, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "100"+ "'", var10.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.centerRange(0.05d);
    double var3 = var0.getUpperMargin();
    var0.setNegativeArrowVisible(false);
    org.jfree.chart.axis.NumberTickUnit var7 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.String var9 = var7.valueToString(100.0d);
    var0.setTickUnit(var7, true, false);
    int var13 = var7.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "100"+ "'", var9.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var0.setBaseToolTipGenerator(var3, true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    var7.centerRange(0.05d);
    var7.setNegativeArrowVisible(false);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var14 = var13.getTickMarkOutsideLength();
    java.awt.Paint var15 = var13.getAxisLinePaint();
    java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var17.getDomainMarkers(0, var20);
    java.awt.Paint var22 = var17.getRangeGridlinePaint();
    java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
    java.awt.Paint[] var24 = null;
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Stroke var27 = null;
    java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var30, var32);
    java.awt.Shape[] var34 = new java.awt.Shape[] { var32};
    org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var23, var24, var26, var28, var34);
    java.awt.Shape var36 = var35.getNextShape();
    var7.setRightArrow(var36);
    var0.setBaseShape(var36, false);
    org.jfree.chart.annotations.CategoryAnnotation var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var5 = null;
//     org.jfree.chart.util.VerticalAlignment var6 = null;
//     org.jfree.chart.block.FlowArrangement var9 = new org.jfree.chart.block.FlowArrangement(var5, var6, 0.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var13 = var11.getDomainAxis();
//     int var14 = var11.getBackgroundImageAlignment();
//     var11.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var18 = null;
//     java.util.Collection var19 = var11.getDomainMarkers(10, var18);
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var11);
//     org.jfree.data.general.DatasetGroup var21 = var11.getDatasetGroup();
//     boolean var22 = var9.equals((java.lang.Object)var11);
//     var11.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var24 = var11.getRowRenderingOrder();
//     boolean var25 = var4.equals((java.lang.Object)var11);
//     
//     // Checks the contract:  equals-hashcode on var4 and var9
//     assertTrue("Contract failed: equals-hashcode on var4 and var9", var4.equals(var9) ? var4.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var4
//     assertTrue("Contract failed: equals-hashcode on var9 and var4", var9.equals(var4) ? var9.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "AxisLabelEntity: label = hi!", var3);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.awt.Paint var2 = var0.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.util.RectangleAnchor var5 = var4.getLegendItemGraphicLocation();
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var9 = new org.jfree.chart.axis.CategoryLabelPosition(var5, var6, var7, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var6 = null;
//     var4.setTickLabelPaint((java.lang.Comparable)10L, var6);
//     var4.setCategoryLabelPositionOffset(0);
//     var4.setAxisLineVisible(true);
//     var4.configure();
//     java.awt.Font var14 = var4.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var17 = var16.getTickMarkOutsideLength();
//     java.awt.Paint var18 = var16.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("", var14, var18);
//     org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var14);
//     org.jfree.chart.text.TextFragment var21 = new org.jfree.chart.text.TextFragment("", var14);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var26.setLabel("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull");
//     var26.setLabel("");
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.labels.ItemLabelPosition var35 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var36 = var35.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var32, (-1.0f), 100.0f, var36, 100.0d, 2.0f, 2.0f);
//     java.lang.String var41 = var36.toString();
//     var26.setLabelTextAnchor(var36);
//     org.jfree.chart.axis.CategoryLabelPositions var44 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
//     boolean var45 = var36.equals((java.lang.Object)10.0d);
//     var21.draw(var22, 0.0f, 100.0f, var36, 1.0f, 100.0f, 100.0d);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("RectangleAnchor.CENTER", 15, 1);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, (-1.0f), 10.0f, 104.0d, 1.0f, (-1.0f));

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var8 = null;
//     var6.setTickLabelPaint((java.lang.Comparable)10L, var8);
//     var6.setCategoryLabelPositionOffset(0);
//     var6.setAxisLineVisible(true);
//     var6.configure();
//     java.awt.Font var16 = var6.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var19 = var18.getTickMarkOutsideLength();
//     java.awt.Paint var20 = var18.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var21 = new org.jfree.chart.text.TextFragment("", var16, var20);
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var16);
//     org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("", var16);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var26 = var24.getRangeAxisForDataset(0);
//     java.awt.Paint var27 = var24.getBackgroundPaint();
//     org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("", var16, var27);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var30 = var29.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var34 = var33.getTickMarkOutsideLength();
//     boolean var35 = var33.isAxisLineVisible();
//     var29.setDomainAxis(10, var33);
//     java.awt.Paint var37 = var33.getLabelPaint();
//     org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", var16, var37);
//     
//     // Checks the contract:  equals-hashcode on var24 and var29
//     assertTrue("Contract failed: equals-hashcode on var24 and var29", var24.equals(var29) ? var24.hashCode() == var29.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var29.", var24.equals(var29) == var29.equals(var24));
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var8 = var7.getTickMarkOutsideLength();
    java.awt.Paint var9 = var7.getAxisLinePaint();
    java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var11.getDomainMarkers(0, var14);
    java.awt.Paint var16 = var11.getRangeGridlinePaint();
    java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
    java.awt.Paint[] var18 = null;
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
    java.awt.Shape[] var28 = new java.awt.Shape[] { var26};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var17, var18, var20, var22, var28);
    java.awt.Shape var30 = var29.getNextShape();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var33 = var32.getTickMarkOutsideLength();
    boolean var34 = var32.isAxisLineVisible();
    java.awt.Stroke var35 = var32.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var40 = null;
    var38.setTickLabelPaint((java.lang.Comparable)10L, var40);
    var38.setCategoryLabelPositionOffset(0);
    var38.setAxisLineVisible(true);
    var38.configure();
    java.awt.Font var48 = var38.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var51 = var50.getTickMarkOutsideLength();
    java.awt.Paint var52 = var50.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var48, var52);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var30, var35, var52);
    var0.setSeriesPaint(100, var52, true);
    boolean var57 = var0.getIncludeBaseInRange();
    var0.setAutoPopulateSeriesOutlinePaint(true);
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var62 = var61.getTickMarkOutsideLength();
    java.awt.Paint var63 = var61.getAxisLinePaint();
    java.awt.Font var64 = var61.getTickLabelFont();
    var0.setBaseItemLabelFont(var64);
    java.awt.Stroke var67 = var0.getSeriesStroke(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)10, (java.lang.Number)(-100));

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.getAutoRangeIncludesZero();
    org.jfree.chart.axis.MarkerAxisBand var2 = null;
    var0.setMarkerBand(var2);
    var0.setLowerMargin(0.2d);
    org.jfree.data.Range var8 = new org.jfree.data.Range(0.0d, 4.0d);
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
    var0.setRangeWithMargins(var8);
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(var8, 0.2d);
    org.jfree.chart.block.RectangleConstraint var14 = var13.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var15 = var13.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var17 = var15.toFixedWidth(84.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     double var5 = var1.getCategoryMargin();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     org.jfree.chart.util.Layer var9 = null;
//     java.util.Collection var10 = var6.getDomainMarkers(0, var9);
//     java.awt.Paint var11 = var6.getRangeGridlinePaint();
//     var1.setPlot((org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.axis.CategoryLabelPositions var13 = var1.getCategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
//     java.awt.Paint var16 = var14.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var17 = var14.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     java.awt.Font var19 = var18.getItemFont();
//     org.jfree.chart.block.BlockContainer var20 = var18.getItemContainer();
//     java.util.List var21 = var20.getBlocks();
//     org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement();
//     var20.setArrangement((org.jfree.chart.block.Arrangement)var22);
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var27 = null;
//     var25.setTickLabelPaint((java.lang.Comparable)10L, var27);
//     var25.setCategoryLabelPositionOffset(0);
//     var25.setAxisLineVisible(true);
//     var25.configure();
//     java.awt.Font var35 = var25.getTickLabelFont((java.lang.Comparable)0.0f);
//     java.lang.String var36 = var25.getLabelURL();
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var38, var40);
//     org.jfree.chart.entity.ChartEntity var44 = new org.jfree.chart.entity.ChartEntity(var40, "", "hi!");
//     org.jfree.chart.entity.AxisLabelEntity var47 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var25, var40, "hi!", "PlotOrientation.VERTICAL");
//     java.lang.Object var48 = var25.clone();
//     boolean var49 = var22.equals((java.lang.Object)var25);
//     boolean var50 = var13.equals((java.lang.Object)var49);
//     
//     // Checks the contract:  equals-hashcode on var6 and var14
//     assertTrue("Contract failed: equals-hashcode on var6 and var14", var6.equals(var14) ? var6.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var6
//     assertTrue("Contract failed: equals-hashcode on var14 and var6", var14.equals(var6) ? var14.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var15
//     assertTrue("Contract failed: equals-hashcode on var7 and var15", var7.equals(var15) ? var7.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var7
//     assertTrue("Contract failed: equals-hashcode on var15 and var7", var15.equals(var7) ? var15.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     float var5 = var1.getBackgroundAlpha();
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var1.getDatasetRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var9 = var7.getRangeAxisForDataset(0);
//     var7.setAnchorValue(0.2d);
//     org.jfree.chart.axis.AxisSpace var12 = var7.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis();
//     int var17 = var14.getBackgroundImageAlignment();
//     var14.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var14.getDomainMarkers(10, var21);
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var14);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var25 = var24.getRootPlot();
//     java.util.List var26 = var24.getCategories();
//     org.jfree.chart.util.RectangleInsets var27 = var24.getInsets();
//     double var29 = var27.calculateBottomInset((-1.0d));
//     double var30 = var27.getTop();
//     var23.setPadding(var27);
//     var7.setInsets(var27);
//     org.jfree.chart.axis.AxisLocation var34 = var7.getDomainAxisLocation(0);
//     var1.setDomainAxisLocation(var34, true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var25
//     assertTrue("Contract failed: equals-hashcode on var2 and var25", var2.equals(var25) ? var2.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var2
//     assertTrue("Contract failed: equals-hashcode on var25 and var2", var25.equals(var2) ? var25.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
    boolean var6 = var0.equals((java.lang.Object)var5);
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.Comparable var9 = null;
    var0.addObject((java.lang.Object)100.0d, var9, (java.lang.Comparable)(byte)10);
    java.lang.Comparable var13 = var0.getRowKey(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)'4');
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.util.List var2 = var0.getCategories();
//     org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
//     java.awt.Stroke var4 = null;
//     var0.setOutlineStroke(var4);
//     java.util.List var6 = var0.getAnnotations();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var10 = var7.getDomainAxisEdge();
//     java.awt.Paint var11 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var14 = var13.getRootPlot();
//     java.awt.Paint var15 = var13.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var19 = var18.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var22 = var21.getTickMarkOutsideLength();
//     boolean var23 = var21.isAxisLineVisible();
//     java.awt.Stroke var24 = var21.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var26 = var25.getRootPlot();
//     java.util.List var27 = var25.getCategories();
//     org.jfree.chart.util.RectangleInsets var28 = var25.getInsets();
//     double var30 = var28.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var31 = new org.jfree.chart.block.LineBorder(var19, var24, var28);
//     var13.setRangeGridlineStroke(var24);
//     var7.setOutlineStroke(var24);
//     org.jfree.chart.axis.AxisLocation var34 = var7.getDomainAxisLocation();
//     var0.setDomainAxisLocation(var34);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     var36.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.event.MarkerChangeEvent var39 = null;
//     var36.markerChanged(var39);
//     boolean var41 = var34.equals((java.lang.Object)var39);
//     
//     // Checks the contract:  equals-hashcode on var25 and var36
//     assertTrue("Contract failed: equals-hashcode on var25 and var36", var25.equals(var36) ? var25.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var25
//     assertTrue("Contract failed: equals-hashcode on var36 and var25", var36.equals(var25) ? var36.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    int var3 = java.awt.Color.HSBtoRGB(0.5f, 10.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1572964));

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("UnitType.ABSOLUTE", var1, var2);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var3 = var2.getRootPlot();
    java.awt.Paint var4 = var2.getBackgroundPaint();
    var1.setPaint(var4);
    java.awt.Font var6 = var1.getFont();
    double var7 = var1.getContentYOffset();
    java.awt.Graphics2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var9 = var1.arrange(var8);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var8 = var7.getTickMarkOutsideLength();
    java.awt.Paint var9 = var7.getAxisLinePaint();
    java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var11.getDomainMarkers(0, var14);
    java.awt.Paint var16 = var11.getRangeGridlinePaint();
    java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
    java.awt.Paint[] var18 = null;
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
    java.awt.Shape[] var28 = new java.awt.Shape[] { var26};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var17, var18, var20, var22, var28);
    java.awt.Shape var30 = var29.getNextShape();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var33 = var32.getTickMarkOutsideLength();
    boolean var34 = var32.isAxisLineVisible();
    java.awt.Stroke var35 = var32.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var40 = null;
    var38.setTickLabelPaint((java.lang.Comparable)10L, var40);
    var38.setCategoryLabelPositionOffset(0);
    var38.setAxisLineVisible(true);
    var38.configure();
    java.awt.Font var48 = var38.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var51 = var50.getTickMarkOutsideLength();
    java.awt.Paint var52 = var50.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var48, var52);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var30, var35, var52);
    var0.setSeriesPaint(100, var52, true);
    boolean var57 = var0.getIncludeBaseInRange();
    var0.setAutoPopulateSeriesOutlinePaint(true);
    boolean var60 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var61 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var61);
    org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var67 = null;
    var65.setTickLabelPaint((java.lang.Comparable)10L, var67);
    var65.setCategoryLabelPositionOffset(0);
    var65.setAxisLineVisible(true);
    var65.configure();
    java.awt.Font var75 = var65.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var77 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var78 = var77.getTickMarkOutsideLength();
    java.awt.Paint var79 = var77.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var80 = new org.jfree.chart.text.TextFragment("", var75, var79);
    var0.setBaseItemLabelFont(var75, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var13 = var12.getTickMarkOutsideLength();
//     java.awt.Paint var14 = var12.getAxisLinePaint();
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var17 = var16.getRootPlot();
//     org.jfree.chart.util.Layer var19 = null;
//     java.util.Collection var20 = var16.getDomainMarkers(0, var19);
//     java.awt.Paint var21 = var16.getRangeGridlinePaint();
//     java.awt.Paint[] var22 = new java.awt.Paint[] { var21};
//     java.awt.Paint[] var23 = null;
//     java.awt.Stroke var24 = null;
//     java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
//     java.awt.Stroke var26 = null;
//     java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var29, var31);
//     java.awt.Shape[] var33 = new java.awt.Shape[] { var31};
//     org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier(var15, var22, var23, var25, var27, var33);
//     java.awt.Shape var35 = var34.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var38 = var37.getTickMarkOutsideLength();
//     boolean var39 = var37.isAxisLineVisible();
//     java.awt.Stroke var40 = var37.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var45 = null;
//     var43.setTickLabelPaint((java.lang.Comparable)10L, var45);
//     var43.setCategoryLabelPositionOffset(0);
//     var43.setAxisLineVisible(true);
//     var43.configure();
//     java.awt.Font var53 = var43.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var56 = var55.getTickMarkOutsideLength();
//     java.awt.Paint var57 = var55.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var58 = new org.jfree.chart.text.TextFragment("", var53, var57);
//     org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var35, var40, var57);
//     var6.setStroke(var40);
//     org.jfree.chart.util.RectangleAnchor var61 = var6.getLabelAnchor();
//     java.awt.geom.Rectangle2D var62 = org.jfree.chart.util.RectangleAnchor.createRectangle(var2, 100.0d, (-1.0d), var61);
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var64 = var63.getRootPlot();
//     java.awt.Paint var65 = var63.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var66 = var63.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
//     org.jfree.chart.util.RectangleAnchor var68 = var67.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var69 = org.jfree.chart.util.RectangleAnchor.coordinates(var62, var68);
//     
//     // Checks the contract:  equals-hashcode on var16 and var63
//     assertTrue("Contract failed: equals-hashcode on var16 and var63", var16.equals(var63) ? var16.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var16
//     assertTrue("Contract failed: equals-hashcode on var63 and var16", var63.equals(var16) ? var63.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var64
//     assertTrue("Contract failed: equals-hashcode on var17 and var64", var17.equals(var64) ? var17.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var17
//     assertTrue("Contract failed: equals-hashcode on var64 and var17", var64.equals(var17) ? var64.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextLine var1 = var0.getLastLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)"hi!");
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Font var5 = var4.getItemFont();
//     org.jfree.chart.block.BlockContainer var6 = var4.getItemContainer();
//     java.util.List var7 = var6.getBlocks();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     boolean var10 = var9.getAutoRangeIncludesZero();
//     org.jfree.chart.axis.MarkerAxisBand var11 = null;
//     var9.setMarkerBand(var11);
//     var9.setLowerMargin(0.2d);
//     org.jfree.data.Range var17 = new org.jfree.data.Range(0.0d, 4.0d);
//     org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
//     var9.setRangeWithMargins(var17);
//     org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(var17, 0.2d);
//     org.jfree.chart.block.RectangleConstraint var23 = var22.toUnconstrainedWidth();
//     org.jfree.chart.util.Size2D var24 = var6.arrange(var8, var22);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var27 = var25.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.Plot var28 = var25.getParent();
//     boolean var29 = var6.equals((java.lang.Object)var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("ChartEntity: tooltip = ");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.getAutoRangeIncludesZero();
    org.jfree.chart.axis.MarkerAxisBand var2 = null;
    var0.setMarkerBand(var2);
    java.awt.Shape var4 = var0.getDownArrow();
    var0.setLowerBound(0.0d);
    org.jfree.data.Range var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", var1);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var0.setBaseToolTipGenerator(var3, true);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var9 = var8.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var12 = var11.getTickMarkOutsideLength();
    boolean var13 = var11.isAxisLineVisible();
    java.awt.Stroke var14 = var11.getTickMarkStroke();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
    java.util.List var17 = var15.getCategories();
    org.jfree.chart.util.RectangleInsets var18 = var15.getInsets();
    double var20 = var18.calculateBottomInset((-1.0d));
    org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder(var9, var14, var18);
    var0.setSeriesPaint(10, var9, true);
    boolean var24 = var0.getAutoPopulateSeriesOutlinePaint();
    java.awt.Font var27 = var0.getItemLabelFont((-1), 10);
    java.lang.Boolean var29 = var0.getSeriesVisible(15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-1), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "", "PlotOrientation.VERTICAL");
    org.jfree.chart.ui.ProjectInfo var6 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo();
    var6.addLibrary((org.jfree.chart.ui.Library)var7);
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var6);
    var5.addOptionalLibrary("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    var5.setName("hi!");

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
//     java.awt.Paint var6 = var4.getBackgroundPaint();
//     var1.setAxisLinePaint(var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.AxisState var9 = new org.jfree.chart.axis.AxisState();
//     var9.setMax(4.0d);
//     double var12 = var9.getMax();
//     org.jfree.chart.util.Size2D var15 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var26 = var25.getTickMarkOutsideLength();
//     java.awt.Paint var27 = var25.getAxisLinePaint();
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var30 = var29.getRootPlot();
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var29.getDomainMarkers(0, var32);
//     java.awt.Paint var34 = var29.getRangeGridlinePaint();
//     java.awt.Paint[] var35 = new java.awt.Paint[] { var34};
//     java.awt.Paint[] var36 = null;
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var42, var44);
//     java.awt.Shape[] var46 = new java.awt.Shape[] { var44};
//     org.jfree.chart.plot.DefaultDrawingSupplier var47 = new org.jfree.chart.plot.DefaultDrawingSupplier(var28, var35, var36, var38, var40, var46);
//     java.awt.Shape var48 = var47.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var51 = var50.getTickMarkOutsideLength();
//     boolean var52 = var50.isAxisLineVisible();
//     java.awt.Stroke var53 = var50.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var58 = null;
//     var56.setTickLabelPaint((java.lang.Comparable)10L, var58);
//     var56.setCategoryLabelPositionOffset(0);
//     var56.setAxisLineVisible(true);
//     var56.configure();
//     java.awt.Font var66 = var56.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var68 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var69 = var68.getTickMarkOutsideLength();
//     java.awt.Paint var70 = var68.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var71 = new org.jfree.chart.text.TextFragment("", var66, var70);
//     org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var48, var53, var70);
//     var19.setStroke(var53);
//     org.jfree.chart.util.RectangleAnchor var74 = var19.getLabelAnchor();
//     java.awt.geom.Rectangle2D var75 = org.jfree.chart.util.RectangleAnchor.createRectangle(var15, 100.0d, (-1.0d), var74);
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var77 = var76.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var78 = var76.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var79 = var76.getDomainAxisEdge();
//     boolean var80 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var79);
//     java.util.List var81 = var1.refreshTicks(var8, var9, var75, var79);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape(15);
    java.awt.Paint var4 = var0.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var8 = var6.lookupSeriesShape(15);
    java.lang.Boolean var10 = null;
    var6.setSeriesItemLabelsVisible(100, var10);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var14 = var13.getTickMarkOutsideLength();
    java.awt.Paint var15 = var13.getAxisLinePaint();
    java.awt.Paint var16 = var13.getTickLabelPaint();
    double var17 = var13.getCategoryMargin();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var19 = var18.getRootPlot();
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var18.getDomainMarkers(0, var21);
    java.awt.Paint var23 = var18.getRangeGridlinePaint();
    var13.setPlot((org.jfree.chart.plot.Plot)var18);
    boolean var25 = var6.equals((java.lang.Object)var13);
    java.awt.Paint var26 = var6.getBaseOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), var26, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
    org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
    org.jfree.chart.plot.Plot var6 = var0.getParent();
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = null;
    var10.setPlotArea(var11);
    java.awt.geom.Rectangle2D var13 = var10.getPlotArea();
    org.jfree.chart.ChartRenderingInfo var14 = var10.getOwner();
    java.awt.geom.Point2D var15 = null;
    var0.zoomRangeAxes((-12.0d), 0.0d, var10, var15);
    var0.setBackgroundImageAlpha(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxisForDataset(0);
    var0.setAnchorValue(0.2d);
    org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis();
    int var10 = var7.getBackgroundImageAlignment();
    var7.setRangeCrosshairVisible(true);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var7.getDomainMarkers(10, var14);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
    java.util.List var19 = var17.getCategories();
    org.jfree.chart.util.RectangleInsets var20 = var17.getInsets();
    double var22 = var20.calculateBottomInset((-1.0d));
    double var23 = var20.getTop();
    var16.setPadding(var20);
    var0.setInsets(var20);
    org.jfree.chart.axis.AxisLocation var27 = var0.getDomainAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = var0.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.util.List var2 = var0.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
//     org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
//     org.jfree.chart.plot.Plot var6 = var0.getParent();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
//     java.awt.Paint var10 = var8.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
//     float var12 = var8.getBackgroundAlpha();
//     org.jfree.chart.plot.DatasetRenderingOrder var13 = var8.getDatasetRenderingOrder();
//     java.lang.String var14 = var13.toString();
//     var0.setDatasetRenderingOrder(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
    java.lang.Number var3 = var2.getStandardDeviation();
    java.lang.Object var4 = null;
    boolean var5 = var2.equals(var4);
    java.lang.Number var6 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100.0d+ "'", var6.equals(100.0d));

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var3 = var2.getRootPlot();
//     java.awt.Paint var4 = var2.getBackgroundPaint();
//     var1.setPaint(var4);
//     org.jfree.chart.util.RectangleInsets var6 = var1.getPadding();
//     org.jfree.chart.event.TitleChangeEvent var7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var10 = var9.getTickMarkOutsideLength();
//     java.awt.Paint var11 = var9.getAxisLinePaint();
//     java.awt.Paint var12 = var9.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
//     java.awt.Paint var16 = var14.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var14);
//     boolean var18 = var17.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var12, var17, 100, 10);
//     org.jfree.chart.JFreeChart var22 = var21.getChart();
//     var7.setChart(var22);
//     
//     // Checks the contract:  equals-hashcode on var2 and var14
//     assertTrue("Contract failed: equals-hashcode on var2 and var14", var2.equals(var14) ? var2.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var2
//     assertTrue("Contract failed: equals-hashcode on var14 and var2", var14.equals(var2) ? var14.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var6 = var5.getTickMarkOutsideLength();
    java.awt.Paint var7 = var5.getAxisLinePaint();
    java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
    org.jfree.chart.util.Layer var12 = null;
    java.util.Collection var13 = var9.getDomainMarkers(0, var12);
    java.awt.Paint var14 = var9.getRangeGridlinePaint();
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    java.awt.Paint[] var16 = null;
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var24};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var15, var16, var18, var20, var26);
    java.awt.Shape var28 = var27.getNextShape();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var31 = var30.getTickMarkOutsideLength();
    boolean var32 = var30.isAxisLineVisible();
    java.awt.Stroke var33 = var30.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var38 = null;
    var36.setTickLabelPaint((java.lang.Comparable)10L, var38);
    var36.setCategoryLabelPositionOffset(0);
    var36.setAxisLineVisible(true);
    var36.configure();
    java.awt.Font var46 = var36.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var49 = var48.getTickMarkOutsideLength();
    java.awt.Paint var50 = var48.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("", var46, var50);
    org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var28, var33, var50);
    boolean var53 = var52.isShapeVisible();
    java.text.AttributedString var54 = var52.getAttributedLabel();
    boolean var55 = var52.isShapeFilled();
    java.lang.String var56 = var52.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + ""+ "'", var56.equals(""));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object var2 = var0.handleGetObject("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    java.lang.Object[][] var3 = var0.getContents();
    java.util.Enumeration var4 = var0.getKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
//     org.jfree.chart.JFreeChart var14 = var13.getChart();
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var17 = var16.getTickMarkOutsideLength();
//     java.awt.Paint var18 = var16.getAxisLinePaint();
//     java.awt.Paint var19 = var16.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var22 = var21.getRootPlot();
//     java.awt.Paint var23 = var21.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var21);
//     boolean var25 = var24.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var19, var24, 100, 10);
//     java.awt.Stroke var29 = null;
//     var24.setBorderStroke(var29);
//     var24.setAntiAlias(true);
//     var13.setChart(var24);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var22
//     assertTrue("Contract failed: equals-hashcode on var7 and var22", var7.equals(var22) ? var7.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var7
//     assertTrue("Contract failed: equals-hashcode on var22 and var7", var22.equals(var7) ? var22.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var0.setBaseToolTipGenerator(var3, true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    var7.centerRange(0.05d);
    var7.setNegativeArrowVisible(false);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var14 = var13.getTickMarkOutsideLength();
    java.awt.Paint var15 = var13.getAxisLinePaint();
    java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var17.getDomainMarkers(0, var20);
    java.awt.Paint var22 = var17.getRangeGridlinePaint();
    java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
    java.awt.Paint[] var24 = null;
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Stroke var27 = null;
    java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var30, var32);
    java.awt.Shape[] var34 = new java.awt.Shape[] { var32};
    org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var23, var24, var26, var28, var34);
    java.awt.Shape var36 = var35.getNextShape();
    var7.setRightArrow(var36);
    var0.setBaseShape(var36, false);
    double var40 = var0.getUpperClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var1 = var0.getLeftArrow();
    double var2 = var0.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var5 = var4.getTickMarkOutsideLength();
//     boolean var6 = var4.isAxisLineVisible();
//     var0.setDomainAxis(10, var4);
//     java.awt.Paint var8 = var4.getTickMarkPaint();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     java.awt.Paint var11 = var9.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var12 = var9.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     java.awt.Font var14 = var13.getItemFont();
//     var4.setLabelFont(var14);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var0.", var9.equals(var0) == var0.equals(var9));
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var1.", var10.equals(var1) == var1.equals(var10));
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var1 = var0.getBaseItemLabelGenerator();
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var5 = var4.getTickMarkOutsideLength();
//     java.awt.Paint var6 = var4.getAxisLinePaint();
//     java.awt.Paint var7 = var4.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     java.awt.Paint var11 = var9.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var9);
//     boolean var13 = var12.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var16 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var7, var12, 100, 10);
//     var0.setSeriesFillPaint(15, var7);
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var19.getNegativeItemLabelPosition(15, (-1));
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var25 = var24.getTickMarkOutsideLength();
//     boolean var26 = var24.isAxisLineVisible();
//     java.awt.Stroke var27 = var24.getTickMarkStroke();
//     var24.addCategoryLabelToolTip((java.lang.Comparable)(short)1, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     boolean var31 = var22.equals((java.lang.Object)var24);
//     var0.setSeriesNegativeItemLabelPosition(1, var22, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.axis.Axis var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var3 = var2.getTickMarkOutsideLength();
    java.awt.Paint var4 = var2.getAxisLinePaint();
    java.awt.Paint[] var5 = new java.awt.Paint[] { var4};
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    org.jfree.chart.util.Layer var9 = null;
    java.util.Collection var10 = var6.getDomainMarkers(0, var9);
    java.awt.Paint var11 = var6.getRangeGridlinePaint();
    java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
    java.awt.Paint[] var13 = null;
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Stroke var16 = null;
    java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var19, var21);
    java.awt.Shape[] var23 = new java.awt.Shape[] { var21};
    org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var12, var13, var15, var17, var23);
    java.awt.Shape var25 = var24.getNextShape();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var28 = new org.jfree.chart.entity.AxisLabelEntity(var0, var25, "8", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextAnchor.CENTER", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.awt.Paint var2 = var0.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
    org.jfree.chart.plot.Plot var4 = var0.getParent();
    org.jfree.chart.LegendItemCollection var5 = var0.getFixedLegendItems();
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.event.PlotChangeEvent var7 = null;
    var0.notifyListeners(var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var0.getDomainMarkers((-16777216), var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var4 = var3.getRootPlot();
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var3.getDomainMarkers(0, var6);
//     java.awt.Paint var8 = var3.getRangeGridlinePaint();
//     var0.setNoDataMessagePaint(var8);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var12 = var11.getTickMarkOutsideLength();
//     java.awt.Paint var13 = var11.getAxisLinePaint();
//     java.awt.Paint var14 = var11.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var17 = var16.getRootPlot();
//     java.awt.Paint var18 = var16.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var16);
//     boolean var20 = var19.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var23 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var14, var19, 100, 10);
//     java.awt.Stroke var24 = null;
//     var19.setBorderStroke(var24);
//     org.jfree.chart.event.ChartProgressListener var26 = null;
//     var19.addProgressListener(var26);
//     float var28 = var19.getBackgroundImageAlpha();
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var19);
//     
//     // Checks the contract:  equals-hashcode on var3 and var16
//     assertTrue("Contract failed: equals-hashcode on var3 and var16", var3.equals(var16) ? var3.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var3
//     assertTrue("Contract failed: equals-hashcode on var16 and var3", var16.equals(var3) ? var16.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var0.setBaseToolTipGenerator(var3, true);
    org.jfree.chart.plot.CategoryPlot var6 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var3 = var2.getID();
//     java.awt.Font var4 = var2.getFont();
//     org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("", var4);
//     var5.setURLText("PlotOrientation.VERTICAL");
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var11 = var8.getDomainAxisEdge();
//     boolean var12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var11);
//     boolean var13 = var5.equals((java.lang.Object)var11);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.util.Size2D var15 = var5.arrange(var14);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    var1.setAxisLineVisible(true);
    var1.configure();
    java.awt.Font var11 = var1.getTickLabelFont((java.lang.Comparable)0.0f);
    var1.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var15 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var1.setCategoryLabelPositions(var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
    java.util.List var19 = var17.getCategories();
    org.jfree.chart.util.RectangleInsets var20 = var17.getInsets();
    java.awt.Stroke var21 = null;
    var17.setOutlineStroke(var21);
    org.jfree.data.category.CategoryDataset var24 = var17.getDataset(0);
    org.jfree.chart.util.RectangleEdge var26 = var17.getDomainAxisEdge(0);
    org.jfree.chart.axis.CategoryLabelPosition var27 = var15.getLabelPosition(var26);
    double var28 = var27.getAngle();
    org.jfree.chart.ui.ProjectInfo var29 = new org.jfree.chart.ui.ProjectInfo();
    var29.setCopyright("");
    java.lang.String var32 = var29.getLicenceName();
    java.lang.String var33 = var29.getLicenceText();
    java.lang.String var34 = var29.getCopyright();
    java.util.List var35 = var29.getContributors();
    boolean var36 = var27.equals((java.lang.Object)var29);
    org.jfree.chart.axis.CategoryLabelPosition var37 = null;
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var41 = null;
    var39.setTickLabelPaint((java.lang.Comparable)10L, var41);
    var39.setCategoryLabelPositionOffset(0);
    var39.setAxisLineVisible(true);
    var39.configure();
    java.awt.Font var49 = var39.getTickLabelFont((java.lang.Comparable)0.0f);
    var39.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var53 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var39.setCategoryLabelPositions(var53);
    org.jfree.chart.axis.CategoryLabelPositions var56 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPosition var57 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var58 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var56, var57);
    org.jfree.chart.axis.CategoryLabelPositions var59 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var53, var57);
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var63 = null;
    var61.setTickLabelPaint((java.lang.Comparable)10L, var63);
    var61.setCategoryLabelPositionOffset(0);
    var61.setAxisLineVisible(true);
    var61.configure();
    java.awt.Font var71 = var61.getTickLabelFont((java.lang.Comparable)0.0f);
    var61.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var75 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var61.setCategoryLabelPositions(var75);
    org.jfree.chart.axis.CategoryLabelPositions var78 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPosition var79 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var80 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var78, var79);
    org.jfree.chart.axis.CategoryLabelPositions var81 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var75, var79);
    org.jfree.chart.title.TextTitle var84 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var85 = var84.getID();
    java.awt.Font var86 = var84.getFont();
    org.jfree.chart.block.LabelBlock var87 = new org.jfree.chart.block.LabelBlock("", var86);
    var87.setURLText("PlotOrientation.VERTICAL");
    org.jfree.chart.plot.CategoryPlot var90 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var91 = var90.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var92 = var90.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var93 = var90.getDomainAxisEdge();
    boolean var94 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var93);
    boolean var95 = var87.equals((java.lang.Object)var93);
    org.jfree.chart.util.RectangleEdge var96 = org.jfree.chart.util.RectangleEdge.opposite(var93);
    org.jfree.chart.axis.CategoryLabelPosition var97 = var75.getLabelPosition(var93);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var98 = new org.jfree.chart.axis.CategoryLabelPositions(var27, var37, var57, var97);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + ""+ "'", var34.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var11 = var10.getTickMarkOutsideLength();
    java.awt.Paint var12 = var10.getAxisLinePaint();
    java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var14.getDomainMarkers(0, var17);
    java.awt.Paint var19 = var14.getRangeGridlinePaint();
    java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
    java.awt.Paint[] var21 = null;
    java.awt.Stroke var22 = null;
    java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
    java.awt.Stroke var24 = null;
    java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var27, var29);
    java.awt.Shape[] var31 = new java.awt.Shape[] { var29};
    org.jfree.chart.plot.DefaultDrawingSupplier var32 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var20, var21, var23, var25, var31);
    java.awt.Shape var33 = var32.getNextShape();
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var36 = var35.getTickMarkOutsideLength();
    boolean var37 = var35.isAxisLineVisible();
    java.awt.Stroke var38 = var35.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var43 = null;
    var41.setTickLabelPaint((java.lang.Comparable)10L, var43);
    var41.setCategoryLabelPositionOffset(0);
    var41.setAxisLineVisible(true);
    var41.configure();
    java.awt.Font var51 = var41.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var54 = var53.getTickMarkOutsideLength();
    java.awt.Paint var55 = var53.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var56 = new org.jfree.chart.text.TextFragment("", var51, var55);
    org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var33, var38, var55);
    boolean var58 = var57.isShapeVisible();
    java.text.AttributedString var59 = var57.getAttributedLabel();
    java.awt.Stroke var60 = var57.getLineStroke();
    java.awt.Paint var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var62 = new org.jfree.chart.LegendItem(var0, "Range[0.0,4.0]", "hi!", "8", var4, var60, var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var0.setBaseToolTipGenerator(var3, true);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var9 = var8.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var12 = var11.getTickMarkOutsideLength();
    boolean var13 = var11.isAxisLineVisible();
    java.awt.Stroke var14 = var11.getTickMarkStroke();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
    java.util.List var17 = var15.getCategories();
    org.jfree.chart.util.RectangleInsets var18 = var15.getInsets();
    double var20 = var18.calculateBottomInset((-1.0d));
    org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder(var9, var14, var18);
    var0.setSeriesPaint(10, var9, true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = var0.getLegendItemURLGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var26 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Color var31 = java.awt.Color.getHSBColor(2.0f, (-1.0f), 0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), (java.awt.Paint)var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.centerRange(0.05d);
//     var0.setNegativeArrowVisible(false);
//     double var5 = var0.getLowerMargin();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var8 = var7.getTickMarkOutsideLength();
//     java.awt.Paint var9 = var7.getAxisLinePaint();
//     java.awt.Paint var10 = var7.getTickLabelPaint();
//     double var11 = var7.getCategoryMargin();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var12.getDomainMarkers(0, var15);
//     java.awt.Paint var17 = var12.getRangeGridlinePaint();
//     var7.setPlot((org.jfree.chart.plot.Plot)var12);
//     org.jfree.data.general.Dataset var19 = null;
//     org.jfree.data.general.DatasetChangeEvent var20 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var7, var19);
//     var7.configure();
//     java.awt.Font var23 = var7.getTickLabelFont((java.lang.Comparable)"PlotOrientation.VERTICAL");
//     var0.setTickLabelFont(var23);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Shape var26 = var25.getDownArrow();
//     var25.resizeRange(0.0d);
//     boolean var29 = var25.isTickMarksVisible();
//     var25.configure();
//     var25.resizeRange(8.0d);
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     boolean var34 = var33.isInverted();
//     var33.setInverted(false);
//     org.jfree.data.RangeType var37 = var33.getRangeType();
//     var25.setRangeType(var37);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var40 = var39.getRootPlot();
//     java.awt.Paint var41 = var39.getBackgroundPaint();
//     boolean var42 = var37.equals((java.lang.Object)var39);
//     var0.setRangeType(var37);
//     
//     // Checks the contract:  equals-hashcode on var12 and var39
//     assertTrue("Contract failed: equals-hashcode on var12 and var39", var12.equals(var39) ? var12.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var12
//     assertTrue("Contract failed: equals-hashcode on var39 and var12", var39.equals(var12) ? var39.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var40
//     assertTrue("Contract failed: equals-hashcode on var13 and var40", var13.equals(var40) ? var13.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var13
//     assertTrue("Contract failed: equals-hashcode on var40 and var13", var40.equals(var13) ? var40.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape(15);
    java.lang.Boolean var4 = null;
    var0.setSeriesItemLabelsVisible(100, var4);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var8 = var7.getTickMarkOutsideLength();
    java.awt.Paint var9 = var7.getAxisLinePaint();
    java.awt.Paint var10 = var7.getTickLabelPaint();
    double var11 = var7.getCategoryMargin();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var12.getDomainMarkers(0, var15);
    java.awt.Paint var17 = var12.getRangeGridlinePaint();
    var7.setPlot((org.jfree.chart.plot.Plot)var12);
    boolean var19 = var0.equals((java.lang.Object)var7);
    java.awt.Paint var20 = var0.getBaseOutlinePaint();
    java.awt.Paint var22 = var0.getSeriesItemLabelPaint(0);
    var0.setIncludeBaseInRange(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    int var14 = var9.getSubtitleCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var3 = var0.getDomainAxisEdge();
//     java.awt.Paint var4 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var12 = var11.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var15 = var14.getTickMarkOutsideLength();
//     boolean var16 = var14.isAxisLineVisible();
//     java.awt.Stroke var17 = var14.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var19 = var18.getRootPlot();
//     java.util.List var20 = var18.getCategories();
//     org.jfree.chart.util.RectangleInsets var21 = var18.getInsets();
//     double var23 = var21.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var24 = new org.jfree.chart.block.LineBorder(var12, var17, var21);
//     var6.setRangeGridlineStroke(var17);
//     var0.setOutlineStroke(var17);
//     org.jfree.chart.axis.AxisLocation var27 = var0.getDomainAxisLocation();
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotOrientation var31 = var28.getOrientation();
//     org.jfree.chart.util.RectangleEdge var32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var27, var31);
//     
//     // Checks the contract:  equals-hashcode on var18 and var28
//     assertTrue("Contract failed: equals-hashcode on var18 and var28", var18.equals(var28) ? var18.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var18
//     assertTrue("Contract failed: equals-hashcode on var28 and var18", var28.equals(var18) ? var28.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setLicenceText("");

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.block.BorderArrangement var1 = new org.jfree.chart.block.BorderArrangement();
    var1.clear();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.block.FlowArrangement var8 = new org.jfree.chart.block.FlowArrangement(var4, var5, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var1, (org.jfree.chart.block.Arrangement)var8);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var13 = var12.getID();
    java.awt.Font var14 = var12.getFont();
    org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("", var14);
    var15.setWidth(1.0d);
    java.lang.Object var18 = null;
    var1.add((org.jfree.chart.block.Block)var15, var18);
    java.lang.String var20 = var15.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    var1.setLabelAngle(0.0d);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
    java.awt.Paint var9 = var7.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var10 = var7.getRowRenderingOrder();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    boolean var12 = var1.equals((java.lang.Object)var7);
    org.jfree.chart.util.RectangleInsets var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setInsets(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.block.BlockContainer var5 = var4.getItemContainer();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     boolean var7 = var6.isInverted();
//     var6.setInverted(false);
//     org.jfree.chart.axis.NumberTickUnit var10 = var6.getTickUnit();
//     var6.setNegativeArrowVisible(false);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.AxisState var14 = new org.jfree.chart.axis.AxisState();
//     java.util.List var15 = var14.getTicks();
//     org.jfree.chart.text.TextBlock var16 = new org.jfree.chart.text.TextBlock();
//     java.util.List var17 = var16.getLines();
//     var14.setTicks(var17);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var21 = var20.getRootPlot();
//     java.awt.Paint var22 = var20.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.util.Layer var25 = null;
//     java.util.Collection var26 = var20.getRangeMarkers(0, var25);
//     org.jfree.chart.plot.Plot var27 = var20.getRootPlot();
//     boolean var28 = var20.isDomainZoomable();
//     var20.setRangeGridlinesVisible(false);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.util.Size2D var34 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var45 = var44.getTickMarkOutsideLength();
//     java.awt.Paint var46 = var44.getAxisLinePaint();
//     java.awt.Paint[] var47 = new java.awt.Paint[] { var46};
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var49 = var48.getRootPlot();
//     org.jfree.chart.util.Layer var51 = null;
//     java.util.Collection var52 = var48.getDomainMarkers(0, var51);
//     java.awt.Paint var53 = var48.getRangeGridlinePaint();
//     java.awt.Paint[] var54 = new java.awt.Paint[] { var53};
//     java.awt.Paint[] var55 = null;
//     java.awt.Stroke var56 = null;
//     java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
//     java.awt.Stroke var58 = null;
//     java.awt.Stroke[] var59 = new java.awt.Stroke[] { var58};
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var64 = org.jfree.chart.util.ShapeUtilities.equal(var61, var63);
//     java.awt.Shape[] var65 = new java.awt.Shape[] { var63};
//     org.jfree.chart.plot.DefaultDrawingSupplier var66 = new org.jfree.chart.plot.DefaultDrawingSupplier(var47, var54, var55, var57, var59, var65);
//     java.awt.Shape var67 = var66.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var69 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var70 = var69.getTickMarkOutsideLength();
//     boolean var71 = var69.isAxisLineVisible();
//     java.awt.Stroke var72 = var69.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var75 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var77 = null;
//     var75.setTickLabelPaint((java.lang.Comparable)10L, var77);
//     var75.setCategoryLabelPositionOffset(0);
//     var75.setAxisLineVisible(true);
//     var75.configure();
//     java.awt.Font var85 = var75.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var87 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var88 = var87.getTickMarkOutsideLength();
//     java.awt.Paint var89 = var87.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var90 = new org.jfree.chart.text.TextFragment("", var85, var89);
//     org.jfree.chart.LegendItem var91 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var67, var72, var89);
//     var38.setStroke(var72);
//     org.jfree.chart.util.RectangleAnchor var93 = var38.getLabelAnchor();
//     java.awt.geom.Rectangle2D var94 = org.jfree.chart.util.RectangleAnchor.createRectangle(var34, 100.0d, (-1.0d), var93);
//     var20.drawBackgroundImage(var31, var94);
//     org.jfree.chart.util.RectangleEdge var96 = null;
//     java.util.List var97 = var6.refreshTicks(var13, var14, var94, var96);
//     var4.setBounds(var94);
//     
//     // Checks the contract:  equals-hashcode on var0 and var48
//     assertTrue("Contract failed: equals-hashcode on var0 and var48", var0.equals(var48) ? var0.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var0
//     assertTrue("Contract failed: equals-hashcode on var48 and var0", var48.equals(var0) ? var48.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var49
//     assertTrue("Contract failed: equals-hashcode on var1 and var49", var1.equals(var49) ? var1.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var1
//     assertTrue("Contract failed: equals-hashcode on var49 and var1", var49.equals(var1) ? var49.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
    int var3 = var0.getBackgroundImageAlignment();
    boolean var4 = var0.isDomainZoomable();
    var0.setBackgroundImageAlignment(0);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
    java.awt.Paint var10 = var8.getBackgroundPaint();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    float var12 = var8.getBackgroundAlpha();
    org.jfree.chart.plot.DatasetRenderingOrder var13 = var8.getDatasetRenderingOrder();
    java.lang.String var14 = var13.toString();
    var0.setDatasetRenderingOrder(var13);
    java.lang.Object var16 = null;
    boolean var17 = var13.equals(var16);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var20 = var19.getLeftArrow();
    org.jfree.chart.entity.CategoryLabelEntity var23 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var20, "hi!", "");
    org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity(var20, "hi!", "PlotOrientation.VERTICAL");
    org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var20, "AxisLabelEntity: label = hi!");
    java.lang.String var29 = var28.getURLText();
    boolean var30 = var13.equals((java.lang.Object)var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var14.equals("DatasetRenderingOrder.REVERSE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape(15);
    java.awt.Paint var4 = var0.getSeriesFillPaint(10);
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var0.setSeriesURLGenerator(100, var6, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxis();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxis((-1572964), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var8 = var7.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var11 = var10.getTickMarkOutsideLength();
//     boolean var12 = var10.isAxisLineVisible();
//     java.awt.Stroke var13 = var10.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
//     java.util.List var16 = var14.getCategories();
//     org.jfree.chart.util.RectangleInsets var17 = var14.getInsets();
//     double var19 = var17.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var20 = new org.jfree.chart.block.LineBorder(var8, var13, var17);
//     var5.setPaint(var8);
//     org.jfree.chart.text.TextAnchor var22 = var5.getLabelTextAnchor();
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var25.setLabel("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull");
//     var25.setLabel("");
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.labels.ItemLabelPosition var34 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var35 = var34.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var31, (-1.0f), 100.0f, var35, 100.0d, 2.0f, 2.0f);
//     java.lang.String var40 = var35.toString();
//     var25.setLabelTextAnchor(var35);
//     java.awt.Shape var42 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Category Plot", var1, 0.5f, 2.0f, var22, 0.0d, var35);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    var0.clear();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var3 = var2.getRootPlot();
    java.awt.Paint var4 = var2.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var5 = var2.getRowRenderingOrder();
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    java.awt.Font var7 = var6.getItemFont();
    org.jfree.chart.block.BlockContainer var8 = var6.getItemContainer();
    java.lang.Object var9 = var8.clone();
    java.awt.Graphics2D var10 = null;
    org.jfree.data.Range var11 = null;
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(var11, 4.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var14 = var0.arrange(var8, var10, var13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     boolean var5 = var1.isRangeGridlinesVisible();
//     java.awt.Font var6 = var1.getNoDataMessageFont();
//     boolean var7 = var1.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAnchor var8 = var1.getDomainGridlinePosition();
//     org.jfree.chart.LegendItemCollection var9 = var1.getLegendItems();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var16 = var15.getTickMarkOutsideLength();
//     java.awt.Paint var17 = var15.getAxisLinePaint();
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var17};
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var20 = var19.getRootPlot();
//     org.jfree.chart.util.Layer var22 = null;
//     java.util.Collection var23 = var19.getDomainMarkers(0, var22);
//     java.awt.Paint var24 = var19.getRangeGridlinePaint();
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
//     java.awt.Paint[] var26 = null;
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     java.awt.Stroke var29 = null;
//     java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var32, var34);
//     java.awt.Shape[] var36 = new java.awt.Shape[] { var34};
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var18, var25, var26, var28, var30, var36);
//     java.awt.Shape var38 = var37.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var41 = var40.getTickMarkOutsideLength();
//     boolean var42 = var40.isAxisLineVisible();
//     java.awt.Stroke var43 = var40.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var48 = null;
//     var46.setTickLabelPaint((java.lang.Comparable)10L, var48);
//     var46.setCategoryLabelPositionOffset(0);
//     var46.setAxisLineVisible(true);
//     var46.configure();
//     java.awt.Font var56 = var46.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var59 = var58.getTickMarkOutsideLength();
//     java.awt.Paint var60 = var58.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var61 = new org.jfree.chart.text.TextFragment("", var56, var60);
//     org.jfree.chart.LegendItem var62 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var38, var43, var60);
//     boolean var63 = var62.isShapeVisible();
//     java.text.AttributedString var64 = var62.getAttributedLabel();
//     var9.add(var62);
//     
//     // Checks the contract:  equals-hashcode on var1 and var19
//     assertTrue("Contract failed: equals-hashcode on var1 and var19", var1.equals(var19) ? var1.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var1
//     assertTrue("Contract failed: equals-hashcode on var19 and var1", var19.equals(var1) ? var19.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    var9.setNotify(true);
    org.jfree.data.KeyedObjects var16 = new org.jfree.data.KeyedObjects();
    org.jfree.data.statistics.MeanAndStandardDeviation var20 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
    java.lang.Number var21 = var20.getStandardDeviation();
    var16.setObject((java.lang.Comparable)100, (java.lang.Object)var21);
    java.lang.Object var23 = var16.clone();
    java.util.List var24 = var16.getKeys();
    boolean var25 = var9.equals((java.lang.Object)var16);
    int var27 = var16.getIndex((java.lang.Comparable)"PlotOrientation.VERTICAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 100.0d+ "'", var21.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-1));

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPosition(15, (-1));
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var9 = var8.getTickMarkOutsideLength();
    boolean var10 = var8.isAxisLineVisible();
    var4.setDomainAxis(10, var8);
    org.jfree.chart.block.LineBorder var12 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var13 = var12.getInsets();
    java.awt.Paint var14 = var12.getPaint();
    var4.setBackgroundPaint(var14);
    var0.setBasePaint(var14, true);
    java.awt.Paint var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelPaint(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.lang.Object var5 = null;
//     boolean var6 = var4.equals(var5);
//     org.jfree.chart.util.RectangleInsets var7 = var4.getLegendItemGraphicPadding();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     java.awt.Paint var11 = var9.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.util.Layer var14 = null;
//     java.util.Collection var15 = var9.getRangeMarkers(0, var14);
//     org.jfree.chart.plot.Plot var16 = var9.getRootPlot();
//     boolean var17 = var9.isDomainZoomable();
//     var9.setRangeGridlinesVisible(false);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.util.Size2D var23 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var34 = var33.getTickMarkOutsideLength();
//     java.awt.Paint var35 = var33.getAxisLinePaint();
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var38 = var37.getRootPlot();
//     org.jfree.chart.util.Layer var40 = null;
//     java.util.Collection var41 = var37.getDomainMarkers(0, var40);
//     java.awt.Paint var42 = var37.getRangeGridlinePaint();
//     java.awt.Paint[] var43 = new java.awt.Paint[] { var42};
//     java.awt.Paint[] var44 = null;
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Stroke var47 = null;
//     java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var53 = org.jfree.chart.util.ShapeUtilities.equal(var50, var52);
//     java.awt.Shape[] var54 = new java.awt.Shape[] { var52};
//     org.jfree.chart.plot.DefaultDrawingSupplier var55 = new org.jfree.chart.plot.DefaultDrawingSupplier(var36, var43, var44, var46, var48, var54);
//     java.awt.Shape var56 = var55.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var59 = var58.getTickMarkOutsideLength();
//     boolean var60 = var58.isAxisLineVisible();
//     java.awt.Stroke var61 = var58.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var66 = null;
//     var64.setTickLabelPaint((java.lang.Comparable)10L, var66);
//     var64.setCategoryLabelPositionOffset(0);
//     var64.setAxisLineVisible(true);
//     var64.configure();
//     java.awt.Font var74 = var64.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var76 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var77 = var76.getTickMarkOutsideLength();
//     java.awt.Paint var78 = var76.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var79 = new org.jfree.chart.text.TextFragment("", var74, var78);
//     org.jfree.chart.LegendItem var80 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var56, var61, var78);
//     var27.setStroke(var61);
//     org.jfree.chart.util.RectangleAnchor var82 = var27.getLabelAnchor();
//     java.awt.geom.Rectangle2D var83 = org.jfree.chart.util.RectangleAnchor.createRectangle(var23, 100.0d, (-1.0d), var82);
//     var9.drawBackgroundImage(var20, var83);
//     org.jfree.chart.util.LengthAdjustmentType var85 = null;
//     org.jfree.chart.util.LengthAdjustmentType var86 = null;
//     java.awt.geom.Rectangle2D var87 = var7.createAdjustedRectangle(var83, var85, var86);
//     
//     // Checks the contract:  equals-hashcode on var0 and var37
//     assertTrue("Contract failed: equals-hashcode on var0 and var37", var0.equals(var37) ? var0.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var0
//     assertTrue("Contract failed: equals-hashcode on var37 and var0", var37.equals(var0) ? var37.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var38
//     assertTrue("Contract failed: equals-hashcode on var1 and var38", var1.equals(var38) ? var1.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var1
//     assertTrue("Contract failed: equals-hashcode on var38 and var1", var38.equals(var1) ? var38.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.util.Size2D var8 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var19 = var18.getTickMarkOutsideLength();
//     java.awt.Paint var20 = var18.getAxisLinePaint();
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var23 = var22.getRootPlot();
//     org.jfree.chart.util.Layer var25 = null;
//     java.util.Collection var26 = var22.getDomainMarkers(0, var25);
//     java.awt.Paint var27 = var22.getRangeGridlinePaint();
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     java.awt.Paint[] var29 = null;
//     java.awt.Stroke var30 = null;
//     java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var35, var37);
//     java.awt.Shape[] var39 = new java.awt.Shape[] { var37};
//     org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var28, var29, var31, var33, var39);
//     java.awt.Shape var41 = var40.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var44 = var43.getTickMarkOutsideLength();
//     boolean var45 = var43.isAxisLineVisible();
//     java.awt.Stroke var46 = var43.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var51 = null;
//     var49.setTickLabelPaint((java.lang.Comparable)10L, var51);
//     var49.setCategoryLabelPositionOffset(0);
//     var49.setAxisLineVisible(true);
//     var49.configure();
//     java.awt.Font var59 = var49.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var62 = var61.getTickMarkOutsideLength();
//     java.awt.Paint var63 = var61.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var64 = new org.jfree.chart.text.TextFragment("", var59, var63);
//     org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var41, var46, var63);
//     var12.setStroke(var46);
//     org.jfree.chart.util.RectangleAnchor var67 = var12.getLabelAnchor();
//     java.awt.geom.Rectangle2D var68 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, 100.0d, (-1.0d), var67);
//     java.awt.geom.Point2D var69 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 84.0d, var68);
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var71 = var70.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var74 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var75 = var74.getTickMarkOutsideLength();
//     boolean var76 = var74.isAxisLineVisible();
//     var70.setDomainAxis(10, var74);
//     java.awt.Paint var78 = var74.getLabelPaint();
//     org.jfree.chart.LegendItem var79 = new org.jfree.chart.LegendItem("hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.awt.Shape)var68, var78);
//     
//     // Checks the contract:  equals-hashcode on var22 and var70
//     assertTrue("Contract failed: equals-hashcode on var22 and var70", var22.equals(var70) ? var22.hashCode() == var70.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var70.", var22.equals(var70) == var70.equals(var22));
//     
//     // Checks the contract:  equals-hashcode on var23 and var71
//     assertTrue("Contract failed: equals-hashcode on var23 and var71", var23.equals(var71) ? var23.hashCode() == var71.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var71.", var23.equals(var71) == var71.equals(var23));
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis();
    int var9 = var6.getBackgroundImageAlignment();
    var6.setRangeCrosshairVisible(true);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var6.getDomainMarkers(10, var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var6);
    org.jfree.data.general.DatasetGroup var16 = var6.getDatasetGroup();
    boolean var17 = var4.equals((java.lang.Object)var6);
    var6.configureDomainAxes();
    org.jfree.chart.util.SortOrder var19 = var6.getRowRenderingOrder();
    java.lang.String var20 = var19.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "SortOrder.ASCENDING"+ "'", var20.equals("SortOrder.ASCENDING"));

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.text.TextAnchor var11 = var10.getRotationAnchor();
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var7, (-1.0f), 100.0f, var11, 100.0d, 2.0f, 2.0f);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var18 = var16.lookupSeriesShape(15);
    java.lang.Boolean var20 = null;
    var16.setSeriesItemLabelsVisible(100, var20);
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var24 = var23.getTickMarkOutsideLength();
    java.awt.Paint var25 = var23.getAxisLinePaint();
    java.awt.Paint var26 = var23.getTickLabelPaint();
    double var27 = var23.getCategoryMargin();
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var29 = var28.getRootPlot();
    org.jfree.chart.util.Layer var31 = null;
    java.util.Collection var32 = var28.getDomainMarkers(0, var31);
    java.awt.Paint var33 = var28.getRangeGridlinePaint();
    var23.setPlot((org.jfree.chart.plot.Plot)var28);
    boolean var35 = var16.equals((java.lang.Object)var23);
    java.awt.Paint var37 = null;
    var16.setSeriesItemLabelPaint(0, var37);
    boolean var39 = var16.getAutoPopulateSeriesFillPaint();
    boolean var42 = var16.getItemVisible(0, 15);
    boolean var43 = var11.equals((java.lang.Object)var16);
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.5f, 10.0f, var4, 0.0d, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, (-1.0d));

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Shape var1 = var0.getDownArrow();
//     var0.resizeRange(0.0d);
//     boolean var4 = var0.isTickMarksVisible();
//     org.jfree.chart.util.Size2D var10 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var21 = var20.getTickMarkOutsideLength();
//     java.awt.Paint var22 = var20.getAxisLinePaint();
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var25 = var24.getRootPlot();
//     org.jfree.chart.util.Layer var27 = null;
//     java.util.Collection var28 = var24.getDomainMarkers(0, var27);
//     java.awt.Paint var29 = var24.getRangeGridlinePaint();
//     java.awt.Paint[] var30 = new java.awt.Paint[] { var29};
//     java.awt.Paint[] var31 = null;
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Stroke var34 = null;
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var37, var39);
//     java.awt.Shape[] var41 = new java.awt.Shape[] { var39};
//     org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier(var23, var30, var31, var33, var35, var41);
//     java.awt.Shape var43 = var42.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var46 = var45.getTickMarkOutsideLength();
//     boolean var47 = var45.isAxisLineVisible();
//     java.awt.Stroke var48 = var45.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var53 = null;
//     var51.setTickLabelPaint((java.lang.Comparable)10L, var53);
//     var51.setCategoryLabelPositionOffset(0);
//     var51.setAxisLineVisible(true);
//     var51.configure();
//     java.awt.Font var61 = var51.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var64 = var63.getTickMarkOutsideLength();
//     java.awt.Paint var65 = var63.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var66 = new org.jfree.chart.text.TextFragment("", var61, var65);
//     org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var43, var48, var65);
//     var14.setStroke(var48);
//     org.jfree.chart.util.RectangleAnchor var69 = var14.getLabelAnchor();
//     java.awt.geom.Rectangle2D var70 = org.jfree.chart.util.RectangleAnchor.createRectangle(var10, 100.0d, (-1.0d), var69);
//     java.awt.geom.Point2D var71 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 84.0d, var70);
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var73 = var72.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var74 = var72.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var75 = var72.getRangeAxisEdge();
//     double var76 = var0.lengthToJava2D(0.05d, var70, var75);
//     
//     // Checks the contract:  equals-hashcode on var24 and var72
//     assertTrue("Contract failed: equals-hashcode on var24 and var72", var24.equals(var72) ? var24.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var24
//     assertTrue("Contract failed: equals-hashcode on var72 and var24", var72.equals(var24) ? var72.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var73
//     assertTrue("Contract failed: equals-hashcode on var25 and var73", var25.equals(var73) ? var25.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var25
//     assertTrue("Contract failed: equals-hashcode on var73 and var25", var73.equals(var25) ? var73.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    boolean var5 = var4.isNotify();
    var4.clearSubtitles();
    java.awt.Image var7 = var4.getBackgroundImage();
    var4.setBackgroundImageAlpha(2.0f);
    org.jfree.chart.ChartRenderingInfo var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var15 = var4.createBufferedImage((-1572964), (-1572964), 100.0d, 30.47619047619048d, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(var2);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = var0.getRendererForDataset(var4);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     java.awt.Paint var9 = var7.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var7);
//     float var11 = var7.getBackgroundAlpha();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var14 = var13.getTickMarkOutsideLength();
//     java.awt.Paint var15 = var13.getAxisLinePaint();
//     java.awt.Paint var16 = var13.getTickLabelPaint();
//     var13.setLabelAngle(0.0d);
//     java.util.List var19 = var7.getCategoriesForAxis(var13);
//     var0.setParent((org.jfree.chart.plot.Plot)var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     boolean var10 = var9.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
//     int var14 = var13.getPercent();
//     int var15 = var13.getPercent();
//     int var16 = var13.getType();
//     int var17 = var13.getType();
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var20 = var19.getTickMarkOutsideLength();
//     java.awt.Paint var21 = var19.getAxisLinePaint();
//     java.awt.Paint var22 = var19.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var25 = var24.getRootPlot();
//     java.awt.Paint var26 = var24.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var24);
//     boolean var28 = var27.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var31 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var22, var27, 100, 10);
//     var27.setNotify(true);
//     org.jfree.data.KeyedObjects var34 = new org.jfree.data.KeyedObjects();
//     org.jfree.data.statistics.MeanAndStandardDeviation var38 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     java.lang.Number var39 = var38.getStandardDeviation();
//     var34.setObject((java.lang.Comparable)100, (java.lang.Object)var39);
//     java.lang.Object var41 = var34.clone();
//     java.util.List var42 = var34.getKeys();
//     boolean var43 = var27.equals((java.lang.Object)var34);
//     org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.block.BlockFrame var46 = var45.getFrame();
//     org.jfree.chart.event.TitleChangeEvent var47 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var45);
//     org.jfree.chart.JFreeChart var48 = var47.getChart();
//     var27.titleChanged(var47);
//     org.jfree.chart.JFreeChart var50 = var47.getChart();
//     var13.setChart(var50);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var25
//     assertTrue("Contract failed: equals-hashcode on var7 and var25", var7.equals(var25) ? var7.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var7
//     assertTrue("Contract failed: equals-hashcode on var25 and var7", var25.equals(var7) ? var25.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var27
//     assertTrue("Contract failed: equals-hashcode on var9 and var27", var9.equals(var27) ? var9.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var50
//     assertTrue("Contract failed: equals-hashcode on var9 and var50", var9.equals(var50) ? var9.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var9
//     assertTrue("Contract failed: equals-hashcode on var27 and var9", var27.equals(var9) ? var27.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var9
//     assertTrue("Contract failed: equals-hashcode on var50 and var9", var50.equals(var9) ? var50.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var3 = var0.getDomainAxisEdge();
//     java.awt.Paint var4 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
//     java.awt.Paint var8 = var6.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var12 = var11.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var15 = var14.getTickMarkOutsideLength();
//     boolean var16 = var14.isAxisLineVisible();
//     java.awt.Stroke var17 = var14.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var19 = var18.getRootPlot();
//     java.util.List var20 = var18.getCategories();
//     org.jfree.chart.util.RectangleInsets var21 = var18.getInsets();
//     double var23 = var21.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var24 = new org.jfree.chart.block.LineBorder(var12, var17, var21);
//     var6.setRangeGridlineStroke(var17);
//     var0.setOutlineStroke(var17);
//     org.jfree.chart.axis.AxisLocation var27 = var0.getDomainAxisLocation();
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = var0.getRendererForDataset(var28);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var33 = var32.getRootPlot();
//     java.util.List var34 = var32.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var32.getRenderer((-16777216));
//     java.util.List var37 = var32.getAnnotations();
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     var32.setRangeAxis(0, var39);
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     java.awt.geom.Rectangle2D var45 = null;
//     var44.setPlotArea(var45);
//     java.awt.geom.Point2D var47 = null;
//     var32.zoomRangeAxes(1.0d, 0.0d, var44, var47);
//     var0.handleClick(10, 255, var44);
//     
//     // Checks the contract:  equals-hashcode on var18 and var32
//     assertTrue("Contract failed: equals-hashcode on var18 and var32", var18.equals(var32) ? var18.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var18
//     assertTrue("Contract failed: equals-hashcode on var32 and var18", var32.equals(var18) ? var32.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var33
//     assertTrue("Contract failed: equals-hashcode on var19 and var33", var19.equals(var33) ? var19.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var19
//     assertTrue("Contract failed: equals-hashcode on var33 and var19", var33.equals(var19) ? var33.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(2.0f, (-1.0f), 0.0f);
//     int var4 = var3.getTransparency();
//     java.awt.color.ColorSpace var5 = null;
//     float[] var6 = null;
//     float[] var7 = var3.getComponents(var5, var6);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape(15);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var5 = var4.getTickMarkOutsideLength();
//     java.awt.Paint var6 = var4.getAxisLinePaint();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     java.awt.Paint var9 = var7.getBackgroundPaint();
//     var4.setAxisLinePaint(var9);
//     var0.setBasePaint(var9, true);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var16 = null;
//     var14.setTickLabelPaint((java.lang.Comparable)10L, var16);
//     var14.setCategoryLabelPositionOffset(0);
//     var14.setAxisLineVisible(true);
//     var14.configure();
//     java.awt.Font var24 = var14.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var27 = var26.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var31 = var30.getTickMarkOutsideLength();
//     boolean var32 = var30.isAxisLineVisible();
//     var26.setDomainAxis(10, var30);
//     org.jfree.chart.block.LineBorder var34 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var35 = var34.getInsets();
//     java.awt.Paint var36 = var34.getPaint();
//     var26.setBackgroundPaint(var36);
//     var14.setTickLabelPaint((java.lang.Comparable)'a', var36);
//     boolean var39 = var0.equals((java.lang.Object)'a');
//     var0.setSeriesVisibleInLegend(10, (java.lang.Boolean)true);
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var45 = var44.getTickMarkOutsideLength();
//     java.awt.Paint var46 = var44.getAxisLinePaint();
//     java.awt.Paint var47 = var44.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var50 = var49.getRootPlot();
//     java.awt.Paint var51 = var49.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var49);
//     boolean var53 = var52.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var47, var52, 100, 10);
//     var52.setNotify(true);
//     org.jfree.data.KeyedObjects var59 = new org.jfree.data.KeyedObjects();
//     org.jfree.data.statistics.MeanAndStandardDeviation var63 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     java.lang.Number var64 = var63.getStandardDeviation();
//     var59.setObject((java.lang.Comparable)100, (java.lang.Object)var64);
//     java.lang.Object var66 = var59.clone();
//     java.util.List var67 = var59.getKeys();
//     boolean var68 = var52.equals((java.lang.Object)var59);
//     org.jfree.chart.title.TextTitle var70 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.block.BlockFrame var71 = var70.getFrame();
//     org.jfree.chart.event.TitleChangeEvent var72 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var70);
//     org.jfree.chart.JFreeChart var73 = var72.getChart();
//     var52.titleChanged(var72);
//     boolean var75 = var0.hasListener((java.util.EventListener)var52);
//     
//     // Checks the contract:  equals-hashcode on var7 and var49
//     assertTrue("Contract failed: equals-hashcode on var7 and var49", var7.equals(var49) ? var7.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var7
//     assertTrue("Contract failed: equals-hashcode on var49 and var7", var49.equals(var7) ? var49.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var50
//     assertTrue("Contract failed: equals-hashcode on var8 and var50", var8.equals(var50) ? var8.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var8
//     assertTrue("Contract failed: equals-hashcode on var50 and var8", var50.equals(var8) ? var50.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object var2 = var0.handleGetObject("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var5 = null;
    var3.setTickLabelPaint((java.lang.Comparable)10L, var5);
    var3.setCategoryLabelPositionOffset(0);
    var3.setAxisLineVisible(true);
    var3.configure();
    java.awt.Font var13 = var3.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var16 = var15.getTickMarkOutsideLength();
    java.awt.Paint var17 = var15.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("", var13, var17);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var13);
    var19.setURLText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");
    java.awt.Font var22 = var19.getFont();
    org.jfree.chart.block.BlockFrame var23 = var19.getFrame();
    java.awt.Paint var24 = var19.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.util.List var2 = var0.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
//     org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var12 = var11.getTickMarkOutsideLength();
//     java.awt.Paint var13 = var11.getAxisLinePaint();
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
//     org.jfree.chart.util.Layer var18 = null;
//     java.util.Collection var19 = var15.getDomainMarkers(0, var18);
//     java.awt.Paint var20 = var15.getRangeGridlinePaint();
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
//     java.awt.Paint[] var22 = null;
//     java.awt.Stroke var23 = null;
//     java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var28, var30);
//     java.awt.Shape[] var32 = new java.awt.Shape[] { var30};
//     org.jfree.chart.plot.DefaultDrawingSupplier var33 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var21, var22, var24, var26, var32);
//     java.awt.Shape var34 = var33.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var37 = var36.getTickMarkOutsideLength();
//     boolean var38 = var36.isAxisLineVisible();
//     java.awt.Stroke var39 = var36.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var44 = null;
//     var42.setTickLabelPaint((java.lang.Comparable)10L, var44);
//     var42.setCategoryLabelPositionOffset(0);
//     var42.setAxisLineVisible(true);
//     var42.configure();
//     java.awt.Font var52 = var42.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var55 = var54.getTickMarkOutsideLength();
//     java.awt.Paint var56 = var54.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var57 = new org.jfree.chart.text.TextFragment("", var52, var56);
//     org.jfree.chart.LegendItem var58 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var34, var39, var56);
//     java.lang.Comparable var59 = var58.getSeriesKey();
//     boolean var60 = var58.isShapeVisible();
//     java.awt.Paint var61 = var58.getFillPaint();
//     var0.setNoDataMessagePaint(var61);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("poly");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(2.0f, (-1.0f), 0.0f);
    int var4 = var3.getTransparency();
    float[] var5 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var3.getRGBComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     org.jfree.data.KeyedObjects var3 = new org.jfree.data.KeyedObjects();
//     org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     java.lang.Number var8 = var7.getStandardDeviation();
//     var3.setObject((java.lang.Comparable)100, (java.lang.Object)var8);
//     java.lang.Object var10 = var3.clone();
//     boolean var11 = var2.equals((java.lang.Object)var3);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var2
//     assertTrue("Contract failed: equals-hashcode on var7 and var2", var7.equals(var2) ? var7.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isInverted();
    var0.setInverted(false);
    org.jfree.chart.axis.NumberTickUnit var4 = var0.getTickUnit();
    var0.setNegativeArrowVisible(false);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.AxisState var8 = new org.jfree.chart.axis.AxisState();
    java.util.List var9 = var8.getTicks();
    org.jfree.chart.text.TextBlock var10 = new org.jfree.chart.text.TextBlock();
    java.util.List var11 = var10.getLines();
    var8.setTicks(var11);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
    java.awt.Paint var16 = var14.getBackgroundPaint();
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var14.getRangeMarkers(0, var19);
    org.jfree.chart.plot.Plot var21 = var14.getRootPlot();
    boolean var22 = var14.isDomainZoomable();
    var14.setRangeGridlinesVisible(false);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.util.Size2D var28 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var39 = var38.getTickMarkOutsideLength();
    java.awt.Paint var40 = var38.getAxisLinePaint();
    java.awt.Paint[] var41 = new java.awt.Paint[] { var40};
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var43 = var42.getRootPlot();
    org.jfree.chart.util.Layer var45 = null;
    java.util.Collection var46 = var42.getDomainMarkers(0, var45);
    java.awt.Paint var47 = var42.getRangeGridlinePaint();
    java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
    java.awt.Paint[] var49 = null;
    java.awt.Stroke var50 = null;
    java.awt.Stroke[] var51 = new java.awt.Stroke[] { var50};
    java.awt.Stroke var52 = null;
    java.awt.Stroke[] var53 = new java.awt.Stroke[] { var52};
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var58 = org.jfree.chart.util.ShapeUtilities.equal(var55, var57);
    java.awt.Shape[] var59 = new java.awt.Shape[] { var57};
    org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier(var41, var48, var49, var51, var53, var59);
    java.awt.Shape var61 = var60.getNextShape();
    org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var64 = var63.getTickMarkOutsideLength();
    boolean var65 = var63.isAxisLineVisible();
    java.awt.Stroke var66 = var63.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var69 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var71 = null;
    var69.setTickLabelPaint((java.lang.Comparable)10L, var71);
    var69.setCategoryLabelPositionOffset(0);
    var69.setAxisLineVisible(true);
    var69.configure();
    java.awt.Font var79 = var69.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var81 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var82 = var81.getTickMarkOutsideLength();
    java.awt.Paint var83 = var81.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var84 = new org.jfree.chart.text.TextFragment("", var79, var83);
    org.jfree.chart.LegendItem var85 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var61, var66, var83);
    var32.setStroke(var66);
    org.jfree.chart.util.RectangleAnchor var87 = var32.getLabelAnchor();
    java.awt.geom.Rectangle2D var88 = org.jfree.chart.util.RectangleAnchor.createRectangle(var28, 100.0d, (-1.0d), var87);
    var14.drawBackgroundImage(var25, var88);
    org.jfree.chart.util.RectangleEdge var90 = null;
    java.util.List var91 = var0.refreshTicks(var7, var8, var88, var90);
    java.util.Collection var92 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var1 = var0.getDownArrow();
    org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.String var5 = var3.valueToString(100.0d);
    var0.setTickUnit(var3);
    var0.resizeRange((-12.0d), 0.05d);
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var18 = var17.getTickMarkOutsideLength();
    java.awt.Paint var19 = var17.getAxisLinePaint();
    java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var22 = var21.getRootPlot();
    org.jfree.chart.util.Layer var24 = null;
    java.util.Collection var25 = var21.getDomainMarkers(0, var24);
    java.awt.Paint var26 = var21.getRangeGridlinePaint();
    java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
    java.awt.Paint[] var28 = null;
    java.awt.Stroke var29 = null;
    java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
    java.awt.Stroke var31 = null;
    java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var34, var36);
    java.awt.Shape[] var38 = new java.awt.Shape[] { var36};
    org.jfree.chart.plot.DefaultDrawingSupplier var39 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var27, var28, var30, var32, var38);
    java.awt.Shape var40 = var39.getNextShape();
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var43 = var42.getTickMarkOutsideLength();
    boolean var44 = var42.isAxisLineVisible();
    java.awt.Stroke var45 = var42.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var50 = null;
    var48.setTickLabelPaint((java.lang.Comparable)10L, var50);
    var48.setCategoryLabelPositionOffset(0);
    var48.setAxisLineVisible(true);
    var48.configure();
    java.awt.Font var58 = var48.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var61 = var60.getTickMarkOutsideLength();
    java.awt.Paint var62 = var60.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var63 = new org.jfree.chart.text.TextFragment("", var58, var62);
    org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var40, var45, var62);
    var10.setSeriesPaint(100, var62, true);
    boolean var67 = var10.getIncludeBaseInRange();
    var10.setAutoPopulateSeriesOutlinePaint(true);
    boolean var70 = var10.getIncludeBaseInRange();
    org.jfree.chart.axis.CategoryAxis var74 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var76 = null;
    var74.setTickLabelPaint((java.lang.Comparable)10L, var76);
    var74.setCategoryLabelPositionOffset(0);
    var74.setAxisLineVisible(true);
    var74.configure();
    java.awt.Font var84 = var74.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var86 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var87 = var86.getTickMarkOutsideLength();
    java.awt.Paint var88 = var86.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var89 = new org.jfree.chart.text.TextFragment("", var84, var88);
    org.jfree.chart.block.LabelBlock var90 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var84);
    var10.setBaseItemLabelFont(var84, false);
    var0.setTickLabelFont(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "100"+ "'", var5.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
    int var3 = var0.getBackgroundImageAlignment();
    var0.setRangeCrosshairVisible(true);
    org.jfree.chart.LegendItemCollection var6 = var0.getFixedLegendItems();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var10 = var9.getTickMarkOutsideLength();
    java.awt.Paint var11 = var9.getAxisLinePaint();
    java.awt.Paint var12 = var9.getTickLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var5 = var3.calculateBottomInset((-1.0d));
    org.jfree.chart.util.UnitType var6 = var3.getUnitType();
    java.lang.String var7 = var6.toString();
    java.lang.String var8 = var6.toString();
    java.lang.String var9 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "UnitType.ABSOLUTE"+ "'", var7.equals("UnitType.ABSOLUTE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "UnitType.ABSOLUTE"+ "'", var8.equals("UnitType.ABSOLUTE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "UnitType.ABSOLUTE"+ "'", var9.equals("UnitType.ABSOLUTE"));

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var4 = var3.getRootPlot();
//     java.awt.Paint var5 = var3.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var3);
//     boolean var7 = var3.isRangeGridlinesVisible();
//     java.awt.Font var8 = var3.getNoDataMessageFont();
//     org.jfree.data.general.Dataset var9 = null;
//     org.jfree.data.general.DatasetChangeEvent var10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var3, var9);
//     var1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var3);
//     java.lang.String var12 = var3.getNoDataMessage();
//     org.jfree.data.general.DatasetGroup var13 = var3.getDatasetGroup();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.util.Size2D var21 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var32 = var31.getTickMarkOutsideLength();
//     java.awt.Paint var33 = var31.getAxisLinePaint();
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var33};
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var36 = var35.getRootPlot();
//     org.jfree.chart.util.Layer var38 = null;
//     java.util.Collection var39 = var35.getDomainMarkers(0, var38);
//     java.awt.Paint var40 = var35.getRangeGridlinePaint();
//     java.awt.Paint[] var41 = new java.awt.Paint[] { var40};
//     java.awt.Paint[] var42 = null;
//     java.awt.Stroke var43 = null;
//     java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var51 = org.jfree.chart.util.ShapeUtilities.equal(var48, var50);
//     java.awt.Shape[] var52 = new java.awt.Shape[] { var50};
//     org.jfree.chart.plot.DefaultDrawingSupplier var53 = new org.jfree.chart.plot.DefaultDrawingSupplier(var34, var41, var42, var44, var46, var52);
//     java.awt.Shape var54 = var53.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var57 = var56.getTickMarkOutsideLength();
//     boolean var58 = var56.isAxisLineVisible();
//     java.awt.Stroke var59 = var56.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var64 = null;
//     var62.setTickLabelPaint((java.lang.Comparable)10L, var64);
//     var62.setCategoryLabelPositionOffset(0);
//     var62.setAxisLineVisible(true);
//     var62.configure();
//     java.awt.Font var72 = var62.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var74 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var75 = var74.getTickMarkOutsideLength();
//     java.awt.Paint var76 = var74.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var77 = new org.jfree.chart.text.TextFragment("", var72, var76);
//     org.jfree.chart.LegendItem var78 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var54, var59, var76);
//     var25.setStroke(var59);
//     org.jfree.chart.util.RectangleAnchor var80 = var25.getLabelAnchor();
//     java.awt.geom.Rectangle2D var81 = org.jfree.chart.util.RectangleAnchor.createRectangle(var21, 100.0d, (-1.0d), var80);
//     java.awt.geom.Point2D var82 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 84.0d, var81);
//     var3.zoomDomainAxes((-12.0d), 4.0d, var16, var82);
//     
//     // Checks the contract:  equals-hashcode on var3 and var35
//     assertTrue("Contract failed: equals-hashcode on var3 and var35", var3.equals(var35) ? var3.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var3
//     assertTrue("Contract failed: equals-hashcode on var35 and var3", var35.equals(var3) ? var35.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var36
//     assertTrue("Contract failed: equals-hashcode on var4 and var36", var4.equals(var36) ? var4.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var4
//     assertTrue("Contract failed: equals-hashcode on var36 and var4", var36.equals(var4) ? var36.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis();
    int var9 = var6.getBackgroundImageAlignment();
    var6.setRangeCrosshairVisible(true);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var6.getDomainMarkers(10, var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var6);
    org.jfree.data.general.DatasetGroup var16 = var6.getDatasetGroup();
    boolean var17 = var4.equals((java.lang.Object)var6);
    var6.setAnchorValue(0.05d, false);
    java.awt.Image var21 = var6.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 100.0f);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    var1.setAxisLineVisible(true);
    var1.configure();
    java.awt.Font var11 = var1.getTickLabelFont((java.lang.Comparable)0.0f);
    var1.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var15 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var1.setCategoryLabelPositions(var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var18 = var17.getRootPlot();
    java.util.List var19 = var17.getCategories();
    org.jfree.chart.util.RectangleInsets var20 = var17.getInsets();
    java.awt.Stroke var21 = null;
    var17.setOutlineStroke(var21);
    org.jfree.data.category.CategoryDataset var24 = var17.getDataset(0);
    org.jfree.chart.util.RectangleEdge var26 = var17.getDomainAxisEdge(0);
    org.jfree.chart.axis.CategoryLabelPosition var27 = var15.getLabelPosition(var26);
    float var28 = var27.getWidthRatio();
    double var29 = var27.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 10.0d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var5 = var4.getTickMarkOutsideLength();
    boolean var6 = var4.isAxisLineVisible();
    var0.setDomainAxis(10, var4);
    java.awt.Paint var8 = var4.getAxisLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var4 = var2.lookupSeriesShape(15);
    org.jfree.chart.labels.ItemLabelPosition var5 = var2.getBaseNegativeItemLabelPosition();
    var0.setPositiveItemLabelPositionFallback(var5);
    java.awt.Stroke var9 = var0.getItemStroke(1, (-1));
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var21 = null;
    var19.setTickLabelPaint((java.lang.Comparable)10L, var21);
    var19.setCategoryLabelPositionOffset(0);
    var19.setAxisLineVisible(true);
    var19.configure();
    java.awt.Font var29 = var19.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var32 = var31.getTickMarkOutsideLength();
    java.awt.Paint var33 = var31.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var34 = new org.jfree.chart.text.TextFragment("", var29, var33);
    org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var29);
    org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("", var29);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var39 = var37.getRangeAxisForDataset(0);
    java.awt.Paint var40 = var37.getBackgroundPaint();
    org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("", var29, var40);
    org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder((-1.0d), 1.0d, (-1.0d), 0.05d, var40);
    var0.setBaseFillPaint(var40);
    var0.setMinimumBarLength(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    java.awt.Stroke var14 = null;
    var9.setBorderStroke(var14);
    org.jfree.chart.event.ChartProgressListener var16 = null;
    var9.addProgressListener(var16);
    var9.setAntiAlias(false);
    var9.fireChartChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var23 = var9.createBufferedImage((-1572964), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
//     int var4 = var1.getBackgroundImageAlignment();
//     var1.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var8 = null;
//     java.util.Collection var9 = var1.getDomainMarkers(10, var8);
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
//     java.util.List var13 = var11.getCategories();
//     org.jfree.chart.util.RectangleInsets var14 = var11.getInsets();
//     double var16 = var14.calculateBottomInset((-1.0d));
//     double var17 = var14.getTop();
//     var10.setPadding(var14);
//     double var20 = var14.calculateBottomOutset(4.0d);
//     org.jfree.chart.util.Size2D var21 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var26 = var25.getLabel();
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var35 = var34.getTickMarkOutsideLength();
//     java.awt.Paint var36 = var34.getAxisLinePaint();
//     java.awt.Paint[] var37 = new java.awt.Paint[] { var36};
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var39 = var38.getRootPlot();
//     org.jfree.chart.util.Layer var41 = null;
//     java.util.Collection var42 = var38.getDomainMarkers(0, var41);
//     java.awt.Paint var43 = var38.getRangeGridlinePaint();
//     java.awt.Paint[] var44 = new java.awt.Paint[] { var43};
//     java.awt.Paint[] var45 = null;
//     java.awt.Stroke var46 = null;
//     java.awt.Stroke[] var47 = new java.awt.Stroke[] { var46};
//     java.awt.Stroke var48 = null;
//     java.awt.Stroke[] var49 = new java.awt.Stroke[] { var48};
//     java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var54 = org.jfree.chart.util.ShapeUtilities.equal(var51, var53);
//     java.awt.Shape[] var55 = new java.awt.Shape[] { var53};
//     org.jfree.chart.plot.DefaultDrawingSupplier var56 = new org.jfree.chart.plot.DefaultDrawingSupplier(var37, var44, var45, var47, var49, var55);
//     java.awt.Shape var57 = var56.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var59 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var60 = var59.getTickMarkOutsideLength();
//     boolean var61 = var59.isAxisLineVisible();
//     java.awt.Stroke var62 = var59.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var67 = null;
//     var65.setTickLabelPaint((java.lang.Comparable)10L, var67);
//     var65.setCategoryLabelPositionOffset(0);
//     var65.setAxisLineVisible(true);
//     var65.configure();
//     java.awt.Font var75 = var65.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var77 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var78 = var77.getTickMarkOutsideLength();
//     java.awt.Paint var79 = var77.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var80 = new org.jfree.chart.text.TextFragment("", var75, var79);
//     org.jfree.chart.LegendItem var81 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var57, var62, var79);
//     var28.setStroke(var62);
//     org.jfree.chart.util.RectangleAnchor var83 = var28.getLabelAnchor();
//     var25.setLabelAnchor(var83);
//     java.awt.geom.Rectangle2D var85 = org.jfree.chart.util.RectangleAnchor.createRectangle(var21, 100.0d, 1.0d, var83);
//     java.awt.geom.Rectangle2D var86 = var14.createOutsetRectangle(var85);
//     
//     // Checks the contract:  equals-hashcode on var11 and var38
//     assertTrue("Contract failed: equals-hashcode on var11 and var38", var11.equals(var38) ? var11.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var11
//     assertTrue("Contract failed: equals-hashcode on var38 and var11", var38.equals(var11) ? var38.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var39
//     assertTrue("Contract failed: equals-hashcode on var12 and var39", var12.equals(var39) ? var12.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var12
//     assertTrue("Contract failed: equals-hashcode on var39 and var12", var39.equals(var12) ? var39.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object var2 = var0.handleGetObject("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    java.util.Set var3 = var0.keySet();
    java.util.Enumeration var4 = var0.getKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     var0.clearAnnotations();
//     double var3 = var0.getAnchorValue();
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getRangeAxisForDataset(0);
//     var6.setAnchorValue(0.2d);
//     org.jfree.chart.axis.AxisSpace var11 = var6.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var14 = var13.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var15 = var13.getDomainAxis();
//     int var16 = var13.getBackgroundImageAlignment();
//     var13.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var13.getDomainMarkers(10, var20);
//     org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var24 = var23.getRootPlot();
//     java.util.List var25 = var23.getCategories();
//     org.jfree.chart.util.RectangleInsets var26 = var23.getInsets();
//     double var28 = var26.calculateBottomInset((-1.0d));
//     double var29 = var26.getTop();
//     var22.setPadding(var26);
//     var6.setInsets(var26);
//     org.jfree.chart.axis.AxisLocation var33 = var6.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var37 = null;
//     var35.setTickLabelPaint((java.lang.Comparable)10L, var37);
//     var35.setCategoryLabelPositionOffset(0);
//     var35.setAxisLineVisible(true);
//     var35.configure();
//     java.awt.Font var45 = var35.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var48 = var47.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var52 = var51.getTickMarkOutsideLength();
//     boolean var53 = var51.isAxisLineVisible();
//     var47.setDomainAxis(10, var51);
//     org.jfree.chart.block.LineBorder var55 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var56 = var55.getInsets();
//     java.awt.Paint var57 = var55.getPaint();
//     var47.setBackgroundPaint(var57);
//     var35.setTickLabelPaint((java.lang.Comparable)'a', var57);
//     boolean var60 = var33.equals((java.lang.Object)var57);
//     var0.setRangeAxisLocation(10, var33);
//     
//     // Checks the contract:  equals-hashcode on var23 and var0
//     assertTrue("Contract failed: equals-hashcode on var23 and var0", var23.equals(var0) ? var23.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var0.", var23.equals(var0) == var0.equals(var23));
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var1.", var24.equals(var1) == var1.equals(var24));
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.data.statistics.MeanAndStandardDeviation var4 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
    java.lang.Number var5 = var4.getStandardDeviation();
    var0.setObject((java.lang.Comparable)100, (java.lang.Object)var5);
    java.lang.Object var7 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var11 = var9.getDomainAxis();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var9.setRangeAxes(var13);
    var0.addObject((java.lang.Comparable)(-100), (java.lang.Object)var13);
    java.util.List var16 = var0.getKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100.0d+ "'", var5.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesStroke(false);
    java.awt.Paint var3 = var0.getBaseFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-1572964), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     boolean var5 = var1.isRangeGridlinesVisible();
//     java.awt.Font var6 = var1.getNoDataMessageFont();
//     boolean var7 = var1.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAnchor var8 = var1.getDomainGridlinePosition();
//     org.jfree.chart.LegendItemCollection var9 = var1.getLegendItems();
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
//     java.awt.Paint var14 = var12.getBackgroundPaint();
//     var11.setPaint(var14);
//     java.awt.Font var16 = var11.getFont();
//     java.awt.Paint var17 = var11.getBackgroundPaint();
//     java.awt.Font var18 = var11.getFont();
//     boolean var19 = var9.equals((java.lang.Object)var18);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    boolean var5 = var1.isRangeGridlinesVisible();
    java.awt.Font var6 = var1.getNoDataMessageFont();
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addAnnotation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isInverted();
    var0.setInverted(false);
    java.text.NumberFormat var4 = var0.getNumberFormatOverride();
    org.jfree.chart.util.RectangleInsets var5 = var0.getTickLabelInsets();
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    java.awt.Color var1 = java.awt.Color.getColor("8");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-3.5d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Shape var1 = var0.getDownArrow();
//     var0.resizeRange(0.0d);
//     boolean var4 = var0.isPositiveArrowVisible();
//     double var5 = var0.getLowerMargin();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var9 = var7.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     org.jfree.chart.util.Layer var13 = null;
//     java.util.Collection var14 = var10.getDomainMarkers(0, var13);
//     java.awt.Paint var15 = var10.getRangeGridlinePaint();
//     var7.setNoDataMessagePaint(var15);
//     org.jfree.chart.util.Size2D var21 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var32 = var31.getTickMarkOutsideLength();
//     java.awt.Paint var33 = var31.getAxisLinePaint();
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var33};
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var36 = var35.getRootPlot();
//     org.jfree.chart.util.Layer var38 = null;
//     java.util.Collection var39 = var35.getDomainMarkers(0, var38);
//     java.awt.Paint var40 = var35.getRangeGridlinePaint();
//     java.awt.Paint[] var41 = new java.awt.Paint[] { var40};
//     java.awt.Paint[] var42 = null;
//     java.awt.Stroke var43 = null;
//     java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var51 = org.jfree.chart.util.ShapeUtilities.equal(var48, var50);
//     java.awt.Shape[] var52 = new java.awt.Shape[] { var50};
//     org.jfree.chart.plot.DefaultDrawingSupplier var53 = new org.jfree.chart.plot.DefaultDrawingSupplier(var34, var41, var42, var44, var46, var52);
//     java.awt.Shape var54 = var53.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var57 = var56.getTickMarkOutsideLength();
//     boolean var58 = var56.isAxisLineVisible();
//     java.awt.Stroke var59 = var56.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var64 = null;
//     var62.setTickLabelPaint((java.lang.Comparable)10L, var64);
//     var62.setCategoryLabelPositionOffset(0);
//     var62.setAxisLineVisible(true);
//     var62.configure();
//     java.awt.Font var72 = var62.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var74 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var75 = var74.getTickMarkOutsideLength();
//     java.awt.Paint var76 = var74.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var77 = new org.jfree.chart.text.TextFragment("", var72, var76);
//     org.jfree.chart.LegendItem var78 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var54, var59, var76);
//     var25.setStroke(var59);
//     org.jfree.chart.util.RectangleAnchor var80 = var25.getLabelAnchor();
//     java.awt.geom.Rectangle2D var81 = org.jfree.chart.util.RectangleAnchor.createRectangle(var21, 100.0d, (-1.0d), var80);
//     java.awt.geom.Point2D var82 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 84.0d, var81);
//     org.jfree.chart.axis.AxisState var83 = new org.jfree.chart.axis.AxisState();
//     java.util.List var84 = var83.getTicks();
//     org.jfree.chart.text.TextBlock var85 = new org.jfree.chart.text.TextBlock();
//     java.util.List var86 = var85.getLines();
//     var83.setTicks(var86);
//     org.jfree.chart.plot.CategoryPlot var89 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var90 = var89.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var91 = var89.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var92 = var89.getDomainAxisEdge();
//     boolean var93 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var92);
//     var83.moveCursor(100.0d, var92);
//     java.lang.String var95 = var92.toString();
//     org.jfree.chart.axis.AxisSpace var96 = null;
//     org.jfree.chart.axis.AxisSpace var97 = var0.reserveSpace(var6, (org.jfree.chart.plot.Plot)var7, var81, var92, var96);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 4.0d);
    var2.setRange(var5);
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(100.0d, var5);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var6 = var5.getTickMarkOutsideLength();
    java.awt.Paint var7 = var5.getAxisLinePaint();
    java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
    org.jfree.chart.util.Layer var12 = null;
    java.util.Collection var13 = var9.getDomainMarkers(0, var12);
    java.awt.Paint var14 = var9.getRangeGridlinePaint();
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    java.awt.Paint[] var16 = null;
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var24};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var15, var16, var18, var20, var26);
    java.awt.Shape var28 = var27.getNextShape();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var31 = var30.getTickMarkOutsideLength();
    boolean var32 = var30.isAxisLineVisible();
    java.awt.Stroke var33 = var30.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var38 = null;
    var36.setTickLabelPaint((java.lang.Comparable)10L, var38);
    var36.setCategoryLabelPositionOffset(0);
    var36.setAxisLineVisible(true);
    var36.configure();
    java.awt.Font var46 = var36.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var49 = var48.getTickMarkOutsideLength();
    java.awt.Paint var50 = var48.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("", var46, var50);
    org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var28, var33, var50);
    boolean var53 = var52.isShapeVisible();
    org.jfree.chart.util.StandardGradientPaintTransformer var54 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var52.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var54);
    org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var59 = null;
    var57.setTickLabelPaint((java.lang.Comparable)10L, var59);
    var57.setCategoryLabelPositionOffset(0);
    var57.setAxisLineVisible(true);
    var57.configure();
    java.awt.Font var67 = var57.getTickLabelFont((java.lang.Comparable)0.0f);
    var57.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var71 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var57.setCategoryLabelPositions(var71);
    double var73 = var57.getCategoryMargin();
    double var74 = var57.getFixedDimension();
    boolean var75 = var54.equals((java.lang.Object)var57);
    java.lang.String var77 = var57.getCategoryLabelToolTip((java.lang.Comparable)84.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     java.lang.Number[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ChartEntity: tooltip = ", var2);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isInverted();
    var0.setInverted(false);
    java.text.NumberFormat var4 = var0.getNumberFormatOverride();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var6 = var5.getLeftArrow();
    var0.setRightArrow(var6);
    org.jfree.chart.axis.MarkerAxisBand var8 = null;
    var0.setMarkerBand(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var2 = var1.getTickMarkOutsideLength();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var6 = var5.getRootPlot();
//     org.jfree.chart.util.Layer var8 = null;
//     java.util.Collection var9 = var5.getDomainMarkers(0, var8);
//     java.awt.Paint var10 = var5.getRangeGridlinePaint();
//     java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
//     java.awt.Paint[] var12 = null;
//     java.awt.Stroke var13 = null;
//     java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var18, var20);
//     java.awt.Shape[] var22 = new java.awt.Shape[] { var20};
//     org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var11, var12, var14, var16, var22);
//     java.awt.Shape var24 = var23.getNextShape();
//     org.jfree.chart.entity.LegendItemEntity var25 = new org.jfree.chart.entity.LegendItemEntity(var24);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var27 = var26.getRootPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var26.setRenderer(var28);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = var26.getRendererForDataset(var30);
//     org.jfree.chart.plot.DrawingSupplier var32 = var26.getDrawingSupplier();
//     org.jfree.chart.plot.PlotOrientation var33 = var26.getOrientation();
//     boolean var34 = var25.equals((java.lang.Object)var26);
//     
//     // Checks the contract:  equals-hashcode on var5 and var26
//     assertTrue("Contract failed: equals-hashcode on var5 and var26", var5.equals(var26) ? var5.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var5
//     assertTrue("Contract failed: equals-hashcode on var26 and var5", var26.equals(var5) ? var26.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var27
//     assertTrue("Contract failed: equals-hashcode on var6 and var27", var6.equals(var27) ? var6.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var6
//     assertTrue("Contract failed: equals-hashcode on var27 and var6", var27.equals(var6) ? var27.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    java.awt.Stroke var4 = null;
    var0.setOutlineStroke(var4);
    java.util.List var6 = var0.getAnnotations();
    int var7 = var0.getDomainAxisCount();
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var0.getRangeMarkers(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var1 = var0.getBaseItemLabelGenerator();
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var5 = var4.getTickMarkOutsideLength();
//     java.awt.Paint var6 = var4.getAxisLinePaint();
//     java.awt.Paint var7 = var4.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     java.awt.Paint var11 = var9.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var9);
//     boolean var13 = var12.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var16 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var7, var12, 100, 10);
//     var0.setSeriesFillPaint(15, var7);
//     java.awt.Paint var19 = var0.getSeriesItemLabelPaint((-16777216));
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var23 = var22.getRootPlot();
//     java.awt.Paint var24 = var22.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var22);
//     org.jfree.chart.event.ChartProgressListener var26 = null;
//     var25.removeProgressListener(var26);
//     org.jfree.chart.title.LegendTitle var29 = var25.getLegend(100);
//     java.awt.Stroke var30 = var25.getBorderStroke();
//     var0.setSeriesOutlineStroke(100, var30);
//     
//     // Checks the contract:  equals-hashcode on var9 and var22
//     assertTrue("Contract failed: equals-hashcode on var9 and var22", var9.equals(var22) ? var9.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var9
//     assertTrue("Contract failed: equals-hashcode on var22 and var9", var22.equals(var9) ? var22.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var23
//     assertTrue("Contract failed: equals-hashcode on var10 and var23", var10.equals(var23) ? var10.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var10
//     assertTrue("Contract failed: equals-hashcode on var23 and var10", var23.equals(var10) ? var23.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var25
//     assertTrue("Contract failed: equals-hashcode on var12 and var25", var12.equals(var25) ? var12.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var12
//     assertTrue("Contract failed: equals-hashcode on var25 and var12", var25.equals(var12) ? var25.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var3 = var0.getDomainAxisEdge();
//     java.awt.Paint var4 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.DatasetRenderingOrder var5 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var8 = var7.getTickMarkOutsideLength();
//     java.awt.Paint var9 = var7.getAxisLinePaint();
//     java.awt.Paint var10 = var7.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
//     java.awt.Paint var14 = var12.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var12);
//     boolean var16 = var15.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var10, var15, 100, 10);
//     var15.setNotify(true);
//     org.jfree.data.KeyedObjects var22 = new org.jfree.data.KeyedObjects();
//     org.jfree.data.statistics.MeanAndStandardDeviation var26 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
//     java.lang.Number var27 = var26.getStandardDeviation();
//     var22.setObject((java.lang.Comparable)100, (java.lang.Object)var27);
//     java.lang.Object var29 = var22.clone();
//     java.util.List var30 = var22.getKeys();
//     boolean var31 = var15.equals((java.lang.Object)var22);
//     boolean var32 = var5.equals((java.lang.Object)var31);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    var0.clear();
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
    java.awt.Paint var6 = var4.getBackgroundPaint();
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var4);
    var2.setChart(var7);
    org.jfree.chart.plot.Plot var9 = var7.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     boolean var1 = var0.isInverted();
//     var0.setInverted(false);
//     var0.setAutoRangeStickyZero(false);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var13 = var10.getDomainAxisEdge();
//     boolean var14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var13);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var16 = var15.getRootPlot();
//     java.util.List var17 = var15.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var15.getRenderer((-16777216));
//     org.jfree.chart.util.SortOrder var20 = var15.getColumnRenderingOrder();
//     org.jfree.chart.plot.Plot var21 = var15.getParent();
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     java.awt.geom.Rectangle2D var26 = null;
//     var25.setPlotArea(var26);
//     java.awt.geom.Rectangle2D var28 = var25.getPlotArea();
//     org.jfree.chart.ChartRenderingInfo var29 = var25.getOwner();
//     java.awt.geom.Point2D var30 = null;
//     var15.zoomRangeAxes((-12.0d), 0.0d, var25, var30);
//     org.jfree.chart.axis.AxisState var32 = var0.draw(var6, (-3.5d), var8, var9, var13, var25);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = var2.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var4 = new org.jfree.chart.title.LegendGraphic(var0, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    var1.setAxisLineVisible(true);
    org.jfree.chart.util.RectangleInsets var9 = var1.getTickLabelInsets();
    double var10 = var1.getLabelAngle();
    java.lang.String var12 = var1.getCategoryLabelToolTip((java.lang.Comparable)(byte)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var6 = var5.getTickMarkOutsideLength();
    java.awt.Paint var7 = var5.getAxisLinePaint();
    java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
    org.jfree.chart.util.Layer var12 = null;
    java.util.Collection var13 = var9.getDomainMarkers(0, var12);
    java.awt.Paint var14 = var9.getRangeGridlinePaint();
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    java.awt.Paint[] var16 = null;
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var24};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var15, var16, var18, var20, var26);
    java.awt.Shape var28 = var27.getNextShape();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var31 = var30.getTickMarkOutsideLength();
    boolean var32 = var30.isAxisLineVisible();
    java.awt.Stroke var33 = var30.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var38 = null;
    var36.setTickLabelPaint((java.lang.Comparable)10L, var38);
    var36.setCategoryLabelPositionOffset(0);
    var36.setAxisLineVisible(true);
    var36.configure();
    java.awt.Font var46 = var36.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var49 = var48.getTickMarkOutsideLength();
    java.awt.Paint var50 = var48.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("", var46, var50);
    org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var28, var33, var50);
    boolean var53 = var52.isShapeVisible();
    java.text.AttributedString var54 = var52.getAttributedLabel();
    java.awt.Stroke var55 = var52.getLineStroke();
    boolean var56 = var52.isLineVisible();
    boolean var57 = var52.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
    java.util.List var5 = var0.getAnnotations();
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    org.jfree.chart.ChartRenderingInfo var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
    java.awt.geom.Rectangle2D var13 = null;
    var12.setPlotArea(var13);
    java.awt.geom.Point2D var15 = null;
    var0.zoomRangeAxes(1.0d, 0.0d, var12, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var18 = var12.getSubplotInfo((-100));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("-1", var1, var2);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.data.statistics.MeanAndStandardDeviation var4 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 100.0d);
    java.lang.Number var5 = var4.getStandardDeviation();
    var0.setObject((java.lang.Comparable)100, (java.lang.Object)var5);
    java.lang.Object var8 = var0.getObject(15);
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100.0d+ "'", var5.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
    boolean var6 = var0.equals((java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var8 = var0.getRowKey(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(var2);
    org.jfree.chart.ChartRenderingInfo var5 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
    java.awt.geom.Point2D var7 = null;
    var0.zoomRangeAxes(100.0d, var6, var7);
    org.jfree.chart.renderer.category.CategoryItemRendererState var9 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var6);
    var9.setBarWidth((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setCopyright("");
    java.lang.String var3 = var0.getLicenceName();
    java.awt.Image var4 = var0.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.LegendTitle var5 = var4.getLegend();
//     org.jfree.chart.block.BlockFrame var6 = var5.getFrame();
//     org.jfree.chart.LegendItemSource[] var7 = var5.getSources();
//     org.jfree.chart.util.VerticalAlignment var8 = var5.getVerticalAlignment();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     java.awt.Paint var11 = var9.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var12 = var9.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var15 = var13.getLegendItemGraphicLocation();
//     var5.setLegendItemGraphicAnchor(var15);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("");
    java.lang.String var2 = var1.getID();
    java.lang.Object var3 = var1.clone();
    java.lang.String var4 = var1.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + ""+ "'", var4.equals(""));

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    int var3 = java.awt.Color.HSBtoRGB(2.0f, 100.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    java.awt.Color var1 = java.awt.Color.getColor("LegendItemEntity: seriesKey=null, dataset=null");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object var2 = var0.handleGetObject("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    java.lang.Object[][] var3 = var0.getContents();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.getObject("ChartEntity: tooltip = ");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 15);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 4.0d);
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, var5);
    java.lang.Object var7 = null;
    boolean var8 = var4.equals(var7);
    org.jfree.data.Range var11 = org.jfree.data.Range.shift(var4, 1.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var8 = var7.getTickMarkOutsideLength();
//     java.awt.Paint var9 = var7.getAxisLinePaint();
//     java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
//     org.jfree.chart.util.Layer var14 = null;
//     java.util.Collection var15 = var11.getDomainMarkers(0, var14);
//     java.awt.Paint var16 = var11.getRangeGridlinePaint();
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Paint[] var18 = null;
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Stroke var21 = null;
//     java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
//     java.awt.Shape[] var28 = new java.awt.Shape[] { var26};
//     org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var17, var18, var20, var22, var28);
//     java.awt.Shape var30 = var29.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var33 = var32.getTickMarkOutsideLength();
//     boolean var34 = var32.isAxisLineVisible();
//     java.awt.Stroke var35 = var32.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var40 = null;
//     var38.setTickLabelPaint((java.lang.Comparable)10L, var40);
//     var38.setCategoryLabelPositionOffset(0);
//     var38.setAxisLineVisible(true);
//     var38.configure();
//     java.awt.Font var48 = var38.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var51 = var50.getTickMarkOutsideLength();
//     java.awt.Paint var52 = var50.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var48, var52);
//     org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var30, var35, var52);
//     var0.setSeriesPaint(100, var52, true);
//     boolean var57 = var0.getIncludeBaseInRange();
//     var0.setAutoPopulateSeriesOutlinePaint(true);
//     org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var62 = var61.getTickMarkOutsideLength();
//     java.awt.Paint var63 = var61.getAxisLinePaint();
//     java.awt.Font var64 = var61.getTickLabelFont();
//     var0.setBaseItemLabelFont(var64);
//     var0.setAutoPopulateSeriesFillPaint(false);
//     var0.setMaximumBarWidth(0.0d);
//     org.jfree.chart.title.TextTitle var72 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var73 = var72.getID();
//     java.awt.Font var74 = var72.getFont();
//     org.jfree.chart.block.LabelBlock var75 = new org.jfree.chart.block.LabelBlock("", var74);
//     var75.setURLText("PlotOrientation.VERTICAL");
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var79 = var78.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var80 = var78.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var81 = var78.getDomainAxisEdge();
//     boolean var82 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var81);
//     boolean var83 = var75.equals((java.lang.Object)var81);
//     org.jfree.chart.renderer.category.BarRenderer var84 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var86 = var84.lookupSeriesShape(15);
//     var84.setBaseSeriesVisible(true, false);
//     boolean var90 = var75.equals((java.lang.Object)var84);
//     var84.setBaseCreateEntities(true, false);
//     org.jfree.chart.labels.ItemLabelPosition var96 = var84.getPositiveItemLabelPosition(0, (-1));
//     var0.setBasePositiveItemLabelPosition(var96);
//     
//     // Checks the contract:  equals-hashcode on var11 and var78
//     assertTrue("Contract failed: equals-hashcode on var11 and var78", var11.equals(var78) ? var11.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var11
//     assertTrue("Contract failed: equals-hashcode on var78 and var11", var78.equals(var11) ? var78.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var79
//     assertTrue("Contract failed: equals-hashcode on var12 and var79", var12.equals(var79) ? var12.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var12
//     assertTrue("Contract failed: equals-hashcode on var79 and var12", var79.equals(var12) ? var79.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.text.TextBlockAnchor var2 = null;
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.labels.ItemLabelPosition var7 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var4, (-1.0f), 100.0f, var8, 100.0d, 2.0f, 2.0f);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var15 = var13.lookupSeriesShape(15);
//     java.lang.Boolean var17 = null;
//     var13.setSeriesItemLabelsVisible(100, var17);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var21 = var20.getTickMarkOutsideLength();
//     java.awt.Paint var22 = var20.getAxisLinePaint();
//     java.awt.Paint var23 = var20.getTickLabelPaint();
//     double var24 = var20.getCategoryMargin();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var26 = var25.getRootPlot();
//     org.jfree.chart.util.Layer var28 = null;
//     java.util.Collection var29 = var25.getDomainMarkers(0, var28);
//     java.awt.Paint var30 = var25.getRangeGridlinePaint();
//     var20.setPlot((org.jfree.chart.plot.Plot)var25);
//     boolean var32 = var13.equals((java.lang.Object)var20);
//     java.awt.Paint var34 = null;
//     var13.setSeriesItemLabelPaint(0, var34);
//     boolean var36 = var13.getAutoPopulateSeriesFillPaint();
//     boolean var39 = var13.getItemVisible(0, 15);
//     boolean var40 = var8.equals((java.lang.Object)var13);
//     org.jfree.chart.axis.CategoryTick var42 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)100.0d, var1, var2, var8, (-12.0d));
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var49 = null;
//     var47.setTickLabelPaint((java.lang.Comparable)10L, var49);
//     var47.setCategoryLabelPositionOffset(0);
//     var47.setAxisLineVisible(true);
//     var47.configure();
//     java.awt.Font var57 = var47.getTickLabelFont((java.lang.Comparable)0.0f);
//     var47.setTickMarkInsideLength(1.0f);
//     org.jfree.chart.axis.CategoryLabelPositions var61 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
//     var47.setCategoryLabelPositions(var61);
//     org.jfree.chart.axis.CategoryLabelPositions var64 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
//     org.jfree.chart.axis.CategoryLabelPosition var65 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var66 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var64, var65);
//     org.jfree.chart.axis.CategoryLabelPositions var67 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var61, var65);
//     org.jfree.chart.title.TextTitle var70 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var71 = var70.getID();
//     java.awt.Font var72 = var70.getFont();
//     org.jfree.chart.block.LabelBlock var73 = new org.jfree.chart.block.LabelBlock("", var72);
//     var73.setURLText("PlotOrientation.VERTICAL");
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var77 = var76.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var78 = var76.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var79 = var76.getDomainAxisEdge();
//     boolean var80 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var79);
//     boolean var81 = var73.equals((java.lang.Object)var79);
//     org.jfree.chart.util.RectangleEdge var82 = org.jfree.chart.util.RectangleEdge.opposite(var79);
//     org.jfree.chart.axis.CategoryLabelPosition var83 = var61.getLabelPosition(var79);
//     org.jfree.chart.text.TextBlockAnchor var84 = var83.getLabelAnchor();
//     var1.draw(var43, 0.0f, (-1.0f), var84, 2.0f, 1.0f, 100.0d);
//     
//     // Checks the contract:  equals-hashcode on var25 and var76
//     assertTrue("Contract failed: equals-hashcode on var25 and var76", var25.equals(var76) ? var25.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var25
//     assertTrue("Contract failed: equals-hashcode on var76 and var25", var76.equals(var25) ? var76.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var77
//     assertTrue("Contract failed: equals-hashcode on var26 and var77", var26.equals(var77) ? var26.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var26
//     assertTrue("Contract failed: equals-hashcode on var77 and var26", var77.equals(var26) ? var77.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Paint var4 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    boolean var10 = var9.isNotify();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, 100, 10);
    java.awt.Stroke var14 = null;
    var9.setBorderStroke(var14);
    var9.setAntiAlias(true);
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.block.BlockFrame var20 = var19.getFrame();
    org.jfree.chart.event.TitleChangeEvent var21 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var19);
    var9.titleChanged(var21);
    org.jfree.chart.plot.Plot var23 = var9.getPlot();
    int var24 = var9.getSubtitleCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.block.BlockContainer var5 = var4.getItemContainer();
//     java.lang.Object var6 = var5.clone();
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var15 = var14.getTickMarkOutsideLength();
//     java.awt.Paint var16 = var14.getAxisLinePaint();
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var19 = var18.getRootPlot();
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var18.getDomainMarkers(0, var21);
//     java.awt.Paint var23 = var18.getRangeGridlinePaint();
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var23};
//     java.awt.Paint[] var25 = null;
//     java.awt.Stroke var26 = null;
//     java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
//     java.awt.Stroke var28 = null;
//     java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var34 = org.jfree.chart.util.ShapeUtilities.equal(var31, var33);
//     java.awt.Shape[] var35 = new java.awt.Shape[] { var33};
//     org.jfree.chart.plot.DefaultDrawingSupplier var36 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var24, var25, var27, var29, var35);
//     java.awt.Shape var37 = var36.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var40 = var39.getTickMarkOutsideLength();
//     boolean var41 = var39.isAxisLineVisible();
//     java.awt.Stroke var42 = var39.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var47 = null;
//     var45.setTickLabelPaint((java.lang.Comparable)10L, var47);
//     var45.setCategoryLabelPositionOffset(0);
//     var45.setAxisLineVisible(true);
//     var45.configure();
//     java.awt.Font var55 = var45.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var58 = var57.getTickMarkOutsideLength();
//     java.awt.Paint var59 = var57.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var60 = new org.jfree.chart.text.TextFragment("", var55, var59);
//     org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var37, var42, var59);
//     var7.setSeriesPaint(100, var59, true);
//     boolean var64 = var7.getIncludeBaseInRange();
//     var7.setAutoPopulateSeriesOutlinePaint(true);
//     boolean var67 = var7.getIncludeBaseInRange();
//     org.jfree.chart.axis.CategoryAxis var71 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var73 = null;
//     var71.setTickLabelPaint((java.lang.Comparable)10L, var73);
//     var71.setCategoryLabelPositionOffset(0);
//     var71.setAxisLineVisible(true);
//     var71.configure();
//     java.awt.Font var81 = var71.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var83 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var84 = var83.getTickMarkOutsideLength();
//     java.awt.Paint var85 = var83.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var86 = new org.jfree.chart.text.TextFragment("", var81, var85);
//     org.jfree.chart.block.LabelBlock var87 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var81);
//     var7.setBaseItemLabelFont(var81, false);
//     boolean var90 = var5.equals((java.lang.Object)false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var19
//     assertTrue("Contract failed: equals-hashcode on var1 and var19", var1.equals(var19) ? var1.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var1
//     assertTrue("Contract failed: equals-hashcode on var19 and var1", var19.equals(var1) ? var19.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.util.List var2 = var0.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
//     java.util.List var5 = var0.getAnnotations();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var0.setRangeAxis(0, var7);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = null;
//     var12.setPlotArea(var13);
//     java.awt.geom.Point2D var15 = null;
//     var0.zoomRangeAxes(1.0d, 0.0d, var12, var15);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var19 = var18.getRootPlot();
//     java.awt.Paint var20 = var18.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var18);
//     org.jfree.chart.util.Layer var23 = null;
//     java.util.Collection var24 = var18.getRangeMarkers(0, var23);
//     org.jfree.chart.plot.Plot var25 = var18.getRootPlot();
//     boolean var26 = var18.isDomainZoomable();
//     var18.setRangeGridlinesVisible(false);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.util.Size2D var32 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var43 = var42.getTickMarkOutsideLength();
//     java.awt.Paint var44 = var42.getAxisLinePaint();
//     java.awt.Paint[] var45 = new java.awt.Paint[] { var44};
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var47 = var46.getRootPlot();
//     org.jfree.chart.util.Layer var49 = null;
//     java.util.Collection var50 = var46.getDomainMarkers(0, var49);
//     java.awt.Paint var51 = var46.getRangeGridlinePaint();
//     java.awt.Paint[] var52 = new java.awt.Paint[] { var51};
//     java.awt.Paint[] var53 = null;
//     java.awt.Stroke var54 = null;
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
//     java.awt.Stroke var56 = null;
//     java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var59, var61);
//     java.awt.Shape[] var63 = new java.awt.Shape[] { var61};
//     org.jfree.chart.plot.DefaultDrawingSupplier var64 = new org.jfree.chart.plot.DefaultDrawingSupplier(var45, var52, var53, var55, var57, var63);
//     java.awt.Shape var65 = var64.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var68 = var67.getTickMarkOutsideLength();
//     boolean var69 = var67.isAxisLineVisible();
//     java.awt.Stroke var70 = var67.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var73 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var75 = null;
//     var73.setTickLabelPaint((java.lang.Comparable)10L, var75);
//     var73.setCategoryLabelPositionOffset(0);
//     var73.setAxisLineVisible(true);
//     var73.configure();
//     java.awt.Font var83 = var73.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var85 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var86 = var85.getTickMarkOutsideLength();
//     java.awt.Paint var87 = var85.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var88 = new org.jfree.chart.text.TextFragment("", var83, var87);
//     org.jfree.chart.LegendItem var89 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var65, var70, var87);
//     var36.setStroke(var70);
//     org.jfree.chart.util.RectangleAnchor var91 = var36.getLabelAnchor();
//     java.awt.geom.Rectangle2D var92 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 100.0d, (-1.0d), var91);
//     var18.drawBackgroundImage(var29, var92);
//     var12.setPlotArea(var92);
//     
//     // Checks the contract:  equals-hashcode on var0 and var46
//     assertTrue("Contract failed: equals-hashcode on var0 and var46", var0.equals(var46) ? var0.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var0
//     assertTrue("Contract failed: equals-hashcode on var46 and var0", var46.equals(var0) ? var46.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var47
//     assertTrue("Contract failed: equals-hashcode on var1 and var47", var1.equals(var47) ? var1.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var1
//     assertTrue("Contract failed: equals-hashcode on var47 and var1", var47.equals(var1) ? var47.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.util.List var3 = var1.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = var1.getRenderer((-16777216));
//     java.util.List var6 = var1.getAnnotations();
//     boolean var7 = var0.equals((java.lang.Object)var6);
//     org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var11 = var10.getURLText();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var13 = var12.getRootPlot();
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var12.getDomainMarkers(0, var15);
//     java.awt.Paint var17 = var12.getRangeGridlinePaint();
//     var10.setBackgroundPaint(var17);
//     java.awt.Paint var19 = var10.getPaint();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var23 = null;
//     var21.setTickLabelPaint((java.lang.Comparable)10L, var23);
//     var21.setCategoryLabelPositionOffset(0);
//     var21.setAxisLineVisible(true);
//     var21.configure();
//     java.awt.Font var31 = var21.getTickLabelFont((java.lang.Comparable)0.0f);
//     var10.setFont(var31);
//     org.jfree.chart.ui.BasicProjectInfo var38 = new org.jfree.chart.ui.BasicProjectInfo("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", "");
//     var0.add((org.jfree.chart.block.Block)var10, (java.lang.Object)"");
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.text.TextBlockAnchor var2 = null;
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.labels.ItemLabelPosition var7 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var4, (-1.0f), 100.0f, var8, 100.0d, 2.0f, 2.0f);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var15 = var13.lookupSeriesShape(15);
//     java.lang.Boolean var17 = null;
//     var13.setSeriesItemLabelsVisible(100, var17);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var21 = var20.getTickMarkOutsideLength();
//     java.awt.Paint var22 = var20.getAxisLinePaint();
//     java.awt.Paint var23 = var20.getTickLabelPaint();
//     double var24 = var20.getCategoryMargin();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var26 = var25.getRootPlot();
//     org.jfree.chart.util.Layer var28 = null;
//     java.util.Collection var29 = var25.getDomainMarkers(0, var28);
//     java.awt.Paint var30 = var25.getRangeGridlinePaint();
//     var20.setPlot((org.jfree.chart.plot.Plot)var25);
//     boolean var32 = var13.equals((java.lang.Object)var20);
//     java.awt.Paint var34 = null;
//     var13.setSeriesItemLabelPaint(0, var34);
//     boolean var36 = var13.getAutoPopulateSeriesFillPaint();
//     boolean var39 = var13.getItemVisible(0, 15);
//     boolean var40 = var8.equals((java.lang.Object)var13);
//     org.jfree.chart.axis.CategoryTick var42 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)100.0d, var1, var2, var8, (-12.0d));
//     org.jfree.chart.text.TextAnchor var43 = var42.getRotationAnchor();
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var47 = null;
//     var45.setTickLabelPaint((java.lang.Comparable)10L, var47);
//     var45.setCategoryLabelPositionOffset(0);
//     var45.setAxisLineVisible(true);
//     var45.configure();
//     java.awt.Font var55 = var45.getTickLabelFont((java.lang.Comparable)0.0f);
//     var45.setTickMarkInsideLength(1.0f);
//     org.jfree.chart.axis.CategoryLabelPositions var59 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
//     var45.setCategoryLabelPositions(var59);
//     org.jfree.chart.axis.CategoryLabelPositions var62 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
//     org.jfree.chart.axis.CategoryLabelPosition var63 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var64 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var62, var63);
//     org.jfree.chart.axis.CategoryLabelPositions var65 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var59, var63);
//     org.jfree.chart.title.TextTitle var68 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var69 = var68.getID();
//     java.awt.Font var70 = var68.getFont();
//     org.jfree.chart.block.LabelBlock var71 = new org.jfree.chart.block.LabelBlock("", var70);
//     var71.setURLText("PlotOrientation.VERTICAL");
//     org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var75 = var74.getRootPlot();
//     org.jfree.chart.axis.CategoryAxis var76 = var74.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var77 = var74.getDomainAxisEdge();
//     boolean var78 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var77);
//     boolean var79 = var71.equals((java.lang.Object)var77);
//     org.jfree.chart.util.RectangleEdge var80 = org.jfree.chart.util.RectangleEdge.opposite(var77);
//     org.jfree.chart.axis.CategoryLabelPosition var81 = var59.getLabelPosition(var77);
//     boolean var82 = var42.equals((java.lang.Object)var81);
//     
//     // Checks the contract:  equals-hashcode on var25 and var74
//     assertTrue("Contract failed: equals-hashcode on var25 and var74", var25.equals(var74) ? var25.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var25
//     assertTrue("Contract failed: equals-hashcode on var74 and var25", var74.equals(var25) ? var74.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var75
//     assertTrue("Contract failed: equals-hashcode on var26 and var75", var26.equals(var75) ? var26.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var26
//     assertTrue("Contract failed: equals-hashcode on var75 and var26", var75.equals(var26) ? var75.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    java.awt.Paint var3 = var1.getBackgroundPaint();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    boolean var5 = var1.isRangeGridlinesVisible();
    java.awt.Font var6 = var1.getNoDataMessageFont();
    boolean var7 = var1.isDomainZoomable();
    org.jfree.chart.axis.CategoryAnchor var8 = var1.getDomainGridlinePosition();
    org.jfree.chart.LegendItemCollection var9 = var1.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var11 = var9.get((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var6 = var5.getTickMarkOutsideLength();
    java.awt.Paint var7 = var5.getAxisLinePaint();
    java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
    org.jfree.chart.util.Layer var12 = null;
    java.util.Collection var13 = var9.getDomainMarkers(0, var12);
    java.awt.Paint var14 = var9.getRangeGridlinePaint();
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    java.awt.Paint[] var16 = null;
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
    java.awt.Shape[] var26 = new java.awt.Shape[] { var24};
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var15, var16, var18, var20, var26);
    java.awt.Shape var28 = var27.getNextShape();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var31 = var30.getTickMarkOutsideLength();
    boolean var32 = var30.isAxisLineVisible();
    java.awt.Stroke var33 = var30.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var38 = null;
    var36.setTickLabelPaint((java.lang.Comparable)10L, var38);
    var36.setCategoryLabelPositionOffset(0);
    var36.setAxisLineVisible(true);
    var36.configure();
    java.awt.Font var46 = var36.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var49 = var48.getTickMarkOutsideLength();
    java.awt.Paint var50 = var48.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("", var46, var50);
    org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var28, var33, var50);
    boolean var53 = var52.isShapeVisible();
    int var54 = var52.getDatasetIndex();
    java.awt.Shape var55 = var52.getShape();
    boolean var56 = var52.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "hi!", "hi!");
    java.awt.Shape var5 = var4.getArea();
    var4.setURLText("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    boolean var3 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var5 = var4.getRootPlot();
    java.util.List var6 = var4.getCategories();
    org.jfree.chart.util.RectangleInsets var7 = var4.getInsets();
    java.awt.Stroke var8 = null;
    var4.setOutlineStroke(var8);
    org.jfree.data.category.CategoryDataset var11 = var4.getDataset(0);
    org.jfree.chart.util.RectangleEdge var13 = var4.getDomainAxisEdge(0);
    boolean var14 = var0.hasListener((java.util.EventListener)var4);
    java.awt.Paint var16 = var0.getSeriesPaint(10);
    var0.removeAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
    boolean var6 = var0.equals((java.lang.Object)var5);
    int var7 = var0.getColumnCount();
    int var9 = var0.getColumnIndex((java.lang.Comparable)(byte)10);
    java.lang.Object var12 = var0.getObject((java.lang.Comparable)"PlotOrientation.VERTICAL", (java.lang.Comparable)"ChartEntity: tooltip = ");
    var0.removeObject((java.lang.Comparable)(short)(-1), (java.lang.Comparable)84.0d);
    int var17 = var0.getRowIndex((java.lang.Comparable)(short)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
    java.util.List var5 = var0.getAnnotations();
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    org.jfree.chart.ChartRenderingInfo var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
    java.awt.geom.Rectangle2D var13 = null;
    var12.setPlotArea(var13);
    java.awt.geom.Point2D var15 = null;
    var0.zoomRangeAxes(1.0d, 0.0d, var12, var15);
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var20 = var18.lookupSeriesShape(15);
    var0.setRenderer(15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var24 = var18.getLegendItem((-1), (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var6 = null;
//     var4.setTickLabelPaint((java.lang.Comparable)10L, var6);
//     var4.setCategoryLabelPositionOffset(0);
//     var4.setAxisLineVisible(true);
//     var4.configure();
//     java.awt.Font var14 = var4.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var17 = var16.getTickMarkOutsideLength();
//     java.awt.Paint var18 = var16.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("", var14, var18);
//     org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var14);
//     java.awt.Font var21 = var20.getFont();
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var29 = null;
//     var27.setTickLabelPaint((java.lang.Comparable)10L, var29);
//     var27.setCategoryLabelPositionOffset(0);
//     var27.setAxisLineVisible(true);
//     var27.configure();
//     java.awt.Font var37 = var27.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var40 = var39.getTickMarkOutsideLength();
//     java.awt.Paint var41 = var39.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("", var37, var41);
//     org.jfree.chart.block.LabelBlock var43 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var37);
//     org.jfree.chart.text.TextFragment var44 = new org.jfree.chart.text.TextFragment("", var37);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var47 = var45.getRangeAxisForDataset(0);
//     java.awt.Paint var48 = var45.getBackgroundPaint();
//     org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("", var37, var48);
//     org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("0,0,2,-2,2,2,2,2", var21, var48);
//     
//     // Checks the contract:  equals-hashcode on var20 and var43
//     assertTrue("Contract failed: equals-hashcode on var20 and var43", var20.equals(var43) ? var20.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var20
//     assertTrue("Contract failed: equals-hashcode on var43 and var20", var43.equals(var20) ? var43.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var6 = var5.getTickMarkOutsideLength();
//     java.awt.Paint var7 = var5.getAxisLinePaint();
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     org.jfree.chart.util.Layer var12 = null;
//     java.util.Collection var13 = var9.getDomainMarkers(0, var12);
//     java.awt.Paint var14 = var9.getRangeGridlinePaint();
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Paint[] var16 = null;
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
//     java.awt.Shape[] var26 = new java.awt.Shape[] { var24};
//     org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var15, var16, var18, var20, var26);
//     java.awt.Shape var28 = var27.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var31 = var30.getTickMarkOutsideLength();
//     boolean var32 = var30.isAxisLineVisible();
//     java.awt.Stroke var33 = var30.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var38 = null;
//     var36.setTickLabelPaint((java.lang.Comparable)10L, var38);
//     var36.setCategoryLabelPositionOffset(0);
//     var36.setAxisLineVisible(true);
//     var36.configure();
//     java.awt.Font var46 = var36.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var49 = var48.getTickMarkOutsideLength();
//     java.awt.Paint var50 = var48.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("", var46, var50);
//     org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var28, var33, var50);
//     java.lang.Comparable var53 = var52.getSeriesKey();
//     org.jfree.chart.util.StandardGradientPaintTransformer var54 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var52.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var54);
//     java.awt.GradientPaint var56 = null;
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Shape var58 = var57.getLeftArrow();
//     java.awt.GradientPaint var59 = var54.transform(var56, var58);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    java.awt.Stroke var4 = null;
    var0.setOutlineStroke(var4);
    org.jfree.data.category.CategoryDataset var7 = var0.getDataset(0);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    boolean var9 = var8.getAutoRangeIncludesZero();
    org.jfree.chart.axis.MarkerAxisBand var10 = null;
    var8.setMarkerBand(var10);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var14 = var13.getRootPlot();
    java.awt.Paint var15 = var13.getBackgroundPaint();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var13);
    float var17 = var13.getBackgroundAlpha();
    org.jfree.chart.plot.DatasetRenderingOrder var18 = var13.getDatasetRenderingOrder();
    org.jfree.chart.axis.AxisLocation var20 = null;
    var13.setRangeAxisLocation(15, var20, false);
    var8.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var13);
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var8};
    var0.setRangeAxes(var24);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var28 = var27.getRootPlot();
    java.awt.Paint var29 = var27.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var30 = var27.getRowRenderingOrder();
    org.jfree.chart.plot.Plot var31 = var27.getParent();
    org.jfree.chart.LegendItemCollection var32 = var27.getFixedLegendItems();
    float var33 = var27.getForegroundAlpha();
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var36 = var35.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var37 = var35.getDomainAxis();
    int var38 = var35.getBackgroundImageAlignment();
    var35.setRangeCrosshairVisible(true);
    org.jfree.chart.util.Layer var42 = null;
    java.util.Collection var43 = var35.getDomainMarkers(10, var42);
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var35);
    org.jfree.data.general.DatasetGroup var45 = var35.getDatasetGroup();
    boolean var46 = var27.equals((java.lang.Object)var35);
    org.jfree.chart.axis.AxisLocation var47 = var35.getRangeAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-1), var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var4 = var3.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var7 = var6.getTickMarkOutsideLength();
//     boolean var8 = var6.isAxisLineVisible();
//     java.awt.Stroke var9 = var6.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var11 = var10.getRootPlot();
//     java.util.List var12 = var10.getCategories();
//     org.jfree.chart.util.RectangleInsets var13 = var10.getInsets();
//     double var15 = var13.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder(var4, var9, var13);
//     var1.setPaint(var4);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var19 = var18.getRootPlot();
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var18.getDomainMarkers(0, var21);
//     java.awt.Paint var23 = var18.getRangeGridlinePaint();
//     var1.setLabelPaint(var23);
//     
//     // Checks the contract:  equals-hashcode on var10 and var18
//     assertTrue("Contract failed: equals-hashcode on var10 and var18", var10.equals(var18) ? var10.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var10
//     assertTrue("Contract failed: equals-hashcode on var18 and var10", var18.equals(var10) ? var18.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var19
//     assertTrue("Contract failed: equals-hashcode on var11 and var19", var11.equals(var19) ? var11.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var11
//     assertTrue("Contract failed: equals-hashcode on var19 and var11", var19.equals(var11) ? var19.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
    boolean var6 = var0.equals((java.lang.Object)var5);
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.Comparable var9 = null;
    var0.addObject((java.lang.Object)100.0d, var9, (java.lang.Comparable)(byte)10);
    java.lang.Comparable var13 = var0.getRowKey(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "hi!", "hi!");
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var6, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var1, var6);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-9.5d), (-9.5d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.LegendTitle var5 = var4.getLegend();
//     org.jfree.chart.block.BlockFrame var6 = var5.getFrame();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.Size2D var10 = new org.jfree.chart.util.Size2D(8.0d, 0.2d);
//     org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var21 = var20.getTickMarkOutsideLength();
//     java.awt.Paint var22 = var20.getAxisLinePaint();
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var25 = var24.getRootPlot();
//     org.jfree.chart.util.Layer var27 = null;
//     java.util.Collection var28 = var24.getDomainMarkers(0, var27);
//     java.awt.Paint var29 = var24.getRangeGridlinePaint();
//     java.awt.Paint[] var30 = new java.awt.Paint[] { var29};
//     java.awt.Paint[] var31 = null;
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Stroke var34 = null;
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var37, var39);
//     java.awt.Shape[] var41 = new java.awt.Shape[] { var39};
//     org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier(var23, var30, var31, var33, var35, var41);
//     java.awt.Shape var43 = var42.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var46 = var45.getTickMarkOutsideLength();
//     boolean var47 = var45.isAxisLineVisible();
//     java.awt.Stroke var48 = var45.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var53 = null;
//     var51.setTickLabelPaint((java.lang.Comparable)10L, var53);
//     var51.setCategoryLabelPositionOffset(0);
//     var51.setAxisLineVisible(true);
//     var51.configure();
//     java.awt.Font var61 = var51.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var64 = var63.getTickMarkOutsideLength();
//     java.awt.Paint var65 = var63.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var66 = new org.jfree.chart.text.TextFragment("", var61, var65);
//     org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var43, var48, var65);
//     var14.setStroke(var48);
//     org.jfree.chart.util.RectangleAnchor var69 = var14.getLabelAnchor();
//     java.awt.geom.Rectangle2D var70 = org.jfree.chart.util.RectangleAnchor.createRectangle(var10, 100.0d, (-1.0d), var69);
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var72 = var71.getRootPlot();
//     java.util.List var73 = var71.getCategories();
//     org.jfree.chart.util.RectangleInsets var74 = var71.getInsets();
//     java.awt.Stroke var75 = null;
//     var71.setOutlineStroke(var75);
//     org.jfree.data.category.CategoryDataset var78 = var71.getDataset(0);
//     org.jfree.chart.util.RectangleEdge var80 = var71.getDomainAxisEdge(0);
//     boolean var81 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var80);
//     boolean var82 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var80);
//     double var83 = org.jfree.chart.util.RectangleEdge.coordinate(var70, var80);
//     var5.draw(var7, var70);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.lang.Object var5 = null;
//     boolean var6 = var4.equals(var5);
//     org.jfree.chart.util.RectangleInsets var7 = var4.getLegendItemGraphicPadding();
//     java.lang.String var8 = var4.getID();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var10 = var9.getRootPlot();
//     java.awt.Paint var11 = var9.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var12 = var9.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     java.awt.Font var14 = var13.getItemFont();
//     org.jfree.chart.block.BlockContainer var15 = var13.getItemContainer();
//     java.util.List var16 = var15.getBlocks();
//     var4.setWrapper(var15);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var2 = var1.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var5 = var4.getTickMarkOutsideLength();
//     boolean var6 = var4.isAxisLineVisible();
//     java.awt.Stroke var7 = var4.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
//     java.util.List var10 = var8.getCategories();
//     org.jfree.chart.util.RectangleInsets var11 = var8.getInsets();
//     double var13 = var11.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var14 = new org.jfree.chart.block.LineBorder(var2, var7, var11);
//     java.awt.Stroke var15 = var14.getStroke();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var17 = var16.getRootPlot();
//     java.awt.Paint var18 = var16.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var19 = var16.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
//     java.awt.Font var21 = var20.getItemFont();
//     org.jfree.chart.block.BlockContainer var22 = var20.getItemContainer();
//     java.util.List var23 = var22.getBlocks();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     boolean var26 = var25.getAutoRangeIncludesZero();
//     org.jfree.chart.axis.MarkerAxisBand var27 = null;
//     var25.setMarkerBand(var27);
//     var25.setLowerMargin(0.2d);
//     org.jfree.data.Range var33 = new org.jfree.data.Range(0.0d, 4.0d);
//     org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var33, 0.0d);
//     var25.setRangeWithMargins(var33);
//     org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(var33, 0.2d);
//     org.jfree.chart.block.RectangleConstraint var39 = var38.toUnconstrainedWidth();
//     org.jfree.chart.util.Size2D var40 = var22.arrange(var24, var38);
//     org.jfree.data.Range var41 = null;
//     org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint(var41, 10.0d);
//     boolean var44 = var40.equals((java.lang.Object)var43);
//     boolean var45 = var14.equals((java.lang.Object)var40);
//     
//     // Checks the contract:  equals-hashcode on var8 and var16
//     assertTrue("Contract failed: equals-hashcode on var8 and var16", var8.equals(var16) ? var8.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var8
//     assertTrue("Contract failed: equals-hashcode on var16 and var8", var16.equals(var8) ? var16.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var17
//     assertTrue("Contract failed: equals-hashcode on var9 and var17", var9.equals(var17) ? var9.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var9
//     assertTrue("Contract failed: equals-hashcode on var17 and var9", var17.equals(var9) ? var17.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var3 = var2.getID();
//     java.awt.Font var4 = var2.getFont();
//     org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("", var4);
//     var5.setURLText("PlotOrientation.VERTICAL");
//     java.awt.Paint var8 = var5.getPaint();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.Range var10 = null;
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(var10, 10.0d);
//     java.lang.String var13 = var12.toString();
//     org.jfree.data.Range var16 = new org.jfree.data.Range(0.0d, 4.0d);
//     org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 0.0d);
//     org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var16, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var21 = var12.toRangeHeight(var20);
//     org.jfree.chart.block.RectangleConstraint var22 = var21.toUnconstrainedWidth();
//     org.jfree.chart.util.Size2D var23 = var5.arrange(var9, var22);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
//     java.awt.Paint var3 = var1.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.LegendTitle var5 = var4.getLegend();
//     org.jfree.chart.block.BlockFrame var6 = var5.getFrame();
//     org.jfree.chart.LegendItemSource[] var7 = var5.getSources();
//     org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var10 = var9.getLabel();
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var19 = var18.getTickMarkOutsideLength();
//     java.awt.Paint var20 = var18.getAxisLinePaint();
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var23 = var22.getRootPlot();
//     org.jfree.chart.util.Layer var25 = null;
//     java.util.Collection var26 = var22.getDomainMarkers(0, var25);
//     java.awt.Paint var27 = var22.getRangeGridlinePaint();
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     java.awt.Paint[] var29 = null;
//     java.awt.Stroke var30 = null;
//     java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var35, var37);
//     java.awt.Shape[] var39 = new java.awt.Shape[] { var37};
//     org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var28, var29, var31, var33, var39);
//     java.awt.Shape var41 = var40.getNextShape();
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var44 = var43.getTickMarkOutsideLength();
//     boolean var45 = var43.isAxisLineVisible();
//     java.awt.Stroke var46 = var43.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var51 = null;
//     var49.setTickLabelPaint((java.lang.Comparable)10L, var51);
//     var49.setCategoryLabelPositionOffset(0);
//     var49.setAxisLineVisible(true);
//     var49.configure();
//     java.awt.Font var59 = var49.getTickLabelFont((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var62 = var61.getTickMarkOutsideLength();
//     java.awt.Paint var63 = var61.getAxisLinePaint();
//     org.jfree.chart.text.TextFragment var64 = new org.jfree.chart.text.TextFragment("", var59, var63);
//     org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var41, var46, var63);
//     var12.setStroke(var46);
//     org.jfree.chart.util.RectangleAnchor var67 = var12.getLabelAnchor();
//     var9.setLabelAnchor(var67);
//     var5.setLegendItemGraphicAnchor(var67);
//     
//     // Checks the contract:  equals-hashcode on var1 and var22
//     assertTrue("Contract failed: equals-hashcode on var1 and var22", var1.equals(var22) ? var1.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var1
//     assertTrue("Contract failed: equals-hashcode on var22 and var1", var22.equals(var1) ? var22.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var23
//     assertTrue("Contract failed: equals-hashcode on var2 and var23", var2.equals(var23) ? var2.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var2
//     assertTrue("Contract failed: equals-hashcode on var23 and var2", var23.equals(var2) ? var23.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.event.MarkerChangeEvent var3 = null;
//     var0.markerChanged(var3);
//     var0.zoom(1.0d);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var3 = var0.getDomainAxisEdge();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var6 = var5.getDownArrow();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.String var10 = var8.valueToString(100.0d);
    var5.setTickUnit(var8);
    var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var5);
    int var13 = var0.getDomainAxisCount();
    int var14 = var0.getBackgroundImageAlignment();
    org.jfree.chart.axis.CategoryAxis var15 = var0.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "100"+ "'", var10.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isInverted();
    var0.setInverted(false);
    java.text.NumberFormat var4 = var0.getNumberFormatOverride();
    double var5 = var0.getLowerBound();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
    var0.setUpArrow(var7);
    java.awt.Paint var12 = var0.getTickMarkPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var3 = var2.getID();
    java.awt.Font var4 = var2.getFont();
    org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("", var4);
    var5.setURLText("PlotOrientation.VERTICAL");
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var9 = var8.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var11 = var8.getDomainAxisEdge();
    boolean var12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var11);
    boolean var13 = var5.equals((java.lang.Object)var11);
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var16 = var14.lookupSeriesShape(15);
    var14.setBaseSeriesVisible(true, false);
    boolean var20 = var5.equals((java.lang.Object)var14);
    org.jfree.chart.labels.ItemLabelPosition var21 = null;
    var14.setPositiveItemLabelPositionFallback(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    var1.setAxisLineVisible(true);
    var1.configure();
    java.awt.Font var11 = var1.getTickLabelFont((java.lang.Comparable)0.0f);
    var1.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var15 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var1.setCategoryLabelPositions(var15);
    org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPosition var19 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var18, var19);
    org.jfree.chart.axis.CategoryLabelPositions var21 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var15, var19);
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var25 = null;
    var23.setTickLabelPaint((java.lang.Comparable)10L, var25);
    var23.setCategoryLabelPositionOffset(0);
    var23.setAxisLineVisible(true);
    var23.configure();
    java.awt.Font var33 = var23.getTickLabelFont((java.lang.Comparable)0.0f);
    var23.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var37 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var23.setCategoryLabelPositions(var37);
    org.jfree.chart.axis.CategoryLabelPositions var40 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPosition var41 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var42 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var40, var41);
    org.jfree.chart.axis.CategoryLabelPositions var43 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var37, var41);
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var47 = null;
    var45.setTickLabelPaint((java.lang.Comparable)10L, var47);
    var45.setCategoryLabelPositionOffset(0);
    var45.setAxisLineVisible(true);
    var45.configure();
    java.awt.Font var55 = var45.getTickLabelFont((java.lang.Comparable)0.0f);
    var45.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var59 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var45.setCategoryLabelPositions(var59);
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var62 = var61.getRootPlot();
    java.util.List var63 = var61.getCategories();
    org.jfree.chart.util.RectangleInsets var64 = var61.getInsets();
    java.awt.Stroke var65 = null;
    var61.setOutlineStroke(var65);
    org.jfree.data.category.CategoryDataset var68 = var61.getDataset(0);
    org.jfree.chart.util.RectangleEdge var70 = var61.getDomainAxisEdge(0);
    org.jfree.chart.axis.CategoryLabelPosition var71 = var59.getLabelPosition(var70);
    org.jfree.chart.axis.CategoryAxis var73 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var75 = null;
    var73.setTickLabelPaint((java.lang.Comparable)10L, var75);
    var73.setCategoryLabelPositionOffset(0);
    var73.setAxisLineVisible(true);
    var73.configure();
    java.awt.Font var83 = var73.getTickLabelFont((java.lang.Comparable)0.0f);
    var73.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.CategoryLabelPositions var87 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    var73.setCategoryLabelPositions(var87);
    org.jfree.chart.axis.CategoryLabelPositions var90 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPosition var91 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var92 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var90, var91);
    org.jfree.chart.axis.CategoryLabelPositions var93 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var87, var91);
    org.jfree.chart.text.TextAnchor var94 = var91.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var95 = new org.jfree.chart.axis.CategoryLabelPositions(var19, var41, var71, var91);
    double var96 = var91.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var8 = var7.getTickMarkOutsideLength();
    java.awt.Paint var9 = var7.getAxisLinePaint();
    java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var11.getDomainMarkers(0, var14);
    java.awt.Paint var16 = var11.getRangeGridlinePaint();
    java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
    java.awt.Paint[] var18 = null;
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
    java.awt.Shape[] var28 = new java.awt.Shape[] { var26};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var17, var18, var20, var22, var28);
    java.awt.Shape var30 = var29.getNextShape();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var33 = var32.getTickMarkOutsideLength();
    boolean var34 = var32.isAxisLineVisible();
    java.awt.Stroke var35 = var32.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var40 = null;
    var38.setTickLabelPaint((java.lang.Comparable)10L, var40);
    var38.setCategoryLabelPositionOffset(0);
    var38.setAxisLineVisible(true);
    var38.configure();
    java.awt.Font var48 = var38.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var51 = var50.getTickMarkOutsideLength();
    java.awt.Paint var52 = var50.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var48, var52);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var30, var35, var52);
    var0.setSeriesPaint(100, var52, true);
    boolean var57 = var0.getIncludeBaseInRange();
    var0.setAutoPopulateSeriesOutlinePaint(true);
    boolean var60 = var0.getAutoPopulateSeriesFillPaint();
    var0.setAutoPopulateSeriesStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getMeanValue(100, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis();
    int var4 = var1.getBackgroundImageAlignment();
    var1.setRangeCrosshairVisible(true);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var1.getDomainMarkers(10, var8);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot)var1);
    boolean var11 = var1.isDomainGridlinesVisible();
    var1.setRangeGridlinesVisible(false);
    var1.mapDatasetToDomainAxis(100, 10);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var21 = var20.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var24 = var23.getTickMarkOutsideLength();
    boolean var25 = var23.isAxisLineVisible();
    java.awt.Stroke var26 = var23.getTickMarkStroke();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var28 = var27.getRootPlot();
    java.util.List var29 = var27.getCategories();
    org.jfree.chart.util.RectangleInsets var30 = var27.getInsets();
    double var32 = var30.calculateBottomInset((-1.0d));
    org.jfree.chart.block.LineBorder var33 = new org.jfree.chart.block.LineBorder(var21, var26, var30);
    var18.setPaint(var21);
    org.jfree.chart.util.Layer var35 = null;
    var1.addRangeMarker((org.jfree.chart.plot.Marker)var18, var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4.0d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    var0.clear();
    java.awt.Image var5 = null;
    org.jfree.chart.ui.ProjectInfo var9 = new org.jfree.chart.ui.ProjectInfo("100", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "hi!", var5, "", "hi!", "PlotOrientation.VERTICAL");
    boolean var10 = var0.equals((java.lang.Object)var5);
    var0.clear();
    org.jfree.chart.block.FlowArrangement var12 = new org.jfree.chart.block.FlowArrangement();
    float[] var19 = new float[] { 100.0f, 0.0f, (-1.0f)};
    float[] var20 = java.awt.Color.RGBtoHSB(0, 1, (-16777216), var19);
    boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var12, (java.lang.Object)var20);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var23 = var22.getRootPlot();
    java.awt.Paint var24 = var22.getBackgroundPaint();
    org.jfree.chart.util.SortOrder var25 = var22.getRowRenderingOrder();
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    java.awt.Font var27 = var26.getItemFont();
    org.jfree.chart.block.BlockContainer var28 = var26.getItemContainer();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var31 = var30.getTickMarkOutsideLength();
    java.awt.Paint var32 = var30.getAxisLinePaint();
    java.awt.Paint var33 = var30.getTickLabelPaint();
    var12.add((org.jfree.chart.block.Block)var28, (java.lang.Object)var30);
    var28.clear();
    java.lang.Object var36 = var28.clone();
    java.awt.Graphics2D var37 = null;
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
    boolean var39 = var38.getAutoRangeIncludesZero();
    org.jfree.chart.axis.MarkerAxisBand var40 = null;
    var38.setMarkerBand(var40);
    var38.setLowerMargin(0.2d);
    org.jfree.data.Range var46 = new org.jfree.data.Range(0.0d, 4.0d);
    org.jfree.data.Range var48 = org.jfree.data.Range.expandToInclude(var46, 0.0d);
    var38.setRangeWithMargins(var46);
    org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(var46, 0.2d);
    org.jfree.chart.block.RectangleConstraint var52 = var51.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var53 = var51.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var54 = var0.arrange(var28, var37, var51);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     var0.clearAnnotations();
//     double var3 = var0.getAnchorValue();
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var7 = var6.getTickMarkOutsideLength();
//     java.awt.Paint var8 = var6.getAxisLinePaint();
//     java.awt.Paint var9 = var6.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
//     java.awt.Paint var13 = var11.getBackgroundPaint();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var11);
//     boolean var15 = var14.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var9, var14, 100, 10);
//     java.awt.Stroke var19 = null;
//     var14.setBorderStroke(var19);
//     org.jfree.chart.event.ChartProgressListener var21 = null;
//     var14.addProgressListener(var21);
//     java.awt.Image var23 = null;
//     var14.setBackgroundImage(var23);
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.Plot var3 = var0.getParent();
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = var0.getRendererForDataset(var4);
//     boolean var6 = var0.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var8 = var7.getRootPlot();
//     java.util.List var9 = var7.getCategories();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var7.getRenderer((-16777216));
//     org.jfree.chart.util.SortOrder var12 = var7.getColumnRenderingOrder();
//     var0.setColumnRenderingOrder(var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(var2);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = var0.getRendererForDataset(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
//     org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis(0);
//     var0.zoom(0.0d);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var5 = var4.getTickMarkOutsideLength();
    boolean var6 = var4.isAxisLineVisible();
    var0.setDomainAxis(10, var4);
    org.jfree.chart.block.LineBorder var8 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var9 = var8.getInsets();
    java.awt.Paint var10 = var8.getPaint();
    var0.setBackgroundPaint(var10);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var20 = var19.getTickMarkOutsideLength();
    java.awt.Paint var21 = var19.getAxisLinePaint();
    java.awt.Paint[] var22 = new java.awt.Paint[] { var21};
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var24 = var23.getRootPlot();
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var23.getDomainMarkers(0, var26);
    java.awt.Paint var28 = var23.getRangeGridlinePaint();
    java.awt.Paint[] var29 = new java.awt.Paint[] { var28};
    java.awt.Paint[] var30 = null;
    java.awt.Stroke var31 = null;
    java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
    java.awt.Stroke var33 = null;
    java.awt.Stroke[] var34 = new java.awt.Stroke[] { var33};
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var36, var38);
    java.awt.Shape[] var40 = new java.awt.Shape[] { var38};
    org.jfree.chart.plot.DefaultDrawingSupplier var41 = new org.jfree.chart.plot.DefaultDrawingSupplier(var22, var29, var30, var32, var34, var40);
    java.awt.Shape var42 = var41.getNextShape();
    org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var45 = var44.getTickMarkOutsideLength();
    boolean var46 = var44.isAxisLineVisible();
    java.awt.Stroke var47 = var44.getTickMarkStroke();
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var52 = null;
    var50.setTickLabelPaint((java.lang.Comparable)10L, var52);
    var50.setCategoryLabelPositionOffset(0);
    var50.setAxisLineVisible(true);
    var50.configure();
    java.awt.Font var60 = var50.getTickLabelFont((java.lang.Comparable)0.0f);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var63 = var62.getTickMarkOutsideLength();
    java.awt.Paint var64 = var62.getAxisLinePaint();
    org.jfree.chart.text.TextFragment var65 = new org.jfree.chart.text.TextFragment("", var60, var64);
    org.jfree.chart.LegendItem var66 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "hi!", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull", var42, var47, var64);
    var12.setSeriesPaint(100, var64, true);
    var12.setAutoPopulateSeriesStroke(false);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    boolean var72 = var12.getAutoPopulateSeriesOutlineStroke();
    java.awt.Font var74 = var12.getSeriesItemLabelFont(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 1.0f);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var2 = var1.getTickMarkOutsideLength();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Font var4 = var1.getTickLabelFont();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var7 = var6.getRootPlot();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.event.ChartProgressListener var10 = null;
    var9.removeProgressListener(var10);
    org.jfree.chart.title.LegendTitle var13 = var9.getLegend(100);
    java.awt.Stroke var14 = var9.getBorderStroke();
    var1.setAxisLineStroke(var14);
    org.jfree.chart.axis.CategoryLabelPositions var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    java.util.List var2 = var0.getCategories();
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer((-16777216));
    java.util.List var5 = var0.getAnnotations();
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    org.jfree.chart.ChartRenderingInfo var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
    java.awt.geom.Rectangle2D var13 = null;
    var12.setPlotArea(var13);
    java.awt.geom.Point2D var15 = null;
    var0.zoomRangeAxes(1.0d, 0.0d, var12, var15);
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var20 = var18.lookupSeriesShape(15);
    var0.setRenderer(15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var22 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    var18.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var22);
    var18.setMinimumBarLength((-3.5d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", var1, var2, var3);
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairLockedOnData(true);
//     var0.setRangeCrosshairValue(0.0d, true);
//     float var6 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     float var9 = var8.getTickMarkOutsideLength();
//     java.awt.Paint var10 = var8.getAxisLinePaint();
//     java.awt.Paint var11 = var8.getTickLabelPaint();
//     double var12 = var8.getCategoryMargin();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var14 = var13.getRootPlot();
//     org.jfree.chart.util.Layer var16 = null;
//     java.util.Collection var17 = var13.getDomainMarkers(0, var16);
//     java.awt.Paint var18 = var13.getRangeGridlinePaint();
//     var8.setPlot((org.jfree.chart.plot.Plot)var13);
//     org.jfree.data.general.Dataset var20 = null;
//     org.jfree.data.general.DatasetChangeEvent var21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var8, var20);
//     var0.datasetChanged(var21);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.ProjectInfo var1 = new org.jfree.chart.ui.ProjectInfo();
    var0.addLibrary((org.jfree.chart.ui.Library)var1);
    java.awt.Image var3 = null;
    var1.setLogo(var3);
    java.awt.Image var5 = null;
    var1.setLogo(var5);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var3 = null;
    var1.setTickLabelPaint((java.lang.Comparable)10L, var3);
    var1.setCategoryLabelPositionOffset(0);
    boolean var7 = var1.isTickLabelsVisible();
    var1.setMaximumCategoryLabelLines((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var3 = var2.getRootPlot();
//     java.awt.Paint var4 = var2.getBackgroundPaint();
//     var1.setPaint(var4);
//     org.jfree.chart.util.RectangleInsets var6 = var1.getPadding();
//     org.jfree.chart.event.TitleChangeEvent var7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = new org.jfree.chart.util.Size2D();
//     var9.setHeight(0.05d);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Plot var15 = var14.getRootPlot();
//     java.awt.Paint var16 = var14.getBackgroundPaint();
//     org.jfree.chart.util.SortOrder var17 = var14.getRowRenderingOrder();
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     java.awt.Paint var19 = var18.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var20 = var18.getLegendItemGraphicLocation();
//     java.lang.String var21 = var20.toString();
//     java.awt.geom.Rectangle2D var22 = org.jfree.chart.util.RectangleAnchor.createRectangle(var9, (-3.5d), 104.0d, var20);
//     var1.draw(var8, var22);
//     
//     // Checks the contract:  equals-hashcode on var2 and var14
//     assertTrue("Contract failed: equals-hashcode on var2 and var14", var2.equals(var14) ? var2.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var2
//     assertTrue("Contract failed: equals-hashcode on var14 and var2", var14.equals(var2) ? var14.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.block.BorderArrangement var1 = new org.jfree.chart.block.BorderArrangement();
    var1.clear();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.block.FlowArrangement var8 = new org.jfree.chart.block.FlowArrangement(var4, var5, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var1, (org.jfree.chart.block.Arrangement)var8);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var13 = var12.getID();
    java.awt.Font var14 = var12.getFont();
    org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("", var14);
    var15.setWidth(1.0d);
    java.lang.Object var18 = null;
    var1.add((org.jfree.chart.block.Block)var15, var18);
    org.jfree.chart.LegendItemSource var20 = null;
    org.jfree.chart.block.BorderArrangement var21 = new org.jfree.chart.block.BorderArrangement();
    var21.clear();
    org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var21);
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.FlowArrangement var28 = new org.jfree.chart.block.FlowArrangement(var24, var25, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var20, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.util.RectangleInsets var30 = var29.getMargin();
    org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Plot var34 = var33.getRootPlot();
    java.awt.Paint var35 = var33.getBackgroundPaint();
    var32.setPaint(var35);
    java.awt.Font var37 = var32.getFont();
    java.awt.Paint var38 = var32.getBackgroundPaint();
    java.awt.Font var39 = var32.getFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.chart.block.Block)var29, (java.lang.Object)var32);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var4 = null;
//     var2.setTickLabelPaint((java.lang.Comparable)10L, var4);
//     var2.setCategoryLabelPositionOffset(0);
//     var2.setAxisLineVisible(true);
//     var2.configure();
//     java.awt.Font var12 = var2.getTickLabelFont((java.lang.Comparable)0.0f);
//     java.lang.String var13 = var2.getLabelURL();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var15, var17);
//     org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var17, "", "hi!");
//     org.jfree.chart.entity.AxisLabelEntity var24 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, var17, "hi!", "PlotOrientation.VERTICAL");
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var17, 100.0d, (-1.0f), 0.0f);
// 
//   }

}
