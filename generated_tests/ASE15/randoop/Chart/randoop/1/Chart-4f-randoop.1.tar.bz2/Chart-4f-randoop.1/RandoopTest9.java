
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    double var7 = var2.getYOffset();
    double var8 = var2.getShadowXOffset();
    double var9 = var2.getShadowXOffset();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot();
    var13.setBackgroundAlpha(1.0f);
    boolean var16 = var12.hasListener((java.util.EventListener)var13);
    java.awt.Shape var17 = var12.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var20 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var10, var17, "hi!", "hi!");
    double var21 = var10.getUpperMargin();
    java.awt.Font var22 = var10.getLabelFont();
    var2.setBaseItemLabelFont(var22);
    var2.setBaseCreateEntities(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var30 = var2.getURLGenerator(100, 223, true);
    var2.setMaximumBarWidth(0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var7 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
    var8.setBackgroundAlpha(1.0f);
    var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
    java.awt.Paint var12 = var8.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    var8.handleClick((-398), 0, var15);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    var5.addLegend(var17);
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var23 = var22.brighter();
    var17.setBackgroundPaint((java.awt.Paint)var22);
    org.jfree.chart.util.RectangleAnchor var25 = var17.getLegendItemGraphicLocation();
    org.jfree.chart.block.BlockContainer var26 = new org.jfree.chart.block.BlockContainer();
    var17.setWrapper(var26);
    java.lang.String var28 = var17.getID();
    var17.setHeight(45.0d);
    org.jfree.chart.StandardChartTheme var32 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var34 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var33.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var34);
    org.jfree.chart.plot.PieLabelLinkStyle var36 = var33.getLabelLinkStyle();
    java.lang.String var37 = var36.toString();
    var32.setLabelLinkStyle(var36);
    java.awt.Paint var39 = var32.getRangeGridlinePaint();
    var17.setBackgroundPaint(var39);
    var17.setWidth(Double.NaN);
    double var43 = var17.getContentYOffset();
    org.jfree.chart.LegendItemSource[] var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setSources(var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "PieLabelLinkStyle.STANDARD"+ "'", var37.equals("PieLabelLinkStyle.STANDARD"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtBottom();
    java.util.List var2 = var0.getAxesAtRight();
    java.util.List var3 = var0.getAxesAtLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var1.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var5 = var1.getOrientation();
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var1.setFixedDomainAxisSpace(var6);
//     org.jfree.chart.axis.AxisSpace var8 = new org.jfree.chart.axis.AxisSpace();
//     var1.setFixedRangeAxisSpace(var8);
//     java.awt.Font var10 = var1.getNoDataMessageFont();
//     java.awt.Color var15 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     float[] var19 = new float[] { 10.0f, (-1.0f), 100.0f};
//     float[] var20 = var15.getColorComponents(var19);
//     java.awt.Color var21 = java.awt.Color.getColor("TitleEntity: tooltip = AxisLabelEntity: label = null", var15);
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("10", var10, (java.awt.Paint)var15);
//     java.lang.Object var23 = var22.clone();
//     org.jfree.chart.axis.LogAxis var24 = new org.jfree.chart.axis.LogAxis();
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var24.exponentLengthToJava2D(0.0d, var26, var27);
//     double var30 = var24.calculateValue((-3.99999d));
//     org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.util.GradientPaintTransformer var32 = var31.getGradientPaintTransformer();
//     org.jfree.chart.labels.XYItemLabelGenerator var33 = var31.getBaseItemLabelGenerator();
//     var31.setShadowYOffset((-3.99999d));
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var37.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var41 = var37.getOrientation();
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var44 = var43.getAxisLineStroke();
//     java.awt.Font var45 = var43.getLabelFont();
//     org.jfree.data.time.DateRange var46 = new org.jfree.data.time.DateRange();
//     var43.setRangeWithMargins((org.jfree.data.Range)var46, false, true);
//     org.jfree.chart.util.RectangleInsets var50 = var43.getLabelInsets();
//     var43.setAutoTickUnitSelection(false);
//     org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D();
//     var53.configure();
//     var53.configure();
//     double var56 = var53.getCategoryMargin();
//     float var57 = var53.getMaximumCategoryLabelWidthRatio();
//     java.awt.Graphics2D var58 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var60 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var61 = var60.getRangeMinorGridlinePaint();
//     var60.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var66 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var67 = new org.jfree.chart.plot.PlotRenderingInfo(var66);
//     var60.handleClick(10, 0, var67);
//     java.awt.geom.Rectangle2D var69 = var67.getDataArea();
//     org.jfree.chart.util.RectangleEdge var70 = null;
//     org.jfree.chart.axis.AxisState var72 = new org.jfree.chart.axis.AxisState(0.2d);
//     var53.drawTickMarks(var58, 9.0d, var69, var70, var72);
//     var31.fillRangeGridBand(var36, (org.jfree.chart.plot.XYPlot)var37, (org.jfree.chart.axis.ValueAxis)var43, var69, 4.0d, 2.0d);
//     var24.setUpArrow((java.awt.Shape)var69);
//     var22.setBounds(var69);
//     
//     // Checks the contract:  equals-hashcode on var1 and var37
//     assertTrue("Contract failed: equals-hashcode on var1 and var37", var1.equals(var37) ? var1.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var1
//     assertTrue("Contract failed: equals-hashcode on var37 and var1", var37.equals(var1) ? var37.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.util.GradientPaintTransformer var1 = var0.getGradientPaintTransformer();
//     org.jfree.chart.labels.XYItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
//     boolean var3 = var0.getShadowsVisible();
//     org.jfree.chart.axis.SegmentedTimeline var4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var6 = var5.getMaximumDate();
//     long var7 = var4.toTimelineValue(var6);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("10", (org.jfree.data.time.RegularTimePeriod)var9, (org.jfree.data.time.RegularTimePeriod)var10);
//     var12.setMinorTickMarkInsideLength((-1.0f));
//     boolean var15 = var12.isMinorTickMarksVisible();
//     java.util.TimeZone var16 = var12.getTimeZone();
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var6, var16);
//     org.jfree.data.time.TimeSeriesCollection var18 = new org.jfree.data.time.TimeSeriesCollection(var16);
//     org.jfree.data.Range var20 = var18.getDomainBounds(true);
//     org.jfree.data.Range var21 = var0.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot();
//     var25.setBackgroundAlpha(1.0f);
//     boolean var28 = var24.hasListener((java.util.EventListener)var25);
//     java.awt.Shape var29 = var24.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var32 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var22, var29, "hi!", "hi!");
//     double var33 = var22.getUpperMargin();
//     double var34 = var22.getAutoRangeMinimumSize();
//     org.jfree.chart.plot.CombinedDomainXYPlot var36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var37 = var36.getRangeMinorGridlinePaint();
//     var36.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = new org.jfree.chart.plot.PlotRenderingInfo(var42);
//     var36.handleClick(10, 0, var43);
//     java.awt.geom.Rectangle2D var45 = var43.getDataArea();
//     java.awt.geom.Rectangle2D var46 = var43.getDataArea();
//     java.awt.geom.Rectangle2D var47 = var43.getDataArea();
//     org.jfree.chart.util.RectangleEdge var48 = null;
//     double var49 = var22.valueToJava2D(0.05d, var47, var48);
//     var0.setLegendBar((java.awt.Shape)var47);
//     boolean var51 = var0.getBaseCreateEntities();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1577894400001L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == true);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var0.setUseOutlinePaint(true);
    boolean var3 = var0.getDrawSeriesLineAsPath();
    var0.setUseOutlinePaint(false);
    java.awt.Shape var7 = var0.getLegendShape(1);
    boolean var8 = var0.getBaseSeriesVisible();
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var13 = var12.getAutoPopulateSeriesFillPaint();
    java.awt.Paint var17 = var12.getItemPaint(255, (-398), true);
    org.jfree.chart.renderer.xy.XYAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.plot.XYPlot var20 = var19.getPlot();
    org.jfree.chart.labels.XYItemLabelGenerator var22 = null;
    var19.setSeriesItemLabelGenerator(0, var22, true);
    int var25 = var19.getPassCount();
    org.jfree.chart.labels.ItemLabelPosition var27 = var19.getSeriesNegativeItemLabelPosition(0);
    var12.setSeriesNegativeItemLabelPosition(1, var27);
    var0.setSeriesNegativeItemLabelPosition(9, var27, true);
    org.jfree.chart.plot.CombinedDomainXYPlot var31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.lang.String var32 = var31.getPlotType();
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation();
    var0.setPlot((org.jfree.chart.plot.XYPlot)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "Combined_Domain_XYPlot"+ "'", var32.equals("Combined_Domain_XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var7 = var6.getTickLabelPaint();
//     int var8 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
//     org.jfree.chart.util.Layer var9 = null;
//     java.util.Collection var10 = var0.getRangeMarkers(var9);
//     var0.setRangeCrosshairValue(2.0d);
//     org.jfree.chart.axis.AxisSpace var13 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var14.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var18 = var14.getOrientation();
//     org.jfree.chart.axis.AxisSpace var19 = null;
//     var14.setFixedDomainAxisSpace(var19);
//     org.jfree.chart.axis.AxisSpace var21 = new org.jfree.chart.axis.AxisSpace();
//     var14.setFixedRangeAxisSpace(var21);
//     var13.ensureAtLeast(var21);
//     org.jfree.chart.axis.AxisSpace var24 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var26.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var30 = var26.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var33 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var34 = var33.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot();
//     var35.setBackgroundAlpha(1.0f);
//     java.awt.Paint var38 = var35.getBackgroundPaint();
//     var33.setPaint(var38);
//     var26.setRangeMinorGridlinePaint(var38);
//     int var41 = var26.getWeight();
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var44 = var43.getAxisLineStroke();
//     boolean var45 = var43.isAutoRange();
//     java.awt.Shape var46 = var43.getLeftArrow();
//     int var47 = var26.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var43);
//     org.jfree.chart.util.RectangleEdge var48 = var26.getRangeAxisEdge();
//     var24.add(0.0d, var48);
//     var21.ensureAtLeast(var24);
//     var24.setLeft(3.9999900000000004d);
//     var0.setFixedRangeAxisSpace(var24, true);
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis("10");
//     org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis("10");
//     org.jfree.chart.axis.DateAxis var61 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     org.jfree.chart.axis.DateTickUnit var62 = var61.getTickUnit();
//     java.util.Date var63 = var59.calculateLowestVisibleTickValue(var62);
//     java.util.Date var64 = var57.calculateLowestVisibleTickValue(var62);
//     org.jfree.chart.ChartRenderingInfo var66 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PlotRenderingInfo var67 = new org.jfree.chart.plot.PlotRenderingInfo(var66);
//     java.awt.geom.Rectangle2D var68 = var67.getDataArea();
//     org.jfree.chart.util.RectangleEdge var69 = null;
//     double var70 = var57.java2DToValue(10.5d, var68, var69);
//     java.awt.geom.Rectangle2D var71 = var24.shrink(var55, var68);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    int var1 = var0.getRendererCount();
    org.jfree.chart.plot.IntervalMarker var5 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var6 = var5.getOutlineStroke();
    float var7 = var5.getAlpha();
    org.jfree.chart.util.Layer var8 = null;
    boolean var9 = var0.removeDomainMarker(15, (org.jfree.chart.plot.Marker)var5, var8);
    java.awt.Stroke var10 = var0.getRangeZeroBaselineStroke();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var14 = var13.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var13);
    org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var17 = var16.getRangeMinorGridlinePaint();
    boolean var18 = var16.isRangeMinorGridlinesVisible();
    var16.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.PlotOrientation var21 = var16.getOrientation();
    var15.setOrientation(var21);
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var25 = var24.getAxisLineStroke();
    var24.resizeRange2(0.0d, 10.0d);
    java.awt.Font var29 = var24.getTickLabelFont();
    org.jfree.data.Range var30 = var24.getDefaultAutoRange();
    boolean var31 = var24.isAutoTickUnitSelection();
    java.awt.Stroke var32 = var24.getTickMarkStroke();
    var15.setRangeAxis((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.chart.plot.IntervalMarker var36 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var37 = var36.getOutlineStroke();
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setBackgroundAlpha(1.0f);
    java.awt.Paint var41 = var38.getBackgroundPaint();
    var36.setPaint(var41);
    var15.addRangeMarker((org.jfree.chart.plot.Marker)var36);
    boolean var44 = var11.removeDomainMarker((org.jfree.chart.plot.Marker)var36);
    boolean var45 = var11.isRangeCrosshairVisible();
    org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D();
    var46.removeCategoryLabelToolTip((java.lang.Comparable)2147483647);
    java.lang.Object var49 = var46.clone();
    int var50 = var11.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var46);
    var0.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var46);
    boolean var52 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var6 = var5.getAxisLineStroke();
    boolean var7 = var5.isAutoRange();
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    double var11 = var10.getLowerBound();
    var5.setRangeWithMargins(var10, false, false);
    float var15 = var5.getMinorTickMarkInsideLength();
    org.jfree.data.Range var16 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var5);
    java.util.List var17 = var3.getSubplots();
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot();
    var20.setBackgroundAlpha(1.0f);
    boolean var23 = var19.hasListener((java.util.EventListener)var20);
    java.awt.Shape var24 = var19.getLeftArrow();
    var19.setAutoRangeIncludesZero(false);
    var19.setPositiveArrowVisible(false);
    int var29 = var3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var19);
    var19.setRange((-1.0d), 10.0d);
    var19.configure();
    double var34 = var19.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1.0d));

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.plot.XYPlot var1 = var0.getPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.lang.String var3 = var2.getPlotType();
    var0.setPlot((org.jfree.chart.plot.XYPlot)var2);
    org.jfree.chart.labels.XYSeriesLabelGenerator var5 = null;
    var0.setLegendItemURLGenerator(var5);
    var0.removeAnnotations();
    var0.setSeriesItemLabelsVisible(100, true);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var12 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var14 = var13.getTickLabelFont();
    boolean var15 = var12.equals((java.lang.Object)var13);
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var12);
    boolean var17 = var0.getPlotArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Combined_Domain_XYPlot"+ "'", var3.equals("Combined_Domain_XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.event.RendererChangeEvent var2 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)(short)1);
    org.jfree.chart.JFreeChart var3 = null;
    var2.setChart(var3);
    boolean var5 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var6.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var10 = var6.getOrientation();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    var11.setNotify(false);
    var11.setNotify(false);
    org.jfree.chart.event.ChartProgressEvent var18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var2, var11, 13, (-398));
    var18.setType(100);
    var18.setPercent(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    var0.setOutline(false);
    var0.setOutline(true);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    org.jfree.data.xy.XYDataItem var7 = var4.addOrUpdate(1.0E-5d, (-5.99999d));
    boolean var8 = var4.getAllowDuplicateXValues();
    double var9 = var4.getMinY();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-5.99999d));

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
//     org.jfree.chart.axis.SegmentedTimeline var2 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var4 = var3.getMaximumDate();
//     long var5 = var2.toTimelineValue(var4);
//     java.util.List var6 = var2.getExceptionSegments();
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(255);
//     org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var13 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     var13.add(10.0d, (-1.0d), true);
//     double var18 = var13.getMinX();
//     org.jfree.data.xy.XYSeriesCollection var19 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     org.jfree.data.Range var21 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var19, true);
//     boolean var22 = var19.isAutoWidth();
//     org.jfree.data.xy.DefaultXYDataset var23 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
//     var24.setBackgroundAlpha(1.0f);
//     var23.addChangeListener((org.jfree.data.general.DatasetChangeListener)var24);
//     int var29 = var23.indexOf((java.lang.Comparable)'a');
//     java.lang.Number var30 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var23);
//     org.jfree.chart.axis.NumberTickUnit var32 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var35 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     java.util.List var36 = var35.getItems();
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var39 = var38.getAxisLineStroke();
//     var38.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var43 = var38.getTickLabelFont();
//     org.jfree.data.Range var44 = var38.getDefaultAutoRange();
//     org.jfree.chart.ui.Library var49 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var50 = var49.getLicenceName();
//     boolean var51 = var44.equals((java.lang.Object)var49);
//     org.jfree.data.Range var53 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var23, var36, var44, false);
//     org.jfree.data.Range var56 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var57 = var56.getLowerBound();
//     org.jfree.data.Range var59 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var19, var36, var56, false);
//     org.jfree.data.time.SpreadsheetDate var61 = new org.jfree.data.time.SpreadsheetDate(255);
//     int var62 = var19.indexOf((java.lang.Comparable)var61);
//     boolean var63 = var8.isBefore((org.jfree.data.time.SerialDate)var61);
//     java.util.Date var64 = var61.toDate();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var65 = var2.getSegment(var64);
//     var0.setTimeline((org.jfree.chart.axis.Timeline)var2);
//     org.jfree.chart.plot.CombinedRangeXYPlot var67 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1577894400001L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "hi!"+ "'", var50.equals("hi!"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.util.RectangleEdge var3 = null;
//     double var4 = var0.exponentLengthToJava2D(0.0d, var2, var3);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var7 = var6.getRangeMinorGridlinePaint();
//     var6.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     var6.handleClick(10, 0, var13);
//     java.awt.geom.Rectangle2D var15 = var13.getDataArea();
//     java.awt.geom.Rectangle2D var16 = var13.getDataArea();
//     java.awt.geom.Rectangle2D var17 = var13.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var18.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var22 = var18.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var26 = var25.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot();
//     var27.setBackgroundAlpha(1.0f);
//     java.awt.Paint var30 = var27.getBackgroundPaint();
//     var25.setPaint(var30);
//     var18.setRangeMinorGridlinePaint(var30);
//     int var33 = var18.getWeight();
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var36 = var35.getAxisLineStroke();
//     boolean var37 = var35.isAutoRange();
//     java.awt.Shape var38 = var35.getLeftArrow();
//     int var39 = var18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.chart.util.RectangleEdge var40 = var18.getRangeAxisEdge();
//     double var41 = var0.exponentLengthToJava2D(9.0d, var17, var40);
//     boolean var42 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var2 = var1.getAxisLineStroke();
//     boolean var3 = var1.isAutoRange();
//     java.awt.Shape var4 = var1.getLeftArrow();
//     org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var13 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     double var14 = var13.getMinX();
//     java.beans.PropertyChangeListener var15 = null;
//     var13.removePropertyChangeListener(var15);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     var13.setKey((java.lang.Comparable)var17);
//     double[][] var19 = var13.toArray();
//     org.jfree.data.category.CategoryDataset var20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DomainOrder.NONE", "TitleEntity: tooltip = AxisLabelEntity: label = null", var19);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(255);
//     org.jfree.data.xy.DefaultXYDataset var23 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var23, true);
//     org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot();
//     var26.setBackgroundAlpha(1.0f);
//     java.awt.Paint var29 = var26.getBackgroundPaint();
//     org.jfree.chart.axis.TickUnit var30 = var26.getAngleTickUnit();
//     int var31 = var23.indexOf((java.lang.Comparable)var30);
//     org.jfree.chart.entity.CategoryItemEntity var32 = new org.jfree.chart.entity.CategoryItemEntity(var4, "SerialDate.weekInMonthToString(): invalid code.", "org.jfree.data.general.SeriesException: org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.event.RendererChangeEvent[source=1]]", var20, (java.lang.Comparable)var22, (java.lang.Comparable)var30);
//     java.lang.Comparable var33 = var32.getColumnKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var3.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(6.0d, var3);
    org.jfree.chart.block.RectangleConstraint var6 = var5.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var7 = var5.toUnconstrainedHeight();
    org.jfree.chart.block.LengthConstraintType var8 = var7.getWidthConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
    org.jfree.chart.plot.PieLabelLinkStyle var5 = var2.getLabelLinkStyle();
    java.lang.String var6 = var5.toString();
    var1.setLabelLinkStyle(var5);
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var10 = var9.getAxisLineStroke();
    java.awt.Font var11 = var9.getLabelFont();
    var1.setLargeFont(var11);
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Graphics2D var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    org.jfree.chart.plot.CrosshairState var19 = null;
    boolean var20 = var14.render(var15, var16, 0, var18, var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("TitleEntity: tooltip = AxisLabelEntity: label = null", (org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.title.LegendTitle var22 = var21.getLegend();
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
    int var25 = var24.getMaximumLinesToDisplay();
    var21.setTitle(var24);
    var1.apply(var21);
    int var28 = var21.getSubtitleCount();
    var21.fireChartChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "PieLabelLinkStyle.STANDARD"+ "'", var6.equals("PieLabelLinkStyle.STANDARD"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
//     var0.setUseOutlinePaint(true);
//     boolean var3 = var0.getDrawSeriesLineAsPath();
//     var0.setSeriesShapesVisible(1, (java.lang.Boolean)true);
//     boolean var7 = var0.getBaseLinesVisible();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var10 = var9.getRangeMinorGridlinePaint();
//     boolean var11 = var9.isRangeMinorGridlinesVisible();
//     var9.setDomainCrosshairVisible(false);
//     org.jfree.chart.LegendItemCollection var14 = var9.getLegendItems();
//     java.awt.Stroke var15 = var9.getRangeGridlineStroke();
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot();
//     var18.setBackgroundAlpha(1.0f);
//     boolean var21 = var17.hasListener((java.util.EventListener)var18);
//     java.awt.Shape var22 = var17.getLeftArrow();
//     var17.setAutoRangeIncludesZero(false);
//     var17.setPositiveArrowVisible(false);
//     org.jfree.chart.event.AxisChangeEvent var27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var17);
//     org.jfree.chart.axis.Axis var28 = var27.getAxis();
//     var9.axisChanged(var27);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.chart.axis.PeriodAxis var34 = new org.jfree.chart.axis.PeriodAxis("10", (org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     var34.setMinorTickMarkInsideLength((-1.0f));
//     java.awt.geom.Rectangle2D var37 = null;
//     var0.drawDomainGridLine(var8, (org.jfree.chart.plot.XYPlot)var9, (org.jfree.chart.axis.ValueAxis)var34, var37, 4.0d);
//     float var40 = var34.getMinorTickMarkInsideLength();
//     var34.setLabelToolTip("hi!");
//     org.jfree.chart.util.RectangleInsets var43 = var34.getTickLabelInsets();
//     org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var46 = var45.clone();
//     org.jfree.data.xy.DefaultXYDataset var47 = new org.jfree.data.xy.DefaultXYDataset();
//     var45.setDataset((org.jfree.data.general.Dataset)var47);
//     org.jfree.data.general.Dataset var49 = var45.getDataset();
//     java.awt.Color var53 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var54 = var53.brighter();
//     var45.setFillPaint((java.awt.Paint)var54);
//     int var56 = var54.getGreen();
//     java.awt.Color var57 = var54.brighter();
//     var34.setTickMarkPaint((java.awt.Paint)var54);
//     org.jfree.chart.plot.PiePlot3D var59 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var61 = var60.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var62 = var60.getTickLabelInsets();
//     double var64 = var62.trimHeight(1.0E-5d);
//     double var66 = var62.calculateBottomInset(1.0E-8d);
//     var59.setSimpleLabelOffset(var62);
//     org.jfree.chart.plot.AbstractPieLabelDistributor var68 = var59.getLabelDistributor();
//     org.jfree.data.general.PieDataset var69 = null;
//     var59.setDataset(var69);
//     org.jfree.chart.plot.PieLabelLinkStyle var71 = var59.getLabelLinkStyle();
//     boolean var72 = var34.equals((java.lang.Object)var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-1.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == (-3.99999d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }
// 
// 
//     java.util.TimeZone var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     double var3 = var1.getDomainLowerBound(false);
//     var1.removeAllSeries();
//     org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var7 = var6.getRangeMinorGridlinePaint();
//     boolean var8 = var6.isRangeMinorGridlinesVisible();
//     var6.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.PlotOrientation var11 = var6.getOrientation();
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var15 = var14.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var18 = var17.getAxisLineStroke();
//     var14.setBaseOutlineStroke(var18, false);
//     var6.setDomainCrosshairStroke(var18);
//     var5.setLabelOutlineStroke(var18);
//     boolean var23 = var1.equals((java.lang.Object)var18);
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"4", "Combined_Domain_XYPlot", "PlotOrientation.HORIZONTAL");
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.previous();
//     var27.add((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)100.0f, false);
//     var1.addSeries(var27);
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"4", "Combined_Domain_XYPlot", "PlotOrientation.HORIZONTAL");
//     var1.removeSeries(var38);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var41 = var1.getSeries(1);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0E-5d);
//     org.jfree.chart.LegendItem var4 = var1.getLegendItem(0, 0);
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     double var8 = var6.getDomainLowerBound(false);
//     var6.removeAllSeries();
//     java.lang.Comparable var10 = null;
//     org.jfree.data.time.TimeSeries var11 = var6.getSeries(var10);
//     org.jfree.data.Range var12 = var1.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     org.jfree.chart.ChartRenderingInfo var13 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var14 = var13.getChartArea();
//     var1.setLegendBar((java.awt.Shape)var14);
//     boolean var16 = var1.getAutoPopulateSeriesOutlineStroke();
//     int var17 = var1.getDefaultEntityRadius();
//     java.awt.Shape var18 = var1.getLegendBar();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var4 = var2.lookupSeriesPaint(10);
    java.awt.Stroke var6 = var2.lookupSeriesOutlineStroke(13);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var11 = var9.lookupSeriesPaint(10);
    java.awt.Stroke var13 = var9.lookupSeriesOutlineStroke(13);
    var2.setBaseStroke(var13);
    java.awt.Paint var16 = var2.getSeriesFillPaint(0);
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot();
    double var18 = var17.getMinimumArcAngleToDraw();
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var23 = var22.brighter();
    var17.setBaseSectionOutlinePaint((java.awt.Paint)var23);
    var2.setBasePaint((java.awt.Paint)var23, false);
    int var27 = var23.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-1));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", var3, "", "", "");
    org.jfree.chart.axis.NumberTickUnit var9 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var13 = var12.getItems();
    var7.setContributors(var13);
    java.lang.String var15 = var7.getLicenceName();
    var7.setVersion("500%");
    var7.setLicenceText("ChartChangeEventType.GENERAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + ""+ "'", var15.equals(""));

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    int var1 = var0.getRendererCount();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)'4', false);
    org.jfree.chart.event.RendererChangeEvent var5 = null;
    var0.rendererChanged(var5);
    int var7 = var0.getDatasetCount();
    boolean var8 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Graphics2D var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.plot.CrosshairState var17 = null;
    boolean var18 = var12.render(var13, var14, 0, var16, var17);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("TitleEntity: tooltip = AxisLabelEntity: label = null", (org.jfree.chart.plot.Plot)var12);
    org.jfree.chart.title.LegendTitle var20 = var19.getLegend();
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
    int var23 = var22.getMaximumLinesToDisplay();
    var19.setTitle(var22);
    boolean var25 = var19.isNotify();
    org.jfree.chart.event.ChartProgressListener var26 = null;
    var19.removeProgressListener(var26);
    org.jfree.chart.ChartRenderingInfo var32 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.image.BufferedImage var33 = var19.createBufferedImage(255, 255, (-1.0d), 5.0d, var32);
    org.jfree.chart.plot.PlotRenderingInfo var34 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
    java.awt.geom.Point2D var35 = null;
    var0.zoomDomainAxes(3.9999900000000004d, 0.14d, var34, var35);
    org.jfree.chart.renderer.category.BarRenderer3D var39 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var40 = var39.getAutoPopulateSeriesFillPaint();
    double var41 = var39.getLowerClip();
    var39.setShadowYOffset(1.0E-5d);
    double var44 = var39.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var45 = var39.getPositiveItemLabelPositionFallback();
    org.jfree.chart.plot.RingPlot var47 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var48 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var47.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var48);
    org.jfree.chart.plot.PieLabelLinkStyle var50 = var47.getLabelLinkStyle();
    var47.setSimpleLabels(false);
    java.awt.Stroke var53 = var47.getSeparatorStroke();
    var39.setSeriesOutlineStroke(100, var53, true);
    var39.clearSeriesPaints(false);
    boolean var58 = var34.equals((java.lang.Object)var39);
    int var59 = var39.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
//     var0.setUseOutlinePaint(true);
//     boolean var3 = var0.getDrawSeriesLineAsPath();
//     var0.setSeriesShapesVisible(1, (java.lang.Boolean)true);
//     boolean var7 = var0.getBaseLinesVisible();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var10 = var9.getRangeMinorGridlinePaint();
//     boolean var11 = var9.isRangeMinorGridlinesVisible();
//     var9.setDomainCrosshairVisible(false);
//     org.jfree.chart.LegendItemCollection var14 = var9.getLegendItems();
//     java.awt.Stroke var15 = var9.getRangeGridlineStroke();
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot();
//     var18.setBackgroundAlpha(1.0f);
//     boolean var21 = var17.hasListener((java.util.EventListener)var18);
//     java.awt.Shape var22 = var17.getLeftArrow();
//     var17.setAutoRangeIncludesZero(false);
//     var17.setPositiveArrowVisible(false);
//     org.jfree.chart.event.AxisChangeEvent var27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var17);
//     org.jfree.chart.axis.Axis var28 = var27.getAxis();
//     var9.axisChanged(var27);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.chart.axis.PeriodAxis var34 = new org.jfree.chart.axis.PeriodAxis("10", (org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var32);
//     var34.setMinorTickMarkInsideLength((-1.0f));
//     java.awt.geom.Rectangle2D var37 = null;
//     var0.drawDomainGridLine(var8, (org.jfree.chart.plot.XYPlot)var9, (org.jfree.chart.axis.ValueAxis)var34, var37, 4.0d);
//     org.jfree.data.time.RegularTimePeriod var40 = var34.getLast();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem(var40, (java.lang.Number)(short)0);
//     var42.setValue((java.lang.Number)1.0E-100d);
//     org.jfree.data.time.RegularTimePeriod var45 = var42.getPeriod();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var4 = var2.lookupSeriesPaint(10);
    java.awt.Stroke var6 = var2.lookupSeriesOutlineStroke(13);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var11 = var9.lookupSeriesPaint(10);
    java.awt.Stroke var13 = var9.lookupSeriesOutlineStroke(13);
    var2.setBaseStroke(var13);
    java.awt.Paint var16 = var2.getSeriesFillPaint(0);
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot();
    double var18 = var17.getMinimumArcAngleToDraw();
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var23 = var22.brighter();
    var17.setBaseSectionOutlinePaint((java.awt.Paint)var23);
    var2.setBasePaint((java.awt.Paint)var23, false);
    var2.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.urls.CategoryURLGenerator var29 = null;
    var2.setBaseURLGenerator(var29, false);
    org.jfree.chart.renderer.category.BarPainter var32 = var2.getBarPainter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
    var2.setBackgroundAlpha(1.0f);
    boolean var5 = var1.hasListener((java.util.EventListener)var2);
    java.awt.Paint var6 = var2.getAngleLabelPaint();
    org.jfree.chart.plot.Plot var7 = var2.getParent();
    boolean var8 = var2.isAngleLabelsVisible();
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot();
    double var10 = var9.getMinimumArcAngleToDraw();
    java.awt.Stroke var11 = var9.getLabelOutlineStroke();
    java.awt.Color var16 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var20 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var21 = var16.getColorComponents(var20);
    java.awt.color.ColorSpace var22 = var16.getColorSpace();
    java.awt.Color var26 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var30 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var31 = var26.getColorComponents(var30);
    float[] var32 = var16.getRGBColorComponents(var30);
    var9.setSectionPaint((java.lang.Comparable)(byte)(-1), (java.awt.Paint)var16);
    var2.setRadiusGridlinePaint((java.awt.Paint)var16);
    org.jfree.chart.plot.CombinedDomainXYPlot var35 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var35.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var39 = var35.getOrientation();
    org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var43 = var42.getOutlineStroke();
    org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot();
    var44.setBackgroundAlpha(1.0f);
    java.awt.Paint var47 = var44.getBackgroundPaint();
    var42.setPaint(var47);
    var35.setRangeMinorGridlinePaint(var47);
    org.jfree.chart.axis.AxisSpace var50 = null;
    var35.setFixedDomainAxisSpace(var50);
    java.awt.Stroke var52 = var35.getRangeZeroBaselineStroke();
    var2.setRadiusGridlineStroke(var52);
    var2.clearCornerTextItems();
    var2.setAngleLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
//     boolean var2 = var0.isRangeMinorGridlinesVisible();
//     var0.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.PlotOrientation var5 = var0.getOrientation();
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
//     var11.setBackgroundAlpha(1.0f);
//     boolean var14 = var10.hasListener((java.util.EventListener)var11);
//     java.awt.Paint var15 = var11.getAngleLabelPaint();
//     var8.setLabelPaint(var15);
//     java.lang.String var17 = var8.getLabelURL();
//     java.awt.Shape var18 = var8.getDownArrow();
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var8);
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot();
//     var22.setBackgroundAlpha(1.0f);
//     boolean var25 = var21.hasListener((java.util.EventListener)var22);
//     java.awt.Shape var26 = var21.getLeftArrow();
//     var21.setAutoRangeIncludesZero(false);
//     var21.setPositiveArrowVisible(false);
//     org.jfree.chart.event.AxisChangeEvent var31 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var21);
//     org.jfree.chart.axis.Axis var32 = var31.getAxis();
//     org.jfree.chart.axis.Axis var33 = var31.getAxis();
//     org.jfree.chart.axis.Axis var34 = var31.getAxis();
//     var0.axisChanged(var31);
//     
//     // Checks the contract:  equals-hashcode on var11 and var22
//     assertTrue("Contract failed: equals-hashcode on var11 and var22", var11.equals(var22) ? var11.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var11
//     assertTrue("Contract failed: equals-hashcode on var22 and var11", var22.equals(var11) ? var22.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var6 = var5.getAxisLineStroke();
    boolean var7 = var5.isAutoRange();
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    double var11 = var10.getLowerBound();
    var5.setRangeWithMargins(var10, false, false);
    float var15 = var5.getMinorTickMarkInsideLength();
    org.jfree.data.Range var16 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var5);
    java.util.List var17 = var3.getSubplots();
    org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var19 = var18.getRangeMinorGridlinePaint();
    var18.clearRangeMarkers(1);
    org.jfree.chart.ChartRenderingInfo var24 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
    var18.handleClick(10, 0, var25);
    java.awt.geom.Rectangle2D var27 = var25.getDataArea();
    org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var28.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var32 = var28.getOrientation();
    boolean var33 = var28.isDomainMinorGridlinesVisible();
    java.awt.geom.Point2D var34 = var28.getQuadrantOrigin();
    org.jfree.chart.plot.XYPlot var35 = var3.findSubplot(var25, var34);
    org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var40 = var38.lookupSeriesPaint(10);
    java.awt.Stroke var42 = var38.lookupSeriesOutlineStroke(13);
    var3.setDomainGridlineStroke(var42);
    java.awt.Stroke var44 = var3.getRangeGridlineStroke();
    var3.clearRangeAxes();
    var3.setRangeMinorGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    org.jfree.data.xy.DefaultXYDataset var2 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    var2.addChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
    java.awt.Paint var7 = var3.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    var3.handleClick((-398), 0, var10);
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var14 = var13.getRangeMinorGridlinePaint();
    boolean var15 = var13.isRangeMinorGridlinesVisible();
    var13.setDomainCrosshairVisible(false);
    org.jfree.chart.LegendItemCollection var18 = var13.getLegendItems();
    org.jfree.chart.LegendItemSource[] var19 = new org.jfree.chart.LegendItemSource[] { var13};
    var12.setSources(var19);
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
    java.text.NumberFormat var23 = var22.getNumberFormatOverride();
    var22.setFixedAutoRange(4.0d);
    java.awt.Paint var26 = var22.getTickMarkPaint();
    var12.setItemPaint(var26);
    org.jfree.chart.util.RectangleAnchor var28 = var12.getLegendItemGraphicAnchor();
    var1.setTextAnchor(var28);
    java.awt.Font var30 = var1.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    double var4 = var0.valueToJava2D(1.0d, var2, var3);
    double var5 = var0.getAutoRangeMinimumSize();
    org.jfree.chart.text.TextLine var6 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.text.TextAnchor var10 = null;
    var6.draw(var7, 2.0f, 100.0f, var10, 100.0f, (-1.0f), 2.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var18 = var17.getAutoPopulateSeriesFillPaint();
    double var19 = var17.getLowerClip();
    org.jfree.chart.ChartColor var23 = new org.jfree.chart.ChartColor(10, 100, 1);
    var17.setBasePaint((java.awt.Paint)var23);
    java.awt.Font var25 = var17.getBaseItemLabelFont();
    boolean var26 = var6.equals((java.lang.Object)var17);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot();
    var30.setBackgroundAlpha(1.0f);
    boolean var33 = var29.hasListener((java.util.EventListener)var30);
    java.awt.Shape var34 = var29.getLeftArrow();
    double var35 = var29.getLowerBound();
    java.awt.Paint var36 = var29.getTickLabelPaint();
    var27.setRangeMinorGridlinePaint(var36);
    var17.setPlot(var27);
    var27.setWeight(0);
    var0.setPlot((org.jfree.chart.plot.Plot)var27);
    var27.setDomainCrosshairRowKey((java.lang.Comparable)"0.781", true);
    java.lang.Object var45 = var27.clone();
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var48 = null;
    var46.setDataset(100, var48);
    org.jfree.chart.axis.CategoryAxis var50 = var46.getDomainAxis();
    org.jfree.chart.plot.IntervalMarker var53 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 1.0d);
    boolean var54 = var46.removeDomainMarker((org.jfree.chart.plot.Marker)var53);
    var27.addRangeMarker((org.jfree.chart.plot.Marker)var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    boolean var6 = var2.hasListener((java.util.EventListener)var3);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
    java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var7, (java.awt.Paint)var14);
    java.text.NumberFormat var18 = java.text.NumberFormat.getNumberInstance();
    org.jfree.chart.axis.NumberTickUnit var19 = new org.jfree.chart.axis.NumberTickUnit(2.0d, var18);
    boolean var20 = var14.equals((java.lang.Object)var19);
    int var21 = var19.getMinorTickCount();
    int var22 = var19.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     var4.add(10.0d, (-1.0d), true);
//     double var9 = var4.getMinX();
//     org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var4);
//     org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var10, true);
//     boolean var13 = var10.isAutoWidth();
//     org.jfree.data.xy.DefaultXYDataset var14 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
//     var15.setBackgroundAlpha(1.0f);
//     var14.addChangeListener((org.jfree.data.general.DatasetChangeListener)var15);
//     int var20 = var14.indexOf((java.lang.Comparable)'a');
//     java.lang.Number var21 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var14);
//     org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var26 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     java.util.List var27 = var26.getItems();
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var30 = var29.getAxisLineStroke();
//     var29.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var34 = var29.getTickLabelFont();
//     org.jfree.data.Range var35 = var29.getDefaultAutoRange();
//     org.jfree.chart.ui.Library var40 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var41 = var40.getLicenceName();
//     boolean var42 = var35.equals((java.lang.Object)var40);
//     org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var14, var27, var35, false);
//     org.jfree.data.Range var47 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var48 = var47.getLowerBound();
//     org.jfree.data.Range var50 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var10, var27, var47, false);
//     org.jfree.data.time.SpreadsheetDate var52 = new org.jfree.data.time.SpreadsheetDate(255);
//     int var53 = var10.indexOf((java.lang.Comparable)var52);
//     java.lang.String var54 = var52.getDescription();
//     int var55 = var52.getYYYY();
//     org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var58 = var57.clone();
//     var57.setDescription("");
//     org.jfree.data.time.Day var61 = new org.jfree.data.time.Day();
//     var57.setSeriesKey((java.lang.Comparable)var61);
//     org.jfree.data.time.SerialDate var63 = var61.getSerialDate();
//     int var64 = var52.compare(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "hi!"+ "'", var41.equals("hi!"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == (-41738));
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     boolean var5 = var0.isDomainMinorGridlinesVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     var0.setRenderer(1, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var0.getDomainMarkers(2147483647, var10);
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var14 = var13.getAxisLineStroke();
//     java.awt.Font var15 = var13.getLabelFont();
//     org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange();
//     var13.setRangeWithMargins((org.jfree.data.Range)var16, false, true);
//     org.jfree.chart.util.RectangleInsets var20 = var13.getLabelInsets();
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
//     java.lang.String var22 = var21.toString();
//     long var23 = var21.getUpperMillis();
//     double var24 = var21.getLength();
//     var13.setDefaultAutoRange((org.jfree.data.Range)var21);
//     java.lang.String var26 = var13.getLabelToolTip();
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var31 = var30.getAxisLineStroke();
//     java.awt.Font var32 = var30.getLabelFont();
//     org.jfree.data.time.DateRange var33 = new org.jfree.data.time.DateRange();
//     var30.setRangeWithMargins((org.jfree.data.Range)var33, false, true);
//     org.jfree.chart.util.RectangleInsets var37 = var30.getLabelInsets();
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var40 = var39.getAxisLineStroke();
//     var39.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var44 = var39.getTickLabelFont();
//     org.jfree.data.Range var45 = var39.getDefaultAutoRange();
//     boolean var46 = var39.isAutoTickUnitSelection();
//     java.awt.Paint var47 = var39.getTickLabelPaint();
//     org.jfree.chart.axis.NumberAxis3D var48 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var51 = new org.jfree.chart.plot.PolarPlot();
//     var51.setBackgroundAlpha(1.0f);
//     boolean var54 = var50.hasListener((java.util.EventListener)var51);
//     java.awt.Shape var55 = var50.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var58 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var48, var55, "hi!", "hi!");
//     double var59 = var48.getUpperMargin();
//     org.jfree.chart.util.RectangleInsets var64 = new org.jfree.chart.util.RectangleInsets(1.0E-5d, 0.0d, 1.0d, Double.NaN);
//     var48.setTickLabelInsets(var64);
//     double var66 = var64.getRight();
//     var39.setLabelInsets(var64, true);
//     var30.setLabelInsets(var64);
//     var0.setDomainAxis(9, (org.jfree.chart.axis.ValueAxis)var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var22.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == Double.NaN);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator((-398));
    org.jfree.chart.labels.StandardXYToolTipGenerator var5 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.lang.String var6 = var5.getNullYString();
    java.text.DateFormat var7 = var5.getXDateFormat();
    java.text.DateFormat var8 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RectangleAnchor.CENTER", var7, var8);
    var0.setSeriesToolTipGenerator(1900, (org.jfree.chart.labels.XYToolTipGenerator)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "null"+ "'", var6.equals("null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var2 = var1.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var5 = var4.getAxisLineStroke();
    var4.resizeRange2(0.0d, 10.0d);
    java.awt.Font var9 = var4.getTickLabelFont();
    org.jfree.data.Range var10 = var4.getDefaultAutoRange();
    boolean var11 = var4.isAutoTickUnitSelection();
    java.awt.Paint var12 = var4.getTickLabelPaint();
    var1.setBackgroundPaint(var12);
    var1.setWidth(0.2d);
    boolean var16 = var1.getExpandToFitSpace();
    java.awt.Font var18 = null;
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var23 = var22.brighter();
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22);
    java.awt.Font var26 = null;
    java.awt.Color var30 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var31 = var30.brighter();
    org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, (java.awt.Paint)var30);
    org.jfree.chart.text.TextBlock var33 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var34 = var33.getLineAlignment();
    java.lang.String var35 = var34.toString();
    var32.setLineAlignment(var34);
    org.jfree.chart.util.HorizontalAlignment var37 = var32.getLineAlignment();
    var24.setLineAlignment(var37);
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.text.TextBlockAnchor var42 = null;
    var24.draw(var39, 2.0f, (-1.0f), var42);
    org.jfree.chart.util.HorizontalAlignment var44 = var24.getLineAlignment();
    var1.setTextAlignment(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var35.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    java.awt.Paint var2 = var1.getRangeGridlinePaint();
    java.awt.Paint var3 = var1.getBaselinePaint();
    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("Combined Range XYPlot");
    var1.setErrorIndicatorPaint((java.awt.Paint)var5);
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot();
    double var8 = var7.getMinimumArcAngleToDraw();
    java.awt.Stroke var9 = var7.getLabelOutlineStroke();
    var7.clearSectionOutlineStrokes(true);
    org.jfree.chart.urls.PieURLGenerator var12 = var7.getURLGenerator();
    boolean var13 = var7.getSectionOutlinesVisible();
    var7.setIgnoreZeroValues(true);
    java.awt.Paint var16 = var7.getLabelShadowPaint();
    var1.setAxisLabelPaint(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", var3, "", "", "");
    org.jfree.chart.axis.NumberTickUnit var9 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var13 = var12.getItems();
    var7.setContributors(var13);
    java.lang.String var15 = var7.getLicenceName();
    var7.setLicenceName("ThreadContext");
    java.lang.String var18 = var7.getVersion();
    var7.setLicenceText("9");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + ""+ "'", var15.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, true);
    var2.setSeriesLinesVisible(0, true);
    org.jfree.chart.LegendItem var8 = var2.getLegendItem(9, 2);
    boolean var9 = var2.getBaseLinesVisible();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    var13.setAutoPopulateSeriesShape(false);
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var21 = var19.lookupSeriesPaint(10);
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot();
    var30.setBackgroundAlpha(1.0f);
    java.awt.Paint var33 = var30.getBackgroundPaint();
    var29.setLabelPaint(var33);
    org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 0.0d, 100.0d, var33);
    var19.setSeriesPaint(13, var33);
    var13.setSeriesPaint(0, var33);
    java.awt.Stroke var41 = var13.getItemStroke((-398), 0, false);
    var2.setSeriesStroke(10, var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    var0.setOutline(false);
    java.awt.Stroke var3 = var0.getBaseOutlineStroke();
    java.awt.Paint var5 = var0.getSeriesPaint(13);
    org.jfree.chart.plot.XYPlot var6 = var0.getPlot();
    boolean var7 = var0.getShapesVisible();
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var12 = var11.getAutoPopulateSeriesFillPaint();
    double var13 = var11.getLowerClip();
    var11.setShadowYOffset(1.0E-5d);
    double var16 = var11.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var11.setSeriesNegativeItemLabelPosition(1, var18);
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var22 = var21.getAxisLineStroke();
    java.awt.Font var23 = var21.getLabelFont();
    var11.setBaseItemLabelFont(var23);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var27 = var26.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var30 = var29.getAxisLineStroke();
    var29.resizeRange2(0.0d, 10.0d);
    java.awt.Font var34 = var29.getTickLabelFont();
    org.jfree.data.Range var35 = var29.getDefaultAutoRange();
    boolean var36 = var29.isAutoTickUnitSelection();
    java.awt.Paint var37 = var29.getTickLabelPaint();
    var26.setBackgroundPaint(var37);
    java.awt.Graphics2D var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var26.draw(var39, var40);
    var26.setID("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.awt.Color var47 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    var26.setPaint((java.awt.Paint)var47);
    org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("TitleEntity: tooltip = AxisLabelEntity: label = null", var23, (java.awt.Paint)var47, 0.0f);
    var0.setBaseLegendTextPaint((java.awt.Paint)var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var3 = var2.getRangeMinorGridlinePaint();
    org.jfree.chart.LegendItemCollection var4 = var2.getFixedLegendItems();
    int var5 = var2.getRangeAxisCount();
    int var6 = var2.getDomainAxisCount();
    var2.setDomainCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisLocation var10 = var2.getDomainAxisLocation(1);
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot();
    double var12 = var11.getMinimumArcAngleToDraw();
    java.awt.Stroke var13 = var11.getLabelOutlineStroke();
    java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var22 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var23 = var18.getColorComponents(var22);
    java.awt.color.ColorSpace var24 = var18.getColorSpace();
    java.awt.Color var28 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var32 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var33 = var28.getColorComponents(var32);
    float[] var34 = var18.getRGBColorComponents(var32);
    var11.setSectionPaint((java.lang.Comparable)(byte)(-1), (java.awt.Paint)var18);
    var2.setRangeMinorGridlinePaint((java.awt.Paint)var18);
    var0.setPaint(100, (java.awt.Paint)var18);
    int var38 = var18.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 255);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var5 = var4.getLicenceName();
    java.lang.String var6 = var4.getLicenceName();
    java.lang.String var7 = var4.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "hi!"+ "'", var6.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "hi!"+ "'", var7.equals("hi!"));

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Font var3 = var2.getBaseLegendTextFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
    org.jfree.chart.plot.PieLabelLinkStyle var5 = var2.getLabelLinkStyle();
    java.lang.String var6 = var5.toString();
    var1.setLabelLinkStyle(var5);
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var10 = var9.getAxisLineStroke();
    java.awt.Font var11 = var9.getLabelFont();
    var1.setLargeFont(var11);
    java.awt.Paint var13 = var1.getItemLabelPaint();
    java.awt.Font var14 = var1.getExtraLargeFont();
    java.awt.Paint var15 = var1.getBaselinePaint();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    int var17 = var16.getRendererCount();
    var16.setDomainCrosshairColumnKey((java.lang.Comparable)'4', false);
    org.jfree.chart.event.RendererChangeEvent var21 = null;
    var16.rendererChanged(var21);
    org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Paint var27 = var26.getLabelPaint();
    org.jfree.chart.event.MarkerChangeEvent var28 = null;
    var26.notifyListeners(var28);
    org.jfree.chart.util.Layer var30 = null;
    boolean var32 = var16.removeRangeMarker(2, (org.jfree.chart.plot.Marker)var26, var30, true);
    org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var35 = var34.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var36 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var34);
    org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var37.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var41 = var37.getOrientation();
    var36.add((org.jfree.chart.plot.XYPlot)var37);
    org.jfree.chart.axis.AxisSpace var43 = var36.getFixedDomainAxisSpace();
    java.awt.Paint var44 = var36.getDomainGridlinePaint();
    var26.setOutlinePaint(var44);
    var1.setPlotBackgroundPaint(var44);
    java.lang.String var47 = var1.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "PieLabelLinkStyle.STANDARD"+ "'", var6.equals("PieLabelLinkStyle.STANDARD"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + " version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var47.equals(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }
// 
// 
//     org.jfree.chart.util.BooleanList var1 = new org.jfree.chart.util.BooleanList();
//     boolean var3 = var1.equals((java.lang.Object)"Combined Range XYPlot");
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     long var7 = var6.getMiddleMillisecond();
//     org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("10", (org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var6);
//     var8.setMinorTickMarkInsideLength((-1.0f));
//     boolean var11 = var8.isMinorTickMarksVisible();
//     java.util.TimeZone var12 = var8.getTimeZone();
//     org.jfree.data.xy.DefaultXYDataset var13 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot();
//     var14.setBackgroundAlpha(1.0f);
//     var13.addChangeListener((org.jfree.data.general.DatasetChangeListener)var14);
//     int var19 = var13.indexOf((java.lang.Comparable)'a');
//     java.lang.Number var20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var13);
//     org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var25 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     java.util.List var26 = var25.getItems();
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var29 = var28.getAxisLineStroke();
//     var28.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var33 = var28.getTickLabelFont();
//     org.jfree.data.Range var34 = var28.getDefaultAutoRange();
//     org.jfree.chart.ui.Library var39 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var40 = var39.getLicenceName();
//     boolean var41 = var34.equals((java.lang.Object)var39);
//     org.jfree.data.Range var43 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var13, var26, var34, false);
//     var8.setRangeWithMargins(var34);
//     boolean var45 = var1.equals((java.lang.Object)var8);
//     java.util.Locale var46 = var8.getLocale();
//     java.text.NumberFormat var47 = java.text.NumberFormat.getInstance(var46);
//     java.text.NumberFormat var48 = java.text.NumberFormat.getIntegerInstance(var46);
//     java.util.ResourceBundle.Control var49 = null;
//     java.util.ResourceBundle var50 = java.util.ResourceBundle.getBundle("Category Plot", var46, var49);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var2 = var1.getMaximumDate();
//     long var3 = var0.toTimelineValue(var2);
//     long var4 = var0.getStartTime();
//     java.util.Date var6 = var0.getDate((-2208898800000L));
//     int var7 = var0.getGroupSegmentCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1577894400001L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2208960000000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var7 = var6.getTickLabelPaint();
    int var8 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.util.Layer var9 = null;
    java.util.Collection var10 = var0.getRangeMarkers(var9);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
    var15.setBackgroundAlpha(1.0f);
    boolean var18 = var14.hasListener((java.util.EventListener)var15);
    java.awt.Shape var19 = var14.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var22 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var12, var19, "hi!", "hi!");
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var25 = var24.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var28 = var27.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var31 = var30.getAxisLineStroke();
    var30.resizeRange2(0.0d, 10.0d);
    java.awt.Font var35 = var30.getTickLabelFont();
    org.jfree.data.Range var36 = var30.getDefaultAutoRange();
    boolean var37 = var30.isAutoTickUnitSelection();
    java.awt.Paint var38 = var30.getTickLabelPaint();
    var27.setBackgroundPaint(var38);
    boolean var40 = var24.equals((java.lang.Object)var38);
    org.jfree.chart.entity.TitleEntity var42 = new org.jfree.chart.entity.TitleEntity(var19, (org.jfree.chart.title.Title)var24, "AxisLabelEntity: label = null");
    java.awt.Shape var43 = var42.getArea();
    org.jfree.chart.axis.NumberTickUnit var45 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var48 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var48.add(10.0d, (-1.0d), true);
    double var53 = var48.getMinX();
    org.jfree.data.xy.XYSeriesCollection var54 = new org.jfree.data.xy.XYSeriesCollection(var48);
    org.jfree.data.Range var56 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var54, false);
    org.jfree.chart.entity.XYItemEntity var61 = new org.jfree.chart.entity.XYItemEntity(var43, (org.jfree.data.xy.XYDataset)var54, 13, 0, "10", "PieLabelLinkStyle.STANDARD");
    var54.setIntervalWidth(0.0d);
    org.jfree.data.Range var64 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var54);
    org.jfree.chart.axis.DateAxis var66 = new org.jfree.chart.axis.DateAxis("ThreadContext");
    var66.configure();
    org.jfree.chart.renderer.PolarItemRenderer var68 = null;
    org.jfree.chart.plot.PolarPlot var69 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var54, (org.jfree.chart.axis.ValueAxis)var66, var68);
    var0.setDataset(10, (org.jfree.data.xy.XYDataset)var54);
    org.jfree.data.Range var72 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var54, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.valueToJava2D(1.0d, var3, var4);
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var8 = var7.getAxisLineStroke();
    var7.resizeRange2(0.0d, 10.0d);
    java.awt.Font var12 = var7.getTickLabelFont();
    org.jfree.data.Range var13 = var7.getDefaultAutoRange();
    boolean var14 = var7.isAutoTickUnitSelection();
    java.awt.Paint var15 = var7.getTickLabelPaint();
    var7.resizeRange((-1.0d));
    float var18 = var7.getMinorTickMarkInsideLength();
    java.awt.Shape var19 = var7.getLeftArrow();
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var26 = var25.getAxisLineStroke();
    var25.resizeRange2(0.0d, 10.0d);
    java.awt.Font var30 = var25.getTickLabelFont();
    org.jfree.chart.axis.MarkerAxisBand var31 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var7, 0.0d, 1.0E-100d, 1.0E-5d, 1.0000230261160271E-4d, var30);
    var1.setLabelFont(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var37 = var35.lookupSeriesPaint(10);
    java.awt.Stroke var39 = var35.lookupSeriesOutlineStroke(13);
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var44 = var42.lookupSeriesPaint(10);
    java.awt.Stroke var46 = var42.lookupSeriesOutlineStroke(13);
    var35.setBaseStroke(var46);
    java.awt.Paint var49 = var35.getSeriesFillPaint(0);
    org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot();
    double var51 = var50.getMinimumArcAngleToDraw();
    java.awt.Color var55 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var56 = var55.brighter();
    var50.setBaseSectionOutlinePaint((java.awt.Paint)var56);
    var35.setBasePaint((java.awt.Paint)var56, false);
    org.jfree.chart.text.TextFragment var60 = new org.jfree.chart.text.TextFragment("Category Plot", var30, (java.awt.Paint)var56);
    java.lang.String var61 = var60.getText();
    java.awt.Font var62 = var60.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "Category Plot"+ "'", var61.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(15);
    java.awt.Shape var2 = var1.getLegendArea();
    org.jfree.chart.title.Title var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TitleEntity var4 = new org.jfree.chart.entity.TitleEntity(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(68, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.setNotify(false);
    var5.setNotify(false);
    var5.setTextAntiAlias(true);
    var5.setBorderVisible(false);
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var20 = var19.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var21 = var19.getTickLabelInsets();
    double var23 = var21.trimHeight(1.0E-5d);
    double var25 = var21.calculateBottomInset(1.0E-8d);
    org.jfree.chart.text.TextBlock var26 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var27 = var26.getLineAlignment();
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("");
    java.lang.Object var30 = var29.clone();
    var29.setDescription("");
    boolean var33 = var26.equals((java.lang.Object)"");
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.util.Size2D var35 = var26.calculateDimensions(var34);
    org.jfree.chart.plot.CombinedDomainXYPlot var38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var38.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var42 = var38.getOrientation();
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var38);
    var43.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var45 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot();
    var46.setBackgroundAlpha(1.0f);
    var45.addChangeListener((org.jfree.data.general.DatasetChangeListener)var46);
    java.awt.Paint var50 = var46.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var53 = null;
    var46.handleClick((-398), 0, var53);
    org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46);
    var43.addLegend(var55);
    java.awt.Color var60 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var61 = var60.brighter();
    var55.setBackgroundPaint((java.awt.Paint)var60);
    org.jfree.chart.util.RectangleAnchor var63 = var55.getLegendItemGraphicLocation();
    org.jfree.chart.ui.Library var68 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var69 = var68.getLicenceName();
    java.lang.String var70 = var68.getLicenceName();
    boolean var71 = var63.equals((java.lang.Object)var70);
    java.awt.geom.Rectangle2D var72 = org.jfree.chart.util.RectangleAnchor.createRectangle(var35, (-3.99999d), 5.0d, var63);
    var21.trim(var72);
    var18.setChartArea(var72);
    org.jfree.chart.RenderingSource var75 = null;
    var18.setRenderingSource(var75);
    org.jfree.chart.entity.EntityCollection var77 = null;
    var18.setEntityCollection(var77);
    java.awt.image.BufferedImage var79 = var5.createBufferedImage(2, 31, 0.08d, 0.0d, var18);
    org.jfree.chart.plot.PlotRenderingInfo var80 = var18.getPlotInfo();
    org.jfree.chart.renderer.xy.XYAreaRenderer var81 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.plot.XYPlot var82 = var81.getPlot();
    var81.removeAnnotations();
    org.jfree.chart.plot.RingPlot var85 = new org.jfree.chart.plot.RingPlot();
    double var86 = var85.getMinimumArcAngleToDraw();
    java.awt.Stroke var87 = var85.getLabelOutlineStroke();
    var81.setSeriesStroke(255, var87);
    var81.setBaseItemLabelsVisible(false, true);
    java.awt.Paint var93 = var81.getSeriesItemLabelPaint((-16777216));
    boolean var94 = var18.equals((java.lang.Object)var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-3.99999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "hi!"+ "'", var69.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var70 + "' != '" + "hi!"+ "'", var70.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setBackgroundAlpha(1.0f);
//     boolean var6 = var2.hasListener((java.util.EventListener)var3);
//     java.awt.Shape var7 = var2.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
//     java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var15 = var14.brighter();
//     org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var7, (java.awt.Paint)var14);
//     java.awt.Shape var17 = var16.getLine();
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"4", "Combined_Domain_XYPlot", "PlotOrientation.HORIZONTAL");
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     long var23 = var22.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var24 = var22.previous();
//     var21.add((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)100.0f, false);
//     boolean var28 = var16.equals((java.lang.Object)false);
//     java.awt.Stroke var29 = var16.getLineStroke();
//     org.jfree.chart.block.BlockFrame var30 = var16.getFrame();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    var0.draw(var1, 2.0f, 100.0f, var4, 100.0f, (-1.0f), 2.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var12 = var11.getAutoPopulateSeriesFillPaint();
    double var13 = var11.getLowerClip();
    org.jfree.chart.ChartColor var17 = new org.jfree.chart.ChartColor(10, 100, 1);
    var11.setBasePaint((java.awt.Paint)var17);
    java.awt.Font var19 = var11.getBaseItemLabelFont();
    boolean var20 = var0.equals((java.lang.Object)var11);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
    var24.setBackgroundAlpha(1.0f);
    boolean var27 = var23.hasListener((java.util.EventListener)var24);
    java.awt.Shape var28 = var23.getLeftArrow();
    double var29 = var23.getLowerBound();
    java.awt.Paint var30 = var23.getTickLabelPaint();
    var21.setRangeMinorGridlinePaint(var30);
    var11.setPlot(var21);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var36 = var35.getAutoPopulateSeriesFillPaint();
    double var37 = var35.getLowerClip();
    var35.setShadowYOffset(1.0E-5d);
    double var40 = var35.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var41 = var35.getPositiveItemLabelPositionFallback();
    var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var46 = var45.getAutoPopulateSeriesFillPaint();
    double var47 = var45.getLowerClip();
    var45.setShadowYOffset(1.0E-5d);
    double var50 = var45.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var52 = null;
    var45.setSeriesNegativeItemLabelPosition(1, var52);
    org.jfree.chart.axis.NumberAxis3D var55 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var56 = var55.getAxisLineStroke();
    java.awt.Font var57 = var55.getLabelFont();
    var45.setBaseItemLabelFont(var57);
    var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var45, false);
    var21.clearDomainMarkers(10);
    org.jfree.chart.axis.AxisLocation var64 = null;
    var21.setRangeAxisLocation(3, var64, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    org.jfree.chart.plot.CrosshairState var6 = null;
    boolean var7 = var1.render(var2, var3, 0, var5, var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("TitleEntity: tooltip = AxisLabelEntity: label = null", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.LegendTitle var9 = var8.getLegend();
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("");
    int var12 = var11.getMaximumLinesToDisplay();
    var8.setTitle(var11);
    boolean var14 = var8.isNotify();
    org.jfree.chart.event.ChartProgressListener var15 = null;
    var8.removeProgressListener(var15);
    org.jfree.chart.ChartRenderingInfo var21 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.image.BufferedImage var22 = var8.createBufferedImage(255, 255, (-1.0d), 5.0d, var21);
    org.jfree.chart.plot.XYPlot var23 = var8.getXYPlot();
    var8.clearSubtitles();
    float var25 = var8.getBackgroundImageAlpha();
    var8.setTextAntiAlias(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.5f);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(255);
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var7 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var7.add(10.0d, (-1.0d), true);
    double var12 = var7.getMinX();
    org.jfree.data.xy.XYSeriesCollection var13 = new org.jfree.data.xy.XYSeriesCollection(var7);
    org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var13, true);
    boolean var16 = var13.isAutoWidth();
    org.jfree.data.xy.DefaultXYDataset var17 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot();
    var18.setBackgroundAlpha(1.0f);
    var17.addChangeListener((org.jfree.data.general.DatasetChangeListener)var18);
    int var23 = var17.indexOf((java.lang.Comparable)'a');
    java.lang.Number var24 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var17);
    org.jfree.chart.axis.NumberTickUnit var26 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var29 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var30 = var29.getItems();
    org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var33 = var32.getAxisLineStroke();
    var32.resizeRange2(0.0d, 10.0d);
    java.awt.Font var37 = var32.getTickLabelFont();
    org.jfree.data.Range var38 = var32.getDefaultAutoRange();
    org.jfree.chart.ui.Library var43 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var44 = var43.getLicenceName();
    boolean var45 = var38.equals((java.lang.Object)var43);
    org.jfree.data.Range var47 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var17, var30, var38, false);
    org.jfree.data.Range var50 = new org.jfree.data.Range(0.0d, 0.0d);
    double var51 = var50.getLowerBound();
    org.jfree.data.Range var53 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var13, var30, var50, false);
    org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(255);
    int var56 = var13.indexOf((java.lang.Comparable)var55);
    boolean var57 = var2.isBefore((org.jfree.data.time.SerialDate)var55);
    int var58 = var2.getDayOfMonth();
    org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(255);
    java.lang.String var61 = var60.toString();
    java.util.Date var62 = var60.toDate();
    java.lang.String var63 = var60.getDescription();
    boolean var64 = var2.isBefore((org.jfree.data.time.SerialDate)var60);
    org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.addDays(3, (org.jfree.data.time.SerialDate)var60);
    int var66 = var60.getYYYY();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "hi!"+ "'", var44.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "11-September-1900"+ "'", var61.equals("11-September-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1900);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var4.add(10.0d, (-1.0d), true);
    double var9 = var4.getMinX();
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var4);
    org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var10, true);
    boolean var13 = var10.isAutoWidth();
    org.jfree.data.xy.DefaultXYDataset var14 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
    var15.setBackgroundAlpha(1.0f);
    var14.addChangeListener((org.jfree.data.general.DatasetChangeListener)var15);
    int var20 = var14.indexOf((java.lang.Comparable)'a');
    java.lang.Number var21 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var14);
    org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var26 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var27 = var26.getItems();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var30 = var29.getAxisLineStroke();
    var29.resizeRange2(0.0d, 10.0d);
    java.awt.Font var34 = var29.getTickLabelFont();
    org.jfree.data.Range var35 = var29.getDefaultAutoRange();
    org.jfree.chart.ui.Library var40 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var41 = var40.getLicenceName();
    boolean var42 = var35.equals((java.lang.Object)var40);
    org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var14, var27, var35, false);
    org.jfree.data.Range var47 = new org.jfree.data.Range(0.0d, 0.0d);
    double var48 = var47.getLowerBound();
    org.jfree.data.Range var50 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var10, var27, var47, false);
    java.util.List var51 = var10.getSeries();
    var10.setIntervalWidth(1.0d);
    org.jfree.data.Range var55 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "hi!"+ "'", var41.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var4.add(10.0d, (-1.0d), true);
    double var9 = var4.getMinX();
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var4);
    org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var10, true);
    boolean var13 = var10.isAutoWidth();
    org.jfree.data.xy.DefaultXYDataset var14 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
    var15.setBackgroundAlpha(1.0f);
    var14.addChangeListener((org.jfree.data.general.DatasetChangeListener)var15);
    int var20 = var14.indexOf((java.lang.Comparable)'a');
    java.lang.Number var21 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var14);
    org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var26 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var27 = var26.getItems();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var30 = var29.getAxisLineStroke();
    var29.resizeRange2(0.0d, 10.0d);
    java.awt.Font var34 = var29.getTickLabelFont();
    org.jfree.data.Range var35 = var29.getDefaultAutoRange();
    org.jfree.chart.ui.Library var40 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var41 = var40.getLicenceName();
    boolean var42 = var35.equals((java.lang.Object)var40);
    org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var14, var27, var35, false);
    org.jfree.data.Range var47 = new org.jfree.data.Range(0.0d, 0.0d);
    double var48 = var47.getLowerBound();
    org.jfree.data.Range var50 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var10, var27, var47, false);
    double var52 = var10.getRangeLowerBound(true);
    org.jfree.data.Range var54 = var10.getDomainBounds(true);
    org.jfree.data.Range var55 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYSeries var57 = var10.getSeries(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "hi!"+ "'", var41.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Paint var3 = var2.getLabelPaint();
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.plot.XYPlot var5 = var4.getPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.lang.String var7 = var6.getPlotType();
    var4.setPlot((org.jfree.chart.plot.XYPlot)var6);
    org.jfree.chart.labels.XYSeriesLabelGenerator var9 = null;
    var4.setLegendItemURLGenerator(var9);
    var4.removeAnnotations();
    org.jfree.chart.LegendItemCollection var12 = var4.getLegendItems();
    org.jfree.chart.labels.ItemLabelPosition var14 = var4.getSeriesPositiveItemLabelPosition(1);
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var17 = var16.getLinePaint();
    boolean var18 = var16.isShapeOutlineVisible();
    java.lang.String var19 = var16.getDescription();
    org.jfree.chart.util.GradientPaintTransformer var20 = var16.getFillPaintTransformer();
    var4.setGradientTransformer(var20);
    var2.setGradientPaintTransformer(var20);
    org.jfree.chart.util.LengthAdjustmentType var23 = var2.getLabelOffsetType();
    java.awt.Paint var24 = var2.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setAlpha(2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Combined_Domain_XYPlot"+ "'", var7.equals("Combined_Domain_XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     boolean var5 = var0.isDomainMinorGridlinesVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     var0.setRenderer(1, var7);
//     org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var10 = var9.getRangeMinorGridlinePaint();
//     boolean var11 = var9.isRangeMinorGridlinesVisible();
//     var9.setBackgroundImageAlignment(2147483647);
//     org.jfree.data.xy.DefaultXYDataset var14 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
//     var15.setBackgroundAlpha(1.0f);
//     var14.addChangeListener((org.jfree.data.general.DatasetChangeListener)var15);
//     int var20 = var14.indexOf((java.lang.Comparable)'a');
//     org.jfree.data.xy.IntervalXYDelegate var21 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var14);
//     int var22 = var9.indexOf((org.jfree.data.xy.XYDataset)var14);
//     org.jfree.chart.axis.NumberTickUnit var24 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     double var28 = var27.getMinX();
//     java.beans.PropertyChangeListener var29 = null;
//     var27.removePropertyChangeListener(var29);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     var27.setKey((java.lang.Comparable)var31);
//     org.jfree.data.xy.DefaultXYDataset var33 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.data.Range var35 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var33, true);
//     org.jfree.data.xy.IntervalXYDelegate var36 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var33);
//     int var37 = var33.getSeriesCount();
//     java.lang.Object var38 = var33.clone();
//     var27.addChangeListener((org.jfree.data.general.SeriesChangeListener)var33);
//     boolean var40 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var33);
//     var9.setDataset((org.jfree.data.xy.XYDataset)var33);
//     var0.setDataset((org.jfree.data.xy.XYDataset)var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == true);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var0.setUseOutlinePaint(true);
    boolean var3 = var0.getDrawSeriesLineAsPath();
    org.jfree.chart.text.TextBlock var4 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
    var9.setBackgroundAlpha(1.0f);
    boolean var12 = var8.hasListener((java.util.EventListener)var9);
    java.awt.Shape var13 = var8.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var16 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var6, var13, "hi!", "hi!");
    double var17 = var6.getUpperMargin();
    java.awt.Font var18 = var6.getLabelFont();
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var23 = var22.brighter();
    var4.addLine("", var18, (java.awt.Paint)var23);
    java.awt.Color var28 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var32 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var33 = var28.getColorComponents(var32);
    java.awt.color.ColorSpace var34 = var28.getColorSpace();
    java.awt.Color var38 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var42 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var43 = var38.getColorComponents(var42);
    java.awt.color.ColorSpace var44 = var38.getColorSpace();
    java.awt.Color var48 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var52 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var53 = var48.getColorComponents(var52);
    float[] var54 = var38.getRGBColorComponents(var52);
    float[] var55 = var23.getColorComponents(var34, var52);
    var0.setBaseOutlinePaint((java.awt.Paint)var23);
    org.jfree.chart.urls.StandardXYURLGenerator var58 = new org.jfree.chart.urls.StandardXYURLGenerator();
    var0.setSeriesURLGenerator(0, (org.jfree.chart.urls.XYURLGenerator)var58, false);
    var0.setBaseShapesFilled(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var3.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(6.0d, var3);
    org.jfree.chart.block.RectangleConstraint var6 = var5.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var8 = var6.toFixedHeight(1.0000230261160271E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    var0.setBackgroundImageAlignment(2147483647);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation();
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var9 = var8.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var12 = var11.getRangeMinorGridlinePaint();
    boolean var13 = var11.isRangeMinorGridlinesVisible();
    var11.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.PlotOrientation var16 = var11.getOrientation();
    var10.setOrientation(var16);
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var20 = var19.getAxisLineStroke();
    var19.resizeRange2(0.0d, 10.0d);
    java.awt.Font var24 = var19.getTickLabelFont();
    org.jfree.data.Range var25 = var19.getDefaultAutoRange();
    boolean var26 = var19.isAutoTickUnitSelection();
    java.awt.Stroke var27 = var19.getTickMarkStroke();
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var19);
    org.jfree.chart.plot.IntervalMarker var31 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var32 = var31.getOutlineStroke();
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot();
    var33.setBackgroundAlpha(1.0f);
    java.awt.Paint var36 = var33.getBackgroundPaint();
    var31.setPaint(var36);
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var31);
    org.jfree.chart.util.Layer var39 = null;
    boolean var40 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var31, var39);
    int var41 = var0.getRendererCount();
    org.jfree.chart.plot.PiePlot3D var42 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.data.general.PieDataset var43 = null;
    var42.setDataset(var43);
    var42.setDarkerSides(true);
    org.jfree.chart.labels.PieSectionLabelGenerator var47 = null;
    var42.setLegendLabelToolTipGenerator(var47);
    org.jfree.chart.plot.AbstractPieLabelDistributor var49 = var42.getLabelDistributor();
    org.jfree.chart.event.PlotChangeEvent var50 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var42);
    var0.plotChanged(var50);
    org.jfree.chart.plot.Plot var52 = var50.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var7 = var6.getTickLabelPaint();
    int var8 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
    var6.setFixedDimension((-5.99999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var4.add(10.0d, (-1.0d), true);
    double var9 = var4.getMinX();
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var4);
    org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var10, true);
    boolean var13 = var10.isAutoWidth();
    org.jfree.data.xy.DefaultXYDataset var14 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
    var15.setBackgroundAlpha(1.0f);
    var14.addChangeListener((org.jfree.data.general.DatasetChangeListener)var15);
    int var20 = var14.indexOf((java.lang.Comparable)'a');
    java.lang.Number var21 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var14);
    org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var26 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var27 = var26.getItems();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var30 = var29.getAxisLineStroke();
    var29.resizeRange2(0.0d, 10.0d);
    java.awt.Font var34 = var29.getTickLabelFont();
    org.jfree.data.Range var35 = var29.getDefaultAutoRange();
    org.jfree.chart.ui.Library var40 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var41 = var40.getLicenceName();
    boolean var42 = var35.equals((java.lang.Object)var40);
    org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var14, var27, var35, false);
    org.jfree.data.Range var47 = new org.jfree.data.Range(0.0d, 0.0d);
    double var48 = var47.getLowerBound();
    org.jfree.data.Range var50 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var10, var27, var47, false);
    org.jfree.data.general.SeriesChangeInfo var51 = null;
    org.jfree.data.general.SeriesChangeEvent var52 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)false, var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "hi!"+ "'", var41.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    boolean var2 = var0.isRangeMinorGridlinesVisible();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
    java.awt.Paint var6 = var0.getRangeTickBandPaint();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var11 = var10.getAutoPopulateSeriesFillPaint();
    double var12 = var10.getLowerClip();
    org.jfree.chart.ChartColor var16 = new org.jfree.chart.ChartColor(10, 100, 1);
    var10.setBasePaint((java.awt.Paint)var16);
    java.awt.Font var18 = var10.getBaseItemLabelFont();
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var20 = var19.getRangeMinorGridlinePaint();
    boolean var21 = var19.isRangeMinorGridlinesVisible();
    var19.setBackgroundImageAlignment(2147483647);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("TitleEntity: tooltip = AxisLabelEntity: label = null", var18, (org.jfree.chart.plot.Plot)var19, true);
    org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var25, 9, 2014);
    var25.setTitle("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("AxisLabelEntity: label = null");
    var1.setToolTipText("DomainOrder.NONE");

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    java.lang.String var2 = var1.getName();
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var3.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var7 = var3.getOrientation();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    var8.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var10 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
    var11.setBackgroundAlpha(1.0f);
    var10.addChangeListener((org.jfree.data.general.DatasetChangeListener)var11);
    java.awt.Paint var15 = var11.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    var11.handleClick((-398), 0, var18);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    var8.addLegend(var20);
    java.awt.Color var25 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var26 = var25.brighter();
    var20.setBackgroundPaint((java.awt.Paint)var25);
    java.awt.Font var28 = var20.getItemFont();
    double var29 = var20.getHeight();
    org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var31 = var30.getRangeMinorGridlinePaint();
    var30.clearRangeMarkers(1);
    org.jfree.chart.plot.IntervalMarker var37 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var38 = var37.getOutlineStroke();
    java.awt.Stroke var39 = var37.getOutlineStroke();
    org.jfree.chart.util.Layer var40 = null;
    var30.addRangeMarker(10, (org.jfree.chart.plot.Marker)var37, var40, true);
    org.jfree.chart.plot.IntervalMarker var46 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 1.0d);
    org.jfree.chart.util.Layer var47 = null;
    boolean var49 = var30.removeDomainMarker(13, (org.jfree.chart.plot.Marker)var46, var47, true);
    org.jfree.chart.axis.ValueAxis var51 = var30.getRangeAxis(0);
    java.awt.Paint var52 = var30.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var53 = var30.getInsets();
    var20.setLegendItemGraphicPadding(var53);
    var1.setAxisOffset(var53);
    double var56 = var53.getTop();
    double var58 = var53.calculateLeftInset(9.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + " version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var2.equals(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 8.0d);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var1 = var0.getStartTime();
//     boolean var4 = var0.containsDomainRange(1L, 1L);
//     int var5 = var0.getSegmentsExcluded();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-2208927600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 68);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    org.jfree.chart.LegendItemCollection var2 = var0.getFixedLegendItems();
    int var3 = var0.getRangeAxisCount();
    int var4 = var0.getDomainAxisCount();
    var0.setDomainCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation(1);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var12 = var11.getMaximumDate();
    var10.setMinimumDate(var12);
    org.jfree.data.Range var14 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var0.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }
// 
// 
//     java.util.TimeZone var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     double var3 = var1.getDomainLowerBound(false);
//     var1.removeAllSeries();
//     org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var7 = var6.getRangeMinorGridlinePaint();
//     boolean var8 = var6.isRangeMinorGridlinesVisible();
//     var6.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.PlotOrientation var11 = var6.getOrientation();
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var15 = var14.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var18 = var17.getAxisLineStroke();
//     var14.setBaseOutlineStroke(var18, false);
//     var6.setDomainCrosshairStroke(var18);
//     var5.setLabelOutlineStroke(var18);
//     boolean var23 = var1.equals((java.lang.Object)var18);
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"4", "Combined_Domain_XYPlot", "PlotOrientation.HORIZONTAL");
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var28.previous();
//     var27.add((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)100.0f, false);
//     var1.addSeries(var27);
//     int var35 = var1.getSeriesCount();
//     org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D();
//     var36.configure();
//     var36.configure();
//     float var39 = var36.getMaximumCategoryLabelWidthRatio();
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     long var43 = var42.getMiddleMillisecond();
//     org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("10", (org.jfree.data.time.RegularTimePeriod)var41, (org.jfree.data.time.RegularTimePeriod)var42);
//     org.jfree.chart.plot.CombinedDomainXYPlot var45 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var45.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var49 = var45.getOrientation();
//     org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var45);
//     int var51 = var42.compareTo((java.lang.Object)var50);
//     java.awt.Font var52 = var36.getTickLabelFont((java.lang.Comparable)var42);
//     int var53 = var1.indexOf((java.lang.Comparable)var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-1));
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var3 = var2.getMaximumDate();
//     long var4 = var1.toTimelineValue(var3);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     long var8 = var7.getMiddleMillisecond();
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("10", (org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var7);
//     var9.setMinorTickMarkInsideLength((-1.0f));
//     boolean var12 = var9.isMinorTickMarksVisible();
//     java.util.TimeZone var13 = var9.getTimeZone();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var3, var13);
//     org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var13);
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("4", var13);
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var18 = var17.getMaximumDate();
//     var16.setMaximumDate(var18);
//     double var20 = var16.getUpperMargin();
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
//     var24.setBackgroundAlpha(1.0f);
//     boolean var27 = var23.hasListener((java.util.EventListener)var24);
//     java.awt.Shape var28 = var23.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var31 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var21, var28, "hi!", "hi!");
//     double var32 = var21.getUpperMargin();
//     java.awt.Font var33 = var21.getLabelFont();
//     java.awt.Paint var34 = var21.getTickLabelPaint();
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var37 = var36.clone();
//     var36.setDescription("");
//     java.awt.Stroke var40 = var36.getOutlineStroke();
//     org.jfree.chart.plot.CombinedDomainXYPlot var41 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var41.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var45 = var41.getOrientation();
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var41);
//     org.jfree.chart.axis.AxisSpace var47 = null;
//     var41.setFixedRangeAxisSpace(var47);
//     java.awt.Paint var49 = var41.getRangeMinorGridlinePaint();
//     org.jfree.chart.util.RectangleInsets var54 = new org.jfree.chart.util.RectangleInsets(1.0E-5d, 0.0d, 1.0d, Double.NaN);
//     var41.setInsets(var54);
//     org.jfree.chart.block.LineBorder var56 = new org.jfree.chart.block.LineBorder(var34, var40, var54);
//     org.jfree.chart.util.RectangleInsets var57 = var56.getInsets();
//     java.awt.Stroke var58 = var56.getStroke();
//     var16.setAxisLineStroke(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1577894400001L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    double var4 = var0.valueToJava2D(1.0d, var2, var3);
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.ChartColor var11 = new org.jfree.chart.ChartColor(10, 100, 1);
    int var12 = var11.getAlpha();
    boolean var13 = var7.equals((java.lang.Object)var12);
    var0.setRange(var7, false, true);
    var0.configure();
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    org.jfree.chart.axis.DateTickUnit var20 = var19.getTickUnit();
    java.util.Date var21 = var0.calculateHighestVisibleTickValue(var20);
    org.jfree.chart.axis.DateTickUnitType var22 = var20.getUnitType();
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var25 = var24.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var29 = var28.getAxisLineStroke();
    boolean var30 = var28.isAutoRange();
    org.jfree.data.Range var33 = new org.jfree.data.Range(0.0d, 0.0d);
    double var34 = var33.getLowerBound();
    var28.setRangeWithMargins(var33, false, false);
    float var38 = var28.getMinorTickMarkInsideLength();
    org.jfree.data.Range var39 = var26.getDataRange((org.jfree.chart.axis.ValueAxis)var28);
    org.jfree.data.xy.DefaultXYDataset var40 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot();
    var41.setBackgroundAlpha(1.0f);
    var40.addChangeListener((org.jfree.data.general.DatasetChangeListener)var41);
    int var46 = var40.indexOf((java.lang.Comparable)'a');
    org.jfree.data.xy.IntervalXYDelegate var47 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var40);
    boolean var48 = var26.equals((java.lang.Object)var47);
    java.awt.Image var49 = var26.getBackgroundImage();
    var26.zoom(45.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var52 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var53 = var52.getRangeMinorGridlinePaint();
    var52.clearRangeMarkers(1);
    java.awt.Paint var56 = var52.getRangeZeroBaselinePaint();
    java.awt.Stroke var57 = var52.getDomainCrosshairStroke();
    var26.setDomainMinorGridlineStroke(var57);
    boolean var59 = var22.equals((java.lang.Object)var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.data.general.PieDataset var1 = null;
    var0.setDataset(var1);
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var3.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var7 = var3.getOrientation();
    org.jfree.chart.plot.IntervalMarker var10 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var11 = var10.getOutlineStroke();
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot();
    var12.setBackgroundAlpha(1.0f);
    java.awt.Paint var15 = var12.getBackgroundPaint();
    var10.setPaint(var15);
    var3.setRangeMinorGridlinePaint(var15);
    int var18 = var3.getWeight();
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var21 = var20.getAxisLineStroke();
    boolean var22 = var20.isAutoRange();
    java.awt.Shape var23 = var20.getLeftArrow();
    int var24 = var3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var20);
    org.jfree.chart.util.RectangleEdge var25 = var3.getRangeAxisEdge();
    var3.clearDomainMarkers();
    var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var3);
    var0.setLabelGap(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    boolean var5 = var0.isDomainMinorGridlinesVisible();
    boolean var6 = var0.canSelectByPoint();
    java.awt.Paint var7 = var0.getRangeGridlinePaint();
    java.lang.String var8 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Combined_Domain_XYPlot"+ "'", var8.equals("Combined_Domain_XYPlot"));

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
//     org.jfree.chart.plot.PieLabelLinkStyle var5 = var2.getLabelLinkStyle();
//     java.lang.String var6 = var5.toString();
//     var1.setLabelLinkStyle(var5);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var10 = var9.getAxisLineStroke();
//     java.awt.Font var11 = var9.getLabelFont();
//     var1.setLargeFont(var11);
//     org.jfree.chart.ChartColor var16 = new org.jfree.chart.ChartColor(10, 100, 1);
//     int var17 = var16.getAlpha();
//     var1.setShadowPaint((java.awt.Paint)var16);
//     org.jfree.chart.renderer.xy.XYBarPainter var19 = var1.getXYBarPainter();
//     org.jfree.data.xy.DefaultXYDataset var20 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot();
//     var21.setBackgroundAlpha(1.0f);
//     var20.addChangeListener((org.jfree.data.general.DatasetChangeListener)var21);
//     java.awt.Paint var25 = var21.getAngleGridlinePaint();
//     var1.setLegendItemPaint(var25);
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot();
//     var30.setBackgroundAlpha(1.0f);
//     boolean var33 = var29.hasListener((java.util.EventListener)var30);
//     java.awt.Shape var34 = var29.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var37 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var27, var34, "hi!", "hi!");
//     java.awt.Color var41 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var42 = var41.brighter();
//     org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var34, (java.awt.Paint)var41);
//     org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var46 = var45.getAxisLineStroke();
//     var45.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var50 = var45.getTickLabelFont();
//     org.jfree.data.Range var51 = var45.getDefaultAutoRange();
//     boolean var52 = var45.isAutoTickUnitSelection();
//     java.awt.Stroke var53 = var45.getTickMarkStroke();
//     org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var55 = var54.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var56 = var54.getTickLabelInsets();
//     double var57 = var56.getBottom();
//     org.jfree.chart.util.UnitType var58 = var56.getUnitType();
//     org.jfree.chart.block.LineBorder var59 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var41, var53, var56);
//     var1.setAxisOffset(var56);
//     
//     // Checks the contract:  equals-hashcode on var21 and var30
//     assertTrue("Contract failed: equals-hashcode on var21 and var30", var21.equals(var30) ? var21.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var21
//     assertTrue("Contract failed: equals-hashcode on var30 and var21", var30.equals(var21) ? var30.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    boolean var6 = var2.hasListener((java.util.EventListener)var3);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
    java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var7, (java.awt.Paint)var14);
    java.awt.Stroke var17 = var16.getOutlineStroke();
    org.jfree.chart.util.GradientPaintTransformer var18 = var16.getFillPaintTransformer();
    java.awt.Paint var19 = var16.getFillPaint();
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var21 = var20.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var22 = var20.getTickLabelInsets();
    double var23 = var22.getBottom();
    double var24 = var22.getTop();
    double var26 = var22.extendHeight(6.12E7d);
    var16.setPadding(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 6.1200004E7d);

  }

}
