
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Shape var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.XYItemEntity var6 = new org.jfree.chart.entity.XYItemEntity(var0, var1, (-1), 0, "", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Paint var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.awt.Paint var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var1 = new org.jfree.chart.block.BlockBorder(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 100.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     org.jfree.data.time.RegularTimePeriod var1 = null;
//     org.jfree.data.time.RegularTimePeriod var2 = null;
//     org.jfree.chart.axis.PeriodAxis var3 = new org.jfree.chart.axis.PeriodAxis("", var1, var2);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, (-1.0f), 100.0f, 0.0d, 0.0f, 100.0f);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.util.RectangleInsets var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.0d, (-1.0d), 0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.LineUtilities.clipLine(var0, var1);
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(var0, 100);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", var1);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.clipLine(var0, var1);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var3 = var2.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
//     var4.setBackgroundAlpha(1.0f);
//     java.awt.Paint var7 = var4.getBackgroundPaint();
//     var2.setPaint(var7);
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var12 = var11.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot();
//     var13.setBackgroundAlpha(1.0f);
//     java.awt.Paint var16 = var13.getBackgroundPaint();
//     var11.setPaint(var16);
//     var2.setLabelPaint(var16);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)100);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var0, 100, 0.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.chart.axis.Axis var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.AxisChangeEvent var1 = new org.jfree.chart.event.AxisChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var3 = var2.getOutlineStroke();
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 100.0f);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    var0.setBackgroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getBackgroundPaint();
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
//     var2.setBackgroundAlpha(1.0f);
//     boolean var5 = var1.hasListener((java.util.EventListener)var2);
//     java.awt.Shape var6 = var1.getLeftArrow();
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.PlotEntity var8 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var7);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var2
//     assertTrue("Contract failed: equals-hashcode on var7 and var2", var7.equals(var2) ? var7.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
    var2.setBackgroundAlpha(1.0f);
    boolean var5 = var1.hasListener((java.util.EventListener)var2);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.JFreeChart var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var10 = new org.jfree.chart.entity.JFreeChartEntity(var6, var7, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setBackgroundAlpha(1.0f);
//     boolean var6 = var2.hasListener((java.util.EventListener)var3);
//     java.awt.Shape var7 = var2.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
//     org.jfree.data.xy.DefaultXYDataset var11 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot();
//     var12.setBackgroundAlpha(1.0f);
//     var11.addChangeListener((org.jfree.data.general.DatasetChangeListener)var12);
//     org.jfree.chart.entity.PlotEntity var17 = new org.jfree.chart.entity.PlotEntity(var7, (org.jfree.chart.plot.Plot)var12, "hi!");
//     
//     // Checks the contract:  equals-hashcode on var3 and var12
//     assertTrue("Contract failed: equals-hashcode on var3 and var12", var3.equals(var12) ? var3.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var3
//     assertTrue("Contract failed: equals-hashcode on var12 and var3", var12.equals(var3) ? var12.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    boolean var6 = var2.hasListener((java.util.EventListener)var3);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
    org.jfree.chart.title.Title var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TitleEntity var12 = new org.jfree.chart.entity.TitleEntity(var7, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(var0);
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getPercentInstance(var0);
// 
//   }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.util.LineUtilities var0 = new org.jfree.chart.util.LineUtilities();

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.text.DateFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
//     var2.setBackgroundAlpha(1.0f);
//     boolean var5 = var1.hasListener((java.util.EventListener)var2);
//     java.awt.Shape var6 = var1.getLeftArrow();
//     org.jfree.data.xy.DefaultXYDataset var7 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
//     var8.setBackgroundAlpha(1.0f);
//     var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
//     org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var8);
//     
//     // Checks the contract:  equals-hashcode on var2 and var8
//     assertTrue("Contract failed: equals-hashcode on var2 and var8", var2.equals(var8) ? var2.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var2
//     assertTrue("Contract failed: equals-hashcode on var8 and var2", var8.equals(var2) ? var8.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
//     var2.setBackgroundAlpha(1.0f);
//     boolean var5 = var1.hasListener((java.util.EventListener)var2);
//     java.awt.Paint var6 = var2.getAngleLabelPaint();
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     org.jfree.chart.ChartColor var11 = new org.jfree.chart.ChartColor(10, 100, 1);
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Color var16 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     float[] var20 = new float[] { 10.0f, (-1.0f), 100.0f};
//     float[] var21 = var16.getColorComponents(var20);
//     java.awt.color.ColorSpace var22 = var16.getColorSpace();
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var16};
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var26 = var25.getAxisLineStroke();
//     java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
//     org.jfree.chart.plot.IntervalMarker var30 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var31 = var30.getOutlineStroke();
//     java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot();
//     var35.setBackgroundAlpha(1.0f);
//     boolean var38 = var34.hasListener((java.util.EventListener)var35);
//     java.awt.Shape var39 = var34.getLeftArrow();
//     java.awt.Shape[] var40 = new java.awt.Shape[] { var39};
//     org.jfree.chart.plot.DefaultDrawingSupplier var41 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var12, var23, var27, var32, var40);
//     
//     // Checks the contract:  equals-hashcode on var2 and var35
//     assertTrue("Contract failed: equals-hashcode on var2 and var35", var2.equals(var35) ? var2.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var2
//     assertTrue("Contract failed: equals-hashcode on var35 and var2", var35.equals(var2) ? var35.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 1.0d, 10.0d, var3);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 1.0d, "", var3, var4, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-1));
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 0.0d, (-1.0d), var3);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 0.0d, var2);
// 
//   }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(-1L));
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-398));

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.data.xy.DefaultXYDataset var1 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var0.generateLabelString((org.jfree.data.xy.XYDataset)var1, 100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 1.0d, "hi!", var3, var4, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var5 = var4.getLicenceName();
    java.lang.String var6 = var4.getLicenceName();
    java.lang.String var7 = var4.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "hi!"+ "'", var6.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + ""+ "'", var7.equals(""));

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    var1.setBackgroundAlpha(1.0f);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
    int var6 = var0.indexOf((java.lang.Comparable)'a');
    java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var0);
    org.jfree.data.general.DatasetGroup var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setGroup(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.util.List var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var1, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
//     var2.setBackgroundAlpha(1.0f);
//     boolean var5 = var1.hasListener((java.util.EventListener)var2);
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.Point var9 = var2.translateValueThetaRadiusToJava2D(0.0d, Double.NaN, var8);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var1 = var0.getTickLabelFont();
    var0.setAxisLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    org.jfree.data.xy.IntervalXYDelegate var3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setIntervalPositionFactor(100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var3 = var0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit)var2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var3 = var2.getAxisLineStroke();
//     java.awt.Font var4 = var2.getLabelFont();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var7 = var6.getTickLabelPaint();
//     org.jfree.chart.text.TextMeasurer var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("Combined_Domain_XYPlot", var4, var7, (-1.0f), 0, var10);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYSeries var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(var0, 100.0d, 100.0d, 255, (java.lang.Comparable)(-398));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.setBackgroundAlpha(1.0f);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
//     org.jfree.chart.axis.TickUnit var5 = var1.getAngleTickUnit();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes(0.0d, var7, var8);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == true);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getCurrencyInstance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    var1.setBackgroundAlpha(1.0f);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(255, (-1), 255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Comparable var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var4 = var3.getAxisLineStroke();
    java.awt.Font var5 = var3.getLabelFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelFont(var1, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    var0.clearRangeMarkers(1);
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-1), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.data.Range var2 = new org.jfree.data.Range(Double.NaN, 10.0d);
//     
//     // Checks the contract:  var2.equals(var2)
//     assertTrue("Contract failed: var2.equals(var2)", var2.equals(var2));
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(short)100);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Paint var3 = var2.getLabelPaint();
//     org.jfree.chart.event.MarkerChangeEvent var4 = null;
//     var2.notifyListeners(var4);
//     java.awt.Stroke var6 = var2.getStroke();
//     java.lang.Class var7 = null;
//     java.util.EventListener[] var8 = var2.getListeners(var7);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    double var4 = var0.valueToJava2D(1.0d, var2, var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    java.awt.Paint var6 = var3.getBackgroundPaint();
    var2.setLabelPaint(var6);
    org.jfree.chart.text.TextAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelTextAnchor(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.data.time.RegularTimePeriod var1 = null;
//     org.jfree.data.time.RegularTimePeriod var2 = null;
//     org.jfree.chart.axis.PeriodAxis var3 = new org.jfree.chart.axis.PeriodAxis("Combined_Domain_XYPlot", var1, var2);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(0.0d, "", "", false);
    java.lang.Object var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var4.format(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 100.0f, 10.0f, var4, 0.0d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    var1.setBackgroundAlpha(1.0f);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
    java.awt.Paint var5 = var1.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    var1.handleClick((-398), 0, var8);
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    org.jfree.chart.util.RectangleInsets var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setItemLabelPadding(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.setBackgroundAlpha(1.0f);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
//     java.awt.Paint var5 = var1.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var1.handleClick((-398), 0, var8);
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.plot.PlotOrientation var11 = var1.getOrientation();
//     org.jfree.data.xy.DefaultXYDataset var12 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot();
//     var13.setBackgroundAlpha(1.0f);
//     var12.addChangeListener((org.jfree.data.general.DatasetChangeListener)var13);
//     org.jfree.chart.axis.TickUnit var17 = var13.getAngleTickUnit();
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var20 = var19.getAxisLineStroke();
//     var13.setRadiusGridlineStroke(var20);
//     var1.setRadiusGridlineStroke(var20);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var6 = var4.remove((java.lang.Number)10L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.data.time.Year var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, var1);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var7 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var8 = var3.getColorComponents(var7);
    java.awt.Color var12 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var16 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var17 = var12.getColorComponents(var16);
    java.awt.color.ColorSpace var18 = var12.getColorSpace();
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var26 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var27 = var22.getColorComponents(var26);
    float[] var28 = var12.getRGBColorComponents(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var29 = var3.getRGBComponents(var28);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.configure();
    var0.configure();
    org.jfree.chart.axis.CategoryLabelPositions var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setCategoryLabelPositions(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    var0.setBackgroundAlpha(1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
    var2.setBackgroundAlpha(1.0f);
    boolean var5 = var1.hasListener((java.util.EventListener)var2);
    java.awt.Shape var6 = var1.getLeftArrow();
    double var7 = var1.getLowerBound();
    java.awt.Paint var8 = var1.getTickLabelPaint();
    java.awt.Stroke var9 = null;
    org.jfree.chart.util.RectangleInsets var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var11 = new org.jfree.chart.block.LineBorder(var8, var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.lang.String var1 = var0.getPlotType();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     var0.handleClick((-398), (-398), var4);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, (-1.0d), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.chart.util.StrokeMap var0 = new org.jfree.chart.util.StrokeMap();
//     java.lang.Comparable var1 = null;
//     boolean var2 = var0.containsKey(var1);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var0.setFixedRangeAxisSpace(var6);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     org.jfree.chart.plot.PlotState var11 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var0.draw(var8, var9, var10, var11, var12);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.drawBackground(var1, var2);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(0.0d, "", "", false);
    java.lang.StringBuffer var6 = null;
    java.text.FieldPosition var7 = null;
    java.lang.StringBuffer var8 = var4.format((-1.0d), var6, var7);
    java.text.NumberFormat var9 = var4.getExponentFormat();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Currency var10 = var4.getCurrency();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var2 = null;
//     java.awt.geom.RectangularShape var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     var0.paintBarShadow(var1, var2, 255, 100, true, var6, var7, false);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var1 = var0.getNumberFormat();
    org.jfree.chart.renderer.xy.GradientXYBarPainter var2 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedCharacterIterator var3 = var1.formatToCharacterIterator((java.lang.Object)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.setNotify(false);
    org.jfree.chart.ChartRenderingInfo var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var11 = var5.createBufferedImage((-1), 100, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var2.drawDomainGridline(var3, var4, var5, 100.0d);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("PlotOrientation.HORIZONTAL");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var1 = org.jfree.chart.util.SerialUtilities.readShape(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelLinkStroke(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var5.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var7 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
//     var8.setBackgroundAlpha(1.0f);
//     var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
//     java.awt.Paint var12 = var8.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     var8.handleClick((-398), 0, var15);
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     var5.addLegend(var17);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     var17.draw(var19, var20);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("PlotOrientation.HORIZONTAL");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     org.jfree.chart.axis.DateTickUnitType var2 = null;
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(var0, 2147483647, var2, (-1), var4);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     boolean var1 = var0.isVerticalTickLabels();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.axis.AxisState var8 = var0.draw(var2, 0.0d, var4, var5, var6, var7);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(1.0E-5d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.setNotify(false);
    var5.setNotify(false);
    java.lang.Object var10 = var5.getTextAntiAlias();
    org.jfree.chart.ChartRenderingInfo var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var14 = var5.createBufferedImage((-1), 0, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
//     var7.setBackgroundAlpha(1.0f);
//     java.awt.Paint var10 = var7.getBackgroundPaint();
//     var6.setLabelPaint(var10);
//     org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 0.0d, 100.0d, var10);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var12.draw(var13, var14);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
//     var8.setBackgroundAlpha(1.0f);
//     java.awt.Paint var11 = var8.getBackgroundPaint();
//     var7.setLabelPaint(var11);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 0.0d, 100.0d, var11);
//     boolean var14 = var0.equals((java.lang.Object)100.0d);
//     org.jfree.data.general.PieDataset var15 = null;
//     java.text.AttributedString var17 = var0.generateAttributedSectionLabel(var15, (java.lang.Comparable)1.0f);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     boolean var1 = var0.isVerticalTickLabels();
//     java.lang.Object var2 = var0.clone();
//     java.util.Date var3 = null;
//     java.util.Date var4 = null;
//     var0.setRange(var3, var4);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.xy.DefaultXYDataset var3 = new org.jfree.data.xy.DefaultXYDataset();
//     var1.setDataset((org.jfree.data.general.Dataset)var3);
//     org.jfree.data.general.Dataset var5 = var1.getDataset();
//     java.awt.Color var9 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var10 = var9.brighter();
//     var1.setFillPaint((java.awt.Paint)var10);
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var10};
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var15 = var14.getLinePaint();
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
//     org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var19 = var18.clone();
//     org.jfree.data.xy.DefaultXYDataset var20 = new org.jfree.data.xy.DefaultXYDataset();
//     var18.setDataset((org.jfree.data.general.Dataset)var20);
//     org.jfree.data.general.Dataset var22 = var18.getDataset();
//     java.awt.Color var26 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var27 = var26.brighter();
//     var18.setFillPaint((java.awt.Paint)var27);
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var27};
//     org.jfree.chart.plot.IntervalMarker var32 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var33 = var32.getOutlineStroke();
//     java.awt.Stroke var34 = var32.getOutlineStroke();
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     java.awt.Stroke[] var36 = null;
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var39 = var38.getAxisLineStroke();
//     boolean var40 = var38.isAutoRange();
//     java.awt.Shape var41 = var38.getRightArrow();
//     java.awt.Shape[] var42 = new java.awt.Shape[] { var41};
//     org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var16, var29, var35, var36, var42);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     double var5 = var4.getMinX();
//     org.jfree.data.xy.XYDataItem var8 = var4.addOrUpdate((java.lang.Number)(byte)10, (java.lang.Number)2.0f);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.xy.XYDataItem var10 = var4.remove((java.lang.Number)0.5d);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    boolean var6 = var0.equals((java.lang.Object)true);
    java.text.NumberFormat var8 = java.text.NumberFormat.getNumberInstance();
    org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(Double.NaN, var8, 2147483647);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var11 = var0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit)var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("AxisLabelEntity: label = null", var1, var2);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("PlotOrientation.HORIZONTAL", var1);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     java.util.Locale var2 = null;
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var0, var1, var2);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setBackgroundAlpha(1.0f);
//     boolean var6 = var2.hasListener((java.util.EventListener)var3);
//     java.awt.Shape var7 = var2.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
//     java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var15 = var14.brighter();
//     org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var7, (java.awt.Paint)var14);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     boolean var20 = var19.isVerticalTickLabels();
//     java.lang.Object var21 = var16.draw(var17, var18, (java.lang.Object)var19);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.ValueAxis[] var2 = null;
//     var0.setDomainAxes(var2);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(255, 10, (-398));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Combined_Domain_XYPlot", var1, var2);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.data.time.RegularTimePeriod var1 = null;
//     org.jfree.data.time.RegularTimePeriod var2 = null;
//     org.jfree.chart.axis.PeriodAxis var3 = new org.jfree.chart.axis.PeriodAxis("hi!", var1, var2);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-398), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    org.jfree.chart.labels.ItemLabelPosition var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseNegativeItemLabelPosition(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 2147483647);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.2d, (-1.0d), (-1.0d));

  }

//  public void test152() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
//
//
//    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
//
//  }
//
  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var1);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var5 = var4.getAxisLineStroke();
    var4.resizeRange2(0.0d, 10.0d);
    java.awt.Font var9 = var4.getTickLabelFont();
    var0.setNoDataMessageFont(var9);
    double var11 = var0.getMinimumArcAngleToDraw();
    java.awt.Font var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelFont(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0E-5d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(100, 1, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.setNotify(false);
    var5.setNotify(false);
    java.lang.Object var10 = var5.getTextAntiAlias();
    var5.fireChartChanged();
    org.jfree.chart.ChartRenderingInfo var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var15 = var5.createBufferedImage(255, (-398), var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    java.text.DateFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.event.TitleChangeEvent var6 = null;
//     var5.titleChanged(var6);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.Title var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.addSubtitle(100, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var3 = var2.getAutoPopulateSeriesFillPaint();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = null;
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     boolean var7 = var6.isVerticalTickLabels();
//     java.lang.Object var8 = var6.clone();
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot();
//     var18.setBackgroundAlpha(1.0f);
//     java.awt.Paint var21 = var18.getBackgroundPaint();
//     var17.setLabelPaint(var21);
//     org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 0.0d, 100.0d, var21);
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var26 = var25.getAxisLineStroke();
//     boolean var27 = var25.isAutoRange();
//     org.jfree.chart.plot.IntervalMarker var30 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var31 = var30.getOutlineStroke();
//     var25.setTickMarkStroke(var31);
//     var2.drawRangeLine(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9, 0.05d, var21, var31);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 1.0f, (-1.0f), var4, 100.0d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    boolean var6 = var2.hasListener((java.util.EventListener)var3);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var13 = var12.getAxisLineStroke();
    var12.resizeRange2(0.0d, 10.0d);
    org.jfree.chart.entity.AxisEntity var18 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var12, "hi!");
    java.lang.String var19 = var18.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "hi!"+ "'", var19.equals("hi!"));

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 0);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.2d, 1.0d, (-1), (java.lang.Comparable)10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    var1.setBackgroundAlpha(1.0f);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
    int var6 = var0.indexOf((java.lang.Comparable)'a');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var0.getYValue(100, 13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("AxisLabelEntity: label = null", var1);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.updateByIndex((-398), (java.lang.Number)2147483647);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var3 = var2.getAutoPopulateSeriesFillPaint();
//     double var4 = var2.getLowerClip();
//     var2.setShadowYOffset(1.0E-5d);
//     double var7 = var2.getYOffset();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
//     var10.configure();
//     var10.configure();
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot();
//     var16.setBackgroundAlpha(1.0f);
//     boolean var19 = var15.hasListener((java.util.EventListener)var16);
//     java.awt.Shape var20 = var15.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var23 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var13, var20, "hi!", "hi!");
//     double var24 = var13.getUpperMargin();
//     double var25 = var13.getAutoRangeMinimumSize();
//     org.jfree.chart.util.Layer var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     var2.drawAnnotations(var8, var9, (org.jfree.chart.axis.CategoryAxis)var10, (org.jfree.chart.axis.ValueAxis)var13, var26, var27);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var3 = var0.get((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     java.util.Date var1 = null;
//     long var2 = var0.getTime(var1);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.2d);
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelTextAnchor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(0, var1);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    org.jfree.data.xy.IntervalXYDelegate var3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    java.lang.Object var4 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var0.getXValue(255, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseOutlinePaint(var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var1 = var0.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var2 = var0.getTickLabelInsets();
    double var4 = var2.trimHeight(1.0E-5d);
    java.awt.geom.Rectangle2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var2.createInsetRectangle(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-3.99999d));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    java.awt.Stroke var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeZeroBaselineStroke(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.removeCategoryLabelToolTip((java.lang.Comparable)2147483647);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var0.getCategorySeriesMiddle((-1), (-398), 0, 13, 0.0d, var8, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var7 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
    var8.setBackgroundAlpha(1.0f);
    var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
    java.awt.Paint var12 = var8.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    var8.handleClick((-398), 0, var15);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    var5.addLegend(var17);
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var23 = var22.brighter();
    var17.setBackgroundPaint((java.awt.Paint)var22);
    org.jfree.chart.util.RectangleEdge var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setLegendItemGraphicEdge(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator((-398));
    org.jfree.chart.annotations.XYAnnotation var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var1 = var0.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var2 = var0.getTickLabelInsets();
    double var3 = var2.getLeft();
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var7 = var2.createInsetRectangle(var4, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4.0d);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
//     var2.setBackgroundAlpha(1.0f);
//     boolean var5 = var1.hasListener((java.util.EventListener)var2);
//     java.awt.Paint var6 = var2.getAngleLabelPaint();
//     java.awt.Stroke var7 = var2.getAngleGridlineStroke();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
//     var11.setBackgroundAlpha(1.0f);
//     boolean var14 = var10.hasListener((java.util.EventListener)var11);
//     java.awt.Shape var15 = var10.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var8, var15, "hi!", "hi!");
//     java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var23 = var22.brighter();
//     org.jfree.chart.title.LegendGraphic var24 = new org.jfree.chart.title.LegendGraphic(var15, (java.awt.Paint)var22);
//     boolean var25 = var2.equals((java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var0.addException(1L);
//     var0.addBaseTimelineExclusions(0L, (-1L));
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var0, var1);
    java.lang.Comparable[] var4 = new java.lang.Comparable[] { "null"};
    double[] var5 = null;
    double[][] var6 = new double[][] { var5};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[])var0, var4, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    int var2 = var1.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.setBackgroundAlpha(1.0f);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
//     org.jfree.chart.axis.TickUnit var5 = var1.getAngleTickUnit();
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var9.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var13 = var9.getOrientation();
//     boolean var14 = var9.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var15 = var9.getQuadrantOrigin();
//     var1.zoomRangeAxes(1.0E-8d, var8, var15, true);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat(0.0d, "", "", false);
    java.lang.StringBuffer var7 = null;
    java.text.FieldPosition var8 = null;
    java.lang.StringBuffer var9 = var5.format((-1.0d), var7, var8);
    java.text.NumberFormat var10 = var5.getExponentFormat();
    java.text.NumberFormat var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.chart.ChartColor[r=10,g=100,b=1]", (java.text.NumberFormat)var5, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setBackgroundAlpha(1.0f);
//     boolean var6 = var2.hasListener((java.util.EventListener)var3);
//     java.awt.Shape var7 = var2.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
//     boolean var11 = var0.isVisible();
//     org.jfree.chart.text.TextBlock var12 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot();
//     var17.setBackgroundAlpha(1.0f);
//     boolean var20 = var16.hasListener((java.util.EventListener)var17);
//     java.awt.Shape var21 = var16.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var24 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var14, var21, "hi!", "hi!");
//     double var25 = var14.getUpperMargin();
//     java.awt.Font var26 = var14.getLabelFont();
//     java.awt.Color var30 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var31 = var30.brighter();
//     var12.addLine("", var26, (java.awt.Paint)var31);
//     var0.setLabelFont(var26);
//     
//     // Checks the contract:  equals-hashcode on var3 and var17
//     assertTrue("Contract failed: equals-hashcode on var3 and var17", var3.equals(var17) ? var3.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var3
//     assertTrue("Contract failed: equals-hashcode on var17 and var3", var17.equals(var3) ? var17.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getNumberInstance();
    boolean var1 = var0.isParseIntegerOnly();
    var0.setMinimumIntegerDigits(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.parseObject("org.jfree.chart.ChartColor[r=10,g=100,b=1]");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    double var7 = var2.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var2.setSeriesNegativeItemLabelPosition(1, var9);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var13 = var12.getAxisLineStroke();
    java.awt.Font var14 = var12.getLabelFont();
    var2.setBaseItemLabelFont(var14);
    org.jfree.chart.util.GradientPaintTransformer var16 = var2.getGradientPaintTransformer();
    var2.clearSeriesStrokes(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setRangeWithMargins(0.2d, 10.0d);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var2.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var6 = var2.getOrientation();
//     boolean var7 = var2.isDomainMinorGridlinesVisible();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     boolean var9 = var8.isVerticalTickLabels();
//     java.lang.Object var10 = var8.clone();
//     org.jfree.chart.plot.IntervalMarker var13 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var14 = var13.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
//     var15.setBackgroundAlpha(1.0f);
//     java.awt.Paint var18 = var15.getBackgroundPaint();
//     var13.setPaint(var18);
//     org.jfree.chart.text.TextBlock var20 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var21 = var20.getLineAlignment();
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var24 = var23.clone();
//     var23.setDescription("");
//     boolean var27 = var20.equals((java.lang.Object)"");
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.util.Size2D var29 = var20.calculateDimensions(var28);
//     org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var32.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var36 = var32.getOrientation();
//     org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var32);
//     var37.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var39 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot();
//     var40.setBackgroundAlpha(1.0f);
//     var39.addChangeListener((org.jfree.data.general.DatasetChangeListener)var40);
//     java.awt.Paint var44 = var40.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     var40.handleClick((-398), 0, var47);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
//     var37.addLegend(var49);
//     java.awt.Color var54 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var55 = var54.brighter();
//     var49.setBackgroundPaint((java.awt.Paint)var54);
//     org.jfree.chart.util.RectangleAnchor var57 = var49.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var62 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var63 = var62.getLicenceName();
//     java.lang.String var64 = var62.getLicenceName();
//     boolean var65 = var57.equals((java.lang.Object)var64);
//     java.awt.geom.Rectangle2D var66 = org.jfree.chart.util.RectangleAnchor.createRectangle(var29, (-3.99999d), 5.0d, var57);
//     var0.drawDomainMarker(var1, (org.jfree.chart.plot.XYPlot)var2, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.plot.Marker)var13, var66);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     java.util.Locale var2 = null;
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var0, var1, var2);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.event.RendererChangeEvent[source=1]]");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var2 = var1.getAxisLineStroke();
    java.awt.Paint var3 = var1.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.AffineTransform var7 = null;
//     java.awt.RenderingHints var8 = null;
//     java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
//     java.awt.Paint[] var10 = new java.awt.Paint[] { var3};
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("");
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("");
//     java.awt.Paint var16 = var15.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var19 = var18.getAxisLineStroke();
//     var18.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var23 = var18.getTickLabelFont();
//     org.jfree.data.Range var24 = var18.getDefaultAutoRange();
//     boolean var25 = var18.isAutoTickUnitSelection();
//     java.awt.Paint var26 = var18.getTickLabelPaint();
//     var15.setBackgroundPaint(var26);
//     boolean var28 = var12.equals((java.lang.Object)var26);
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var26};
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var30.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var34 = var30.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var37 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var38 = var37.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot();
//     var39.setBackgroundAlpha(1.0f);
//     java.awt.Paint var42 = var39.getBackgroundPaint();
//     var37.setPaint(var42);
//     var30.setRangeMinorGridlinePaint(var42);
//     org.jfree.chart.axis.AxisSpace var45 = null;
//     var30.setFixedDomainAxisSpace(var45);
//     java.awt.Stroke var47 = var30.getRangeZeroBaselineStroke();
//     java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
//     org.jfree.data.xy.DefaultXYDataset var49 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var50 = new org.jfree.chart.plot.PolarPlot();
//     var50.setBackgroundAlpha(1.0f);
//     var49.addChangeListener((org.jfree.data.general.DatasetChangeListener)var50);
//     org.jfree.chart.axis.TickUnit var54 = var50.getAngleTickUnit();
//     org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var57 = var56.getAxisLineStroke();
//     var50.setRadiusGridlineStroke(var57);
//     java.awt.Stroke[] var59 = new java.awt.Stroke[] { var57};
//     org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var62 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var63 = new org.jfree.chart.plot.PolarPlot();
//     var63.setBackgroundAlpha(1.0f);
//     boolean var66 = var62.hasListener((java.util.EventListener)var63);
//     java.awt.Shape var67 = var62.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var70 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var60, var67, "hi!", "hi!");
//     java.awt.Shape[] var71 = new java.awt.Shape[] { var67};
//     org.jfree.chart.plot.DefaultDrawingSupplier var72 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var29, var48, var59, var71);
//     
//     // Checks the contract:  equals-hashcode on var39 and var63
//     assertTrue("Contract failed: equals-hashcode on var39 and var63", var39.equals(var63) ? var39.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var39
//     assertTrue("Contract failed: equals-hashcode on var63 and var39", var63.equals(var39) ? var63.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
//     org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter)var0);
//     org.jfree.chart.util.StrokeMap var2 = new org.jfree.chart.util.StrokeMap();
//     java.lang.Object var3 = var2.clone();
//     boolean var4 = var0.equals(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = null;
//     org.jfree.chart.text.TextBlock var10 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var11 = var10.getLineAlignment();
//     org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var14 = var13.clone();
//     var13.setDescription("");
//     boolean var17 = var10.equals((java.lang.Object)"");
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.util.Size2D var19 = var10.calculateDimensions(var18);
//     org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var22.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var26 = var22.getOrientation();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
//     var27.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var29 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot();
//     var30.setBackgroundAlpha(1.0f);
//     var29.addChangeListener((org.jfree.data.general.DatasetChangeListener)var30);
//     java.awt.Paint var34 = var30.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     var30.handleClick((-398), 0, var37);
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     var27.addLegend(var39);
//     java.awt.Color var44 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var45 = var44.brighter();
//     var39.setBackgroundPaint((java.awt.Paint)var44);
//     org.jfree.chart.util.RectangleAnchor var47 = var39.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var52 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var53 = var52.getLicenceName();
//     java.lang.String var54 = var52.getLicenceName();
//     boolean var55 = var47.equals((java.lang.Object)var54);
//     java.awt.geom.Rectangle2D var56 = org.jfree.chart.util.RectangleAnchor.createRectangle(var19, (-3.99999d), 5.0d, var47);
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     var0.paintBar(var5, var6, 2147483647, (-1), false, (java.awt.geom.RectangularShape)var56, var57);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    double var7 = var2.getYOffset();
    org.jfree.data.xy.DefaultXYDataset var9 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot();
    var10.setBackgroundAlpha(1.0f);
    var9.addChangeListener((org.jfree.data.general.DatasetChangeListener)var10);
    java.awt.Paint var14 = var10.getAngleGridlinePaint();
    var2.setLegendTextPaint(0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
    var7.setBackgroundAlpha(1.0f);
    boolean var10 = var6.hasListener((java.util.EventListener)var7);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var4, var11, "hi!", "hi!");
    org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Paint var18 = var17.getLabelPaint();
    org.jfree.data.xy.DefaultXYDataset var19 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot();
    var20.setBackgroundAlpha(1.0f);
    var19.addChangeListener((org.jfree.data.general.DatasetChangeListener)var20);
    org.jfree.chart.axis.TickUnit var24 = var20.getAngleTickUnit();
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var27 = var26.getAxisLineStroke();
    var20.setRadiusGridlineStroke(var27);
    java.awt.Paint var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem(var0, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "null", "AxisLabelEntity: label = null", var11, var18, var27, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("");
    int var3 = var2.getMaximumLinesToDisplay();
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
    var4.setBackgroundAlpha(1.0f);
    java.awt.Paint var7 = var4.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var2, (java.lang.Object)var4);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var3 = var2.getAutoPopulateSeriesFillPaint();
//     double var4 = var2.getLowerClip();
//     var2.setShadowYOffset(1.0E-5d);
//     double var7 = var2.getYOffset();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot();
//     var13.setBackgroundAlpha(1.0f);
//     boolean var16 = var12.hasListener((java.util.EventListener)var13);
//     java.awt.Shape var17 = var12.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var20 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var10, var17, "hi!", "hi!");
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var23 = var22.getAxisLineStroke();
//     var22.resizeRange2(0.0d, 10.0d);
//     org.jfree.chart.entity.AxisEntity var28 = new org.jfree.chart.entity.AxisEntity(var17, (org.jfree.chart.axis.Axis)var22, "hi!");
//     var22.setAutoRangeIncludesZero(false);
//     float var31 = var22.getTickMarkOutsideLength();
//     org.jfree.chart.text.TextBlock var32 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var33 = var32.getLineAlignment();
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var36 = var35.clone();
//     var35.setDescription("");
//     boolean var39 = var32.equals((java.lang.Object)"");
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.util.Size2D var41 = var32.calculateDimensions(var40);
//     org.jfree.chart.plot.CombinedDomainXYPlot var44 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var44.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var48 = var44.getOrientation();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var44);
//     var49.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var51 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var52 = new org.jfree.chart.plot.PolarPlot();
//     var52.setBackgroundAlpha(1.0f);
//     var51.addChangeListener((org.jfree.data.general.DatasetChangeListener)var52);
//     java.awt.Paint var56 = var52.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     var52.handleClick((-398), 0, var59);
//     org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
//     var49.addLegend(var61);
//     java.awt.Color var66 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var67 = var66.brighter();
//     var61.setBackgroundPaint((java.awt.Paint)var66);
//     org.jfree.chart.util.RectangleAnchor var69 = var61.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var74 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var75 = var74.getLicenceName();
//     java.lang.String var76 = var74.getLicenceName();
//     boolean var77 = var69.equals((java.lang.Object)var76);
//     java.awt.geom.Rectangle2D var78 = org.jfree.chart.util.RectangleAnchor.createRectangle(var41, (-3.99999d), 5.0d, var69);
//     org.jfree.chart.axis.NumberAxis3D var80 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var82 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var83 = new org.jfree.chart.plot.PolarPlot();
//     var83.setBackgroundAlpha(1.0f);
//     boolean var86 = var82.hasListener((java.util.EventListener)var83);
//     java.awt.Shape var87 = var82.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var90 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var80, var87, "hi!", "hi!");
//     java.awt.Color var94 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var95 = var94.brighter();
//     org.jfree.chart.title.LegendGraphic var96 = new org.jfree.chart.title.LegendGraphic(var87, (java.awt.Paint)var94);
//     java.awt.Stroke var97 = null;
//     var2.drawRangeLine(var8, var9, (org.jfree.chart.axis.ValueAxis)var22, var78, 10.0d, (java.awt.Paint)var94, var97);
//     
//     // Checks the contract:  equals-hashcode on var13 and var52
//     assertTrue("Contract failed: equals-hashcode on var13 and var52", var13.equals(var52) ? var13.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var83
//     assertTrue("Contract failed: equals-hashcode on var13 and var83", var13.equals(var83) ? var13.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var13
//     assertTrue("Contract failed: equals-hashcode on var52 and var13", var52.equals(var13) ? var52.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var83
//     assertTrue("Contract failed: equals-hashcode on var52 and var83", var52.equals(var83) ? var52.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var13
//     assertTrue("Contract failed: equals-hashcode on var83 and var13", var83.equals(var13) ? var83.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var52
//     assertTrue("Contract failed: equals-hashcode on var83 and var52", var83.equals(var52) ? var83.hashCode() == var52.hashCode() : true);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    int var2 = var0.size();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var4 = var0.get((-398));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.setBackgroundAlpha(1.0f);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
//     java.awt.Paint var5 = var1.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var1.handleClick((-398), 0, var8);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     java.awt.geom.Point2D var13 = null;
//     var1.zoomDomainAxes(Double.NaN, 0.05d, var12, var13);
//     org.jfree.chart.plot.PlotOrientation var15 = var1.getOrientation();
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var18 = var17.getRangeMinorGridlinePaint();
//     var17.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     var17.handleClick(10, 0, var24);
//     org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var26.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var30 = var26.getOrientation();
//     boolean var31 = var26.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var32 = var26.getQuadrantOrigin();
//     var1.zoomRangeAxes(1.0E-8d, var24, var32, true);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.lang.String var1 = var0.getNullYString();
    java.lang.Object var2 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "null"+ "'", var1.equals("null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    org.jfree.data.xy.XYDataItem var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var6 = var4.addOrUpdate(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var2 = var1.getLineAlignment();
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var5 = var4.clone();
//     var4.setDescription("");
//     boolean var8 = var1.equals((java.lang.Object)"");
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.util.Size2D var10 = var1.calculateDimensions(var9);
//     org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var13.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var17 = var13.getOrientation();
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
//     var18.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var20 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot();
//     var21.setBackgroundAlpha(1.0f);
//     var20.addChangeListener((org.jfree.data.general.DatasetChangeListener)var21);
//     java.awt.Paint var25 = var21.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     var21.handleClick((-398), 0, var28);
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
//     var18.addLegend(var30);
//     java.awt.Color var35 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var36 = var35.brighter();
//     var30.setBackgroundPaint((java.awt.Paint)var35);
//     org.jfree.chart.util.RectangleAnchor var38 = var30.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var43 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var44 = var43.getLicenceName();
//     java.lang.String var45 = var43.getLicenceName();
//     boolean var46 = var38.equals((java.lang.Object)var45);
//     java.awt.geom.Rectangle2D var47 = org.jfree.chart.util.RectangleAnchor.createRectangle(var10, (-3.99999d), 5.0d, var38);
//     org.jfree.chart.text.TextBlock var48 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var49 = var48.getLineAlignment();
//     org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var52 = var51.clone();
//     var51.setDescription("");
//     boolean var55 = var48.equals((java.lang.Object)"");
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.util.Size2D var57 = var48.calculateDimensions(var56);
//     org.jfree.chart.plot.CombinedDomainXYPlot var60 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var60.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var64 = var60.getOrientation();
//     org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var60);
//     var65.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var67 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var68 = new org.jfree.chart.plot.PolarPlot();
//     var68.setBackgroundAlpha(1.0f);
//     var67.addChangeListener((org.jfree.data.general.DatasetChangeListener)var68);
//     java.awt.Paint var72 = var68.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     var68.handleClick((-398), 0, var75);
//     org.jfree.chart.title.LegendTitle var77 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var68);
//     var65.addLegend(var77);
//     java.awt.Color var82 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var83 = var82.brighter();
//     var77.setBackgroundPaint((java.awt.Paint)var82);
//     org.jfree.chart.util.RectangleAnchor var85 = var77.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var90 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var91 = var90.getLicenceName();
//     java.lang.String var92 = var90.getLicenceName();
//     boolean var93 = var85.equals((java.lang.Object)var92);
//     java.awt.geom.Rectangle2D var94 = org.jfree.chart.util.RectangleAnchor.createRectangle(var57, (-3.99999d), 5.0d, var85);
//     java.awt.geom.Rectangle2D var95 = var0.shrink(var47, var94);
//     
//     // Checks the contract:  equals-hashcode on var4 and var51
//     assertTrue("Contract failed: equals-hashcode on var4 and var51", var4.equals(var51) ? var4.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var4
//     assertTrue("Contract failed: equals-hashcode on var51 and var4", var51.equals(var4) ? var51.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var52
//     assertTrue("Contract failed: equals-hashcode on var5 and var52", var5.equals(var52) ? var5.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var5
//     assertTrue("Contract failed: equals-hashcode on var52 and var5", var52.equals(var5) ? var52.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var57
//     assertTrue("Contract failed: equals-hashcode on var10 and var57", var10.equals(var57) ? var10.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var10
//     assertTrue("Contract failed: equals-hashcode on var57 and var10", var57.equals(var10) ? var57.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var60
//     assertTrue("Contract failed: equals-hashcode on var13 and var60", var13.equals(var60) ? var13.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var13
//     assertTrue("Contract failed: equals-hashcode on var60 and var13", var60.equals(var13) ? var60.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var65
//     assertTrue("Contract failed: equals-hashcode on var18 and var65", var18.equals(var65) ? var18.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var18
//     assertTrue("Contract failed: equals-hashcode on var65 and var18", var65.equals(var18) ? var65.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var68
//     assertTrue("Contract failed: equals-hashcode on var21 and var68", var21.equals(var68) ? var21.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var21
//     assertTrue("Contract failed: equals-hashcode on var68 and var21", var68.equals(var21) ? var68.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var3 = var2.getAutoPopulateSeriesFillPaint();
//     double var4 = var2.getLowerClip();
//     var2.setShadowYOffset(1.0E-5d);
//     double var7 = var2.getYOffset();
//     org.jfree.chart.labels.ItemLabelPosition var9 = null;
//     var2.setSeriesNegativeItemLabelPosition(1, var9);
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var13 = var12.getAxisLineStroke();
//     java.awt.Font var14 = var12.getLabelFont();
//     var2.setBaseItemLabelFont(var14);
//     java.awt.Paint var16 = var2.getBaseItemLabelPaint();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = null;
//     org.jfree.chart.text.TextBlock var19 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var20 = var19.getLineAlignment();
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var23 = var22.clone();
//     var22.setDescription("");
//     boolean var26 = var19.equals((java.lang.Object)"");
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.util.Size2D var28 = var19.calculateDimensions(var27);
//     org.jfree.chart.plot.CombinedDomainXYPlot var31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var31.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var35 = var31.getOrientation();
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
//     var36.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var38 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot();
//     var39.setBackgroundAlpha(1.0f);
//     var38.addChangeListener((org.jfree.data.general.DatasetChangeListener)var39);
//     java.awt.Paint var43 = var39.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     var39.handleClick((-398), 0, var46);
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     var36.addLegend(var48);
//     java.awt.Color var53 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var54 = var53.brighter();
//     var48.setBackgroundPaint((java.awt.Paint)var53);
//     org.jfree.chart.util.RectangleAnchor var56 = var48.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var61 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var62 = var61.getLicenceName();
//     java.lang.String var63 = var61.getLicenceName();
//     boolean var64 = var56.equals((java.lang.Object)var63);
//     java.awt.geom.Rectangle2D var65 = org.jfree.chart.util.RectangleAnchor.createRectangle(var28, (-3.99999d), 5.0d, var56);
//     org.jfree.chart.title.TextTitle var68 = new org.jfree.chart.title.TextTitle("");
//     java.awt.Paint var69 = var68.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis3D var71 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var72 = var71.getAxisLineStroke();
//     var71.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var76 = var71.getTickLabelFont();
//     org.jfree.data.Range var77 = var71.getDefaultAutoRange();
//     boolean var78 = var71.isAutoTickUnitSelection();
//     java.awt.Paint var79 = var71.getTickLabelPaint();
//     var68.setBackgroundPaint(var79);
//     org.jfree.chart.axis.NumberAxis3D var82 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var83 = var82.getAxisLineStroke();
//     boolean var84 = var82.isAutoRange();
//     org.jfree.chart.plot.IntervalMarker var87 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var88 = var87.getOutlineStroke();
//     var82.setTickMarkStroke(var88);
//     var2.drawDomainLine(var17, var18, var65, 0.0d, var79, var88);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
//     org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var5.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.LegendItemCollection var9 = var5.getLegendItems();
//     var4.addAll(var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var9
//     assertTrue("Contract failed: equals-hashcode on var4 and var9", var4.equals(var9) ? var4.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var4
//     assertTrue("Contract failed: equals-hashcode on var9 and var4", var9.equals(var4) ? var9.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var1 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
//     var2.setBackgroundAlpha(1.0f);
//     var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var2);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     var2.zoomDomainAxes(1.0d, 0.0d, var8, var9);
//     org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var14 = var13.getAutoPopulateSeriesFillPaint();
//     double var15 = var13.getLowerClip();
//     org.jfree.chart.ChartColor var19 = new org.jfree.chart.ChartColor(10, 100, 1);
//     var13.setBasePaint((java.awt.Paint)var19);
//     java.awt.Font var21 = var13.getBaseItemLabelFont();
//     var2.setAngleLabelFont(var21);
//     org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot();
//     var30.setBackgroundAlpha(1.0f);
//     java.awt.Paint var33 = var30.getBackgroundPaint();
//     var29.setLabelPaint(var33);
//     org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 0.0d, 100.0d, var33);
//     org.jfree.chart.text.TextMeasurer var37 = null;
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("PlotOrientation.HORIZONTAL", var21, var33, 10.0f, var37);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     org.jfree.data.general.PieDataset var1 = null;
//     java.text.AttributedString var3 = var0.generateAttributedSectionLabel(var1, (java.lang.Comparable)"Combined_Domain_XYPlot");
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var2 = var1.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getTickLabelInsets();
//     double var5 = var3.trimHeight(1.0E-5d);
//     double var7 = var3.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var8 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var9 = var8.getLineAlignment();
//     org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var12 = var11.clone();
//     var11.setDescription("");
//     boolean var15 = var8.equals((java.lang.Object)"");
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.util.Size2D var17 = var8.calculateDimensions(var16);
//     org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var20.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var24 = var20.getOrientation();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var20);
//     var25.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var27 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot();
//     var28.setBackgroundAlpha(1.0f);
//     var27.addChangeListener((org.jfree.data.general.DatasetChangeListener)var28);
//     java.awt.Paint var32 = var28.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     var28.handleClick((-398), 0, var35);
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
//     var25.addLegend(var37);
//     java.awt.Color var42 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var43 = var42.brighter();
//     var37.setBackgroundPaint((java.awt.Paint)var42);
//     org.jfree.chart.util.RectangleAnchor var45 = var37.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var50 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var51 = var50.getLicenceName();
//     java.lang.String var52 = var50.getLicenceName();
//     boolean var53 = var45.equals((java.lang.Object)var52);
//     java.awt.geom.Rectangle2D var54 = org.jfree.chart.util.RectangleAnchor.createRectangle(var17, (-3.99999d), 5.0d, var45);
//     var3.trim(var54);
//     boolean var56 = org.jfree.chart.util.LineUtilities.clipLine(var0, var54);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("{0}: ({1}, {2})", "", var3);
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var1 = var0.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getTickLabelInsets();
//     double var4 = var2.trimHeight(1.0E-5d);
//     double var6 = var2.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var7 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var11 = var10.clone();
//     var10.setDescription("");
//     boolean var14 = var7.equals((java.lang.Object)"");
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.util.Size2D var16 = var7.calculateDimensions(var15);
//     org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var19.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var23 = var19.getOrientation();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     var24.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var26 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot();
//     var27.setBackgroundAlpha(1.0f);
//     var26.addChangeListener((org.jfree.data.general.DatasetChangeListener)var27);
//     java.awt.Paint var31 = var27.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     var27.handleClick((-398), 0, var34);
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     var24.addLegend(var36);
//     java.awt.Color var41 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var42 = var41.brighter();
//     var36.setBackgroundPaint((java.awt.Paint)var41);
//     org.jfree.chart.util.RectangleAnchor var44 = var36.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var49 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var50 = var49.getLicenceName();
//     java.lang.String var51 = var49.getLicenceName();
//     boolean var52 = var44.equals((java.lang.Object)var51);
//     java.awt.geom.Rectangle2D var53 = org.jfree.chart.util.RectangleAnchor.createRectangle(var16, (-3.99999d), 5.0d, var44);
//     var2.trim(var53);
//     org.jfree.chart.plot.CombinedDomainXYPlot var55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var55.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var59 = var55.getOrientation();
//     org.jfree.chart.JFreeChart var60 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var55);
//     var60.setNotify(false);
//     var60.setNotify(false);
//     java.lang.Object var65 = var60.getTextAntiAlias();
//     org.jfree.chart.entity.JFreeChartEntity var67 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var53, var60, "ThreadContext");
//     
//     // Checks the contract:  equals-hashcode on var19 and var55
//     assertTrue("Contract failed: equals-hashcode on var19 and var55", var19.equals(var55) ? var19.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var19
//     assertTrue("Contract failed: equals-hashcode on var55 and var19", var55.equals(var19) ? var55.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    boolean var6 = var2.hasListener((java.util.EventListener)var3);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
    java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var7, (java.awt.Paint)var14);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.block.RectangleConstraint var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var19 = var16.arrange(var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("null");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    var2.setMinorTickMarkOutsideLength(0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisEntity var7 = new org.jfree.chart.entity.AxisEntity(var0, (org.jfree.chart.axis.Axis)var2, "hi!", "org.jfree.chart.ChartColor[r=10,g=100,b=1]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var0.addException(1L);
//     java.util.Date var3 = null;
//     var0.addBaseTimelineException(var3);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.renderer.xy.XYBarPainter var0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var4.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var8 = var4.getOrientation();
    var3.add((org.jfree.chart.plot.XYPlot)var4);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot();
    var13.setBackgroundAlpha(1.0f);
    boolean var16 = var12.hasListener((java.util.EventListener)var13);
    java.awt.Shape var17 = var12.getLeftArrow();
    double var18 = var12.getLowerBound();
    java.awt.Paint var19 = var12.getTickLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setQuadrantPaint(255, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    boolean var2 = var0.isRangeMinorGridlinesVisible();
    var0.setBackgroundImageAlignment(2147483647);
    org.jfree.chart.axis.NumberTickUnit var7 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var11 = var10.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxes(10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    org.jfree.chart.axis.AxisSpace var7 = new org.jfree.chart.axis.AxisSpace();
    var0.setFixedRangeAxisSpace(var7);
    org.jfree.chart.util.RectangleEdge var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.ensureAtLeast(10.0d, var10);
      fail("Expected exception of type java.lang.IllegalStateException");
    } catch (java.lang.IllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
    var8.setBackgroundAlpha(1.0f);
    java.awt.Paint var11 = var8.getBackgroundPaint();
    var7.setLabelPaint(var11);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 0.0d, 100.0d, var11);
    boolean var14 = var0.equals((java.lang.Object)100.0d);
    java.text.AttributedString var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAttributedLabel((-398), var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var1 = var0.getSegmentsGroupSize();
    org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var7 = var6.getItems();
    var0.addExceptions(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.XYPlot var2 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     var3.setVerticalTickLabels(false);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var7 = var6.getRangeMinorGridlinePaint();
//     var6.clearRangeMarkers(1);
//     org.jfree.chart.plot.IntervalMarker var13 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var14 = var13.getOutlineStroke();
//     java.awt.Stroke var15 = var13.getOutlineStroke();
//     org.jfree.chart.util.Layer var16 = null;
//     var6.addRangeMarker(10, (org.jfree.chart.plot.Marker)var13, var16, true);
//     org.jfree.chart.plot.IntervalMarker var22 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 1.0d);
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var25 = var6.removeDomainMarker(13, (org.jfree.chart.plot.Marker)var22, var23, true);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var28 = var27.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var29 = var27.getTickLabelInsets();
//     double var31 = var29.trimHeight(1.0E-5d);
//     double var33 = var29.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var34 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var35 = var34.getLineAlignment();
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var38 = var37.clone();
//     var37.setDescription("");
//     boolean var41 = var34.equals((java.lang.Object)"");
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.util.Size2D var43 = var34.calculateDimensions(var42);
//     org.jfree.chart.plot.CombinedDomainXYPlot var46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var46.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var50 = var46.getOrientation();
//     org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var46);
//     var51.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var53 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var54 = new org.jfree.chart.plot.PolarPlot();
//     var54.setBackgroundAlpha(1.0f);
//     var53.addChangeListener((org.jfree.data.general.DatasetChangeListener)var54);
//     java.awt.Paint var58 = var54.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     var54.handleClick((-398), 0, var61);
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54);
//     var51.addLegend(var63);
//     java.awt.Color var68 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var69 = var68.brighter();
//     var63.setBackgroundPaint((java.awt.Paint)var68);
//     org.jfree.chart.util.RectangleAnchor var71 = var63.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var76 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var77 = var76.getLicenceName();
//     java.lang.String var78 = var76.getLicenceName();
//     boolean var79 = var71.equals((java.lang.Object)var78);
//     java.awt.geom.Rectangle2D var80 = org.jfree.chart.util.RectangleAnchor.createRectangle(var43, (-3.99999d), 5.0d, var71);
//     var29.trim(var80);
//     org.jfree.chart.axis.NumberTickUnit var83 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var86 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     java.util.List var87 = var86.getItems();
//     var6.drawRangeTickBands(var26, var80, var87);
//     org.jfree.chart.axis.NumberAxis3D var91 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var92 = var91.getTickLabelPaint();
//     org.jfree.chart.plot.IntervalMarker var95 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var96 = var95.getOutlineStroke();
//     var0.drawRangeLine(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var80, 10.0d, var92, var96);
//     
//     // Checks the contract:  equals-hashcode on var13 and var95
//     assertTrue("Contract failed: equals-hashcode on var13 and var95", var13.equals(var95) ? var13.hashCode() == var95.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var95 and var13
//     assertTrue("Contract failed: equals-hashcode on var95 and var13", var95.equals(var13) ? var95.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    int var2 = var0.size();
    org.jfree.chart.axis.TickUnit var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var4 = var0.getCeilingTickUnit(var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var5.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var7 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
//     var8.setBackgroundAlpha(1.0f);
//     var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
//     java.awt.Paint var12 = var8.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     var8.handleClick((-398), 0, var15);
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     var5.addLegend(var17);
//     java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var23 = var22.brighter();
//     var17.setBackgroundPaint((java.awt.Paint)var22);
//     org.jfree.chart.util.RectangleAnchor var25 = var17.getLegendItemGraphicLocation();
//     org.jfree.chart.block.BlockContainer var26 = new org.jfree.chart.block.BlockContainer();
//     var17.setWrapper(var26);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.util.RectangleInsets var30 = var29.getSimpleLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var32 = var31.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var33 = var31.getTickLabelInsets();
//     double var35 = var33.trimHeight(1.0E-5d);
//     double var37 = var33.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var38 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var39 = var38.getLineAlignment();
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var42 = var41.clone();
//     var41.setDescription("");
//     boolean var45 = var38.equals((java.lang.Object)"");
//     java.awt.Graphics2D var46 = null;
//     org.jfree.chart.util.Size2D var47 = var38.calculateDimensions(var46);
//     org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var50.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var54 = var50.getOrientation();
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var50);
//     var55.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var57 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var58 = new org.jfree.chart.plot.PolarPlot();
//     var58.setBackgroundAlpha(1.0f);
//     var57.addChangeListener((org.jfree.data.general.DatasetChangeListener)var58);
//     java.awt.Paint var62 = var58.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     var58.handleClick((-398), 0, var65);
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58);
//     var55.addLegend(var67);
//     java.awt.Color var72 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var73 = var72.brighter();
//     var67.setBackgroundPaint((java.awt.Paint)var72);
//     org.jfree.chart.util.RectangleAnchor var75 = var67.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var80 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var81 = var80.getLicenceName();
//     java.lang.String var82 = var80.getLicenceName();
//     boolean var83 = var75.equals((java.lang.Object)var82);
//     java.awt.geom.Rectangle2D var84 = org.jfree.chart.util.RectangleAnchor.createRectangle(var47, (-3.99999d), 5.0d, var75);
//     var33.trim(var84);
//     java.awt.geom.Rectangle2D var88 = var30.createInsetRectangle(var84, true, true);
//     var26.draw(var28, var88);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var4.add(10.0d, (-1.0d), true);
    double var9 = var4.getMinX();
    org.jfree.data.xy.XYDataItem var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.0d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.labels.PieSectionLabelGenerator var1 = var0.getLegendLabelGenerator();
    java.awt.Stroke var2 = var0.getSeparatorStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     org.jfree.chart.axis.DateTickUnitType var2 = null;
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(var0, 10, var2, 13, var4);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 100);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.lang.Object var2 = var1.clone();
    org.jfree.data.xy.DefaultXYDataset var3 = new org.jfree.data.xy.DefaultXYDataset();
    var1.setDataset((org.jfree.data.general.Dataset)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset)var3, 0, 1.0d, 1.0E-5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var8 = var7.getOutlineStroke();
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
    var9.setBackgroundAlpha(1.0f);
    java.awt.Paint var12 = var9.getBackgroundPaint();
    var7.setPaint(var12);
    var0.setRangeMinorGridlinePaint(var12);
    int var15 = var0.getWeight();
    org.jfree.chart.annotations.XYAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var17 = var0.removeAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getNumberInstance(var0);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Paint var3 = var2.getLabelPaint();
    org.jfree.chart.event.MarkerChangeEvent var4 = null;
    var2.notifyListeners(var4);
    java.awt.Stroke var6 = var2.getStroke();
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var7.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var11 = var7.getOrientation();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    var12.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var14 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
    var15.setBackgroundAlpha(1.0f);
    var14.addChangeListener((org.jfree.data.general.DatasetChangeListener)var15);
    java.awt.Paint var19 = var15.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    var15.handleClick((-398), 0, var22);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    var12.addLegend(var24);
    java.awt.Color var29 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var30 = var29.brighter();
    var24.setBackgroundPaint((java.awt.Paint)var29);
    org.jfree.chart.util.RectangleAnchor var32 = var24.getLegendItemGraphicLocation();
    org.jfree.chart.ui.Library var37 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var38 = var37.getLicenceName();
    java.lang.String var39 = var37.getLicenceName();
    boolean var40 = var32.equals((java.lang.Object)var39);
    var2.setLabelAnchor(var32);
    org.jfree.chart.util.LengthAdjustmentType var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelOffsetType(var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "hi!"+ "'", var38.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "hi!"+ "'", var39.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var6 = var5.getAxisLineStroke();
    boolean var7 = var5.isAutoRange();
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    double var11 = var10.getLowerBound();
    var5.setRangeWithMargins(var10, false, false);
    float var15 = var5.getMinorTickMarkInsideLength();
    org.jfree.data.Range var16 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var5);
    java.awt.Paint var17 = var3.getRangeCrosshairPaint();
    boolean var18 = var3.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.AxisSpace var6 = null;
    var0.setFixedRangeAxisSpace(var6);
    java.awt.Stroke var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeMinorGridlineStroke(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("AxisLabelEntity: label = null", "null", var3);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.plot.CrosshairState var5 = null;
//     boolean var6 = var0.render(var1, var2, 0, var4, var5);
//     var0.setGap(1.0E-8d);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.util.RectangleInsets var11 = var10.getSimpleLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var13 = var12.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var14 = var12.getTickLabelInsets();
//     double var16 = var14.trimHeight(1.0E-5d);
//     double var18 = var14.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var19 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var20 = var19.getLineAlignment();
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var23 = var22.clone();
//     var22.setDescription("");
//     boolean var26 = var19.equals((java.lang.Object)"");
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.util.Size2D var28 = var19.calculateDimensions(var27);
//     org.jfree.chart.plot.CombinedDomainXYPlot var31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var31.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var35 = var31.getOrientation();
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
//     var36.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var38 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot();
//     var39.setBackgroundAlpha(1.0f);
//     var38.addChangeListener((org.jfree.data.general.DatasetChangeListener)var39);
//     java.awt.Paint var43 = var39.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     var39.handleClick((-398), 0, var46);
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     var36.addLegend(var48);
//     java.awt.Color var53 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var54 = var53.brighter();
//     var48.setBackgroundPaint((java.awt.Paint)var53);
//     org.jfree.chart.util.RectangleAnchor var56 = var48.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var61 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var62 = var61.getLicenceName();
//     java.lang.String var63 = var61.getLicenceName();
//     boolean var64 = var56.equals((java.lang.Object)var63);
//     java.awt.geom.Rectangle2D var65 = org.jfree.chart.util.RectangleAnchor.createRectangle(var28, (-3.99999d), 5.0d, var56);
//     var14.trim(var65);
//     java.awt.geom.Rectangle2D var69 = var11.createInsetRectangle(var65, true, true);
//     org.jfree.chart.plot.CombinedDomainXYPlot var70 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var70.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var74 = var70.getOrientation();
//     boolean var75 = var70.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var76 = var70.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var77 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var78 = null;
//     var0.draw(var9, var65, var76, var77, var78);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var8 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var9 = var4.getColorComponents(var8);
    java.awt.Color var10 = java.awt.Color.getColor("TitleEntity: tooltip = AxisLabelEntity: label = null", var4);
    java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var18 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var19 = var14.getColorComponents(var18);
    java.awt.color.ColorSpace var20 = var14.getColorSpace();
    java.awt.Color var24 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var28 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var29 = var24.getColorComponents(var28);
    float[] var30 = var14.getRGBColorComponents(var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var31 = var4.getComponents(var28);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    org.jfree.data.xy.DefaultXYDataset var1 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
    var2.setBackgroundAlpha(1.0f);
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var2);
    int var7 = var1.indexOf((java.lang.Comparable)'a');
    java.lang.Number var8 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var1);
    var1.validateObject();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var0.generateLabel((org.jfree.data.xy.XYDataset)var1, 15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     java.text.NumberFormat var1 = java.text.NumberFormat.getNumberInstance();
//     org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(Double.NaN, var1, 2147483647);
//     int var4 = var1.getMaximumFractionDigits();
//     java.text.ParsePosition var6 = null;
//     java.lang.Object var7 = var1.parseObject("org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.event.RendererChangeEvent[source=1]]", var6);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
    var7.setBackgroundAlpha(1.0f);
    boolean var10 = var6.hasListener((java.util.EventListener)var7);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var4, var11, "hi!", "hi!");
    java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var19 = var18.brighter();
    org.jfree.chart.title.LegendGraphic var20 = new org.jfree.chart.title.LegendGraphic(var11, (java.awt.Paint)var18);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, Double.NaN, 0.2d);
    org.jfree.chart.ChartColor var27 = new org.jfree.chart.ChartColor(10, 100, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem(var0, "PlotOrientation.HORIZONTAL", "AxisLabelEntity: label = null", "org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.event.RendererChangeEvent[source=1]]", var23, (java.awt.Paint)var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
    var6.setBackgroundAlpha(1.0f);
    boolean var9 = var5.hasListener((java.util.EventListener)var6);
    java.awt.Shape var10 = var5.getLeftArrow();
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var14 = var13.getAutoPopulateSeriesFillPaint();
    double var15 = var13.getLowerClip();
    var13.setShadowYOffset(1.0E-5d);
    double var18 = var13.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var20 = null;
    var13.setSeriesNegativeItemLabelPosition(1, var20);
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var24 = var23.getAxisLineStroke();
    java.awt.Font var25 = var23.getLabelFont();
    var13.setBaseItemLabelFont(var25);
    java.awt.Paint var27 = var13.getBaseItemLabelPaint();
    org.jfree.chart.labels.ItemLabelPosition var29 = null;
    var13.setSeriesNegativeItemLabelPosition(15, var29);
    java.awt.Paint var31 = var13.getBaseItemLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem(var0, "org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.event.RendererChangeEvent[source=1]]", "org.jfree.chart.event.ChartProgressEvent[source=org.jfree.chart.event.RendererChangeEvent[source=1]]", "hi!", var10, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     var3.setGap(4.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var6.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var10 = var6.getOrientation();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var11.setNotify(false);
//     var3.addChangeListener((org.jfree.chart.event.PlotChangeListener)var11);
//     org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var15.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var19 = var15.getOrientation();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var15);
//     var20.setNotify(false);
//     var20.setNotify(false);
//     java.lang.Object var25 = var20.getTextAntiAlias();
//     var20.setTextAntiAlias(true);
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var29 = var28.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var30 = var28.getTickLabelInsets();
//     double var31 = var30.getLeft();
//     var20.setPadding(var30);
//     var3.setInsets(var30);
//     
//     // Checks the contract:  equals-hashcode on var6 and var15
//     assertTrue("Contract failed: equals-hashcode on var6 and var15", var6.equals(var15) ? var6.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.setNotify(false);
    var5.setNotify(false);
    java.lang.Object var10 = var5.getTextAntiAlias();
    var5.setTextAntiAlias(true);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var17 = var5.createBufferedImage(10, (-398), (-1), var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    var1.setBackgroundAlpha(1.0f);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
    int var6 = var0.indexOf((java.lang.Comparable)'a');
    org.jfree.data.xy.IntervalXYDelegate var7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var0.getXValue((-398), 255);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var0.setFixedDomainAxisSpace(var5);
//     org.jfree.chart.axis.AxisSpace var7 = new org.jfree.chart.axis.AxisSpace();
//     var0.setFixedRangeAxisSpace(var7);
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var13 = var12.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var14 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var17 = var16.getAxisLineStroke();
//     boolean var18 = var16.isAutoRange();
//     org.jfree.data.Range var21 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var22 = var21.getLowerBound();
//     var16.setRangeWithMargins(var21, false, false);
//     float var26 = var16.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var27 = var14.getDataRange((org.jfree.chart.axis.ValueAxis)var16);
//     java.util.List var28 = var14.getSubplots();
//     org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var30 = var29.getRangeMinorGridlinePaint();
//     var29.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     var29.handleClick(10, 0, var36);
//     java.awt.geom.Rectangle2D var38 = var36.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var39.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var43 = var39.getOrientation();
//     boolean var44 = var39.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var45 = var39.getQuadrantOrigin();
//     org.jfree.chart.plot.XYPlot var46 = var14.findSubplot(var36, var45);
//     org.jfree.chart.axis.NumberAxis3D var48 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var49 = var48.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var50 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var48);
//     org.jfree.chart.axis.NumberAxis3D var52 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var53 = var52.getAxisLineStroke();
//     boolean var54 = var52.isAutoRange();
//     org.jfree.data.Range var57 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var58 = var57.getLowerBound();
//     var52.setRangeWithMargins(var57, false, false);
//     float var62 = var52.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var63 = var50.getDataRange((org.jfree.chart.axis.ValueAxis)var52);
//     java.util.List var64 = var50.getSubplots();
//     org.jfree.chart.plot.CombinedDomainXYPlot var65 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var66 = var65.getRangeMinorGridlinePaint();
//     var65.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var71 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var72 = new org.jfree.chart.plot.PlotRenderingInfo(var71);
//     var65.handleClick(10, 0, var72);
//     java.awt.geom.Rectangle2D var74 = var72.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var75 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var75.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var79 = var75.getOrientation();
//     boolean var80 = var75.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var81 = var75.getQuadrantOrigin();
//     org.jfree.chart.plot.XYPlot var82 = var50.findSubplot(var72, var81);
//     var0.zoomRangeAxes(100.0d, 0.5d, var36, var81);
//     
//     // Checks the contract:  equals-hashcode on var0 and var39
//     assertTrue("Contract failed: equals-hashcode on var0 and var39", var0.equals(var39) ? var0.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var75
//     assertTrue("Contract failed: equals-hashcode on var0 and var75", var0.equals(var75) ? var0.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var65
//     assertTrue("Contract failed: equals-hashcode on var29 and var65", var29.equals(var65) ? var29.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var0
//     assertTrue("Contract failed: equals-hashcode on var39 and var0", var39.equals(var0) ? var39.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var75
//     assertTrue("Contract failed: equals-hashcode on var39 and var75", var39.equals(var75) ? var39.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var29
//     assertTrue("Contract failed: equals-hashcode on var65 and var29", var65.equals(var29) ? var65.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var0
//     assertTrue("Contract failed: equals-hashcode on var75 and var0", var75.equals(var0) ? var75.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var39
//     assertTrue("Contract failed: equals-hashcode on var75 and var39", var75.equals(var39) ? var75.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var50
//     assertTrue("Contract failed: equals-hashcode on var14 and var50", var14.equals(var50) ? var14.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var14
//     assertTrue("Contract failed: equals-hashcode on var50 and var14", var50.equals(var14) ? var50.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var72
//     assertTrue("Contract failed: equals-hashcode on var36 and var72", var36.equals(var72) ? var36.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var36
//     assertTrue("Contract failed: equals-hashcode on var72 and var36", var72.equals(var36) ? var72.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    var0.clearRangeMarkers(1);
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var8 = var7.getOutlineStroke();
    java.awt.Stroke var9 = var7.getOutlineStroke();
    org.jfree.chart.util.Layer var10 = null;
    var0.addRangeMarker(10, (org.jfree.chart.plot.Marker)var7, var10, true);
    org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 1.0d);
    org.jfree.chart.util.Layer var17 = null;
    boolean var19 = var0.removeDomainMarker(13, (org.jfree.chart.plot.Marker)var16, var17, true);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var22 = var21.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var23 = var21.getTickLabelInsets();
    double var25 = var23.trimHeight(1.0E-5d);
    double var27 = var23.calculateBottomInset(1.0E-8d);
    org.jfree.chart.text.TextBlock var28 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var29 = var28.getLineAlignment();
    org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("");
    java.lang.Object var32 = var31.clone();
    var31.setDescription("");
    boolean var35 = var28.equals((java.lang.Object)"");
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.util.Size2D var37 = var28.calculateDimensions(var36);
    org.jfree.chart.plot.CombinedDomainXYPlot var40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var40.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var44 = var40.getOrientation();
    org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var40);
    var45.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var47 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var48 = new org.jfree.chart.plot.PolarPlot();
    var48.setBackgroundAlpha(1.0f);
    var47.addChangeListener((org.jfree.data.general.DatasetChangeListener)var48);
    java.awt.Paint var52 = var48.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    var48.handleClick((-398), 0, var55);
    org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    var45.addLegend(var57);
    java.awt.Color var62 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var63 = var62.brighter();
    var57.setBackgroundPaint((java.awt.Paint)var62);
    org.jfree.chart.util.RectangleAnchor var65 = var57.getLegendItemGraphicLocation();
    org.jfree.chart.ui.Library var70 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var71 = var70.getLicenceName();
    java.lang.String var72 = var70.getLicenceName();
    boolean var73 = var65.equals((java.lang.Object)var72);
    java.awt.geom.Rectangle2D var74 = org.jfree.chart.util.RectangleAnchor.createRectangle(var37, (-3.99999d), 5.0d, var65);
    var23.trim(var74);
    org.jfree.chart.axis.NumberTickUnit var77 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var80 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var81 = var80.getItems();
    var0.drawRangeTickBands(var20, var74, var81);
    org.jfree.data.category.CategoryDataset var85 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var88 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var74, "PlotOrientation.HORIZONTAL", "Combined_Domain_XYPlot", var85, (java.lang.Comparable)"null", (java.lang.Comparable)"{0}: ({1}, {2})");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-3.99999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var71 + "' != '" + "hi!"+ "'", var71.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + "hi!"+ "'", var72.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("10");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.setBackgroundAlpha(1.0f);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
//     java.awt.Paint var5 = var1.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var1.handleClick((-398), 0, var8);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     java.awt.geom.Point2D var13 = null;
//     var1.zoomDomainAxes(Double.NaN, 0.05d, var12, var13);
//     org.jfree.chart.plot.PlotOrientation var15 = var1.getOrientation();
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var18 = var17.getRangeMinorGridlinePaint();
//     var17.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     var17.handleClick(10, 0, var24);
//     java.awt.geom.Rectangle2D var26 = var24.getDataArea();
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var29 = var28.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var28);
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var33 = var32.getAxisLineStroke();
//     boolean var34 = var32.isAutoRange();
//     org.jfree.data.Range var37 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var38 = var37.getLowerBound();
//     var32.setRangeWithMargins(var37, false, false);
//     float var42 = var32.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var43 = var30.getDataRange((org.jfree.chart.axis.ValueAxis)var32);
//     java.util.List var44 = var30.getSubplots();
//     org.jfree.chart.plot.CombinedDomainXYPlot var45 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var46 = var45.getRangeMinorGridlinePaint();
//     var45.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var51 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var52 = new org.jfree.chart.plot.PlotRenderingInfo(var51);
//     var45.handleClick(10, 0, var52);
//     java.awt.geom.Rectangle2D var54 = var52.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var55.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var59 = var55.getOrientation();
//     boolean var60 = var55.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var61 = var55.getQuadrantOrigin();
//     org.jfree.chart.plot.XYPlot var62 = var30.findSubplot(var52, var61);
//     var1.zoomRangeAxes((-3.99999d), var24, var61, true);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var7 = var6.getTickLabelPaint();
    int var8 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
    var6.setNegativeArrowVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var1 = var0.getShapesVisible();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var3 = null;
    org.jfree.chart.text.TextBlock var4 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var5 = var4.getLineAlignment();
    org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem("");
    java.lang.Object var8 = var7.clone();
    var7.setDescription("");
    boolean var11 = var4.equals((java.lang.Object)"");
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.util.Size2D var13 = var4.calculateDimensions(var12);
    org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var16.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var20 = var16.getOrientation();
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
    var21.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var23 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
    var24.setBackgroundAlpha(1.0f);
    var23.addChangeListener((org.jfree.data.general.DatasetChangeListener)var24);
    java.awt.Paint var28 = var24.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    var24.handleClick((-398), 0, var31);
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    var21.addLegend(var33);
    java.awt.Color var38 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var39 = var38.brighter();
    var33.setBackgroundPaint((java.awt.Paint)var38);
    org.jfree.chart.util.RectangleAnchor var41 = var33.getLegendItemGraphicLocation();
    org.jfree.chart.ui.Library var46 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var47 = var46.getLicenceName();
    java.lang.String var48 = var46.getLicenceName();
    boolean var49 = var41.equals((java.lang.Object)var48);
    java.awt.geom.Rectangle2D var50 = org.jfree.chart.util.RectangleAnchor.createRectangle(var13, (-3.99999d), 5.0d, var41);
    org.jfree.chart.axis.NumberAxis3D var52 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var53 = var52.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var54 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var52);
    org.jfree.chart.plot.CombinedDomainXYPlot var55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var56 = var55.getRangeMinorGridlinePaint();
    boolean var57 = var55.isRangeMinorGridlinesVisible();
    var55.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.PlotOrientation var60 = var55.getOrientation();
    var54.setOrientation(var60);
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.axis.NumberAxis3D var64 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var65 = var64.getAxisLineStroke();
    var64.resizeRange2(0.0d, 10.0d);
    java.awt.Font var69 = var64.getTickLabelFont();
    org.jfree.data.Range var70 = var64.getDefaultAutoRange();
    boolean var71 = var64.isAutoTickUnitSelection();
    java.awt.Stroke var72 = var64.getTickMarkStroke();
    org.jfree.chart.LegendItem var74 = new org.jfree.chart.LegendItem("");
    java.lang.Object var75 = var74.clone();
    org.jfree.data.xy.DefaultXYDataset var76 = new org.jfree.data.xy.DefaultXYDataset();
    var74.setDataset((org.jfree.data.general.Dataset)var76);
    org.jfree.data.xy.IntervalXYDelegate var78 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var76);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var2, var3, var50, (org.jfree.chart.plot.XYPlot)var54, var62, (org.jfree.chart.axis.ValueAxis)var64, (org.jfree.data.xy.XYDataset)var76, 3, 13, true, (-398));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "hi!"+ "'", var47.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "hi!"+ "'", var48.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    boolean var2 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedRangeAxisSpace(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var6 = var0.getDomainAxisForDataset(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var7 = var6.getTickLabelPaint();
    int var8 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.plot.DatasetRenderingOrder var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    var1.setBackgroundAlpha(1.0f);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
    int var6 = var0.indexOf((java.lang.Comparable)'a');
    java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var0);
    org.jfree.chart.axis.NumberTickUnit var9 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var13 = var12.getItems();
    org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var16 = var15.getAxisLineStroke();
    var15.resizeRange2(0.0d, 10.0d);
    java.awt.Font var20 = var15.getTickLabelFont();
    org.jfree.data.Range var21 = var15.getDefaultAutoRange();
    org.jfree.chart.ui.Library var26 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var27 = var26.getLicenceName();
    boolean var28 = var21.equals((java.lang.Object)var26);
    org.jfree.data.Range var30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, var13, var21, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var33 = var0.getYValue(10, 13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "hi!"+ "'", var27.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
//     boolean var2 = var0.isRangeMinorGridlinesVisible();
//     var0.setDomainCrosshairVisible(false);
//     org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
//     org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var8 = var7.clone();
//     org.jfree.data.xy.DefaultXYDataset var9 = new org.jfree.data.xy.DefaultXYDataset();
//     var7.setDataset((org.jfree.data.general.Dataset)var9);
//     var5.add(var7);
//     org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var13 = var12.getRangeMinorGridlinePaint();
//     boolean var14 = var12.isRangeMinorGridlinesVisible();
//     var12.setDomainCrosshairVisible(false);
//     org.jfree.chart.LegendItemCollection var17 = var12.getLegendItems();
//     int var18 = var17.getItemCount();
//     int var19 = var17.getItemCount();
//     var5.addAll(var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 1.0d);
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelTextAnchor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var4.add(10.0d, (-1.0d), true);
    var4.setKey((java.lang.Comparable)(byte)(-1));
    boolean var11 = var4.getAllowDuplicateXValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete(0, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("4", var1);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.plot.CrosshairState var5 = null;
//     boolean var6 = var0.render(var1, var2, 0, var4, var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.util.RectangleInsets var9 = var8.getSimpleLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var11 = var10.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getTickLabelInsets();
//     double var14 = var12.trimHeight(1.0E-5d);
//     double var16 = var12.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var17 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var18 = var17.getLineAlignment();
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var21 = var20.clone();
//     var20.setDescription("");
//     boolean var24 = var17.equals((java.lang.Object)"");
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.util.Size2D var26 = var17.calculateDimensions(var25);
//     org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var29.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var33 = var29.getOrientation();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var29);
//     var34.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var36 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot();
//     var37.setBackgroundAlpha(1.0f);
//     var36.addChangeListener((org.jfree.data.general.DatasetChangeListener)var37);
//     java.awt.Paint var41 = var37.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     var37.handleClick((-398), 0, var44);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
//     var34.addLegend(var46);
//     java.awt.Color var51 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var52 = var51.brighter();
//     var46.setBackgroundPaint((java.awt.Paint)var51);
//     org.jfree.chart.util.RectangleAnchor var54 = var46.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var59 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var60 = var59.getLicenceName();
//     java.lang.String var61 = var59.getLicenceName();
//     boolean var62 = var54.equals((java.lang.Object)var61);
//     java.awt.geom.Rectangle2D var63 = org.jfree.chart.util.RectangleAnchor.createRectangle(var26, (-3.99999d), 5.0d, var54);
//     var12.trim(var63);
//     java.awt.geom.Rectangle2D var67 = var9.createInsetRectangle(var63, true, true);
//     var0.drawBackground(var7, var63);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", var3, "", "", "");
    org.jfree.chart.axis.NumberTickUnit var9 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var13 = var12.getItems();
    var7.setContributors(var13);
    var7.setLicenceName("org.jfree.chart.ChartColor[r=10,g=100,b=1]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    java.util.TimeZone var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var4 = var1.isSelected(0, (-398));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 100.0d);
    java.awt.Paint var3 = var2.getOutlinePaint();
    org.jfree.chart.util.LengthAdjustmentType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelOffsetType(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var6 = var5.getAxisLineStroke();
    boolean var7 = var5.isAutoRange();
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    double var11 = var10.getLowerBound();
    var5.setRangeWithMargins(var10, false, false);
    float var15 = var5.getMinorTickMarkInsideLength();
    org.jfree.data.Range var16 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var5);
    java.awt.Paint var17 = var3.getRangeCrosshairPaint();
    org.jfree.chart.annotations.XYAnnotation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.addAnnotation(var18, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var7 = var4.equals((java.lang.Object)"");
    var4.add((java.lang.Number)100.0d, (java.lang.Number)13, false);
    org.jfree.data.xy.XYDataItem var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var2 = var1.getLinePaint();
    boolean var3 = var1.isShapeOutlineVisible();
    java.lang.String var4 = var1.getDescription();
    org.jfree.chart.util.GradientPaintTransformer var5 = var1.getFillPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setFillPaintTransformer(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var3 = var2.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
    var9.setBackgroundAlpha(1.0f);
    boolean var12 = var8.hasListener((java.util.EventListener)var9);
    java.awt.Paint var13 = var9.getAngleLabelPaint();
    var6.setLabelPaint(var13);
    org.jfree.chart.axis.NumberTickUnit var16 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.String var18 = var16.valueToString(0.0d);
    var6.setTickUnit(var16);
    var2.setTickUnit(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var23 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)var16, 0.08d, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "0"+ "'", var18.equals("0"));

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     var3.setGap(4.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var6.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var10 = var6.getOrientation();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var11.setNotify(false);
//     var3.addChangeListener((org.jfree.chart.event.PlotChangeListener)var11);
//     org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var17 = var16.getRangeMinorGridlinePaint();
//     var16.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     var16.handleClick(10, 0, var23);
//     java.awt.geom.Rectangle2D var25 = var23.getDataArea();
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var28 = var27.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var29 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var27);
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var32 = var31.getAxisLineStroke();
//     boolean var33 = var31.isAutoRange();
//     org.jfree.data.Range var36 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var37 = var36.getLowerBound();
//     var31.setRangeWithMargins(var36, false, false);
//     float var41 = var31.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var42 = var29.getDataRange((org.jfree.chart.axis.ValueAxis)var31);
//     java.util.List var43 = var29.getSubplots();
//     org.jfree.chart.plot.CombinedDomainXYPlot var44 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var45 = var44.getRangeMinorGridlinePaint();
//     var44.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var50 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var51 = new org.jfree.chart.plot.PlotRenderingInfo(var50);
//     var44.handleClick(10, 0, var51);
//     java.awt.geom.Rectangle2D var53 = var51.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var54 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var54.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var58 = var54.getOrientation();
//     boolean var59 = var54.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var60 = var54.getQuadrantOrigin();
//     org.jfree.chart.plot.XYPlot var61 = var29.findSubplot(var51, var60);
//     var3.panDomainAxes(100.0d, var23, var60);
//     
//     // Checks the contract:  equals-hashcode on var6 and var54
//     assertTrue("Contract failed: equals-hashcode on var6 and var54", var6.equals(var54) ? var6.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var44
//     assertTrue("Contract failed: equals-hashcode on var16 and var44", var16.equals(var44) ? var16.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var16
//     assertTrue("Contract failed: equals-hashcode on var44 and var16", var44.equals(var16) ? var44.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var6
//     assertTrue("Contract failed: equals-hashcode on var54 and var6", var54.equals(var6) ? var54.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var51
//     assertTrue("Contract failed: equals-hashcode on var23 and var51", var23.equals(var51) ? var23.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var23
//     assertTrue("Contract failed: equals-hashcode on var51 and var23", var51.equals(var23) ? var51.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("10", var1, var2);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var4 = var2.lookupSeriesPaint(10);
    java.lang.Boolean var6 = var2.getSeriesVisible(100);
    java.awt.Paint var8 = var2.lookupSeriesOutlinePaint(255);
    var2.setBaseItemLabelsVisible(false, false);
    org.jfree.chart.annotations.CategoryAnnotation var12 = null;
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addAnnotation(var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var0.setUseOutlinePaint(true);
    boolean var3 = var0.getDrawSeriesLineAsPath();
    var0.setUseOutlinePaint(false);
    java.awt.Shape var7 = var0.getLegendShape(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesFilled((-398), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    boolean var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    boolean var1 = var0.isVerticalTickLabels();
    java.util.TimeZone var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTimeZone(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.lang.String var1 = var0.getLabelFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "{0}: ({1}, {2})"+ "'", var1.equals("{0}: ({1}, {2})"));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    org.jfree.data.xy.IntervalXYDelegate var3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    boolean var4 = var3.isAutoWidth();
    double var5 = var3.getFixedIntervalWidth();
    var3.setFixedIntervalWidth(1.0E-5d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var3.getEndXValue((-398), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getNumberInstance();
    org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(Double.NaN, var1, 2147483647);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var4.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var8 = var4.getOrientation();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.util.LogFormat var14 = new org.jfree.chart.util.LogFormat(0.0d, "", "", false);
    java.lang.StringBuffer var16 = null;
    java.text.FieldPosition var17 = null;
    java.lang.StringBuffer var18 = var14.format((-1.0d), var16, var17);
    java.text.FieldPosition var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.StringBuffer var20 = var1.format((java.lang.Object)var4, var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     double var5 = var4.getMinX();
//     var4.setDescription("");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.xy.XYDataItem var9 = var4.getDataItem(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var3 = var2.getAxisLineStroke();
//     java.awt.Font var4 = var2.getLabelFont();
//     org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange();
//     var2.setRangeWithMargins((org.jfree.data.Range)var5, false, true);
//     java.util.Date var9 = var5.getLowerDate();
//     org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange(var0, var9);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
//     org.jfree.chart.LegendItemCollection var2 = var0.getFixedLegendItems();
//     int var3 = var0.getRangeAxisCount();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
//     var7.setBackgroundAlpha(1.0f);
//     boolean var10 = var6.hasListener((java.util.EventListener)var7);
//     java.awt.Shape var11 = var6.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var4, var11, "hi!", "hi!");
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
//     java.awt.Paint var17 = var16.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("");
//     java.awt.Paint var20 = var19.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var23 = var22.getAxisLineStroke();
//     var22.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var27 = var22.getTickLabelFont();
//     org.jfree.data.Range var28 = var22.getDefaultAutoRange();
//     boolean var29 = var22.isAutoTickUnitSelection();
//     java.awt.Paint var30 = var22.getTickLabelPaint();
//     var19.setBackgroundPaint(var30);
//     boolean var32 = var16.equals((java.lang.Object)var30);
//     org.jfree.chart.entity.TitleEntity var34 = new org.jfree.chart.entity.TitleEntity(var11, (org.jfree.chart.title.Title)var16, "AxisLabelEntity: label = null");
//     org.jfree.data.xy.DefaultXYDataset var35 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.data.Range var37 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var35, true);
//     org.jfree.data.xy.IntervalXYDelegate var38 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var35);
//     java.lang.Object var39 = var35.clone();
//     org.jfree.chart.entity.XYItemEntity var44 = new org.jfree.chart.entity.XYItemEntity(var11, (org.jfree.data.xy.XYDataset)var35, (-1), 15, "null", "");
//     var0.setDataset((org.jfree.data.xy.XYDataset)var35);
//     org.jfree.chart.plot.CombinedDomainXYPlot var46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var46.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var50 = var46.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var53 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var54 = var53.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot();
//     var55.setBackgroundAlpha(1.0f);
//     java.awt.Paint var58 = var55.getBackgroundPaint();
//     var53.setPaint(var58);
//     var46.setRangeMinorGridlinePaint(var58);
//     org.jfree.chart.axis.AxisSpace var61 = null;
//     var46.setFixedDomainAxisSpace(var61);
//     java.awt.Stroke var63 = var46.getRangeZeroBaselineStroke();
//     var0.setDomainZeroBaselineStroke(var63);
//     
//     // Checks the contract:  equals-hashcode on var7 and var55
//     assertTrue("Contract failed: equals-hashcode on var7 and var55", var7.equals(var55) ? var7.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var7
//     assertTrue("Contract failed: equals-hashcode on var55 and var7", var55.equals(var7) ? var55.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     var3.setGap(4.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var6.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var10 = var6.getOrientation();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var11.setNotify(false);
//     var3.addChangeListener((org.jfree.chart.event.PlotChangeListener)var11);
//     org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var15.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var19 = var15.getOrientation();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var15);
//     var20.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var22 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     var23.setBackgroundAlpha(1.0f);
//     var22.addChangeListener((org.jfree.data.general.DatasetChangeListener)var23);
//     java.awt.Paint var27 = var23.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var23.handleClick((-398), 0, var30);
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
//     var20.addLegend(var32);
//     java.awt.Color var37 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var38 = var37.brighter();
//     var32.setBackgroundPaint((java.awt.Paint)var37);
//     java.awt.Font var40 = var32.getItemFont();
//     var11.addSubtitle((org.jfree.chart.title.Title)var32);
//     
//     // Checks the contract:  equals-hashcode on var6 and var15
//     assertTrue("Contract failed: equals-hashcode on var6 and var15", var6.equals(var15) ? var6.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.util.RectangleInsets var1 = var0.getSimpleLabelOffset();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var4 = var2.getTickLabelInsets();
    double var6 = var4.trimHeight(1.0E-5d);
    double var8 = var4.calculateBottomInset(1.0E-8d);
    org.jfree.chart.text.TextBlock var9 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var10 = var9.getLineAlignment();
    org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("");
    java.lang.Object var13 = var12.clone();
    var12.setDescription("");
    boolean var16 = var9.equals((java.lang.Object)"");
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.util.Size2D var18 = var9.calculateDimensions(var17);
    org.jfree.chart.plot.CombinedDomainXYPlot var21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var21.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var25 = var21.getOrientation();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var21);
    var26.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var28 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot();
    var29.setBackgroundAlpha(1.0f);
    var28.addChangeListener((org.jfree.data.general.DatasetChangeListener)var29);
    java.awt.Paint var33 = var29.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    var29.handleClick((-398), 0, var36);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
    var26.addLegend(var38);
    java.awt.Color var43 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var44 = var43.brighter();
    var38.setBackgroundPaint((java.awt.Paint)var43);
    org.jfree.chart.util.RectangleAnchor var46 = var38.getLegendItemGraphicLocation();
    org.jfree.chart.ui.Library var51 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var52 = var51.getLicenceName();
    java.lang.String var53 = var51.getLicenceName();
    boolean var54 = var46.equals((java.lang.Object)var53);
    java.awt.geom.Rectangle2D var55 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, (-3.99999d), 5.0d, var46);
    var4.trim(var55);
    java.awt.geom.Rectangle2D var59 = var1.createInsetRectangle(var55, true, true);
    double var61 = var1.trimHeight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-3.99999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + "hi!"+ "'", var52.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "hi!"+ "'", var53.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.lang.Object var2 = var1.clone();
    var1.setDescription("");
    java.awt.Paint var5 = var1.getLinePaint();
    var1.setToolTipText("PlotOrientation.HORIZONTAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.removeCategoryLabelToolTip((java.lang.Comparable)2147483647);
//     java.lang.Object var3 = var0.clone();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.xy.DefaultXYDataset var5 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
//     var6.setBackgroundAlpha(1.0f);
//     var5.addChangeListener((org.jfree.data.general.DatasetChangeListener)var6);
//     java.awt.Paint var10 = var6.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     var6.handleClick((-398), 0, var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     org.jfree.chart.text.TextBlock var16 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var17 = var16.getLineAlignment();
//     org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var20 = var19.clone();
//     var19.setDescription("");
//     boolean var23 = var16.equals((java.lang.Object)"");
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.util.Size2D var25 = var16.calculateDimensions(var24);
//     org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var28.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var32 = var28.getOrientation();
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
//     var33.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var35 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot();
//     var36.setBackgroundAlpha(1.0f);
//     var35.addChangeListener((org.jfree.data.general.DatasetChangeListener)var36);
//     java.awt.Paint var40 = var36.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     var36.handleClick((-398), 0, var43);
//     org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
//     var33.addLegend(var45);
//     java.awt.Color var50 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var51 = var50.brighter();
//     var45.setBackgroundPaint((java.awt.Paint)var50);
//     org.jfree.chart.util.RectangleAnchor var53 = var45.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var58 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var59 = var58.getLicenceName();
//     java.lang.String var60 = var58.getLicenceName();
//     boolean var61 = var53.equals((java.lang.Object)var60);
//     java.awt.geom.Rectangle2D var62 = org.jfree.chart.util.RectangleAnchor.createRectangle(var25, (-3.99999d), 5.0d, var53);
//     org.jfree.chart.plot.CombinedDomainXYPlot var63 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var63.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var67 = var63.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var70 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var71 = var70.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var72 = new org.jfree.chart.plot.PolarPlot();
//     var72.setBackgroundAlpha(1.0f);
//     java.awt.Paint var75 = var72.getBackgroundPaint();
//     var70.setPaint(var75);
//     var63.setRangeMinorGridlinePaint(var75);
//     int var78 = var63.getWeight();
//     org.jfree.chart.axis.NumberAxis3D var80 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var81 = var80.getAxisLineStroke();
//     boolean var82 = var80.isAutoRange();
//     java.awt.Shape var83 = var80.getLeftArrow();
//     int var84 = var63.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var80);
//     org.jfree.chart.util.RectangleEdge var85 = var63.getRangeAxisEdge();
//     org.jfree.chart.plot.CombinedDomainXYPlot var86 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var86.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var90 = var86.getOrientation();
//     org.jfree.chart.axis.AxisSpace var91 = null;
//     var86.setFixedDomainAxisSpace(var91);
//     org.jfree.chart.axis.AxisSpace var93 = new org.jfree.chart.axis.AxisSpace();
//     var86.setFixedRangeAxisSpace(var93);
//     org.jfree.chart.axis.AxisSpace var95 = var0.reserveSpace(var4, (org.jfree.chart.plot.Plot)var6, var62, var85, var93);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var7 = var6.getTickLabelPaint();
    int var8 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.util.Layer var9 = null;
    java.util.Collection var10 = var0.getRangeMarkers(var9);
    org.jfree.chart.annotations.XYAnnotation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var12 = var0.removeAnnotation(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var2 = var1.getRangeMinorGridlinePaint();
//     boolean var3 = var0.equals((java.lang.Object)var2);
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var5 = var4.getRangeMinorGridlinePaint();
//     boolean var6 = var4.isRangeMinorGridlinesVisible();
//     var4.setDomainCrosshairVisible(false);
//     org.jfree.chart.LegendItemCollection var9 = var4.getLegendItems();
//     java.awt.Stroke var10 = var4.getRangeGridlineStroke();
//     var0.setTickMarkStroke(var10);
//     
//     // Checks the contract:  equals-hashcode on var1 and var4
//     assertTrue("Contract failed: equals-hashcode on var1 and var4", var1.equals(var4) ? var1.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    double var7 = var2.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var8 = var2.getPositiveItemLabelPositionFallback();
    double var9 = var2.getShadowYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0E-5d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    boolean var6 = var2.hasListener((java.util.EventListener)var3);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
    java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var7, (java.awt.Paint)var14);
    java.text.NumberFormat var18 = java.text.NumberFormat.getNumberInstance();
    org.jfree.chart.axis.NumberTickUnit var19 = new org.jfree.chart.axis.NumberTickUnit(2.0d, var18);
    boolean var20 = var14.equals((java.lang.Object)var19);
    java.awt.Color var24 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var28 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var29 = var24.getColorComponents(var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var30 = var14.getRGBComponents(var29);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    var1.setBackgroundAlpha(1.0f);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
    java.util.List var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset)var0, var5, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    org.jfree.chart.LegendItemCollection var2 = var0.getFixedLegendItems();
    java.awt.Stroke var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeGridlineStroke(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.lang.Object var2 = var1.clone();
    org.jfree.data.xy.DefaultXYDataset var3 = new org.jfree.data.xy.DefaultXYDataset();
    var1.setDataset((org.jfree.data.general.Dataset)var3);
    org.jfree.data.general.Dataset var5 = var1.getDataset();
    java.awt.Color var9 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var10 = var9.brighter();
    var1.setFillPaint((java.awt.Paint)var10);
    int var12 = var10.getGreen();
    java.awt.Color var16 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    java.awt.color.ColorSpace var17 = var16.getColorSpace();
    java.awt.Color var21 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var25 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var26 = var21.getColorComponents(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var27 = var10.getComponents(var17, var26);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var1);
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var5 = var4.getAxisLineStroke();
//     var4.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var9 = var4.getTickLabelFont();
//     var0.setNoDataMessageFont(var9);
//     double var11 = var0.getMinimumArcAngleToDraw();
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot();
//     var14.setBackgroundAlpha(1.0f);
//     boolean var17 = var13.hasListener((java.util.EventListener)var14);
//     java.awt.Shape var18 = var13.getLeftArrow();
//     double var19 = var13.getLowerBound();
//     java.awt.Paint var20 = var13.getTickLabelPaint();
//     var0.setLabelPaint(var20);
//     org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var22.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var26 = var22.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var30 = var29.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot();
//     var31.setBackgroundAlpha(1.0f);
//     java.awt.Paint var34 = var31.getBackgroundPaint();
//     var29.setPaint(var34);
//     var22.setRangeMinorGridlinePaint(var34);
//     org.jfree.chart.axis.AxisSpace var37 = null;
//     var22.setFixedDomainAxisSpace(var37);
//     java.awt.Stroke var39 = var22.getRangeZeroBaselineStroke();
//     var0.setSeparatorStroke(var39);
//     
//     // Checks the contract:  equals-hashcode on var14 and var31
//     assertTrue("Contract failed: equals-hashcode on var14 and var31", var14.equals(var31) ? var14.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var14
//     assertTrue("Contract failed: equals-hashcode on var31 and var14", var31.equals(var14) ? var31.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    boolean var4 = var2.contains(100.0d);
    double var5 = var2.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-457));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var2 = var1.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var5 = var4.getAxisLineStroke();
    var4.resizeRange2(0.0d, 10.0d);
    java.awt.Font var9 = var4.getTickLabelFont();
    org.jfree.data.Range var10 = var4.getDefaultAutoRange();
    boolean var11 = var4.isAutoTickUnitSelection();
    java.awt.Paint var12 = var4.getTickLabelPaint();
    var1.setBackgroundPaint(var12);
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var1.draw(var14, var15);
    org.jfree.chart.util.RectangleInsets var17 = var1.getPadding();
    org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var18.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var22 = var18.getOrientation();
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var18);
    var23.setNotify(false);
    int var26 = var23.getSubtitleCount();
    var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var7 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
    var8.setBackgroundAlpha(1.0f);
    var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
    java.awt.Paint var12 = var8.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    var8.handleClick((-398), 0, var15);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    var5.addLegend(var17);
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var23 = var22.brighter();
    var17.setBackgroundPaint((java.awt.Paint)var22);
    java.awt.Color var28 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var32 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var33 = var28.getColorComponents(var32);
    java.awt.color.ColorSpace var34 = var28.getColorSpace();
    java.awt.Color var38 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var42 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var43 = var38.getColorComponents(var42);
    float[] var44 = var28.getRGBColorComponents(var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var45 = var22.getRGBComponents(var42);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
//     org.jfree.chart.LegendItemCollection var2 = var0.getFixedLegendItems();
//     org.jfree.chart.axis.AxisLocation var4 = var0.getDomainAxisLocation(255);
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var8 = var7.getRangeMinorGridlinePaint();
//     var7.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     var7.handleClick(10, 0, var14);
//     java.awt.geom.Rectangle2D var16 = var14.getDataArea();
//     var0.handleClick(10, 3, var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var2 = var1.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var5 = var4.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var8 = var7.getAxisLineStroke();
    var7.resizeRange2(0.0d, 10.0d);
    java.awt.Font var12 = var7.getTickLabelFont();
    org.jfree.data.Range var13 = var7.getDefaultAutoRange();
    boolean var14 = var7.isAutoTickUnitSelection();
    java.awt.Paint var15 = var7.getTickLabelPaint();
    var4.setBackgroundPaint(var15);
    boolean var17 = var1.equals((java.lang.Object)var15);
    java.awt.Color var21 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var22 = var21.brighter();
    var1.setBackgroundPaint((java.awt.Paint)var22);
    org.jfree.chart.util.VerticalAlignment var24 = var1.getVerticalAlignment();
    java.lang.String var25 = var24.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "VerticalAlignment.CENTER"+ "'", var25.equals("VerticalAlignment.CENTER"));

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.xy.DefaultXYDataset var3 = new org.jfree.data.xy.DefaultXYDataset();
//     var1.setDataset((org.jfree.data.general.Dataset)var3);
//     org.jfree.data.xy.IntervalXYDelegate var5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var3);
//     double var7 = var5.getDomainLowerBound(false);
//     double var8 = var5.getIntervalPositionFactor();
//     double var9 = var5.getIntervalWidth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var2 = var1.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var3 = var1.getTickLabelInsets();
    double var5 = var3.trimHeight(1.0E-5d);
    double var7 = var3.calculateBottomInset(1.0E-8d);
    var0.setSimpleLabelOffset(var3);
    org.jfree.chart.plot.AbstractPieLabelDistributor var9 = var0.getLabelDistributor();
    var0.setDarkerSides(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-3.99999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     java.util.TimeZone var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     double var3 = var1.getDomainLowerBound(false);
//     java.util.List var4 = null;
//     org.jfree.data.Range var6 = var1.getDomainBounds(var4, true);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("500%", (-457), 3);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     var3.setGap(4.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var6.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var10 = var6.getOrientation();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var11.setNotify(false);
//     var3.addChangeListener((org.jfree.chart.event.PlotChangeListener)var11);
//     var3.setDomainCrosshairValue(9.99999999995449E-6d);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.util.RectangleInsets var19 = var18.getSimpleLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var21 = var20.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var22 = var20.getTickLabelInsets();
//     double var24 = var22.trimHeight(1.0E-5d);
//     double var26 = var22.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var27 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var28 = var27.getLineAlignment();
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var31 = var30.clone();
//     var30.setDescription("");
//     boolean var34 = var27.equals((java.lang.Object)"");
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.util.Size2D var36 = var27.calculateDimensions(var35);
//     org.jfree.chart.plot.CombinedDomainXYPlot var39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var39.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var43 = var39.getOrientation();
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var39);
//     var44.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var46 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var47 = new org.jfree.chart.plot.PolarPlot();
//     var47.setBackgroundAlpha(1.0f);
//     var46.addChangeListener((org.jfree.data.general.DatasetChangeListener)var47);
//     java.awt.Paint var51 = var47.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     var47.handleClick((-398), 0, var54);
//     org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
//     var44.addLegend(var56);
//     java.awt.Color var61 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var62 = var61.brighter();
//     var56.setBackgroundPaint((java.awt.Paint)var61);
//     org.jfree.chart.util.RectangleAnchor var64 = var56.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var69 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var70 = var69.getLicenceName();
//     java.lang.String var71 = var69.getLicenceName();
//     boolean var72 = var64.equals((java.lang.Object)var71);
//     java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var36, (-3.99999d), 5.0d, var64);
//     var22.trim(var73);
//     java.awt.geom.Rectangle2D var77 = var19.createInsetRectangle(var73, true, true);
//     org.jfree.chart.plot.CombinedDomainXYPlot var78 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var78.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var82 = var78.getOrientation();
//     boolean var83 = var78.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var84 = var78.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var85 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.CombinedDomainXYPlot var86 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var87 = var86.getRangeMinorGridlinePaint();
//     var86.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var92 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var93 = new org.jfree.chart.plot.PlotRenderingInfo(var92);
//     var86.handleClick(10, 0, var93);
//     java.awt.geom.Rectangle2D var95 = var93.getDataArea();
//     var3.draw(var17, var73, var84, var85, var93);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var2 = var1.getLinePaint();
    boolean var3 = var1.isShapeVisible();
    java.awt.Paint var4 = var1.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    boolean var6 = var2.hasListener((java.util.EventListener)var3);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
    double var11 = var0.getUpperMargin();
    java.awt.Font var12 = var0.getLabelFont();
    var0.setUpperBound(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(13, 2147483647, (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"4", "Combined_Domain_XYPlot", "PlotOrientation.HORIZONTAL");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete(13, 255, false);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var0.setFixedDomainAxisSpace(var5);
//     org.jfree.chart.axis.AxisSpace var7 = new org.jfree.chart.axis.AxisSpace();
//     var0.setFixedRangeAxisSpace(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var11 = var10.getRangeMinorGridlinePaint();
//     var10.clearRangeMarkers(1);
//     org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var18 = var17.getOutlineStroke();
//     java.awt.Stroke var19 = var17.getOutlineStroke();
//     org.jfree.chart.util.Layer var20 = null;
//     var10.addRangeMarker(10, (org.jfree.chart.plot.Marker)var17, var20, true);
//     org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 1.0d);
//     org.jfree.chart.util.Layer var27 = null;
//     boolean var29 = var10.removeDomainMarker(13, (org.jfree.chart.plot.Marker)var26, var27, true);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var32 = var31.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var33 = var31.getTickLabelInsets();
//     double var35 = var33.trimHeight(1.0E-5d);
//     double var37 = var33.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var38 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var39 = var38.getLineAlignment();
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var42 = var41.clone();
//     var41.setDescription("");
//     boolean var45 = var38.equals((java.lang.Object)"");
//     java.awt.Graphics2D var46 = null;
//     org.jfree.chart.util.Size2D var47 = var38.calculateDimensions(var46);
//     org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var50.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var54 = var50.getOrientation();
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var50);
//     var55.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var57 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var58 = new org.jfree.chart.plot.PolarPlot();
//     var58.setBackgroundAlpha(1.0f);
//     var57.addChangeListener((org.jfree.data.general.DatasetChangeListener)var58);
//     java.awt.Paint var62 = var58.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     var58.handleClick((-398), 0, var65);
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58);
//     var55.addLegend(var67);
//     java.awt.Color var72 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var73 = var72.brighter();
//     var67.setBackgroundPaint((java.awt.Paint)var72);
//     org.jfree.chart.util.RectangleAnchor var75 = var67.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var80 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var81 = var80.getLicenceName();
//     java.lang.String var82 = var80.getLicenceName();
//     boolean var83 = var75.equals((java.lang.Object)var82);
//     java.awt.geom.Rectangle2D var84 = org.jfree.chart.util.RectangleAnchor.createRectangle(var47, (-3.99999d), 5.0d, var75);
//     var33.trim(var84);
//     org.jfree.chart.axis.NumberTickUnit var87 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var90 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     java.util.List var91 = var90.getItems();
//     var10.drawRangeTickBands(var30, var84, var91);
//     var0.drawBackground(var9, var84);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"4", "Combined_Domain_XYPlot", "PlotOrientation.HORIZONTAL");
    org.jfree.data.time.RegularTimePeriod var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.add(var4, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
//     var2.setBackgroundAlpha(1.0f);
//     boolean var5 = var1.hasListener((java.util.EventListener)var2);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var8 = var7.getRangeMinorGridlinePaint();
//     org.jfree.chart.LegendItemCollection var9 = var7.getFixedLegendItems();
//     org.jfree.chart.axis.AxisLocation var11 = var7.getDomainAxisLocation(255);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var14 = var13.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var15 = var13.getTickLabelInsets();
//     double var17 = var15.trimHeight(1.0E-5d);
//     double var19 = var15.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var20 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var21 = var20.getLineAlignment();
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var24 = var23.clone();
//     var23.setDescription("");
//     boolean var27 = var20.equals((java.lang.Object)"");
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.util.Size2D var29 = var20.calculateDimensions(var28);
//     org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var32.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var36 = var32.getOrientation();
//     org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var32);
//     var37.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var39 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot();
//     var40.setBackgroundAlpha(1.0f);
//     var39.addChangeListener((org.jfree.data.general.DatasetChangeListener)var40);
//     java.awt.Paint var44 = var40.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     var40.handleClick((-398), 0, var47);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
//     var37.addLegend(var49);
//     java.awt.Color var54 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var55 = var54.brighter();
//     var49.setBackgroundPaint((java.awt.Paint)var54);
//     org.jfree.chart.util.RectangleAnchor var57 = var49.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var62 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var63 = var62.getLicenceName();
//     java.lang.String var64 = var62.getLicenceName();
//     boolean var65 = var57.equals((java.lang.Object)var64);
//     java.awt.geom.Rectangle2D var66 = org.jfree.chart.util.RectangleAnchor.createRectangle(var29, (-3.99999d), 5.0d, var57);
//     var15.trim(var66);
//     org.jfree.chart.axis.NumberAxis3D var69 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var70 = var69.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var71 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var69);
//     org.jfree.chart.axis.NumberAxis3D var73 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var74 = var73.getAxisLineStroke();
//     boolean var75 = var73.isAutoRange();
//     org.jfree.data.Range var78 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var79 = var78.getLowerBound();
//     var73.setRangeWithMargins(var78, false, false);
//     float var83 = var73.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var84 = var71.getDataRange((org.jfree.chart.axis.ValueAxis)var73);
//     java.util.List var85 = var71.getSubplots();
//     var7.drawDomainTickBands(var12, var66, var85);
//     var2.drawBackground(var6, var66);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var5 = var4.getRangeMinorGridlinePaint();
    boolean var6 = var4.isRangeMinorGridlinesVisible();
    var4.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.PlotOrientation var9 = var4.getOrientation();
    var3.setOrientation(var9);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.util.RectangleEdge var15 = null;
    double var16 = var12.valueToJava2D(1.0d, var14, var15);
    double var17 = var12.getAutoRangeMinimumSize();
    boolean var18 = var12.isNegativeArrowVisible();
    var3.setRangeAxis(13, (org.jfree.chart.axis.ValueAxis)var12, true);
    java.lang.String var21 = var3.getPlotType();
    org.jfree.chart.plot.IntervalMarker var24 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Paint var25 = var24.getLabelPaint();
    org.jfree.chart.renderer.xy.XYAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.plot.XYPlot var27 = var26.getPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.lang.String var29 = var28.getPlotType();
    var26.setPlot((org.jfree.chart.plot.XYPlot)var28);
    org.jfree.chart.labels.XYSeriesLabelGenerator var31 = null;
    var26.setLegendItemURLGenerator(var31);
    var26.removeAnnotations();
    org.jfree.chart.LegendItemCollection var34 = var26.getLegendItems();
    org.jfree.chart.labels.ItemLabelPosition var36 = var26.getSeriesPositiveItemLabelPosition(1);
    org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var39 = var38.getLinePaint();
    boolean var40 = var38.isShapeOutlineVisible();
    java.lang.String var41 = var38.getDescription();
    org.jfree.chart.util.GradientPaintTransformer var42 = var38.getFillPaintTransformer();
    var26.setGradientTransformer(var42);
    var24.setGradientPaintTransformer(var42);
    org.jfree.chart.util.Layer var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.addDomainMarker((org.jfree.chart.plot.Marker)var24, var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Combined Range XYPlot"+ "'", var21.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "Combined_Domain_XYPlot"+ "'", var29.equals("Combined_Domain_XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var3 = var2.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var7 = var6.getAxisLineStroke();
    boolean var8 = var6.isAutoRange();
    org.jfree.data.Range var11 = new org.jfree.data.Range(0.0d, 0.0d);
    double var12 = var11.getLowerBound();
    var6.setRangeWithMargins(var11, false, false);
    float var16 = var6.getMinorTickMarkInsideLength();
    org.jfree.data.Range var17 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
    java.util.List var18 = var4.getSubplots();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var20 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(var0, var18, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    int var2 = var1.getMaximumLinesToDisplay();
    java.lang.Object var3 = var1.clone();
    org.jfree.chart.plot.IntervalMarker var10 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
    var11.setBackgroundAlpha(1.0f);
    java.awt.Paint var14 = var11.getBackgroundPaint();
    var10.setLabelPaint(var14);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 0.0d, 100.0d, var14);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var16);
    org.jfree.chart.event.RendererChangeEvent var19 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var1, false);
    var1.setURLText("org.jfree.chart.ChartColor[r=10,g=100,b=1]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(1, var1);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var0.getCategorySeriesMiddle(0, 0, (-398), 1, 0.05d, var6, var7);
    org.jfree.data.xy.DefaultXYDataset var9 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot();
    var10.setBackgroundAlpha(1.0f);
    var9.addChangeListener((org.jfree.data.general.DatasetChangeListener)var10);
    java.awt.Paint var14 = var10.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    var10.handleClick((-398), 0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
    var0.setPlot((org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("");
    java.lang.Object var24 = var23.clone();
    var23.setDescription("");
    java.awt.Paint var27 = var23.getLinePaint();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot();
    var30.setBackgroundAlpha(1.0f);
    boolean var33 = var29.hasListener((java.util.EventListener)var30);
    java.awt.Paint var34 = var30.getAngleLabelPaint();
    org.jfree.chart.plot.Plot var35 = var30.getParent();
    boolean var36 = var30.isAngleLabelsVisible();
    org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot();
    double var38 = var37.getMinimumArcAngleToDraw();
    java.awt.Stroke var39 = var37.getLabelOutlineStroke();
    java.awt.Color var44 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var48 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var49 = var44.getColorComponents(var48);
    java.awt.color.ColorSpace var50 = var44.getColorSpace();
    java.awt.Color var54 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var58 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var59 = var54.getColorComponents(var58);
    float[] var60 = var44.getRGBColorComponents(var58);
    var37.setSectionPaint((java.lang.Comparable)(byte)(-1), (java.awt.Paint)var44);
    var30.setRadiusGridlinePaint((java.awt.Paint)var44);
    var23.setLinePaint((java.awt.Paint)var44);
    var0.setTickLabelPaint((java.lang.Comparable)(-1), (java.awt.Paint)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var7 = var4.equals((java.lang.Object)"");
    var4.add((java.lang.Number)100.0d, (java.lang.Number)13, false);
    java.lang.Comparable var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setKey(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.lang.Object var2 = var1.clone();
    var1.setDescription("");
    java.lang.String var5 = var1.getLabel();
    var1.setLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.axis.AxisLocation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var6 = var5.getAxisLineStroke();
    boolean var7 = var5.isAutoRange();
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    double var11 = var10.getLowerBound();
    var5.setRangeWithMargins(var10, false, false);
    float var15 = var5.getMinorTickMarkInsideLength();
    org.jfree.data.Range var16 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var5);
    java.awt.Stroke var17 = var5.getAxisLineStroke();
    java.io.ObjectOutputStream var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     double var5 = var4.getMinX();
//     var4.setDescription("");
//     var4.fireSeriesChanged();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setBackgroundAlpha(1.0f);
//     boolean var6 = var2.hasListener((java.util.EventListener)var3);
//     java.awt.Shape var7 = var2.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
//     java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var15 = var14.brighter();
//     org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var7, (java.awt.Paint)var14);
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot();
//     var25.setBackgroundAlpha(1.0f);
//     boolean var28 = var24.hasListener((java.util.EventListener)var25);
//     java.awt.Paint var29 = var25.getAngleLabelPaint();
//     var22.setLabelPaint(var29);
//     java.lang.String var31 = var22.getLabelURL();
//     java.awt.Shape var32 = var22.getDownArrow();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
//     java.awt.Paint var35 = var33.lookupSeriesFillPaint(100);
//     org.jfree.chart.plot.IntervalMarker var38 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Paint var39 = var38.getLabelPaint();
//     org.jfree.chart.event.MarkerChangeEvent var40 = null;
//     var38.notifyListeners(var40);
//     java.awt.Stroke var42 = var38.getStroke();
//     org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var45 = var44.getLinePaint();
//     boolean var46 = var44.isShapeOutlineVisible();
//     java.awt.Color var50 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.image.ColorModel var51 = null;
//     java.awt.Rectangle var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     java.awt.geom.AffineTransform var54 = null;
//     java.awt.RenderingHints var55 = null;
//     java.awt.PaintContext var56 = var50.createContext(var51, var52, var53, var54, var55);
//     var44.setOutlinePaint((java.awt.Paint)var50);
//     org.jfree.chart.LegendItem var58 = new org.jfree.chart.LegendItem("DateTickMarkPosition.START", "DateTickMarkPosition.START", "VerticalAlignment.CENTER", "DateTickMarkPosition.START", var32, var35, var42, (java.awt.Paint)var50);
//     var16.setLine(var32);
//     
//     // Checks the contract:  equals-hashcode on var3 and var25
//     assertTrue("Contract failed: equals-hashcode on var3 and var25", var3.equals(var25) ? var3.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var3
//     assertTrue("Contract failed: equals-hashcode on var25 and var3", var25.equals(var3) ? var25.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    boolean var2 = var0.isRangeMinorGridlinesVisible();
    var0.setBackgroundImageAlignment(2147483647);
    org.jfree.data.xy.DefaultXYDataset var5 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
    var6.setBackgroundAlpha(1.0f);
    var5.addChangeListener((org.jfree.data.general.DatasetChangeListener)var6);
    int var11 = var5.indexOf((java.lang.Comparable)'a');
    org.jfree.data.xy.IntervalXYDelegate var12 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var5);
    int var13 = var0.indexOf((org.jfree.data.xy.XYDataset)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var5.getItemCount((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.general.SeriesChangeInfo var1 = null;
    org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)(short)(-1), var1);
    org.jfree.data.general.SeriesChangeInfo var3 = var2.getSummary();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
//     var0.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     var0.handleClick(10, 0, var7);
//     java.awt.geom.Rectangle2D var9 = var7.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var11 = var10.getRangeMinorGridlinePaint();
//     var10.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     var10.handleClick(10, 0, var17);
//     java.awt.geom.Rectangle2D var19 = var17.getDataArea();
//     boolean var20 = org.jfree.chart.util.ShapeUtilities.intersects(var9, var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var17
//     assertTrue("Contract failed: equals-hashcode on var7 and var17", var7.equals(var17) ? var7.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var7
//     assertTrue("Contract failed: equals-hashcode on var17 and var7", var17.equals(var7) ? var17.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var4.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var8 = var4.getOrientation();
    var3.add((org.jfree.chart.plot.XYPlot)var4);
    org.jfree.chart.axis.AxisSpace var10 = var3.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    var3.setRenderer(var11);
    org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var16 = var15.getRangeMinorGridlinePaint();
    var15.clearRangeMarkers(1);
    org.jfree.chart.ChartRenderingInfo var21 = null;
    org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
    var15.handleClick(10, 0, var22);
    java.awt.geom.Rectangle2D var24 = var22.getDataArea();
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var25.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var29 = var25.getOrientation();
    boolean var30 = var25.isDomainMinorGridlinesVisible();
    java.awt.geom.Point2D var31 = var25.getQuadrantOrigin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.zoomDomainAxes(2.0d, 1.0E-5d, var22, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var7 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var8 = var3.getColorComponents(var7);
    java.awt.color.ColorSpace var9 = var3.getColorSpace();
    java.awt.Color var13 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var17 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var18 = var13.getColorComponents(var17);
    java.awt.color.ColorSpace var19 = var13.getColorSpace();
    java.awt.Color var23 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var27 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var28 = var23.getColorComponents(var27);
    float[] var29 = var13.getRGBColorComponents(var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var30 = var3.getRGBComponents(var27);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
//     double var5 = var4.getMinX();
//     java.beans.PropertyChangeListener var6 = null;
//     var4.removePropertyChangeListener(var6);
//     org.jfree.data.xy.XYDataItem var8 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.add(var8, false);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     var0.setDepthFactor(Double.NaN);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var5 = var4.getRangeMinorGridlinePaint();
//     var4.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
//     var4.handleClick(10, 0, var11);
//     java.awt.geom.Rectangle2D var13 = var11.getDataArea();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var16 = var15.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var15);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var20 = var19.getAxisLineStroke();
//     boolean var21 = var19.isAutoRange();
//     org.jfree.data.Range var24 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var25 = var24.getLowerBound();
//     var19.setRangeWithMargins(var24, false, false);
//     float var29 = var19.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var30 = var17.getDataRange((org.jfree.chart.axis.ValueAxis)var19);
//     java.util.List var31 = var17.getSubplots();
//     org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var33 = var32.getRangeMinorGridlinePaint();
//     var32.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
//     var32.handleClick(10, 0, var39);
//     java.awt.geom.Rectangle2D var41 = var39.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var42 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var42.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var46 = var42.getOrientation();
//     boolean var47 = var42.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var48 = var42.getQuadrantOrigin();
//     org.jfree.chart.plot.XYPlot var49 = var17.findSubplot(var39, var48);
//     org.jfree.chart.plot.PlotState var50 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.CombinedDomainXYPlot var51 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var52 = var51.getRangeMinorGridlinePaint();
//     var51.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var57 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var58 = new org.jfree.chart.plot.PlotRenderingInfo(var57);
//     var51.handleClick(10, 0, var58);
//     java.awt.geom.Rectangle2D var60 = var58.getDataArea();
//     var0.draw(var3, var13, var48, var50, var58);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(byte)0);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.setBackgroundAlpha(1.0f);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomDomainAxes(1.0d, 0.0d, var7, var8);
//     org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var13 = var12.getRangeMinorGridlinePaint();
//     var12.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var18);
//     var12.handleClick(10, 0, var19);
//     java.awt.geom.Rectangle2D var21 = var19.getDataArea();
//     java.awt.geom.Rectangle2D var22 = var19.getDataArea();
//     java.awt.geom.Rectangle2D var23 = var19.getDataArea();
//     java.awt.Point var24 = var1.translateValueThetaRadiusToJava2D(4.0d, 4.0d, var23);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator((-398));
    org.jfree.chart.plot.XYPlot var3 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    double var7 = var2.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var2.setSeriesNegativeItemLabelPosition(1, var9);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var13 = var12.getAxisLineStroke();
    java.awt.Font var14 = var12.getLabelFont();
    var2.setBaseItemLabelFont(var14);
    java.awt.Paint var16 = var2.getBaseItemLabelPaint();
    double var17 = var2.getShadowXOffset();
    java.awt.Paint var21 = var2.getItemOutlinePaint(2147483647, 10, false);
    var2.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     java.lang.String var3 = var1.valueToString(0.0d);
//     int var4 = var1.getMinorTickCount();
//     java.lang.Comparable[] var5 = new java.lang.Comparable[] { var4};
//     java.lang.String[] var6 = org.jfree.data.time.SerialDate.getMonths();
//     double[] var7 = null;
//     double[][] var8 = new double[][] { var7};
//     org.jfree.data.category.CategoryDataset var9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var5, (java.lang.Comparable[])var6, var8);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var5.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var7 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
//     var8.setBackgroundAlpha(1.0f);
//     var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
//     java.awt.Paint var12 = var8.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     var8.handleClick((-398), 0, var15);
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     var5.addLegend(var17);
//     java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var23 = var22.brighter();
//     var17.setBackgroundPaint((java.awt.Paint)var22);
//     org.jfree.chart.util.RectangleAnchor var25 = var17.getLegendItemGraphicLocation();
//     org.jfree.chart.block.BlockContainer var26 = var17.getItemContainer();
//     org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var27.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var31 = var27.getOrientation();
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var27);
//     var32.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var34 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot();
//     var35.setBackgroundAlpha(1.0f);
//     var34.addChangeListener((org.jfree.data.general.DatasetChangeListener)var35);
//     java.awt.Paint var39 = var35.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     var35.handleClick((-398), 0, var42);
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
//     var32.addLegend(var44);
//     java.awt.Color var49 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var50 = var49.brighter();
//     var44.setBackgroundPaint((java.awt.Paint)var49);
//     org.jfree.chart.util.RectangleAnchor var52 = var44.getLegendItemGraphicLocation();
//     java.lang.String var53 = var52.toString();
//     var17.setLegendItemGraphicLocation(var52);
//     
//     // Checks the contract:  equals-hashcode on var0 and var27
//     assertTrue("Contract failed: equals-hashcode on var0 and var27", var0.equals(var27) ? var0.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var0
//     assertTrue("Contract failed: equals-hashcode on var27 and var0", var27.equals(var0) ? var27.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var32
//     assertTrue("Contract failed: equals-hashcode on var5 and var32", var5.equals(var32) ? var5.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var5
//     assertTrue("Contract failed: equals-hashcode on var32 and var5", var32.equals(var5) ? var32.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var35
//     assertTrue("Contract failed: equals-hashcode on var8 and var35", var8.equals(var35) ? var8.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var8
//     assertTrue("Contract failed: equals-hashcode on var35 and var8", var35.equals(var8) ? var35.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.configure();
    var0.configure();
    double var3 = var0.getCategoryMargin();
    double var4 = var0.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("AxisLabelEntity: label = null", "{0}: ({1}, {2})", var3);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var4 = var2.lookupSeriesPaint(10);
    java.awt.Stroke var6 = var2.lookupSeriesOutlineStroke(13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelGenerator((-398), var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.labels.PieSectionLabelGenerator var1 = var0.getLegendLabelGenerator();
    boolean var2 = var0.getSeparatorsVisible();
    var0.setStartAngle((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    double var7 = var2.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var8 = var2.getPositiveItemLabelPositionFallback();
    org.jfree.chart.plot.CategoryPlot var9 = var2.getPlot();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = null;
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
    var15.setBackgroundAlpha(1.0f);
    boolean var18 = var14.hasListener((java.util.EventListener)var15);
    java.awt.Shape var19 = var14.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var22 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var12, var19, "hi!", "hi!");
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var25 = var24.getAxisLineStroke();
    var24.resizeRange2(0.0d, 10.0d);
    org.jfree.chart.entity.AxisEntity var30 = new org.jfree.chart.entity.AxisEntity(var19, (org.jfree.chart.axis.Axis)var24, "hi!");
    var24.setAutoRangeIncludesZero(false);
    java.awt.geom.Rectangle2D var33 = null;
    var2.drawRangeGridline(var10, var11, (org.jfree.chart.axis.ValueAxis)var24, var33, 100.0d);
    java.awt.Paint var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setWallPaint(var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var2 = var1.getLinePaint();
    boolean var3 = var1.isShapeVisible();
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var8 = var6.lookupSeriesPaint(10);
    java.awt.Stroke var10 = var6.lookupSeriesOutlineStroke(13);
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var15 = var13.lookupSeriesPaint(10);
    java.awt.Stroke var17 = var13.lookupSeriesOutlineStroke(13);
    var6.setBaseStroke(var17);
    java.awt.Paint var20 = var6.getSeriesFillPaint(0);
    org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot();
    double var22 = var21.getMinimumArcAngleToDraw();
    java.awt.Color var26 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var27 = var26.brighter();
    var21.setBaseSectionOutlinePaint((java.awt.Paint)var27);
    var6.setBasePaint((java.awt.Paint)var27, false);
    var1.setLabelPaint((java.awt.Paint)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var4 = var2.lookupSeriesPaint(10);
    java.awt.Stroke var6 = var2.lookupSeriesOutlineStroke(13);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var11 = var9.lookupSeriesPaint(10);
    java.awt.Stroke var13 = var9.lookupSeriesOutlineStroke(13);
    var2.setBaseStroke(var13);
    var2.setBaseCreateEntities(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var4 = var3.getAutoPopulateSeriesFillPaint();
//     double var5 = var3.getLowerClip();
//     org.jfree.chart.ChartColor var9 = new org.jfree.chart.ChartColor(10, 100, 1);
//     var3.setBasePaint((java.awt.Paint)var9);
//     java.awt.Paint var12 = var3.getSeriesPaint(0);
//     var3.setDrawBarOutline(true);
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var18 = var17.getAxisLineStroke();
//     var17.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var22 = var17.getTickLabelFont();
//     var3.setSeriesItemLabelFont(2, var22);
//     org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var24.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var28 = var24.getOrientation();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     org.jfree.chart.axis.AxisSpace var30 = null;
//     var24.setFixedRangeAxisSpace(var30);
//     java.awt.Paint var32 = var24.getRangeMinorGridlinePaint();
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleAnchor.CENTER", var22, var32, 2.0f, var34);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     java.util.TimeZone var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     double var3 = var1.getDomainLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var5 = var1.getSeries(2147483647);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.block.BlockResult var0 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var1 = null;
    var0.setEntityCollection(var1);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     long var0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == (-2208960000000L));
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object[][] var1 = var0.getContents();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.getString("{0}: ({1}, {2})");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var2 = var1.getAxisLineStroke();
    var1.resizeRange2(0.0d, 10.0d);
    java.awt.Font var6 = var1.getTickLabelFont();
    var1.resizeRange2(1.0E-8d, 2.0d);
    var1.zoomRange(0.5d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var6 = var5.getAxisLineStroke();
    boolean var7 = var5.isAutoRange();
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    double var11 = var10.getLowerBound();
    var5.setRangeWithMargins(var10, false, false);
    float var15 = var5.getMinorTickMarkInsideLength();
    org.jfree.data.Range var16 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var5);
    var3.setDomainMinorGridlinesVisible(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var20 = var19.getRangeMinorGridlinePaint();
    boolean var21 = var19.isRangeMinorGridlinesVisible();
    boolean var22 = var19.isDomainGridlinesVisible();
    org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    org.jfree.chart.util.Layer var26 = null;
    boolean var27 = var19.removeDomainMarker((org.jfree.chart.plot.Marker)var25, var26);
    org.jfree.data.xy.DefaultXYDataset var28 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot();
    var29.setBackgroundAlpha(1.0f);
    var28.addChangeListener((org.jfree.data.general.DatasetChangeListener)var29);
    java.awt.Paint var33 = var29.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    var29.handleClick((-398), 0, var36);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
    org.jfree.chart.plot.PlotOrientation var39 = var29.getOrientation();
    java.lang.String var40 = var39.toString();
    var19.setOrientation(var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.add((org.jfree.chart.plot.XYPlot)var19, (-398));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "PlotOrientation.HORIZONTAL"+ "'", var40.equals("PlotOrientation.HORIZONTAL"));

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var3 = var2.getAutoPopulateSeriesFillPaint();
//     double var4 = var2.getLowerClip();
//     var2.setShadowYOffset(1.0E-5d);
//     java.lang.Boolean var8 = var2.getSeriesItemLabelsVisible(15);
//     org.jfree.chart.plot.DrawingSupplier var9 = var2.getDrawingSupplier();
//     double var10 = var2.getMinimumBarLength();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.text.TextBlock var14 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var15 = var14.getLineAlignment();
//     org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var18 = var17.clone();
//     var17.setDescription("");
//     boolean var21 = var14.equals((java.lang.Object)"");
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.util.Size2D var23 = var14.calculateDimensions(var22);
//     org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var26.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var30 = var26.getOrientation();
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var26);
//     var31.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var33 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot();
//     var34.setBackgroundAlpha(1.0f);
//     var33.addChangeListener((org.jfree.data.general.DatasetChangeListener)var34);
//     java.awt.Paint var38 = var34.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     var34.handleClick((-398), 0, var41);
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     var31.addLegend(var43);
//     java.awt.Color var48 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var49 = var48.brighter();
//     var43.setBackgroundPaint((java.awt.Paint)var48);
//     org.jfree.chart.util.RectangleAnchor var51 = var43.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var56 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var57 = var56.getLicenceName();
//     java.lang.String var58 = var56.getLicenceName();
//     boolean var59 = var51.equals((java.lang.Object)var58);
//     java.awt.geom.Rectangle2D var60 = org.jfree.chart.util.RectangleAnchor.createRectangle(var23, (-3.99999d), 5.0d, var51);
//     org.jfree.chart.LegendItem var63 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var64 = var63.getLinePaint();
//     org.jfree.data.xy.DefaultXYDataset var65 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var66 = new org.jfree.chart.plot.PolarPlot();
//     var66.setBackgroundAlpha(1.0f);
//     var65.addChangeListener((org.jfree.data.general.DatasetChangeListener)var66);
//     org.jfree.chart.axis.TickUnit var70 = var66.getAngleTickUnit();
//     org.jfree.chart.axis.NumberAxis3D var72 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var73 = var72.getAxisLineStroke();
//     var66.setRadiusGridlineStroke(var73);
//     var2.drawRangeLine(var11, var12, var13, var60, 0.0d, var64, var73);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var0.setFixedRangeAxisSpace(var6);
//     var0.setDomainCrosshairLockedOnData(true);
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var13 = var12.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var14 = var12.getTickLabelInsets();
//     double var16 = var14.trimHeight(1.0E-5d);
//     double var18 = var14.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var19 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var20 = var19.getLineAlignment();
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var23 = var22.clone();
//     var22.setDescription("");
//     boolean var26 = var19.equals((java.lang.Object)"");
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.util.Size2D var28 = var19.calculateDimensions(var27);
//     org.jfree.chart.plot.CombinedDomainXYPlot var31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var31.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var35 = var31.getOrientation();
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
//     var36.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var38 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot();
//     var39.setBackgroundAlpha(1.0f);
//     var38.addChangeListener((org.jfree.data.general.DatasetChangeListener)var39);
//     java.awt.Paint var43 = var39.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     var39.handleClick((-398), 0, var46);
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     var36.addLegend(var48);
//     java.awt.Color var53 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var54 = var53.brighter();
//     var48.setBackgroundPaint((java.awt.Paint)var53);
//     org.jfree.chart.util.RectangleAnchor var56 = var48.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var61 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var62 = var61.getLicenceName();
//     java.lang.String var63 = var61.getLicenceName();
//     boolean var64 = var56.equals((java.lang.Object)var63);
//     java.awt.geom.Rectangle2D var65 = org.jfree.chart.util.RectangleAnchor.createRectangle(var28, (-3.99999d), 5.0d, var56);
//     var14.trim(var65);
//     org.jfree.chart.RenderingSource var67 = null;
//     var0.select(0.0d, 2.0d, var65, var67);
//     
//     // Checks the contract:  equals-hashcode on var0 and var31
//     assertTrue("Contract failed: equals-hashcode on var0 and var31", var0.equals(var31) ? var0.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var0
//     assertTrue("Contract failed: equals-hashcode on var31 and var0", var31.equals(var0) ? var31.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var0.setFixedRangeAxisSpace(var6);
//     java.awt.Paint var8 = var0.getRangeMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var12 = var11.getOutlineStroke();
//     java.awt.Stroke var13 = var11.getOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.plot.IntervalMarker var18 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Paint var19 = var18.getLabelPaint();
//     org.jfree.chart.event.MarkerChangeEvent var20 = null;
//     var18.notifyListeners(var20);
//     org.jfree.chart.util.Layer var22 = null;
//     boolean var23 = var0.removeRangeMarker((-457), (org.jfree.chart.plot.Marker)var18, var22);
//     
//     // Checks the contract:  equals-hashcode on var11 and var18
//     assertTrue("Contract failed: equals-hashcode on var11 and var18", var11.equals(var18) ? var11.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var11
//     assertTrue("Contract failed: equals-hashcode on var18 and var11", var18.equals(var11) ? var18.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(2147483647, var1);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    java.util.TimeZone var0 = null;
    java.util.Locale var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("AxisLabelEntity: label = null");
    java.awt.Color var5 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var9 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var10 = var5.getColorComponents(var9);
    var1.setLinePaint((java.awt.Paint)var5);
    java.lang.String var12 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AxisLabelEntity: label = null"+ "'", var12.equals("AxisLabelEntity: label = null"));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var3 = var2.getTickLabelFont();
    boolean var4 = var1.equals((java.lang.Object)var2);
    org.jfree.data.xy.DefaultXYDataset var5 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var5, true);
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
    var8.setBackgroundAlpha(1.0f);
    java.awt.Paint var11 = var8.getBackgroundPaint();
    org.jfree.chart.axis.TickUnit var12 = var8.getAngleTickUnit();
    int var13 = var5.indexOf((java.lang.Comparable)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var15 = var1.generateLabel((org.jfree.data.xy.XYDataset)var5, (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    boolean var7 = var4.equals((java.lang.Object)"");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var4.getY(2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     org.jfree.chart.axis.SegmentedTimeline var2 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var4 = var3.getMaximumDate();
//     long var5 = var2.toTimelineValue(var4);
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var8 = var7.getAxisLineStroke();
//     java.awt.Font var9 = var7.getLabelFont();
//     org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange();
//     var7.setRangeWithMargins((org.jfree.data.Range)var10, false, true);
//     java.util.Date var14 = var10.getLowerDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setRange(var4, var14);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1577894400001L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.ColumnArrangement var1 = new org.jfree.chart.block.ColumnArrangement();
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
//     org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var3.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var7 = var3.getOrientation();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
//     var8.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var10 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
//     var11.setBackgroundAlpha(1.0f);
//     var10.addChangeListener((org.jfree.data.general.DatasetChangeListener)var11);
//     java.awt.Paint var15 = var11.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var11.handleClick((-398), 0, var18);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
//     var8.addLegend(var20);
//     var0.add((org.jfree.chart.block.Block)var20);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot();
//     var27.setBackgroundAlpha(1.0f);
//     boolean var30 = var26.hasListener((java.util.EventListener)var27);
//     java.awt.Shape var31 = var26.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var24, var31, "hi!", "hi!");
//     double var35 = var24.getUpperMargin();
//     double var36 = var24.getAutoRangeMinimumSize();
//     org.jfree.chart.plot.CombinedDomainXYPlot var38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var39 = var38.getRangeMinorGridlinePaint();
//     var38.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var44 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = new org.jfree.chart.plot.PlotRenderingInfo(var44);
//     var38.handleClick(10, 0, var45);
//     java.awt.geom.Rectangle2D var47 = var45.getDataArea();
//     java.awt.geom.Rectangle2D var48 = var45.getDataArea();
//     java.awt.geom.Rectangle2D var49 = var45.getDataArea();
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var24.valueToJava2D(0.05d, var49, var50);
//     org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
//     var52.configure();
//     var52.removeCategoryLabelToolTip((java.lang.Comparable)'#');
//     java.lang.Object var56 = var0.draw(var23, var49, (java.lang.Object)var52);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"4", "Combined_Domain_XYPlot", "PlotOrientation.HORIZONTAL");
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var6 = var3.getDataItem(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     java.awt.geom.Rectangle2D var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var4 = var2.getTickLabelInsets();
//     double var6 = var4.trimHeight(1.0E-5d);
//     double var8 = var4.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var9 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var10 = var9.getLineAlignment();
//     org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var13 = var12.clone();
//     var12.setDescription("");
//     boolean var16 = var9.equals((java.lang.Object)"");
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.util.Size2D var18 = var9.calculateDimensions(var17);
//     org.jfree.chart.plot.CombinedDomainXYPlot var21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var21.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var25 = var21.getOrientation();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var21);
//     var26.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var28 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot();
//     var29.setBackgroundAlpha(1.0f);
//     var28.addChangeListener((org.jfree.data.general.DatasetChangeListener)var29);
//     java.awt.Paint var33 = var29.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     var29.handleClick((-398), 0, var36);
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
//     var26.addLegend(var38);
//     java.awt.Color var43 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var44 = var43.brighter();
//     var38.setBackgroundPaint((java.awt.Paint)var43);
//     org.jfree.chart.util.RectangleAnchor var46 = var38.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var51 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var52 = var51.getLicenceName();
//     java.lang.String var53 = var51.getLicenceName();
//     boolean var54 = var46.equals((java.lang.Object)var53);
//     java.awt.geom.Rectangle2D var55 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, (-3.99999d), 5.0d, var46);
//     var4.trim(var55);
//     java.awt.geom.Rectangle2D var57 = var0.expand(var1, var55);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"hi!", 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.util.RectangleEdge var3 = null;
//     double var4 = var0.exponentLengthToJava2D(0.0d, var2, var3);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var7 = var6.getRangeMinorGridlinePaint();
//     var6.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     var6.handleClick(10, 0, var13);
//     java.awt.geom.Rectangle2D var15 = var13.getDataArea();
//     java.awt.geom.Rectangle2D var16 = var13.getDataArea();
//     java.awt.geom.Rectangle2D var17 = var13.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var18.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var22 = var18.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var26 = var25.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot();
//     var27.setBackgroundAlpha(1.0f);
//     java.awt.Paint var30 = var27.getBackgroundPaint();
//     var25.setPaint(var30);
//     var18.setRangeMinorGridlinePaint(var30);
//     int var33 = var18.getWeight();
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var36 = var35.getAxisLineStroke();
//     boolean var37 = var35.isAutoRange();
//     java.awt.Shape var38 = var35.getLeftArrow();
//     int var39 = var18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.chart.util.RectangleEdge var40 = var18.getRangeAxisEdge();
//     double var41 = var0.exponentLengthToJava2D(9.0d, var17, var40);
//     org.jfree.chart.axis.NumberTickUnit var42 = var0.getTickUnit();
//     var0.setSmallestValue(0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var6 = var5.getAxisLineStroke();
//     boolean var7 = var5.isAutoRange();
//     org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var11 = var10.getLowerBound();
//     var5.setRangeWithMargins(var10, false, false);
//     float var15 = var5.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var16 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var5);
//     java.util.List var17 = var3.getSubplots();
//     org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var19 = var18.getRangeMinorGridlinePaint();
//     var18.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     var18.handleClick(10, 0, var25);
//     java.awt.geom.Rectangle2D var27 = var25.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var28.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var32 = var28.getOrientation();
//     boolean var33 = var28.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var34 = var28.getQuadrantOrigin();
//     org.jfree.chart.plot.XYPlot var35 = var3.findSubplot(var25, var34);
//     org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     java.awt.Paint var40 = var38.lookupSeriesPaint(10);
//     java.awt.Stroke var42 = var38.lookupSeriesOutlineStroke(13);
//     var3.setDomainGridlineStroke(var42);
//     java.awt.Stroke var44 = var3.getRangeGridlineStroke();
//     org.jfree.chart.plot.CombinedDomainXYPlot var45 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var46 = var45.getRangeMinorGridlinePaint();
//     boolean var47 = var45.isRangeMinorGridlinesVisible();
//     var45.setDomainCrosshairVisible(false);
//     org.jfree.chart.LegendItemCollection var50 = var45.getLegendItems();
//     org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var53 = var52.clone();
//     org.jfree.data.xy.DefaultXYDataset var54 = new org.jfree.data.xy.DefaultXYDataset();
//     var52.setDataset((org.jfree.data.general.Dataset)var54);
//     var50.add(var52);
//     org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var60 = var59.getAutoPopulateSeriesFillPaint();
//     java.awt.Paint var64 = var59.getItemPaint(255, (-398), true);
//     var52.setOutlinePaint(var64);
//     var3.setDomainMinorGridlinePaint(var64);
//     
//     // Checks the contract:  equals-hashcode on var18 and var45
//     assertTrue("Contract failed: equals-hashcode on var18 and var45", var18.equals(var45) ? var18.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var18
//     assertTrue("Contract failed: equals-hashcode on var45 and var18", var45.equals(var18) ? var45.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var5 = var4.getRangeMinorGridlinePaint();
    boolean var6 = var4.isRangeMinorGridlinesVisible();
    var4.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.PlotOrientation var9 = var4.getOrientation();
    var3.setOrientation(var9);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.util.RectangleEdge var15 = null;
    double var16 = var12.valueToJava2D(1.0d, var14, var15);
    double var17 = var12.getAutoRangeMinimumSize();
    boolean var18 = var12.isNegativeArrowVisible();
    var3.setRangeAxis(13, (org.jfree.chart.axis.ValueAxis)var12, true);
    java.lang.String var21 = var3.getPlotType();
    java.awt.Paint var22 = var3.getNoDataMessagePaint();
    org.jfree.chart.plot.DatasetRenderingOrder var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setDatasetRenderingOrder(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Combined Range XYPlot"+ "'", var21.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var0.getCategorySeriesMiddle(0, 0, (-398), 1, 0.05d, var6, var7);
//     var0.setCategoryMargin(1.0E-100d);
//     org.jfree.chart.axis.CategoryAnchor var11 = null;
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot();
//     var17.setBackgroundAlpha(1.0f);
//     boolean var20 = var16.hasListener((java.util.EventListener)var17);
//     java.awt.Shape var21 = var16.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var24 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var14, var21, "hi!", "hi!");
//     double var25 = var14.getUpperMargin();
//     double var26 = var14.getAutoRangeMinimumSize();
//     org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var29 = var28.getRangeMinorGridlinePaint();
//     var28.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
//     var28.handleClick(10, 0, var35);
//     java.awt.geom.Rectangle2D var37 = var35.getDataArea();
//     java.awt.geom.Rectangle2D var38 = var35.getDataArea();
//     java.awt.geom.Rectangle2D var39 = var35.getDataArea();
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var14.valueToJava2D(0.05d, var39, var40);
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     double var43 = var0.getCategoryJava2DCoordinate(var11, 1, (-398), var39, var42);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var2 = var1.getAxisLineStroke();
    var1.resizeRange2(0.0d, 10.0d);
    java.awt.Font var6 = var1.getTickLabelFont();
    org.jfree.data.Range var7 = var1.getDefaultAutoRange();
    boolean var8 = var1.isAutoTickUnitSelection();
    java.awt.Stroke var9 = var1.getTickMarkStroke();
    var1.setAutoRangeMinimumSize(1.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var3 = var2.getRangeMinorGridlinePaint();
    var2.clearRangeMarkers(1);
    org.jfree.chart.ChartRenderingInfo var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
    var2.handleClick(10, 0, var9);
    java.awt.geom.Rectangle2D var11 = var9.getDataArea();
    java.awt.geom.Rectangle2D var12 = var9.getDataArea();
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var13.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var17 = var13.getOrientation();
    boolean var18 = var13.isDomainMinorGridlinesVisible();
    java.awt.geom.Point2D var19 = var13.getQuadrantOrigin();
    var0.zoomDomainAxes(0.2d, var9, var19, true);
    java.io.ObjectOutputStream var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var19, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
//     var4.setBackgroundAlpha(1.0f);
//     boolean var7 = var3.hasListener((java.util.EventListener)var4);
//     java.awt.Shape var8 = var3.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var8, "hi!", "hi!");
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var14 = var13.getAxisLineStroke();
//     var13.resizeRange2(0.0d, 10.0d);
//     org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var13, "hi!");
//     var13.setAutoRangeIncludesZero(false);
//     java.lang.Object var22 = var13.clone();
//     boolean var23 = var13.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot();
//     var26.setBackgroundAlpha(1.0f);
//     boolean var29 = var25.hasListener((java.util.EventListener)var26);
//     java.awt.Shape var30 = var25.getLeftArrow();
//     double var31 = var25.getLowerBound();
//     java.awt.Paint var32 = var25.getTickLabelPaint();
//     boolean var33 = var25.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//     org.jfree.chart.plot.XYPlot var35 = var34.getPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.lang.String var37 = var36.getPlotType();
//     var34.setPlot((org.jfree.chart.plot.XYPlot)var36);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var39 = null;
//     var34.setLegendItemURLGenerator(var39);
//     var34.removeAnnotations();
//     org.jfree.chart.LegendItemCollection var42 = var34.getLegendItems();
//     org.jfree.chart.labels.ItemLabelPosition var44 = var34.getSeriesPositiveItemLabelPosition(1);
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.renderer.xy.XYItemRenderer)var34);
//     
//     // Checks the contract:  equals-hashcode on var4 and var26
//     assertTrue("Contract failed: equals-hashcode on var4 and var26", var4.equals(var26) ? var4.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var4
//     assertTrue("Contract failed: equals-hashcode on var26 and var4", var26.equals(var4) ? var26.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.configure();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var9 = var8.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var10 = var8.getTickLabelInsets();
//     double var12 = var10.trimHeight(1.0E-5d);
//     double var14 = var10.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var15 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var16 = var15.getLineAlignment();
//     org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var19 = var18.clone();
//     var18.setDescription("");
//     boolean var22 = var15.equals((java.lang.Object)"");
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.util.Size2D var24 = var15.calculateDimensions(var23);
//     org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var27.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var31 = var27.getOrientation();
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var27);
//     var32.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var34 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot();
//     var35.setBackgroundAlpha(1.0f);
//     var34.addChangeListener((org.jfree.data.general.DatasetChangeListener)var35);
//     java.awt.Paint var39 = var35.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     var35.handleClick((-398), 0, var42);
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
//     var32.addLegend(var44);
//     java.awt.Color var49 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var50 = var49.brighter();
//     var44.setBackgroundPaint((java.awt.Paint)var49);
//     org.jfree.chart.util.RectangleAnchor var52 = var44.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var57 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var58 = var57.getLicenceName();
//     java.lang.String var59 = var57.getLicenceName();
//     boolean var60 = var52.equals((java.lang.Object)var59);
//     java.awt.geom.Rectangle2D var61 = org.jfree.chart.util.RectangleAnchor.createRectangle(var24, (-3.99999d), 5.0d, var52);
//     var10.trim(var61);
//     org.jfree.chart.util.RectangleEdge var63 = null;
//     double var64 = var0.getCategorySeriesMiddle(100, (-1), 13, 1, 100.0d, var61, var63);
//     org.jfree.chart.plot.CombinedDomainXYPlot var65 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var65.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var69 = var65.getOrientation();
//     org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var65);
//     org.jfree.chart.axis.AxisSpace var71 = null;
//     var65.setFixedRangeAxisSpace(var71);
//     var65.setDomainCrosshairLockedOnData(true);
//     org.jfree.chart.entity.PlotEntity var77 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape)var61, (org.jfree.chart.plot.Plot)var65, "org.jfree.chart.ChartColor[r=10,g=100,b=1]", "VerticalAlignment.CENTER");
//     
//     // Checks the contract:  equals-hashcode on var27 and var65
//     assertTrue("Contract failed: equals-hashcode on var27 and var65", var27.equals(var65) ? var27.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var27
//     assertTrue("Contract failed: equals-hashcode on var65 and var27", var65.equals(var27) ? var65.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.setBackgroundAlpha(1.0f);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
//     org.jfree.chart.axis.TickUnit var5 = var1.getAngleTickUnit();
//     float var6 = var1.getForegroundAlpha();
//     var1.setAngleLabelsVisible(false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
//     var10.configure();
//     java.lang.Object var12 = var10.clone();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var19 = var18.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var20 = var18.getTickLabelInsets();
//     double var22 = var20.trimHeight(1.0E-5d);
//     double var24 = var20.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var25 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var26 = var25.getLineAlignment();
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var29 = var28.clone();
//     var28.setDescription("");
//     boolean var32 = var25.equals((java.lang.Object)"");
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.util.Size2D var34 = var25.calculateDimensions(var33);
//     org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var37.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var41 = var37.getOrientation();
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var37);
//     var42.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var44 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot();
//     var45.setBackgroundAlpha(1.0f);
//     var44.addChangeListener((org.jfree.data.general.DatasetChangeListener)var45);
//     java.awt.Paint var49 = var45.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     var45.handleClick((-398), 0, var52);
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
//     var42.addLegend(var54);
//     java.awt.Color var59 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var60 = var59.brighter();
//     var54.setBackgroundPaint((java.awt.Paint)var59);
//     org.jfree.chart.util.RectangleAnchor var62 = var54.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var67 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var68 = var67.getLicenceName();
//     java.lang.String var69 = var67.getLicenceName();
//     boolean var70 = var62.equals((java.lang.Object)var69);
//     java.awt.geom.Rectangle2D var71 = org.jfree.chart.util.RectangleAnchor.createRectangle(var34, (-3.99999d), 5.0d, var62);
//     var20.trim(var71);
//     org.jfree.chart.util.RectangleEdge var73 = null;
//     double var74 = var10.getCategorySeriesMiddle(100, (-1), 13, 1, 100.0d, var71, var73);
//     var1.drawOutline(var9, var71);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     boolean var1 = var0.isVerticalTickLabels();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.data.xy.DefaultXYDataset var3 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
//     var4.setBackgroundAlpha(1.0f);
//     var3.addChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
//     org.jfree.chart.axis.TickUnit var8 = var4.getAngleTickUnit();
//     float var9 = var4.getForegroundAlpha();
//     var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
//     org.jfree.chart.axis.SegmentedTimeline var11 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var13 = var12.getMaximumDate();
//     long var14 = var11.toTimelineValue(var13);
//     org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
//     java.util.Date var16 = var15.getUpperDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setRange(var13, var16);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1577894400001L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var5 = var4.getRangeMinorGridlinePaint();
//     boolean var6 = var4.isRangeMinorGridlinesVisible();
//     var4.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.PlotOrientation var9 = var4.getOrientation();
//     var3.setOrientation(var9);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var12.valueToJava2D(1.0d, var14, var15);
//     double var17 = var12.getAutoRangeMinimumSize();
//     boolean var18 = var12.isNegativeArrowVisible();
//     var3.setRangeAxis(13, (org.jfree.chart.axis.ValueAxis)var12, true);
//     java.lang.String var21 = var3.getPlotType();
//     org.jfree.chart.axis.ValueAxis[] var22 = null;
//     var3.setDomainAxes(var22);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    double var7 = var2.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var2.setSeriesNegativeItemLabelPosition(1, var9);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var13 = var12.getAxisLineStroke();
    java.awt.Font var14 = var12.getLabelFont();
    var2.setBaseItemLabelFont(var14);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var16 = var2.getLegendItemToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    var0.clearRangeMarkers(1);
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    var0.handleClick(10, 0, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var10 = var7.getSubplotInfo((-398));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Combined_Domain_XYPlot", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var4 = var2.lookupSeriesPaint(10);
    java.awt.Stroke var6 = var2.lookupSeriesOutlineStroke(13);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var11 = var9.lookupSeriesPaint(10);
    java.awt.Stroke var13 = var9.lookupSeriesOutlineStroke(13);
    var2.setBaseStroke(var13);
    java.awt.Paint var16 = var2.getSeriesFillPaint(0);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    boolean var2 = var0.containsKey("{0}: ({1}, {2})");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject("TitleEntity: tooltip = AxisLabelEntity: label = null");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-398));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var4 = var3.getRangeMinorGridlinePaint();
//     var3.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     var3.handleClick(10, 0, var10);
//     java.awt.geom.Rectangle2D var12 = var10.getDataArea();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var16 = var15.getRangeMinorGridlinePaint();
//     var15.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     var15.handleClick(10, 0, var22);
//     java.awt.geom.Rectangle2D var24 = var22.getDataArea();
//     java.awt.geom.Rectangle2D var25 = var22.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var26.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var30 = var26.getOrientation();
//     boolean var31 = var26.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var32 = var26.getQuadrantOrigin();
//     var13.zoomDomainAxes(0.2d, var22, var32, true);
//     var0.zoomDomainAxes(4.0d, var10, var32, false);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var22
//     assertTrue("Contract failed: equals-hashcode on var10 and var22", var10.equals(var22) ? var10.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var10
//     assertTrue("Contract failed: equals-hashcode on var22 and var10", var22.equals(var10) ? var22.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getLowerBound();
    java.lang.Object var2 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.setBackgroundAlpha(1.0f);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
//     java.awt.Paint var5 = var1.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var1.handleClick((-398), 0, var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets(1.0E-5d, 0.0d, 1.0d, Double.NaN);
//     org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var17 = var16.getRangeMinorGridlinePaint();
//     org.jfree.chart.LegendItemCollection var18 = var16.getFixedLegendItems();
//     org.jfree.chart.axis.AxisLocation var20 = var16.getDomainAxisLocation(255);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var23 = var22.getTickLabelFont();
//     org.jfree.chart.util.RectangleInsets var24 = var22.getTickLabelInsets();
//     double var26 = var24.trimHeight(1.0E-5d);
//     double var28 = var24.calculateBottomInset(1.0E-8d);
//     org.jfree.chart.text.TextBlock var29 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var30 = var29.getLineAlignment();
//     org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var33 = var32.clone();
//     var32.setDescription("");
//     boolean var36 = var29.equals((java.lang.Object)"");
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.util.Size2D var38 = var29.calculateDimensions(var37);
//     org.jfree.chart.plot.CombinedDomainXYPlot var41 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var41.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var45 = var41.getOrientation();
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var41);
//     var46.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var48 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot();
//     var49.setBackgroundAlpha(1.0f);
//     var48.addChangeListener((org.jfree.data.general.DatasetChangeListener)var49);
//     java.awt.Paint var53 = var49.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     var49.handleClick((-398), 0, var56);
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
//     var46.addLegend(var58);
//     java.awt.Color var63 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var64 = var63.brighter();
//     var58.setBackgroundPaint((java.awt.Paint)var63);
//     org.jfree.chart.util.RectangleAnchor var66 = var58.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var71 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var72 = var71.getLicenceName();
//     java.lang.String var73 = var71.getLicenceName();
//     boolean var74 = var66.equals((java.lang.Object)var73);
//     java.awt.geom.Rectangle2D var75 = org.jfree.chart.util.RectangleAnchor.createRectangle(var38, (-3.99999d), 5.0d, var66);
//     var24.trim(var75);
//     org.jfree.chart.axis.NumberAxis3D var78 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var79 = var78.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var80 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var78);
//     org.jfree.chart.axis.NumberAxis3D var82 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var83 = var82.getAxisLineStroke();
//     boolean var84 = var82.isAutoRange();
//     org.jfree.data.Range var87 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var88 = var87.getLowerBound();
//     var82.setRangeWithMargins(var87, false, false);
//     float var92 = var82.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var93 = var80.getDataRange((org.jfree.chart.axis.ValueAxis)var82);
//     java.util.List var94 = var80.getSubplots();
//     var16.drawDomainTickBands(var21, var75, var94);
//     java.awt.geom.Rectangle2D var98 = var15.createInsetRectangle(var75, false, false);
//     var1.drawOutline(var10, var75);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(0.0d, "", "", false);
    java.lang.StringBuffer var6 = null;
    java.text.FieldPosition var7 = null;
    java.lang.StringBuffer var8 = var4.format((-1.0d), var6, var7);
    java.text.NumberFormat var9 = var4.getExponentFormat();
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var10.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var14 = var10.getOrientation();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var15.setNotify(false);
    var15.setNotify(false);
    java.lang.Object var20 = var15.getTextAntiAlias();
    var15.setTextAntiAlias(true);
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var24 = var23.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var25 = var23.getTickLabelInsets();
    double var26 = var25.getLeft();
    var15.setPadding(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedCharacterIterator var28 = var4.formatToCharacterIterator((java.lang.Object)var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 4.0d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    double var7 = var2.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var2.setSeriesNegativeItemLabelPosition(1, var9);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var13 = var12.getAxisLineStroke();
    java.awt.Font var14 = var12.getLabelFont();
    var2.setBaseItemLabelFont(var14);
    java.awt.Paint var16 = var2.getBaseItemLabelPaint();
    double var17 = var2.getShadowXOffset();
    java.awt.Paint var21 = var2.getItemOutlinePaint(2147483647, 10, false);
    int var22 = var2.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    org.jfree.data.xy.IntervalXYDelegate var3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    java.lang.Object var4 = var0.clone();
    double[] var6 = null;
    double[][] var7 = new double[][] { var6};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addSeries((java.lang.Comparable)9.0d, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     java.util.TimeZone var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     double var3 = var1.getDomainLowerBound(false);
//     var1.removeAllSeries();
//     org.jfree.data.time.TimeSeries var5 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.removeSeries(var5);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    var0.setShapesVisible(true);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//     org.jfree.chart.plot.XYPlot var1 = var0.getPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.lang.String var3 = var2.getPlotType();
//     var0.setPlot((org.jfree.chart.plot.XYPlot)var2);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var5 = null;
//     var0.setLegendItemURLGenerator(var5);
//     var0.removeAnnotations();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var11 = var10.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var10);
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var15 = var14.getAxisLineStroke();
//     boolean var16 = var14.isAutoRange();
//     org.jfree.data.Range var19 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var20 = var19.getLowerBound();
//     var14.setRangeWithMargins(var19, false, false);
//     float var24 = var14.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var25 = var12.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot();
//     var29.setBackgroundAlpha(1.0f);
//     boolean var32 = var28.hasListener((java.util.EventListener)var29);
//     java.awt.Shape var33 = var28.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var36 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var26, var33, "hi!", "hi!");
//     double var37 = var26.getUpperMargin();
//     org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets(1.0E-5d, 0.0d, 1.0d, Double.NaN);
//     var26.setTickLabelInsets(var42);
//     var26.setMinorTickMarkOutsideLength(0.0f);
//     org.jfree.chart.text.TextBlock var46 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var47 = var46.getLineAlignment();
//     org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var50 = var49.clone();
//     var49.setDescription("");
//     boolean var53 = var46.equals((java.lang.Object)"");
//     java.awt.Graphics2D var54 = null;
//     org.jfree.chart.util.Size2D var55 = var46.calculateDimensions(var54);
//     org.jfree.chart.plot.CombinedDomainXYPlot var58 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var58.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var62 = var58.getOrientation();
//     org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var58);
//     var63.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var65 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var66 = new org.jfree.chart.plot.PolarPlot();
//     var66.setBackgroundAlpha(1.0f);
//     var65.addChangeListener((org.jfree.data.general.DatasetChangeListener)var66);
//     java.awt.Paint var70 = var66.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     var66.handleClick((-398), 0, var73);
//     org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66);
//     var63.addLegend(var75);
//     java.awt.Color var80 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var81 = var80.brighter();
//     var75.setBackgroundPaint((java.awt.Paint)var80);
//     org.jfree.chart.util.RectangleAnchor var83 = var75.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var88 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var89 = var88.getLicenceName();
//     java.lang.String var90 = var88.getLicenceName();
//     boolean var91 = var83.equals((java.lang.Object)var90);
//     java.awt.geom.Rectangle2D var92 = org.jfree.chart.util.RectangleAnchor.createRectangle(var55, (-3.99999d), 5.0d, var83);
//     var0.fillRangeGridBand(var8, (org.jfree.chart.plot.XYPlot)var12, (org.jfree.chart.axis.ValueAxis)var26, var92, 1.0E-5d, 5.0d);
//     
//     // Checks the contract:  equals-hashcode on var29 and var66
//     assertTrue("Contract failed: equals-hashcode on var29 and var66", var29.equals(var66) ? var29.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var29
//     assertTrue("Contract failed: equals-hashcode on var66 and var29", var66.equals(var29) ? var66.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    boolean var2 = var0.isRangeMinorGridlinesVisible();
    var0.setBackgroundImageAlignment(2147483647);
    org.jfree.data.xy.DefaultXYDataset var5 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
    var6.setBackgroundAlpha(1.0f);
    var5.addChangeListener((org.jfree.data.general.DatasetChangeListener)var6);
    int var11 = var5.indexOf((java.lang.Comparable)'a');
    org.jfree.data.xy.IntervalXYDelegate var12 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var5);
    int var13 = var0.indexOf((org.jfree.data.xy.XYDataset)var5);
    java.awt.Stroke var14 = var0.getDomainGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    org.jfree.chart.plot.CrosshairState var5 = null;
    boolean var6 = var0.render(var1, var2, 0, var4, var5);
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var10 = var9.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var9);
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var14 = var13.getAxisLineStroke();
    boolean var15 = var13.isAutoRange();
    org.jfree.data.Range var18 = new org.jfree.data.Range(0.0d, 0.0d);
    double var19 = var18.getLowerBound();
    var13.setRangeWithMargins(var18, false, false);
    float var23 = var13.getMinorTickMarkInsideLength();
    org.jfree.data.Range var24 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var13);
    java.awt.Paint var25 = var11.getRangeCrosshairPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint((-398), var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.BlockContainer var1 = null;
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var5 = var4.getAxisLineStroke();
//     boolean var6 = var4.isAutoRange();
//     org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var10 = var9.getLowerBound();
//     var4.setRangeWithMargins(var9, false, false);
//     org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var9, 4.0d);
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(var15, 100.0d);
//     org.jfree.chart.util.Size2D var18 = var0.arrange(var1, var2, var17);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getLineAlignment();
    org.jfree.chart.LegendItem var3 = new org.jfree.chart.LegendItem("");
    java.lang.Object var4 = var3.clone();
    var3.setDescription("");
    boolean var7 = var0.equals((java.lang.Object)"");
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.util.Size2D var9 = var0.calculateDimensions(var8);
    org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var12.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var16 = var12.getOrientation();
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
    var17.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var19 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot();
    var20.setBackgroundAlpha(1.0f);
    var19.addChangeListener((org.jfree.data.general.DatasetChangeListener)var20);
    java.awt.Paint var24 = var20.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    var20.handleClick((-398), 0, var27);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
    var17.addLegend(var29);
    java.awt.Color var34 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var35 = var34.brighter();
    var29.setBackgroundPaint((java.awt.Paint)var34);
    org.jfree.chart.util.RectangleAnchor var37 = var29.getLegendItemGraphicLocation();
    org.jfree.chart.ui.Library var42 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var43 = var42.getLicenceName();
    java.lang.String var44 = var42.getLicenceName();
    boolean var45 = var37.equals((java.lang.Object)var44);
    java.awt.geom.Rectangle2D var46 = org.jfree.chart.util.RectangleAnchor.createRectangle(var9, (-3.99999d), 5.0d, var37);
    java.lang.String var47 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "hi!"+ "'", var43.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "hi!"+ "'", var44.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var47.equals("Size2D[width=0.0, height=0.0]"));

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays((-398), var1);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.fireChartChanged();
    var5.removeLegend();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var9 = var5.getSubtitle(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var2 = var1.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var5 = var4.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var8 = var7.getAxisLineStroke();
    var7.resizeRange2(0.0d, 10.0d);
    java.awt.Font var12 = var7.getTickLabelFont();
    org.jfree.data.Range var13 = var7.getDefaultAutoRange();
    boolean var14 = var7.isAutoTickUnitSelection();
    java.awt.Paint var15 = var7.getTickLabelPaint();
    var4.setBackgroundPaint(var15);
    boolean var17 = var1.equals((java.lang.Object)var15);
    boolean var18 = var1.getExpandToFitSpace();
    java.lang.Object var19 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
//     org.jfree.chart.plot.PieLabelLinkStyle var5 = var2.getLabelLinkStyle();
//     java.lang.String var6 = var5.toString();
//     var1.setLabelLinkStyle(var5);
//     org.jfree.chart.StandardChartTheme var9 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var10.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var11);
//     org.jfree.chart.plot.PieLabelLinkStyle var13 = var10.getLabelLinkStyle();
//     java.lang.String var14 = var13.toString();
//     var9.setLabelLinkStyle(var13);
//     var1.setLabelLinkStyle(var13);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var2 = var1.getMaximumDate();
//     long var3 = var0.toTimelineValue(var2);
//     var0.addBaseTimelineException(1404331199999L);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var5 = var4.getRangeMinorGridlinePaint();
    boolean var6 = var4.isRangeMinorGridlinesVisible();
    var4.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.PlotOrientation var9 = var4.getOrientation();
    var3.setOrientation(var9);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var13 = var12.getAxisLineStroke();
    var12.resizeRange2(0.0d, 10.0d);
    java.awt.Font var17 = var12.getTickLabelFont();
    org.jfree.data.Range var18 = var12.getDefaultAutoRange();
    boolean var19 = var12.isAutoTickUnitSelection();
    java.awt.Stroke var20 = var12.getTickMarkStroke();
    var3.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.axis.AxisSpace var22 = var3.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var1 = var0.getTickLabelFont();
    boolean var2 = var0.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var0.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var5.fireChartChanged();
//     var5.removeLegend();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var10 = var9.getRangeMinorGridlinePaint();
//     var9.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     var9.handleClick(10, 0, var16);
//     java.awt.geom.Rectangle2D var18 = var16.getDataArea();
//     org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo();
//     var5.draw(var8, var18, var19);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("ThreadContext");
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot();
    var10.setBackgroundAlpha(1.0f);
    boolean var13 = var9.hasListener((java.util.EventListener)var10);
    java.awt.Paint var14 = var10.getAngleLabelPaint();
    var7.setLabelPaint(var14);
    java.lang.String var16 = var7.getLabelURL();
    java.awt.Shape var17 = var7.getDownArrow();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    java.awt.Paint var20 = var18.lookupSeriesFillPaint(100);
    org.jfree.chart.plot.IntervalMarker var23 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Paint var24 = var23.getLabelPaint();
    org.jfree.chart.event.MarkerChangeEvent var25 = null;
    var23.notifyListeners(var25);
    java.awt.Stroke var27 = var23.getStroke();
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var30 = var29.getLinePaint();
    boolean var31 = var29.isShapeOutlineVisible();
    java.awt.Color var35 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.image.ColorModel var36 = null;
    java.awt.Rectangle var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    java.awt.geom.AffineTransform var39 = null;
    java.awt.RenderingHints var40 = null;
    java.awt.PaintContext var41 = var35.createContext(var36, var37, var38, var39, var40);
    var29.setOutlinePaint((java.awt.Paint)var35);
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("DateTickMarkPosition.START", "DateTickMarkPosition.START", "VerticalAlignment.CENTER", "DateTickMarkPosition.START", var17, var20, var27, (java.awt.Paint)var35);
    var1.setLeftArrow(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(13, 15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    boolean var4 = var2.contains(100.0d);
    double var6 = var2.constrain(2.0d);
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var9 = var8.getAxisLineStroke();
    java.awt.Font var10 = var8.getLabelFont();
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
    var8.setRangeWithMargins((org.jfree.data.Range)var11, false, true);
    boolean var15 = var2.intersects((org.jfree.data.Range)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setBackgroundAlpha(1.0f);
//     boolean var6 = var2.hasListener((java.util.EventListener)var3);
//     java.awt.Shape var7 = var2.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("");
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("");
//     java.awt.Paint var16 = var15.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var19 = var18.getAxisLineStroke();
//     var18.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var23 = var18.getTickLabelFont();
//     org.jfree.data.Range var24 = var18.getDefaultAutoRange();
//     boolean var25 = var18.isAutoTickUnitSelection();
//     java.awt.Paint var26 = var18.getTickLabelPaint();
//     var15.setBackgroundPaint(var26);
//     boolean var28 = var12.equals((java.lang.Object)var26);
//     org.jfree.chart.entity.TitleEntity var30 = new org.jfree.chart.entity.TitleEntity(var7, (org.jfree.chart.title.Title)var12, "AxisLabelEntity: label = null");
//     java.lang.String var31 = var30.toString();
//     java.lang.Object var32 = null;
//     boolean var33 = var30.equals(var32);
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var36 = var35.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.chart.plot.CombinedDomainXYPlot var38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var38.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var42 = var38.getOrientation();
//     var37.add((org.jfree.chart.plot.XYPlot)var38);
//     org.jfree.chart.axis.AxisSpace var44 = var37.getFixedDomainAxisSpace();
//     var37.setDomainCrosshairVisible(false);
//     boolean var47 = var30.equals((java.lang.Object)false);
//     org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var50 = new org.jfree.chart.plot.PolarPlot();
//     var50.setBackgroundAlpha(1.0f);
//     boolean var53 = var49.hasListener((java.util.EventListener)var50);
//     java.awt.Shape var54 = var49.getLeftArrow();
//     org.jfree.chart.entity.ChartEntity var57 = new org.jfree.chart.entity.ChartEntity(var54, "{0}: ({1}, {2})", "");
//     boolean var58 = var30.equals((java.lang.Object)var57);
//     
//     // Checks the contract:  equals-hashcode on var3 and var50
//     assertTrue("Contract failed: equals-hashcode on var3 and var50", var3.equals(var50) ? var3.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var3
//     assertTrue("Contract failed: equals-hashcode on var50 and var3", var50.equals(var3) ? var50.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var0.setUseOutlinePaint(true);
    boolean var3 = var0.getDrawSeriesLineAsPath();
    org.jfree.chart.text.TextBlock var4 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
    var9.setBackgroundAlpha(1.0f);
    boolean var12 = var8.hasListener((java.util.EventListener)var9);
    java.awt.Shape var13 = var8.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var16 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var6, var13, "hi!", "hi!");
    double var17 = var6.getUpperMargin();
    java.awt.Font var18 = var6.getLabelFont();
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var23 = var22.brighter();
    var4.addLine("", var18, (java.awt.Paint)var23);
    java.awt.Color var28 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var32 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var33 = var28.getColorComponents(var32);
    java.awt.color.ColorSpace var34 = var28.getColorSpace();
    java.awt.Color var38 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var42 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var43 = var38.getColorComponents(var42);
    java.awt.color.ColorSpace var44 = var38.getColorSpace();
    java.awt.Color var48 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var52 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var53 = var48.getColorComponents(var52);
    float[] var54 = var38.getRGBColorComponents(var52);
    float[] var55 = var23.getColorComponents(var34, var52);
    var0.setBaseOutlinePaint((java.awt.Paint)var23);
    java.io.ObjectOutputStream var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint)var23, var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    org.jfree.chart.plot.CrosshairState var6 = null;
    boolean var7 = var1.render(var2, var3, 0, var5, var6);
    var1.setGap(1.0E-8d);
    boolean var10 = var1.isRangeCrosshairVisible();
    var1.zoom(Double.NaN);
    java.util.List var13 = var1.getSubplots();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(var0, var13, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var8 = var7.getOutlineStroke();
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
    var9.setBackgroundAlpha(1.0f);
    java.awt.Paint var12 = var9.getBackgroundPaint();
    var7.setPaint(var12);
    var0.setRangeMinorGridlinePaint(var12);
    int var15 = var0.getWeight();
    java.lang.String var16 = var0.getPlotType();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var21 = var20.getRangeMinorGridlinePaint();
    var20.clearRangeMarkers(1);
    org.jfree.chart.plot.IntervalMarker var27 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var28 = var27.getOutlineStroke();
    java.awt.Stroke var29 = var27.getOutlineStroke();
    org.jfree.chart.util.Layer var30 = null;
    var20.addRangeMarker(10, (org.jfree.chart.plot.Marker)var27, var30, true);
    org.jfree.chart.plot.IntervalMarker var36 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 1.0d);
    org.jfree.chart.util.Layer var37 = null;
    boolean var39 = var20.removeDomainMarker(13, (org.jfree.chart.plot.Marker)var36, var37, true);
    org.jfree.chart.util.Layer var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(15, (org.jfree.chart.plot.Marker)var36, var40, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Combined_Domain_XYPlot"+ "'", var16.equals("Combined_Domain_XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
    org.jfree.chart.plot.PieLabelLinkStyle var5 = var2.getLabelLinkStyle();
    java.lang.String var6 = var5.toString();
    var1.setLabelLinkStyle(var5);
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var10 = var9.getAxisLineStroke();
    java.awt.Font var11 = var9.getLabelFont();
    var1.setLargeFont(var11);
    java.awt.Paint var13 = var1.getItemLabelPaint();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var15 = var14.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var16 = var14.getTickLabelInsets();
    double var18 = var16.trimHeight(1.0E-5d);
    var1.setAxisOffset(var16);
    java.awt.Paint var20 = var1.getShadowPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "PieLabelLinkStyle.STANDARD"+ "'", var6.equals("PieLabelLinkStyle.STANDARD"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-3.99999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var4.add(10.0d, (-1.0d), true);
    var4.setMaximumItemCount(0);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.renderer.xy.GradientXYBarPainter var3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(2.0d, 0.0d, 2.0d);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getMiddleMillisecond(var2);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"4", "Combined_Domain_XYPlot", "PlotOrientation.HORIZONTAL");
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var4.getEndY(3, 13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var1);
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var5 = var4.getAxisLineStroke();
//     var4.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var9 = var4.getTickLabelFont();
//     var0.setNoDataMessageFont(var9);
//     double var11 = var0.getMinimumArcAngleToDraw();
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot();
//     var14.setBackgroundAlpha(1.0f);
//     boolean var17 = var13.hasListener((java.util.EventListener)var14);
//     java.awt.Shape var18 = var13.getLeftArrow();
//     double var19 = var13.getLowerBound();
//     java.awt.Paint var20 = var13.getTickLabelPaint();
//     var0.setLabelPaint(var20);
//     var0.setLabelLinksVisible(false);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var26 = var25.getRangeMinorGridlinePaint();
//     var25.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     var25.handleClick(10, 0, var32);
//     java.awt.geom.Rectangle2D var34 = var32.getDataArea();
//     java.awt.geom.Rectangle2D var35 = var32.getDataArea();
//     java.awt.geom.Rectangle2D var36 = var32.getDataArea();
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Paint var39 = var38.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var38);
//     org.jfree.chart.axis.NumberAxis3D var42 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var43 = var42.getAxisLineStroke();
//     boolean var44 = var42.isAutoRange();
//     org.jfree.data.Range var47 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var48 = var47.getLowerBound();
//     var42.setRangeWithMargins(var47, false, false);
//     float var52 = var42.getMinorTickMarkInsideLength();
//     org.jfree.data.Range var53 = var40.getDataRange((org.jfree.chart.axis.ValueAxis)var42);
//     java.util.List var54 = var40.getSubplots();
//     org.jfree.chart.plot.CombinedDomainXYPlot var55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var56 = var55.getRangeMinorGridlinePaint();
//     var55.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var61 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var62 = new org.jfree.chart.plot.PlotRenderingInfo(var61);
//     var55.handleClick(10, 0, var62);
//     java.awt.geom.Rectangle2D var64 = var62.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var65 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var65.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var69 = var65.getOrientation();
//     boolean var70 = var65.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var71 = var65.getQuadrantOrigin();
//     org.jfree.chart.plot.XYPlot var72 = var40.findSubplot(var62, var71);
//     org.jfree.chart.plot.PlotState var73 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.CombinedDomainXYPlot var74 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var75 = var74.getRangeMinorGridlinePaint();
//     var74.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var80 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var81 = new org.jfree.chart.plot.PlotRenderingInfo(var80);
//     var74.handleClick(10, 0, var81);
//     var0.draw(var24, var36, var71, var73, var81);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.XYPlot var2 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var4 = var3.getRangeMinorGridlinePaint();
//     var3.clearRangeMarkers(1);
//     org.jfree.chart.plot.IntervalMarker var10 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var11 = var10.getOutlineStroke();
//     java.awt.Stroke var12 = var10.getOutlineStroke();
//     org.jfree.chart.util.Layer var13 = null;
//     var3.addRangeMarker(10, (org.jfree.chart.plot.Marker)var10, var13, true);
//     org.jfree.chart.plot.IntervalMarker var19 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 1.0d);
//     org.jfree.chart.util.Layer var20 = null;
//     boolean var22 = var3.removeDomainMarker(13, (org.jfree.chart.plot.Marker)var19, var20, true);
//     org.jfree.chart.axis.ValueAxis var24 = var3.getRangeAxis(0);
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot();
//     var30.setBackgroundAlpha(1.0f);
//     boolean var33 = var29.hasListener((java.util.EventListener)var30);
//     java.awt.Paint var34 = var30.getAngleLabelPaint();
//     var27.setLabelPaint(var34);
//     org.jfree.chart.axis.NumberTickUnit var37 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     java.lang.String var39 = var37.valueToString(0.0d);
//     var27.setTickUnit(var37);
//     var27.setAutoRangeMinimumSize(Double.NaN, true);
//     var3.setDomainAxis(100, (org.jfree.chart.axis.ValueAxis)var27, false);
//     java.awt.geom.Rectangle2D var46 = null;
//     var0.fillDomainGridBand(var1, var2, (org.jfree.chart.axis.ValueAxis)var27, var46, 3.9999900000000004d, 9.0d);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)'a');
    org.jfree.data.general.SeriesChangeInfo var2 = null;
    var1.setSummary(var2);
    org.jfree.data.general.SeriesChangeInfo var4 = var1.getSummary();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     boolean var3 = var2.getAutoPopulateSeriesFillPaint();
//     double var4 = var2.getLowerClip();
//     var2.setShadowYOffset(1.0E-5d);
//     java.lang.Boolean var8 = var2.getSeriesItemLabelsVisible(15);
//     org.jfree.chart.plot.DrawingSupplier var9 = var2.getDrawingSupplier();
//     double var10 = var2.getMinimumBarLength();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var15 = var14.getAxisLineStroke();
//     org.jfree.chart.text.TextBlock var16 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var17 = var16.getLineAlignment();
//     org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var20 = var19.clone();
//     var19.setDescription("");
//     boolean var23 = var16.equals((java.lang.Object)"");
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.util.Size2D var25 = var16.calculateDimensions(var24);
//     org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var28.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var32 = var28.getOrientation();
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
//     var33.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var35 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot();
//     var36.setBackgroundAlpha(1.0f);
//     var35.addChangeListener((org.jfree.data.general.DatasetChangeListener)var36);
//     java.awt.Paint var40 = var36.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     var36.handleClick((-398), 0, var43);
//     org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
//     var33.addLegend(var45);
//     java.awt.Color var50 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var51 = var50.brighter();
//     var45.setBackgroundPaint((java.awt.Paint)var50);
//     org.jfree.chart.util.RectangleAnchor var53 = var45.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var58 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var59 = var58.getLicenceName();
//     java.lang.String var60 = var58.getLicenceName();
//     boolean var61 = var53.equals((java.lang.Object)var60);
//     java.awt.geom.Rectangle2D var62 = org.jfree.chart.util.RectangleAnchor.createRectangle(var25, (-3.99999d), 5.0d, var53);
//     var2.drawRangeGridline(var11, var12, (org.jfree.chart.axis.ValueAxis)var14, var62, 1.0d);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var1 = var0.getMinimumArcAngleToDraw();
    java.awt.Stroke var2 = var0.getLabelOutlineStroke();
    var0.clearSectionOutlineStrokes(true);
    org.jfree.chart.urls.PieURLGenerator var5 = null;
    var0.setLegendLabelURLGenerator(var5);
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("");
    java.lang.Object var9 = var8.clone();
    var8.setDescription("");
    java.awt.Paint var12 = var8.getLinePaint();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
    var15.setBackgroundAlpha(1.0f);
    boolean var18 = var14.hasListener((java.util.EventListener)var15);
    java.awt.Paint var19 = var15.getAngleLabelPaint();
    org.jfree.chart.plot.Plot var20 = var15.getParent();
    boolean var21 = var15.isAngleLabelsVisible();
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot();
    double var23 = var22.getMinimumArcAngleToDraw();
    java.awt.Stroke var24 = var22.getLabelOutlineStroke();
    java.awt.Color var29 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var33 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var34 = var29.getColorComponents(var33);
    java.awt.color.ColorSpace var35 = var29.getColorSpace();
    java.awt.Color var39 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var43 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var44 = var39.getColorComponents(var43);
    float[] var45 = var29.getRGBColorComponents(var43);
    var22.setSectionPaint((java.lang.Comparable)(byte)(-1), (java.awt.Paint)var29);
    var15.setRadiusGridlinePaint((java.awt.Paint)var29);
    var8.setLinePaint((java.awt.Paint)var29);
    java.awt.Paint var49 = var8.getOutlinePaint();
    boolean var50 = var0.equals((java.lang.Object)var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    var1.setLabelLinksVisible(true);
    java.awt.Font var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNoDataMessageFont(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("Combined Range XYPlot", "VerticalAlignment.CENTER", "RectangleAnchor.CENTER", "null");

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (-398));
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(10, 100, 1);
    var2.setBasePaint((java.awt.Paint)var8);
    java.awt.Paint var11 = var2.getSeriesPaint(0);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var15 = var14.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var18 = var17.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var21 = var20.getAxisLineStroke();
    var20.resizeRange2(0.0d, 10.0d);
    java.awt.Font var25 = var20.getTickLabelFont();
    org.jfree.data.Range var26 = var20.getDefaultAutoRange();
    boolean var27 = var20.isAutoTickUnitSelection();
    java.awt.Paint var28 = var20.getTickLabelPaint();
    var17.setBackgroundPaint(var28);
    boolean var30 = var14.equals((java.lang.Object)var28);
    java.awt.Color var34 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var35 = var34.brighter();
    var14.setBackgroundPaint((java.awt.Paint)var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesOutlinePaint((-398), (java.awt.Paint)var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
    org.jfree.data.xy.DefaultXYDataset var2 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    var2.addChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
    int var8 = var2.indexOf((java.lang.Comparable)'a');
    java.lang.Number var9 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var2);
    org.jfree.chart.axis.NumberTickUnit var11 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var14 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var15 = var14.getItems();
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var18 = var17.getAxisLineStroke();
    var17.resizeRange2(0.0d, 10.0d);
    java.awt.Font var22 = var17.getTickLabelFont();
    org.jfree.data.Range var23 = var17.getDefaultAutoRange();
    org.jfree.chart.ui.Library var28 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var29 = var28.getLicenceName();
    boolean var30 = var23.equals((java.lang.Object)var28);
    org.jfree.data.Range var32 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2, var15, var23, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var34 = var1.generateLabel((org.jfree.data.xy.XYDataset)var2, 2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "hi!"+ "'", var29.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.setBackgroundAlpha(1.0f);
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var7 = var6.getRangeMinorGridlinePaint();
//     var6.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     var6.handleClick(10, 0, var13);
//     java.awt.geom.Rectangle2D var15 = var13.getDataArea();
//     java.awt.geom.Rectangle2D var16 = var13.getDataArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var17.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var21 = var17.getOrientation();
//     boolean var22 = var17.isDomainMinorGridlinesVisible();
//     java.awt.geom.Point2D var23 = var17.getQuadrantOrigin();
//     var4.zoomDomainAxes(0.2d, var13, var23, true);
//     java.awt.geom.Point2D var26 = null;
//     var0.zoomRangeAxes(100.0d, var13, var26);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    org.jfree.data.xy.IntervalXYDelegate var3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    java.lang.Object var4 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var0, 0, 5.0d, Double.NaN);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    java.util.TimeZone var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setXPosition(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.lang.String var1 = var0.getNullYString();
    java.text.DateFormat var2 = var0.getXDateFormat();
    org.jfree.chart.plot.PlotState var3 = new org.jfree.chart.plot.PlotState();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var2.format((java.lang.Object)var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "null"+ "'", var1.equals("null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getSimpleLabelOffset();
//     java.awt.Stroke var2 = var0.getLabelLinkStroke();
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot();
//     double var4 = var3.getMinimumArcAngleToDraw();
//     java.awt.Color var8 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var9 = var8.brighter();
//     var3.setBaseSectionOutlinePaint((java.awt.Paint)var9);
//     var0.setBaseSectionOutlinePaint((java.awt.Paint)var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.setNotify(false);
    var5.setNotify(false);
    java.lang.Object var10 = var5.getTextAntiAlias();
    var5.setTextAntiAlias(true);
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var14 = var13.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var15 = var13.getTickLabelInsets();
    double var16 = var15.getLeft();
    var5.setPadding(var15);
    double var19 = var15.calculateBottomOutset(0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    var0.setBackgroundImageAlignment(2147483647);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation();
    org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var9 = var8.getRangeMinorGridlinePaint();
    var8.clearRangeMarkers(1);
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var16 = var15.getOutlineStroke();
    java.awt.Stroke var17 = var15.getOutlineStroke();
    org.jfree.chart.util.Layer var18 = null;
    var8.addRangeMarker(10, (org.jfree.chart.plot.Marker)var15, var18, true);
    org.jfree.chart.util.Layer var21 = null;
    var0.addRangeMarker(0, (org.jfree.chart.plot.Marker)var15, var21);
    boolean var23 = var0.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.xy.DefaultXYDataset var3 = new org.jfree.data.xy.DefaultXYDataset();
//     var1.setDataset((org.jfree.data.general.Dataset)var3);
//     org.jfree.data.xy.IntervalXYDelegate var5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var3);
//     double var7 = var5.getDomainLowerBound(false);
//     double var8 = var5.getIntervalPositionFactor();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var11 = var5.getEndX(2147483647, 3);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5d);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.lang.Object var2 = var1.clone();
    org.jfree.data.xy.DefaultXYDataset var3 = new org.jfree.data.xy.DefaultXYDataset();
    var1.setDataset((org.jfree.data.general.Dataset)var3);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var7 = var3.getSeriesKey(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", var3, "", "", "");
    org.jfree.chart.axis.NumberTickUnit var9 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var13 = var12.getItems();
    var7.setContributors(var13);
    java.awt.Image var15 = var7.getLogo();
    org.jfree.chart.ui.Library var20 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
    java.lang.String var21 = var20.getLicenceName();
    var7.addOptionalLibrary(var20);
    var7.setInfo("AxisLabelEntity: label = null");
    java.lang.String var25 = var7.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "hi!"+ "'", var21.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + ""+ "'", var25.equals(""));

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("org.jfree.chart.ChartColor[r=10,g=100,b=1]", var1, var2);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var4.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var8 = var4.getOrientation();
    var3.add((org.jfree.chart.plot.XYPlot)var4);
    java.awt.Stroke var10 = var4.getRangeCrosshairStroke();
    org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var13 = var12.getRangeMinorGridlinePaint();
    org.jfree.chart.LegendItemCollection var14 = var12.getFixedLegendItems();
    org.jfree.chart.axis.AxisLocation var16 = var12.getDomainAxisLocation(255);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxisLocation(2147483647, var16, true);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     java.util.TimeZone var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     double var3 = var1.getDomainLowerBound(false);
//     var1.removeAllSeries();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.getItemCount(100);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
//     var7.setBackgroundAlpha(1.0f);
//     boolean var10 = var6.hasListener((java.util.EventListener)var7);
//     java.awt.Shape var11 = var6.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var4, var11, "hi!", "hi!");
//     java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var19 = var18.brighter();
//     org.jfree.chart.title.LegendGraphic var20 = new org.jfree.chart.title.LegendGraphic(var11, (java.awt.Paint)var18);
//     org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder(0.2d, 2.0d, 2.0d, 0.2d, (java.awt.Paint)var18);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var21.draw(var22, var23);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxis();
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
    var11.setBackgroundAlpha(1.0f);
    boolean var14 = var10.hasListener((java.util.EventListener)var11);
    java.awt.Shape var15 = var10.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var8, var15, "hi!", "hi!");
    double var19 = var8.getUpperMargin();
    var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var8, false);
    var0.setRangePannable(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setBackgroundAlpha(1.0f);
//     boolean var6 = var2.hasListener((java.util.EventListener)var3);
//     java.awt.Shape var7 = var2.getLeftArrow();
//     double var8 = var2.getLowerBound();
//     java.awt.Paint var9 = var2.getTickLabelPaint();
//     var0.setRangeMinorGridlinePaint(var9);
//     org.jfree.chart.axis.AxisSpace var11 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var13.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var17 = var13.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var20 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var21 = var20.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot();
//     var22.setBackgroundAlpha(1.0f);
//     java.awt.Paint var25 = var22.getBackgroundPaint();
//     var20.setPaint(var25);
//     var13.setRangeMinorGridlinePaint(var25);
//     int var28 = var13.getWeight();
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var31 = var30.getAxisLineStroke();
//     boolean var32 = var30.isAutoRange();
//     java.awt.Shape var33 = var30.getLeftArrow();
//     int var34 = var13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var30);
//     org.jfree.chart.util.RectangleEdge var35 = var13.getRangeAxisEdge();
//     var11.add(0.0d, var35);
//     var0.setFixedRangeAxisSpace(var11);
//     
//     // Checks the contract:  equals-hashcode on var3 and var22
//     assertTrue("Contract failed: equals-hashcode on var3 and var22", var3.equals(var22) ? var3.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var3
//     assertTrue("Contract failed: equals-hashcode on var22 and var3", var22.equals(var3) ? var22.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
//     boolean var2 = var0.isRangeMinorGridlinesVisible();
//     var0.setDomainCrosshairVisible(false);
//     org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
//     java.awt.Stroke var6 = var0.getRangeGridlineStroke();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
//     var9.setBackgroundAlpha(1.0f);
//     boolean var12 = var8.hasListener((java.util.EventListener)var9);
//     java.awt.Shape var13 = var8.getLeftArrow();
//     var8.setAutoRangeIncludesZero(false);
//     var8.setPositiveArrowVisible(false);
//     org.jfree.chart.event.AxisChangeEvent var18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var8);
//     org.jfree.chart.axis.Axis var19 = var18.getAxis();
//     var0.axisChanged(var18);
//     org.jfree.chart.axis.AxisSpace var21 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var22.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var26 = var22.getOrientation();
//     org.jfree.chart.axis.AxisSpace var27 = null;
//     var22.setFixedDomainAxisSpace(var27);
//     org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
//     var22.setFixedRangeAxisSpace(var29);
//     var21.ensureAtLeast(var29);
//     org.jfree.chart.axis.AxisSpace var32 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CombinedDomainXYPlot var34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var34.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var38 = var34.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var41 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var42 = var41.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var43 = new org.jfree.chart.plot.PolarPlot();
//     var43.setBackgroundAlpha(1.0f);
//     java.awt.Paint var46 = var43.getBackgroundPaint();
//     var41.setPaint(var46);
//     var34.setRangeMinorGridlinePaint(var46);
//     int var49 = var34.getWeight();
//     org.jfree.chart.axis.NumberAxis3D var51 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var52 = var51.getAxisLineStroke();
//     boolean var53 = var51.isAutoRange();
//     java.awt.Shape var54 = var51.getLeftArrow();
//     int var55 = var34.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var51);
//     org.jfree.chart.util.RectangleEdge var56 = var34.getRangeAxisEdge();
//     var32.add(0.0d, var56);
//     var29.ensureAtLeast(var32);
//     var0.setFixedRangeAxisSpace(var32, false);
//     
//     // Checks the contract:  equals-hashcode on var9 and var43
//     assertTrue("Contract failed: equals-hashcode on var9 and var43", var9.equals(var43) ? var9.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var9
//     assertTrue("Contract failed: equals-hashcode on var43 and var9", var43.equals(var9) ? var43.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Stroke var5 = null;
    org.jfree.chart.StandardChartTheme var7 = new org.jfree.chart.StandardChartTheme(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    java.awt.Paint var8 = var7.getRangeGridlinePaint();
    java.awt.Paint var9 = var7.getBaselinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem(var0, "VerticalAlignment.CENTER", "RectangleAnchor.CENTER", "Size2D[width=0.0, height=0.0]", var4, var5, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.ColumnArrangement var2 = new org.jfree.chart.block.ColumnArrangement();
//     var1.setArrangement((org.jfree.chart.block.Arrangement)var2);
//     boolean var5 = var2.equals((java.lang.Object)1.0E-8d);
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var2);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var4 = var2.lookupSeriesPaint(10);
    java.awt.Stroke var6 = var2.lookupSeriesOutlineStroke(13);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var11 = var9.lookupSeriesPaint(10);
    java.awt.Stroke var13 = var9.lookupSeriesOutlineStroke(13);
    var2.setBaseStroke(var13);
    java.awt.Paint var16 = var2.getSeriesFillPaint(0);
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot();
    double var18 = var17.getMinimumArcAngleToDraw();
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    java.awt.Color var23 = var22.brighter();
    var17.setBaseSectionOutlinePaint((java.awt.Paint)var23);
    var2.setBasePaint((java.awt.Paint)var23, false);
    org.jfree.chart.annotations.CategoryAnnotation var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addAnnotation(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var5.setNotify(false);
    var5.fireChartChanged();
    var5.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", var3, "", "", "");
    org.jfree.chart.axis.NumberTickUnit var9 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    java.util.List var13 = var12.getItems();
    var7.setContributors(var13);
    java.awt.Image var15 = var7.getLogo();
    java.lang.String var16 = var7.getInfo();
    var7.setName("Size2D[width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    var1.setBackgroundAlpha(1.0f);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
    int var6 = var0.indexOf((java.lang.Comparable)'a');
    org.jfree.data.xy.IntervalXYDelegate var7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.getXValue((-398), 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var4.add(10.0d, (-1.0d), true);
    double var9 = var4.getMinX();
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var4);
    org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var10, true);
    boolean var13 = var10.isAutoWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var10.getItemCount(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(2.0d, 0.0d, 9.99999999995449E-6d, 2.0d);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var1.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var5 = var1.getOrientation();
//     org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var6.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var8 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
//     var9.setBackgroundAlpha(1.0f);
//     var8.addChangeListener((org.jfree.data.general.DatasetChangeListener)var9);
//     java.awt.Paint var13 = var9.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var9.handleClick((-398), 0, var16);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     var6.addLegend(var18);
//     java.awt.Color var23 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var24 = var23.brighter();
//     var18.setBackgroundPaint((java.awt.Paint)var23);
//     org.jfree.chart.util.RectangleAnchor var26 = var18.getLegendItemGraphicLocation();
//     org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer();
//     var18.setWrapper(var27);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.block.RectangleConstraint var30 = null;
//     org.jfree.chart.util.Size2D var31 = var0.arrange(var27, var29, var30);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(13, var1);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setBackgroundAlpha(1.0f);
//     boolean var6 = var2.hasListener((java.util.EventListener)var3);
//     java.awt.Shape var7 = var2.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
//     java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var15 = var14.brighter();
//     org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var7, (java.awt.Paint)var14);
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var19 = var18.getAxisLineStroke();
//     boolean var20 = var18.isAutoRange();
//     java.awt.Shape var21 = var18.getRightArrow();
//     java.awt.Shape var22 = var18.getUpArrow();
//     var16.setLine(var22);
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var26 = var25.getAxisLineStroke();
//     boolean var27 = var25.isAutoRange();
//     java.awt.Shape var28 = var25.getRightArrow();
//     org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var29.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var33 = var29.getOrientation();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var29);
//     var34.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var36 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot();
//     var37.setBackgroundAlpha(1.0f);
//     var36.addChangeListener((org.jfree.data.general.DatasetChangeListener)var37);
//     java.awt.Paint var41 = var37.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     var37.handleClick((-398), 0, var44);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
//     var34.addLegend(var46);
//     java.awt.Color var51 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var52 = var51.brighter();
//     var46.setBackgroundPaint((java.awt.Paint)var51);
//     org.jfree.chart.util.RectangleAnchor var54 = var46.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var59 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var60 = var59.getLicenceName();
//     java.lang.String var61 = var59.getLicenceName();
//     boolean var62 = var54.equals((java.lang.Object)var61);
//     boolean var64 = var54.equals((java.lang.Object)"0");
//     java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var28, var54, 0.0d, 6.0d);
//     var16.setShape(var28);
//     
//     // Checks the contract:  equals-hashcode on var3 and var37
//     assertTrue("Contract failed: equals-hashcode on var3 and var37", var3.equals(var37) ? var3.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var3
//     assertTrue("Contract failed: equals-hashcode on var37 and var3", var37.equals(var3) ? var37.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Paint var1 = var0.getRangeMinorGridlinePaint();
    var0.clearRangeMarkers(1);
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
    java.awt.Stroke var8 = var7.getOutlineStroke();
    java.awt.Stroke var9 = var7.getOutlineStroke();
    org.jfree.chart.util.Layer var10 = null;
    var0.addRangeMarker(10, (org.jfree.chart.plot.Marker)var7, var10, true);
    org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 1.0d);
    org.jfree.chart.util.Layer var17 = null;
    boolean var19 = var0.removeDomainMarker(13, (org.jfree.chart.plot.Marker)var16, var17, true);
    org.jfree.chart.axis.ValueAxis var21 = var0.getRangeAxis(0);
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot();
    var27.setBackgroundAlpha(1.0f);
    boolean var30 = var26.hasListener((java.util.EventListener)var27);
    java.awt.Paint var31 = var27.getAngleLabelPaint();
    var24.setLabelPaint(var31);
    org.jfree.chart.axis.NumberTickUnit var34 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    java.lang.String var36 = var34.valueToString(0.0d);
    var24.setTickUnit(var34);
    var24.setAutoRangeMinimumSize(Double.NaN, true);
    var0.setDomainAxis(100, (org.jfree.chart.axis.ValueAxis)var24, false);
    java.awt.Color var47 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var51 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var52 = var47.getColorComponents(var51);
    java.awt.Color var53 = java.awt.Color.getColor("TitleEntity: tooltip = AxisLabelEntity: label = null", var47);
    var0.setRangeCrosshairPaint((java.awt.Paint)var53);
    java.awt.Color var58 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var62 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var63 = var58.getColorComponents(var62);
    java.awt.color.ColorSpace var64 = var58.getColorSpace();
    java.awt.Color var68 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    float[] var72 = new float[] { 10.0f, (-1.0f), 100.0f};
    float[] var73 = var68.getColorComponents(var72);
    float[] var74 = var58.getRGBColorComponents(var72);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var75 = var53.getComponents(var74);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "0"+ "'", var36.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.ColumnArrangement var1 = new org.jfree.chart.block.ColumnArrangement();
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
//     org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var3.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var7 = var3.getOrientation();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
//     var8.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var10 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
//     var11.setBackgroundAlpha(1.0f);
//     var10.addChangeListener((org.jfree.data.general.DatasetChangeListener)var11);
//     java.awt.Paint var15 = var11.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var11.handleClick((-398), 0, var18);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
//     var8.addLegend(var20);
//     var0.add((org.jfree.chart.block.Block)var20);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.text.TextBlock var24 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var25 = var24.getLineAlignment();
//     org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("");
//     java.lang.Object var28 = var27.clone();
//     var27.setDescription("");
//     boolean var31 = var24.equals((java.lang.Object)"");
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.util.Size2D var33 = var24.calculateDimensions(var32);
//     org.jfree.chart.plot.CombinedDomainXYPlot var36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var36.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var40 = var36.getOrientation();
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var36);
//     var41.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var43 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot();
//     var44.setBackgroundAlpha(1.0f);
//     var43.addChangeListener((org.jfree.data.general.DatasetChangeListener)var44);
//     java.awt.Paint var48 = var44.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     var44.handleClick((-398), 0, var51);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var44);
//     var41.addLegend(var53);
//     java.awt.Color var58 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var59 = var58.brighter();
//     var53.setBackgroundPaint((java.awt.Paint)var58);
//     org.jfree.chart.util.RectangleAnchor var61 = var53.getLegendItemGraphicLocation();
//     org.jfree.chart.ui.Library var66 = new org.jfree.chart.ui.Library("", "hi!", "hi!", "");
//     java.lang.String var67 = var66.getLicenceName();
//     java.lang.String var68 = var66.getLicenceName();
//     boolean var69 = var61.equals((java.lang.Object)var68);
//     java.awt.geom.Rectangle2D var70 = org.jfree.chart.util.RectangleAnchor.createRectangle(var33, (-3.99999d), 5.0d, var61);
//     var0.draw(var23, var70);
// 
//   }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     java.util.TimeZone var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     double var3 = var1.getDomainLowerBound(false);
//     var1.removeAllSeries();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.getStartXValue(15, 0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var2 = var1.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var5 = var4.getAxisLineStroke();
    var4.resizeRange2(0.0d, 10.0d);
    java.awt.Font var9 = var4.getTickLabelFont();
    org.jfree.data.Range var10 = var4.getDefaultAutoRange();
    boolean var11 = var4.isAutoTickUnitSelection();
    java.awt.Paint var12 = var4.getTickLabelPaint();
    var1.setBackgroundPaint(var12);
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var1.draw(var14, var15);
    var1.setExpandToFitSpace(false);
    java.lang.String var19 = var1.getToolTipText();
    java.lang.Object var20 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var4 = var2.lookupSeriesPaint(10);
    java.awt.Stroke var6 = var2.lookupSeriesOutlineStroke(13);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var11 = var9.lookupSeriesPaint(10);
    java.awt.Stroke var13 = var9.lookupSeriesOutlineStroke(13);
    var2.setBaseStroke(var13);
    java.awt.Paint var16 = var2.getSeriesFillPaint(0);
    double var17 = var2.getMaximumBarWidth();
    org.jfree.chart.labels.CategoryToolTipGenerator var19 = var2.getSeriesToolTipGenerator((-398));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("null", var1, 2.0f, 0.0f, 1.0000230261160271E-4d, 0.5f, 0.5f);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.ColumnArrangement var1 = new org.jfree.chart.block.ColumnArrangement();
    var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var3.setDomainCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var7 = var3.getOrientation();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    var8.fireChartChanged();
    org.jfree.data.xy.DefaultXYDataset var10 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
    var11.setBackgroundAlpha(1.0f);
    var10.addChangeListener((org.jfree.data.general.DatasetChangeListener)var11);
    java.awt.Paint var15 = var11.getAngleGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    var11.handleClick((-398), 0, var18);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    var8.addLegend(var20);
    var0.add((org.jfree.chart.block.Block)var20);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)15);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    org.jfree.data.xy.IntervalXYDelegate var3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var3.getEndX((-1), 2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.chart.plot.CrosshairState var6 = null;
//     boolean var7 = var1.render(var2, var3, 0, var5, var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("TitleEntity: tooltip = AxisLabelEntity: label = null", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.LegendTitle var9 = var8.getLegend();
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("");
//     int var12 = var11.getMaximumLinesToDisplay();
//     var8.setTitle(var11);
//     boolean var14 = var8.isNotify();
//     org.jfree.chart.event.ChartProgressListener var15 = null;
//     var8.removeProgressListener(var15);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot();
//     var21.setBackgroundAlpha(1.0f);
//     boolean var24 = var20.hasListener((java.util.EventListener)var21);
//     java.awt.Shape var25 = var20.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var28 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, var25, "hi!", "hi!");
//     double var29 = var18.getUpperMargin();
//     double var30 = var18.getAutoRangeMinimumSize();
//     org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Paint var33 = var32.getRangeMinorGridlinePaint();
//     var32.clearRangeMarkers(1);
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
//     var32.handleClick(10, 0, var39);
//     java.awt.geom.Rectangle2D var41 = var39.getDataArea();
//     java.awt.geom.Rectangle2D var42 = var39.getDataArea();
//     java.awt.geom.Rectangle2D var43 = var39.getDataArea();
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var18.valueToJava2D(0.05d, var43, var44);
//     org.jfree.chart.ChartRenderingInfo var46 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var47 = var46.getChartArea();
//     var8.draw(var17, var43, var46);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(0.0d, "", "", false);
    java.text.NumberFormat var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExponentFormat(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     java.awt.Paint var2 = var1.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("");
//     java.awt.Paint var5 = var4.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var8 = var7.getAxisLineStroke();
//     var7.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var12 = var7.getTickLabelFont();
//     org.jfree.data.Range var13 = var7.getDefaultAutoRange();
//     boolean var14 = var7.isAutoTickUnitSelection();
//     java.awt.Paint var15 = var7.getTickLabelPaint();
//     var4.setBackgroundPaint(var15);
//     boolean var17 = var1.equals((java.lang.Object)var15);
//     java.awt.Color var21 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var22 = var21.brighter();
//     var1.setBackgroundPaint((java.awt.Paint)var22);
//     org.jfree.chart.util.VerticalAlignment var24 = var1.getVerticalAlignment();
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var25.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var29 = var25.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var32 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var33 = var32.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot();
//     var34.setBackgroundAlpha(1.0f);
//     java.awt.Paint var37 = var34.getBackgroundPaint();
//     var32.setPaint(var37);
//     var25.setRangeMinorGridlinePaint(var37);
//     int var40 = var25.getWeight();
//     org.jfree.chart.axis.NumberAxis3D var42 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var43 = var42.getAxisLineStroke();
//     boolean var44 = var42.isAutoRange();
//     java.awt.Shape var45 = var42.getLeftArrow();
//     int var46 = var25.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var42);
//     org.jfree.chart.util.RectangleEdge var47 = var25.getRangeAxisEdge();
//     var1.setPosition(var47);
//     org.jfree.chart.axis.AxisSpace var49 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CombinedDomainXYPlot var51 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var51.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var55 = var51.getOrientation();
//     org.jfree.chart.plot.IntervalMarker var58 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d);
//     java.awt.Stroke var59 = var58.getOutlineStroke();
//     org.jfree.chart.plot.PolarPlot var60 = new org.jfree.chart.plot.PolarPlot();
//     var60.setBackgroundAlpha(1.0f);
//     java.awt.Paint var63 = var60.getBackgroundPaint();
//     var58.setPaint(var63);
//     var51.setRangeMinorGridlinePaint(var63);
//     int var66 = var51.getWeight();
//     org.jfree.chart.axis.NumberAxis3D var68 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var69 = var68.getAxisLineStroke();
//     boolean var70 = var68.isAutoRange();
//     java.awt.Shape var71 = var68.getLeftArrow();
//     int var72 = var51.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var68);
//     org.jfree.chart.util.RectangleEdge var73 = var51.getRangeAxisEdge();
//     var49.ensureAtLeast(0.0d, var73);
//     var1.setPosition(var73);
//     
//     // Checks the contract:  equals-hashcode on var25 and var51
//     assertTrue("Contract failed: equals-hashcode on var25 and var51", var25.equals(var51) ? var25.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var25
//     assertTrue("Contract failed: equals-hashcode on var51 and var25", var51.equals(var25) ? var51.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var58
//     assertTrue("Contract failed: equals-hashcode on var32 and var58", var32.equals(var58) ? var32.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var32
//     assertTrue("Contract failed: equals-hashcode on var58 and var32", var58.equals(var32) ? var58.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var60
//     assertTrue("Contract failed: equals-hashcode on var34 and var60", var34.equals(var60) ? var34.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var34
//     assertTrue("Contract failed: equals-hashcode on var60 and var34", var60.equals(var34) ? var60.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var3 = var2.getAutoPopulateSeriesFillPaint();
    double var4 = var2.getLowerClip();
    var2.setShadowYOffset(1.0E-5d);
    double var7 = var2.getYOffset();
    double var8 = var2.getShadowXOffset();
    java.awt.Paint var12 = var2.getItemLabelPaint(0, 2, true);
    var2.setSeriesCreateEntities(3, (java.lang.Boolean)false);
    org.jfree.chart.LegendItemCollection var16 = var2.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setBackgroundAlpha(1.0f);
//     boolean var6 = var2.hasListener((java.util.EventListener)var3);
//     java.awt.Shape var7 = var2.getLeftArrow();
//     org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
//     java.awt.Color var14 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var15 = var14.brighter();
//     org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var7, (java.awt.Paint)var14);
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var19 = var18.getAxisLineStroke();
//     boolean var20 = var18.isAutoRange();
//     java.awt.Shape var21 = var18.getRightArrow();
//     java.awt.Shape var22 = var18.getUpArrow();
//     var16.setLine(var22);
//     org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
//     java.awt.Paint var28 = var26.lookupSeriesPaint(10);
//     java.lang.Boolean var30 = var26.getSeriesVisible(100);
//     boolean var31 = var26.isDrawBarOutline();
//     java.awt.Stroke var32 = var26.getBaseStroke();
//     var16.setLineStroke(var32);
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var35 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var34.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var35);
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.Stroke var39 = var38.getAxisLineStroke();
//     var38.resizeRange2(0.0d, 10.0d);
//     java.awt.Font var43 = var38.getTickLabelFont();
//     var34.setNoDataMessageFont(var43);
//     double var45 = var34.getMinimumArcAngleToDraw();
//     java.awt.Stroke var46 = null;
//     var34.setLabelOutlineStroke(var46);
//     java.awt.Color var51 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var52 = var51.brighter();
//     var34.setLabelShadowPaint((java.awt.Paint)var51);
//     org.jfree.chart.plot.CombinedDomainXYPlot var54 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var54.setDomainCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var58 = var54.getOrientation();
//     org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var54);
//     var59.fireChartChanged();
//     org.jfree.data.xy.DefaultXYDataset var61 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.plot.PolarPlot var62 = new org.jfree.chart.plot.PolarPlot();
//     var62.setBackgroundAlpha(1.0f);
//     var61.addChangeListener((org.jfree.data.general.DatasetChangeListener)var62);
//     java.awt.Paint var66 = var62.getAngleGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var69 = null;
//     var62.handleClick((-398), 0, var69);
//     org.jfree.chart.title.LegendTitle var71 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var62);
//     var59.addLegend(var71);
//     java.awt.Color var76 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
//     java.awt.Color var77 = var76.brighter();
//     var71.setBackgroundPaint((java.awt.Paint)var76);
//     org.jfree.chart.util.RectangleAnchor var79 = var71.getLegendItemGraphicLocation();
//     boolean var80 = var51.equals((java.lang.Object)var79);
//     var16.setOutlinePaint((java.awt.Paint)var51);
//     
//     // Checks the contract:  equals-hashcode on var3 and var62
//     assertTrue("Contract failed: equals-hashcode on var3 and var62", var3.equals(var62) ? var3.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var3
//     assertTrue("Contract failed: equals-hashcode on var62 and var3", var62.equals(var3) ? var62.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.CENTER", var1, 10.0f, 10.0f, var4, Double.NaN, var6);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("500%", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)100.0d, true, true);
    var4.add(10.0d, (-1.0d), true);
    var4.setKey((java.lang.Comparable)(byte)(-1));
    org.jfree.data.xy.XYDataItem var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var12 = var4.addOrUpdate(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    boolean var6 = var2.hasListener((java.util.EventListener)var3);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var13 = var12.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var16 = var15.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Stroke var19 = var18.getAxisLineStroke();
    var18.resizeRange2(0.0d, 10.0d);
    java.awt.Font var23 = var18.getTickLabelFont();
    org.jfree.data.Range var24 = var18.getDefaultAutoRange();
    boolean var25 = var18.isAutoTickUnitSelection();
    java.awt.Paint var26 = var18.getTickLabelPaint();
    var15.setBackgroundPaint(var26);
    boolean var28 = var12.equals((java.lang.Object)var26);
    org.jfree.chart.entity.TitleEntity var30 = new org.jfree.chart.entity.TitleEntity(var7, (org.jfree.chart.title.Title)var12, "AxisLabelEntity: label = null");
    org.jfree.data.xy.DefaultXYDataset var31 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.Range var33 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var31, true);
    org.jfree.data.xy.IntervalXYDelegate var34 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var31);
    java.lang.Object var35 = var31.clone();
    org.jfree.chart.entity.XYItemEntity var40 = new org.jfree.chart.entity.XYItemEntity(var7, (org.jfree.data.xy.XYDataset)var31, (-1), 15, "null", "");
    org.jfree.data.Range var42 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var31, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var46 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var31, (-1), 1.0000230261160271E-4d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    var0.draw(var1, 2.0f, 100.0f, var4, 100.0f, (-1.0f), 2.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    boolean var12 = var11.getAutoPopulateSeriesFillPaint();
    double var13 = var11.getLowerClip();
    org.jfree.chart.ChartColor var17 = new org.jfree.chart.ChartColor(10, 100, 1);
    var11.setBasePaint((java.awt.Paint)var17);
    java.awt.Font var19 = var11.getBaseItemLabelFont();
    boolean var20 = var0.equals((java.lang.Object)var11);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
    var24.setBackgroundAlpha(1.0f);
    boolean var27 = var23.hasListener((java.util.EventListener)var24);
    java.awt.Shape var28 = var23.getLeftArrow();
    double var29 = var23.getLowerBound();
    java.awt.Paint var30 = var23.getTickLabelPaint();
    var21.setRangeMinorGridlinePaint(var30);
    var11.setPlot(var21);
    org.jfree.chart.plot.CategoryMarker var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.addDomainMarker(var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.VerticalAlignment var2 = var1.getVerticalAlignment();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var8 = var7.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(6.0d, var7);
//     org.jfree.chart.block.RectangleConstraint var10 = var9.toUnconstrainedHeight();
//     org.jfree.chart.block.RectangleConstraint var11 = var9.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var12 = var1.arrange(var3, var11);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var1 = var0.getMaximumDate();
//     org.jfree.chart.axis.SegmentedTimeline var2 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var4 = var3.getMaximumDate();
//     long var5 = var2.toTimelineValue(var4);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("10", (org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var8);
//     var10.setMinorTickMarkInsideLength((-1.0f));
//     boolean var13 = var10.isMinorTickMarksVisible();
//     java.util.TimeZone var14 = var10.getTimeZone();
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day(var4, var14);
//     org.jfree.data.time.TimeSeriesCollection var16 = new org.jfree.data.time.TimeSeriesCollection(var14);
//     java.util.Locale var17 = null;
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var1, var14, var17);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var4 = var2.lookupSeriesPaint(10);
    java.awt.Stroke var6 = var2.lookupSeriesOutlineStroke(13);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0E-8d, 0.0d);
    java.awt.Paint var11 = var9.lookupSeriesPaint(10);
    java.awt.Stroke var13 = var9.lookupSeriesOutlineStroke(13);
    var2.setBaseStroke(var13);
    boolean var15 = var2.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(true);
    var1.updateCrosshairX(0.0d, 100);
    var1.setCrosshairY(0.2d);
    var1.setAnchorX(2.0d);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var3.setBackgroundAlpha(1.0f);
    boolean var6 = var2.hasListener((java.util.EventListener)var3);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var7, "hi!", "hi!");
    double var11 = var0.getUpperMargin();
    double var12 = var0.getAutoRangeMinimumSize();
    var0.configure();
    boolean var14 = var0.isVerticalTickLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(13);
    double var2 = var1.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0d);

  }

}
