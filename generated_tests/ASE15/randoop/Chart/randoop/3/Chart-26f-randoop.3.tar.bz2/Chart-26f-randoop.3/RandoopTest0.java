
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var2, 10.0f, 100, var5);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Paint var2 = null;
    java.awt.Stroke var3 = null;
    java.awt.Paint var4 = null;
    java.awt.Stroke var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, var2, var3, var4, var5, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("hi!", var1, var2, var3, var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.lang.Number var0 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(var0, (java.lang.Number)100.0d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    float var2 = var1.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Font var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseItemLabelFont(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    org.jfree.chart.plot.DatasetRenderingOrder var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.block.BlockContainer var1 = null;
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.block.RectangleConstraint var3 = null;
//     org.jfree.chart.util.Size2D var4 = var0.arrange(var1, var2, var3);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Image var1 = var0.getBackgroundImage();
    java.awt.Stroke var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainZeroBaselineStroke(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.lang.Comparable var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var8 = null;
    org.jfree.chart.ui.ProjectInfo var12 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var8, "hi!", "", "hi!");
    java.awt.Image var16 = null;
    org.jfree.chart.ui.ProjectInfo var20 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var16, "hi!", "", "hi!");
    var12.addLibrary((org.jfree.chart.ui.Library)var20);
    boolean var22 = var4.equals((java.lang.Object)var20);
    java.awt.Paint var24 = var4.lookupSeriesFillPaint(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("hi!", var1, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem(var0, "", "", "", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
    org.jfree.data.Range var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDefaultAutoRange(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var3 = null;
    var1.setQuadrantPaint(1, var3);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var11 = null;
    org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var11, "hi!", "", "hi!");
    java.awt.Image var19 = null;
    org.jfree.chart.ui.ProjectInfo var23 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var19, "hi!", "", "hi!");
    var15.addLibrary((org.jfree.chart.ui.Library)var23);
    boolean var25 = var7.equals((java.lang.Object)var23);
    java.awt.Paint var27 = var7.lookupSeriesFillPaint(100);
    var1.setBackgroundPaint(var27);
    java.awt.Stroke var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, var27, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
    var8.setDomainCrosshairValue(1.0d, false);
    org.jfree.chart.util.RectangleInsets var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setInsets(var12, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    org.jfree.chart.plot.CategoryPlot var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setPlot(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    var2.setUseOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBasePositiveItemLabelPosition(var23, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 1.0f, 0.5f, var4);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "", "hi!", "");

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var10 = null;
    org.jfree.chart.ui.ProjectInfo var14 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var10, "hi!", "", "hi!");
    java.awt.Image var18 = null;
    org.jfree.chart.ui.ProjectInfo var22 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var18, "hi!", "", "hi!");
    var14.addLibrary((org.jfree.chart.ui.Library)var22);
    boolean var24 = var6.equals((java.lang.Object)var22);
    java.awt.Paint var26 = var6.lookupSeriesFillPaint(100);
    var0.setBackgroundPaint(var26);
    org.jfree.chart.plot.Marker var29 = null;
    org.jfree.chart.util.Layer var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((-1), var29, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.awt.Color var1 = java.awt.Color.getColor("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.plot.Plot var1 = var0.getRootPlot();
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var3.isTickMarksVisible();
//     java.awt.Font var6 = var3.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var13 = null;
//     org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
//     java.awt.Image var21 = null;
//     org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
//     var17.addLibrary((org.jfree.chart.ui.Library)var25);
//     boolean var27 = var9.equals((java.lang.Object)var25);
//     java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var38 = null;
//     org.jfree.chart.ui.ProjectInfo var42 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var38, "hi!", "", "hi!");
//     java.awt.Image var46 = null;
//     org.jfree.chart.ui.ProjectInfo var50 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var46, "hi!", "", "hi!");
//     var42.addLibrary((org.jfree.chart.ui.Library)var50);
//     boolean var52 = var34.equals((java.lang.Object)var50);
//     java.awt.Paint var54 = var34.lookupSeriesFillPaint(100);
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var57 = null;
//     var55.setQuadrantPaint(1, var57);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var65 = null;
//     org.jfree.chart.ui.ProjectInfo var69 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var65, "hi!", "", "hi!");
//     java.awt.Image var73 = null;
//     org.jfree.chart.ui.ProjectInfo var77 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var73, "hi!", "", "hi!");
//     var69.addLibrary((org.jfree.chart.ui.Library)var77);
//     boolean var79 = var61.equals((java.lang.Object)var77);
//     java.awt.Paint var81 = var61.lookupSeriesFillPaint(100);
//     var55.setBackgroundPaint(var81);
//     boolean var83 = org.jfree.chart.util.PaintUtilities.equal(var54, var81);
//     org.jfree.chart.text.TextMeasurer var86 = null;
//     org.jfree.chart.text.TextBlock var87 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var6, var54, 0.5f, 0, var86);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)100);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(short)1);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var6 = null;
//     org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     var10.addLibrary((org.jfree.chart.ui.Library)var18);
//     boolean var20 = var2.equals((java.lang.Object)var18);
//     var2.setSeriesShapesVisible(1, false);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.plot.CategoryMarker var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     var2.drawDomainMarker(var24, var25, var26, var27, var28);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1L), (java.lang.Number)(short)10);
    java.lang.Number var3 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)10+ "'", var3.equals((short)10));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var2 = null;
//     var0.setQuadrantPaint(1, var2);
//     boolean var4 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.Marker var6 = null;
//     org.jfree.chart.util.Layer var7 = null;
//     var0.addRangeMarker(var6, var7);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", var3);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var1 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var2 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var1};
    var0.setRenderers(var2);
    org.jfree.chart.plot.Marker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(10, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.category.CategoryDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = var0.findRangeBounds(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.awt.Shape var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var23 = null;
    org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
    java.awt.Image var31 = null;
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
    var27.addLibrary((org.jfree.chart.ui.Library)var35);
    boolean var37 = var19.equals((java.lang.Object)var35);
    java.awt.Paint var39 = var19.lookupSeriesFillPaint(100);
    java.awt.Paint var41 = var19.getSeriesOutlinePaint(1);
    java.lang.Number var43 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var44 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var43);
    boolean var45 = var19.equals((java.lang.Object)var43);
    java.lang.Boolean var47 = var19.getSeriesCreateEntities(10);
    var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.axis.AxisLocation var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setDomainAxisLocation(var49, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     java.awt.Paint var39 = var19.lookupSeriesFillPaint(100);
//     java.awt.Paint var41 = var19.getSeriesOutlinePaint(1);
//     java.lang.Number var43 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var44 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var43);
//     boolean var45 = var19.equals((java.lang.Object)var43);
//     java.lang.Boolean var47 = var19.getSeriesCreateEntities(10);
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
//     org.jfree.data.category.CategoryDataset var50 = null;
//     org.jfree.chart.axis.CategoryAxis var51 = null;
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var57 = var56.clone();
//     boolean var58 = var56.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var59 = null;
//     org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.axis.ValueAxis)var56, var59);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var63 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var65 = var63.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var50, var51, (org.jfree.chart.axis.ValueAxis)var56, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var69 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var73 = null;
//     org.jfree.chart.ui.ProjectInfo var77 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var73, "hi!", "", "hi!");
//     java.awt.Image var81 = null;
//     org.jfree.chart.ui.ProjectInfo var85 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var81, "hi!", "", "hi!");
//     var77.addLibrary((org.jfree.chart.ui.Library)var85);
//     boolean var87 = var69.equals((java.lang.Object)var85);
//     java.awt.Paint var89 = var69.lookupSeriesFillPaint(100);
//     java.awt.Paint var91 = var69.getSeriesOutlinePaint(1);
//     java.lang.Number var93 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var94 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var93);
//     boolean var95 = var69.equals((java.lang.Object)var93);
//     java.lang.Boolean var97 = var69.getSeriesCreateEntities(10);
//     var66.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var69);
//     var16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var69);
//     
//     // Checks the contract:  equals-hashcode on var10 and var60
//     assertTrue("Contract failed: equals-hashcode on var10 and var60", var10.equals(var60) ? var10.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var10
//     assertTrue("Contract failed: equals-hashcode on var60 and var10", var60.equals(var10) ? var60.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var66
//     assertTrue("Contract failed: equals-hashcode on var16 and var66", var16.equals(var66) ? var16.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var16
//     assertTrue("Contract failed: equals-hashcode on var66 and var16", var66.equals(var16) ? var66.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var94
//     assertTrue("Contract failed: equals-hashcode on var44 and var94", var44.equals(var94) ? var44.hashCode() == var94.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var94 and var44
//     assertTrue("Contract failed: equals-hashcode on var94 and var44", var94.equals(var44) ? var94.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    java.awt.Paint var24 = var2.getSeriesOutlinePaint(1);
    java.lang.Number var26 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var26);
    boolean var28 = var2.equals((java.lang.Object)var26);
    java.lang.Boolean var30 = var2.getSeriesCreateEntities(10);
    var2.setSeriesCreateEntities(10, (java.lang.Boolean)true, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var37 = var2.getToolTipGenerator(1, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var4 = var3.clone();
    boolean var5 = var3.isTickMarksVisible();
    java.awt.Font var6 = var3.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
    java.awt.Image var21 = null;
    org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
    var17.addLibrary((org.jfree.chart.ui.Library)var25);
    boolean var27 = var9.equals((java.lang.Object)var25);
    java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
    java.awt.Font var32 = var31.getFont();
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var36 = var35.clone();
    boolean var37 = var35.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var40 = var39.clone();
    var39.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var43);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var44, true);
    org.jfree.chart.event.ChartChangeListener var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var46.addChangeListener(var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.event.RendererChangeEvent var5 = null;
    var0.rendererChanged(var5);
    org.jfree.chart.annotations.XYAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var8 = var0.removeAnnotation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var3 = var2.clone();
//     boolean var4 = var2.isTickMarksVisible();
//     java.awt.Font var5 = var2.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var12 = null;
//     org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var12, "hi!", "", "hi!");
//     java.awt.Image var20 = null;
//     org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var20, "hi!", "", "hi!");
//     var16.addLibrary((org.jfree.chart.ui.Library)var24);
//     boolean var26 = var8.equals((java.lang.Object)var24);
//     java.awt.Paint var28 = var8.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("", var5, var28, 0.0f);
//     java.awt.Font var31 = var30.getFont();
//     org.jfree.chart.JFreeChart var32 = null;
//     org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var30, var32);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.text.TextAnchor var35 = null;
//     float var36 = var30.calculateBaselineOffset(var34, var35);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
    org.jfree.chart.plot.Plot var9 = var2.getPlot();
    org.jfree.data.RangeType var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setRangeType(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     var16.setRangeCrosshairVisible(true);
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var28 = var27.clone();
//     boolean var29 = var27.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var27, var30);
//     org.jfree.chart.axis.ValueAxis[] var32 = new org.jfree.chart.axis.ValueAxis[] { var27};
//     var16.setRangeAxes(var32);
//     
//     // Checks the contract:  equals-hashcode on var10 and var31
//     assertTrue("Contract failed: equals-hashcode on var10 and var31", var10.equals(var31) ? var10.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var10
//     assertTrue("Contract failed: equals-hashcode on var31 and var10", var31.equals(var10) ? var31.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer(0);
    boolean var8 = var0.isRangeZeroBaselineVisible();
    org.jfree.chart.annotations.XYAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, (-1.0d), 1.0d, 0, (java.lang.Comparable)15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     var16.setRangeCrosshairVisible(true);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var30 = null;
//     org.jfree.chart.ui.ProjectInfo var34 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var30, "hi!", "", "hi!");
//     java.awt.Image var38 = null;
//     org.jfree.chart.ui.ProjectInfo var42 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var38, "hi!", "", "hi!");
//     var34.addLibrary((org.jfree.chart.ui.Library)var42);
//     boolean var44 = var26.equals((java.lang.Object)var42);
//     java.awt.Paint var46 = var26.lookupSeriesFillPaint(100);
//     java.awt.Paint var48 = var26.getSeriesOutlinePaint(1);
//     java.lang.Number var50 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var51 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var50);
//     boolean var52 = var26.equals((java.lang.Object)var50);
//     java.lang.Boolean var54 = var26.getSeriesCreateEntities(10);
//     var26.setSeriesCreateEntities(10, (java.lang.Boolean)true, false);
//     var16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var26, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var26.", var13.equals(var26) == var26.equals(var13));
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var2 = var1.clone();
    boolean var3 = var1.isTickMarksVisible();
    java.awt.Font var4 = var1.getTickLabelFont();
    java.awt.Shape var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var8 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var5, "SerialDate.weekInMonthToString(): invalid code.", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var23 = null;
    org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
    java.awt.Image var31 = null;
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
    var27.addLibrary((org.jfree.chart.ui.Library)var35);
    boolean var37 = var19.equals((java.lang.Object)var35);
    var19.setUseOutlinePaint(false);
    java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
    var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
    org.jfree.chart.axis.CategoryAnchor var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setDomainGridlinePosition(var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    boolean var17 = var13.getUseOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 2.0d, 1.0d, 2.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     var16.drawBackground(var19, var20);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     java.awt.Font var13 = null;
//     org.jfree.chart.axis.MarkerAxisBand var14 = new org.jfree.chart.axis.MarkerAxisBand(var2, (-1.0d), (-1.0d), 100.0d, 10.0d, var13);
//     org.jfree.chart.plot.IntervalMarker var15 = null;
//     var14.addMarker(var15);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var14.draw(var17, var18, var19, 1.0d, 10.0d);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "", var3, "", "SerialDate.weekInMonthToString(): invalid code.", "");

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var6 = null;
//     org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     var10.addLibrary((org.jfree.chart.ui.Library)var18);
//     boolean var20 = var2.equals((java.lang.Object)var18);
//     var2.setUseOutlinePaint(false);
//     var2.setSeriesLinesVisible(0, (java.lang.Boolean)false);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var33 = null;
//     org.jfree.chart.ui.ProjectInfo var37 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var33, "hi!", "", "hi!");
//     java.awt.Image var41 = null;
//     org.jfree.chart.ui.ProjectInfo var45 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var41, "hi!", "", "hi!");
//     var37.addLibrary((org.jfree.chart.ui.Library)var45);
//     boolean var47 = var29.equals((java.lang.Object)var45);
//     java.awt.Paint var49 = var29.lookupSeriesFillPaint(100);
//     java.awt.Paint var51 = var29.getSeriesOutlinePaint(1);
//     java.lang.Number var53 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var54 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var53);
//     boolean var55 = var29.equals((java.lang.Object)var53);
//     java.lang.Boolean var57 = var29.getSeriesCreateEntities(10);
//     java.awt.Paint var58 = var29.getBaseFillPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var65 = null;
//     org.jfree.chart.ui.ProjectInfo var69 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var65, "hi!", "", "hi!");
//     java.awt.Image var73 = null;
//     org.jfree.chart.ui.ProjectInfo var77 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var73, "hi!", "", "hi!");
//     var69.addLibrary((org.jfree.chart.ui.Library)var77);
//     boolean var79 = var61.equals((java.lang.Object)var77);
//     var61.setUseOutlinePaint(false);
//     java.awt.Stroke var84 = var61.getItemStroke(10, (-1));
//     org.jfree.chart.plot.ValueMarker var85 = new org.jfree.chart.plot.ValueMarker(1.0d, var58, var84);
//     var2.setBaseOutlineStroke(var84);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var2.", var29.equals(var2) == var2.equals(var29));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var61 and var2.", var61.equals(var2) == var2.equals(var61));
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", var3);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.LengthConstraintType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1, var2, 0.0d, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var27 = var26.clone();
    boolean var28 = var26.isTickMarksVisible();
    java.awt.Font var29 = var26.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var36 = null;
    org.jfree.chart.ui.ProjectInfo var40 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var36, "hi!", "", "hi!");
    java.awt.Image var44 = null;
    org.jfree.chart.ui.ProjectInfo var48 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var44, "hi!", "", "hi!");
    var40.addLibrary((org.jfree.chart.ui.Library)var48);
    boolean var50 = var32.equals((java.lang.Object)var48);
    java.awt.Paint var52 = var32.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("", var29, var52, 0.0f);
    java.awt.Font var55 = var54.getFont();
    org.jfree.data.xy.XYDataset var56 = null;
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var59 = var58.clone();
    boolean var60 = var58.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var63 = var62.clone();
    var62.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
    org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var56, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.axis.ValueAxis)var62, var66);
    org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("", var55, (org.jfree.chart.plot.Plot)var67, true);
    org.jfree.chart.event.ChartProgressEvent var72 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var2, var69, 10, 1);
    org.jfree.chart.ChartRenderingInfo var75 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var76 = var69.createBufferedImage(0, (-1), var75);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.xy.XYDataset var1 = null;
//     var0.setDataset(var1);
//     java.awt.Paint var3 = var0.getRangeGridlinePaint();
//     org.jfree.chart.axis.ValueAxis[] var4 = null;
//     var0.setDomainAxes(var4);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
//     org.jfree.chart.LegendItem var3 = var0.getLegendItem((-1), 100);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var12 = var11.clone();
//     boolean var13 = var11.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var20 = var18.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.LegendItemCollection var22 = null;
//     var21.setFixedLegendItems(var22);
//     org.jfree.data.general.DatasetChangeEvent var24 = null;
//     var21.datasetChanged(var24);
//     org.jfree.chart.LegendItemCollection var26 = var21.getLegendItems();
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var28.setTickMarkOutsideLength(10.0f);
//     org.jfree.chart.plot.CategoryMarker var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     var0.drawDomainMarker(var4, var21, var28, var31, var32);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.data.general.DatasetChangeEvent var19 = null;
    var16.datasetChanged(var19);
    var16.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisLocation var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setRangeAxisLocation(0, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.block.BlockContainer var1 = null;
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.Range var3 = null;
//     org.jfree.data.Range var4 = null;
//     org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(var3, var4);
//     org.jfree.chart.util.Size2D var6 = var0.arrange(var1, var2, var5);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 0, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     java.lang.Number[] var0 = null;
//     java.lang.Number[][] var1 = new java.lang.Number[][] { var0};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(0, var1);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var3 = var2.clone();
    boolean var4 = var2.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    var6.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    java.awt.Font var12 = var2.getLabelFont();
    boolean var13 = var2.isVerticalTickLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var3 = var0.getItemOutlinePaint(100, 0);
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-1), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code."};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     java.lang.Number[] var4 = null;
//     java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var5);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.AxisLocation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var25 = var24.clone();
//     boolean var26 = var24.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var27);
//     var16.setRangeAxis(15, (org.jfree.chart.axis.ValueAxis)var24, true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var28
//     assertTrue("Contract failed: equals-hashcode on var10 and var28", var10.equals(var28) ? var10.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var10
//     assertTrue("Contract failed: equals-hashcode on var28 and var10", var28.equals(var10) ? var28.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var3, "hi!", "", "hi!");
    var7.setVersion("hi!");
    java.lang.String var10 = var7.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.annotations.XYAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.AxisLocation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.xy.XYDataset var1 = null;
    var0.setDataset(var1);
    java.awt.Paint var3 = var0.getRangeGridlinePaint();
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(0, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var9 = var8.clone();
//     boolean var10 = var8.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var8, var11);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var17 = var15.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var2, var3, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.LegendItemCollection var19 = null;
//     var18.setFixedLegendItems(var19);
//     org.jfree.data.general.DatasetChangeEvent var21 = null;
//     var18.datasetChanged(var21);
//     var18.setRangeCrosshairVisible(true);
//     var18.clearRangeMarkers();
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var31 = var30.clone();
//     boolean var32 = var30.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var30, var33);
//     java.awt.Font var39 = null;
//     org.jfree.chart.axis.MarkerAxisBand var40 = new org.jfree.chart.axis.MarkerAxisBand(var28, (-1.0d), (-1.0d), 100.0d, 10.0d, var39);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.axis.AxisState var42 = null;
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     java.util.List var45 = var28.refreshTicks(var41, var42, var43, var44);
//     java.awt.geom.Rectangle2D var46 = null;
//     var0.drawRangeGridline(var1, var18, (org.jfree.chart.axis.ValueAxis)var28, var46, 1.0d);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(15, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("({0}, {1}) = {3} - {4}");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var1.getCategoryEnd(0, 0, var4, var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var10 = null;
//     var8.setQuadrantPaint(1, var10);
//     var8.configureDomainAxes();
//     java.awt.Font var13 = var8.getNoDataMessageFont();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     org.jfree.chart.axis.AxisSpace var17 = var1.reserveSpace(var7, (org.jfree.chart.plot.Plot)var8, var14, var15, var16);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 0L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { "({0}, {1}) = {3} - {4}"};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var1 = org.jfree.chart.util.SerialUtilities.readShape(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     org.jfree.chart.LegendItemCollection var21 = var16.getLegendItems();
//     org.jfree.chart.LegendItemCollection var22 = null;
//     var21.addAll(var22);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
    java.awt.Font var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNoDataMessageFont(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    java.awt.Paint var24 = var2.getSeriesOutlinePaint(1);
    java.lang.Number var26 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var26);
    boolean var28 = var2.equals((java.lang.Object)var26);
    java.lang.Boolean var30 = var2.getSeriesCreateEntities(10);
    boolean var31 = var2.getUseOutlinePaint();
    var2.setBaseShapesFilled(false);
    boolean var34 = var2.getUseFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("SerialDate.weekInMonthToString(): invalid code.", var1);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var0, var1);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var1.getCategoryEnd(0, 0, var4, var5);
//     var1.configure();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Object var12 = var11.clone();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var18 = var16.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var20 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var16.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var20);
//     var11.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var20, true);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var26 = null;
//     var24.setQuadrantPaint(1, var26);
//     var24.configureDomainAxes();
//     java.awt.Font var29 = var24.getNoDataMessageFont();
//     java.awt.Paint var30 = var24.getDomainGridlinePaint();
//     var11.setBasePaint(var30);
//     var1.setTickLabelPaint((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", var30);
//     boolean var33 = var1.isTickLabelsVisible();
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var36 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var35};
//     var34.setRenderers(var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     int var39 = var34.indexOf(var38);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var34);
//     
//     // Checks the contract:  equals-hashcode on var24 and var34
//     assertTrue("Contract failed: equals-hashcode on var24 and var34", var24.equals(var34) ? var24.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var24
//     assertTrue("Contract failed: equals-hashcode on var34 and var24", var34.equals(var24) ? var34.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
    java.awt.Font var13 = null;
    org.jfree.chart.axis.MarkerAxisBand var14 = new org.jfree.chart.axis.MarkerAxisBand(var2, (-1.0d), (-1.0d), 100.0d, 10.0d, var13);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.axis.AxisState var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    java.util.List var19 = var2.refreshTicks(var15, var16, var17, var18);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var23 = var22.clone();
    boolean var24 = var22.isTickMarksVisible();
    java.awt.Font var25 = var22.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var32 = null;
    org.jfree.chart.ui.ProjectInfo var36 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var32, "hi!", "", "hi!");
    java.awt.Image var40 = null;
    org.jfree.chart.ui.ProjectInfo var44 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var40, "hi!", "", "hi!");
    var36.addLibrary((org.jfree.chart.ui.Library)var44);
    boolean var46 = var28.equals((java.lang.Object)var44);
    java.awt.Paint var48 = var28.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("", var25, var48, 0.0f);
    var2.setLabelPaint(var48);
    var2.setFixedAutoRange(0.0d);
    var2.setUpperMargin(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
    var2.setTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.plot.PlotOrientation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setOrientation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=0,g=0,b=0]", var1, Double.NEGATIVE_INFINITY, 0.5f, 0.0f);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var1.getCategoryEnd(0, 0, var4, var5);
//     float var7 = var1.getMaximumCategoryLabelWidthRatio();
//     var1.setCategoryLabelPositionOffset(1);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.axis.AxisState var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     java.util.List var14 = var1.refreshTicks(var10, var11, var12, var13);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.chart.text.TextAnchor var2 = null;
//     org.jfree.chart.text.TextAnchor var3 = null;
//     org.jfree.chart.axis.DateTick var5 = new org.jfree.chart.axis.DateTick(var0, "", var2, var3, 100.0d);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    org.jfree.chart.event.ChartChangeEventType var48 = null;
    org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var47, var48);
    int var50 = var47.getBackgroundImageAlignment();
    org.jfree.chart.util.RectangleInsets var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var47.setPadding(var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 15);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}", var1);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
//     double var3 = var2.getBase();
//     org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var4);
//     java.lang.Object var6 = var4.clone();
//     boolean var7 = var2.equals((java.lang.Object)var4);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var16 = var15.clone();
//     boolean var17 = var15.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var18);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var24 = var22.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     org.jfree.chart.LegendItemCollection var26 = null;
//     var25.setFixedLegendItems(var26);
//     org.jfree.data.general.DatasetChangeEvent var28 = null;
//     var25.datasetChanged(var28);
//     org.jfree.chart.LegendItemCollection var30 = var25.getLegendItems();
//     org.jfree.chart.plot.DatasetRenderingOrder var31 = var25.getDatasetRenderingOrder();
//     org.jfree.chart.axis.ValueAxis var33 = var25.getRangeAxisForDataset((-1));
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var40 = var39.clone();
//     boolean var41 = var39.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.axis.ValueAxis)var39, var42);
//     java.awt.Font var48 = null;
//     org.jfree.chart.axis.MarkerAxisBand var49 = new org.jfree.chart.axis.MarkerAxisBand(var37, (-1.0d), (-1.0d), 100.0d, 10.0d, var48);
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.axis.AxisState var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.chart.util.RectangleEdge var53 = null;
//     java.util.List var54 = var37.refreshTicks(var50, var51, var52, var53);
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var58 = var57.clone();
//     boolean var59 = var57.isTickMarksVisible();
//     java.awt.Font var60 = var57.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var63 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var67 = null;
//     org.jfree.chart.ui.ProjectInfo var71 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var67, "hi!", "", "hi!");
//     java.awt.Image var75 = null;
//     org.jfree.chart.ui.ProjectInfo var79 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var75, "hi!", "", "hi!");
//     var71.addLibrary((org.jfree.chart.ui.Library)var79);
//     boolean var81 = var63.equals((java.lang.Object)var79);
//     java.awt.Paint var83 = var63.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var85 = new org.jfree.chart.text.TextFragment("", var60, var83, 0.0f);
//     var37.setLabelPaint(var83);
//     var25.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var37);
//     java.awt.geom.Rectangle2D var88 = null;
//     var2.drawBackground(var8, var25, var88);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    java.text.DateFormat var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(255, 100, 255, 15, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((-1.0d), 100.0d, 10.0d, Double.NEGATIVE_INFINITY);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var8 = null;
    org.jfree.chart.ui.ProjectInfo var12 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var8, "hi!", "", "hi!");
    java.awt.Image var16 = null;
    org.jfree.chart.ui.ProjectInfo var20 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var16, "hi!", "", "hi!");
    var12.addLibrary((org.jfree.chart.ui.Library)var20);
    boolean var22 = var4.equals((java.lang.Object)var20);
    java.awt.Paint var24 = var4.lookupSeriesFillPaint(100);
    java.awt.Paint var26 = var4.getSeriesOutlinePaint(1);
    java.lang.Number var28 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var29 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var28);
    boolean var30 = var4.equals((java.lang.Object)var28);
    java.lang.Boolean var32 = var4.getSeriesCreateEntities(10);
    java.awt.Paint var33 = var4.getBaseFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    boolean var3 = var1.equals((java.lang.Object)100L);
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(100, var1);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var2 = var1.clone();
    boolean var3 = var1.isTickMarksVisible();
    boolean var4 = var1.isTickLabelsVisible();
    var1.setPositiveArrowVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize((-1.0d), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var4 = var2.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var8 = var5.getItemOutlinePaint(100, 0);
    var2.setBasePaint(var8, false);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var16 = var15.clone();
    boolean var17 = var15.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var18);
    java.awt.Font var24 = null;
    org.jfree.chart.axis.MarkerAxisBand var25 = new org.jfree.chart.axis.MarkerAxisBand(var13, (-1.0d), (-1.0d), 100.0d, 10.0d, var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.axis.AxisState var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    java.util.List var30 = var13.refreshTicks(var26, var27, var28, var29);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var34 = var33.clone();
    boolean var35 = var33.isTickMarksVisible();
    java.awt.Font var36 = var33.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var43 = null;
    org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
    java.awt.Image var51 = null;
    org.jfree.chart.ui.ProjectInfo var55 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var51, "hi!", "", "hi!");
    var47.addLibrary((org.jfree.chart.ui.Library)var55);
    boolean var57 = var39.equals((java.lang.Object)var55);
    java.awt.Paint var59 = var39.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var61 = new org.jfree.chart.text.TextFragment("", var36, var59, 0.0f);
    var13.setLabelPaint(var59);
    boolean var63 = var2.equals((java.lang.Object)var59);
    boolean var64 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.urls.CategoryURLGenerator var66 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesURLGenerator((-1), var66);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var1.getCategoryEnd(0, 0, var4, var5);
    float var7 = var1.getMaximumCategoryLabelWidthRatio();
    var1.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var11.setTickMarkOutsideLength(10.0f);
    org.jfree.chart.axis.CategoryLabelPositions var14 = var11.getCategoryLabelPositions();
    var1.setCategoryLabelPositions(var14);
    org.jfree.chart.axis.CategoryLabelPosition var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var17 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var14, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var3.isTickMarksVisible();
//     java.awt.Font var6 = var3.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var13 = null;
//     org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
//     java.awt.Image var21 = null;
//     org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
//     var17.addLibrary((org.jfree.chart.ui.Library)var25);
//     boolean var27 = var9.equals((java.lang.Object)var25);
//     java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
//     java.awt.Font var32 = var31.getFont();
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var36 = var35.clone();
//     boolean var37 = var35.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var40 = var39.clone();
//     var39.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var43);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var44, true);
//     java.awt.Graphics2D var47 = null;
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.data.xy.XYDataset var49 = null;
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var54 = var53.clone();
//     boolean var55 = var53.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var49, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.chart.axis.ValueAxis)var53, var56);
//     java.awt.Font var62 = null;
//     org.jfree.chart.axis.MarkerAxisBand var63 = new org.jfree.chart.axis.MarkerAxisBand(var51, (-1.0d), (-1.0d), 100.0d, 10.0d, var62);
//     java.awt.Graphics2D var64 = null;
//     org.jfree.chart.axis.AxisState var65 = null;
//     java.awt.geom.Rectangle2D var66 = null;
//     org.jfree.chart.util.RectangleEdge var67 = null;
//     java.util.List var68 = var51.refreshTicks(var64, var65, var66, var67);
//     java.util.Collection var69 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var68);
//     var44.drawRangeTickBands(var47, var48, var68);
//     
//     // Checks the contract:  equals-hashcode on var44 and var57
//     assertTrue("Contract failed: equals-hashcode on var44 and var57", var44.equals(var57) ? var44.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var44
//     assertTrue("Contract failed: equals-hashcode on var57 and var44", var57.equals(var44) ? var57.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("java.awt.Color[r=0,g=0,b=0]");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var6 = null;
//     org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     var10.addLibrary((org.jfree.chart.ui.Library)var18);
//     boolean var20 = var2.equals((java.lang.Object)var18);
//     var2.setSeriesShapesVisible(1, false);
//     org.jfree.chart.LegendItem var26 = var2.getLegendItem(0, (-1));
//     int var27 = var2.getPassCount();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var31 = var30.clone();
//     boolean var32 = var30.isTickMarksVisible();
//     java.awt.Font var33 = var30.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var40 = null;
//     org.jfree.chart.ui.ProjectInfo var44 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var40, "hi!", "", "hi!");
//     java.awt.Image var48 = null;
//     org.jfree.chart.ui.ProjectInfo var52 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var48, "hi!", "", "hi!");
//     var44.addLibrary((org.jfree.chart.ui.Library)var52);
//     boolean var54 = var36.equals((java.lang.Object)var52);
//     java.awt.Paint var56 = var36.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var58 = new org.jfree.chart.text.TextFragment("", var33, var56, 0.0f);
//     var2.setBaseFillPaint(var56, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var36 and var2.", var36.equals(var2) == var2.equals(var36));
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)1.0d, "", var2, var3, Double.NEGATIVE_INFINITY);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    boolean var3 = var1.equals((java.lang.Object)100L);
    org.jfree.chart.util.RectangleInsets var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMargin(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var7 = null;
//     org.jfree.chart.ui.ProjectInfo var11 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var7, "hi!", "", "hi!");
//     java.awt.Image var15 = null;
//     org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
//     var11.addLibrary((org.jfree.chart.ui.Library)var19);
//     boolean var21 = var3.equals((java.lang.Object)var19);
//     java.awt.Paint var23 = var3.lookupSeriesFillPaint(100);
//     java.awt.Paint var25 = var3.getSeriesOutlinePaint(1);
//     java.lang.Number var27 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var28 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var27);
//     boolean var29 = var3.equals((java.lang.Object)var27);
//     java.lang.Boolean var31 = var3.getSeriesCreateEntities(10);
//     java.awt.Paint var32 = var3.getBaseFillPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var39 = null;
//     org.jfree.chart.ui.ProjectInfo var43 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var39, "hi!", "", "hi!");
//     java.awt.Image var47 = null;
//     org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
//     var43.addLibrary((org.jfree.chart.ui.Library)var51);
//     boolean var53 = var35.equals((java.lang.Object)var51);
//     var35.setUseOutlinePaint(false);
//     java.awt.Stroke var58 = var35.getItemStroke(10, (-1));
//     org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(1.0d, var32, var58);
//     var59.setLabel("hi!");
//     org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var65 = var64.clone();
//     boolean var66 = var64.isTickMarksVisible();
//     java.awt.Font var67 = var64.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var70 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var74 = null;
//     org.jfree.chart.ui.ProjectInfo var78 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var74, "hi!", "", "hi!");
//     java.awt.Image var82 = null;
//     org.jfree.chart.ui.ProjectInfo var86 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var82, "hi!", "", "hi!");
//     var78.addLibrary((org.jfree.chart.ui.Library)var86);
//     boolean var88 = var70.equals((java.lang.Object)var86);
//     java.awt.Paint var90 = var70.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var92 = new org.jfree.chart.text.TextFragment("", var67, var90, 0.0f);
//     var59.setOutlinePaint(var90);
//     java.awt.Paint var94 = var59.getLabelPaint();
//     java.lang.Class var95 = null;
//     java.util.EventListener[] var96 = var59.getListeners(var95);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var1.getCategoryEnd(0, 0, var4, var5);
    float var7 = var1.getMaximumCategoryLabelWidthRatio();
    var1.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var11.setTickMarkOutsideLength(10.0f);
    org.jfree.chart.axis.CategoryLabelPositions var14 = var11.getCategoryLabelPositions();
    var1.setCategoryLabelPositions(var14);
    org.jfree.chart.axis.CategoryAnchor var16 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var1.getCategoryJava2DCoordinate(var16, 0, 255, var19, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     java.awt.Image var2 = null;
//     var1.setBackgroundImage(var2);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     org.jfree.chart.plot.PlotState var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var1.draw(var4, var5, var6, var7, var8);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var23 = null;
    org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
    java.awt.Image var31 = null;
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
    var27.addLibrary((org.jfree.chart.ui.Library)var35);
    boolean var37 = var19.equals((java.lang.Object)var35);
    var19.setUseOutlinePaint(false);
    java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
    var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
    var16.setAnchorValue(100.0d, true);
    var16.setDomainGridlinesVisible(false);
    java.awt.Stroke var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setDomainGridlineStroke(var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var4 = var2.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var6 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var2.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var6);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Object var12 = var11.clone();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var18 = var16.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var20 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var16.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var20);
//     var11.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var20, true);
//     java.lang.String var24 = var20.getLabelFormat();
//     var2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var20);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var2.", var16.equals(var2) == var2.equals(var16));
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = null;
    var4.setQuadrantPaint(1, var6);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    var4.setBackgroundPaint(var30);
    java.awt.Stroke var32 = var4.getDomainGridlineStroke();
    var2.setBaseStroke(var32, false);
    boolean var35 = var2.getUseFillPaint();
    java.awt.Graphics2D var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.data.xy.XYDataset var40 = null;
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var45 = var44.clone();
    boolean var46 = var44.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var40, (org.jfree.chart.axis.ValueAxis)var42, (org.jfree.chart.axis.ValueAxis)var44, var47);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var53 = var51.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.renderer.category.CategoryItemRenderer)var51);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var61 = null;
    org.jfree.chart.ui.ProjectInfo var65 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var61, "hi!", "", "hi!");
    java.awt.Image var69 = null;
    org.jfree.chart.ui.ProjectInfo var73 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var69, "hi!", "", "hi!");
    var65.addLibrary((org.jfree.chart.ui.Library)var73);
    boolean var75 = var57.equals((java.lang.Object)var73);
    var57.setUseOutlinePaint(false);
    java.awt.Stroke var80 = var57.getItemStroke(10, (-1));
    var54.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var57, false);
    var54.setAnchorValue(100.0d, true);
    var54.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var89 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var90 = var2.initialise(var36, var37, var54, 1, var89);
    org.jfree.chart.util.Layer var92 = null;
    java.util.Collection var93 = var54.getRangeMarkers(10, var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var93);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var2 = null;
//     var0.setQuadrantPaint(1, var2);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var10 = null;
//     org.jfree.chart.ui.ProjectInfo var14 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var10, "hi!", "", "hi!");
//     java.awt.Image var18 = null;
//     org.jfree.chart.ui.ProjectInfo var22 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var18, "hi!", "", "hi!");
//     var14.addLibrary((org.jfree.chart.ui.Library)var22);
//     boolean var24 = var6.equals((java.lang.Object)var22);
//     java.awt.Paint var26 = var6.lookupSeriesFillPaint(100);
//     var0.setBackgroundPaint(var26);
//     java.awt.Stroke var28 = var0.getDomainGridlineStroke();
//     org.jfree.chart.event.RendererChangeEvent var29 = null;
//     var0.rendererChanged(var29);
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var35 = var34.clone();
//     boolean var36 = var34.isTickMarksVisible();
//     java.awt.Font var37 = var34.getTickLabelFont();
//     var34.setInverted(false);
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var42 = null;
//     var40.setQuadrantPaint(1, var42);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var46 = var45.clone();
//     var45.setAutoRange(true);
//     org.jfree.chart.axis.ValueAxis[] var49 = new org.jfree.chart.axis.ValueAxis[] { var45};
//     var40.setRangeAxes(var49);
//     boolean var51 = var34.equals((java.lang.Object)var49);
//     var0.setRangeAxes(var49);
//     
//     // Checks the contract:  equals-hashcode on var0 and var40
//     assertTrue("Contract failed: equals-hashcode on var0 and var40", var0.equals(var40) ? var0.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var0
//     assertTrue("Contract failed: equals-hashcode on var40 and var0", var40.equals(var0) ? var40.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var10 = null;
    org.jfree.chart.ui.ProjectInfo var14 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var10, "hi!", "", "hi!");
    java.awt.Image var18 = null;
    org.jfree.chart.ui.ProjectInfo var22 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var18, "hi!", "", "hi!");
    var14.addLibrary((org.jfree.chart.ui.Library)var22);
    boolean var24 = var6.equals((java.lang.Object)var22);
    java.awt.Paint var26 = var6.lookupSeriesFillPaint(100);
    var0.setBackgroundPaint(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBackgroundImageAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     java.awt.Font var7 = var4.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     java.awt.Image var22 = null;
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
//     var18.addLibrary((org.jfree.chart.ui.Library)var26);
//     boolean var28 = var10.equals((java.lang.Object)var26);
//     java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
//     java.awt.Font var33 = var32.getFont();
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var37 = var36.clone();
//     boolean var38 = var36.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var41 = var40.clone();
//     var40.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
//     java.awt.Font var48 = var45.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var45);
//     org.jfree.chart.util.HorizontalAlignment var50 = null;
//     org.jfree.chart.util.VerticalAlignment var51 = null;
//     org.jfree.chart.block.FlowArrangement var54 = new org.jfree.chart.block.FlowArrangement(var50, var51, (-1.0d), 0.0d);
//     org.jfree.chart.util.HorizontalAlignment var55 = null;
//     org.jfree.chart.util.VerticalAlignment var56 = null;
//     org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 0.0d, 0.05d);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45, (org.jfree.chart.block.Arrangement)var54, (org.jfree.chart.block.Arrangement)var59);
//     org.jfree.chart.block.BlockContainer var61 = null;
//     java.awt.Graphics2D var62 = null;
//     org.jfree.chart.block.RectangleConstraint var65 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
//     org.jfree.chart.util.Size2D var66 = var59.arrange(var61, var62, var65);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var2 = null;
//     var0.setQuadrantPaint(1, var2);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var10 = null;
//     org.jfree.chart.ui.ProjectInfo var14 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var10, "hi!", "", "hi!");
//     java.awt.Image var18 = null;
//     org.jfree.chart.ui.ProjectInfo var22 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var18, "hi!", "", "hi!");
//     var14.addLibrary((org.jfree.chart.ui.Library)var22);
//     boolean var24 = var6.equals((java.lang.Object)var22);
//     java.awt.Paint var26 = var6.lookupSeriesFillPaint(100);
//     var0.setBackgroundPaint(var26);
//     java.awt.Stroke var28 = var0.getDomainGridlineStroke();
//     org.jfree.chart.event.RendererChangeEvent var29 = null;
//     var0.rendererChanged(var29);
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var39 = var38.clone();
//     boolean var40 = var38.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var38, var41);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var47 = var45.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var32, var33, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var45);
//     org.jfree.chart.LegendItemCollection var49 = null;
//     var48.setFixedLegendItems(var49);
//     org.jfree.data.general.DatasetChangeEvent var51 = null;
//     var48.datasetChanged(var51);
//     org.jfree.chart.LegendItemCollection var53 = var48.getLegendItems();
//     org.jfree.data.category.CategoryDataset var55 = var48.getDataset(0);
//     org.jfree.chart.axis.AxisLocation var57 = var48.getRangeAxisLocation(2);
//     var0.setDomainAxisLocation(255, var57);
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var61 = null;
//     var59.setQuadrantPaint(1, var61);
//     var59.configureDomainAxes();
//     java.awt.Font var64 = var59.getNoDataMessageFont();
//     var0.setNoDataMessageFont(var64);
//     
//     // Checks the contract:  equals-hashcode on var59 and var0
//     assertTrue("Contract failed: equals-hashcode on var59 and var0", var59.equals(var0) ? var59.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var59 and var0.", var59.equals(var0) == var0.equals(var59));
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    double var1 = var0.getHeight();
    double var2 = var0.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Paint var3 = var0.getItemOutlinePaint(100, 0);
//     double var5 = var0.getSeriesBarWidth((-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    java.awt.Paint var24 = var2.getSeriesOutlinePaint(1);
    java.lang.Number var26 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var26);
    boolean var28 = var2.equals((java.lang.Object)var26);
    var2.setSeriesVisible(1, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Monday"+ "'", var1.equals("Monday"));

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     var16.handleClick(0, 255, var21);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var3 = var2.clone();
//     boolean var4 = var2.isTickMarksVisible();
//     java.awt.Font var5 = var2.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var12 = null;
//     org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var12, "hi!", "", "hi!");
//     java.awt.Image var20 = null;
//     org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var20, "hi!", "", "hi!");
//     var16.addLibrary((org.jfree.chart.ui.Library)var24);
//     boolean var26 = var8.equals((java.lang.Object)var24);
//     java.awt.Paint var28 = var8.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("", var5, var28, 0.0f);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.text.TextAnchor var32 = null;
//     float var33 = var30.calculateBaselineOffset(var31, var32);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.time.TimePeriod var1 = null;
    org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var4 = var2.getSubtask(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(255, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Monday", "hi!", var3);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var2 = var1.clone();
//     boolean var3 = var1.isTickMarksVisible();
//     java.awt.Font var4 = var1.getTickLabelFont();
//     var1.setInverted(false);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.axis.AxisState var13 = var1.draw(var7, 2.0d, var9, var10, var11, var12);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     org.jfree.chart.LegendItemCollection var21 = var16.getLegendItems();
//     org.jfree.data.category.CategoryDataset var23 = var16.getDataset(0);
//     org.jfree.chart.axis.AxisLocation var25 = var16.getRangeAxisLocation(2);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var33 = var32.clone();
//     boolean var34 = var32.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.axis.ValueAxis)var32, var35);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var41 = var39.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var26, var27, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var49 = null;
//     org.jfree.chart.ui.ProjectInfo var53 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var49, "hi!", "", "hi!");
//     java.awt.Image var57 = null;
//     org.jfree.chart.ui.ProjectInfo var61 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var57, "hi!", "", "hi!");
//     var53.addLibrary((org.jfree.chart.ui.Library)var61);
//     boolean var63 = var45.equals((java.lang.Object)var61);
//     java.awt.Paint var65 = var45.lookupSeriesFillPaint(100);
//     java.awt.Paint var67 = var45.getSeriesOutlinePaint(1);
//     java.lang.Number var69 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var70 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var69);
//     boolean var71 = var45.equals((java.lang.Object)var69);
//     java.lang.Boolean var73 = var45.getSeriesCreateEntities(10);
//     var42.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var45);
//     java.lang.Object var75 = var42.clone();
//     boolean var76 = var25.equals((java.lang.Object)var42);
//     
//     // Checks the contract:  equals-hashcode on var10 and var36
//     assertTrue("Contract failed: equals-hashcode on var10 and var36", var10.equals(var36) ? var10.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var10
//     assertTrue("Contract failed: equals-hashcode on var36 and var10", var36.equals(var10) ? var36.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var42
//     assertTrue("Contract failed: equals-hashcode on var16 and var42", var16.equals(var42) ? var16.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var16
//     assertTrue("Contract failed: equals-hashcode on var42 and var16", var42.equals(var16) ? var42.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
    org.jfree.chart.axis.NumberTickUnit var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTickUnit(var9, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(15, var1);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = null;
    var4.setQuadrantPaint(1, var6);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    var4.setBackgroundPaint(var30);
    java.awt.Stroke var32 = var4.getDomainGridlineStroke();
    var2.setBaseStroke(var32, false);
    var2.setAutoPopulateSeriesOutlinePaint(true);
    java.awt.Paint var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseOutlinePaint(var37, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "SerialDate.weekInMonthToString(): invalid code.", "hi!");
    org.jfree.chart.renderer.category.StackedAreaRenderer var6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var8 = var6.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.category.LayeredBarRenderer var9 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var12 = var9.getItemOutlinePaint(100, 0);
    var6.setBasePaint(var12, false);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var20 = var19.clone();
    boolean var21 = var19.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var19, var22);
    java.awt.Font var28 = null;
    org.jfree.chart.axis.MarkerAxisBand var29 = new org.jfree.chart.axis.MarkerAxisBand(var17, (-1.0d), (-1.0d), 100.0d, 10.0d, var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.axis.AxisState var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.util.RectangleEdge var33 = null;
    java.util.List var34 = var17.refreshTicks(var30, var31, var32, var33);
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var38 = var37.clone();
    boolean var39 = var37.isTickMarksVisible();
    java.awt.Font var40 = var37.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var47 = null;
    org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
    java.awt.Image var55 = null;
    org.jfree.chart.ui.ProjectInfo var59 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var55, "hi!", "", "hi!");
    var51.addLibrary((org.jfree.chart.ui.Library)var59);
    boolean var61 = var43.equals((java.lang.Object)var59);
    java.awt.Paint var63 = var43.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var65 = new org.jfree.chart.text.TextFragment("", var40, var63, 0.0f);
    var17.setLabelPaint(var63);
    boolean var67 = var6.equals((java.lang.Object)var63);
    boolean var68 = var5.equals((java.lang.Object)var6);
    java.lang.String var69 = var5.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "poly"+ "'", var69.equals("poly"));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
//     var0.clear();
//     org.jfree.chart.block.BlockContainer var2 = null;
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
//     org.jfree.chart.block.LengthConstraintType var7 = var6.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var8 = var0.arrange(var2, var3, var6);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var6 = null;
//     org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     var10.addLibrary((org.jfree.chart.ui.Library)var18);
//     boolean var20 = var2.equals((java.lang.Object)var18);
//     java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
//     java.awt.Paint var24 = var2.getSeriesOutlinePaint(1);
//     java.lang.Number var26 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var26);
//     boolean var28 = var2.equals((java.lang.Object)var26);
//     java.lang.Boolean var30 = var2.getSeriesCreateEntities(10);
//     boolean var31 = var2.getUseOutlinePaint();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var38 = var37.clone();
//     boolean var39 = var37.isTickMarksVisible();
//     java.awt.Font var40 = var37.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var47 = null;
//     org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
//     java.awt.Image var55 = null;
//     org.jfree.chart.ui.ProjectInfo var59 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var55, "hi!", "", "hi!");
//     var51.addLibrary((org.jfree.chart.ui.Library)var59);
//     boolean var61 = var43.equals((java.lang.Object)var59);
//     java.awt.Paint var63 = var43.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var65 = new org.jfree.chart.text.TextFragment("", var40, var63, 0.0f);
//     java.awt.Font var66 = var65.getFont();
//     org.jfree.data.xy.XYDataset var67 = null;
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var70 = var69.clone();
//     boolean var71 = var69.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var74 = var73.clone();
//     var73.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var77 = null;
//     org.jfree.chart.plot.XYPlot var78 = new org.jfree.chart.plot.XYPlot(var67, (org.jfree.chart.axis.ValueAxis)var69, (org.jfree.chart.axis.ValueAxis)var73, var77);
//     org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("", var66, (org.jfree.chart.plot.Plot)var78, true);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var81 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
//     java.awt.Stroke var83 = var81.getSeriesOutlineStroke(15);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var84 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Paint var87 = var84.getItemOutlinePaint(100, 0);
//     var81.setBasePaint(var87, false);
//     org.jfree.chart.text.TextLine var90 = new org.jfree.chart.text.TextLine("hi!", var66, var87);
//     var2.setSeriesOutlinePaint(100, var87);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var43 and var2.", var43.equals(var2) == var2.equals(var43));
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var16 = var15.clone();
//     boolean var17 = var15.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var20 = var19.clone();
//     var19.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var19, var23);
//     java.awt.Font var25 = var15.getLabelFont();
//     java.awt.Font var26 = var15.getLabelFont();
//     org.jfree.chart.axis.MarkerAxisBand var27 = new org.jfree.chart.axis.MarkerAxisBand(var4, Double.NEGATIVE_INFINITY, 100.0d, Double.NEGATIVE_INFINITY, 0.0d, var26);
//     
//     // Checks the contract:  equals-hashcode on var8 and var24
//     assertTrue("Contract failed: equals-hashcode on var8 and var24", var8.equals(var24) ? var8.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var8
//     assertTrue("Contract failed: equals-hashcode on var24 and var8", var24.equals(var8) ? var24.hashCode() == var8.hashCode() : true);
// 
//   }

//  public void test168() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SerialDate.weekInMonthToString(): invalid code.", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "First"+ "'", var1.equals("First"));

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    java.lang.String var1 = var0.toString();
    var0.setHeight(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var1.equals("Size2D[width=0.0, height=0.0]"));

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var8 = var7.clone();
    boolean var9 = var7.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.data.general.DatasetChangeEvent var20 = null;
    var17.datasetChanged(var20);
    org.jfree.chart.LegendItemCollection var22 = var17.getLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var23 = var17.getDatasetRenderingOrder();
    org.jfree.chart.axis.ValueAxis var25 = var17.getRangeAxisForDataset((-1));
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var0, var25, var26);
    boolean var28 = var27.isDomainZoomable();
    org.jfree.chart.renderer.PolarItemRenderer var29 = var27.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     org.jfree.data.Range var9 = var4.getRange();
//     org.jfree.data.Range var12 = org.jfree.data.Range.expand(var9, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange(var12);
//     java.util.Date var14 = var13.getLowerDate();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var20 = var19.clone();
//     boolean var21 = var19.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var19, var22);
//     org.jfree.data.Range var24 = var19.getRange();
//     org.jfree.data.Range var27 = org.jfree.data.Range.expand(var24, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var28 = new org.jfree.data.time.DateRange(var27);
//     java.util.Date var29 = var28.getLowerDate();
//     org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange(var14, var29);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer(0);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var13 = var12.clone();
    boolean var14 = var12.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var15);
    org.jfree.chart.axis.TickUnitSource var17 = var10.getStandardTickUnits();
    int var18 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var10);
    var10.setTickMarksVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.renderer.category.WaterfallBarRenderer var0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var2);
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var12 = var11.clone();
    boolean var13 = var11.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var14);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var20 = var18.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.LegendItemCollection var22 = null;
    var21.setFixedLegendItems(var22);
    org.jfree.data.general.DatasetChangeEvent var24 = null;
    var21.datasetChanged(var24);
    var21.setRangeCrosshairVisible(true);
    var21.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.util.RectangleEdge var35 = null;
    double var36 = var31.getCategoryEnd(0, 0, var34, var35);
    org.jfree.chart.event.AxisChangeEvent var37 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var31);
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var40 = var39.clone();
    boolean var41 = var39.isTickMarksVisible();
    java.awt.Font var42 = var39.getTickLabelFont();
    var39.setInverted(false);
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var47 = null;
    var45.setQuadrantPaint(1, var47);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var51 = var50.clone();
    var50.setAutoRange(true);
    org.jfree.chart.axis.ValueAxis[] var54 = new org.jfree.chart.axis.ValueAxis[] { var50};
    var45.setRangeAxes(var54);
    boolean var56 = var39.equals((java.lang.Object)var54);
    org.jfree.data.category.DefaultCategoryDataset var57 = new org.jfree.data.category.DefaultCategoryDataset();
    var57.removeColumn((java.lang.Comparable)0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var3, var4, var21, var31, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.data.category.CategoryDataset)var57, 255, 15, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
//     double var3 = var2.getBase();
//     org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var4);
//     java.lang.Object var6 = var4.clone();
//     boolean var7 = var2.equals((java.lang.Object)var4);
//     var2.setSeriesItemLabelsVisible(2, true);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var19 = var18.clone();
//     boolean var20 = var18.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var18, var21);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var27 = var25.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
//     org.jfree.chart.LegendItemCollection var29 = null;
//     var28.setFixedLegendItems(var29);
//     org.jfree.data.general.DatasetChangeEvent var31 = null;
//     var28.datasetChanged(var31);
//     var28.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.SortOrder var35 = var28.getColumnRenderingOrder();
//     java.awt.geom.Rectangle2D var36 = null;
//     var2.drawDomainGridline(var11, var28, var36, 0.05d);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var11 = null;
//     org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var11, "hi!", "", "hi!");
//     java.awt.Image var19 = null;
//     org.jfree.chart.ui.ProjectInfo var23 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var19, "hi!", "", "hi!");
//     var15.addLibrary((org.jfree.chart.ui.Library)var23);
//     boolean var25 = var7.equals((java.lang.Object)var23);
//     java.awt.Paint var27 = var7.lookupSeriesFillPaint(100);
//     java.awt.Paint var29 = var7.getSeriesOutlinePaint(1);
//     java.lang.Number var31 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var32 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var31);
//     boolean var33 = var7.equals((java.lang.Object)var31);
//     java.lang.Boolean var35 = var7.getSeriesCreateEntities(10);
//     java.awt.Paint var36 = var7.getBaseFillPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var43 = null;
//     org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
//     java.awt.Image var51 = null;
//     org.jfree.chart.ui.ProjectInfo var55 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var51, "hi!", "", "hi!");
//     var47.addLibrary((org.jfree.chart.ui.Library)var55);
//     boolean var57 = var39.equals((java.lang.Object)var55);
//     var39.setUseOutlinePaint(false);
//     java.awt.Stroke var62 = var39.getItemStroke(10, (-1));
//     org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(1.0d, var36, var62);
//     var63.setLabel("hi!");
//     java.awt.Paint var66 = var63.getLabelPaint();
//     org.jfree.chart.text.TextAnchor var67 = var63.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("VerticalAlignment.CENTER", var1, 0.5f, 0.5f, var67, 100.0d, 0.0f, 100.0f);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var1.getCategoryEnd(0, 0, var4, var5);
    org.jfree.chart.event.AxisChangeEvent var7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var1);
    var1.configure();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var10.setTickMarkOutsideLength(10.0f);
    org.jfree.chart.axis.CategoryLabelPositions var13 = var10.getCategoryLabelPositions();
    var1.setCategoryLabelPositions(var13);
    org.jfree.chart.axis.CategoryLabelPosition var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var16 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var13, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var8 = var7.clone();
//     boolean var9 = var7.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     org.jfree.data.general.DatasetChangeEvent var20 = null;
//     var17.datasetChanged(var20);
//     var17.setRangeCrosshairLockedOnData(false);
//     var17.clearRangeMarkers();
//     org.jfree.chart.util.RectangleEdge var26 = var17.getDomainAxisEdge(10);
//     double var27 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var26);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=0,g=0,b=0]", var1, 0.0f, 2.0f, Double.NaN, 1.0f, 100.0f);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.data.general.DatasetChangeEvent var19 = null;
    var16.datasetChanged(var19);
    org.jfree.chart.LegendItemCollection var21 = var16.getLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var22 = var16.getDatasetRenderingOrder();
    org.jfree.chart.axis.ValueAxis var24 = var16.getRangeAxisForDataset((-1));
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var31 = var30.clone();
    boolean var32 = var30.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var30, var33);
    java.awt.Font var39 = null;
    org.jfree.chart.axis.MarkerAxisBand var40 = new org.jfree.chart.axis.MarkerAxisBand(var28, (-1.0d), (-1.0d), 100.0d, 10.0d, var39);
    java.awt.Graphics2D var41 = null;
    org.jfree.chart.axis.AxisState var42 = null;
    java.awt.geom.Rectangle2D var43 = null;
    org.jfree.chart.util.RectangleEdge var44 = null;
    java.util.List var45 = var28.refreshTicks(var41, var42, var43, var44);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var49 = var48.clone();
    boolean var50 = var48.isTickMarksVisible();
    java.awt.Font var51 = var48.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var54 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var58 = null;
    org.jfree.chart.ui.ProjectInfo var62 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var58, "hi!", "", "hi!");
    java.awt.Image var66 = null;
    org.jfree.chart.ui.ProjectInfo var70 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var66, "hi!", "", "hi!");
    var62.addLibrary((org.jfree.chart.ui.Library)var70);
    boolean var72 = var54.equals((java.lang.Object)var70);
    java.awt.Paint var74 = var54.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var76 = new org.jfree.chart.text.TextFragment("", var51, var74, 0.0f);
    var28.setLabelPaint(var74);
    var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var28);
    java.awt.Stroke var79 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var28.setTickMarkStroke(var79);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var4 = var3.clone();
    boolean var5 = var3.isTickMarksVisible();
    java.awt.Font var6 = var3.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
    java.awt.Image var21 = null;
    org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
    var17.addLibrary((org.jfree.chart.ui.Library)var25);
    boolean var27 = var9.equals((java.lang.Object)var25);
    java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
    java.awt.Font var32 = var31.getFont();
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var36 = var35.clone();
    boolean var37 = var35.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var40 = var39.clone();
    var39.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var43);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var44, true);
    java.awt.Paint var47 = var46.getBorderPaint();
    org.jfree.chart.renderer.category.LineRenderer3D var48 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    var46.addSubtitle((org.jfree.chart.title.Title)var49);
    org.jfree.chart.event.ChartChangeListener var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var46.addChangeListener(var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = var0.getObject("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     var19.setUseOutlinePaint(false);
//     java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
//     java.awt.Graphics2D var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     var16.drawBackground(var45, var46);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var3 = var2.clone();
//     boolean var4 = var2.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     var6.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var2.java2DToValue(1.0d, var13, var14);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var25 = var24.clone();
//     boolean var26 = var24.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var27);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var33 = var31.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
//     org.jfree.chart.LegendItemCollection var35 = null;
//     var34.setFixedLegendItems(var35);
//     org.jfree.data.general.DatasetChangeEvent var37 = null;
//     var34.datasetChanged(var37);
//     var34.setRangeCrosshairLockedOnData(false);
//     var34.clearRangeMarkers();
//     org.jfree.chart.util.RectangleEdge var43 = var34.getDomainAxisEdge(10);
//     double var44 = var2.java2DToValue(0.0d, var17, var43);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("java.awt.Color[r=0,g=0,b=0]", var1);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    var2.setRenderAsPercentages(true);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var12 = var11.clone();
    boolean var13 = var11.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var14);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var20 = var18.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.LegendItemCollection var22 = null;
    var21.setFixedLegendItems(var22);
    org.jfree.data.general.DatasetChangeEvent var24 = null;
    var21.datasetChanged(var24);
    org.jfree.chart.LegendItemCollection var26 = var21.getLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var27 = var21.getDatasetRenderingOrder();
    org.jfree.chart.axis.ValueAxis var29 = var21.getRangeAxisForDataset((-1));
    boolean var30 = var2.equals((java.lang.Object)var21);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    java.awt.Image var33 = var32.getBackgroundImage();
    float var34 = var32.getBackgroundAlpha();
    java.awt.Stroke var35 = var32.getDomainZeroBaselineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesStroke((-1), var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var4 = var2.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var8 = var5.getItemOutlinePaint(100, 0);
    var2.setBasePaint(var8, false);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var16 = var15.clone();
    boolean var17 = var15.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var18);
    java.awt.Font var24 = null;
    org.jfree.chart.axis.MarkerAxisBand var25 = new org.jfree.chart.axis.MarkerAxisBand(var13, (-1.0d), (-1.0d), 100.0d, 10.0d, var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.axis.AxisState var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    java.util.List var30 = var13.refreshTicks(var26, var27, var28, var29);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var34 = var33.clone();
    boolean var35 = var33.isTickMarksVisible();
    java.awt.Font var36 = var33.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var43 = null;
    org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
    java.awt.Image var51 = null;
    org.jfree.chart.ui.ProjectInfo var55 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var51, "hi!", "", "hi!");
    var47.addLibrary((org.jfree.chart.ui.Library)var55);
    boolean var57 = var39.equals((java.lang.Object)var55);
    java.awt.Paint var59 = var39.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var61 = new org.jfree.chart.text.TextFragment("", var36, var59, 0.0f);
    var13.setLabelPaint(var59);
    boolean var63 = var2.equals((java.lang.Object)var59);
    boolean var64 = var1.equals((java.lang.Object)var2);
    java.awt.Paint var65 = var1.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var66 = var1.getLegendItemGraphicPadding();
    double var68 = var66.calculateRightInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 2.0d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(100, 100, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    var0.configureDomainAxes();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var0.zoomRangeAxes(Double.POSITIVE_INFINITY, var6, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var10 = var0.getDomainAxisForDataset(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    java.awt.Paint var24 = var2.getSeriesOutlinePaint(1);
    java.lang.Number var26 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var26);
    boolean var28 = var2.equals((java.lang.Object)var26);
    java.lang.Boolean var30 = var2.getSeriesCreateEntities(10);
    boolean var31 = var2.getUseOutlinePaint();
    var2.setBaseShapesFilled(false);
    var2.setDrawOutlines(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    var2.setSeriesShapesVisible(1, false);
    double var24 = var2.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     var16.setAnchorValue(100.0d);
//     int var23 = var16.getDomainAxisCount();
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var30 = var29.clone();
//     boolean var31 = var29.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.axis.ValueAxis)var29, var32);
//     java.awt.Font var38 = null;
//     org.jfree.chart.axis.MarkerAxisBand var39 = new org.jfree.chart.axis.MarkerAxisBand(var27, (-1.0d), (-1.0d), 100.0d, 10.0d, var38);
//     boolean var40 = var27.isPositiveArrowVisible();
//     var16.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var27, true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var33
//     assertTrue("Contract failed: equals-hashcode on var10 and var33", var10.equals(var33) ? var10.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var10
//     assertTrue("Contract failed: equals-hashcode on var33 and var10", var33.equals(var10) ? var33.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     java.awt.Font var13 = null;
//     org.jfree.chart.axis.MarkerAxisBand var14 = new org.jfree.chart.axis.MarkerAxisBand(var2, (-1.0d), (-1.0d), 100.0d, 10.0d, var13);
//     org.jfree.chart.plot.IntervalMarker var15 = null;
//     var14.addMarker(var15);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var14.draw(var17, var18, var19, 0.0d, 0.0d);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     var19.setUseOutlinePaint(false);
//     java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
//     var16.setAnchorValue(100.0d, true);
//     org.jfree.chart.axis.AxisSpace var48 = null;
//     var16.setFixedRangeAxisSpace(var48);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Object var53 = var52.clone();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var59 = var57.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var61 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var57.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var61);
//     var52.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var61, true);
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var67 = null;
//     var65.setQuadrantPaint(1, var67);
//     var65.configureDomainAxes();
//     java.awt.Font var70 = var65.getNoDataMessageFont();
//     java.awt.Paint var71 = var65.getDomainGridlinePaint();
//     var52.setBasePaint(var71);
//     org.jfree.chart.labels.ItemLabelPosition var73 = var52.getBasePositiveItemLabelPosition();
//     int var74 = var16.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var52);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var57.", var13.equals(var57) == var57.equals(var13));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var57.", var19.equals(var57) == var57.equals(var19));
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "SerialDate.weekInMonthToString(): invalid code.", "hi!");
    java.lang.String var6 = var5.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "poly"+ "'", var6.equals("poly"));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var4 = var2.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var8 = var5.getItemOutlinePaint(100, 0);
    var2.setBasePaint(var8, false);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var16 = var15.clone();
    boolean var17 = var15.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var18);
    java.awt.Font var24 = null;
    org.jfree.chart.axis.MarkerAxisBand var25 = new org.jfree.chart.axis.MarkerAxisBand(var13, (-1.0d), (-1.0d), 100.0d, 10.0d, var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.axis.AxisState var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    java.util.List var30 = var13.refreshTicks(var26, var27, var28, var29);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var34 = var33.clone();
    boolean var35 = var33.isTickMarksVisible();
    java.awt.Font var36 = var33.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var43 = null;
    org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
    java.awt.Image var51 = null;
    org.jfree.chart.ui.ProjectInfo var55 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var51, "hi!", "", "hi!");
    var47.addLibrary((org.jfree.chart.ui.Library)var55);
    boolean var57 = var39.equals((java.lang.Object)var55);
    java.awt.Paint var59 = var39.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var61 = new org.jfree.chart.text.TextFragment("", var36, var59, 0.0f);
    var13.setLabelPaint(var59);
    boolean var63 = var2.equals((java.lang.Object)var59);
    boolean var64 = var1.equals((java.lang.Object)var2);
    java.awt.Paint var65 = var1.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var66 = var1.getLegendItemGraphicPadding();
    double var68 = var66.calculateTopOutset(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 2.0d);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.data.time.TimePeriod var1 = null;
//     org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var1);
//     org.jfree.data.time.TimePeriod var4 = null;
//     org.jfree.data.gantt.Task var5 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var4);
//     var2.removeSubtask(var5);
//     
//     // Checks the contract:  equals-hashcode on var2 and var5
//     assertTrue("Contract failed: equals-hashcode on var2 and var5", var2.equals(var5) ? var2.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var2
//     assertTrue("Contract failed: equals-hashcode on var5 and var2", var5.equals(var2) ? var5.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     org.jfree.data.Range var9 = var4.getRange();
//     org.jfree.data.Range var12 = org.jfree.data.Range.expand(var9, 10.0d, 0.0d);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var18 = var17.clone();
//     boolean var19 = var17.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var17, var20);
//     org.jfree.data.Range var22 = var17.getRange();
//     org.jfree.data.Range var25 = org.jfree.data.Range.expand(var22, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange(var25);
//     org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var9, var25);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     var16.setRangeCrosshairLockedOnData(false);
//     var16.clearRangeMarkers();
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     int var27 = var24.indexOf(var26);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var36 = var35.clone();
//     boolean var37 = var35.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.axis.ValueAxis)var35, var38);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var44 = var42.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var29, var30, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var42);
//     org.jfree.chart.LegendItemCollection var46 = null;
//     var45.setFixedLegendItems(var46);
//     org.jfree.data.general.DatasetChangeEvent var48 = null;
//     var45.datasetChanged(var48);
//     org.jfree.chart.LegendItemCollection var50 = var45.getLegendItems();
//     org.jfree.data.category.CategoryDataset var52 = var45.getDataset(0);
//     org.jfree.chart.axis.AxisLocation var54 = var45.getRangeAxisLocation(2);
//     var24.setRangeAxisLocation(2, var54);
//     org.jfree.chart.axis.AxisLocation var56 = var54.getOpposite();
//     var16.setDomainAxisLocation(var56, false);
//     
//     // Checks the contract:  equals-hashcode on var10 and var39
//     assertTrue("Contract failed: equals-hashcode on var10 and var39", var10.equals(var39) ? var10.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var10
//     assertTrue("Contract failed: equals-hashcode on var39 and var10", var39.equals(var10) ? var39.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
//     var2.setRenderAsPercentages(true);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var12 = var11.clone();
//     boolean var13 = var11.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var20 = var18.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.LegendItemCollection var22 = null;
//     var21.setFixedLegendItems(var22);
//     org.jfree.data.general.DatasetChangeEvent var24 = null;
//     var21.datasetChanged(var24);
//     org.jfree.chart.LegendItemCollection var26 = var21.getLegendItems();
//     org.jfree.chart.plot.DatasetRenderingOrder var27 = var21.getDatasetRenderingOrder();
//     org.jfree.chart.axis.ValueAxis var29 = var21.getRangeAxisForDataset((-1));
//     boolean var30 = var2.equals((java.lang.Object)var21);
//     org.jfree.chart.axis.CategoryAxis[] var31 = null;
//     var21.setDomainAxes(var31);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    var2.setBaseCreateEntities(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.CategoryAnchor var1 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var0.getCategoryJava2DCoordinate(var1, 255, 10, var4, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     java.awt.Paint var39 = var19.lookupSeriesFillPaint(100);
//     java.awt.Paint var41 = var19.getSeriesOutlinePaint(1);
//     java.lang.Number var43 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var44 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var43);
//     boolean var45 = var19.equals((java.lang.Object)var43);
//     java.lang.Boolean var47 = var19.getSeriesCreateEntities(10);
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
//     java.lang.Object var49 = var16.clone();
//     org.jfree.chart.axis.CategoryAnchor var50 = var16.getDomainGridlinePosition();
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var56 = var55.clone();
//     boolean var57 = var55.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var51, (org.jfree.chart.axis.ValueAxis)var53, (org.jfree.chart.axis.ValueAxis)var55, var58);
//     org.jfree.data.Range var60 = var55.getRange();
//     boolean var61 = var50.equals((java.lang.Object)var60);
//     
//     // Checks the contract:  equals-hashcode on var10 and var59
//     assertTrue("Contract failed: equals-hashcode on var10 and var59", var10.equals(var59) ? var10.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var10
//     assertTrue("Contract failed: equals-hashcode on var59 and var10", var59.equals(var10) ? var59.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     org.jfree.chart.LegendItemCollection var21 = var16.getLegendItems();
//     org.jfree.data.category.CategoryDataset var23 = var16.getDataset(0);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     var16.setRangeAxis(var24);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var34 = var33.clone();
//     boolean var35 = var33.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var29, (org.jfree.chart.axis.ValueAxis)var31, (org.jfree.chart.axis.ValueAxis)var33, var36);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var42 = var40.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40);
//     var16.setRenderer(255, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40, true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    var2.setRenderAsPercentages(true);
    var2.setSeriesCreateEntities(15, (java.lang.Boolean)false);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(10, var1);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    java.lang.String var3 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var3.equals("Size2D[width=0.0, height=0.0]"));

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    java.awt.Color var1 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    java.text.DateFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(10, 100, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setTickMarkOutsideLength(10.0f);
//     org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var16 = var15.clone();
//     boolean var17 = var15.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var18);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var24 = var22.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     org.jfree.chart.LegendItemCollection var26 = null;
//     var25.setFixedLegendItems(var26);
//     org.jfree.data.general.DatasetChangeEvent var28 = null;
//     var25.datasetChanged(var28);
//     var25.setRangeCrosshairLockedOnData(false);
//     var25.clearRangeMarkers();
//     org.jfree.chart.util.RectangleEdge var34 = var25.getDomainAxisEdge(10);
//     org.jfree.chart.util.RectangleEdge var35 = org.jfree.chart.util.RectangleEdge.opposite(var34);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.chart.axis.AxisState var37 = var1.draw(var5, 2.0d, var7, var8, var34, var36);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Paint var3 = var0.getItemOutlinePaint(100, 0);
//     org.jfree.chart.util.HorizontalAlignment var4 = null;
//     org.jfree.chart.util.VerticalAlignment var5 = null;
//     org.jfree.chart.block.FlowArrangement var8 = new org.jfree.chart.block.FlowArrangement(var4, var5, 0.0d, 0.05d);
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.FlowArrangement var13 = new org.jfree.chart.block.FlowArrangement(var9, var10, 0.0d, 0.05d);
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     
//     // Checks the contract:  equals-hashcode on var8 and var13
//     assertTrue("Contract failed: equals-hashcode on var8 and var13", var8.equals(var13) ? var8.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var8
//     assertTrue("Contract failed: equals-hashcode on var13 and var8", var13.equals(var8) ? var13.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var3.isTickMarksVisible();
//     java.awt.Font var6 = var3.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var13 = null;
//     org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
//     java.awt.Image var21 = null;
//     org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
//     var17.addLibrary((org.jfree.chart.ui.Library)var25);
//     boolean var27 = var9.equals((java.lang.Object)var25);
//     java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
//     java.awt.Font var32 = var31.getFont();
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var36 = var35.clone();
//     boolean var37 = var35.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var40 = var39.clone();
//     var39.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var43);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var44, true);
//     java.awt.Paint var47 = var46.getBorderPaint();
//     int var48 = var46.getSubtitleCount();
//     java.awt.Graphics2D var49 = null;
//     java.awt.geom.Rectangle2D var50 = null;
//     var46.draw(var49, var50);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var2 = var0.getTimeFromLong(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var5 = var0.containsDomainRange(100L, 0L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var1 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
//     var1.setBaseShape(var4);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var4, (-1.0d), 1.0f, 0.5f);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer(0);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = var0.getRenderer();
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var16 = var15.clone();
    boolean var17 = var15.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var18);
    java.awt.Font var24 = null;
    org.jfree.chart.axis.MarkerAxisBand var25 = new org.jfree.chart.axis.MarkerAxisBand(var13, (-1.0d), (-1.0d), 100.0d, 10.0d, var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.axis.AxisState var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    java.util.List var30 = var13.refreshTicks(var26, var27, var28, var29);
    java.util.Collection var31 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var30);
    var0.drawDomainTickBands(var9, var10, var30);
    org.jfree.chart.axis.AxisLocation var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var33, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var10 = null;
    org.jfree.chart.ui.ProjectInfo var14 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var10, "hi!", "", "hi!");
    java.awt.Image var18 = null;
    org.jfree.chart.ui.ProjectInfo var22 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var18, "hi!", "", "hi!");
    var14.addLibrary((org.jfree.chart.ui.Library)var22);
    boolean var24 = var6.equals((java.lang.Object)var22);
    java.awt.Paint var26 = var6.lookupSeriesFillPaint(100);
    java.awt.Paint var28 = var6.getSeriesOutlinePaint(1);
    java.lang.Number var30 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var31 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var30);
    boolean var32 = var6.equals((java.lang.Object)var30);
    java.lang.Boolean var34 = var6.getSeriesCreateEntities(10);
    java.awt.Paint var35 = var6.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var42 = null;
    org.jfree.chart.ui.ProjectInfo var46 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var42, "hi!", "", "hi!");
    java.awt.Image var50 = null;
    org.jfree.chart.ui.ProjectInfo var54 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var50, "hi!", "", "hi!");
    var46.addLibrary((org.jfree.chart.ui.Library)var54);
    boolean var56 = var38.equals((java.lang.Object)var54);
    var38.setUseOutlinePaint(false);
    java.awt.Stroke var61 = var38.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var62 = new org.jfree.chart.plot.ValueMarker(1.0d, var35, var61);
    var62.setLabel("hi!");
    org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var68 = var67.clone();
    boolean var69 = var67.isTickMarksVisible();
    java.awt.Font var70 = var67.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var73 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var77 = null;
    org.jfree.chart.ui.ProjectInfo var81 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var77, "hi!", "", "hi!");
    java.awt.Image var85 = null;
    org.jfree.chart.ui.ProjectInfo var89 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var85, "hi!", "", "hi!");
    var81.addLibrary((org.jfree.chart.ui.Library)var89);
    boolean var91 = var73.equals((java.lang.Object)var89);
    java.awt.Paint var93 = var73.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var95 = new org.jfree.chart.text.TextFragment("", var70, var93, 0.0f);
    var62.setOutlinePaint(var93);
    java.awt.Paint var97 = var62.getLabelPaint();
    org.jfree.chart.util.RectangleAnchor var98 = var62.getLabelAnchor();
    java.awt.geom.Rectangle2D var99 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 1.0d, 0.0d, var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var1 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)Double.NaN);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var2 = null;
//     var0.setQuadrantPaint(1, var2);
//     var0.configureDomainAxes();
//     java.awt.Font var5 = var0.getNoDataMessageFont();
//     org.jfree.chart.axis.AxisSpace var6 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Image var8 = var7.getBackgroundImage();
//     org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
//     var0.setDrawingSupplier(var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.data.time.TimePeriod var1 = null;
    org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var1);
    java.lang.String var3 = var2.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var5 = var2.getSubtask(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var3.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var3, "hi!", "", "hi!");
    java.awt.Image var11 = null;
    org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var11, "hi!", "", "hi!");
    var7.addLibrary((org.jfree.chart.ui.Library)var15);
    java.lang.String var17 = var15.getLicenceText();
    java.lang.String var18 = var15.getVersion();
    var15.setName("java.awt.Color[r=0,g=0,b=0]");
    var15.setCopyright("First");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "hi!"+ "'", var17.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "hi!"+ "'", var18.equals("hi!"));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)100.0f);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Image var1 = var0.getBackgroundImage();
    java.lang.String var2 = var0.getNoDataMessage();
    int var3 = var0.getWeight();
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    var0.setRangeGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    java.awt.Font var48 = var45.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var45);
    java.lang.Object var50 = var49.clone();
    var49.setBorderVisible(false);
    java.lang.Object var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var49.setTextAntiAlias(var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var3 = null;
    var1.setQuadrantPaint(1, var3);
    boolean var5 = var1.isRangeCrosshairLockedOnData();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
    java.awt.Image var21 = null;
    org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
    var17.addLibrary((org.jfree.chart.ui.Library)var25);
    boolean var27 = var9.equals((java.lang.Object)var25);
    java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
    java.awt.Paint var31 = var9.getSeriesOutlinePaint(1);
    java.lang.Number var33 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var34 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var33);
    boolean var35 = var9.equals((java.lang.Object)var33);
    java.lang.Boolean var37 = var9.getSeriesCreateEntities(10);
    java.awt.Paint var38 = var9.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var45 = null;
    org.jfree.chart.ui.ProjectInfo var49 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var45, "hi!", "", "hi!");
    java.awt.Image var53 = null;
    org.jfree.chart.ui.ProjectInfo var57 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var53, "hi!", "", "hi!");
    var49.addLibrary((org.jfree.chart.ui.Library)var57);
    boolean var59 = var41.equals((java.lang.Object)var57);
    var41.setUseOutlinePaint(false);
    java.awt.Stroke var64 = var41.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(1.0d, var38, var64);
    var1.addDomainMarker((org.jfree.chart.plot.Marker)var65);
    boolean var67 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.util.RectangleInsets var68 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelInsets(var68);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var8 = var7.clone();
    boolean var9 = var7.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.data.general.DatasetChangeEvent var20 = null;
    var17.datasetChanged(var20);
    org.jfree.chart.LegendItemCollection var22 = var17.getLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var23 = var17.getDatasetRenderingOrder();
    org.jfree.chart.axis.ValueAxis var25 = var17.getRangeAxisForDataset((-1));
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var0, var25, var26);
    var27.setAngleLabelsVisible(false);
    boolean var30 = var27.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getColumnKey(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var0.setDomainCrosshairValue(1.0d, false);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "SerialDate.weekInMonthToString(): invalid code.", "hi!");
    org.jfree.chart.renderer.category.StackedAreaRenderer var6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var8 = var6.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.category.LayeredBarRenderer var9 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var12 = var9.getItemOutlinePaint(100, 0);
    var6.setBasePaint(var12, false);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var20 = var19.clone();
    boolean var21 = var19.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var19, var22);
    java.awt.Font var28 = null;
    org.jfree.chart.axis.MarkerAxisBand var29 = new org.jfree.chart.axis.MarkerAxisBand(var17, (-1.0d), (-1.0d), 100.0d, 10.0d, var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.axis.AxisState var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.util.RectangleEdge var33 = null;
    java.util.List var34 = var17.refreshTicks(var30, var31, var32, var33);
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var38 = var37.clone();
    boolean var39 = var37.isTickMarksVisible();
    java.awt.Font var40 = var37.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var47 = null;
    org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
    java.awt.Image var55 = null;
    org.jfree.chart.ui.ProjectInfo var59 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var55, "hi!", "", "hi!");
    var51.addLibrary((org.jfree.chart.ui.Library)var59);
    boolean var61 = var43.equals((java.lang.Object)var59);
    java.awt.Paint var63 = var43.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var65 = new org.jfree.chart.text.TextFragment("", var40, var63, 0.0f);
    var17.setLabelPaint(var63);
    boolean var67 = var6.equals((java.lang.Object)var63);
    boolean var68 = var5.equals((java.lang.Object)var6);
    java.lang.String var69 = var5.getShapeCoords();
    java.lang.Object var70 = var5.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "-10,-10,-10,-10,0,0,10,-10,10,-10,0,0,10,10,10,10,0,0,-10,10,-10,10,0,0,0,0"+ "'", var69.equals("-10,-10,-10,-10,0,0,10,-10,10,-10,0,0,10,10,10,10,0,0,-10,10,-10,10,0,0,0,0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     org.jfree.chart.LegendItemCollection var21 = var16.getLegendItems();
//     org.jfree.data.category.CategoryDataset var23 = var16.getDataset(0);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     var16.setRangeAxis(var24);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     var16.handleClick(96, 96, var28);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var3 = var2.clone();
//     boolean var4 = var2.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     var6.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.entity.EntityCollection var13 = null;
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo(var13);
//     org.jfree.chart.entity.EntityCollection var15 = var14.getEntityCollection();
//     java.awt.geom.Rectangle2D var16 = var14.getChartArea();
//     var11.drawOutline(var12, var16);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var7 = null;
    org.jfree.chart.ui.ProjectInfo var11 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var7, "hi!", "", "hi!");
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
    var11.addLibrary((org.jfree.chart.ui.Library)var19);
    boolean var21 = var3.equals((java.lang.Object)var19);
    java.awt.Paint var23 = var3.lookupSeriesFillPaint(100);
    java.awt.Paint var25 = var3.getSeriesOutlinePaint(1);
    java.lang.Number var27 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var28 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var27);
    boolean var29 = var3.equals((java.lang.Object)var27);
    java.lang.Boolean var31 = var3.getSeriesCreateEntities(10);
    java.awt.Paint var32 = var3.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var39 = null;
    org.jfree.chart.ui.ProjectInfo var43 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var39, "hi!", "", "hi!");
    java.awt.Image var47 = null;
    org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
    var43.addLibrary((org.jfree.chart.ui.Library)var51);
    boolean var53 = var35.equals((java.lang.Object)var51);
    var35.setUseOutlinePaint(false);
    java.awt.Stroke var58 = var35.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(1.0d, var32, var58);
    java.awt.Color var61 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    var59.setPaint((java.awt.Paint)var61);
    float[] var65 = new float[] { 10.0f, 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var66 = var61.getRGBColorComponents(var65);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Set var1 = var0.keySet();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.getString("Range[0.0,1.05]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var1 = var0.getCompletePaint();
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var9 = var8.clone();
//     boolean var10 = var8.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var8, var11);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var17 = var15.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var2, var3, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.LegendItemCollection var19 = null;
//     var18.setFixedLegendItems(var19);
//     org.jfree.data.general.DatasetChangeEvent var21 = null;
//     var18.datasetChanged(var21);
//     var18.setRangeCrosshairVisible(true);
//     var18.clearRangeMarkers();
//     var0.setPlot(var18);
//     boolean var27 = var18.isRangeCrosshairVisible();
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var29.getCategoryEnd(0, 0, var32, var33);
//     var29.configure();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Object var40 = var39.clone();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var44 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var46 = var44.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var48 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var44.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var48);
//     var39.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var48, true);
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var54 = null;
//     var52.setQuadrantPaint(1, var54);
//     var52.configureDomainAxes();
//     java.awt.Font var57 = var52.getNoDataMessageFont();
//     java.awt.Paint var58 = var52.getDomainGridlinePaint();
//     var39.setBasePaint(var58);
//     var29.setTickLabelPaint((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", var58);
//     var18.setRangeGridlinePaint(var58);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var44.", var15.equals(var44) == var44.equals(var15));
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     java.awt.Paint var39 = var19.lookupSeriesFillPaint(100);
//     java.awt.Paint var41 = var19.getSeriesOutlinePaint(1);
//     java.lang.Number var43 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var44 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var43);
//     boolean var45 = var19.equals((java.lang.Object)var43);
//     java.lang.Boolean var47 = var19.getSeriesCreateEntities(10);
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
//     java.lang.Object var49 = var16.clone();
//     org.jfree.chart.axis.CategoryAnchor var50 = var16.getDomainGridlinePosition();
//     java.awt.Stroke var51 = var16.getRangeCrosshairStroke();
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var55 = var54.clone();
//     boolean var56 = var54.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var59 = var58.clone();
//     var58.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var62 = null;
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.axis.ValueAxis)var58, var62);
//     java.awt.Font var64 = var54.getLabelFont();
//     org.jfree.chart.axis.ValueAxis[] var65 = new org.jfree.chart.axis.ValueAxis[] { var54};
//     var16.setRangeAxes(var65);
//     
//     // Checks the contract:  equals-hashcode on var10 and var63
//     assertTrue("Contract failed: equals-hashcode on var10 and var63", var10.equals(var63) ? var10.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var10
//     assertTrue("Contract failed: equals-hashcode on var63 and var10", var63.equals(var10) ? var63.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    double var2 = var1.getSeriesRunningTotal();
    double var3 = var1.getBarWidth();
    var1.setBarWidth(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var6 = var5.clone();
//     boolean var7 = var5.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var5, var8);
//     java.awt.Font var14 = null;
//     org.jfree.chart.axis.MarkerAxisBand var15 = new org.jfree.chart.axis.MarkerAxisBand(var3, (-1.0d), (-1.0d), 100.0d, 10.0d, var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.AxisState var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     java.util.List var20 = var3.refreshTicks(var16, var17, var18, var19);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var24 = var23.clone();
//     boolean var25 = var23.isTickMarksVisible();
//     java.awt.Font var26 = var23.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var33 = null;
//     org.jfree.chart.ui.ProjectInfo var37 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var33, "hi!", "", "hi!");
//     java.awt.Image var41 = null;
//     org.jfree.chart.ui.ProjectInfo var45 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var41, "hi!", "", "hi!");
//     var37.addLibrary((org.jfree.chart.ui.Library)var45);
//     boolean var47 = var29.equals((java.lang.Object)var45);
//     java.awt.Paint var49 = var29.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("", var26, var49, 0.0f);
//     var3.setLabelPaint(var49);
//     boolean var53 = var0.equals((java.lang.Object)var3);
//     var0.clear();
//     var0.clear();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var58 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var60 = var58.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var62 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var58.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var62);
//     var58.setBaseSeriesVisible(true);
//     boolean var66 = var0.equals((java.lang.Object)var58);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var58.", var29.equals(var58) == var58.equals(var29));
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var6 = null;
//     org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     var10.addLibrary((org.jfree.chart.ui.Library)var18);
//     boolean var20 = var2.equals((java.lang.Object)var18);
//     var2.setSeriesShapesVisible(1, false);
//     org.jfree.chart.LegendItem var26 = var2.getLegendItem(0, (-1));
//     int var27 = var2.getPassCount();
//     boolean var28 = var2.getBaseSeriesVisibleInLegend();
//     java.awt.Stroke var30 = var2.lookupSeriesStroke((-1));
//     java.awt.Graphics2D var31 = null;
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var39 = var38.clone();
//     boolean var40 = var38.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var38, var41);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var47 = var45.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var32, var33, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var45);
//     org.jfree.chart.LegendItemCollection var49 = null;
//     var48.setFixedLegendItems(var49);
//     org.jfree.data.general.DatasetChangeEvent var51 = null;
//     var48.datasetChanged(var51);
//     var48.setRangeCrosshairVisible(true);
//     var48.clearRangeMarkers();
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var59 = var58.clone();
//     boolean var60 = var58.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var63 = var62.clone();
//     var62.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var56, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.axis.ValueAxis)var62, var66);
//     org.jfree.chart.event.AxisChangeEvent var68 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var62);
//     java.awt.Stroke var69 = var62.getAxisLineStroke();
//     org.jfree.chart.entity.EntityCollection var70 = null;
//     org.jfree.chart.ChartRenderingInfo var71 = new org.jfree.chart.ChartRenderingInfo(var70);
//     org.jfree.chart.entity.EntityCollection var72 = var71.getEntityCollection();
//     java.awt.geom.Rectangle2D var73 = var71.getChartArea();
//     var2.drawRangeGridline(var31, var48, (org.jfree.chart.axis.ValueAxis)var62, var73, 1.0d);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var27 = var26.clone();
    boolean var28 = var26.isTickMarksVisible();
    java.awt.Font var29 = var26.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var36 = null;
    org.jfree.chart.ui.ProjectInfo var40 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var36, "hi!", "", "hi!");
    java.awt.Image var44 = null;
    org.jfree.chart.ui.ProjectInfo var48 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var44, "hi!", "", "hi!");
    var40.addLibrary((org.jfree.chart.ui.Library)var48);
    boolean var50 = var32.equals((java.lang.Object)var48);
    java.awt.Paint var52 = var32.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("", var29, var52, 0.0f);
    java.awt.Font var55 = var54.getFont();
    org.jfree.data.xy.XYDataset var56 = null;
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var59 = var58.clone();
    boolean var60 = var58.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var63 = var62.clone();
    var62.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
    org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var56, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.axis.ValueAxis)var62, var66);
    org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("", var55, (org.jfree.chart.plot.Plot)var67, true);
    org.jfree.chart.event.ChartProgressEvent var72 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var2, var69, 10, 1);
    java.lang.Object var73 = var69.clone();
    org.jfree.chart.block.BlockBorder var78 = new org.jfree.chart.block.BlockBorder(Double.POSITIVE_INFINITY, 0.0d, Double.POSITIVE_INFINITY, 100.0d);
    org.jfree.chart.util.RectangleInsets var79 = var78.getInsets();
    double var81 = var79.calculateBottomOutset(0.2d);
    var69.setPadding(var79);
    org.jfree.chart.entity.EntityCollection var86 = null;
    org.jfree.chart.ChartRenderingInfo var87 = new org.jfree.chart.ChartRenderingInfo(var86);
    org.jfree.chart.entity.EntityCollection var88 = var87.getEntityCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var89 = var69.createBufferedImage(0, 255, 1969, var87);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var2 = null;
//     var0.setQuadrantPaint(1, var2);
//     boolean var4 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer(0);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var13 = var12.clone();
//     boolean var14 = var12.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var15);
//     org.jfree.chart.axis.TickUnitSource var17 = var10.getStandardTickUnits();
//     int var18 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var10);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var24 = var23.clone();
//     boolean var25 = var23.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var28 = var27.clone();
//     var27.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var27, var31);
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var23.java2DToValue(1.0d, var34, var35);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.axis.AxisState var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     java.util.List var41 = var23.refreshTicks(var37, var38, var39, var40);
//     var0.drawRangeTickBands(var19, var20, var41);
//     
//     // Checks the contract:  equals-hashcode on var16 and var32
//     assertTrue("Contract failed: equals-hashcode on var16 and var32", var16.equals(var32) ? var16.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var16
//     assertTrue("Contract failed: equals-hashcode on var32 and var16", var32.equals(var16) ? var32.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    java.awt.Paint var48 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var49 = org.jfree.chart.text.TextUtilities.createTextBlock("-10,-10,-10,-10,0,0,10,-10,10,-10,0,0,10,10,10,10,0,0,-10,10,-10,10,0,0,0,0", var33, var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setNegativeItemLabelPositionFallback(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.entity.EntityCollection var4 = null;
    org.jfree.chart.ChartRenderingInfo var5 = new org.jfree.chart.ChartRenderingInfo(var4);
    org.jfree.chart.entity.EntityCollection var6 = var5.getEntityCollection();
    java.awt.geom.Rectangle2D var7 = var5.getChartArea();
    org.jfree.chart.plot.CategoryPlot var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var11 = var0.initialise(var3, var7, var8, 0, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.data.time.TimePeriod var1 = null;
//     org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var1);
//     org.jfree.data.time.TimePeriod var3 = var2.getDuration();
//     org.jfree.data.time.TimePeriod var5 = null;
//     org.jfree.data.gantt.Task var6 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var12 = var11.clone();
//     boolean var13 = var11.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     org.jfree.data.Range var16 = var11.getRange();
//     org.jfree.data.Range var19 = org.jfree.data.Range.expand(var16, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange(var19);
//     java.util.Date var21 = var20.getLowerDate();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(var21);
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var21);
//     var6.setDuration((org.jfree.data.time.TimePeriod)var23);
//     var2.setDuration((org.jfree.data.time.TimePeriod)var23);
//     
//     // Checks the contract:  equals-hashcode on var2 and var6
//     assertTrue("Contract failed: equals-hashcode on var2 and var6", var2.equals(var6) ? var2.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var2
//     assertTrue("Contract failed: equals-hashcode on var6 and var2", var6.equals(var2) ? var6.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(0, 15, 100, 15, var4);
//     int var6 = var5.getRollUnit();
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var12 = var11.clone();
//     boolean var13 = var11.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     org.jfree.data.Range var16 = var11.getRange();
//     org.jfree.data.Range var19 = org.jfree.data.Range.expand(var16, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange(var19);
//     java.util.Date var21 = var20.getLowerDate();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(var21);
//     java.util.TimeZone var23 = null;
//     java.util.Date var24 = var5.rollDate(var21, var23);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setAutoPopulateSeriesStroke(true);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "poly", "");

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Image var1 = var0.getBackgroundImage();
    java.lang.String var2 = var0.getNoDataMessage();
    int var3 = var0.getWeight();
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    var0.setRenderer(15, var5, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var7 = null;
    org.jfree.chart.ui.ProjectInfo var11 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var7, "hi!", "", "hi!");
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
    var11.addLibrary((org.jfree.chart.ui.Library)var19);
    boolean var21 = var3.equals((java.lang.Object)var19);
    java.awt.Paint var23 = var3.lookupSeriesFillPaint(100);
    java.awt.Paint var25 = var3.getSeriesOutlinePaint(1);
    java.lang.Number var27 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var28 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var27);
    boolean var29 = var3.equals((java.lang.Object)var27);
    java.lang.Boolean var31 = var3.getSeriesCreateEntities(10);
    java.awt.Paint var32 = var3.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var39 = null;
    org.jfree.chart.ui.ProjectInfo var43 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var39, "hi!", "", "hi!");
    java.awt.Image var47 = null;
    org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
    var43.addLibrary((org.jfree.chart.ui.Library)var51);
    boolean var53 = var35.equals((java.lang.Object)var51);
    var35.setUseOutlinePaint(false);
    java.awt.Stroke var58 = var35.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(1.0d, var32, var58);
    var59.setLabel("hi!");
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var65 = var64.clone();
    boolean var66 = var64.isTickMarksVisible();
    java.awt.Font var67 = var64.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var70 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var74 = null;
    org.jfree.chart.ui.ProjectInfo var78 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var74, "hi!", "", "hi!");
    java.awt.Image var82 = null;
    org.jfree.chart.ui.ProjectInfo var86 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var82, "hi!", "", "hi!");
    var78.addLibrary((org.jfree.chart.ui.Library)var86);
    boolean var88 = var70.equals((java.lang.Object)var86);
    java.awt.Paint var90 = var70.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var92 = new org.jfree.chart.text.TextFragment("", var67, var90, 0.0f);
    var59.setOutlinePaint(var90);
    org.jfree.chart.util.LengthAdjustmentType var94 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var59.setLabelOffsetType(var94);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == true);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var8 = var7.clone();
//     boolean var9 = var7.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     org.jfree.data.general.DatasetChangeEvent var20 = null;
//     var17.datasetChanged(var20);
//     org.jfree.chart.LegendItemCollection var22 = var17.getLegendItems();
//     org.jfree.chart.plot.DatasetRenderingOrder var23 = var17.getDatasetRenderingOrder();
//     org.jfree.chart.axis.ValueAxis var25 = var17.getRangeAxisForDataset((-1));
//     org.jfree.chart.renderer.PolarItemRenderer var26 = null;
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var0, var25, var26);
//     org.jfree.chart.plot.WaferMapPlot var28 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var35 = null;
//     org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var35, "hi!", "", "hi!");
//     java.awt.Image var43 = null;
//     org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
//     var39.addLibrary((org.jfree.chart.ui.Library)var47);
//     boolean var49 = var31.equals((java.lang.Object)var47);
//     var31.setUseOutlinePaint(false);
//     java.awt.Stroke var54 = var31.getItemStroke(10, (-1));
//     var28.setOutlineStroke(var54);
//     var27.setAngleGridlineStroke(var54);
//     var27.addCornerTextItem("");
//     var27.removeCornerTextItem("Monday");
//     boolean var61 = var27.isAngleLabelsVisible();
//     org.jfree.chart.LegendItemCollection var62 = var27.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var22 and var62
//     assertTrue("Contract failed: equals-hashcode on var22 and var62", var22.equals(var62) ? var22.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var22
//     assertTrue("Contract failed: equals-hashcode on var62 and var22", var62.equals(var22) ? var62.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     var2.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.entity.EntityCollection var12 = null;
//     org.jfree.chart.ChartRenderingInfo var13 = new org.jfree.chart.ChartRenderingInfo(var12);
//     org.jfree.chart.entity.EntityCollection var14 = var13.getEntityCollection();
//     java.awt.geom.Rectangle2D var15 = var13.getChartArea();
//     org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var15, "VerticalAlignment.CENTER", "Category Plot");
//     org.jfree.data.category.CategoryDataset var19 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var26 = var25.clone();
//     boolean var27 = var25.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var25, var28);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var34 = var32.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var19, var20, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
//     org.jfree.chart.LegendItemCollection var36 = null;
//     var35.setFixedLegendItems(var36);
//     org.jfree.data.general.DatasetChangeEvent var38 = null;
//     var35.datasetChanged(var38);
//     var35.setRangeCrosshairLockedOnData(false);
//     var35.clearRangeMarkers();
//     org.jfree.chart.util.RectangleEdge var44 = var35.getDomainAxisEdge(10);
//     double var45 = var2.java2DToValue(Double.NaN, var15, var44);
//     
//     // Checks the contract:  equals-hashcode on var8 and var29
//     assertTrue("Contract failed: equals-hashcode on var8 and var29", var8.equals(var29) ? var8.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var8
//     assertTrue("Contract failed: equals-hashcode on var29 and var8", var29.equals(var8) ? var29.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
//     org.jfree.chart.LegendItem var3 = var0.getLegendItem((-1), 100);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var5 = null;
//     org.jfree.chart.entity.EntityCollection var6 = null;
//     org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo(var6);
//     org.jfree.chart.entity.EntityCollection var8 = var7.getEntityCollection();
//     java.awt.geom.Rectangle2D var9 = var7.getChartArea();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var17 = var16.clone();
//     boolean var18 = var16.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var16, var19);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var25 = var23.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var10, var11, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     org.jfree.chart.LegendItemCollection var27 = null;
//     var26.setFixedLegendItems(var27);
//     org.jfree.data.general.DatasetChangeEvent var29 = null;
//     var26.datasetChanged(var29);
//     var26.setRangeCrosshairVisible(true);
//     var26.clearRangeMarkers();
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var41 = var40.clone();
//     boolean var42 = var40.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var36, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.axis.ValueAxis)var40, var43);
//     java.awt.Font var49 = null;
//     org.jfree.chart.axis.MarkerAxisBand var50 = new org.jfree.chart.axis.MarkerAxisBand(var38, (-1.0d), (-1.0d), 100.0d, 10.0d, var49);
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.axis.AxisState var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     org.jfree.chart.util.RectangleEdge var54 = null;
//     java.util.List var55 = var38.refreshTicks(var51, var52, var53, var54);
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var59 = var58.clone();
//     boolean var60 = var58.isTickMarksVisible();
//     java.awt.Font var61 = var58.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var64 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var68 = null;
//     org.jfree.chart.ui.ProjectInfo var72 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var68, "hi!", "", "hi!");
//     java.awt.Image var76 = null;
//     org.jfree.chart.ui.ProjectInfo var80 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var76, "hi!", "", "hi!");
//     var72.addLibrary((org.jfree.chart.ui.Library)var80);
//     boolean var82 = var64.equals((java.lang.Object)var80);
//     java.awt.Paint var84 = var64.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var86 = new org.jfree.chart.text.TextFragment("", var61, var84, 0.0f);
//     var38.setLabelPaint(var84);
//     boolean var88 = var35.equals((java.lang.Object)var38);
//     org.jfree.data.category.DefaultCategoryDataset var89 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var90 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var89);
//     org.jfree.data.general.PieDataset var92 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var89, 2);
//     var0.drawItem(var4, var5, var9, var26, var34, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.data.category.CategoryDataset)var89, 1, 255, 15);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var2 = null;
//     var0.setQuadrantPaint(1, var2);
//     boolean var4 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var12 = null;
//     org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var12, "hi!", "", "hi!");
//     java.awt.Image var20 = null;
//     org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var20, "hi!", "", "hi!");
//     var16.addLibrary((org.jfree.chart.ui.Library)var24);
//     boolean var26 = var8.equals((java.lang.Object)var24);
//     java.awt.Paint var28 = var8.lookupSeriesFillPaint(100);
//     java.awt.Paint var30 = var8.getSeriesOutlinePaint(1);
//     java.lang.Number var32 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var33 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var32);
//     boolean var34 = var8.equals((java.lang.Object)var32);
//     java.lang.Boolean var36 = var8.getSeriesCreateEntities(10);
//     java.awt.Paint var37 = var8.getBaseFillPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var44 = null;
//     org.jfree.chart.ui.ProjectInfo var48 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var44, "hi!", "", "hi!");
//     java.awt.Image var52 = null;
//     org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var52, "hi!", "", "hi!");
//     var48.addLibrary((org.jfree.chart.ui.Library)var56);
//     boolean var58 = var40.equals((java.lang.Object)var56);
//     var40.setUseOutlinePaint(false);
//     java.awt.Stroke var63 = var40.getItemStroke(10, (-1));
//     org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(1.0d, var37, var63);
//     var0.addDomainMarker((org.jfree.chart.plot.Marker)var64);
//     java.lang.Class var66 = null;
//     java.util.EventListener[] var67 = var64.getListeners(var66);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var3 = var2.clone();
    boolean var4 = var2.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    var6.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var2.centerRange(0.0d);
    double var14 = var2.getLowerMargin();
    var2.setLabelAngle(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var8 = var7.clone();
    boolean var9 = var7.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.data.general.DatasetChangeEvent var20 = null;
    var17.datasetChanged(var20);
    org.jfree.chart.LegendItemCollection var22 = var17.getLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var23 = var17.getDatasetRenderingOrder();
    org.jfree.chart.axis.ValueAxis var25 = var17.getRangeAxisForDataset((-1));
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var0, var25, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    var27.setDataset(var28);
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var32 = var31.clone();
    boolean var33 = var31.isTickMarksVisible();
    java.awt.Font var34 = var31.getTickLabelFont();
    var27.setAngleLabelFont(var34);
    java.awt.Stroke var36 = var27.getAngleGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    double var3 = var1.calculateRightInset(0.05d);
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var7 = var1.createOutsetRectangle(var4, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    double var2 = var1.getSeriesRunningTotal();
    double var3 = var1.getSeriesRunningTotal();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var2 = var0.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.AreaRendererEndType var3 = var0.getEndType();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var11 = var10.clone();
    boolean var12 = var10.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var13);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var19 = var17.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
    org.jfree.chart.LegendItemCollection var21 = null;
    var20.setFixedLegendItems(var21);
    org.jfree.data.general.DatasetChangeEvent var23 = null;
    var20.datasetChanged(var23);
    var20.setRangeCrosshairLockedOnData(false);
    boolean var27 = var0.equals((java.lang.Object)false);
    org.jfree.chart.renderer.category.StackedAreaRenderer var28 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    var28.setRenderAsPercentages(true);
    org.jfree.chart.renderer.category.StackedAreaRenderer var31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var33 = var31.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.AreaRendererEndType var34 = var31.getEndType();
    var28.setEndType(var34);
    var0.setEndType(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    var2.setRenderAsPercentages(true);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var12, "hi!", "", "hi!");
    java.awt.Image var20 = null;
    org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var20, "hi!", "", "hi!");
    var16.addLibrary((org.jfree.chart.ui.Library)var24);
    boolean var26 = var8.equals((java.lang.Object)var24);
    java.awt.Paint var28 = var8.lookupSeriesFillPaint(100);
    java.awt.Paint var30 = var8.getSeriesOutlinePaint(1);
    java.lang.Number var32 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var33 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var32);
    boolean var34 = var8.equals((java.lang.Object)var32);
    java.lang.Boolean var36 = var8.getSeriesCreateEntities(10);
    java.awt.Paint var37 = var8.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var44 = null;
    org.jfree.chart.ui.ProjectInfo var48 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var44, "hi!", "", "hi!");
    java.awt.Image var52 = null;
    org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var52, "hi!", "", "hi!");
    var48.addLibrary((org.jfree.chart.ui.Library)var56);
    boolean var58 = var40.equals((java.lang.Object)var56);
    var40.setUseOutlinePaint(false);
    java.awt.Stroke var63 = var40.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(1.0d, var37, var63);
    java.awt.Color var66 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    var64.setPaint((java.awt.Paint)var66);
    var2.setBasePaint((java.awt.Paint)var66, false);
    java.io.ObjectOutputStream var70 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint)var66, var70);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var3 = var0.getItemOutlinePaint(100, 0);
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var6 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var5};
    var4.setRenderers(var6);
    boolean var8 = var0.equals((java.lang.Object)var4);
    java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    int var11 = var10.getAlpha();
    java.awt.Color var12 = var10.darker();
    var0.setBasePaint((java.awt.Paint)var12);
    int var14 = var12.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 255);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var8 = var7.clone();
    boolean var9 = var7.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.data.general.DatasetChangeEvent var20 = null;
    var17.datasetChanged(var20);
    org.jfree.chart.LegendItemCollection var22 = var17.getLegendItems();
    org.jfree.data.category.CategoryDataset var24 = var17.getDataset(0);
    org.jfree.chart.axis.ValueAxis var25 = null;
    var17.setRangeAxis(var25);
    boolean var27 = var0.equals((java.lang.Object)var17);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var34 = null;
    org.jfree.chart.ui.ProjectInfo var38 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var34, "hi!", "", "hi!");
    java.awt.Image var42 = null;
    org.jfree.chart.ui.ProjectInfo var46 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var42, "hi!", "", "hi!");
    var38.addLibrary((org.jfree.chart.ui.Library)var46);
    boolean var48 = var30.equals((java.lang.Object)var46);
    java.awt.Paint var50 = var30.lookupSeriesFillPaint(100);
    java.awt.Paint var52 = var30.getSeriesOutlinePaint(1);
    java.lang.Number var54 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var55 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var54);
    boolean var56 = var30.equals((java.lang.Object)var54);
    java.lang.Boolean var58 = var30.getSeriesCreateEntities(10);
    java.awt.Paint var59 = var30.getBaseFillPaint();
    var0.setBaseItemLabelPaint(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.data.category.CategoryDataset var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var0.generateToolTip(var3, 1969, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    java.awt.Font var48 = var45.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var45);
    org.jfree.chart.util.HorizontalAlignment var50 = null;
    org.jfree.chart.util.VerticalAlignment var51 = null;
    org.jfree.chart.block.FlowArrangement var54 = new org.jfree.chart.block.FlowArrangement(var50, var51, (-1.0d), 0.0d);
    org.jfree.chart.util.HorizontalAlignment var55 = null;
    org.jfree.chart.util.VerticalAlignment var56 = null;
    org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 0.0d, 0.05d);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45, (org.jfree.chart.block.Arrangement)var54, (org.jfree.chart.block.Arrangement)var59);
    java.awt.Paint var61 = var60.getItemPaint();
    var60.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "First"};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     java.lang.Number[] var4 = null;
//     java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var5);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var4 = var3.clone();
    boolean var5 = var3.isTickMarksVisible();
    java.awt.Font var6 = var3.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
    java.awt.Image var21 = null;
    org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
    var17.addLibrary((org.jfree.chart.ui.Library)var25);
    boolean var27 = var9.equals((java.lang.Object)var25);
    java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
    java.awt.Font var32 = var31.getFont();
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var36 = var35.clone();
    boolean var37 = var35.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var40 = var39.clone();
    var39.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var43);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var44, true);
    java.awt.Paint var47 = var46.getBorderPaint();
    org.jfree.chart.block.LineBorder var48 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var49 = var48.getInsets();
    double var51 = var49.calculateRightInset(0.05d);
    var46.setPadding(var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var54 = var46.getSubtitle(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
//     var0.clear();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
//     double var5 = var4.getBase();
//     org.jfree.data.category.DefaultCategoryDataset var6 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var6);
//     java.lang.Object var8 = var6.clone();
//     boolean var9 = var4.equals((java.lang.Object)var6);
//     org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)true);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var19 = var18.clone();
//     boolean var20 = var18.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var18, var21);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var27 = var25.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var35 = null;
//     org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var35, "hi!", "", "hi!");
//     java.awt.Image var43 = null;
//     org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
//     var39.addLibrary((org.jfree.chart.ui.Library)var47);
//     boolean var49 = var31.equals((java.lang.Object)var47);
//     var31.setUseOutlinePaint(false);
//     java.awt.Stroke var54 = var31.getItemStroke(10, (-1));
//     var28.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var31, false);
//     var28.setAnchorValue(100.0d, true);
//     var28.setDomainGridlinesVisible(false);
//     boolean var62 = var6.hasListener((java.util.EventListener)var28);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var68 = var67.clone();
//     boolean var69 = var67.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var70 = null;
//     org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot(var63, (org.jfree.chart.axis.ValueAxis)var65, (org.jfree.chart.axis.ValueAxis)var67, var70);
//     org.jfree.data.Range var72 = var67.getRange();
//     org.jfree.data.Range var75 = org.jfree.data.Range.expand(var72, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var76 = new org.jfree.data.time.DateRange(var75);
//     java.util.Date var77 = var76.getLowerDate();
//     org.jfree.data.time.Month var78 = new org.jfree.data.time.Month(var77);
//     org.jfree.chart.title.LegendItemBlockContainer var79 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var6, (java.lang.Comparable)var78);
//     
//     // Checks the contract:  equals-hashcode on var22 and var71
//     assertTrue("Contract failed: equals-hashcode on var22 and var71", var22.equals(var71) ? var22.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var22
//     assertTrue("Contract failed: equals-hashcode on var71 and var22", var71.equals(var22) ? var71.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     org.jfree.data.Range var9 = var4.getRange();
//     org.jfree.data.Range var12 = org.jfree.data.Range.expand(var9, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange(var12);
//     java.util.Date var14 = var13.getLowerDate();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year(var14);
//     java.util.Calendar var16 = null;
//     long var17 = var15.getFirstMillisecond(var16);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.data.general.DatasetChangeEvent var19 = null;
    var16.datasetChanged(var19);
    var16.setRangeCrosshairVisible(true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var16.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     java.text.NumberFormat var3 = var2.getNumberFormat();
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var4 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", var3);
//     org.jfree.chart.labels.StandardCategoryToolTipGenerator var5 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("java.awt.Color[r=0,g=0,b=0]", var3);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     java.lang.String var8 = var5.generateColumnLabel(var6, (-1));
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("({0}, {1}) = {3} - {4}", var1, 0.0f, 0.0f, 0.0d, 10.0f, 10.0f);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    org.jfree.chart.event.ChartChangeEventType var48 = null;
    org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var47, var48);
    double var50 = var0.getBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    java.lang.Object var3 = var1.get(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getRightArrow();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var3, "({0}, {1}) = {3} - {4}", "[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var6 = var5.clone();
    boolean var7 = var5.isTickMarksVisible();
    java.awt.Font var8 = var5.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
    java.awt.Image var23 = null;
    org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
    var19.addLibrary((org.jfree.chart.ui.Library)var27);
    boolean var29 = var11.equals((java.lang.Object)var27);
    java.awt.Paint var31 = var11.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var8, var31, 0.0f);
    java.awt.Font var34 = var33.getFont();
    org.jfree.data.xy.XYDataset var35 = null;
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var38 = var37.clone();
    boolean var39 = var37.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var42 = var41.clone();
    var41.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.axis.ValueAxis)var41, var45);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("", var34, (org.jfree.chart.plot.Plot)var46, true);
    java.awt.Font var49 = var46.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var46);
    java.lang.Object var51 = var50.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPieChart(var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Object var3 = var2.clone();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var9 = var7.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var11 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var7.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var11);
//     var2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var11, true);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var17 = null;
//     var15.setQuadrantPaint(1, var17);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var25 = null;
//     org.jfree.chart.ui.ProjectInfo var29 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var25, "hi!", "", "hi!");
//     java.awt.Image var33 = null;
//     org.jfree.chart.ui.ProjectInfo var37 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var33, "hi!", "", "hi!");
//     var29.addLibrary((org.jfree.chart.ui.Library)var37);
//     boolean var39 = var21.equals((java.lang.Object)var37);
//     java.awt.Paint var41 = var21.lookupSeriesFillPaint(100);
//     var15.setBackgroundPaint(var41);
//     java.awt.Stroke var43 = var15.getDomainGridlineStroke();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var50 = null;
//     org.jfree.chart.ui.ProjectInfo var54 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var50, "hi!", "", "hi!");
//     java.awt.Image var58 = null;
//     org.jfree.chart.ui.ProjectInfo var62 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var58, "hi!", "", "hi!");
//     var54.addLibrary((org.jfree.chart.ui.Library)var62);
//     boolean var64 = var46.equals((java.lang.Object)var62);
//     java.awt.Paint var66 = var46.lookupSeriesFillPaint(100);
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var69 = null;
//     var67.setQuadrantPaint(1, var69);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var73 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var77 = null;
//     org.jfree.chart.ui.ProjectInfo var81 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var77, "hi!", "", "hi!");
//     java.awt.Image var85 = null;
//     org.jfree.chart.ui.ProjectInfo var89 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var85, "hi!", "", "hi!");
//     var81.addLibrary((org.jfree.chart.ui.Library)var89);
//     boolean var91 = var73.equals((java.lang.Object)var89);
//     java.awt.Paint var93 = var73.lookupSeriesFillPaint(100);
//     var67.setBackgroundPaint(var93);
//     boolean var95 = org.jfree.chart.util.PaintUtilities.equal(var66, var93);
//     var15.setDomainCrosshairPaint(var93);
//     var2.setBaseFillPaint(var93);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var2.", var21.equals(var2) == var2.equals(var21));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var7.", var21.equals(var7) == var7.equals(var21));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var46 and var2.", var46.equals(var2) == var2.equals(var46));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var46 and var7.", var46.equals(var7) == var7.equals(var46));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var73 and var2.", var73.equals(var2) == var2.equals(var73));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var73 and var7.", var73.equals(var7) == var7.equals(var73));
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.getTimeFromLong(10L);
//     var0.addBaseTimelineException(1L);
//     java.text.DateFormat var9 = null;
//     org.jfree.chart.axis.DateTickUnit var10 = new org.jfree.chart.axis.DateTickUnit(0, 15, 100, 15, var9);
//     int var11 = var10.getRollUnit();
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var17 = var16.clone();
//     boolean var18 = var16.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var16, var19);
//     org.jfree.data.Range var21 = var16.getRange();
//     org.jfree.data.Range var24 = org.jfree.data.Range.expand(var21, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var25 = new org.jfree.data.time.DateRange(var24);
//     java.util.Date var26 = var25.getLowerDate();
//     java.lang.String var27 = var10.dateToString(var26);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var33 = var32.clone();
//     boolean var34 = var32.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.axis.ValueAxis)var32, var35);
//     org.jfree.data.Range var37 = var32.getRange();
//     org.jfree.data.Range var40 = org.jfree.data.Range.expand(var37, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange(var40);
//     java.util.Date var42 = var41.getLowerDate();
//     org.jfree.data.time.Month var43 = new org.jfree.data.time.Month(var42);
//     org.jfree.data.time.Month var44 = new org.jfree.data.time.Month(var42);
//     boolean var45 = var0.containsDomainRange(var26, var42);
//     
//     // Checks the contract:  equals-hashcode on var20 and var36
//     assertTrue("Contract failed: equals-hashcode on var20 and var36", var20.equals(var36) ? var20.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var20
//     assertTrue("Contract failed: equals-hashcode on var36 and var20", var36.equals(var20) ? var36.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(4.7304E11d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     org.jfree.data.general.WaferMapDataset var2 = var1.getDataset();
//     org.jfree.chart.LegendItemCollection var3 = var1.getLegendItems();
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     java.awt.Paint var39 = var19.lookupSeriesFillPaint(100);
//     java.awt.Paint var41 = var19.getSeriesOutlinePaint(1);
//     java.lang.Number var43 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var44 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var43);
//     boolean var45 = var19.equals((java.lang.Object)var43);
//     java.lang.Boolean var47 = var19.getSeriesCreateEntities(10);
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
//     java.lang.Object var49 = var16.clone();
//     org.jfree.chart.util.Layer var51 = null;
//     java.util.Collection var52 = var16.getDomainMarkers(15, var51);
//     org.jfree.data.xy.XYDataset var53 = null;
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var58 = var57.clone();
//     boolean var59 = var57.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var53, (org.jfree.chart.axis.ValueAxis)var55, (org.jfree.chart.axis.ValueAxis)var57, var60);
//     var55.setAutoRangeStickyZero(false);
//     var55.setFixedAutoRange(10.0d);
//     org.jfree.data.xy.XYDataset var66 = null;
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var71 = var70.clone();
//     boolean var72 = var70.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var73 = null;
//     org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot(var66, (org.jfree.chart.axis.ValueAxis)var68, (org.jfree.chart.axis.ValueAxis)var70, var73);
//     org.jfree.data.Range var75 = var70.getRange();
//     org.jfree.data.Range var78 = org.jfree.data.Range.expand(var75, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var79 = new org.jfree.data.time.DateRange(var78);
//     java.util.Date var80 = var79.getLowerDate();
//     var55.setRangeWithMargins((org.jfree.data.Range)var79, false, false);
//     org.jfree.data.general.Dataset var84 = null;
//     org.jfree.data.general.DatasetChangeEvent var85 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var79, var84);
//     var16.datasetChanged(var85);
//     
//     // Checks the contract:  equals-hashcode on var10 and var74
//     assertTrue("Contract failed: equals-hashcode on var10 and var74", var10.equals(var74) ? var10.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var10
//     assertTrue("Contract failed: equals-hashcode on var74 and var10", var74.equals(var10) ? var74.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var9 = var7.getSeriesVisibleInLegend(10);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var11 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var7.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var11);
    var2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var11, true);
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var17 = null;
    var15.setQuadrantPaint(1, var17);
    var15.configureDomainAxes();
    java.awt.Font var20 = var15.getNoDataMessageFont();
    java.awt.Paint var21 = var15.getDomainGridlinePaint();
    var2.setBasePaint(var21);
    org.jfree.chart.labels.ItemLabelPosition var23 = var2.getBasePositiveItemLabelPosition();
    boolean var24 = var2.getBaseLinesVisible();
    var2.setBaseSeriesVisibleInLegend(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    java.awt.Paint var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     var16.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.LegendItemCollection var23 = var16.getLegendItems();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var31 = var30.clone();
//     boolean var32 = var30.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var30, var33);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var39 = var37.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     org.jfree.chart.LegendItemCollection var41 = null;
//     var40.setFixedLegendItems(var41);
//     org.jfree.data.general.DatasetChangeEvent var43 = null;
//     var40.datasetChanged(var43);
//     org.jfree.chart.LegendItemCollection var45 = var40.getLegendItems();
//     var23.addAll(var45);
//     
//     // Checks the contract:  equals-hashcode on var10 and var34
//     assertTrue("Contract failed: equals-hashcode on var10 and var34", var10.equals(var34) ? var10.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var10
//     assertTrue("Contract failed: equals-hashcode on var34 and var10", var34.equals(var10) ? var34.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var45
//     assertTrue("Contract failed: equals-hashcode on var23 and var45", var23.equals(var45) ? var23.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var23
//     assertTrue("Contract failed: equals-hashcode on var45 and var23", var45.equals(var23) ? var45.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    double var3 = var2.getBase();
    org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var4);
    java.lang.Object var6 = var4.clone();
    boolean var7 = var2.equals((java.lang.Object)var4);
    org.jfree.data.time.TimePeriod var10 = null;
    org.jfree.data.gantt.Task var11 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var10);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var17 = var16.clone();
    boolean var18 = var16.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var16, var19);
    org.jfree.data.Range var21 = var16.getRange();
    org.jfree.data.Range var24 = org.jfree.data.Range.expand(var21, 10.0d, 0.0d);
    org.jfree.data.time.DateRange var25 = new org.jfree.data.time.DateRange(var24);
    java.util.Date var26 = var25.getLowerDate();
    org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(var26);
    org.jfree.data.time.Month var28 = new org.jfree.data.time.Month(var26);
    var11.setDuration((org.jfree.data.time.TimePeriod)var28);
    var4.addValue((java.lang.Number)(short)10, (java.lang.Comparable)var28, (java.lang.Comparable)"Range[0.0,1.05]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.removeColumn(96);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0d+ "'", var5.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var3, "hi!", "", "hi!");
    java.awt.Image var11 = null;
    org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var11, "hi!", "", "hi!");
    var7.addLibrary((org.jfree.chart.ui.Library)var15);
    var7.setInfo("[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]");
    java.lang.String var19 = var7.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "hi!"+ "'", var19.equals("hi!"));

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var1);
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setQuadrantPaint(10, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var6 = var5.clone();
//     boolean var7 = var5.isTickMarksVisible();
//     java.awt.Font var8 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var15 = null;
//     org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     var19.addLibrary((org.jfree.chart.ui.Library)var27);
//     boolean var29 = var11.equals((java.lang.Object)var27);
//     java.awt.Paint var31 = var11.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var8, var31, 0.0f);
//     java.awt.Font var34 = var33.getFont();
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var38 = var37.clone();
//     boolean var39 = var37.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var42 = var41.clone();
//     var41.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.axis.ValueAxis)var41, var45);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("", var34, (org.jfree.chart.plot.Plot)var46, true);
//     java.awt.Font var49 = var46.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var46);
//     org.jfree.chart.util.HorizontalAlignment var51 = null;
//     org.jfree.chart.util.VerticalAlignment var52 = null;
//     org.jfree.chart.block.FlowArrangement var55 = new org.jfree.chart.block.FlowArrangement(var51, var52, (-1.0d), 0.0d);
//     org.jfree.chart.util.HorizontalAlignment var56 = null;
//     org.jfree.chart.util.VerticalAlignment var57 = null;
//     org.jfree.chart.block.FlowArrangement var60 = new org.jfree.chart.block.FlowArrangement(var56, var57, 0.0d, 0.05d);
//     org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46, (org.jfree.chart.block.Arrangement)var55, (org.jfree.chart.block.Arrangement)var60);
//     org.jfree.chart.util.VerticalAlignment var62 = var61.getVerticalAlignment();
//     org.jfree.chart.util.RectangleInsets var63 = var61.getLegendItemGraphicPadding();
//     org.jfree.chart.block.BlockContainer var64 = var61.getItemContainer();
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.xy.XYDataset var67 = var65.getDataset((-1));
//     org.jfree.data.xy.XYDataset var69 = null;
//     org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var74 = var73.clone();
//     boolean var75 = var73.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var76 = null;
//     org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot(var69, (org.jfree.chart.axis.ValueAxis)var71, (org.jfree.chart.axis.ValueAxis)var73, var76);
//     var65.setDomainAxis(100, (org.jfree.chart.axis.ValueAxis)var71, true);
//     var0.add((org.jfree.chart.block.Block)var61, (java.lang.Object)100);
//     
//     // Checks the contract:  equals-hashcode on var46 and var77
//     assertTrue("Contract failed: equals-hashcode on var46 and var77", var46.equals(var77) ? var46.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var46
//     assertTrue("Contract failed: equals-hashcode on var77 and var46", var77.equals(var46) ? var77.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var2 = var1.clone();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var8 = var7.clone();
    boolean var9 = var7.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.data.Range var12 = var7.getRange();
    org.jfree.data.Range var15 = org.jfree.data.Range.expand(var12, 10.0d, 0.0d);
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange(var15);
    var1.setRangeWithMargins(var15, false, true);
    java.lang.String var20 = var1.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    var0.configureDomainAxes();
    java.awt.Font var5 = var0.getNoDataMessageFont();
    org.jfree.chart.axis.AxisSpace var6 = var0.getFixedDomainAxisSpace();
    boolean var7 = var0.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(var1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var3 = var2.clone();
    boolean var4 = var2.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    var6.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var2.centerRange(0.0d);
    double var14 = var2.getLowerMargin();
    java.awt.Shape var15 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D();
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
    var16.setBaseShape(var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setUpArrow(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var4 = var3.getInsets();
//     org.jfree.chart.entity.EntityCollection var5 = null;
//     org.jfree.chart.ChartRenderingInfo var6 = new org.jfree.chart.ChartRenderingInfo(var5);
//     org.jfree.chart.entity.EntityCollection var7 = var6.getEntityCollection();
//     java.awt.geom.Rectangle2D var8 = var6.getChartArea();
//     java.awt.geom.Rectangle2D var11 = var4.createInsetRectangle(var8, true, true);
//     org.jfree.chart.block.LineBorder var12 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var13 = var12.getInsets();
//     org.jfree.chart.entity.EntityCollection var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo(var14);
//     org.jfree.chart.entity.EntityCollection var16 = var15.getEntityCollection();
//     java.awt.geom.Rectangle2D var17 = var15.getChartArea();
//     java.awt.geom.Rectangle2D var20 = var13.createInsetRectangle(var17, true, true);
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var28 = var27.clone();
//     boolean var29 = var27.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var27, var30);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var36 = var34.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var21, var22, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
//     org.jfree.chart.LegendItemCollection var38 = null;
//     var37.setFixedLegendItems(var38);
//     org.jfree.data.general.DatasetChangeEvent var40 = null;
//     var37.datasetChanged(var40);
//     var37.setRangeCrosshairLockedOnData(false);
//     var37.clearRangeMarkers();
//     org.jfree.chart.util.RectangleEdge var46 = var37.getDomainAxisEdge(10);
//     org.jfree.chart.util.RectangleEdge var47 = org.jfree.chart.util.RectangleEdge.opposite(var46);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     org.jfree.chart.axis.AxisState var49 = var0.draw(var1, 0.0d, var8, var20, var47, var48);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Image var1 = var0.getBackgroundImage();
    float var2 = var0.getBackgroundAlpha();
    java.awt.Stroke var3 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.annotations.XYAnnotation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    java.awt.Paint var24 = var2.getSeriesOutlinePaint(1);
    java.lang.Number var26 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var26);
    boolean var28 = var2.equals((java.lang.Object)var26);
    java.lang.Boolean var30 = var2.getSeriesCreateEntities(10);
    var2.setSeriesCreateEntities(10, (java.lang.Boolean)true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelsVisible((-1), (java.lang.Boolean)false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("({0}, {1}) = {3} - {4}", var1, 0.65d, (-1.0f), (-1.0f));
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Image var1 = var0.getBackgroundImage();
    org.jfree.chart.plot.DrawingSupplier var2 = var0.getDrawingSupplier();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var11 = var10.clone();
    boolean var12 = var10.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var13);
    org.jfree.data.Range var15 = var10.getRange();
    org.jfree.data.Range var18 = org.jfree.data.Range.expand(var15, 10.0d, 0.0d);
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange(var18);
    var4.setRangeWithMargins(var18, false, true);
    boolean var23 = var0.equals((java.lang.Object)true);
    double var24 = var0.getRangeCrosshairValue();
    org.jfree.chart.axis.ValueAxis var25 = var0.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var6 = var5.clone();
    java.awt.Shape var7 = var5.getLeftArrow();
    org.jfree.chart.renderer.category.LayeredBarRenderer var8 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var11 = var8.getItemOutlinePaint(100, 0);
    org.jfree.chart.renderer.category.LayeredBarRenderer var12 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var15 = var12.getItemOutlinePaint(100, 0);
    java.awt.Paint var16 = var12.getBasePaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var21 = var20.clone();
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var24 = null;
    var22.setQuadrantPaint(1, var24);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var32 = null;
    org.jfree.chart.ui.ProjectInfo var36 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var32, "hi!", "", "hi!");
    java.awt.Image var40 = null;
    org.jfree.chart.ui.ProjectInfo var44 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var40, "hi!", "", "hi!");
    var36.addLibrary((org.jfree.chart.ui.Library)var44);
    boolean var46 = var28.equals((java.lang.Object)var44);
    java.awt.Paint var48 = var28.lookupSeriesFillPaint(100);
    var22.setBackgroundPaint(var48);
    java.awt.Stroke var50 = var22.getDomainGridlineStroke();
    var20.setBaseStroke(var50, false);
    var12.setSeriesOutlineStroke(100, var50);
    java.awt.Paint var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem(var0, "", "({0}, {1}) = {3} - {4}", "Other", var7, var11, var50, var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    java.awt.Color var2 = java.awt.Color.getColor("Range[0.0,1.05]", 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataExtractOrder(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     java.awt.Font var7 = var4.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     java.awt.Image var22 = null;
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
//     var18.addLibrary((org.jfree.chart.ui.Library)var26);
//     boolean var28 = var10.equals((java.lang.Object)var26);
//     java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
//     java.awt.Font var33 = var32.getFont();
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var37 = var36.clone();
//     boolean var38 = var36.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var41 = var40.clone();
//     var40.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
//     java.awt.Font var48 = var45.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var45);
//     org.jfree.chart.util.HorizontalAlignment var50 = null;
//     org.jfree.chart.util.VerticalAlignment var51 = null;
//     org.jfree.chart.block.FlowArrangement var54 = new org.jfree.chart.block.FlowArrangement(var50, var51, (-1.0d), 0.0d);
//     org.jfree.chart.util.HorizontalAlignment var55 = null;
//     org.jfree.chart.util.VerticalAlignment var56 = null;
//     org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 0.0d, 0.05d);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45, (org.jfree.chart.block.Arrangement)var54, (org.jfree.chart.block.Arrangement)var59);
//     org.jfree.chart.util.VerticalAlignment var61 = var60.getVerticalAlignment();
//     org.jfree.chart.util.RectangleInsets var62 = var60.getLegendItemGraphicPadding();
//     org.jfree.chart.block.BlockContainer var63 = var60.getItemContainer();
//     java.awt.Color var65 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     org.jfree.data.category.CategoryDataset var66 = null;
//     org.jfree.chart.axis.CategoryAxis var67 = null;
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var73 = var72.clone();
//     boolean var74 = var72.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var75 = null;
//     org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot(var68, (org.jfree.chart.axis.ValueAxis)var70, (org.jfree.chart.axis.ValueAxis)var72, var75);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var79 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var81 = var79.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var82 = new org.jfree.chart.plot.CategoryPlot(var66, var67, (org.jfree.chart.axis.ValueAxis)var72, (org.jfree.chart.renderer.category.CategoryItemRenderer)var79);
//     org.jfree.chart.LegendItemCollection var83 = null;
//     var82.setFixedLegendItems(var83);
//     org.jfree.data.general.DatasetChangeEvent var85 = null;
//     var82.datasetChanged(var85);
//     var82.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.JFreeChart var89 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var82);
//     boolean var90 = var65.equals((java.lang.Object)var82);
//     org.jfree.chart.plot.DatasetRenderingOrder var91 = var82.getDatasetRenderingOrder();
//     boolean var92 = var63.equals((java.lang.Object)var91);
//     
//     // Checks the contract:  equals-hashcode on var45 and var76
//     assertTrue("Contract failed: equals-hashcode on var45 and var76", var45.equals(var76) ? var45.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var45
//     assertTrue("Contract failed: equals-hashcode on var76 and var45", var76.equals(var45) ? var76.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer(0);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = var0.getRenderer();
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var16 = var15.clone();
    boolean var17 = var15.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var18);
    java.awt.Font var24 = null;
    org.jfree.chart.axis.MarkerAxisBand var25 = new org.jfree.chart.axis.MarkerAxisBand(var13, (-1.0d), (-1.0d), 100.0d, 10.0d, var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.axis.AxisState var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    java.util.List var30 = var13.refreshTicks(var26, var27, var28, var29);
    java.util.Collection var31 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var30);
    var0.drawDomainTickBands(var9, var10, var30);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    java.awt.geom.Point2D var36 = null;
    var0.zoomRangeAxes(0.0d, 0.0d, var35, var36);
    org.jfree.chart.util.Layer var38 = null;
    java.util.Collection var39 = var0.getDomainMarkers(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    var0.setMinimumArcAngleToDraw(0.0d);
    var0.setLabelGap(Double.NaN);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var3 = var2.clone();
    boolean var4 = var2.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    var6.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var2.centerRange(0.0d);
    double var14 = var2.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setTickUnit(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.xy.XYDataset var1 = null;
//     var0.setDataset(var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     var0.setRenderer(var3);
//     float var5 = var0.getBackgroundAlpha();
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     org.jfree.chart.entity.EntityCollection var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo(var8);
//     org.jfree.chart.entity.EntityCollection var10 = var9.getEntityCollection();
//     java.awt.geom.Rectangle2D var11 = var9.getChartArea();
//     java.awt.geom.Rectangle2D var14 = var7.createInsetRectangle(var11, true, true);
//     var0.setInsets(var7);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Image var17 = var16.getBackgroundImage();
//     float var18 = var16.getBackgroundAlpha();
//     java.awt.Stroke var19 = var16.getDomainZeroBaselineStroke();
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
//     org.jfree.chart.entity.EntityCollection var21 = null;
//     org.jfree.chart.ChartRenderingInfo var22 = new org.jfree.chart.ChartRenderingInfo(var21);
//     org.jfree.chart.entity.EntityCollection var23 = var22.getEntityCollection();
//     java.awt.geom.Rectangle2D var24 = var22.getChartArea();
//     org.jfree.chart.entity.ChartEntity var27 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var24, "VerticalAlignment.CENTER", "Category Plot");
//     var20.setBounds(var24);
//     java.awt.geom.Rectangle2D var31 = var7.createInsetRectangle(var24, false, false);
//     
//     // Checks the contract:  equals-hashcode on var9 and var22
//     assertTrue("Contract failed: equals-hashcode on var9 and var22", var9.equals(var22) ? var9.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var9
//     assertTrue("Contract failed: equals-hashcode on var22 and var9", var22.equals(var9) ? var22.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var6 = var5.clone();
    var5.setAutoRange(true);
    org.jfree.chart.axis.ValueAxis[] var9 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setRangeAxes(var9);
    int var11 = var0.getBackgroundImageAlignment();
    var0.setDomainZeroBaselineVisible(true);
    org.jfree.chart.plot.DrawingSupplier var14 = var0.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.data.general.DatasetChangeEvent var19 = null;
    var16.datasetChanged(var19);
    var16.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
    var23.setBackgroundImageAlpha(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, 2);
    java.lang.Comparable var5 = null;
    java.lang.Class var6 = null;
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var12 = var11.clone();
    boolean var13 = var11.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var14);
    org.jfree.data.Range var16 = var11.getRange();
    org.jfree.data.Range var19 = org.jfree.data.Range.expand(var16, 10.0d, 0.0d);
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange(var19);
    java.util.Date var21 = var20.getLowerDate();
    org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(var21);
    java.util.TimeZone var23 = null;
    org.jfree.data.time.RegularTimePeriod var24 = org.jfree.data.time.RegularTimePeriod.createInstance(var6, var21, var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addValue((java.lang.Number)10, var5, (java.lang.Comparable)var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + 0.0d+ "'", var1.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("XY Plot");

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Range[0.0,1.05]", var1, 0.95f, (-1.0f), 1.0E-8d, 0.5f, 0.0f);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = null;
    var4.setQuadrantPaint(1, var6);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    var4.setBackgroundPaint(var30);
    java.awt.Stroke var32 = var4.getDomainGridlineStroke();
    var2.setBaseStroke(var32, false);
    boolean var35 = var2.getUseFillPaint();
    java.awt.Graphics2D var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.data.xy.XYDataset var40 = null;
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var45 = var44.clone();
    boolean var46 = var44.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var40, (org.jfree.chart.axis.ValueAxis)var42, (org.jfree.chart.axis.ValueAxis)var44, var47);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var53 = var51.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.renderer.category.CategoryItemRenderer)var51);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var61 = null;
    org.jfree.chart.ui.ProjectInfo var65 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var61, "hi!", "", "hi!");
    java.awt.Image var69 = null;
    org.jfree.chart.ui.ProjectInfo var73 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var69, "hi!", "", "hi!");
    var65.addLibrary((org.jfree.chart.ui.Library)var73);
    boolean var75 = var57.equals((java.lang.Object)var73);
    var57.setUseOutlinePaint(false);
    java.awt.Stroke var80 = var57.getItemStroke(10, (-1));
    var54.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var57, false);
    var54.setAnchorValue(100.0d, true);
    var54.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var89 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var90 = var2.initialise(var36, var37, var54, 1, var89);
    var2.setDrawOutlines(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]", var1, var2);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var9 = var7.getSeriesVisibleInLegend(10);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var11 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var7.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var11);
    var2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var11, true);
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var17 = null;
    var15.setQuadrantPaint(1, var17);
    var15.configureDomainAxes();
    java.awt.Font var20 = var15.getNoDataMessageFont();
    java.awt.Paint var21 = var15.getDomainGridlinePaint();
    var2.setBasePaint(var21);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var23 = var2.getLegendItemToolTipGenerator();
    org.jfree.chart.event.RendererChangeListener var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.removeChangeListener(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var23 = null;
    org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
    java.awt.Image var31 = null;
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
    var27.addLibrary((org.jfree.chart.ui.Library)var35);
    boolean var37 = var19.equals((java.lang.Object)var35);
    var19.setUseOutlinePaint(false);
    java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
    var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
    var16.setAnchorValue(100.0d, true);
    var16.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.ValueAxis var51 = var16.getRangeAxisForDataset(0);
    var51.setPositiveArrowVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var7 = null;
    org.jfree.chart.ui.ProjectInfo var11 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var7, "hi!", "", "hi!");
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
    var11.addLibrary((org.jfree.chart.ui.Library)var19);
    boolean var21 = var3.equals((java.lang.Object)var19);
    java.awt.Paint var23 = var3.lookupSeriesFillPaint(100);
    java.awt.Paint var25 = var3.getSeriesOutlinePaint(1);
    java.lang.Number var27 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var28 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var27);
    boolean var29 = var3.equals((java.lang.Object)var27);
    java.lang.Boolean var31 = var3.getSeriesCreateEntities(10);
    java.awt.Paint var32 = var3.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var39 = null;
    org.jfree.chart.ui.ProjectInfo var43 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var39, "hi!", "", "hi!");
    java.awt.Image var47 = null;
    org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
    var43.addLibrary((org.jfree.chart.ui.Library)var51);
    boolean var53 = var35.equals((java.lang.Object)var51);
    var35.setUseOutlinePaint(false);
    java.awt.Stroke var58 = var35.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(1.0d, var32, var58);
    var59.setLabel("hi!");
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var65 = var64.clone();
    boolean var66 = var64.isTickMarksVisible();
    java.awt.Font var67 = var64.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var70 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var74 = null;
    org.jfree.chart.ui.ProjectInfo var78 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var74, "hi!", "", "hi!");
    java.awt.Image var82 = null;
    org.jfree.chart.ui.ProjectInfo var86 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var82, "hi!", "", "hi!");
    var78.addLibrary((org.jfree.chart.ui.Library)var86);
    boolean var88 = var70.equals((java.lang.Object)var86);
    java.awt.Paint var90 = var70.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var92 = new org.jfree.chart.text.TextFragment("", var67, var90, 0.0f);
    var59.setOutlinePaint(var90);
    java.awt.Paint var94 = var59.getLabelPaint();
    var59.setValue(Double.NEGATIVE_INFINITY);
    java.awt.Paint var97 = var59.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.KeyToGroupMap var0 = new org.jfree.data.KeyToGroupMap();
    int var2 = var0.getGroupIndex((java.lang.Comparable)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var9 = var8.clone();
//     boolean var10 = var8.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var8, var11);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var17 = var15.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var2, var3, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.LegendItemCollection var19 = null;
//     var18.setFixedLegendItems(var19);
//     org.jfree.data.general.DatasetChangeEvent var21 = null;
//     var18.datasetChanged(var21);
//     var18.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var18);
//     boolean var26 = var1.equals((java.lang.Object)var18);
//     org.jfree.chart.event.PlotChangeEvent var27 = null;
//     var18.notifyListeners(var27);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getDatasetCount();
    boolean var2 = var0.isRangeCrosshairLockedOnData();
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeZeroBaselinePaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    var2.setSeriesShapesVisible(1, false);
    org.jfree.chart.LegendItem var26 = var2.getLegendItem(0, (-1));
    int var27 = var2.getPassCount();
    var2.setAutoPopulateSeriesShape(true);
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.xy.XYDataset var31 = null;
    var30.setDataset(var31);
    java.awt.Paint var33 = var30.getRangeGridlinePaint();
    var2.setBaseItemLabelPaint(var33, false);
    org.jfree.chart.labels.ItemLabelPosition var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBasePositiveItemLabelPosition(var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    java.text.DateFormat var5 = null;
    org.jfree.chart.axis.DateTickUnit var6 = new org.jfree.chart.axis.DateTickUnit(0, 15, 100, 15, var5);
    int var7 = var6.getCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var8 = var0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit)var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 15);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    var0.configureDomainAxes();
    org.jfree.chart.axis.ValueAxis var5 = var0.getDomainAxis();
    org.jfree.chart.LegendItemCollection var6 = var0.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setXOffset(Double.NaN);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     var19.setUseOutlinePaint(false);
//     java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
//     var16.setAnchorValue(100.0d, true);
//     var16.setDomainGridlinesVisible(false);
//     org.jfree.data.general.DatasetChangeEvent var50 = null;
//     var16.datasetChanged(var50);
//     var16.clearDomainMarkers(2);
//     var16.clearRangeAxes();
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var56);
//     org.jfree.data.xy.XYDataset var58 = null;
//     int var59 = var56.indexOf(var58);
//     org.jfree.data.category.CategoryDataset var61 = null;
//     org.jfree.chart.axis.CategoryAxis var62 = null;
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var68 = var67.clone();
//     boolean var69 = var67.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var70 = null;
//     org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot(var63, (org.jfree.chart.axis.ValueAxis)var65, (org.jfree.chart.axis.ValueAxis)var67, var70);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var74 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var76 = var74.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot(var61, var62, (org.jfree.chart.axis.ValueAxis)var67, (org.jfree.chart.renderer.category.CategoryItemRenderer)var74);
//     org.jfree.chart.LegendItemCollection var78 = null;
//     var77.setFixedLegendItems(var78);
//     org.jfree.data.general.DatasetChangeEvent var80 = null;
//     var77.datasetChanged(var80);
//     org.jfree.chart.LegendItemCollection var82 = var77.getLegendItems();
//     org.jfree.data.category.CategoryDataset var84 = var77.getDataset(0);
//     org.jfree.chart.axis.AxisLocation var86 = var77.getRangeAxisLocation(2);
//     var56.setRangeAxisLocation(2, var86);
//     var16.setDomainAxisLocation(15, var86, false);
//     
//     // Checks the contract:  equals-hashcode on var10 and var71
//     assertTrue("Contract failed: equals-hashcode on var10 and var71", var10.equals(var71) ? var10.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var10
//     assertTrue("Contract failed: equals-hashcode on var71 and var10", var71.equals(var10) ? var71.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var2 = var0.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.AreaRendererEndType var3 = var0.getEndType();
    org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
    org.jfree.chart.entity.EntityCollection var6 = null;
    org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo(var6);
    org.jfree.chart.entity.EntityCollection var8 = var7.getEntityCollection();
    java.awt.geom.Rectangle2D var9 = var7.getChartArea();
    java.awt.geom.Rectangle2D var12 = var5.createInsetRectangle(var9, true, true);
    boolean var13 = var3.equals((java.lang.Object)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("Category Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Size2D[width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(2, var1);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var1 = var0.getLegendLabelURLGenerator();
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelDistributor(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Object var3 = var2.clone();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var9 = var7.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var11 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var7.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var11);
//     var2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var11, true);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var17 = null;
//     var15.setQuadrantPaint(1, var17);
//     var15.configureDomainAxes();
//     java.awt.Font var20 = var15.getNoDataMessageFont();
//     java.awt.Paint var21 = var15.getDomainGridlinePaint();
//     var2.setBasePaint(var21);
//     org.jfree.chart.labels.ItemLabelPosition var25 = var2.getNegativeItemLabelPosition(10, 10);
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Image var28 = var27.getBackgroundImage();
//     float var29 = var27.getBackgroundAlpha();
//     java.awt.Stroke var30 = var27.getDomainZeroBaselineStroke();
//     var2.setSeriesStroke(1969, var30, false);
//     
//     // Checks the contract:  equals-hashcode on var15 and var27
//     assertTrue("Contract failed: equals-hashcode on var15 and var27", var15.equals(var27) ? var15.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var15
//     assertTrue("Contract failed: equals-hashcode on var27 and var15", var27.equals(var15) ? var27.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.data.time.TimePeriod var1 = null;
//     org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var1);
//     var2.setPercentComplete((java.lang.Double)0.2d);
//     java.lang.Double var5 = var2.getPercentComplete();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var11 = var10.clone();
//     boolean var12 = var10.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var13);
//     org.jfree.data.Range var15 = var10.getRange();
//     org.jfree.data.Range var18 = org.jfree.data.Range.expand(var15, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange(var18);
//     java.util.Date var20 = var19.getLowerDate();
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var20);
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(var20);
//     var2.setDuration((org.jfree.data.time.TimePeriod)var22);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var29 = var28.clone();
//     boolean var30 = var28.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var28, var31);
//     org.jfree.data.Range var33 = var28.getRange();
//     org.jfree.data.Range var36 = org.jfree.data.Range.expand(var33, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var37 = new org.jfree.data.time.DateRange(var36);
//     java.util.Date var38 = var37.getLowerDate();
//     org.jfree.data.time.Month var39 = new org.jfree.data.time.Month(var38);
//     int var40 = var39.getYearValue();
//     var2.setDuration((org.jfree.data.time.TimePeriod)var39);
//     
//     // Checks the contract:  equals-hashcode on var14 and var32
//     assertTrue("Contract failed: equals-hashcode on var14 and var32", var14.equals(var32) ? var14.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var14
//     assertTrue("Contract failed: equals-hashcode on var32 and var14", var32.equals(var14) ? var32.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var8 = var7.clone();
    boolean var9 = var7.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.data.general.DatasetChangeEvent var20 = null;
    var17.datasetChanged(var20);
    org.jfree.chart.LegendItemCollection var22 = var17.getLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var23 = var17.getDatasetRenderingOrder();
    org.jfree.chart.axis.ValueAxis var25 = var17.getRangeAxisForDataset((-1));
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var0, var25, var26);
    var27.setAngleLabelsVisible(false);
    var27.removeCornerTextItem("");
    var27.removeCornerTextItem("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    var27.setRenderer(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var12, "hi!", "", "hi!");
    java.awt.Image var20 = null;
    org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var20, "hi!", "", "hi!");
    var16.addLibrary((org.jfree.chart.ui.Library)var24);
    boolean var26 = var8.equals((java.lang.Object)var24);
    java.awt.Paint var28 = var8.lookupSeriesFillPaint(100);
    java.awt.Paint var30 = var8.getSeriesOutlinePaint(1);
    java.lang.Number var32 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var33 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var32);
    boolean var34 = var8.equals((java.lang.Object)var32);
    java.lang.Boolean var36 = var8.getSeriesCreateEntities(10);
    java.awt.Paint var37 = var8.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var44 = null;
    org.jfree.chart.ui.ProjectInfo var48 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var44, "hi!", "", "hi!");
    java.awt.Image var52 = null;
    org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var52, "hi!", "", "hi!");
    var48.addLibrary((org.jfree.chart.ui.Library)var56);
    boolean var58 = var40.equals((java.lang.Object)var56);
    var40.setUseOutlinePaint(false);
    java.awt.Stroke var63 = var40.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(1.0d, var37, var63);
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var64);
    java.awt.geom.Point2D var66 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantOrigin(var66);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    var4.setAutoRangeStickyZero(false);
    var4.setFixedAutoRange(10.0d);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    java.awt.Image var30 = null;
    org.jfree.chart.ui.ProjectInfo var34 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var30, "hi!", "", "hi!");
    var26.addLibrary((org.jfree.chart.ui.Library)var34);
    boolean var36 = var18.equals((java.lang.Object)var34);
    java.awt.Paint var38 = var18.lookupSeriesFillPaint(100);
    java.awt.Paint var40 = var18.getSeriesOutlinePaint(1);
    java.lang.Number var42 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var43 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var42);
    boolean var44 = var18.equals((java.lang.Object)var42);
    java.lang.Boolean var46 = var18.getSeriesCreateEntities(10);
    java.awt.Paint var47 = var18.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var54 = null;
    org.jfree.chart.ui.ProjectInfo var58 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var54, "hi!", "", "hi!");
    java.awt.Image var62 = null;
    org.jfree.chart.ui.ProjectInfo var66 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var62, "hi!", "", "hi!");
    var58.addLibrary((org.jfree.chart.ui.Library)var66);
    boolean var68 = var50.equals((java.lang.Object)var66);
    var50.setUseOutlinePaint(false);
    java.awt.Stroke var73 = var50.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var74 = new org.jfree.chart.plot.ValueMarker(1.0d, var47, var73);
    java.awt.Color var76 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    var74.setPaint((java.awt.Paint)var76);
    java.awt.Color var78 = var76.brighter();
    var4.setAxisLinePaint((java.awt.Paint)var76);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var80 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=0,g=0,b=0]", var1, (java.awt.Paint)var76);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    var2.setSeriesShapesVisible(1, false);
    java.awt.Paint var25 = var2.getSeriesPaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getRowKey(1969);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    org.jfree.data.Range var4 = var2.getHeightRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 10.0d, 1.0E-8d, (-1.0d), 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Image var1 = var0.getBackgroundImage();
    org.jfree.chart.plot.DrawingSupplier var2 = var0.getDrawingSupplier();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var11 = var10.clone();
    boolean var12 = var10.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var13);
    org.jfree.data.Range var15 = var10.getRange();
    org.jfree.data.Range var18 = org.jfree.data.Range.expand(var15, 10.0d, 0.0d);
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange(var18);
    var4.setRangeWithMargins(var18, false, true);
    boolean var23 = var0.equals((java.lang.Object)true);
    org.jfree.chart.annotations.XYAnnotation var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var25 = var0.removeAnnotation(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var2 = null;
//     var0.setQuadrantPaint(1, var2);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var10 = null;
//     org.jfree.chart.ui.ProjectInfo var14 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var10, "hi!", "", "hi!");
//     java.awt.Image var18 = null;
//     org.jfree.chart.ui.ProjectInfo var22 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var18, "hi!", "", "hi!");
//     var14.addLibrary((org.jfree.chart.ui.Library)var22);
//     boolean var24 = var6.equals((java.lang.Object)var22);
//     java.awt.Paint var26 = var6.lookupSeriesFillPaint(100);
//     var0.setBackgroundPaint(var26);
//     java.awt.Stroke var28 = var0.getDomainGridlineStroke();
//     org.jfree.chart.event.RendererChangeEvent var29 = null;
//     var0.rendererChanged(var29);
//     var0.clearRangeMarkers(100);
//     boolean var33 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     var0.handleClick(1, 0, var36);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, (-1.0d), 0.05d, 15, (java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Image var1 = var0.getBackgroundImage();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.AxisSpace var3 = new org.jfree.chart.axis.AxisSpace();
//     var0.setFixedRangeAxisSpace(var3);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, Double.NEGATIVE_INFINITY);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     java.awt.Image var22 = null;
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
//     var18.addLibrary((org.jfree.chart.ui.Library)var26);
//     boolean var28 = var10.equals((java.lang.Object)var26);
//     java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var33 = null;
//     var31.setQuadrantPaint(1, var33);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var41 = null;
//     org.jfree.chart.ui.ProjectInfo var45 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var41, "hi!", "", "hi!");
//     java.awt.Image var49 = null;
//     org.jfree.chart.ui.ProjectInfo var53 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var49, "hi!", "", "hi!");
//     var45.addLibrary((org.jfree.chart.ui.Library)var53);
//     boolean var55 = var37.equals((java.lang.Object)var53);
//     java.awt.Paint var57 = var37.lookupSeriesFillPaint(100);
//     var31.setBackgroundPaint(var57);
//     boolean var59 = org.jfree.chart.util.PaintUtilities.equal(var30, var57);
//     var7.setBaseOutlinePaint(var30);
//     boolean var61 = var3.equals((java.lang.Object)var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var31
//     assertTrue("Contract failed: equals-hashcode on var0 and var31", var0.equals(var31) ? var0.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var0
//     assertTrue("Contract failed: equals-hashcode on var31 and var0", var31.equals(var0) ? var31.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var6 = var5.clone();
//     boolean var7 = var5.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var5, var8);
//     org.jfree.chart.plot.Plot var10 = var3.getPlot();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var13 = var12.clone();
//     boolean var14 = var12.isTickMarksVisible();
//     boolean var15 = var12.isTickLabelsVisible();
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var12.java2DToValue((-1.0d), var17, var18);
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var12, var20);
//     
//     // Checks the contract:  equals-hashcode on var9 and var21
//     assertTrue("Contract failed: equals-hashcode on var9 and var21", var9.equals(var21) ? var9.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var9
//     assertTrue("Contract failed: equals-hashcode on var21 and var9", var21.equals(var9) ? var21.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Image var1 = var0.getBackgroundImage();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     org.jfree.data.xy.XYDataset var4 = null;
//     int var5 = var2.indexOf(var4);
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var14 = var13.clone();
//     boolean var15 = var13.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var13, var16);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var22 = var20.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var7, var8, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     org.jfree.chart.LegendItemCollection var24 = null;
//     var23.setFixedLegendItems(var24);
//     org.jfree.data.general.DatasetChangeEvent var26 = null;
//     var23.datasetChanged(var26);
//     org.jfree.chart.LegendItemCollection var28 = var23.getLegendItems();
//     org.jfree.data.category.CategoryDataset var30 = var23.getDataset(0);
//     org.jfree.chart.axis.AxisLocation var32 = var23.getRangeAxisLocation(2);
//     var2.setRangeAxisLocation(2, var32);
//     var0.setRangeAxisLocation(var32);
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     var0.handleClick(1, 0, var37);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     java.awt.Font var7 = var4.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     java.awt.Image var22 = null;
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
//     var18.addLibrary((org.jfree.chart.ui.Library)var26);
//     boolean var28 = var10.equals((java.lang.Object)var26);
//     java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
//     java.awt.Font var33 = var32.getFont();
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var37 = var36.clone();
//     boolean var38 = var36.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var41 = var40.clone();
//     var40.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
//     java.awt.Font var48 = var45.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var45);
//     org.jfree.chart.util.HorizontalAlignment var50 = null;
//     org.jfree.chart.util.VerticalAlignment var51 = null;
//     org.jfree.chart.block.FlowArrangement var54 = new org.jfree.chart.block.FlowArrangement(var50, var51, (-1.0d), 0.0d);
//     org.jfree.chart.util.HorizontalAlignment var55 = null;
//     org.jfree.chart.util.VerticalAlignment var56 = null;
//     org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 0.0d, 0.05d);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45, (org.jfree.chart.block.Arrangement)var54, (org.jfree.chart.block.Arrangement)var59);
//     org.jfree.chart.util.HorizontalAlignment var61 = null;
//     org.jfree.chart.util.VerticalAlignment var62 = null;
//     org.jfree.chart.block.FlowArrangement var65 = new org.jfree.chart.block.FlowArrangement(var61, var62, 0.0d, 0.05d);
//     org.jfree.data.general.Dataset var66 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var68 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var65, var66, (java.lang.Comparable)"12/31/69");
//     java.lang.Comparable var69 = var68.getSeriesKey();
//     java.awt.Graphics2D var70 = null;
//     org.jfree.chart.block.RectangleConstraint var73 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
//     org.jfree.chart.block.LengthConstraintType var74 = var73.getWidthConstraintType();
//     org.jfree.chart.block.LengthConstraintType var75 = var73.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var76 = var73.toUnconstrainedWidth();
//     org.jfree.chart.util.Size2D var77 = var59.arrange((org.jfree.chart.block.BlockContainer)var68, var70, var76);
//     
//     // Checks the contract:  equals-hashcode on var59 and var65
//     assertTrue("Contract failed: equals-hashcode on var59 and var65", var59.equals(var65) ? var59.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var59
//     assertTrue("Contract failed: equals-hashcode on var65 and var59", var65.equals(var59) ? var65.hashCode() == var59.hashCode() : true);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     var16.setRangeCrosshairLockedOnData(false);
//     var16.clearRangeMarkers();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleEdge var29 = null;
//     double var30 = var25.getCategoryEnd(0, 0, var28, var29);
//     float var31 = var25.getMaximumCategoryLabelWidthRatio();
//     var25.setCategoryLabelPositionOffset(1);
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var35.setTickMarkOutsideLength(10.0f);
//     org.jfree.chart.axis.CategoryLabelPositions var38 = var35.getCategoryLabelPositions();
//     var25.setCategoryLabelPositions(var38);
//     int var40 = var16.getDomainAxisIndex(var25);
//     java.lang.String var41 = var16.getPlotType();
//     org.jfree.chart.axis.AxisLocation var43 = var16.getDomainAxisLocation(15);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var47 = var46.clone();
//     boolean var48 = var46.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var51 = var50.clone();
//     var50.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var54 = null;
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot(var44, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.chart.axis.ValueAxis)var50, var54);
//     java.awt.Font var56 = var46.getLabelFont();
//     org.jfree.data.Range var57 = var16.getDataRange((org.jfree.chart.axis.ValueAxis)var46);
//     
//     // Checks the contract:  equals-hashcode on var10 and var55
//     assertTrue("Contract failed: equals-hashcode on var10 and var55", var10.equals(var55) ? var10.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var10
//     assertTrue("Contract failed: equals-hashcode on var55 and var10", var55.equals(var10) ? var55.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var3.isTickMarksVisible();
//     java.awt.Font var6 = var3.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var13 = null;
//     org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
//     java.awt.Image var21 = null;
//     org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
//     var17.addLibrary((org.jfree.chart.ui.Library)var25);
//     boolean var27 = var9.equals((java.lang.Object)var25);
//     java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
//     java.awt.Font var32 = var31.getFont();
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var36 = var35.clone();
//     boolean var37 = var35.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var40 = var39.clone();
//     var39.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var43);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var44, true);
//     java.awt.Paint var47 = var46.getBorderPaint();
//     java.awt.RenderingHints var48 = null;
//     var46.setRenderingHints(var48);
// 
//   }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     java.awt.Font var7 = var4.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     java.awt.Image var22 = null;
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
//     var18.addLibrary((org.jfree.chart.ui.Library)var26);
//     boolean var28 = var10.equals((java.lang.Object)var26);
//     java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
//     java.awt.Font var33 = var32.getFont();
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var37 = var36.clone();
//     boolean var38 = var36.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var41 = var40.clone();
//     var40.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
//     org.jfree.chart.event.ChartChangeEventType var48 = null;
//     org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var47, var48);
//     int var50 = var47.getBackgroundImageAlignment();
//     java.lang.Object var51 = var47.getTextAntiAlias();
//     java.awt.Graphics2D var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     var47.draw(var52, var53);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    double var4 = var3.getBase();
    org.jfree.data.category.DefaultCategoryDataset var5 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Object var7 = var5.clone();
    boolean var8 = var3.equals((java.lang.Object)var5);
    org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)true);
    double var11 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var10);
    org.jfree.data.general.PieDataset var14 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var10, (java.lang.Comparable)2, 1.05d);
    var0.setDataset(var10);
    java.awt.Paint var16 = var0.getLabelLinkPaint();
    java.awt.Paint var17 = var0.getShadowPaint();
    var0.setCircular(false);
    org.jfree.chart.plot.AbstractPieLabelDistributor var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelDistributor(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0d+ "'", var6.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(1.0d, Double.POSITIVE_INFINITY);
//     java.lang.String var3 = var2.toString();
//     org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange(1.0d, Double.POSITIVE_INFINITY);
//     java.lang.String var7 = var6.toString();
//     org.jfree.data.Range var8 = org.jfree.data.Range.combine((org.jfree.data.Range)var2, (org.jfree.data.Range)var6);
//     org.jfree.data.Range var11 = org.jfree.data.Range.shift((org.jfree.data.Range)var2, 0.0d, false);
//     boolean var14 = var2.intersects(0.2d, 0.65d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]"+ "'", var3.equals("[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]"+ "'", var7.equals("[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var7 = null;
    org.jfree.chart.ui.ProjectInfo var11 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var7, "hi!", "", "hi!");
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
    var11.addLibrary((org.jfree.chart.ui.Library)var19);
    boolean var21 = var3.equals((java.lang.Object)var19);
    java.awt.Paint var23 = var3.lookupSeriesFillPaint(100);
    java.awt.Paint var25 = var3.getSeriesOutlinePaint(1);
    java.lang.Number var27 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var28 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var27);
    boolean var29 = var3.equals((java.lang.Object)var27);
    boolean var30 = var0.equals((java.lang.Object)var29);
    java.lang.String var31 = var0.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "NOID"+ "'", var31.equals("NOID"));

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, var1);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("-10,-10,-10,-10,0,0,10,-10,10,-10,0,0,10,10,10,10,0,0,-10,10,-10,10,0,0,0,0");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    java.awt.Font var48 = var45.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var45);
    org.jfree.chart.util.HorizontalAlignment var50 = null;
    org.jfree.chart.util.VerticalAlignment var51 = null;
    org.jfree.chart.block.FlowArrangement var54 = new org.jfree.chart.block.FlowArrangement(var50, var51, (-1.0d), 0.0d);
    org.jfree.chart.util.HorizontalAlignment var55 = null;
    org.jfree.chart.util.VerticalAlignment var56 = null;
    org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 0.0d, 0.05d);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45, (org.jfree.chart.block.Arrangement)var54, (org.jfree.chart.block.Arrangement)var59);
    org.jfree.chart.util.RectangleInsets var61 = var60.getLegendItemGraphicPadding();
    double var63 = var61.calculateRightInset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 2.0d);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
//     org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var4 = new org.jfree.chart.util.Size2D();
//     java.lang.String var5 = var4.toString();
//     org.jfree.chart.util.Size2D var6 = var2.calculateConstrainedSize(var4);
//     org.jfree.chart.block.RectangleConstraint var7 = var2.toUnconstrainedWidth();
//     org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange(1.0d, Double.POSITIVE_INFINITY);
//     java.lang.String var11 = var10.toString();
//     org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange(1.0d, Double.POSITIVE_INFINITY);
//     java.lang.String var15 = var14.toString();
//     org.jfree.data.Range var16 = org.jfree.data.Range.combine((org.jfree.data.Range)var10, (org.jfree.data.Range)var14);
//     org.jfree.chart.block.RectangleConstraint var17 = var2.toRangeWidth((org.jfree.data.Range)var14);
//     org.jfree.data.Range var19 = org.jfree.data.Range.shift((org.jfree.data.Range)var14, Double.NEGATIVE_INFINITY);
//     
//     // Checks the contract:  var19.equals(var19)
//     assertTrue("Contract failed: var19.equals(var19)", var19.equals(var19));
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    double var3 = var2.getBase();
    org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var4);
    java.lang.Object var6 = var4.clone();
    boolean var7 = var2.equals((java.lang.Object)var4);
    org.jfree.data.time.TimePeriod var10 = null;
    org.jfree.data.gantt.Task var11 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var10);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var17 = var16.clone();
    boolean var18 = var16.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var16, var19);
    org.jfree.data.Range var21 = var16.getRange();
    org.jfree.data.Range var24 = org.jfree.data.Range.expand(var21, 10.0d, 0.0d);
    org.jfree.data.time.DateRange var25 = new org.jfree.data.time.DateRange(var24);
    java.util.Date var26 = var25.getLowerDate();
    org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(var26);
    org.jfree.data.time.Month var28 = new org.jfree.data.time.Month(var26);
    var11.setDuration((org.jfree.data.time.TimePeriod)var28);
    var4.addValue((java.lang.Number)(short)10, (java.lang.Comparable)var28, (java.lang.Comparable)"Range[0.0,1.05]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.removeRow(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0d+ "'", var5.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange(1.0d, Double.POSITIVE_INFINITY);
//     java.lang.String var4 = var3.toString();
//     org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange(1.0d, Double.POSITIVE_INFINITY);
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.Range var9 = org.jfree.data.Range.combine((org.jfree.data.Range)var3, (org.jfree.data.Range)var7);
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
//     org.jfree.chart.block.LengthConstraintType var13 = var12.getWidthConstraintType();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var20 = var19.clone();
//     boolean var21 = var19.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var19, var22);
//     var17.setAutoRangeStickyZero(false);
//     var17.setFixedAutoRange(10.0d);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var33 = var32.clone();
//     boolean var34 = var32.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.axis.ValueAxis)var32, var35);
//     org.jfree.data.Range var37 = var32.getRange();
//     org.jfree.data.Range var40 = org.jfree.data.Range.expand(var37, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange(var40);
//     java.util.Date var42 = var41.getLowerDate();
//     var17.setRangeWithMargins((org.jfree.data.Range)var41, false, false);
//     org.jfree.chart.block.RectangleConstraint var48 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
//     org.jfree.chart.block.LengthConstraintType var49 = var48.getWidthConstraintType();
//     org.jfree.chart.block.LengthConstraintType var50 = var48.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(1.05d, var9, var13, 0.2d, (org.jfree.data.Range)var41, var50);
//     java.lang.String var52 = var41.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]"+ "'", var4.equals("[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]"+ "'", var8.equals("[Dec 31, 1969 4:00:00 PM --> Aug 16, 292278994 11:12:55 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + "[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var52.equals("[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]"));
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var8 = var7.clone();
    boolean var9 = var7.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    boolean var18 = var0.equals((java.lang.Object)var2);
    java.lang.String var19 = var0.getID();
    java.lang.Object var20 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "NOID"+ "'", var19.equals("NOID"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    java.awt.geom.Point2D var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Set var1 = var0.keySet();
    java.util.Set var2 = var0.keySet();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     org.jfree.data.Range var9 = var4.getRange();
//     org.jfree.data.Range var12 = org.jfree.data.Range.expand(var9, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange(var12);
//     java.util.Date var14 = var13.getLowerDate();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year(var14);
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var23 = var22.clone();
//     boolean var24 = var22.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var22, var25);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var31 = var29.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var16, var17, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var39 = null;
//     org.jfree.chart.ui.ProjectInfo var43 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var39, "hi!", "", "hi!");
//     java.awt.Image var47 = null;
//     org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
//     var43.addLibrary((org.jfree.chart.ui.Library)var51);
//     boolean var53 = var35.equals((java.lang.Object)var51);
//     java.awt.Paint var55 = var35.lookupSeriesFillPaint(100);
//     java.awt.Paint var57 = var35.getSeriesOutlinePaint(1);
//     java.lang.Number var59 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var60 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var59);
//     boolean var61 = var35.equals((java.lang.Object)var59);
//     java.lang.Boolean var63 = var35.getSeriesCreateEntities(10);
//     var32.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
//     java.lang.Object var65 = var32.clone();
//     org.jfree.chart.axis.CategoryAnchor var66 = var32.getDomainGridlinePosition();
//     int var67 = var15.compareTo((java.lang.Object)var32);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     boolean var1 = var0.getBaseItemLabelsVisible();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var11 = var10.clone();
//     boolean var12 = var10.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var19 = var17.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
//     org.jfree.chart.LegendItemCollection var21 = null;
//     var20.setFixedLegendItems(var21);
//     org.jfree.data.general.DatasetChangeEvent var23 = null;
//     var20.datasetChanged(var23);
//     org.jfree.chart.LegendItemCollection var25 = var20.getLegendItems();
//     org.jfree.chart.plot.DatasetRenderingOrder var26 = var20.getDatasetRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var29 = var0.initialise(var2, var3, var20, 100, var28);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var33 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var32};
//     var31.setRenderers(var33);
//     int var35 = var31.getDomainAxisCount();
//     var31.configureRangeAxes();
//     var31.setDomainCrosshairValue(10.0d, false);
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var42 = null;
//     var40.setQuadrantPaint(1, var42);
//     boolean var44 = var40.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.AxisSpace var45 = var40.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = var40.getRenderer(0);
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = var40.getRenderer();
//     java.awt.Graphics2D var49 = null;
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var56 = var55.clone();
//     boolean var57 = var55.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var51, (org.jfree.chart.axis.ValueAxis)var53, (org.jfree.chart.axis.ValueAxis)var55, var58);
//     java.awt.Font var64 = null;
//     org.jfree.chart.axis.MarkerAxisBand var65 = new org.jfree.chart.axis.MarkerAxisBand(var53, (-1.0d), (-1.0d), 100.0d, 10.0d, var64);
//     java.awt.Graphics2D var66 = null;
//     org.jfree.chart.axis.AxisState var67 = null;
//     java.awt.geom.Rectangle2D var68 = null;
//     org.jfree.chart.util.RectangleEdge var69 = null;
//     java.util.List var70 = var53.refreshTicks(var66, var67, var68, var69);
//     java.util.Collection var71 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var70);
//     var40.drawDomainTickBands(var49, var50, var70);
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     java.awt.geom.Point2D var76 = null;
//     var40.zoomRangeAxes(0.0d, 0.0d, var75, var76);
//     org.jfree.chart.axis.ValueAxis var79 = var40.getDomainAxis(15);
//     org.jfree.chart.axis.AxisLocation var81 = var40.getDomainAxisLocation(15);
//     var31.setRangeAxisLocation(var81);
//     var20.setRangeAxisLocation(2, var81, false);
//     
//     // Checks the contract:  equals-hashcode on var14 and var59
//     assertTrue("Contract failed: equals-hashcode on var14 and var59", var14.equals(var59) ? var14.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var14
//     assertTrue("Contract failed: equals-hashcode on var59 and var14", var59.equals(var14) ? var59.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var1);
    java.util.List var3 = var1.getRowKeys();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = null;
    var4.setQuadrantPaint(1, var6);
    var4.configureDomainAxes();
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
    var1.setValue(10.0d, (java.lang.Comparable)"[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]", (java.lang.Comparable)(-2649600000L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var15 = new org.jfree.chart.title.LegendItemBlockContainer(var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)8.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.0d+ "'", var2.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    org.jfree.chart.event.ChartChangeEventType var48 = null;
    org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var47, var48);
    org.jfree.chart.event.ChartProgressListener var50 = null;
    var47.addProgressListener(var50);
    org.jfree.chart.event.ChartChangeListener var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var47.addChangeListener(var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var10 = null;
    org.jfree.chart.ui.ProjectInfo var14 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var10, "hi!", "", "hi!");
    java.awt.Image var18 = null;
    org.jfree.chart.ui.ProjectInfo var22 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var18, "hi!", "", "hi!");
    var14.addLibrary((org.jfree.chart.ui.Library)var22);
    boolean var24 = var6.equals((java.lang.Object)var22);
    java.awt.Paint var26 = var6.lookupSeriesFillPaint(100);
    var0.setBackgroundPaint(var26);
    java.awt.Stroke var28 = var0.getDomainGridlineStroke();
    org.jfree.chart.event.RendererChangeEvent var29 = null;
    var0.rendererChanged(var29);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var38 = null;
    org.jfree.chart.ui.ProjectInfo var42 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var38, "hi!", "", "hi!");
    java.awt.Image var46 = null;
    org.jfree.chart.ui.ProjectInfo var50 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var46, "hi!", "", "hi!");
    var42.addLibrary((org.jfree.chart.ui.Library)var50);
    boolean var52 = var34.equals((java.lang.Object)var50);
    java.awt.Paint var54 = var34.lookupSeriesFillPaint(100);
    java.awt.Paint var56 = var34.getSeriesOutlinePaint(1);
    java.lang.Number var58 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var59 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var58);
    boolean var60 = var34.equals((java.lang.Object)var58);
    java.lang.Boolean var62 = var34.getSeriesCreateEntities(10);
    java.awt.Paint var63 = var34.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var66 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var70 = null;
    org.jfree.chart.ui.ProjectInfo var74 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var70, "hi!", "", "hi!");
    java.awt.Image var78 = null;
    org.jfree.chart.ui.ProjectInfo var82 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var78, "hi!", "", "hi!");
    var74.addLibrary((org.jfree.chart.ui.Library)var82);
    boolean var84 = var66.equals((java.lang.Object)var82);
    var66.setUseOutlinePaint(false);
    java.awt.Stroke var89 = var66.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var90 = new org.jfree.chart.plot.ValueMarker(1.0d, var63, var89);
    var0.setRangeTickBandPaint(var63);
    java.awt.Font var92 = var0.getNoDataMessageFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var3 = var2.clone();
//     boolean var4 = var2.isTickMarksVisible();
//     java.awt.Font var5 = var2.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var12 = null;
//     org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var12, "hi!", "", "hi!");
//     java.awt.Image var20 = null;
//     org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var20, "hi!", "", "hi!");
//     var16.addLibrary((org.jfree.chart.ui.Library)var24);
//     boolean var26 = var8.equals((java.lang.Object)var24);
//     java.awt.Paint var28 = var8.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("", var5, var28, 0.0f);
//     java.awt.Paint var31 = var30.getPaint();
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.util.Size2D var33 = var30.calculateDimensions(var32);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var1.getCategoryEnd(0, 0, var4, var5);
//     var1.configure();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Object var12 = var11.clone();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var18 = var16.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var20 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var16.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var20);
//     var11.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var20, true);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var26 = null;
//     var24.setQuadrantPaint(1, var26);
//     var24.configureDomainAxes();
//     java.awt.Font var29 = var24.getNoDataMessageFont();
//     java.awt.Paint var30 = var24.getDomainGridlinePaint();
//     var11.setBasePaint(var30);
//     var1.setTickLabelPaint((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", var30);
//     boolean var33 = var1.isTickLabelsVisible();
//     org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var37 = var36.getInsets();
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Image var40 = var39.getBackgroundImage();
//     float var41 = var39.getBackgroundAlpha();
//     java.awt.Stroke var42 = var39.getDomainZeroBaselineStroke();
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     org.jfree.chart.entity.EntityCollection var44 = null;
//     org.jfree.chart.ChartRenderingInfo var45 = new org.jfree.chart.ChartRenderingInfo(var44);
//     org.jfree.chart.entity.EntityCollection var46 = var45.getEntityCollection();
//     java.awt.geom.Rectangle2D var47 = var45.getChartArea();
//     org.jfree.chart.entity.ChartEntity var50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var47, "VerticalAlignment.CENTER", "Category Plot");
//     var43.setBounds(var47);
//     var36.draw(var38, var47);
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var60 = var59.clone();
//     boolean var61 = var59.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var62 = null;
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot(var55, (org.jfree.chart.axis.ValueAxis)var57, (org.jfree.chart.axis.ValueAxis)var59, var62);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var66 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var68 = var66.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot(var53, var54, (org.jfree.chart.axis.ValueAxis)var59, (org.jfree.chart.renderer.category.CategoryItemRenderer)var66);
//     org.jfree.chart.LegendItemCollection var70 = null;
//     var69.setFixedLegendItems(var70);
//     org.jfree.data.general.DatasetChangeEvent var72 = null;
//     var69.datasetChanged(var72);
//     var69.setRangeCrosshairLockedOnData(false);
//     var69.clearRangeMarkers();
//     org.jfree.chart.util.RectangleEdge var78 = var69.getDomainAxisEdge(10);
//     org.jfree.chart.util.RectangleEdge var79 = org.jfree.chart.util.RectangleEdge.opposite(var78);
//     double var80 = var1.getCategoryStart(0, 15, var47, var79);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var66 and var16.", var66.equals(var16) == var16.equals(var66));
//     
//     // Checks the contract:  equals-hashcode on var24 and var39
//     assertTrue("Contract failed: equals-hashcode on var24 and var39", var24.equals(var39) ? var24.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var24
//     assertTrue("Contract failed: equals-hashcode on var39 and var24", var39.equals(var24) ? var39.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getLabelAngle();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
//     org.jfree.chart.entity.EntityCollection var6 = null;
//     org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo(var6);
//     org.jfree.chart.entity.EntityCollection var8 = var7.getEntityCollection();
//     java.awt.geom.Rectangle2D var9 = var7.getChartArea();
//     java.awt.geom.Rectangle2D var12 = var5.createInsetRectangle(var9, true, true);
//     org.jfree.chart.entity.EntityCollection var13 = null;
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo(var13);
//     org.jfree.chart.entity.EntityCollection var15 = var14.getEntityCollection();
//     java.awt.geom.Rectangle2D var16 = var14.getChartArea();
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var16, "VerticalAlignment.CENTER", "Category Plot");
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var27 = var26.clone();
//     boolean var28 = var26.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var29);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var35 = var33.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var20, var21, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
//     org.jfree.chart.LegendItemCollection var37 = null;
//     var36.setFixedLegendItems(var37);
//     org.jfree.data.general.DatasetChangeEvent var39 = null;
//     var36.datasetChanged(var39);
//     var36.setRangeCrosshairLockedOnData(false);
//     var36.clearRangeMarkers();
//     org.jfree.chart.util.RectangleEdge var45 = var36.getDomainAxisEdge(10);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     org.jfree.chart.axis.AxisState var47 = var0.draw(var2, Double.NEGATIVE_INFINITY, var9, var16, var45, var46);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var4 = var3.clone();
    boolean var5 = var3.isTickMarksVisible();
    java.awt.Font var6 = var3.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
    java.awt.Image var21 = null;
    org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
    var17.addLibrary((org.jfree.chart.ui.Library)var25);
    boolean var27 = var9.equals((java.lang.Object)var25);
    java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
    java.awt.Font var32 = var31.getFont();
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var36 = var35.clone();
    boolean var37 = var35.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var40 = var39.clone();
    var39.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var43);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var44, true);
    java.awt.Image var47 = null;
    var46.setBackgroundImage(var47);
    var46.setBackgroundImageAlpha(100.0f);
    org.jfree.chart.util.StrokeList var51 = new org.jfree.chart.util.StrokeList();
    org.jfree.chart.renderer.category.LayeredBarRenderer var53 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var56 = var53.getItemOutlinePaint(100, 0);
    java.awt.Paint var57 = var53.getBasePaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var62 = var61.clone();
    org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var65 = null;
    var63.setQuadrantPaint(1, var65);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var69 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var73 = null;
    org.jfree.chart.ui.ProjectInfo var77 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var73, "hi!", "", "hi!");
    java.awt.Image var81 = null;
    org.jfree.chart.ui.ProjectInfo var85 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var81, "hi!", "", "hi!");
    var77.addLibrary((org.jfree.chart.ui.Library)var85);
    boolean var87 = var69.equals((java.lang.Object)var85);
    java.awt.Paint var89 = var69.lookupSeriesFillPaint(100);
    var63.setBackgroundPaint(var89);
    java.awt.Stroke var91 = var63.getDomainGridlineStroke();
    var61.setBaseStroke(var91, false);
    var53.setSeriesOutlineStroke(100, var91);
    var51.setStroke(96, var91);
    var46.setBorderStroke(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    double var4 = var3.getBase();
    org.jfree.data.category.DefaultCategoryDataset var5 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Object var7 = var5.clone();
    boolean var8 = var3.equals((java.lang.Object)var5);
    org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)true);
    double var11 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var10);
    org.jfree.data.general.PieDataset var14 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var10, (java.lang.Comparable)2, 1.05d);
    var0.setDataset(var10);
    var0.setBackgroundAlpha(0.5f);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var25 = null;
    org.jfree.chart.ui.ProjectInfo var29 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var25, "hi!", "", "hi!");
    java.awt.Image var33 = null;
    org.jfree.chart.ui.ProjectInfo var37 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var33, "hi!", "", "hi!");
    var29.addLibrary((org.jfree.chart.ui.Library)var37);
    boolean var39 = var21.equals((java.lang.Object)var37);
    java.awt.Paint var41 = var21.lookupSeriesFillPaint(100);
    java.awt.Paint var43 = var21.getSeriesOutlinePaint(1);
    java.lang.Number var45 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var46 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var45);
    boolean var47 = var21.equals((java.lang.Object)var45);
    java.lang.Boolean var49 = var21.getSeriesCreateEntities(10);
    java.awt.Paint var50 = var21.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var53 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var57 = null;
    org.jfree.chart.ui.ProjectInfo var61 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var57, "hi!", "", "hi!");
    java.awt.Image var65 = null;
    org.jfree.chart.ui.ProjectInfo var69 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var65, "hi!", "", "hi!");
    var61.addLibrary((org.jfree.chart.ui.Library)var69);
    boolean var71 = var53.equals((java.lang.Object)var69);
    var53.setUseOutlinePaint(false);
    java.awt.Stroke var76 = var53.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var77 = new org.jfree.chart.plot.ValueMarker(1.0d, var50, var76);
    var77.setLabel("hi!");
    java.awt.Paint var80 = var77.getPaint();
    var0.setLabelLinkPaint(var80);
    org.jfree.chart.plot.PiePlot var82 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var85 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    double var86 = var85.getBase();
    org.jfree.data.category.DefaultCategoryDataset var87 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var88 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var87);
    java.lang.Object var89 = var87.clone();
    boolean var90 = var85.equals((java.lang.Object)var87);
    org.jfree.data.general.PieDataset var92 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var87, (java.lang.Comparable)true);
    double var93 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var92);
    org.jfree.data.general.PieDataset var96 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var92, (java.lang.Comparable)2, 1.05d);
    var82.setDataset(var92);
    java.awt.Paint var98 = var82.getLabelLinkPaint();
    var0.setLabelLinkPaint(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0d+ "'", var6.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + 0.0d+ "'", var88.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     java.awt.Font var7 = var4.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     java.awt.Image var22 = null;
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
//     var18.addLibrary((org.jfree.chart.ui.Library)var26);
//     boolean var28 = var10.equals((java.lang.Object)var26);
//     java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
//     java.awt.Font var33 = var32.getFont();
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var37 = var36.clone();
//     boolean var38 = var36.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var41 = var40.clone();
//     var40.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
//     java.awt.Font var48 = var45.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var45);
//     org.jfree.chart.util.HorizontalAlignment var50 = null;
//     org.jfree.chart.util.VerticalAlignment var51 = null;
//     org.jfree.chart.block.FlowArrangement var54 = new org.jfree.chart.block.FlowArrangement(var50, var51, (-1.0d), 0.0d);
//     org.jfree.chart.util.HorizontalAlignment var55 = null;
//     org.jfree.chart.util.VerticalAlignment var56 = null;
//     org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 0.0d, 0.05d);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45, (org.jfree.chart.block.Arrangement)var54, (org.jfree.chart.block.Arrangement)var59);
//     org.jfree.chart.util.VerticalAlignment var61 = var60.getVerticalAlignment();
//     org.jfree.chart.util.HorizontalAlignment var62 = null;
//     org.jfree.chart.util.VerticalAlignment var63 = null;
//     org.jfree.chart.block.FlowArrangement var66 = new org.jfree.chart.block.FlowArrangement(var62, var63, 0.0d, 0.05d);
//     org.jfree.data.general.Dataset var67 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var69 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var66, var67, (java.lang.Comparable)"12/31/69");
//     var60.setWrapper((org.jfree.chart.block.BlockContainer)var69);
//     
//     // Checks the contract:  equals-hashcode on var59 and var66
//     assertTrue("Contract failed: equals-hashcode on var59 and var66", var59.equals(var66) ? var59.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var59
//     assertTrue("Contract failed: equals-hashcode on var66 and var59", var66.equals(var59) ? var66.hashCode() == var59.hashCode() : true);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var4 = var2.getSeriesItemLabelsVisible(0);
    boolean var7 = var2.getItemShapeFilled(2, 255);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = var2.getLegendItemURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TickLabelEntity var3 = new org.jfree.chart.entity.TickLabelEntity(var0, "Monday", "[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var8 = null;
    org.jfree.chart.ui.ProjectInfo var12 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var8, "hi!", "", "hi!");
    java.awt.Image var16 = null;
    org.jfree.chart.ui.ProjectInfo var20 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var16, "hi!", "", "hi!");
    var12.addLibrary((org.jfree.chart.ui.Library)var20);
    boolean var22 = var4.equals((java.lang.Object)var20);
    java.awt.Paint var24 = var4.lookupSeriesFillPaint(100);
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var27 = null;
    var25.setQuadrantPaint(1, var27);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var35 = null;
    org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var35, "hi!", "", "hi!");
    java.awt.Image var43 = null;
    org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
    var39.addLibrary((org.jfree.chart.ui.Library)var47);
    boolean var49 = var31.equals((java.lang.Object)var47);
    java.awt.Paint var51 = var31.lookupSeriesFillPaint(100);
    var25.setBackgroundPaint(var51);
    boolean var53 = org.jfree.chart.util.PaintUtilities.equal(var24, var51);
    var0.setPaint(1969, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     var19.setUseOutlinePaint(false);
//     java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
//     var16.setAnchorValue(100.0d, true);
//     var16.setDomainGridlinesVisible(false);
//     org.jfree.data.general.DatasetChangeEvent var50 = null;
//     var16.datasetChanged(var50);
//     var16.clearDomainMarkers(2);
//     var16.clearRangeAxes();
//     org.jfree.data.category.CategoryDataset var55 = null;
//     org.jfree.chart.axis.CategoryAxis var56 = null;
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var62 = var61.clone();
//     boolean var63 = var61.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot(var57, (org.jfree.chart.axis.ValueAxis)var59, (org.jfree.chart.axis.ValueAxis)var61, var64);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var68 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var70 = var68.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var55, var56, (org.jfree.chart.axis.ValueAxis)var61, (org.jfree.chart.renderer.category.CategoryItemRenderer)var68);
//     org.jfree.chart.LegendItemCollection var72 = null;
//     var71.setFixedLegendItems(var72);
//     org.jfree.data.general.DatasetChangeEvent var74 = null;
//     var71.datasetChanged(var74);
//     var71.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.SortOrder var78 = var71.getColumnRenderingOrder();
//     var16.setRowRenderingOrder(var78);
//     
//     // Checks the contract:  equals-hashcode on var10 and var65
//     assertTrue("Contract failed: equals-hashcode on var10 and var65", var10.equals(var65) ? var10.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var10
//     assertTrue("Contract failed: equals-hashcode on var65 and var10", var65.equals(var10) ? var65.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Image var1 = var0.getBackgroundImage();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.AxisSpace var3 = new org.jfree.chart.axis.AxisSpace();
//     var0.setFixedRangeAxisSpace(var3);
//     double var5 = var3.getLeft();
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
//     double var10 = var9.getBase();
//     org.jfree.data.category.DefaultCategoryDataset var11 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var12 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var11);
//     java.lang.Object var13 = var11.clone();
//     boolean var14 = var9.equals((java.lang.Object)var11);
//     org.jfree.data.general.PieDataset var16 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var11, (java.lang.Comparable)true);
//     double var17 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var16);
//     org.jfree.data.general.PieDataset var20 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var16, (java.lang.Comparable)2, 1.05d);
//     var6.setDataset(var16);
//     java.awt.Paint var22 = var6.getLabelLinkPaint();
//     java.awt.Paint var23 = var6.getShadowPaint();
//     boolean var24 = var3.equals((java.lang.Object)var6);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var27 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var26};
//     var25.setRenderers(var27);
//     int var29 = var25.getDomainAxisCount();
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var35 = var34.clone();
//     boolean var36 = var34.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.axis.ValueAxis)var34, var37);
//     var32.setAutoRangeStickyZero(false);
//     var32.setFixedAutoRange(10.0d);
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var48 = var47.clone();
//     boolean var49 = var47.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var43, (org.jfree.chart.axis.ValueAxis)var45, (org.jfree.chart.axis.ValueAxis)var47, var50);
//     org.jfree.data.Range var52 = var47.getRange();
//     org.jfree.data.Range var55 = org.jfree.data.Range.expand(var52, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var56 = new org.jfree.data.time.DateRange(var55);
//     java.util.Date var57 = var56.getLowerDate();
//     var32.setRangeWithMargins((org.jfree.data.Range)var56, false, false);
//     org.jfree.data.general.Dataset var61 = null;
//     org.jfree.data.general.DatasetChangeEvent var62 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var56, var61);
//     var25.datasetChanged(var62);
//     var6.datasetChanged(var62);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("NOID", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.data.category.DefaultCategoryDataset var17 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var19 = var18.getFixedLegendItems();
//     var17.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = var16.getRendererForDataset((org.jfree.data.category.CategoryDataset)var17);
//     org.jfree.chart.renderer.category.GanttRenderer var22 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var23 = var22.getCompletePaint();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var31 = var30.clone();
//     boolean var32 = var30.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var30, var33);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var39 = var37.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     org.jfree.chart.LegendItemCollection var41 = null;
//     var40.setFixedLegendItems(var41);
//     org.jfree.data.general.DatasetChangeEvent var43 = null;
//     var40.datasetChanged(var43);
//     var40.setRangeCrosshairVisible(true);
//     var40.clearRangeMarkers();
//     var22.setPlot(var40);
//     var40.setDomainGridlinesVisible(true);
//     var40.clearDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var53.setTickMarkOutsideLength(10.0f);
//     org.jfree.chart.axis.CategoryLabelPositions var56 = var53.getCategoryLabelPositions();
//     org.jfree.chart.axis.CategoryAxis[] var57 = new org.jfree.chart.axis.CategoryAxis[] { var53};
//     var40.setDomainAxes(var57);
//     var16.setDomainAxes(var57);
//     
//     // Checks the contract:  equals-hashcode on var10 and var34
//     assertTrue("Contract failed: equals-hashcode on var10 and var34", var10.equals(var34) ? var10.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var10
//     assertTrue("Contract failed: equals-hashcode on var34 and var10", var34.equals(var10) ? var34.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var6 = var5.clone();
    var5.setAutoRange(true);
    org.jfree.chart.axis.ValueAxis[] var9 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setRangeAxes(var9);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.xy.XYDataset var12 = null;
    var11.setDataset(var12);
    java.awt.Paint var14 = var11.getRangeGridlinePaint();
    var0.setRangeZeroBaselinePaint(var14);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var23 = var22.clone();
    boolean var24 = var22.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var22, var25);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var31 = var29.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var16, var17, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29);
    org.jfree.chart.LegendItemCollection var33 = null;
    var32.setFixedLegendItems(var33);
    org.jfree.data.general.DatasetChangeEvent var35 = null;
    var32.datasetChanged(var35);
    org.jfree.chart.LegendItemCollection var37 = var32.getLegendItems();
    var0.setFixedLegendItems(var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var40 = var37.get(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     var0.setMinimumArcAngleToDraw(0.0d);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
//     double var6 = var5.getBase();
//     org.jfree.data.category.DefaultCategoryDataset var7 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var8 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var7);
//     java.lang.Object var9 = var7.clone();
//     boolean var10 = var5.equals((java.lang.Object)var7);
//     org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, (java.lang.Comparable)true);
//     double var13 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var12);
//     org.jfree.data.general.PieDataset var16 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var12, (java.lang.Comparable)2, 1.05d);
//     var0.setDataset(var16);
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
//     double var22 = var21.getBase();
//     org.jfree.data.category.DefaultCategoryDataset var23 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var24 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var23);
//     java.lang.Object var25 = var23.clone();
//     boolean var26 = var21.equals((java.lang.Object)var23);
//     org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var23, (java.lang.Comparable)true);
//     double var29 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var28);
//     org.jfree.data.general.PieDataset var32 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var28, (java.lang.Comparable)2, 1.05d);
//     var18.setDataset(var28);
//     java.awt.Paint var34 = var18.getLabelLinkPaint();
//     java.awt.Paint var35 = var18.getShadowPaint();
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot();
//     var36.setMinimumArcAngleToDraw(0.0d);
//     org.jfree.chart.labels.PieSectionLabelGenerator var39 = var36.getLabelGenerator();
//     var18.setLegendLabelGenerator(var39);
//     var0.setLabelGenerator(var39);
//     
//     // Checks the contract:  equals-hashcode on var0 and var36
//     assertTrue("Contract failed: equals-hashcode on var0 and var36", var0.equals(var36) ? var0.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var0
//     assertTrue("Contract failed: equals-hashcode on var36 and var0", var36.equals(var0) ? var36.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var6 = var5.clone();
    boolean var7 = var5.isTickMarksVisible();
    java.awt.Font var8 = var5.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
    java.awt.Image var23 = null;
    org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
    var19.addLibrary((org.jfree.chart.ui.Library)var27);
    boolean var29 = var11.equals((java.lang.Object)var27);
    java.awt.Paint var31 = var11.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var8, var31, 0.0f);
    java.awt.Font var34 = var33.getFont();
    org.jfree.data.xy.XYDataset var35 = null;
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var38 = var37.clone();
    boolean var39 = var37.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var42 = var41.clone();
    var41.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.axis.ValueAxis)var41, var45);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("", var34, (org.jfree.chart.plot.Plot)var46, true);
    java.awt.Font var49 = var46.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var46);
    org.jfree.chart.util.HorizontalAlignment var51 = null;
    org.jfree.chart.util.VerticalAlignment var52 = null;
    org.jfree.chart.block.FlowArrangement var55 = new org.jfree.chart.block.FlowArrangement(var51, var52, (-1.0d), 0.0d);
    org.jfree.chart.util.HorizontalAlignment var56 = null;
    org.jfree.chart.util.VerticalAlignment var57 = null;
    org.jfree.chart.block.FlowArrangement var60 = new org.jfree.chart.block.FlowArrangement(var56, var57, 0.0d, 0.05d);
    org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46, (org.jfree.chart.block.Arrangement)var55, (org.jfree.chart.block.Arrangement)var60);
    org.jfree.chart.util.HorizontalAlignment var62 = var61.getHorizontalAlignment();
    boolean var63 = var0.equals((java.lang.Object)var61);
    java.text.DateFormat var68 = null;
    org.jfree.chart.axis.DateTickUnit var69 = new org.jfree.chart.axis.DateTickUnit(0, 15, 100, 15, var68);
    int var70 = var69.getCount();
    int var71 = var69.getCount();
    org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var74 = null;
    var72.setQuadrantPaint(1, var74);
    boolean var76 = var72.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var77 = var72.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var79 = var72.getRenderer(0);
    boolean var80 = var69.equals((java.lang.Object)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var81 = var0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit)var69);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=Infinity,l=0.0,b=Infinity,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var2 = var1.getTickUnit();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.AxisState var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Image var7 = var6.getBackgroundImage();
//     java.lang.String var8 = var6.getNoDataMessage();
//     int var9 = var6.getWeight();
//     int var10 = var6.getRangeAxisCount();
//     org.jfree.chart.util.RectangleEdge var11 = var6.getDomainAxisEdge();
//     java.util.List var12 = var1.refreshTicks(var3, var4, var5, var11);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
    var4.setTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    java.awt.Stroke var24 = var2.getSeriesOutlineStroke(1);
    org.jfree.chart.labels.CategoryItemLabelGenerator var26 = null;
    var2.setSeriesItemLabelGenerator(0, var26, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var2 = var1.clone();
    boolean var3 = var1.isTickMarksVisible();
    java.awt.Font var4 = var1.getTickLabelFont();
    var1.setInverted(false);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var9 = null;
    var7.setQuadrantPaint(1, var9);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var13 = var12.clone();
    var12.setAutoRange(true);
    org.jfree.chart.axis.ValueAxis[] var16 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var7.setRangeAxes(var16);
    boolean var18 = var1.equals((java.lang.Object)var16);
    org.jfree.chart.plot.Plot var19 = var1.getPlot();
    var1.setAutoRangeMinimumSize(2.0d);
    org.jfree.chart.util.RectangleInsets var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelInsets(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     org.jfree.data.Range var9 = var4.getRange();
//     org.jfree.data.Range var12 = org.jfree.data.Range.expand(var9, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange(var12);
//     java.util.Date var14 = var13.getLowerDate();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(var14);
//     java.util.TimeZone var17 = null;
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year(var14, var17);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.data.time.TimePeriod var1 = null;
    org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var1);
    var2.setPercentComplete((java.lang.Double)0.2d);
    java.lang.Double var5 = var2.getPercentComplete();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var11 = var10.clone();
    boolean var12 = var10.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var13);
    org.jfree.data.Range var15 = var10.getRange();
    org.jfree.data.Range var18 = org.jfree.data.Range.expand(var15, 10.0d, 0.0d);
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange(var18);
    java.util.Date var20 = var19.getLowerDate();
    org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var20);
    org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(var20);
    var2.setDuration((org.jfree.data.time.TimePeriod)var22);
    java.lang.Object var24 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.2d+ "'", var5.equals(0.2d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    org.jfree.chart.entity.EntityCollection var2 = var1.getEntityCollection();
    java.awt.geom.Rectangle2D var3 = var1.getChartArea();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var3, "VerticalAlignment.CENTER", "Category Plot");
    java.lang.Object var7 = var6.clone();
    java.lang.String var8 = var6.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "VerticalAlignment.CENTER"+ "'", var8.equals("VerticalAlignment.CENTER"));

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    org.jfree.chart.util.Size2D var4 = new org.jfree.chart.util.Size2D();
    java.lang.String var5 = var4.toString();
    org.jfree.chart.util.Size2D var6 = var2.calculateConstrainedSize(var4);
    org.jfree.chart.block.RectangleConstraint var7 = var2.toUnconstrainedWidth();
    org.jfree.data.Range var8 = var2.getHeightRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var5.equals("Size2D[width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var9 = var8.clone();
    boolean var10 = var8.isTickMarksVisible();
    java.awt.Font var11 = var8.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var18 = null;
    org.jfree.chart.ui.ProjectInfo var22 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var18, "hi!", "", "hi!");
    java.awt.Image var26 = null;
    org.jfree.chart.ui.ProjectInfo var30 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var26, "hi!", "", "hi!");
    var22.addLibrary((org.jfree.chart.ui.Library)var30);
    boolean var32 = var14.equals((java.lang.Object)var30);
    java.awt.Paint var34 = var14.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("", var11, var34, 0.0f);
    java.awt.Font var37 = var36.getFont();
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    boolean var42 = var40.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var45 = var44.clone();
    var44.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
    org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.axis.ValueAxis)var44, var48);
    org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart("", var37, (org.jfree.chart.plot.Plot)var49, true);
    java.awt.Font var52 = var49.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var49);
    java.lang.Object var54 = var53.clone();
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var53);
    org.jfree.chart.title.LegendTitle var56 = var53.getLegend();
    org.jfree.chart.event.TitleChangeListener var57 = null;
    var56.addChangeListener(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     java.util.List var2 = var0.getRowKeys();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var5 = null;
//     var3.setQuadrantPaint(1, var5);
//     var3.configureDomainAxes();
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
//     java.util.List var9 = var0.getRowKeys();
//     java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     java.text.DateFormat var15 = null;
//     org.jfree.chart.axis.DateTickUnit var16 = new org.jfree.chart.axis.DateTickUnit(0, 15, 100, 15, var15);
//     int var17 = var16.getCount();
//     int var18 = var0.getColumnIndex((java.lang.Comparable)var16);
//     java.text.DateFormat var23 = null;
//     org.jfree.chart.axis.DateTickUnit var24 = new org.jfree.chart.axis.DateTickUnit(0, 15, 100, 15, var23);
//     int var25 = var24.getRollUnit();
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var31 = var30.clone();
//     boolean var32 = var30.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var30, var33);
//     org.jfree.data.Range var35 = var30.getRange();
//     org.jfree.data.Range var38 = org.jfree.data.Range.expand(var35, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var39 = new org.jfree.data.time.DateRange(var38);
//     java.util.Date var40 = var39.getLowerDate();
//     java.lang.String var41 = var24.dateToString(var40);
//     java.util.TimeZone var42 = null;
//     java.util.Date var43 = var16.rollDate(var40, var42);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var2 = null;
//     var0.setQuadrantPaint(1, var2);
//     boolean var4 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer(0);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = var0.getRenderer();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var16 = var15.clone();
//     boolean var17 = var15.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var18);
//     java.awt.Font var24 = null;
//     org.jfree.chart.axis.MarkerAxisBand var25 = new org.jfree.chart.axis.MarkerAxisBand(var13, (-1.0d), (-1.0d), 100.0d, 10.0d, var24);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.axis.AxisState var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleEdge var29 = null;
//     java.util.List var30 = var13.refreshTicks(var26, var27, var28, var29);
//     java.util.Collection var31 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var30);
//     var0.drawDomainTickBands(var9, var10, var30);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var37 = var36.clone();
//     boolean var38 = var36.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var41 = var40.clone();
//     var40.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
//     java.awt.geom.Rectangle2D var47 = null;
//     org.jfree.chart.util.RectangleEdge var48 = null;
//     double var49 = var36.java2DToValue(1.0d, var47, var48);
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.axis.AxisState var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.chart.util.RectangleEdge var53 = null;
//     java.util.List var54 = var36.refreshTicks(var50, var51, var52, var53);
//     var0.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis)var36, true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var45
//     assertTrue("Contract failed: equals-hashcode on var19 and var45", var19.equals(var45) ? var19.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var19
//     assertTrue("Contract failed: equals-hashcode on var45 and var19", var45.equals(var19) ? var45.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var8 = var7.clone();
    boolean var9 = var7.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.data.general.DatasetChangeEvent var20 = null;
    var17.datasetChanged(var20);
    org.jfree.chart.LegendItemCollection var22 = var17.getLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var23 = var17.getDatasetRenderingOrder();
    org.jfree.chart.axis.ValueAxis var25 = var17.getRangeAxisForDataset((-1));
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var0, var25, var26);
    org.jfree.chart.plot.WaferMapPlot var28 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var35 = null;
    org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var35, "hi!", "", "hi!");
    java.awt.Image var43 = null;
    org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
    var39.addLibrary((org.jfree.chart.ui.Library)var47);
    boolean var49 = var31.equals((java.lang.Object)var47);
    var31.setUseOutlinePaint(false);
    java.awt.Stroke var54 = var31.getItemStroke(10, (-1));
    var28.setOutlineStroke(var54);
    var27.setAngleGridlineStroke(var54);
    var27.addCornerTextItem("");
    var27.setRadiusGridlinesVisible(true);
    var27.clearCornerTextItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    java.text.DateFormat var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(1969, 1, 1969, 96, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    var0.setBackgroundAlpha(0.5f);
    boolean var3 = var0.isOutlineVisible();
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    var0.setRenderer(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var10 = var9.clone();
//     boolean var11 = var9.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var9, var12);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var18 = var16.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var3, var4, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var26 = null;
//     org.jfree.chart.ui.ProjectInfo var30 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var26, "hi!", "", "hi!");
//     java.awt.Image var34 = null;
//     org.jfree.chart.ui.ProjectInfo var38 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var34, "hi!", "", "hi!");
//     var30.addLibrary((org.jfree.chart.ui.Library)var38);
//     boolean var40 = var22.equals((java.lang.Object)var38);
//     java.awt.Paint var42 = var22.lookupSeriesFillPaint(100);
//     java.awt.Paint var44 = var22.getSeriesOutlinePaint(1);
//     java.lang.Number var46 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var47 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var46);
//     boolean var48 = var22.equals((java.lang.Object)var46);
//     java.lang.Boolean var50 = var22.getSeriesCreateEntities(10);
//     var19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     org.jfree.chart.axis.CategoryAnchor var52 = var19.getDomainGridlinePosition();
//     org.jfree.chart.entity.EntityCollection var55 = null;
//     org.jfree.chart.ChartRenderingInfo var56 = new org.jfree.chart.ChartRenderingInfo(var55);
//     org.jfree.chart.entity.EntityCollection var57 = var56.getEntityCollection();
//     java.awt.geom.Rectangle2D var58 = var56.getChartArea();
//     org.jfree.chart.entity.ChartEntity var61 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var58, "VerticalAlignment.CENTER", "Category Plot");
//     org.jfree.data.category.CategoryDataset var62 = null;
//     org.jfree.chart.axis.CategoryAxis var63 = null;
//     org.jfree.data.xy.XYDataset var64 = null;
//     org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var69 = var68.clone();
//     boolean var70 = var68.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var64, (org.jfree.chart.axis.ValueAxis)var66, (org.jfree.chart.axis.ValueAxis)var68, var71);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var75 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var77 = var75.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot(var62, var63, (org.jfree.chart.axis.ValueAxis)var68, (org.jfree.chart.renderer.category.CategoryItemRenderer)var75);
//     org.jfree.chart.LegendItemCollection var79 = null;
//     var78.setFixedLegendItems(var79);
//     org.jfree.data.general.DatasetChangeEvent var81 = null;
//     var78.datasetChanged(var81);
//     var78.setRangeCrosshairLockedOnData(false);
//     var78.clearRangeMarkers();
//     org.jfree.chart.util.RectangleEdge var87 = var78.getDomainAxisEdge(10);
//     double var88 = var1.getCategoryJava2DCoordinate(var52, 1, 100, var58, var87);
//     
//     // Checks the contract:  equals-hashcode on var13 and var72
//     assertTrue("Contract failed: equals-hashcode on var13 and var72", var13.equals(var72) ? var13.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var13
//     assertTrue("Contract failed: equals-hashcode on var72 and var13", var72.equals(var13) ? var72.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var4 = var2.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var5 = var2.getPlot();
    var2.setSeriesVisible(1, (java.lang.Boolean)true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)0);
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setURLGenerator(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     java.awt.Paint var39 = var19.lookupSeriesFillPaint(100);
//     java.awt.Paint var41 = var19.getSeriesOutlinePaint(1);
//     java.lang.Number var43 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var44 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var43);
//     boolean var45 = var19.equals((java.lang.Object)var43);
//     java.lang.Boolean var47 = var19.getSeriesCreateEntities(10);
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
//     java.lang.Object var49 = var16.clone();
//     org.jfree.chart.axis.CategoryAnchor var50 = var16.getDomainGridlinePosition();
//     java.awt.Stroke var51 = var16.getRangeCrosshairStroke();
//     int var52 = var16.getDatasetCount();
//     org.jfree.data.xy.XYDataset var53 = null;
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var56 = var55.clone();
//     boolean var57 = var55.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var60 = var59.clone();
//     var59.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var53, (org.jfree.chart.axis.ValueAxis)var55, (org.jfree.chart.axis.ValueAxis)var59, var63);
//     org.jfree.chart.event.AxisChangeEvent var65 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var59);
//     var16.axisChanged(var65);
//     
//     // Checks the contract:  equals-hashcode on var10 and var64
//     assertTrue("Contract failed: equals-hashcode on var10 and var64", var10.equals(var64) ? var10.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var10
//     assertTrue("Contract failed: equals-hashcode on var64 and var10", var64.equals(var10) ? var64.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var3 = var2.clone();
    boolean var4 = var2.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    var6.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    java.awt.Font var12 = var2.getLabelFont();
    java.awt.Font var13 = var2.getLabelFont();
    java.awt.Font var14 = var2.getLabelFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setRange(1.0E-8d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    boolean var2 = var0.equals((java.lang.Object)100.0d);
    java.awt.Paint var3 = var0.getCompletePaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var7 = var6.clone();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var13 = var11.getSeriesVisibleInLegend(10);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var15 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var11.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var15);
    var6.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var15, true);
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var21 = null;
    var19.setQuadrantPaint(1, var21);
    var19.configureDomainAxes();
    java.awt.Font var24 = var19.getNoDataMessageFont();
    java.awt.Paint var25 = var19.getDomainGridlinePaint();
    var6.setBasePaint(var25);
    org.jfree.chart.labels.ItemLabelPosition var27 = var6.getBasePositiveItemLabelPosition();
    var0.setPositiveItemLabelPositionFallback(var27);
    java.awt.Stroke var30 = var0.getSeriesStroke(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var7 = null;
    org.jfree.chart.ui.ProjectInfo var11 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var7, "hi!", "", "hi!");
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
    var11.addLibrary((org.jfree.chart.ui.Library)var19);
    boolean var21 = var3.equals((java.lang.Object)var19);
    java.awt.Paint var23 = var3.lookupSeriesFillPaint(100);
    java.awt.Paint var25 = var3.getSeriesOutlinePaint(1);
    java.lang.Number var27 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var28 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var27);
    boolean var29 = var3.equals((java.lang.Object)var27);
    java.lang.Boolean var31 = var3.getSeriesCreateEntities(10);
    java.awt.Paint var32 = var3.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var39 = null;
    org.jfree.chart.ui.ProjectInfo var43 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var39, "hi!", "", "hi!");
    java.awt.Image var47 = null;
    org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
    var43.addLibrary((org.jfree.chart.ui.Library)var51);
    boolean var53 = var35.equals((java.lang.Object)var51);
    var35.setUseOutlinePaint(false);
    java.awt.Stroke var58 = var35.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(1.0d, var32, var58);
    org.jfree.chart.util.RectangleInsets var60 = var59.getLabelOffset();
    double var61 = var60.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 3.0d);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(0, 15, 100, 15, var4);
//     int var6 = var5.getCount();
//     int var7 = var5.getCount();
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=Infinity,l=0.0,b=Infinity,r=100.0]");
//     java.util.Date var10 = var9.getMinimumDate();
//     java.util.TimeZone var11 = null;
//     java.util.Date var12 = var5.addToDate(var10, var11);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Image var1 = var0.getBackgroundImage();
    float var2 = var0.getBackgroundAlpha();
    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.lang.String var6 = var5.toString();
    float[] var10 = new float[] { 0.0f, 100.0f, 1.0f};
    float[] var11 = var5.getRGBColorComponents(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint(100, (java.awt.Paint)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var6.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    org.jfree.chart.block.LengthConstraintType var4 = var2.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toUnconstrainedWidth();
    double var6 = var5.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    var2.setUseOutlinePaint(false);
    org.jfree.chart.plot.DrawingSupplier var23 = var2.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var9 = var7.getSeriesVisibleInLegend(10);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var11 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var7.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var11);
    var2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var11, true);
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var17 = null;
    var15.setQuadrantPaint(1, var17);
    var15.configureDomainAxes();
    java.awt.Font var20 = var15.getNoDataMessageFont();
    java.awt.Paint var21 = var15.getDomainGridlinePaint();
    var2.setBasePaint(var21);
    org.jfree.chart.labels.ItemLabelPosition var25 = var2.getNegativeItemLabelPosition(10, 10);
    boolean var26 = var2.getUseFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(96, 2, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.removeColumn((java.lang.Comparable)0.0f);
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    var2.setRenderAsPercentages(true);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var12 = var11.clone();
    boolean var13 = var11.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var14);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var20 = var18.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.LegendItemCollection var22 = null;
    var21.setFixedLegendItems(var22);
    org.jfree.data.general.DatasetChangeEvent var24 = null;
    var21.datasetChanged(var24);
    org.jfree.chart.LegendItemCollection var26 = var21.getLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var27 = var21.getDatasetRenderingOrder();
    org.jfree.chart.axis.ValueAxis var29 = var21.getRangeAxisForDataset((-1));
    boolean var30 = var2.equals((java.lang.Object)var21);
    org.jfree.chart.annotations.CategoryAnnotation var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var32 = var21.removeAnnotation(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var3 = null;
    var1.setQuadrantPaint(1, var3);
    boolean var5 = var1.isRangeCrosshairLockedOnData();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
    java.awt.Image var21 = null;
    org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
    var17.addLibrary((org.jfree.chart.ui.Library)var25);
    boolean var27 = var9.equals((java.lang.Object)var25);
    java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
    java.awt.Paint var31 = var9.getSeriesOutlinePaint(1);
    java.lang.Number var33 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var34 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var33);
    boolean var35 = var9.equals((java.lang.Object)var33);
    java.lang.Boolean var37 = var9.getSeriesCreateEntities(10);
    java.awt.Paint var38 = var9.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var45 = null;
    org.jfree.chart.ui.ProjectInfo var49 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var45, "hi!", "", "hi!");
    java.awt.Image var53 = null;
    org.jfree.chart.ui.ProjectInfo var57 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var53, "hi!", "", "hi!");
    var49.addLibrary((org.jfree.chart.ui.Library)var57);
    boolean var59 = var41.equals((java.lang.Object)var57);
    var41.setUseOutlinePaint(false);
    java.awt.Stroke var64 = var41.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(1.0d, var38, var64);
    var1.addDomainMarker((org.jfree.chart.plot.Marker)var65);
    boolean var67 = var0.equals((java.lang.Object)var1);
    java.awt.Font var69 = var0.getTickLabelFont((java.lang.Comparable)Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var4 = var3.clone();
    boolean var5 = var3.isTickMarksVisible();
    java.awt.Font var6 = var3.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
    java.awt.Image var21 = null;
    org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
    var17.addLibrary((org.jfree.chart.ui.Library)var25);
    boolean var27 = var9.equals((java.lang.Object)var25);
    java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
    java.awt.Font var32 = var31.getFont();
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var36 = var35.clone();
    boolean var37 = var35.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var40 = var39.clone();
    var39.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var43);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var44, true);
    java.awt.Image var47 = null;
    var46.setBackgroundImage(var47);
    org.jfree.chart.axis.SegmentedTimeline var49 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    var49.addException(1L);
    org.jfree.chart.renderer.category.GanttRenderer var52 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var53 = var52.getCompletePaint();
    boolean var54 = var49.equals((java.lang.Object)var53);
    var46.setBorderPaint(var53);
    org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var58 = var57.clone();
    boolean var59 = var57.isTickMarksVisible();
    java.awt.Font var60 = var57.getTickLabelFont();
    float var61 = var57.getTickMarkOutsideLength();
    java.awt.Font var66 = null;
    org.jfree.chart.axis.MarkerAxisBand var67 = new org.jfree.chart.axis.MarkerAxisBand(var57, 1.0d, 0.0d, 10.0d, 1.0d, var66);
    java.awt.Graphics2D var68 = null;
    double var69 = var67.getHeight(var68);
    boolean var70 = var46.equals((java.lang.Object)var67);
    org.jfree.chart.event.ChartChangeListener var71 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var46.addChangeListener(var71);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var3 = var2.clone();
    boolean var4 = var2.isTickMarksVisible();
    boolean var5 = var2.isTickLabelsVisible();
    var2.setPositiveArrowVisible(false);
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(96, 255);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    var0.setMinimumArcAngleToDraw(1.0d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.urls.StandardCategoryURLGenerator var1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("-10,-10,-10,-10,0,0,10,-10,10,-10,0,0,10,10,10,10,0,0,-10,10,-10,10,0,0,0,0");

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    java.awt.Color var1 = java.awt.Color.getColor("NOID");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    double var1 = var0.getLabelAngle();
    java.lang.Comparable var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
    var3.setMinimumArcAngleToDraw(0.0d);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var9 = var8.clone();
    boolean var10 = var8.isTickMarksVisible();
    java.awt.Font var11 = var8.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var18 = null;
    org.jfree.chart.ui.ProjectInfo var22 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var18, "hi!", "", "hi!");
    java.awt.Image var26 = null;
    org.jfree.chart.ui.ProjectInfo var30 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var26, "hi!", "", "hi!");
    var22.addLibrary((org.jfree.chart.ui.Library)var30);
    boolean var32 = var14.equals((java.lang.Object)var30);
    java.awt.Paint var34 = var14.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("", var11, var34, 0.0f);
    java.awt.Font var37 = var36.getFont();
    var3.setLabelFont(var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelFont(var2, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getRangeTickBandPaint();
    var0.mapDatasetToDomainAxis(10, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Color var2 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    int var3 = var2.getAlpha();
    var0.setLabelLinkPaint((java.awt.Paint)var2);
    double var5 = var0.getLabelLinkMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "poly", "[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]", "Size2D[width=0.0, height=0.0]");
    java.lang.String var6 = var5.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var6.equals("Size2D[width=0.0, height=0.0]"));

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var2 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Paint var5 = var2.getItemOutlinePaint(100, 0);
//     java.awt.Paint var6 = var2.getBasePaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = null;
//     var12.setQuadrantPaint(1, var14);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var22 = null;
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
//     java.awt.Image var30 = null;
//     org.jfree.chart.ui.ProjectInfo var34 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var30, "hi!", "", "hi!");
//     var26.addLibrary((org.jfree.chart.ui.Library)var34);
//     boolean var36 = var18.equals((java.lang.Object)var34);
//     java.awt.Paint var38 = var18.lookupSeriesFillPaint(100);
//     var12.setBackgroundPaint(var38);
//     java.awt.Stroke var40 = var12.getDomainGridlineStroke();
//     var10.setBaseStroke(var40, false);
//     var2.setSeriesOutlineStroke(100, var40);
//     var0.setStroke(96, var40);
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Image var47 = var46.getBackgroundImage();
//     float var48 = var46.getBackgroundAlpha();
//     java.awt.Stroke var49 = var46.getDomainZeroBaselineStroke();
//     var0.setStroke(10, var49);
//     
//     // Checks the contract:  equals-hashcode on var12 and var46
//     assertTrue("Contract failed: equals-hashcode on var12 and var46", var12.equals(var46) ? var12.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var12
//     assertTrue("Contract failed: equals-hashcode on var46 and var12", var46.equals(var12) ? var46.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.data.time.TimePeriod var1 = null;
//     org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var1);
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var8 = var7.clone();
//     boolean var9 = var7.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     org.jfree.data.Range var12 = var7.getRange();
//     org.jfree.data.Range var15 = org.jfree.data.Range.expand(var12, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange(var15);
//     java.util.Date var17 = var16.getLowerDate();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     var2.setDuration((org.jfree.data.time.TimePeriod)var19);
//     org.jfree.data.time.RegularTimePeriod var21 = var19.previous();
//     java.util.Calendar var22 = null;
//     long var23 = var19.getFirstMillisecond(var22);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    org.jfree.chart.event.ChartChangeEventType var48 = null;
    org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var47, var48);
    org.jfree.chart.event.ChartProgressListener var50 = null;
    var47.addProgressListener(var50);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var54 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    double var55 = var54.getBase();
    org.jfree.data.category.DefaultCategoryDataset var56 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var57 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var56);
    java.lang.Object var58 = var56.clone();
    boolean var59 = var54.equals((java.lang.Object)var56);
    var54.setSeriesItemLabelsVisible(2, true);
    double var63 = var54.getXOffset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var47.setTextAntiAlias((java.lang.Object)var63);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + 0.0d+ "'", var57.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.data.general.DatasetChangeEvent var19 = null;
    var16.datasetChanged(var19);
    var16.setRangeCrosshairLockedOnData(false);
    var16.clearRangeMarkers();
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var25.getCategoryEnd(0, 0, var28, var29);
    float var31 = var25.getMaximumCategoryLabelWidthRatio();
    var25.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var35.setTickMarkOutsideLength(10.0f);
    org.jfree.chart.axis.CategoryLabelPositions var38 = var35.getCategoryLabelPositions();
    var25.setCategoryLabelPositions(var38);
    int var40 = var16.getDomainAxisIndex(var25);
    var25.setMaximumCategoryLabelWidthRatio(0.5f);
    var25.setLowerMargin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1));

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var11 = null;
//     org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var11, "hi!", "", "hi!");
//     java.awt.Image var19 = null;
//     org.jfree.chart.ui.ProjectInfo var23 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var19, "hi!", "", "hi!");
//     var15.addLibrary((org.jfree.chart.ui.Library)var23);
//     boolean var25 = var7.equals((java.lang.Object)var23);
//     java.awt.Paint var27 = var7.lookupSeriesFillPaint(100);
//     java.awt.Paint var29 = var7.getSeriesOutlinePaint(1);
//     java.lang.Number var31 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var32 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var31);
//     boolean var33 = var7.equals((java.lang.Object)var31);
//     java.lang.Boolean var35 = var7.getSeriesCreateEntities(10);
//     java.awt.Paint var36 = var7.getBaseFillPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var43 = null;
//     org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
//     java.awt.Image var51 = null;
//     org.jfree.chart.ui.ProjectInfo var55 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var51, "hi!", "", "hi!");
//     var47.addLibrary((org.jfree.chart.ui.Library)var55);
//     boolean var57 = var39.equals((java.lang.Object)var55);
//     var39.setUseOutlinePaint(false);
//     java.awt.Stroke var62 = var39.getItemStroke(10, (-1));
//     org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(1.0d, var36, var62);
//     var63.setLabel("hi!");
//     java.awt.Paint var66 = var63.getLabelPaint();
//     org.jfree.chart.text.TextAnchor var67 = var63.getLabelTextAnchor();
//     java.awt.geom.Rectangle2D var68 = org.jfree.chart.text.TextUtilities.drawAlignedString("black", var1, 2.0f, 0.0f, var67);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    org.jfree.chart.block.LengthConstraintType var4 = var2.getWidthConstraintType();
    double var5 = var2.getHeight();
    org.jfree.chart.block.LengthConstraintType var6 = var2.getHeightConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setNegativeItemLabelPositionFallback(var1);
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var10 = var9.clone();
    boolean var11 = var9.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var9, var12);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var18 = var16.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var3, var4, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var26 = null;
    org.jfree.chart.ui.ProjectInfo var30 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var26, "hi!", "", "hi!");
    java.awt.Image var34 = null;
    org.jfree.chart.ui.ProjectInfo var38 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var34, "hi!", "", "hi!");
    var30.addLibrary((org.jfree.chart.ui.Library)var38);
    boolean var40 = var22.equals((java.lang.Object)var38);
    java.awt.Paint var42 = var22.lookupSeriesFillPaint(100);
    java.awt.Paint var44 = var22.getSeriesOutlinePaint(1);
    java.lang.Number var46 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var47 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var46);
    boolean var48 = var22.equals((java.lang.Object)var46);
    java.lang.Boolean var50 = var22.getSeriesCreateEntities(10);
    var19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    java.lang.Object var52 = var19.clone();
    org.jfree.chart.util.Layer var54 = null;
    java.util.Collection var55 = var19.getDomainMarkers(15, var54);
    org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.xy.XYDataset var57 = null;
    var56.setDataset(var57);
    java.awt.Paint var59 = var56.getRangeGridlinePaint();
    var19.setRangeGridlinePaint(var59);
    org.jfree.chart.plot.PlotRenderingInfo var62 = null;
    java.awt.geom.Point2D var63 = null;
    var19.zoomDomainAxes(4.0d, var62, var63);
    org.jfree.chart.axis.AxisSpace var65 = var19.getFixedRangeAxisSpace();
    boolean var66 = var1.equals((java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var23 = null;
    org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
    java.awt.Image var31 = null;
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
    var27.addLibrary((org.jfree.chart.ui.Library)var35);
    boolean var37 = var19.equals((java.lang.Object)var35);
    var19.setUseOutlinePaint(false);
    java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
    var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
    var16.setAnchorValue(100.0d, true);
    var16.setDomainGridlinesVisible(false);
    boolean var50 = var16.isRangeGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.data.general.DatasetChangeEvent var19 = null;
    var16.datasetChanged(var19);
    var16.setRangeCrosshairLockedOnData(false);
    var16.clearRangeMarkers();
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var25.getCategoryEnd(0, 0, var28, var29);
    float var31 = var25.getMaximumCategoryLabelWidthRatio();
    var25.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var35.setTickMarkOutsideLength(10.0f);
    org.jfree.chart.axis.CategoryLabelPositions var38 = var35.getCategoryLabelPositions();
    var25.setCategoryLabelPositions(var38);
    int var40 = var16.getDomainAxisIndex(var25);
    var25.setMaximumCategoryLabelWidthRatio(0.5f);
    var25.setMaximumCategoryLabelLines(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1));

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var6 = var5.clone();
//     boolean var7 = var5.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var5, var8);
//     java.awt.Font var14 = null;
//     org.jfree.chart.axis.MarkerAxisBand var15 = new org.jfree.chart.axis.MarkerAxisBand(var3, (-1.0d), (-1.0d), 100.0d, 10.0d, var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.AxisState var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     java.util.List var20 = var3.refreshTicks(var16, var17, var18, var19);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var24 = var23.clone();
//     boolean var25 = var23.isTickMarksVisible();
//     java.awt.Font var26 = var23.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var33 = null;
//     org.jfree.chart.ui.ProjectInfo var37 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var33, "hi!", "", "hi!");
//     java.awt.Image var41 = null;
//     org.jfree.chart.ui.ProjectInfo var45 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var41, "hi!", "", "hi!");
//     var37.addLibrary((org.jfree.chart.ui.Library)var45);
//     boolean var47 = var29.equals((java.lang.Object)var45);
//     java.awt.Paint var49 = var29.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("", var26, var49, 0.0f);
//     var3.setLabelPaint(var49);
//     boolean var53 = var0.equals((java.lang.Object)var3);
//     var0.clear();
//     var0.clear();
//     org.jfree.chart.util.HorizontalAlignment var56 = null;
//     org.jfree.chart.util.VerticalAlignment var57 = null;
//     org.jfree.chart.block.FlowArrangement var60 = new org.jfree.chart.block.FlowArrangement(var56, var57, 0.0d, 0.05d);
//     org.jfree.data.general.Dataset var61 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var63 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var60, var61, (java.lang.Comparable)"12/31/69");
//     java.lang.Comparable var64 = var63.getSeriesKey();
//     java.lang.String var65 = var63.getURLText();
//     var63.setURLText("Other");
//     java.awt.Graphics2D var68 = null;
//     org.jfree.chart.block.RectangleConstraint var69 = null;
//     org.jfree.chart.util.Size2D var70 = var0.arrange((org.jfree.chart.block.BlockContainer)var63, var68, var69);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.text.TextBlock var3 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var12, "hi!", "", "hi!");
    java.awt.Image var20 = null;
    org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var20, "hi!", "", "hi!");
    var16.addLibrary((org.jfree.chart.ui.Library)var24);
    boolean var26 = var8.equals((java.lang.Object)var24);
    java.awt.Paint var28 = var8.lookupSeriesFillPaint(100);
    java.awt.Paint var30 = var8.getSeriesOutlinePaint(1);
    java.lang.Number var32 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var33 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var32);
    boolean var34 = var8.equals((java.lang.Object)var32);
    java.lang.Boolean var36 = var8.getSeriesCreateEntities(10);
    java.awt.Paint var37 = var8.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var44 = null;
    org.jfree.chart.ui.ProjectInfo var48 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var44, "hi!", "", "hi!");
    java.awt.Image var52 = null;
    org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var52, "hi!", "", "hi!");
    var48.addLibrary((org.jfree.chart.ui.Library)var56);
    boolean var58 = var40.equals((java.lang.Object)var56);
    var40.setUseOutlinePaint(false);
    java.awt.Stroke var63 = var40.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(1.0d, var37, var63);
    var64.setLabel("hi!");
    java.awt.Paint var67 = var64.getLabelPaint();
    org.jfree.chart.text.TextAnchor var68 = var64.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var70 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(-1L), var3, var4, var68, 2.0d);
    java.lang.String var71 = var70.toString();
    java.lang.String var72 = var70.getText();
    org.jfree.chart.text.TextAnchor var73 = var70.getTextAnchor();
    org.jfree.chart.text.TextAnchor var74 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var76 = new org.jfree.chart.axis.NumberTick((java.lang.Number)3.0d, "VerticalAlignment.CENTER", var73, var74, 1.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var71 + "' != '" + ""+ "'", var71.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + ""+ "'", var72.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)"Other");

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var1 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var2 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var1};
    var0.setRenderers(var2);
    int var4 = var0.getDomainAxisCount();
    var0.configureRangeAxes();
    var0.setDomainCrosshairValue(10.0d, false);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var11 = null;
    var9.setQuadrantPaint(1, var11);
    boolean var13 = var9.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var14 = var9.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = var9.getRenderer(0);
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = var9.getRenderer();
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var25 = var24.clone();
    boolean var26 = var24.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var27);
    java.awt.Font var33 = null;
    org.jfree.chart.axis.MarkerAxisBand var34 = new org.jfree.chart.axis.MarkerAxisBand(var22, (-1.0d), (-1.0d), 100.0d, 10.0d, var33);
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.axis.AxisState var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.util.RectangleEdge var38 = null;
    java.util.List var39 = var22.refreshTicks(var35, var36, var37, var38);
    java.util.Collection var40 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var39);
    var9.drawDomainTickBands(var18, var19, var39);
    org.jfree.chart.plot.PlotRenderingInfo var44 = null;
    java.awt.geom.Point2D var45 = null;
    var9.zoomRangeAxes(0.0d, 0.0d, var44, var45);
    org.jfree.chart.axis.ValueAxis var48 = var9.getDomainAxis(15);
    org.jfree.chart.axis.AxisLocation var50 = var9.getDomainAxisLocation(15);
    var0.setRangeAxisLocation(var50);
    java.lang.String var52 = var50.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + "AxisLocation.TOP_OR_RIGHT"+ "'", var52.equals("AxisLocation.TOP_OR_RIGHT"));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.data.time.TimePeriod var1 = null;
    org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("SerialDate.weekInMonthToString(): invalid code.", var1);
    java.lang.String var3 = var2.getDescription();
    org.jfree.data.time.TimePeriod var4 = null;
    var2.setDuration(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var3.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=Infinity,l=0.0,b=Infinity,r=100.0]");
//     java.util.Date var2 = var1.getMinimumDate();
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var8 = var7.clone();
//     boolean var9 = var7.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     org.jfree.data.Range var12 = var7.getRange();
//     org.jfree.data.Range var15 = org.jfree.data.Range.expand(var12, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange(var15);
//     java.util.Date var17 = var16.getLowerDate();
//     var1.setMaximumDate(var17);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var24 = var23.clone();
//     boolean var25 = var23.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var23, var26);
//     org.jfree.data.Range var28 = var23.getRange();
//     org.jfree.data.Range var31 = org.jfree.data.Range.expand(var28, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange(var31);
//     java.util.Date var33 = var32.getLowerDate();
//     var1.setRange((org.jfree.data.Range)var32, false, false);
//     
//     // Checks the contract:  equals-hashcode on var11 and var27
//     assertTrue("Contract failed: equals-hashcode on var11 and var27", var11.equals(var27) ? var11.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var11
//     assertTrue("Contract failed: equals-hashcode on var27 and var11", var27.equals(var11) ? var27.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
    java.awt.Font var13 = null;
    org.jfree.chart.axis.MarkerAxisBand var14 = new org.jfree.chart.axis.MarkerAxisBand(var2, (-1.0d), (-1.0d), 100.0d, 10.0d, var13);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.axis.AxisState var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    java.util.List var19 = var2.refreshTicks(var15, var16, var17, var18);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var23 = var22.clone();
    boolean var24 = var22.isTickMarksVisible();
    java.awt.Font var25 = var22.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var32 = null;
    org.jfree.chart.ui.ProjectInfo var36 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var32, "hi!", "", "hi!");
    java.awt.Image var40 = null;
    org.jfree.chart.ui.ProjectInfo var44 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var40, "hi!", "", "hi!");
    var36.addLibrary((org.jfree.chart.ui.Library)var44);
    boolean var46 = var28.equals((java.lang.Object)var44);
    java.awt.Paint var48 = var28.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("", var25, var48, 0.0f);
    var2.setLabelPaint(var48);
    var2.setFixedAutoRange(0.0d);
    var2.setTickLabelsVisible(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.zoomRange(4.0d, 1.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + "XY Plot"+ "'", var0.equals("XY Plot"));

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     org.jfree.data.Range var9 = var4.getRange();
//     org.jfree.data.Range var12 = org.jfree.data.Range.expand(var9, 10.0d, 0.0d);
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange(var12);
//     java.util.Date var14 = var13.getLowerDate();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     int var16 = var15.getYearValue();
//     java.util.Calendar var17 = null;
//     long var18 = var15.getFirstMillisecond(var17);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Image var1 = var0.getBackgroundImage();
    float var2 = var0.getBackgroundAlpha();
    java.awt.Stroke var3 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.entity.EntityCollection var5 = null;
    org.jfree.chart.ChartRenderingInfo var6 = new org.jfree.chart.ChartRenderingInfo(var5);
    org.jfree.chart.entity.EntityCollection var7 = var6.getEntityCollection();
    java.awt.geom.Rectangle2D var8 = var6.getChartArea();
    org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var8, "VerticalAlignment.CENTER", "Category Plot");
    var4.setBounds(var8);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var20 = null;
    org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var20, "hi!", "", "hi!");
    java.awt.Image var28 = null;
    org.jfree.chart.ui.ProjectInfo var32 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var28, "hi!", "", "hi!");
    var24.addLibrary((org.jfree.chart.ui.Library)var32);
    boolean var34 = var16.equals((java.lang.Object)var32);
    java.awt.Paint var36 = var16.lookupSeriesFillPaint(100);
    java.awt.Paint var38 = var16.getSeriesOutlinePaint(1);
    java.lang.Number var40 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var41 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var40);
    boolean var42 = var16.equals((java.lang.Object)var40);
    java.lang.Boolean var44 = var16.getSeriesCreateEntities(10);
    java.awt.Paint var45 = var16.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var52 = null;
    org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var52, "hi!", "", "hi!");
    java.awt.Image var60 = null;
    org.jfree.chart.ui.ProjectInfo var64 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var60, "hi!", "", "hi!");
    var56.addLibrary((org.jfree.chart.ui.Library)var64);
    boolean var66 = var48.equals((java.lang.Object)var64);
    var48.setUseOutlinePaint(false);
    java.awt.Stroke var71 = var48.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var72 = new org.jfree.chart.plot.ValueMarker(1.0d, var45, var71);
    java.awt.Color var74 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    var72.setPaint((java.awt.Paint)var74);
    org.jfree.chart.title.LegendGraphic var76 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var8, (java.awt.Paint)var74);
    org.jfree.chart.util.RectangleAnchor var77 = var76.getShapeLocation();
    java.awt.Paint var78 = var76.getFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Paint var3 = var0.getItemOutlinePaint(100, 0);
//     var0.setSeriesBarWidth(0, 100.0d);
//     var0.setDrawBarOutline(false);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var15 = null;
//     org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     var19.addLibrary((org.jfree.chart.ui.Library)var27);
//     boolean var29 = var11.equals((java.lang.Object)var27);
//     java.awt.Paint var31 = var11.lookupSeriesFillPaint(100);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var36 = var35.clone();
//     boolean var37 = var35.isTickMarksVisible();
//     java.awt.Font var38 = var35.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var45 = null;
//     org.jfree.chart.ui.ProjectInfo var49 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var45, "hi!", "", "hi!");
//     java.awt.Image var53 = null;
//     org.jfree.chart.ui.ProjectInfo var57 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var53, "hi!", "", "hi!");
//     var49.addLibrary((org.jfree.chart.ui.Library)var57);
//     boolean var59 = var41.equals((java.lang.Object)var57);
//     java.awt.Paint var61 = var41.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var63 = new org.jfree.chart.text.TextFragment("", var38, var61, 0.0f);
//     java.awt.Font var64 = var63.getFont();
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var68 = var67.clone();
//     boolean var69 = var67.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var72 = var71.clone();
//     var71.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var75 = null;
//     org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot(var65, (org.jfree.chart.axis.ValueAxis)var67, (org.jfree.chart.axis.ValueAxis)var71, var75);
//     org.jfree.chart.JFreeChart var78 = new org.jfree.chart.JFreeChart("", var64, (org.jfree.chart.plot.Plot)var76, true);
//     org.jfree.chart.event.ChartProgressEvent var81 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var11, var78, 10, 1);
//     var78.setTextAntiAlias(false);
//     org.jfree.data.xy.XYDataset var84 = null;
//     org.jfree.chart.axis.NumberAxis var86 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var87 = var86.clone();
//     boolean var88 = var86.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var90 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var91 = var90.clone();
//     var90.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var94 = null;
//     org.jfree.chart.plot.XYPlot var95 = new org.jfree.chart.plot.XYPlot(var84, (org.jfree.chart.axis.ValueAxis)var86, (org.jfree.chart.axis.ValueAxis)var90, var94);
//     org.jfree.chart.event.AxisChangeEvent var96 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var90);
//     org.jfree.chart.event.ChartChangeEventType var97 = var96.getType();
//     java.lang.String var98 = var97.toString();
//     org.jfree.chart.event.ChartChangeEvent var99 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var78, var97);
//     
//     // Checks the contract:  equals-hashcode on var76 and var95
//     assertTrue("Contract failed: equals-hashcode on var76 and var95", var76.equals(var95) ? var76.hashCode() == var95.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var95 and var76
//     assertTrue("Contract failed: equals-hashcode on var95 and var76", var95.equals(var76) ? var95.hashCode() == var76.hashCode() : true);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    var0.setMinimumArcAngleToDraw(0.0d);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var6 = var5.clone();
    boolean var7 = var5.isTickMarksVisible();
    java.awt.Font var8 = var5.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
    java.awt.Image var23 = null;
    org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
    var19.addLibrary((org.jfree.chart.ui.Library)var27);
    boolean var29 = var11.equals((java.lang.Object)var27);
    java.awt.Paint var31 = var11.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var8, var31, 0.0f);
    java.awt.Font var34 = var33.getFont();
    var0.setLabelFont(var34);
    org.jfree.chart.renderer.category.LayeredBarRenderer var36 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var39 = var36.getItemOutlinePaint(100, 0);
    org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var42 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var41};
    var40.setRenderers(var42);
    boolean var44 = var36.equals((java.lang.Object)var40);
    double var45 = var36.getMaximumBarWidth();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var52 = null;
    org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var52, "hi!", "", "hi!");
    java.awt.Image var60 = null;
    org.jfree.chart.ui.ProjectInfo var64 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var60, "hi!", "", "hi!");
    var56.addLibrary((org.jfree.chart.ui.Library)var64);
    boolean var66 = var48.equals((java.lang.Object)var64);
    var48.setUseOutlinePaint(false);
    java.awt.Stroke var71 = var48.getItemStroke(10, (-1));
    var36.setBaseStroke(var71, true);
    var0.setLabelOutlineStroke(var71);
    org.jfree.chart.plot.AbstractPieLabelDistributor var75 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelDistributor(var75);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = null;
    var0.setQuadrantPaint(1, var2);
    var0.configureDomainAxes();
    java.awt.Font var5 = var0.getNoDataMessageFont();
    java.awt.Paint var6 = var0.getRangeTickBandPaint();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
    var10.setRenderAsPercentages(true);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var20 = null;
    org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var20, "hi!", "", "hi!");
    java.awt.Image var28 = null;
    org.jfree.chart.ui.ProjectInfo var32 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var28, "hi!", "", "hi!");
    var24.addLibrary((org.jfree.chart.ui.Library)var32);
    boolean var34 = var16.equals((java.lang.Object)var32);
    java.awt.Paint var36 = var16.lookupSeriesFillPaint(100);
    java.awt.Paint var38 = var16.getSeriesOutlinePaint(1);
    java.lang.Number var40 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var41 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var40);
    boolean var42 = var16.equals((java.lang.Object)var40);
    java.lang.Boolean var44 = var16.getSeriesCreateEntities(10);
    java.awt.Paint var45 = var16.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var52 = null;
    org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var52, "hi!", "", "hi!");
    java.awt.Image var60 = null;
    org.jfree.chart.ui.ProjectInfo var64 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var60, "hi!", "", "hi!");
    var56.addLibrary((org.jfree.chart.ui.Library)var64);
    boolean var66 = var48.equals((java.lang.Object)var64);
    var48.setUseOutlinePaint(false);
    java.awt.Stroke var71 = var48.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var72 = new org.jfree.chart.plot.ValueMarker(1.0d, var45, var71);
    java.awt.Color var74 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    var72.setPaint((java.awt.Paint)var74);
    var10.setBasePaint((java.awt.Paint)var74, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint(15, (java.awt.Paint)var74);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    java.awt.Font var48 = var45.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var45);
    org.jfree.chart.util.HorizontalAlignment var50 = null;
    org.jfree.chart.util.VerticalAlignment var51 = null;
    org.jfree.chart.block.FlowArrangement var54 = new org.jfree.chart.block.FlowArrangement(var50, var51, (-1.0d), 0.0d);
    org.jfree.chart.util.HorizontalAlignment var55 = null;
    org.jfree.chart.util.VerticalAlignment var56 = null;
    org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 0.0d, 0.05d);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45, (org.jfree.chart.block.Arrangement)var54, (org.jfree.chart.block.Arrangement)var59);
    org.jfree.chart.util.HorizontalAlignment var61 = var60.getHorizontalAlignment();
    org.jfree.chart.LegendItemSource[] var62 = var60.getSources();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.get(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    java.awt.Paint var24 = var2.getSeriesOutlinePaint(1);
    java.lang.Number var26 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var26);
    boolean var28 = var2.equals((java.lang.Object)var26);
    java.lang.Boolean var30 = var2.getSeriesCreateEntities(10);
    boolean var31 = var2.getUseOutlinePaint();
    var2.setSeriesShapesVisible(100, (java.lang.Boolean)false);
    java.lang.Object var35 = var2.clone();
    java.awt.Stroke var37 = var2.lookupSeriesOutlineStroke(0);
    java.awt.Paint var40 = var2.getItemLabelPaint(1969, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var8 = var7.clone();
    boolean var9 = var7.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var16 = var14.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.data.general.DatasetChangeEvent var20 = null;
    var17.datasetChanged(var20);
    org.jfree.chart.LegendItemCollection var22 = var17.getLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var23 = var17.getDatasetRenderingOrder();
    org.jfree.chart.axis.ValueAxis var25 = var17.getRangeAxisForDataset((-1));
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var0, var25, var26);
    org.jfree.chart.plot.WaferMapPlot var28 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var35 = null;
    org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var35, "hi!", "", "hi!");
    java.awt.Image var43 = null;
    org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
    var39.addLibrary((org.jfree.chart.ui.Library)var47);
    boolean var49 = var31.equals((java.lang.Object)var47);
    var31.setUseOutlinePaint(false);
    java.awt.Stroke var54 = var31.getItemStroke(10, (-1));
    var28.setOutlineStroke(var54);
    var27.setAngleGridlineStroke(var54);
    var27.addCornerTextItem("");
    var27.setRadiusGridlinesVisible(false);
    org.jfree.chart.renderer.PolarItemRenderer var61 = null;
    var27.setRenderer(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var7 = null;
//     org.jfree.chart.ui.ProjectInfo var11 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var7, "hi!", "", "hi!");
//     java.awt.Image var15 = null;
//     org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var15, "hi!", "", "hi!");
//     var11.addLibrary((org.jfree.chart.ui.Library)var19);
//     boolean var21 = var3.equals((java.lang.Object)var19);
//     java.awt.Paint var23 = var3.lookupSeriesFillPaint(100);
//     java.awt.Paint var25 = var3.getSeriesOutlinePaint(1);
//     java.lang.Number var27 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var28 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var27);
//     boolean var29 = var3.equals((java.lang.Object)var27);
//     java.lang.Boolean var31 = var3.getSeriesCreateEntities(10);
//     java.awt.Paint var32 = var3.getBaseFillPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var39 = null;
//     org.jfree.chart.ui.ProjectInfo var43 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var39, "hi!", "", "hi!");
//     java.awt.Image var47 = null;
//     org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var47, "hi!", "", "hi!");
//     var43.addLibrary((org.jfree.chart.ui.Library)var51);
//     boolean var53 = var35.equals((java.lang.Object)var51);
//     var35.setUseOutlinePaint(false);
//     java.awt.Stroke var58 = var35.getItemStroke(10, (-1));
//     org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(1.0d, var32, var58);
//     java.lang.Class var60 = null;
//     java.util.EventListener[] var61 = var59.getListeners(var60);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     boolean var2 = var1.getAutoPopulateSeriesOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var7 = var5.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var9 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var5.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var9);
//     java.awt.Paint var13 = var5.getItemPaint(0, 0);
//     var1.setBasePaint(var13);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var15 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Paint var18 = var15.getItemOutlinePaint(100, 0);
//     java.awt.Paint var19 = var15.getBasePaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Object var24 = var23.clone();
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var27 = null;
//     var25.setQuadrantPaint(1, var27);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var35 = null;
//     org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var35, "hi!", "", "hi!");
//     java.awt.Image var43 = null;
//     org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
//     var39.addLibrary((org.jfree.chart.ui.Library)var47);
//     boolean var49 = var31.equals((java.lang.Object)var47);
//     java.awt.Paint var51 = var31.lookupSeriesFillPaint(100);
//     var25.setBackgroundPaint(var51);
//     java.awt.Stroke var53 = var25.getDomainGridlineStroke();
//     var23.setBaseStroke(var53, false);
//     var15.setSeriesOutlineStroke(100, var53);
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.2d, var13, var53);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var5.", var31.equals(var5) == var5.equals(var31));
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var2 = var0.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.category.LayeredBarRenderer var3 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var6 = var3.getItemOutlinePaint(100, 0);
    var0.setBasePaint(var6, false);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var14 = var13.clone();
    boolean var15 = var13.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var13, var16);
    java.awt.Font var22 = null;
    org.jfree.chart.axis.MarkerAxisBand var23 = new org.jfree.chart.axis.MarkerAxisBand(var11, (-1.0d), (-1.0d), 100.0d, 10.0d, var22);
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.axis.AxisState var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    java.util.List var28 = var11.refreshTicks(var24, var25, var26, var27);
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var32 = var31.clone();
    boolean var33 = var31.isTickMarksVisible();
    java.awt.Font var34 = var31.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var41 = null;
    org.jfree.chart.ui.ProjectInfo var45 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var41, "hi!", "", "hi!");
    java.awt.Image var49 = null;
    org.jfree.chart.ui.ProjectInfo var53 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var49, "hi!", "", "hi!");
    var45.addLibrary((org.jfree.chart.ui.Library)var53);
    boolean var55 = var37.equals((java.lang.Object)var53);
    java.awt.Paint var57 = var37.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var59 = new org.jfree.chart.text.TextFragment("", var34, var57, 0.0f);
    var11.setLabelPaint(var57);
    boolean var61 = var0.equals((java.lang.Object)var57);
    var0.setAutoPopulateSeriesFillPaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var2 = var0.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.category.LayeredBarRenderer var3 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var6 = var3.getItemOutlinePaint(100, 0);
    var0.setBasePaint(var6, false);
    boolean var9 = var0.getRenderAsPercentages();
    org.jfree.chart.renderer.AreaRendererEndType var10 = var0.getEndType();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, Double.NEGATIVE_INFINITY);
    boolean var14 = var10.equals((java.lang.Object)1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2, var1);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.data.UnknownKeyException var1 = new org.jfree.data.UnknownKeyException("");
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.UnknownKeyException: "+ "'", var2.equals("org.jfree.data.UnknownKeyException: "));

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    java.util.List var2 = var0.getRowKeys();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var5 = null;
    var3.setQuadrantPaint(1, var5);
    var3.configureDomainAxes();
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
    java.util.List var9 = var0.getRowKeys();
    java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.DatasetGroup var11 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)0.5f);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + 0.0d+ "'", var1.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0d+ "'", var10.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    java.lang.Comparable var0 = null;
    org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var3.getCategoryEnd(0, 0, var6, var7);
    float var9 = var3.getMaximumCategoryLabelWidthRatio();
    var3.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var13.setTickMarkOutsideLength(10.0f);
    org.jfree.chart.axis.CategoryLabelPositions var16 = var13.getCategoryLabelPositions();
    var3.setCategoryLabelPositions(var16);
    org.jfree.chart.axis.CategoryLabelPosition var18 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var19 = var18.getWidthRatio();
    org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var16, var18);
    double var21 = var18.getAngle();
    org.jfree.chart.text.TextBlockAnchor var22 = var18.getLabelAnchor();
    org.jfree.chart.text.TextBlock var24 = null;
    org.jfree.chart.text.TextBlockAnchor var25 = null;
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var33 = null;
    org.jfree.chart.ui.ProjectInfo var37 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var33, "hi!", "", "hi!");
    java.awt.Image var41 = null;
    org.jfree.chart.ui.ProjectInfo var45 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var41, "hi!", "", "hi!");
    var37.addLibrary((org.jfree.chart.ui.Library)var45);
    boolean var47 = var29.equals((java.lang.Object)var45);
    java.awt.Paint var49 = var29.lookupSeriesFillPaint(100);
    java.awt.Paint var51 = var29.getSeriesOutlinePaint(1);
    java.lang.Number var53 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var54 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var53);
    boolean var55 = var29.equals((java.lang.Object)var53);
    java.lang.Boolean var57 = var29.getSeriesCreateEntities(10);
    java.awt.Paint var58 = var29.getBaseFillPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var65 = null;
    org.jfree.chart.ui.ProjectInfo var69 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var65, "hi!", "", "hi!");
    java.awt.Image var73 = null;
    org.jfree.chart.ui.ProjectInfo var77 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var73, "hi!", "", "hi!");
    var69.addLibrary((org.jfree.chart.ui.Library)var77);
    boolean var79 = var61.equals((java.lang.Object)var77);
    var61.setUseOutlinePaint(false);
    java.awt.Stroke var84 = var61.getItemStroke(10, (-1));
    org.jfree.chart.plot.ValueMarker var85 = new org.jfree.chart.plot.ValueMarker(1.0d, var58, var84);
    var85.setLabel("hi!");
    java.awt.Paint var88 = var85.getLabelPaint();
    org.jfree.chart.text.TextAnchor var89 = var85.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var91 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(-1L), var24, var25, var89, 2.0d);
    org.jfree.chart.text.TextAnchor var92 = var91.getRotationAnchor();
    org.jfree.chart.axis.CategoryTick var94 = new org.jfree.chart.axis.CategoryTick(var0, var1, var22, var92, 100.0d);
    java.lang.String var95 = var22.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var95 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER"+ "'", var95.equals("TextBlockAnchor.BOTTOM_CENTER"));

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var4.isTickMarksVisible();
//     java.awt.Font var7 = var4.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     java.awt.Image var22 = null;
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
//     var18.addLibrary((org.jfree.chart.ui.Library)var26);
//     boolean var28 = var10.equals((java.lang.Object)var26);
//     java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
//     java.awt.Font var33 = var32.getFont();
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var37 = var36.clone();
//     boolean var38 = var36.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var41 = var40.clone();
//     var40.setAutoRange(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
//     java.awt.Font var48 = var45.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var45);
//     org.jfree.chart.util.HorizontalAlignment var50 = null;
//     org.jfree.chart.util.VerticalAlignment var51 = null;
//     org.jfree.chart.block.FlowArrangement var54 = new org.jfree.chart.block.FlowArrangement(var50, var51, (-1.0d), 0.0d);
//     org.jfree.chart.util.HorizontalAlignment var55 = null;
//     org.jfree.chart.util.VerticalAlignment var56 = null;
//     org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 0.0d, 0.05d);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45, (org.jfree.chart.block.Arrangement)var54, (org.jfree.chart.block.Arrangement)var59);
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var63 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var62};
//     var61.setRenderers(var63);
//     var60.setSources((org.jfree.chart.LegendItemSource[])var63);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var66 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     boolean var67 = var66.getAutoPopulateSeriesOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var70 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var72 = var70.getSeriesVisibleInLegend(10);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var74 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var70.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var74);
//     java.awt.Paint var78 = var70.getItemPaint(0, 0);
//     var66.setBasePaint(var78);
//     var60.setBackgroundPaint(var78);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var70.", var10.equals(var70) == var70.equals(var10));
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    java.awt.Font var7 = var4.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    java.awt.Image var22 = null;
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
    var18.addLibrary((org.jfree.chart.ui.Library)var26);
    boolean var28 = var10.equals((java.lang.Object)var26);
    java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var7, var30, 0.0f);
    java.awt.Font var33 = var32.getFont();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var37 = var36.clone();
    boolean var38 = var36.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var41 = var40.clone();
    var40.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var45, true);
    org.jfree.chart.event.ChartChangeEventType var48 = null;
    org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var47, var48);
    org.jfree.chart.event.ChartProgressListener var50 = null;
    var47.addProgressListener(var50);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var47.setTextAntiAlias((java.lang.Object)100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.getSubIntervalCount(1, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var5 = var4.clone();
    boolean var6 = var4.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var7);
    java.awt.Font var13 = null;
    org.jfree.chart.axis.MarkerAxisBand var14 = new org.jfree.chart.axis.MarkerAxisBand(var2, (-1.0d), (-1.0d), 100.0d, 10.0d, var13);
    var2.setAutoRangeMinimumSize(Double.POSITIVE_INFINITY, true);
    org.jfree.chart.renderer.category.StackedAreaRenderer var18 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Stroke var20 = var18.getSeriesOutlineStroke(15);
    org.jfree.chart.renderer.category.LayeredBarRenderer var21 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var24 = var21.getItemOutlinePaint(100, 0);
    var18.setBasePaint(var24, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var18.getBaseNegativeItemLabelPosition();
    org.jfree.data.category.CategoryDataset var29 = null;
    org.jfree.chart.axis.CategoryAxis var30 = null;
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var36 = var35.clone();
    boolean var37 = var35.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.axis.ValueAxis)var35, var38);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var44 = var42.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var29, var30, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var42);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var52 = null;
    org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var52, "hi!", "", "hi!");
    java.awt.Image var60 = null;
    org.jfree.chart.ui.ProjectInfo var64 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var60, "hi!", "", "hi!");
    var56.addLibrary((org.jfree.chart.ui.Library)var64);
    boolean var66 = var48.equals((java.lang.Object)var64);
    java.awt.Paint var68 = var48.lookupSeriesFillPaint(100);
    java.awt.Paint var70 = var48.getSeriesOutlinePaint(1);
    java.lang.Number var72 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var73 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var72);
    boolean var74 = var48.equals((java.lang.Object)var72);
    java.lang.Boolean var76 = var48.getSeriesCreateEntities(10);
    var45.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var48);
    java.lang.Object var78 = var45.clone();
    org.jfree.chart.axis.CategoryAnchor var79 = var45.getDomainGridlinePosition();
    java.awt.Stroke var80 = var45.getRangeCrosshairStroke();
    var18.setSeriesStroke(0, var80, true);
    var2.setTickMarkStroke(var80);
    java.awt.Shape var84 = var2.getUpArrow();
    org.jfree.chart.entity.TickLabelEntity var87 = new org.jfree.chart.entity.TickLabelEntity(var84, "Other", "[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(0L, (-2649600000L));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    java.awt.Paint var24 = var2.getSeriesOutlinePaint(1);
    java.lang.Number var26 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var26);
    boolean var28 = var2.equals((java.lang.Object)var26);
    java.lang.Boolean var30 = var2.getSeriesCreateEntities(10);
    boolean var31 = var2.getBaseLinesVisible();
    boolean var32 = var2.getBaseShapesFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    var0.addException(1L);
    boolean var4 = var0.containsDomainValue(1L);
    int var5 = var0.getGroupSegmentCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 96);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Color var2 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    int var3 = var2.getAlpha();
    var0.setLabelLinkPaint((java.awt.Paint)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = var0.getLegendLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var27 = var26.clone();
    boolean var28 = var26.isTickMarksVisible();
    java.awt.Font var29 = var26.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var36 = null;
    org.jfree.chart.ui.ProjectInfo var40 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var36, "hi!", "", "hi!");
    java.awt.Image var44 = null;
    org.jfree.chart.ui.ProjectInfo var48 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var44, "hi!", "", "hi!");
    var40.addLibrary((org.jfree.chart.ui.Library)var48);
    boolean var50 = var32.equals((java.lang.Object)var48);
    java.awt.Paint var52 = var32.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("", var29, var52, 0.0f);
    java.awt.Font var55 = var54.getFont();
    org.jfree.data.xy.XYDataset var56 = null;
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var59 = var58.clone();
    boolean var60 = var58.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var63 = var62.clone();
    var62.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
    org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var56, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.axis.ValueAxis)var62, var66);
    org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("", var55, (org.jfree.chart.plot.Plot)var67, true);
    org.jfree.chart.event.ChartProgressEvent var72 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var2, var69, 10, 1);
    org.jfree.chart.JFreeChart var73 = var72.getChart();
    var73.setBackgroundImageAlpha(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.category.GanttRenderer var3 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var4 = var3.getCompletePaint();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var12 = var11.clone();
//     boolean var13 = var11.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var20 = var18.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.LegendItemCollection var22 = null;
//     var21.setFixedLegendItems(var22);
//     org.jfree.data.general.DatasetChangeEvent var24 = null;
//     var21.datasetChanged(var24);
//     var21.setRangeCrosshairVisible(true);
//     var21.clearRangeMarkers();
//     var3.setPlot(var21);
//     org.jfree.chart.entity.EntityCollection var30 = null;
//     org.jfree.chart.ChartRenderingInfo var31 = new org.jfree.chart.ChartRenderingInfo(var30);
//     org.jfree.chart.entity.EntityCollection var32 = var31.getEntityCollection();
//     java.awt.geom.Rectangle2D var33 = var31.getChartArea();
//     var0.drawDomainGridline(var2, var21, var33, 4.7304E11d);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, Double.POSITIVE_INFINITY);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedHeight();
    double var5 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0d);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var16.datasetChanged(var19);
//     var16.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
//     boolean var24 = var16.isSubplot();
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var32 = var31.clone();
//     boolean var33 = var31.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.axis.ValueAxis)var31, var34);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var40 = var38.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var25, var26, (org.jfree.chart.axis.ValueAxis)var31, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
//     org.jfree.chart.LegendItemCollection var42 = null;
//     var41.setFixedLegendItems(var42);
//     org.jfree.data.general.DatasetChangeEvent var44 = null;
//     var41.datasetChanged(var44);
//     var41.setRangeCrosshairVisible(true);
//     org.jfree.chart.util.SortOrder var48 = var41.getColumnRenderingOrder();
//     var16.setRowRenderingOrder(var48);
//     
//     // Checks the contract:  equals-hashcode on var10 and var35
//     assertTrue("Contract failed: equals-hashcode on var10 and var35", var10.equals(var35) ? var10.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var10
//     assertTrue("Contract failed: equals-hashcode on var35 and var10", var35.equals(var10) ? var35.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlock var5 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     java.awt.Image var22 = null;
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var22, "hi!", "", "hi!");
//     var18.addLibrary((org.jfree.chart.ui.Library)var26);
//     boolean var28 = var10.equals((java.lang.Object)var26);
//     java.awt.Paint var30 = var10.lookupSeriesFillPaint(100);
//     java.awt.Paint var32 = var10.getSeriesOutlinePaint(1);
//     java.lang.Number var34 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var35 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var34);
//     boolean var36 = var10.equals((java.lang.Object)var34);
//     java.lang.Boolean var38 = var10.getSeriesCreateEntities(10);
//     java.awt.Paint var39 = var10.getBaseFillPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var46 = null;
//     org.jfree.chart.ui.ProjectInfo var50 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var46, "hi!", "", "hi!");
//     java.awt.Image var54 = null;
//     org.jfree.chart.ui.ProjectInfo var58 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var54, "hi!", "", "hi!");
//     var50.addLibrary((org.jfree.chart.ui.Library)var58);
//     boolean var60 = var42.equals((java.lang.Object)var58);
//     var42.setUseOutlinePaint(false);
//     java.awt.Stroke var65 = var42.getItemStroke(10, (-1));
//     org.jfree.chart.plot.ValueMarker var66 = new org.jfree.chart.plot.ValueMarker(1.0d, var39, var65);
//     var66.setLabel("hi!");
//     java.awt.Paint var69 = var66.getLabelPaint();
//     org.jfree.chart.text.TextAnchor var70 = var66.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var72 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(-1L), var5, var6, var70, 2.0d);
//     java.lang.String var73 = var72.toString();
//     java.lang.String var74 = var72.getText();
//     org.jfree.chart.text.TextAnchor var75 = var72.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.data.UnknownKeyException: ", var1, 10.0f, 100.0f, var75, 4.0d, 0.95f, 2.0f);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getStartValue(1, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var4 = var3.clone();
    boolean var5 = var3.isTickMarksVisible();
    java.awt.Font var6 = var3.getTickLabelFont();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var13, "hi!", "", "hi!");
    java.awt.Image var21 = null;
    org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var21, "hi!", "", "hi!");
    var17.addLibrary((org.jfree.chart.ui.Library)var25);
    boolean var27 = var9.equals((java.lang.Object)var25);
    java.awt.Paint var29 = var9.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var6, var29, 0.0f);
    java.awt.Font var32 = var31.getFont();
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var36 = var35.clone();
    boolean var37 = var35.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var40 = var39.clone();
    var39.setAutoRange(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var43);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var44, true);
    java.awt.Paint var47 = var46.getBorderPaint();
    org.jfree.chart.title.TextTitle var48 = null;
    var46.setTitle(var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var50 = var46.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var6 = null;
    org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
    var10.addLibrary((org.jfree.chart.ui.Library)var18);
    boolean var20 = var2.equals((java.lang.Object)var18);
    var2.setUseOutlinePaint(false);
    var2.setAutoPopulateSeriesOutlinePaint(true);
    var2.setSeriesLinesVisible(1969, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var9 = var7.getSeriesVisibleInLegend(10);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var11 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var7.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator)var11);
    var2.setSeriesToolTipGenerator(1, (org.jfree.chart.labels.CategoryToolTipGenerator)var11, true);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var16 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var15, 2);
    var15.removeValue((java.lang.Comparable)1.0d, (java.lang.Comparable)2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var24 = var11.generateToolTip((org.jfree.data.category.CategoryDataset)var15, 255, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 0.0d+ "'", var16.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.setVisible(false);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = null;
//     var4.setQuadrantPaint(1, var6);
//     var4.configureDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var4.zoomRangeAxes(Double.POSITIVE_INFINITY, var10, var11);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var21 = var20.clone();
//     boolean var22 = var20.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var20, var23);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var29 = var27.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var27);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var37 = null;
//     org.jfree.chart.ui.ProjectInfo var41 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var37, "hi!", "", "hi!");
//     java.awt.Image var45 = null;
//     org.jfree.chart.ui.ProjectInfo var49 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var45, "hi!", "", "hi!");
//     var41.addLibrary((org.jfree.chart.ui.Library)var49);
//     boolean var51 = var33.equals((java.lang.Object)var49);
//     java.awt.Paint var53 = var33.lookupSeriesFillPaint(100);
//     java.awt.Paint var55 = var33.getSeriesOutlinePaint(1);
//     java.lang.Number var57 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var58 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var57);
//     boolean var59 = var33.equals((java.lang.Object)var57);
//     java.lang.Boolean var61 = var33.getSeriesCreateEntities(10);
//     var30.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
//     java.lang.Object var63 = var30.clone();
//     org.jfree.chart.util.RectangleEdge var65 = var30.getRangeAxisEdge(1);
//     org.jfree.chart.axis.AxisSpace var66 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.AxisSpace var67 = var0.reserveSpace(var3, (org.jfree.chart.plot.Plot)var4, var13, var65, var66);
//     org.jfree.chart.block.LineBorder var68 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var69 = var68.getInsets();
//     org.jfree.chart.entity.EntityCollection var70 = null;
//     org.jfree.chart.ChartRenderingInfo var71 = new org.jfree.chart.ChartRenderingInfo(var70);
//     org.jfree.chart.entity.EntityCollection var72 = var71.getEntityCollection();
//     java.awt.geom.Rectangle2D var73 = var71.getChartArea();
//     java.awt.geom.Rectangle2D var76 = var69.createInsetRectangle(var73, true, true);
//     org.jfree.chart.block.LineBorder var77 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var78 = var77.getInsets();
//     org.jfree.chart.entity.EntityCollection var79 = null;
//     org.jfree.chart.ChartRenderingInfo var80 = new org.jfree.chart.ChartRenderingInfo(var79);
//     org.jfree.chart.entity.EntityCollection var81 = var80.getEntityCollection();
//     java.awt.geom.Rectangle2D var82 = var80.getChartArea();
//     java.awt.geom.Rectangle2D var85 = var78.createInsetRectangle(var82, true, true);
//     java.awt.geom.Rectangle2D var86 = var66.expand(var76, var85);
//     
//     // Checks the contract:  equals-hashcode on var68 and var77
//     assertTrue("Contract failed: equals-hashcode on var68 and var77", var68.equals(var77) ? var68.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var68
//     assertTrue("Contract failed: equals-hashcode on var77 and var68", var77.equals(var68) ? var77.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var80
//     assertTrue("Contract failed: equals-hashcode on var71 and var80", var71.equals(var80) ? var71.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var71
//     assertTrue("Contract failed: equals-hashcode on var80 and var71", var80.equals(var71) ? var80.hashCode() == var71.hashCode() : true);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var3, "hi!", "", "hi!");
    java.awt.Image var11 = null;
    org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var11, "hi!", "", "hi!");
    var7.addLibrary((org.jfree.chart.ui.Library)var15);
    var7.addOptionalLibrary("XY Plot");
    org.jfree.chart.ui.Library[] var19 = var7.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var6 = null;
//     org.jfree.chart.ui.ProjectInfo var10 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var6, "hi!", "", "hi!");
//     java.awt.Image var14 = null;
//     org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "hi!", "", "hi!");
//     var10.addLibrary((org.jfree.chart.ui.Library)var18);
//     boolean var20 = var2.equals((java.lang.Object)var18);
//     java.awt.Paint var22 = var2.lookupSeriesFillPaint(100);
//     java.awt.Paint var24 = var2.getSeriesOutlinePaint(1);
//     java.lang.Number var26 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var26);
//     boolean var28 = var2.equals((java.lang.Object)var26);
//     java.lang.Boolean var30 = var2.getSeriesCreateEntities(10);
//     boolean var31 = var2.getUseOutlinePaint();
//     var2.setSeriesShapesVisible(100, (java.lang.Boolean)false);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var41 = null;
//     org.jfree.chart.ui.ProjectInfo var45 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var41, "hi!", "", "hi!");
//     java.awt.Image var49 = null;
//     org.jfree.chart.ui.ProjectInfo var53 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var49, "hi!", "", "hi!");
//     var45.addLibrary((org.jfree.chart.ui.Library)var53);
//     boolean var55 = var37.equals((java.lang.Object)var53);
//     java.awt.Paint var57 = var37.lookupSeriesFillPaint(100);
//     java.awt.Paint var59 = var37.getSeriesOutlinePaint(1);
//     java.lang.Number var61 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var62 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)1.0d, var61);
//     boolean var63 = var37.equals((java.lang.Object)var61);
//     java.lang.Boolean var65 = var37.getSeriesCreateEntities(10);
//     boolean var66 = var37.getUseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var68 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var69 = new org.jfree.chart.labels.ItemLabelPosition();
//     var68.setNegativeItemLabelPositionFallback(var69);
//     var37.setSeriesPositiveItemLabelPosition(2, var69);
//     org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var74 = var73.clone();
//     boolean var75 = var73.isTickMarksVisible();
//     java.awt.Font var76 = var73.getTickLabelFont();
//     var73.setInverted(false);
//     org.jfree.chart.plot.XYPlot var79 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var81 = null;
//     var79.setQuadrantPaint(1, var81);
//     org.jfree.chart.axis.NumberAxis var84 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var85 = var84.clone();
//     var84.setAutoRange(true);
//     org.jfree.chart.axis.ValueAxis[] var88 = new org.jfree.chart.axis.ValueAxis[] { var84};
//     var79.setRangeAxes(var88);
//     boolean var90 = var73.equals((java.lang.Object)var88);
//     boolean var91 = var69.equals((java.lang.Object)var73);
//     var2.setBaseNegativeItemLabelPosition(var69, false);
//     
//     // Checks the contract:  equals-hashcode on var27 and var62
//     assertTrue("Contract failed: equals-hashcode on var27 and var62", var27.equals(var62) ? var27.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var27
//     assertTrue("Contract failed: equals-hashcode on var62 and var27", var62.equals(var27) ? var62.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     var19.setUseOutlinePaint(false);
//     java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
//     var16.setAnchorValue(100.0d, true);
//     var16.setDomainGridlinesVisible(false);
//     org.jfree.chart.plot.Marker var50 = null;
//     var16.addRangeMarker(var50);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var23 = null;
//     org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
//     java.awt.Image var31 = null;
//     org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
//     var27.addLibrary((org.jfree.chart.ui.Library)var35);
//     boolean var37 = var19.equals((java.lang.Object)var35);
//     var19.setUseOutlinePaint(false);
//     java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
//     var16.setAnchorValue(100.0d, true);
//     org.jfree.chart.axis.AxisSpace var48 = null;
//     var16.setFixedRangeAxisSpace(var48);
//     org.jfree.chart.plot.PlotOrientation var50 = var16.getOrientation();
//     org.jfree.data.category.CategoryDataset var51 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     org.jfree.data.xy.XYDataset var53 = null;
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var58 = var57.clone();
//     boolean var59 = var57.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var53, (org.jfree.chart.axis.ValueAxis)var55, (org.jfree.chart.axis.ValueAxis)var57, var60);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var64 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var66 = var64.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot(var51, var52, (org.jfree.chart.axis.ValueAxis)var57, (org.jfree.chart.renderer.category.CategoryItemRenderer)var64);
//     org.jfree.chart.LegendItemCollection var68 = null;
//     var67.setFixedLegendItems(var68);
//     org.jfree.data.general.DatasetChangeEvent var70 = null;
//     var67.datasetChanged(var70);
//     var67.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.JFreeChart var74 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var67);
//     org.jfree.chart.axis.CategoryAxis var76 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryAxis[] var77 = new org.jfree.chart.axis.CategoryAxis[] { var76};
//     var67.setDomainAxes(var77);
//     var16.setDomainAxes(var77);
//     
//     // Checks the contract:  equals-hashcode on var10 and var61
//     assertTrue("Contract failed: equals-hashcode on var10 and var61", var10.equals(var61) ? var10.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var10
//     assertTrue("Contract failed: equals-hashcode on var61 and var10", var61.equals(var10) ? var61.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.awt.Image var23 = null;
    org.jfree.chart.ui.ProjectInfo var27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var23, "hi!", "", "hi!");
    java.awt.Image var31 = null;
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var31, "hi!", "", "hi!");
    var27.addLibrary((org.jfree.chart.ui.Library)var35);
    boolean var37 = var19.equals((java.lang.Object)var35);
    var19.setUseOutlinePaint(false);
    java.awt.Stroke var42 = var19.getItemStroke(10, (-1));
    var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
    var16.setAnchorValue(100.0d, true);
    var16.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.ValueAxis var51 = var16.getRangeAxisForDataset(0);
    org.jfree.data.xy.XYDataset var52 = null;
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var57 = var56.clone();
    boolean var58 = var56.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var59 = null;
    org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.axis.ValueAxis)var56, var59);
    org.jfree.data.Range var61 = var56.getRange();
    org.jfree.data.Range var64 = org.jfree.data.Range.expand(var61, 10.0d, 0.0d);
    java.lang.String var65 = var61.toString();
    var51.setRange(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "Range[0.0,1.05]"+ "'", var65.equals("Range[0.0,1.05]"));

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.lang.Object var7 = var6.clone();
    boolean var8 = var6.isTickMarksVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    java.lang.Boolean var15 = var13.getSeriesVisibleInLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.data.general.DatasetChangeEvent var19 = null;
    var16.datasetChanged(var19);
    var16.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var23 = var16.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var25 = var23.get(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
//     var0.setBaseShape(var3);
//     java.awt.Stroke var6 = null;
//     var0.setSeriesOutlineStroke(100, var6, false);
//     java.lang.Boolean var10 = var0.getSeriesCreateEntities(96);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var19 = var18.clone();
//     boolean var20 = var18.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var18, var21);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.lang.Boolean var27 = var25.getSeriesVisibleInLegend(10);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     java.awt.Image var35 = null;
//     org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var35, "hi!", "", "hi!");
//     java.awt.Image var43 = null;
//     org.jfree.chart.ui.ProjectInfo var47 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var43, "hi!", "", "hi!");
//     var39.addLibrary((org.jfree.chart.ui.Library)var47);
//     boolean var49 = var31.equals((java.lang.Object)var47);
//     var31.setUseOutlinePaint(false);
//     java.awt.Stroke var54 = var31.getItemStroke(10, (-1));
//     var28.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var31, false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var59 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var60 = var59.getPositiveItemLabelPositionFallback();
//     var59.setMaximumBarWidth(0.05d);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var63 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     boolean var64 = var59.equals((java.lang.Object)var63);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("");
//     java.lang.Object var70 = var69.clone();
//     boolean var71 = var69.isTickMarksVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var72 = null;
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot(var65, (org.jfree.chart.axis.ValueAxis)var67, (org.jfree.chart.axis.ValueAxis)var69, var72);
//     java.awt.Font var78 = null;
//     org.jfree.chart.axis.MarkerAxisBand var79 = new org.jfree.chart.axis.MarkerAxisBand(var67, (-1.0d), (-1.0d), 100.0d, 10.0d, var78);
//     boolean var80 = var67.isPositiveArrowVisible();
//     org.jfree.chart.block.LineBorder var81 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var82 = var81.getInsets();
//     org.jfree.chart.entity.EntityCollection var83 = null;
//     org.jfree.chart.ChartRenderingInfo var84 = new org.jfree.chart.ChartRenderingInfo(var83);
//     org.jfree.chart.entity.EntityCollection var85 = var84.getEntityCollection();
//     java.awt.geom.Rectangle2D var86 = var84.getChartArea();
//     java.awt.geom.Rectangle2D var89 = var82.createInsetRectangle(var86, true, true);
//     var67.setUpArrow((java.awt.Shape)var86);
//     var63.setBaseShape((java.awt.Shape)var86);
//     var0.drawOutline(var11, var28, var86);
// 
//   }

}
