
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     int var6 = var4.getDomainAxisIndex(var5);
//     var4.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisLocation var10 = var4.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 10.0d);
//     org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var15);
//     boolean var18 = var15.equals((java.lang.Object)"RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     org.jfree.chart.util.HorizontalAlignment var19 = null;
//     org.jfree.chart.util.VerticalAlignment var20 = null;
//     org.jfree.chart.block.FlowArrangement var23 = new org.jfree.chart.block.FlowArrangement(var19, var20, 100.0d, 10.0d);
//     org.jfree.chart.block.BlockContainer var24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var23);
//     org.jfree.chart.block.Arrangement var25 = var24.getArrangement();
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4, (org.jfree.chart.block.Arrangement)var15, var25);
//     
//     // Checks the contract:  equals-hashcode on var15 and var23
//     assertTrue("Contract failed: equals-hashcode on var15 and var23", var15.equals(var23) ? var15.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var15
//     assertTrue("Contract failed: equals-hashcode on var23 and var15", var23.equals(var15) ? var23.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var24
//     assertTrue("Contract failed: equals-hashcode on var16 and var24", var16.equals(var24) ? var16.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var16
//     assertTrue("Contract failed: equals-hashcode on var24 and var16", var24.equals(var16) ? var24.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.configureDomainAxes();
    var4.clearRangeMarkers(1);
    org.jfree.data.general.DatasetGroup var22 = var4.getDatasetGroup();
    var4.mapDatasetToDomainAxis(0, (-1));
    var4.setDomainCrosshairLockedOnData(true);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    var33.setForegroundAlpha(0.0f);
    float var36 = var33.getBackgroundImageAlpha();
    boolean var37 = var33.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var38 = var33.getRangeAxisEdge();
    java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var33);
    java.awt.Paint var40 = var33.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var44 = var42.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var45 = var42.getLowerMargin();
    var42.setCategoryLabelPositionOffset(1);
    double var48 = var42.getUpperMargin();
    java.awt.Stroke var49 = var42.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(100.0d, var40, var49);
    java.awt.Stroke var51 = var50.getStroke();
    org.jfree.chart.util.LengthAdjustmentType var52 = var50.getLabelOffsetType();
    org.jfree.chart.util.Layer var53 = null;
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var50, var53);
    org.jfree.chart.axis.ValueAxis var56 = var4.getDomainAxis(1);
    org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.RectangleAnchor var59 = var58.getLabelAnchor();
    org.jfree.chart.util.Layer var60 = null;
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var58, var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    var1.configure();
    org.jfree.chart.axis.Timeline var3 = null;
    var1.setTimeline(var3);
    double var5 = var1.getUpperBound();
    org.jfree.data.Range var6 = var1.getRange();
    double var7 = var1.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.Paint var10 = var9.getDomainCrosshairPaint();
//     var4.setBackgroundPaint(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var4.zoomDomainAxes((-1.0d), var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
//     var4.setDomainAxes(var17);
//     org.jfree.chart.axis.AxisLocation var20 = var4.getDomainAxisLocation(0);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     int var29 = var27.getDomainAxisIndex(var28);
//     var27.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var32 = var27.getRangeAxisEdge();
//     java.awt.Paint var33 = var27.getRangeTickBandPaint();
//     var27.configureDomainAxes();
//     java.awt.geom.Point2D var35 = var27.getQuadrantOrigin();
//     var4.zoomDomainAxes(108.0d, var22, var35, false);
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var41 = var40.getCategoryLabelPositions();
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     boolean var44 = var43.isVerticalTickLabels();
//     org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var48 = var46.getTickLabelPaint((java.lang.Comparable)(-1.0f));
//     var43.setTickMarkPaint(var48);
//     var43.setNegativeArrowVisible(false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var38, var40, (org.jfree.chart.axis.ValueAxis)var43, var52);
//     org.jfree.data.xy.XYDataset var54 = null;
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var54, var55, var56, var57);
//     org.jfree.data.xy.XYDataset var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var62 = null;
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot(var59, var60, var61, var62);
//     java.awt.Paint var64 = var63.getDomainCrosshairPaint();
//     var58.setBackgroundPaint(var64);
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     java.awt.geom.Point2D var68 = null;
//     var58.zoomDomainAxes((-1.0d), var67, var68);
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.axis.ValueAxis[] var71 = new org.jfree.chart.axis.ValueAxis[] { var70};
//     var58.setDomainAxes(var71);
//     var58.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var75 = var58.getDomainAxisLocation((-65536));
//     org.jfree.data.xy.XYDataset var76 = null;
//     org.jfree.chart.axis.ValueAxis var77 = null;
//     org.jfree.chart.axis.ValueAxis var78 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var79 = null;
//     org.jfree.chart.plot.XYPlot var80 = new org.jfree.chart.plot.XYPlot(var76, var77, var78, var79);
//     java.awt.Paint var81 = var80.getDomainCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var83 = null;
//     java.awt.geom.Point2D var84 = null;
//     var80.zoomDomainAxes(100.0d, var83, var84, false);
//     var80.setRangeCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var90 = var80.getOrientation();
//     org.jfree.chart.util.RectangleEdge var91 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var75, var90);
//     var53.setDomainAxisLocation(var75, false);
//     org.jfree.data.category.CategoryDataset var95 = null;
//     var53.setDataset(0, var95);
//     org.jfree.chart.event.PlotChangeEvent var97 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var53);
//     var4.setParent((org.jfree.chart.plot.Plot)var53);
//     
//     // Checks the contract:  equals-hashcode on var4 and var58
//     assertTrue("Contract failed: equals-hashcode on var4 and var58", var4.equals(var58) ? var4.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var63
//     assertTrue("Contract failed: equals-hashcode on var9 and var63", var9.equals(var63) ? var9.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var4
//     assertTrue("Contract failed: equals-hashcode on var58 and var4", var58.equals(var4) ? var58.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var9
//     assertTrue("Contract failed: equals-hashcode on var63 and var9", var63.equals(var9) ? var63.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.Paint var6 = var5.getDomainCrosshairPaint();
    java.awt.Stroke var7 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var11 = var10.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var15 = var13.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var10.setTickMarkPaint(var15);
    var5.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var20 = var19.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var21 = null;
    var19.setTickUnit(var21);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var19, var23);
    float var25 = var19.getTickMarkInsideLength();
    boolean var26 = var19.isAutoTickUnitSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    float var20 = var9.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.5f);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    var4.setRenderer(var16);
    org.jfree.chart.axis.AxisSpace var18 = null;
    var4.setFixedDomainAxisSpace(var18);
    java.awt.Paint var20 = var4.getDomainGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
//     java.text.NumberFormat var3 = var2.getPercentFormat();
//     org.jfree.data.Range var5 = null;
//     org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 100.0d);
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var11 = var10.toUnconstrainedHeight();
//     org.jfree.chart.block.RectangleConstraint var13 = var10.toFixedHeight(0.0d);
//     org.jfree.chart.block.LengthConstraintType var14 = var13.getWidthConstraintType();
//     java.lang.String var15 = var14.toString();
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 100.0d);
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, 100.0d);
//     boolean var24 = var22.contains((-1.0d));
//     org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var19, var22);
//     org.jfree.data.Range var26 = null;
//     org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var26, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var29 = var28.toUnconstrainedHeight();
//     org.jfree.chart.block.RectangleConstraint var31 = var28.toFixedHeight(0.0d);
//     org.jfree.chart.block.LengthConstraintType var32 = var31.getWidthConstraintType();
//     java.lang.String var33 = var32.toString();
//     org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(100.0d, var7, var14, (-1.0d), var19, var32);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
//     java.lang.String var37 = var36.getLabelFormat();
//     boolean var38 = var32.equals((java.lang.Object)var36);
//     java.text.NumberFormat var39 = var36.getNumberFormat();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var40 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(" version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", var3, var39);
//     
//     // Checks the contract:  equals-hashcode on var2 and var36
//     assertTrue("Contract failed: equals-hashcode on var2 and var36", var2.equals(var36) ? var2.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var2
//     assertTrue("Contract failed: equals-hashcode on var36 and var2", var36.equals(var2) ? var36.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getDomainCrosshairPaint();
    boolean var6 = var4.isDomainGridlinesVisible();
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    var11.setForegroundAlpha(0.0f);
    float var14 = var11.getBackgroundImageAlpha();
    boolean var15 = var11.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var16 = var11.getRangeAxisEdge();
    org.jfree.chart.plot.PlotOrientation var17 = var11.getOrientation();
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var20 = var19.isVerticalTickLabels();
    org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
    var11.setDomainAxis((org.jfree.chart.axis.ValueAxis)var19);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    java.awt.Paint var34 = var33.getDomainCrosshairPaint();
    var28.setBackgroundPaint(var34);
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    java.awt.geom.Point2D var38 = null;
    var28.zoomDomainAxes((-1.0d), var37, var38);
    var28.setNoDataMessage("hi!");
    var28.zoom(10.0d);
    org.jfree.chart.plot.DrawingSupplier var44 = null;
    var28.setDrawingSupplier(var44);
    var28.setDomainZeroBaselineVisible(true);
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.Layer var51 = null;
    var28.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var50, var51);
    org.jfree.chart.util.Layer var53 = null;
    var11.addRangeMarker(10, (org.jfree.chart.plot.Marker)var50, var53);
    var50.setAlpha(1.0f);
    org.jfree.chart.util.Layer var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker((org.jfree.chart.plot.Marker)var50, var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getDomainCrosshairPaint();
    boolean var6 = var4.isDomainGridlinesVisible();
    var4.setBackgroundImageAlpha(1.0f);
    java.awt.Font var10 = null;
    java.awt.Font var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    java.awt.Paint var18 = var17.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var12, (org.jfree.chart.plot.Plot)var17, true);
    org.jfree.chart.title.Title var21 = null;
    var20.removeSubtitle(var21);
    int var23 = var20.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var29 = var28.getPaint();
    var20.setBorderPaint(var29);
    org.jfree.chart.text.TextMeasurer var33 = null;
    org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, var29, 10.0f, 100, var33);
    var4.setOutlinePaint(var29);
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
    org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
    var40.setForegroundAlpha(0.0f);
    var40.mapDatasetToRangeAxis(0, 10);
    org.jfree.chart.axis.ValueAxis var46 = null;
    int var47 = var40.getRangeAxisIndex(var46);
    org.jfree.chart.axis.ValueAxis var48 = null;
    int var49 = var40.getRangeAxisIndex(var48);
    org.jfree.data.xy.XYDataset var50 = null;
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.axis.ValueAxis var52 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
    org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var50, var51, var52, var53);
    org.jfree.chart.axis.ValueAxis var55 = null;
    int var56 = var54.getDomainAxisIndex(var55);
    var54.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var59 = var54.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var61 = var54.getRangeAxisLocation((-1));
    var40.setRangeAxisLocation(var61, false);
    var4.setRangeAxisLocation(var61);
    org.jfree.chart.axis.DateAxis var66 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    var66.configure();
    int var68 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == (-1));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.axis.ValueAxis var26 = null;
    int var27 = var25.getDomainAxisIndex(var26);
    var25.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
    boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
    java.lang.String var32 = var30.toString();
    var20.setLegendItemGraphicEdge(var30);
    org.jfree.chart.block.BlockContainer var34 = null;
    var20.setWrapper(var34);
    java.lang.Object var36 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
    double var37 = var20.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "RectangleEdge.LEFT"+ "'", var32.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    var4.mapDatasetToRangeAxis(0, 10);
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation();
    org.jfree.chart.LegendItemCollection var11 = var4.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    java.awt.Paint var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    var6.setForegroundAlpha(0.0f);
    float var9 = var6.getBackgroundImageAlpha();
    boolean var10 = var6.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var11 = var6.getRangeAxisEdge();
    java.awt.Stroke var12 = var6.getRangeGridlineStroke();
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    org.jfree.chart.axis.ValueAxis var18 = null;
    int var19 = var17.getDomainAxisIndex(var18);
    var17.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var22 = var17.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var23 = var17.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var27 = var25.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var17.setRangeGridlinePaint(var27);
    java.awt.Font var30 = null;
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
    java.awt.Paint var36 = var35.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("", var30, (org.jfree.chart.plot.Plot)var35, true);
    org.jfree.chart.title.Title var39 = null;
    var38.removeSubtitle(var39);
    org.jfree.chart.event.ChartProgressListener var41 = null;
    var38.removeProgressListener(var41);
    var38.clearSubtitles();
    boolean var44 = var38.isBorderVisible();
    org.jfree.data.xy.XYDataset var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
    org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var45, var46, var47, var48);
    var49.setForegroundAlpha(0.0f);
    float var52 = var49.getBackgroundImageAlpha();
    boolean var53 = var49.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var54 = var49.getRangeAxisEdge();
    java.lang.Object var55 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var49);
    java.awt.Paint var56 = var49.getOutlinePaint();
    java.awt.Stroke var57 = var49.getRangeZeroBaselineStroke();
    var38.setBorderStroke(var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(0.0d, var1, var12, var27, var57, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    org.jfree.chart.title.TextTitle var13 = var9.getTitle();
    var13.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.lang.Object var19 = var13.clone();
    org.jfree.data.Range var20 = null;
    org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, 100.0d);
    boolean var24 = var22.contains((-1.0d));
    boolean var25 = var13.equals((java.lang.Object)(-1.0d));
    var13.setText("");
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var31 = var29.getTickLabelFont((java.lang.Comparable)(byte)100);
    var13.setFont(var31);
    java.lang.String var33 = var13.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }


    float[] var3 = null;
    float[] var4 = java.awt.Color.RGBtoHSB(0, 100, 10, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     int var6 = var4.getDomainAxisIndex(var5);
//     var4.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
//     java.awt.Paint var10 = var4.getRangeTickBandPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     int var19 = var17.getDomainAxisIndex(var18);
//     var17.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var22 = var17.getRangeAxisEdge();
//     java.awt.Paint var23 = var17.getRangeTickBandPaint();
//     var17.configureDomainAxes();
//     java.awt.geom.Point2D var25 = var17.getQuadrantOrigin();
//     var4.zoomDomainAxes(208.0d, var12, var25);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.Paint var6 = var5.getDomainCrosshairPaint();
    java.awt.Stroke var7 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var11 = var10.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var15 = var13.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var10.setTickMarkPaint(var15);
    var5.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var20 = var19.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var21 = null;
    var19.setTickUnit(var21);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var19, var23);
    java.awt.Font var25 = var24.getNoDataMessageFont();
    java.awt.Stroke var26 = var24.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
    var7.addOptionalLibrary("");
    java.lang.String var10 = var7.getVersion();
    java.util.List var11 = var7.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "hi!"+ "'", var10.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    boolean var10 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var9);
    java.lang.String var11 = var9.toString();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var16 = var14.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var17 = var14.getLowerMargin();
    var14.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var12, var14, var20, var21);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = var22.getRendererForDataset(var23);
    org.jfree.chart.LegendItemCollection var25 = var22.getFixedLegendItems();
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var22.getRangeMarkers(var26);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    var34.setForegroundAlpha(0.0f);
    float var37 = var34.getBackgroundImageAlpha();
    boolean var38 = var34.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var39 = var34.getRangeAxisEdge();
    java.lang.Object var40 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var34);
    java.awt.Paint var41 = var34.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var45 = var43.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var46 = var43.getLowerMargin();
    var43.setCategoryLabelPositionOffset(1);
    double var49 = var43.getUpperMargin();
    java.awt.Stroke var50 = var43.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(100.0d, var41, var50);
    java.awt.Stroke var52 = var51.getStroke();
    org.jfree.chart.util.LengthAdjustmentType var53 = var51.getLabelOffsetType();
    org.jfree.chart.util.Layer var54 = null;
    var22.addRangeMarker(0, (org.jfree.chart.plot.Marker)var51, var54);
    boolean var56 = var9.equals((java.lang.Object)var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleEdge.LEFT"+ "'", var11.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    var4.setRenderer(var16);
    boolean var18 = var4.isRangeZeroBaselineVisible();
    var4.setRangeZeroBaselineVisible(false);
    var4.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var10 = var4.getDomainAxisEdge(100);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var13 = var12.isVerticalTickLabels();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    int var15 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.configureDomainAxes();
    var4.clearRangeMarkers(1);
    org.jfree.data.general.DatasetGroup var22 = var4.getDatasetGroup();
    var4.mapDatasetToDomainAxis(0, (-1));
    var4.setDomainCrosshairLockedOnData(true);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    int var30 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
    org.jfree.chart.event.AxisChangeListener var31 = null;
    var29.removeChangeListener(var31);
    boolean var33 = var29.isInverted();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.configureDomainAxes();
    var4.clearRangeMarkers(10);
    org.jfree.chart.annotations.XYAnnotation var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var9.removeProgressListener(var12);
    var9.clearSubtitles();
    org.jfree.chart.title.TextTitle var15 = var9.getTitle();
    java.lang.String var16 = var15.getToolTipText();
    java.awt.Paint var17 = var15.getPaint();
    java.lang.String var18 = var15.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test26"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.Paint var10 = var9.getDomainCrosshairPaint();
//     var4.setBackgroundPaint(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var4.zoomDomainAxes((-1.0d), var13, var14);
//     var4.setNoDataMessage("");
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var22 = var20.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var23 = var20.getLowerMargin();
//     var20.setCategoryLabelPositionOffset(1);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var18, var20, var26, var27);
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var31 = var30.isVisible();
//     java.util.List var32 = var28.getCategoriesForAxis(var30);
//     var30.setVisible(true);
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
//     java.awt.Paint var42 = var41.getDomainCrosshairPaint();
//     java.awt.Stroke var43 = var41.getDomainZeroBaselineStroke();
//     var36.setOutlineStroke(var43);
//     var30.setAxisLineStroke(var43);
//     java.awt.Paint var46 = var30.getAxisLinePaint();
//     var4.setNoDataMessagePaint(var46);
//     
//     // Checks the contract:  equals-hashcode on var9 and var41
//     assertTrue("Contract failed: equals-hashcode on var9 and var41", var9.equals(var41) ? var9.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var9
//     assertTrue("Contract failed: equals-hashcode on var41 and var9", var41.equals(var9) ? var41.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test27"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(10.0d, (-8.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test28"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var5 = var2.getLowerMargin();
//     var2.setCategoryLabelPositionOffset(1);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var13 = var12.isVisible();
//     java.util.List var14 = var10.getCategoriesForAxis(var12);
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     java.awt.Paint var21 = var20.getDomainCrosshairPaint();
//     boolean var22 = var20.isDomainGridlinesVisible();
//     var20.setBackgroundImageAlpha(1.0f);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
//     java.awt.Paint var35 = var34.getDomainCrosshairPaint();
//     var29.setBackgroundPaint(var35);
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     java.awt.geom.Point2D var39 = null;
//     var29.zoomDomainAxes((-1.0d), var38, var39);
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var41};
//     var29.setDomainAxes(var42);
//     org.jfree.chart.axis.AxisLocation var45 = var29.getDomainAxisLocation(0);
//     var20.setDomainAxisLocation(var45, false);
//     var10.setRangeAxisLocation(10, var45, true);
//     org.jfree.data.category.CategoryDataset var50 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var54 = var52.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var55 = var52.getLowerMargin();
//     var52.setCategoryLabelPositionOffset(1);
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var50, var52, var58, var59);
//     org.jfree.data.category.CategoryDataset var61 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var62 = var60.getRendererForDataset(var61);
//     org.jfree.chart.util.RectangleEdge var64 = var60.getDomainAxisEdge(0);
//     boolean var65 = var60.isDomainZoomable();
//     var60.setRangeCrosshairVisible(false);
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var68, var69, var70, var71);
//     java.awt.Paint var73 = var72.getDomainCrosshairPaint();
//     java.awt.Stroke var74 = var72.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.DatasetRenderingOrder var75 = var72.getDatasetRenderingOrder();
//     var60.setDatasetRenderingOrder(var75);
//     org.jfree.chart.plot.PlotOrientation var77 = var60.getOrientation();
//     org.jfree.chart.util.RectangleEdge var78 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var45, var77);
//     
//     // Checks the contract:  equals-hashcode on var60 and var10
//     assertTrue("Contract failed: equals-hashcode on var60 and var10", var60.equals(var10) ? var60.hashCode() == var10.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var60 and var10.", var60.equals(var10) == var10.equals(var60));
//     
//     // Checks the contract:  equals-hashcode on var34 and var72
//     assertTrue("Contract failed: equals-hashcode on var34 and var72", var34.equals(var72) ? var34.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var34
//     assertTrue("Contract failed: equals-hashcode on var72 and var34", var72.equals(var34) ? var72.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test29"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    java.util.List var13 = var9.getSubtitles();
    var9.setBackgroundImageAlpha((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test30"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     int var12 = var9.getBackgroundImageAlignment();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
//     java.awt.Paint var18 = var17.getPaint();
//     var9.setBorderPaint(var18);
//     org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     int var27 = var25.getDomainAxisIndex(var26);
//     var25.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
//     boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
//     java.lang.String var32 = var30.toString();
//     var20.setLegendItemGraphicEdge(var30);
//     org.jfree.chart.block.BlockContainer var34 = null;
//     var20.setWrapper(var34);
//     java.lang.Object var36 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
//     var20.setMargin((-1.0d), 0.0d, 100.0d, 100.0d);
//     org.jfree.chart.util.RectangleInsets var42 = var20.getPadding();
//     org.jfree.chart.text.TextLine var44 = new org.jfree.chart.text.TextLine("");
//     java.awt.Font var47 = null;
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
//     java.awt.Paint var53 = var52.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("", var47, (org.jfree.chart.plot.Plot)var52, true);
//     org.jfree.chart.title.Title var56 = null;
//     var55.removeSubtitle(var56);
//     org.jfree.chart.plot.Plot var58 = var55.getPlot();
//     org.jfree.chart.title.TextTitle var59 = var55.getTitle();
//     var59.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.awt.geom.Rectangle2D var65 = var59.getBounds();
//     var59.setToolTipText("hi!");
//     org.jfree.chart.block.BlockFrame var68 = var59.getFrame();
//     org.jfree.chart.axis.CategoryAxis var70 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var71 = var70.getCategoryLabelPositions();
//     java.awt.Font var72 = var70.getTickLabelFont();
//     var59.setFont(var72);
//     org.jfree.chart.text.TextFragment var74 = new org.jfree.chart.text.TextFragment("", var72);
//     java.lang.String var75 = var74.getText();
//     float var76 = var74.getBaselineOffset();
//     float var77 = var74.getBaselineOffset();
//     var44.removeFragment(var74);
//     java.awt.Font var79 = var74.getFont();
//     var20.setItemFont(var79);
//     
//     // Checks the contract:  equals-hashcode on var6 and var52
//     assertTrue("Contract failed: equals-hashcode on var6 and var52", var6.equals(var52) ? var6.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var6
//     assertTrue("Contract failed: equals-hashcode on var52 and var6", var52.equals(var6) ? var52.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test31"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]", var1, (-1.0f), (-1.0f), var4, 10.0d, var6);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test32"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 100.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedWidth((-1.0d));
    java.lang.String var5 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var5.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test33"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    java.awt.Paint var10 = var4.getRangeTickBandPaint();
    java.awt.Stroke var11 = var4.getDomainCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test34"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(1, var25);
    java.lang.String var27 = var10.getPlotType();
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var31 = var30.isVerticalTickLabels();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    var10.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var30);
    var30.setLowerBound((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Category Plot"+ "'", var27.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test35"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     int var6 = var4.getDomainAxisIndex(var5);
//     var4.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisLocation var10 = var4.getDomainAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var14 = var12.getTickLabelPaint((java.lang.Comparable)(-1.0f));
//     var4.setRangeGridlinePaint(var14);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var4.zoomDomainAxes((-1.0d), var17, var18);
//     var4.zoom(100.0d);
//     boolean var22 = var4.isSubplot();
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     var24.configure();
//     org.jfree.chart.axis.Timeline var26 = null;
//     var24.setTimeline(var26);
//     double var28 = var24.getUpperBound();
//     var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var24);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test36"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    var5.setForegroundAlpha(0.0f);
    float var8 = var5.getBackgroundImageAlpha();
    boolean var9 = var5.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var10 = var5.getRangeAxisEdge();
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
    java.awt.Paint var12 = var5.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var16 = var14.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var17 = var14.getLowerMargin();
    var14.setCategoryLabelPositionOffset(1);
    double var20 = var14.getUpperMargin();
    java.awt.Stroke var21 = var14.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(100.0d, var12, var21);
    java.lang.String var23 = var22.getLabel();
    org.jfree.chart.util.RectangleAnchor var24 = var22.getLabelAnchor();
    org.jfree.chart.text.TextAnchor var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setLabelTextAnchor(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test37"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(byte)100);
    var1.setLabelURL("");
    var1.setMaximumCategoryLabelLines((-65536));
    var1.setFixedDimension(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test38"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    float var7 = var4.getBackgroundImageAlpha();
    boolean var8 = var4.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    org.jfree.chart.plot.PlotOrientation var10 = var4.getOrientation();
    float var11 = var4.getForegroundAlpha();
    org.jfree.data.xy.XYDataset var13 = null;
    var4.setDataset(253, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0f);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test39"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var10.getRangeMarkers(var14);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var10.getDomainMarkers(var16);
    org.jfree.chart.axis.AxisSpace var18 = null;
    var10.setFixedRangeAxisSpace(var18);
    java.awt.Stroke var20 = var10.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test40"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var6 = var4.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var1.setTickMarkPaint(var6);
    var1.setNegativeArrowVisible(false);
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 100.0d);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    boolean var18 = var16.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var13, var16);
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(100.0d, var16);
    var1.setRange(var16, true, false);
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var16, 108.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test41"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var10.getRangeMarkers(var14);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    var22.setForegroundAlpha(0.0f);
    float var25 = var22.getBackgroundImageAlpha();
    boolean var26 = var22.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var27 = var22.getRangeAxisEdge();
    java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var22);
    java.awt.Paint var29 = var22.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var33 = var31.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var34 = var31.getLowerMargin();
    var31.setCategoryLabelPositionOffset(1);
    double var37 = var31.getUpperMargin();
    java.awt.Stroke var38 = var31.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(100.0d, var29, var38);
    java.awt.Stroke var40 = var39.getStroke();
    org.jfree.chart.util.LengthAdjustmentType var41 = var39.getLabelOffsetType();
    org.jfree.chart.util.Layer var42 = null;
    var10.addRangeMarker(0, (org.jfree.chart.plot.Marker)var39, var42);
    java.awt.Font var44 = var39.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test42"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(1, var25);
    org.jfree.chart.util.Layer var28 = null;
    java.util.Collection var29 = var10.getRangeMarkers(0, var28);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    var34.setForegroundAlpha(0.0f);
    var34.mapDatasetToRangeAxis(0, 10);
    org.jfree.chart.axis.ValueAxis var40 = null;
    int var41 = var34.getRangeAxisIndex(var40);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
    java.awt.Paint var52 = var51.getDomainCrosshairPaint();
    var46.setBackgroundPaint(var52);
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    java.awt.geom.Point2D var56 = null;
    var46.zoomDomainAxes((-1.0d), var55, var56);
    var46.setNoDataMessage("hi!");
    var46.zoom(10.0d);
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.axis.ValueAxis[] var63 = new org.jfree.chart.axis.ValueAxis[] { var62};
    var46.setDomainAxes(var63);
    var34.setDomainAxes(var63);
    var10.setRangeAxes(var63);
    java.awt.Paint var67 = var10.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test43"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("PieSection: -10, 0(1)");
    boolean var2 = var1.getAutoRangeIncludesZero();
    var1.setAutoRangeIncludesZero(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test44"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(1, var25);
    org.jfree.chart.util.Layer var28 = null;
    java.util.Collection var29 = var10.getRangeMarkers(0, var28);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    var34.setForegroundAlpha(0.0f);
    var34.mapDatasetToRangeAxis(0, 10);
    org.jfree.chart.axis.ValueAxis var40 = null;
    int var41 = var34.getRangeAxisIndex(var40);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
    java.awt.Paint var52 = var51.getDomainCrosshairPaint();
    var46.setBackgroundPaint(var52);
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    java.awt.geom.Point2D var56 = null;
    var46.zoomDomainAxes((-1.0d), var55, var56);
    var46.setNoDataMessage("hi!");
    var46.zoom(10.0d);
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.axis.ValueAxis[] var63 = new org.jfree.chart.axis.ValueAxis[] { var62};
    var46.setDomainAxes(var63);
    var34.setDomainAxes(var63);
    var10.setRangeAxes(var63);
    org.jfree.chart.util.Layer var68 = null;
    java.util.Collection var69 = var10.getDomainMarkers(100, var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test45"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var3 = var2.getCategoryLabelPositions();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var6 = var5.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var10 = var8.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var5.setTickMarkPaint(var10);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var5, var14);
    var15.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var24 = var22.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var25 = var22.getLowerMargin();
    var22.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var20, var22, var28, var29);
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = var30.getRendererForDataset(var31);
    org.jfree.chart.util.RectangleEdge var34 = var30.getDomainAxisEdge(0);
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
    java.awt.Paint var48 = var47.getDomainCrosshairPaint();
    var42.setBackgroundPaint(var48);
    org.jfree.chart.plot.PlotRenderingInfo var51 = null;
    java.awt.geom.Point2D var52 = null;
    var42.zoomDomainAxes((-1.0d), var51, var52);
    org.jfree.chart.axis.ValueAxis var54 = null;
    org.jfree.chart.axis.ValueAxis[] var55 = new org.jfree.chart.axis.ValueAxis[] { var54};
    var42.setDomainAxes(var55);
    org.jfree.chart.axis.AxisLocation var58 = var42.getDomainAxisLocation(0);
    org.jfree.chart.plot.PlotRenderingInfo var60 = null;
    org.jfree.data.xy.XYDataset var61 = null;
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
    org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot(var61, var62, var63, var64);
    org.jfree.chart.axis.ValueAxis var66 = null;
    int var67 = var65.getDomainAxisIndex(var66);
    var65.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var70 = var65.getRangeAxisEdge();
    java.awt.Paint var71 = var65.getRangeTickBandPaint();
    var65.configureDomainAxes();
    java.awt.geom.Point2D var73 = var65.getQuadrantOrigin();
    var42.zoomDomainAxes(0.0d, var60, var73);
    var30.zoomDomainAxes(0.0d, 10.0d, var37, var73);
    var15.zoomRangeAxes(208.0d, var19, var73, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test46"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 10.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.lang.Object var6 = var5.clone();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     boolean var10 = var9.isVerticalTickLabels();
//     org.jfree.chart.axis.DateTickUnit var11 = null;
//     var9.setTickUnit(var11, true, true);
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var18 = var17.getCategoryLabelPositions();
//     java.awt.Font var19 = var17.getTickLabelFont();
//     var17.setTickLabelsVisible(false);
//     int var22 = var17.getCategoryLabelPositionOffset();
//     org.jfree.chart.util.RectangleInsets var23 = var17.getTickLabelInsets();
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     java.awt.Paint var29 = var28.getDomainCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     java.awt.geom.Point2D var32 = null;
//     var28.zoomDomainAxes(100.0d, var31, var32, false);
//     var28.setRangeCrosshairValue(1.0d, true);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.data.Range var39 = var28.getDataRange(var38);
//     java.awt.Graphics2D var40 = null;
//     java.awt.Font var42 = null;
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
//     java.awt.Paint var48 = var47.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("", var42, (org.jfree.chart.plot.Plot)var47, true);
//     org.jfree.chart.title.Title var51 = null;
//     var50.removeSubtitle(var51);
//     org.jfree.chart.plot.Plot var53 = var50.getPlot();
//     org.jfree.chart.title.TextTitle var54 = var50.getTitle();
//     var54.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.awt.geom.Rectangle2D var60 = var54.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     org.jfree.chart.plot.CrosshairState var63 = null;
//     boolean var64 = var28.render(var40, var60, (-65536), var62, var63);
//     org.jfree.chart.util.LengthAdjustmentType var65 = null;
//     org.jfree.chart.util.LengthAdjustmentType var66 = null;
//     java.awt.geom.Rectangle2D var67 = var23.createAdjustedRectangle(var60, var65, var66);
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var68, var69, var70, var71);
//     var72.setForegroundAlpha(0.0f);
//     float var75 = var72.getBackgroundImageAlpha();
//     boolean var76 = var72.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var77 = var72.getRangeAxisEdge();
//     double var78 = var9.valueToJava2D(0.0d, var60, var77);
//     org.jfree.chart.plot.ValueMarker var80 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.util.RectangleAnchor var81 = var80.getLabelAnchor();
//     java.awt.geom.Point2D var82 = org.jfree.chart.util.RectangleAnchor.coordinates(var60, var81);
//     var5.draw(var7, var60);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test47"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var3 = var2.getCategoryLabelPositions();
//     java.awt.Font var4 = var2.getTickLabelFont();
//     var2.setTickLabelsVisible(false);
//     int var7 = var2.getCategoryLabelPositionOffset();
//     java.lang.String var8 = var2.getLabelToolTip();
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var12 = var10.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var13 = var10.getLowerMargin();
//     java.lang.Object var14 = var10.clone();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var19 = var17.getTickLabelFont((java.lang.Comparable)(byte)100);
//     java.awt.Font var21 = null;
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
//     java.awt.Paint var27 = var26.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("", var21, (org.jfree.chart.plot.Plot)var26, true);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     java.awt.Paint var40 = var39.getDomainCrosshairPaint();
//     var34.setBackgroundPaint(var40);
//     var26.setDomainTickBandPaint(var40);
//     org.jfree.chart.text.TextMeasurer var44 = null;
//     org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, var40, 0.0f, var44);
//     var10.setTickLabelFont(var19);
//     var2.setLabelFont(var19);
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
//     org.jfree.data.xy.XYDataset var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var53, var54, var55, var56);
//     java.awt.Paint var58 = var57.getDomainCrosshairPaint();
//     var52.setBackgroundPaint(var58);
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     java.awt.geom.Point2D var62 = null;
//     var52.zoomDomainAxes((-1.0d), var61, var62);
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis[] var65 = new org.jfree.chart.axis.ValueAxis[] { var64};
//     var52.setDomainAxes(var65);
//     var52.configureDomainAxes();
//     var52.clearRangeMarkers(1);
//     org.jfree.data.general.DatasetGroup var70 = var52.getDatasetGroup();
//     var52.mapDatasetToDomainAxis(0, (-1));
//     var52.setDomainCrosshairLockedOnData(true);
//     org.jfree.chart.JFreeChart var77 = new org.jfree.chart.JFreeChart("PieSection: -10, 0(1)", var19, (org.jfree.chart.plot.Plot)var52, false);
//     
//     // Checks the contract:  equals-hashcode on var39 and var57
//     assertTrue("Contract failed: equals-hashcode on var39 and var57", var39.equals(var57) ? var39.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var39
//     assertTrue("Contract failed: equals-hashcode on var57 and var39", var57.equals(var39) ? var57.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test48"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.Paint var5 = var4.getDomainCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var4.zoomDomainAxes(100.0d, var7, var8, false);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var13, true);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var4.handleClick(100, (-1), var18);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test49"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var9.removeProgressListener(var12);
    var9.fireChartChanged();
    float var15 = var9.getBackgroundImageAlpha();
    java.awt.Stroke var16 = var9.getBorderStroke();
    java.lang.Object var17 = var9.getTextAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test50"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.configureDomainAxes();
    org.jfree.data.xy.XYDataset var20 = var4.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test51"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    java.awt.Paint var8 = var7.getDomainCrosshairPaint();
    boolean var9 = var7.isDomainGridlinesVisible();
    var7.setBackgroundImageAlpha(1.0f);
    java.awt.Font var13 = null;
    java.awt.Font var15 = null;
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    java.awt.Paint var21 = var20.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("", var15, (org.jfree.chart.plot.Plot)var20, true);
    org.jfree.chart.title.Title var24 = null;
    var23.removeSubtitle(var24);
    int var26 = var23.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var32 = var31.getPaint();
    var23.setBorderPaint(var32);
    org.jfree.chart.text.TextMeasurer var36 = null;
    org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, var32, 10.0f, 100, var36);
    var7.setOutlinePaint(var32);
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
    var43.setForegroundAlpha(0.0f);
    var43.mapDatasetToRangeAxis(0, 10);
    org.jfree.chart.axis.ValueAxis var49 = null;
    int var50 = var43.getRangeAxisIndex(var49);
    org.jfree.chart.axis.ValueAxis var51 = null;
    int var52 = var43.getRangeAxisIndex(var51);
    org.jfree.data.xy.XYDataset var53 = null;
    org.jfree.chart.axis.ValueAxis var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var53, var54, var55, var56);
    org.jfree.chart.axis.ValueAxis var58 = null;
    int var59 = var57.getDomainAxisIndex(var58);
    var57.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var62 = var57.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var64 = var57.getRangeAxisLocation((-1));
    var43.setRangeAxisLocation(var64, false);
    var7.setRangeAxisLocation(var64);
    java.awt.Paint var68 = var7.getDomainCrosshairPaint();
    var1.setAxisLinePaint(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test52"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    java.awt.Font var6 = null;
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    java.awt.Paint var12 = var11.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, true);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
    java.awt.Paint var25 = var24.getDomainCrosshairPaint();
    var19.setBackgroundPaint(var25);
    var11.setDomainTickBandPaint(var25);
    org.jfree.chart.text.TextMeasurer var29 = null;
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, var25, 0.0f, var29);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.text.TextBlockAnchor var34 = null;
    java.awt.Shape var38 = var30.calculateBounds(var31, 1.0f, 0.0f, var34, (-1.0f), 0.0f, 0.0d);
    org.jfree.chart.text.TextLine var39 = null;
    var30.addLine(var39);
    boolean var42 = var30.equals((java.lang.Object)100.0f);
    org.jfree.chart.text.TextLine var44 = new org.jfree.chart.text.TextLine("");
    var30.addLine(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test53"); }


    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var5 = var4.getCategoryLabelPositions();
    java.awt.Font var6 = var4.getTickLabelFont();
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    var11.setForegroundAlpha(0.0f);
    float var14 = var11.getBackgroundImageAlpha();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    org.jfree.chart.text.TextMeasurer var17 = null;
    org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var15, 100.0f, var17);
    org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("hi!", var6);
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
    java.awt.Paint var30 = var29.getDomainCrosshairPaint();
    var24.setBackgroundPaint(var30);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var24.zoomDomainAxes((-1.0d), var33, var34);
    var24.setNoDataMessage("hi!");
    org.jfree.chart.plot.SeriesRenderingOrder var38 = var24.getSeriesRenderingOrder();
    org.jfree.chart.util.RectangleEdge var39 = var24.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var43 = var41.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var44 = var41.getLowerMargin();
    var41.setCategoryLabelPositionOffset(1);
    double var47 = var41.getUpperMargin();
    java.awt.Stroke var48 = var41.getAxisLineStroke();
    var24.setRangeGridlineStroke(var48);
    java.awt.Paint var50 = var24.getDomainGridlinePaint();
    org.jfree.chart.text.TextFragment var52 = new org.jfree.chart.text.TextFragment("org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]", var6, var50, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test54"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test55"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    java.awt.Font var3 = var1.getTickLabelFont();
    var1.setTickLabelsVisible(false);
    int var6 = var1.getCategoryLabelPositionOffset();
    var1.setMaximumCategoryLabelLines(1);
    double var9 = var1.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test56"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 10.0d);
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, 100.0d);
    org.jfree.chart.block.RectangleConstraint var8 = var7.toUnconstrainedHeight();
    boolean var9 = var4.equals((java.lang.Object)var7);
    java.awt.Font var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    java.awt.Paint var18 = var17.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var12, (org.jfree.chart.plot.Plot)var17, true);
    org.jfree.chart.title.Title var21 = null;
    var20.removeSubtitle(var21);
    org.jfree.chart.plot.Plot var23 = var20.getPlot();
    org.jfree.chart.title.TextTitle var24 = var20.getTitle();
    var24.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var30 = var24.getBounds();
    var24.setToolTipText("hi!");
    org.jfree.chart.block.BlockFrame var33 = var24.getFrame();
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var36 = var35.getCategoryLabelPositions();
    java.awt.Font var37 = var35.getTickLabelFont();
    var24.setFont(var37);
    org.jfree.chart.text.TextFragment var39 = new org.jfree.chart.text.TextFragment("", var37);
    boolean var40 = var4.equals((java.lang.Object)"");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test57"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     int var12 = var9.getBackgroundImageAlignment();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
//     java.awt.Paint var18 = var17.getPaint();
//     var9.setBorderPaint(var18);
//     org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     int var27 = var25.getDomainAxisIndex(var26);
//     var25.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
//     boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
//     java.lang.String var32 = var30.toString();
//     var20.setLegendItemGraphicEdge(var30);
//     org.jfree.chart.block.BlockContainer var34 = null;
//     var20.setWrapper(var34);
//     org.jfree.chart.util.RectangleAnchor var36 = null;
//     var20.setLegendItemGraphicLocation(var36);
//     org.jfree.chart.util.RectangleEdge var38 = var20.getLegendItemGraphicEdge();
//     java.awt.Paint var39 = var20.getItemPaint();
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var43 = var41.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var44 = var41.getLowerMargin();
//     java.lang.Object var45 = var41.clone();
//     var41.setCategoryLabelPositionOffset(100);
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var52 = var50.getTickLabelFont((java.lang.Comparable)(byte)100);
//     java.awt.Font var54 = null;
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var55, var56, var57, var58);
//     java.awt.Paint var60 = var59.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("", var54, (org.jfree.chart.plot.Plot)var59, true);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var63, var64, var65, var66);
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var68, var69, var70, var71);
//     java.awt.Paint var73 = var72.getDomainCrosshairPaint();
//     var67.setBackgroundPaint(var73);
//     var59.setDomainTickBandPaint(var73);
//     org.jfree.chart.text.TextMeasurer var77 = null;
//     org.jfree.chart.text.TextBlock var78 = org.jfree.chart.text.TextUtilities.createTextBlock("", var52, var73, 0.0f, var77);
//     var41.setLabelPaint(var73);
//     var20.setItemPaint(var73);
//     
//     // Checks the contract:  equals-hashcode on var6 and var72
//     assertTrue("Contract failed: equals-hashcode on var6 and var72", var6.equals(var72) ? var6.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var6
//     assertTrue("Contract failed: equals-hashcode on var72 and var6", var72.equals(var6) ? var72.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test58"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var10.getRangeMarkers(var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    var10.setRangeAxis(var16);
    var10.setRangeCrosshairValue((-1.0d));
    float var20 = var10.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.5f);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test59"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     int var12 = var9.getBackgroundImageAlignment();
//     var9.setBackgroundImageAlpha(0.0f);
//     var9.setNotify(true);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 10.0d);
//     org.jfree.chart.block.BlockContainer var22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var21);
//     java.lang.Object var23 = var22.clone();
//     java.awt.Font var25 = null;
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
//     java.awt.Paint var31 = var30.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("", var25, (org.jfree.chart.plot.Plot)var30, true);
//     org.jfree.chart.title.Title var34 = null;
//     var33.removeSubtitle(var34);
//     org.jfree.chart.plot.Plot var36 = var33.getPlot();
//     org.jfree.chart.title.TextTitle var37 = var33.getTitle();
//     var37.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.lang.Object var43 = var37.clone();
//     java.awt.Image var47 = null;
//     org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var47, "hi!", "hi!", "hi!");
//     boolean var53 = var51.equals((java.lang.Object)'a');
//     java.util.List var54 = var51.getContributors();
//     org.jfree.chart.ui.Library[] var55 = var51.getOptionalLibraries();
//     var22.add((org.jfree.chart.block.Block)var37, (java.lang.Object)var55);
//     var9.setTitle(var37);
//     
//     // Checks the contract:  equals-hashcode on var6 and var30
//     assertTrue("Contract failed: equals-hashcode on var6 and var30", var6.equals(var30) ? var6.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var6
//     assertTrue("Contract failed: equals-hashcode on var30 and var6", var30.equals(var6) ? var30.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test60"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
    java.awt.color.ColorSpace var4 = var3.getColorSpace();
    java.awt.Image var8 = null;
    org.jfree.chart.ui.ProjectInfo var12 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var8, "hi!", "hi!", "hi!");
    boolean var14 = var12.equals((java.lang.Object)'a');
    java.util.List var15 = var12.getContributors();
    org.jfree.chart.ui.Library[] var16 = var12.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var17 = var12.getOptionalLibraries();
    boolean var18 = var3.equals((java.lang.Object)var17);
    int var19 = var3.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 255);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test61"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, 100.0d);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var9 = var6.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var10 = var9.getWidthConstraintType();
    java.lang.String var11 = var10.toString();
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 100.0d);
    org.jfree.data.Range var16 = null;
    org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 100.0d);
    boolean var20 = var18.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var15, var18);
    org.jfree.data.Range var22 = null;
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(var22, 100.0d);
    org.jfree.chart.block.RectangleConstraint var25 = var24.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var27 = var24.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var28 = var27.getWidthConstraintType();
    java.lang.String var29 = var28.toString();
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(100.0d, var3, var10, (-1.0d), var15, var28);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var32 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    java.lang.String var33 = var32.getLabelFormat();
    boolean var34 = var28.equals((java.lang.Object)var32);
    java.text.AttributedString var36 = var32.getAttributedLabel((-65536));
    java.lang.String var37 = var32.getLabelFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var11.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var29.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "hi!"+ "'", var33.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "hi!"+ "'", var37.equals("hi!"));

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test62"); }
// 
// 
//     java.awt.Font var2 = null;
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
//     java.awt.Paint var8 = var7.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", var2, (org.jfree.chart.plot.Plot)var7, true);
//     org.jfree.chart.title.Title var11 = null;
//     var10.removeSubtitle(var11);
//     org.jfree.chart.plot.Plot var13 = var10.getPlot();
//     org.jfree.chart.title.TextTitle var14 = var10.getTitle();
//     var14.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.lang.Object var20 = var14.clone();
//     org.jfree.data.Range var21 = null;
//     org.jfree.data.Range var23 = org.jfree.data.Range.expandToInclude(var21, 100.0d);
//     boolean var25 = var23.contains((-1.0d));
//     boolean var26 = var14.equals((java.lang.Object)(-1.0d));
//     java.awt.Font var27 = var14.getFont();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var29 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var32.setLabelAngle(10.0d);
//     boolean var35 = var29.equals((java.lang.Object)var32);
//     java.awt.Paint var37 = var32.getTickLabelPaint((java.lang.Comparable)10L);
//     org.jfree.chart.text.TextLine var38 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]", var27, var37);
//     org.jfree.chart.text.TextFragment var39 = var38.getLastTextFragment();
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.util.Size2D var41 = var38.calculateDimensions(var40);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test63"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var3 = var2.getCategoryLabelPositions();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var6 = var5.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var10 = var8.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var5.setTickMarkPaint(var10);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var5, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    java.awt.Paint var26 = var25.getDomainCrosshairPaint();
    var20.setBackgroundPaint(var26);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var20.zoomDomainAxes((-1.0d), var29, var30);
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.axis.ValueAxis[] var33 = new org.jfree.chart.axis.ValueAxis[] { var32};
    var20.setDomainAxes(var33);
    var20.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var37 = var20.getDomainAxisLocation((-65536));
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
    java.awt.Paint var43 = var42.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var42.zoomDomainAxes(100.0d, var45, var46, false);
    var42.setRangeCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var52 = var42.getOrientation();
    org.jfree.chart.util.RectangleEdge var53 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var37, var52);
    var15.setDomainAxisLocation(var37, false);
    org.jfree.data.category.CategoryDataset var56 = null;
    org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var60 = var58.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var61 = var58.getLowerMargin();
    var58.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var56, var58, var64, var65);
    org.jfree.chart.axis.CategoryAxis var68 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var69 = var68.isVisible();
    java.util.List var70 = var66.getCategoriesForAxis(var68);
    java.util.List var71 = var15.getCategoriesForAxis(var68);
    double var72 = var15.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var74 = null;
    var15.setRenderer(10, var74, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test64"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     java.awt.Font var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     java.awt.Paint var13 = var12.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, true);
//     org.jfree.chart.title.Title var16 = null;
//     var15.removeSubtitle(var16);
//     org.jfree.chart.plot.Plot var18 = var15.getPlot();
//     org.jfree.chart.title.TextTitle var19 = var15.getTitle();
//     var19.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.awt.geom.Rectangle2D var25 = var19.getBounds();
//     java.awt.geom.AffineTransform var26 = null;
//     java.awt.Font var28 = null;
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     java.awt.Paint var34 = var33.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("", var28, (org.jfree.chart.plot.Plot)var33, true);
//     org.jfree.chart.title.Title var37 = null;
//     var36.removeSubtitle(var37);
//     org.jfree.chart.plot.Plot var39 = var36.getPlot();
//     org.jfree.chart.title.TextTitle var40 = var36.getTitle();
//     java.awt.Image var41 = var36.getBackgroundImage();
//     java.awt.RenderingHints var42 = var36.getRenderingHints();
//     java.awt.PaintContext var43 = var3.createContext(var4, var5, var25, var26, var42);
//     
//     // Checks the contract:  equals-hashcode on var12 and var33
//     assertTrue("Contract failed: equals-hashcode on var12 and var33", var12.equals(var33) ? var12.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var12
//     assertTrue("Contract failed: equals-hashcode on var33 and var12", var33.equals(var12) ? var33.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var39
//     assertTrue("Contract failed: equals-hashcode on var18 and var39", var18.equals(var39) ? var18.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var18
//     assertTrue("Contract failed: equals-hashcode on var39 and var18", var39.equals(var18) ? var39.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test65"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    var10.configureDomainAxes();
    org.jfree.chart.axis.AxisSpace var15 = var10.getFixedDomainAxisSpace();
    var10.setForegroundAlpha(0.0f);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    var23.setForegroundAlpha(0.0f);
    float var26 = var23.getBackgroundImageAlpha();
    boolean var27 = var23.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var28 = var23.getRangeAxisEdge();
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
    java.awt.Paint var30 = var23.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var34 = var32.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var35 = var32.getLowerMargin();
    var32.setCategoryLabelPositionOffset(1);
    double var38 = var32.getUpperMargin();
    java.awt.Stroke var39 = var32.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(100.0d, var30, var39);
    java.awt.Stroke var41 = var40.getStroke();
    var10.setRangeCrosshairStroke(var41);
    org.jfree.chart.plot.DrawingSupplier var43 = var10.getDrawingSupplier();
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    org.jfree.data.xy.XYDataset var46 = null;
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var46, var47, var48, var49);
    org.jfree.data.xy.XYDataset var51 = null;
    org.jfree.chart.axis.ValueAxis var52 = null;
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var54 = null;
    org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot(var51, var52, var53, var54);
    java.awt.Paint var56 = var55.getDomainCrosshairPaint();
    var50.setBackgroundPaint(var56);
    org.jfree.chart.plot.PlotRenderingInfo var59 = null;
    java.awt.geom.Point2D var60 = null;
    var50.zoomDomainAxes((-1.0d), var59, var60);
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.axis.ValueAxis[] var63 = new org.jfree.chart.axis.ValueAxis[] { var62};
    var50.setDomainAxes(var63);
    org.jfree.chart.axis.AxisLocation var66 = var50.getDomainAxisLocation(0);
    org.jfree.chart.plot.PlotRenderingInfo var68 = null;
    org.jfree.data.xy.XYDataset var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.axis.ValueAxis var71 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var72 = null;
    org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot(var69, var70, var71, var72);
    org.jfree.chart.axis.ValueAxis var74 = null;
    int var75 = var73.getDomainAxisIndex(var74);
    var73.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var78 = var73.getRangeAxisEdge();
    java.awt.Paint var79 = var73.getRangeTickBandPaint();
    var73.configureDomainAxes();
    java.awt.geom.Point2D var81 = var73.getQuadrantOrigin();
    var50.zoomDomainAxes(108.0d, var68, var81, false);
    var10.zoomDomainAxes(9.0d, var45, var81, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test66"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]", var1, var2);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test67"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    java.awt.Paint var21 = var9.getBackgroundPaint();
    var9.setAntiAlias(true);
    java.util.List var24 = var9.getSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test68"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes(100.0d, var7, var8, false);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var13, true);
    var4.zoom((-8.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test69"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     org.jfree.chart.title.TextTitle var13 = var9.getTitle();
//     var13.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.lang.Object var19 = var13.clone();
//     org.jfree.chart.util.HorizontalAlignment var20 = var13.getTextAlignment();
//     org.jfree.chart.util.VerticalAlignment var21 = null;
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 0.0d, 10.0d);
//     java.awt.Font var26 = null;
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     java.awt.Paint var32 = var31.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("", var26, (org.jfree.chart.plot.Plot)var31, true);
//     org.jfree.chart.title.Title var35 = null;
//     var34.removeSubtitle(var35);
//     int var37 = var34.getBackgroundImageAlignment();
//     org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
//     java.awt.Paint var43 = var42.getPaint();
//     var34.setBorderPaint(var43);
//     org.jfree.chart.title.LegendTitle var45 = var34.getLegend();
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var46, var47, var48, var49);
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     int var52 = var50.getDomainAxisIndex(var51);
//     var50.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var55 = var50.getRangeAxisEdge();
//     boolean var56 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var55);
//     java.lang.String var57 = var55.toString();
//     var45.setLegendItemGraphicEdge(var55);
//     org.jfree.chart.block.BlockContainer var59 = null;
//     var45.setWrapper(var59);
//     java.lang.Object var61 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var45);
//     var45.setMargin((-1.0d), 0.0d, 100.0d, 100.0d);
//     boolean var67 = var24.equals((java.lang.Object)100.0d);
//     
//     // Checks the contract:  equals-hashcode on var6 and var31
//     assertTrue("Contract failed: equals-hashcode on var6 and var31", var6.equals(var31) ? var6.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var6
//     assertTrue("Contract failed: equals-hashcode on var31 and var6", var31.equals(var6) ? var31.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test70"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    boolean var13 = var10.isDomainZoomable();
    java.awt.Graphics2D var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    int var21 = var19.getDomainAxisIndex(var20);
    var19.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var24 = var19.getRangeAxisEdge();
    var19.setNoDataMessage("");
    java.awt.Graphics2D var27 = null;
    java.awt.Font var29 = null;
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    java.awt.Paint var35 = var34.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("", var29, (org.jfree.chart.plot.Plot)var34, true);
    org.jfree.chart.title.Title var38 = null;
    var37.removeSubtitle(var38);
    org.jfree.chart.plot.Plot var40 = var37.getPlot();
    org.jfree.chart.title.TextTitle var41 = var37.getTitle();
    var41.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var47 = var41.getBounds();
    java.util.List var48 = null;
    var19.drawRangeTickBands(var27, var47, var48);
    org.jfree.chart.plot.PlotRenderingInfo var51 = null;
    boolean var52 = var10.render(var14, var47, 100, var51);
    org.jfree.chart.JFreeChart var53 = null;
    org.jfree.chart.event.ChartProgressEvent var56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var52, var53, 253, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test71"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    org.jfree.chart.title.TextTitle var13 = var9.getTitle();
    var9.fireChartChanged();
    var9.removeLegend();
    var9.removeLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test72"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, 100.0d);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var9 = var6.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var10 = var9.getWidthConstraintType();
    java.lang.String var11 = var10.toString();
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 100.0d);
    org.jfree.data.Range var16 = null;
    org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 100.0d);
    boolean var20 = var18.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var15, var18);
    org.jfree.data.Range var22 = null;
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(var22, 100.0d);
    org.jfree.chart.block.RectangleConstraint var25 = var24.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var27 = var24.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var28 = var27.getWidthConstraintType();
    java.lang.String var29 = var28.toString();
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(100.0d, var3, var10, (-1.0d), var15, var28);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var32 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    java.lang.String var33 = var32.getLabelFormat();
    boolean var34 = var28.equals((java.lang.Object)var32);
    java.text.AttributedString var36 = var32.getAttributedLabel((-65536));
    org.jfree.data.general.PieDataset var37 = null;
    java.lang.String var39 = var32.generateSectionLabel(var37, (java.lang.Comparable)(short)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var11.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var29.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "hi!"+ "'", var33.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test73"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     org.jfree.chart.title.TextTitle var13 = var9.getTitle();
//     var13.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.lang.Object var19 = var13.clone();
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, 100.0d);
//     boolean var24 = var22.contains((-1.0d));
//     boolean var25 = var13.equals((java.lang.Object)(-1.0d));
//     var13.setText("");
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var31 = var29.getTickLabelFont((java.lang.Comparable)(byte)100);
//     var13.setFont(var31);
//     java.awt.Font var34 = null;
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     java.awt.Paint var40 = var39.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart("", var34, (org.jfree.chart.plot.Plot)var39, true);
//     org.jfree.chart.title.Title var43 = null;
//     var42.removeSubtitle(var43);
//     org.jfree.chart.plot.Plot var45 = var42.getPlot();
//     org.jfree.chart.title.TextTitle var46 = var42.getTitle();
//     var42.fireChartChanged();
//     var42.removeLegend();
//     var13.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var42);
//     
//     // Checks the contract:  equals-hashcode on var6 and var39
//     assertTrue("Contract failed: equals-hashcode on var6 and var39", var6.equals(var39) ? var6.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var6
//     assertTrue("Contract failed: equals-hashcode on var39 and var6", var39.equals(var6) ? var39.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var45
//     assertTrue("Contract failed: equals-hashcode on var12 and var45", var12.equals(var45) ? var12.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var12
//     assertTrue("Contract failed: equals-hashcode on var45 and var12", var45.equals(var12) ? var45.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test74"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    var9.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.title.TextTitle var15 = null;
    var9.setTitle(var15);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    var21.setForegroundAlpha(0.0f);
    float var24 = var21.getBackgroundImageAlpha();
    boolean var25 = var21.isOutlineVisible();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var21);
    org.jfree.chart.event.ChartChangeEvent var27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var26);
    org.jfree.chart.plot.Plot var28 = var9.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test75"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.Paint var10 = var9.getDomainCrosshairPaint();
//     var4.setBackgroundPaint(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var4.zoomDomainAxes((-1.0d), var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
//     var4.setDomainAxes(var17);
//     var4.configureDomainAxes();
//     var4.clearRangeMarkers(1);
//     org.jfree.data.general.DatasetGroup var22 = var4.getDatasetGroup();
//     var4.mapDatasetToDomainAxis(0, (-1));
//     var4.setDomainCrosshairLockedOnData(true);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     var33.setForegroundAlpha(0.0f);
//     float var36 = var33.getBackgroundImageAlpha();
//     boolean var37 = var33.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var38 = var33.getRangeAxisEdge();
//     java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var33);
//     java.awt.Paint var40 = var33.getOutlinePaint();
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var44 = var42.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var45 = var42.getLowerMargin();
//     var42.setCategoryLabelPositionOffset(1);
//     double var48 = var42.getUpperMargin();
//     java.awt.Stroke var49 = var42.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(100.0d, var40, var49);
//     java.awt.Stroke var51 = var50.getStroke();
//     org.jfree.chart.util.LengthAdjustmentType var52 = var50.getLabelOffsetType();
//     org.jfree.chart.util.Layer var53 = null;
//     var4.addRangeMarker((org.jfree.chart.plot.Marker)var50, var53);
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     boolean var57 = var56.isVerticalTickLabels();
//     org.jfree.chart.axis.CategoryAxis var59 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var61 = var59.getTickLabelPaint((java.lang.Comparable)(-1.0f));
//     var56.setTickMarkPaint(var61);
//     int var63 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var56);
//     var56.resizeRange(108.0d);
//     var56.configure();
//     org.jfree.chart.axis.DateTickUnit var67 = null;
//     java.util.Date var68 = var56.calculateHighestVisibleTickValue(var67);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test76"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.Paint var10 = var9.getDomainCrosshairPaint();
//     var4.setBackgroundPaint(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var4.zoomDomainAxes((-1.0d), var13, var14);
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     var4.setRenderer(var16);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var24 = var22.getTickLabelFont((java.lang.Comparable)(byte)100);
//     java.awt.Font var26 = null;
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     java.awt.Paint var32 = var31.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("", var26, (org.jfree.chart.plot.Plot)var31, true);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var40, var41, var42, var43);
//     java.awt.Paint var45 = var44.getDomainCrosshairPaint();
//     var39.setBackgroundPaint(var45);
//     var31.setDomainTickBandPaint(var45);
//     org.jfree.chart.text.TextMeasurer var49 = null;
//     org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, var45, 0.0f, var49);
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.text.TextBlockAnchor var54 = null;
//     java.awt.Shape var58 = var50.calculateBounds(var51, 1.0f, 0.0f, var54, (-1.0f), 0.0f, 0.0d);
//     org.jfree.chart.text.TextLine var59 = null;
//     var50.addLine(var59);
//     org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var64 = var63.getCategoryLabelPositions();
//     java.awt.Font var65 = var63.getTickLabelFont();
//     org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var68 = var67.getCategoryLabelPositions();
//     java.awt.Font var69 = var67.getTickLabelFont();
//     var67.setTickLabelsVisible(false);
//     int var72 = var67.getCategoryLabelPositionOffset();
//     java.lang.String var73 = var67.getLabelToolTip();
//     java.awt.Stroke var74 = var67.getAxisLineStroke();
//     java.awt.Paint var75 = var67.getTickLabelPaint();
//     var50.addLine("", var65, var75);
//     var4.setDomainCrosshairPaint(var75);
//     
//     // Checks the contract:  equals-hashcode on var9 and var44
//     assertTrue("Contract failed: equals-hashcode on var9 and var44", var9.equals(var44) ? var9.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var9
//     assertTrue("Contract failed: equals-hashcode on var44 and var9", var44.equals(var9) ? var44.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test77"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var4 = var1.getLowerMargin();
    var1.setCategoryLabelPositionOffset(1);
    double var7 = var1.getUpperMargin();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var10 = var9.getCategoryLabelPositions();
    var1.setCategoryLabelPositions(var10);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    java.awt.Paint var22 = var21.getDomainCrosshairPaint();
    var16.setBackgroundPaint(var22);
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    java.awt.geom.Point2D var26 = null;
    var16.zoomDomainAxes((-1.0d), var25, var26);
    var16.clearAnnotations();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var32 = var30.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var33 = var30.getLowerMargin();
    var30.setCategoryLabelPositionOffset(1);
    double var36 = var30.getUpperMargin();
    java.awt.Stroke var37 = var30.getAxisLineStroke();
    var16.setDomainZeroBaselineStroke(var37);
    var1.setAxisLineStroke(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test78"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var5 = null;
    org.jfree.chart.util.VerticalAlignment var6 = null;
    org.jfree.chart.block.FlowArrangement var9 = new org.jfree.chart.block.FlowArrangement(var5, var6, 100.0d, 10.0d);
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var9);
    boolean var11 = var10.isEmpty();
    java.awt.Graphics2D var12 = null;
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    org.jfree.data.Range var17 = null;
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, 100.0d);
    org.jfree.chart.block.RectangleConstraint var20 = var19.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var22 = var19.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    java.lang.String var24 = var23.toString();
    org.jfree.data.Range var26 = null;
    org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var26, 100.0d);
    org.jfree.data.Range var29 = null;
    org.jfree.data.Range var31 = org.jfree.data.Range.expandToInclude(var29, 100.0d);
    boolean var33 = var31.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(var28, var31);
    org.jfree.data.Range var35 = null;
    org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(var35, 100.0d);
    org.jfree.chart.block.RectangleConstraint var38 = var37.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var40 = var37.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var41 = var40.getWidthConstraintType();
    java.lang.String var42 = var41.toString();
    org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint(100.0d, var16, var23, (-1.0d), var28, var41);
    org.jfree.chart.util.Size2D var44 = var4.arrange(var10, var12, var43);
    java.lang.Object var45 = var44.clone();
    org.jfree.data.xy.XYDataset var46 = null;
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var46, var47, var48, var49);
    var50.setForegroundAlpha(0.0f);
    float var53 = var50.getBackgroundImageAlpha();
    java.awt.Paint var54 = var50.getDomainZeroBaselinePaint();
    org.jfree.data.general.DatasetChangeEvent var55 = null;
    var50.datasetChanged(var55);
    org.jfree.data.xy.XYDataset var57 = null;
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
    org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
    org.jfree.data.xy.XYDataset var62 = null;
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var65 = null;
    org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot(var62, var63, var64, var65);
    java.awt.Paint var67 = var66.getDomainCrosshairPaint();
    var61.setBackgroundPaint(var67);
    org.jfree.chart.plot.PlotRenderingInfo var70 = null;
    java.awt.geom.Point2D var71 = null;
    var61.zoomDomainAxes((-1.0d), var70, var71);
    org.jfree.chart.axis.ValueAxis var73 = null;
    org.jfree.chart.axis.ValueAxis[] var74 = new org.jfree.chart.axis.ValueAxis[] { var73};
    var61.setDomainAxes(var74);
    var61.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.RectangleEdge var79 = var61.getRangeAxisEdge(10);
    org.jfree.chart.util.RectangleInsets var80 = var61.getAxisOffset();
    java.lang.String var81 = var80.toString();
    double var83 = var80.calculateLeftOutset(10.0d);
    var50.setInsets(var80);
    boolean var85 = var44.equals((java.lang.Object)var50);
    java.awt.Stroke var86 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setRangeCrosshairStroke(var86);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var24.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var42.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var81 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"+ "'", var81.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test79"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, 100.0d);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var9 = var6.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var10 = var9.getWidthConstraintType();
    java.lang.String var11 = var10.toString();
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 100.0d);
    org.jfree.data.Range var16 = null;
    org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 100.0d);
    boolean var20 = var18.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var15, var18);
    org.jfree.data.Range var22 = null;
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(var22, 100.0d);
    org.jfree.chart.block.RectangleConstraint var25 = var24.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var27 = var24.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var28 = var27.getWidthConstraintType();
    java.lang.String var29 = var28.toString();
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(100.0d, var3, var10, (-1.0d), var15, var28);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var32 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    java.lang.String var33 = var32.getLabelFormat();
    boolean var34 = var28.equals((java.lang.Object)var32);
    java.text.AttributedString var36 = var32.getAttributedLabel((-65536));
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
    java.awt.Paint var42 = var41.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var44 = null;
    java.awt.geom.Point2D var45 = null;
    var41.zoomDomainAxes(100.0d, var44, var45, false);
    var41.setRangeCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var51 = var41.getOrientation();
    boolean var52 = var32.equals((java.lang.Object)var51);
    org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var54.setLabelAngle(10.0d);
    boolean var57 = var51.equals((java.lang.Object)var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var11.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var29.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "hi!"+ "'", var33.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test80"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    var4.mapDatasetToRangeAxis(0, 10);
    org.jfree.chart.axis.ValueAxis var10 = null;
    int var11 = var4.getRangeAxisIndex(var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    int var13 = var4.getRangeAxisIndex(var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var4.setRangeAxisLocation(var25, false);
    java.awt.Stroke var28 = var4.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test81"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     var4.setForegroundAlpha(0.0f);
//     float var7 = var4.getBackgroundImageAlpha();
//     boolean var8 = var4.isOutlineVisible();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     java.awt.image.BufferedImage var13 = var9.createBufferedImage(253, 253, var12);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test82"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getDomainCrosshairPaint();
    boolean var6 = var4.isDomainGridlinesVisible();
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var12 = var11.getPaint();
    var4.setNoDataMessagePaint(var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    var18.setNoDataMessage("");
    java.awt.Graphics2D var26 = null;
    java.awt.Font var28 = null;
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    java.awt.Paint var34 = var33.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("", var28, (org.jfree.chart.plot.Plot)var33, true);
    org.jfree.chart.title.Title var37 = null;
    var36.removeSubtitle(var37);
    org.jfree.chart.plot.Plot var39 = var36.getPlot();
    org.jfree.chart.title.TextTitle var40 = var36.getTitle();
    var40.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var46 = var40.getBounds();
    java.util.List var47 = null;
    var18.drawRangeTickBands(var26, var46, var47);
    var18.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.RectangleEdge var52 = var18.getDomainAxisEdge(1);
    org.jfree.chart.axis.AxisLocation var53 = var18.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var56 = var55.getCategoryLabelPositions();
    java.awt.Font var57 = var55.getTickLabelFont();
    var55.setTickLabelsVisible(false);
    int var60 = var55.getCategoryLabelPositionOffset();
    java.lang.String var61 = var55.getLabelToolTip();
    java.awt.Stroke var62 = var55.getAxisLineStroke();
    var18.setRangeGridlineStroke(var62);
    var4.setRangeZeroBaselineStroke(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test83"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
    java.lang.String var2 = var1.toString();
    var1.sort();
    var1.sort();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test84"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    var4.mapDatasetToRangeAxis(0, 10);
    org.jfree.chart.axis.ValueAxis var10 = null;
    int var11 = var4.getRangeAxisIndex(var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    int var13 = var4.getRangeAxisIndex(var12);
    var4.zoom(108.0d);
    org.jfree.chart.axis.ValueAxis var16 = null;
    var4.setDomainAxis(var16);
    java.awt.Stroke var18 = var4.getRangeZeroBaselineStroke();
    var4.setDomainZeroBaselineVisible(false);
    org.jfree.chart.axis.ValueAxis var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxis((-1), var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test85"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getDomainCrosshairPaint();
    java.awt.Stroke var6 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var10 = var9.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var14 = var12.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var9.setTickMarkPaint(var14);
    var4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var9);
    org.jfree.chart.axis.DateTickUnit var17 = null;
    var9.setTickUnit(var17, false, false);
    org.jfree.chart.axis.DateTickUnit var21 = var9.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test86"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    boolean var4 = var1.isInverted();
    boolean var6 = var1.isHiddenValue(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test87"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    var10.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var16 = null;
    var10.setDataset(100, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test88"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    var10.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var16 = var10.getDataset(100);
    int var17 = var10.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test89"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.Paint var10 = var9.getDomainCrosshairPaint();
//     var4.setBackgroundPaint(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var4.zoomDomainAxes((-1.0d), var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
//     var4.setDomainAxes(var17);
//     var4.configureDomainAxes();
//     var4.clearRangeMarkers(1);
//     org.jfree.data.general.DatasetGroup var22 = var4.getDatasetGroup();
//     var4.mapDatasetToDomainAxis(0, (-1));
//     var4.setDomainCrosshairLockedOnData(true);
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     int var30 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
//     java.awt.Paint var41 = var40.getDomainCrosshairPaint();
//     var35.setBackgroundPaint(var41);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     java.awt.geom.Point2D var45 = null;
//     var35.zoomDomainAxes((-1.0d), var44, var45);
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis[] var48 = new org.jfree.chart.axis.ValueAxis[] { var47};
//     var35.setDomainAxes(var48);
//     var35.configureDomainAxes();
//     var35.clearRangeMarkers(1);
//     org.jfree.data.general.DatasetGroup var53 = var35.getDatasetGroup();
//     var35.mapDatasetToDomainAxis(0, (-1));
//     var35.setDomainCrosshairLockedOnData(true);
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
//     var64.setForegroundAlpha(0.0f);
//     float var67 = var64.getBackgroundImageAlpha();
//     boolean var68 = var64.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var69 = var64.getRangeAxisEdge();
//     java.lang.Object var70 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var64);
//     java.awt.Paint var71 = var64.getOutlinePaint();
//     org.jfree.chart.axis.CategoryAxis var73 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var75 = var73.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var76 = var73.getLowerMargin();
//     var73.setCategoryLabelPositionOffset(1);
//     double var79 = var73.getUpperMargin();
//     java.awt.Stroke var80 = var73.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var81 = new org.jfree.chart.plot.ValueMarker(100.0d, var71, var80);
//     java.awt.Stroke var82 = var81.getStroke();
//     org.jfree.chart.util.LengthAdjustmentType var83 = var81.getLabelOffsetType();
//     org.jfree.chart.util.Layer var84 = null;
//     var35.addRangeMarker((org.jfree.chart.plot.Marker)var81, var84);
//     var81.setValue(0.0d);
//     boolean var88 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var81);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test90"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.util.RectangleEdge var14 = var10.getDomainAxisEdge(0);
    boolean var15 = var10.isDomainZoomable();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    java.awt.Paint var22 = var21.getDomainCrosshairPaint();
    boolean var23 = var21.isDomainGridlinesVisible();
    var21.setBackgroundImageAlpha(1.0f);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
    java.awt.Paint var36 = var35.getDomainCrosshairPaint();
    var30.setBackgroundPaint(var36);
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    java.awt.geom.Point2D var40 = null;
    var30.zoomDomainAxes((-1.0d), var39, var40);
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var42};
    var30.setDomainAxes(var43);
    org.jfree.chart.axis.AxisLocation var46 = var30.getDomainAxisLocation(0);
    var21.setDomainAxisLocation(var46, false);
    var10.setDomainAxisLocation(253, var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test91"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var4 = var1.getLowerMargin();
//     var1.setCategoryLabelPositionOffset(1);
//     double var7 = var1.getUpperMargin();
//     java.awt.Stroke var8 = var1.getAxisLineStroke();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     boolean var15 = var14.isVerticalTickLabels();
//     org.jfree.chart.axis.DateTickUnit var16 = null;
//     var14.setTickUnit(var16, true, true);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var23 = var22.getCategoryLabelPositions();
//     java.awt.Font var24 = var22.getTickLabelFont();
//     var22.setTickLabelsVisible(false);
//     int var27 = var22.getCategoryLabelPositionOffset();
//     org.jfree.chart.util.RectangleInsets var28 = var22.getTickLabelInsets();
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     java.awt.Paint var34 = var33.getDomainCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     java.awt.geom.Point2D var37 = null;
//     var33.zoomDomainAxes(100.0d, var36, var37, false);
//     var33.setRangeCrosshairValue(1.0d, true);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.data.Range var44 = var33.getDataRange(var43);
//     java.awt.Graphics2D var45 = null;
//     java.awt.Font var47 = null;
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
//     java.awt.Paint var53 = var52.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("", var47, (org.jfree.chart.plot.Plot)var52, true);
//     org.jfree.chart.title.Title var56 = null;
//     var55.removeSubtitle(var56);
//     org.jfree.chart.plot.Plot var58 = var55.getPlot();
//     org.jfree.chart.title.TextTitle var59 = var55.getTitle();
//     var59.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.awt.geom.Rectangle2D var65 = var59.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     org.jfree.chart.plot.CrosshairState var68 = null;
//     boolean var69 = var33.render(var45, var65, (-65536), var67, var68);
//     org.jfree.chart.util.LengthAdjustmentType var70 = null;
//     org.jfree.chart.util.LengthAdjustmentType var71 = null;
//     java.awt.geom.Rectangle2D var72 = var28.createAdjustedRectangle(var65, var70, var71);
//     org.jfree.data.xy.XYDataset var73 = null;
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.axis.ValueAxis var75 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var76 = null;
//     org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot(var73, var74, var75, var76);
//     var77.setForegroundAlpha(0.0f);
//     float var80 = var77.getBackgroundImageAlpha();
//     boolean var81 = var77.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var82 = var77.getRangeAxisEdge();
//     double var83 = var14.valueToJava2D(0.0d, var65, var82);
//     org.jfree.data.xy.XYDataset var84 = null;
//     org.jfree.chart.axis.ValueAxis var85 = null;
//     org.jfree.chart.axis.ValueAxis var86 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var87 = null;
//     org.jfree.chart.plot.XYPlot var88 = new org.jfree.chart.plot.XYPlot(var84, var85, var86, var87);
//     org.jfree.chart.axis.ValueAxis var89 = null;
//     int var90 = var88.getDomainAxisIndex(var89);
//     var88.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var93 = var88.getRangeAxisEdge();
//     boolean var94 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var93);
//     double var95 = var1.getCategorySeriesMiddle((java.lang.Comparable)(-1.0d), (java.lang.Comparable)(short)10, var11, 100.0d, var65, var93);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test92"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
    boolean var9 = var7.equals((java.lang.Object)'a');
    java.util.List var10 = var7.getContributors();
    org.jfree.chart.ui.Library[] var11 = var7.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var12 = var7.getOptionalLibraries();
    var7.setLicenceName("PieSection: -10, 0(1)");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test93"); }
// 
// 
//     java.awt.Font var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     java.awt.Paint var9 = var8.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("", var3, (org.jfree.chart.plot.Plot)var8, true);
//     org.jfree.chart.title.Title var12 = null;
//     var11.removeSubtitle(var12);
//     org.jfree.chart.plot.Plot var14 = var11.getPlot();
//     org.jfree.chart.title.TextTitle var15 = var11.getTitle();
//     var15.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.awt.geom.Rectangle2D var21 = var15.getBounds();
//     var15.setToolTipText("hi!");
//     org.jfree.chart.block.BlockFrame var24 = var15.getFrame();
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var27 = var26.getCategoryLabelPositions();
//     java.awt.Font var28 = var26.getTickLabelFont();
//     var15.setFont(var28);
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("", var28);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     var35.setForegroundAlpha(0.0f);
//     float var38 = var35.getBackgroundImageAlpha();
//     org.jfree.chart.plot.Plot var39 = var35.getRootPlot();
//     org.jfree.chart.axis.AxisSpace var40 = var35.getFixedRangeAxisSpace();
//     java.awt.Paint var41 = var35.getNoDataMessagePaint();
//     org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]", var28, var41);
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.text.TextBlockAnchor var46 = null;
//     var42.draw(var43, 100.0f, 10.0f, var46, (-1.0f), 0.0f, 208.0d);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test94"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    java.awt.Font var3 = var1.getTickLabelFont();
    var1.setTickLabelsVisible(false);
    int var6 = var1.getCategoryLabelPositionOffset();
    double var7 = var1.getLowerMargin();
    java.awt.Paint var9 = var1.getTickLabelPaint((java.lang.Comparable)1L);
    var1.setLabelAngle(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test95"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var8 = var6.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var9 = var6.getLowerMargin();
//     var6.setCategoryLabelPositionOffset(1);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var4, var6, var12, var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     var19.setForegroundAlpha(0.0f);
//     float var22 = var19.getBackgroundImageAlpha();
//     boolean var23 = var19.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var24 = var19.getRangeAxisEdge();
//     java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
//     java.awt.Paint var26 = var19.getOutlinePaint();
//     var14.setRangeCrosshairPaint(var26);
//     boolean var28 = var3.equals((java.lang.Object)var14);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
//     var34.setForegroundAlpha(0.0f);
//     float var37 = var34.getBackgroundImageAlpha();
//     boolean var38 = var34.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var39 = var34.getRangeAxisEdge();
//     java.lang.Object var40 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var34);
//     java.awt.Paint var41 = var34.getOutlinePaint();
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var45 = var43.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var46 = var43.getLowerMargin();
//     var43.setCategoryLabelPositionOffset(1);
//     double var49 = var43.getUpperMargin();
//     java.awt.Stroke var50 = var43.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(100.0d, var41, var50);
//     java.awt.Stroke var52 = var51.getStroke();
//     org.jfree.chart.util.LengthAdjustmentType var53 = var51.getLabelOffsetType();
//     java.awt.Font var55 = null;
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var59 = null;
//     org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var56, var57, var58, var59);
//     java.awt.Paint var61 = var60.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart("", var55, (org.jfree.chart.plot.Plot)var60, true);
//     org.jfree.chart.title.Title var64 = null;
//     var63.removeSubtitle(var64);
//     boolean var66 = var63.isNotify();
//     boolean var67 = var51.equals((java.lang.Object)var66);
//     boolean var68 = var14.removeRangeMarker((org.jfree.chart.plot.Marker)var51);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test96"); }


    java.awt.Font var3 = null;
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
    java.awt.Paint var9 = var8.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("", var3, (org.jfree.chart.plot.Plot)var8, true);
    org.jfree.chart.title.Title var12 = null;
    var11.removeSubtitle(var12);
    org.jfree.chart.plot.Plot var14 = var11.getPlot();
    org.jfree.chart.title.TextTitle var15 = var11.getTitle();
    var15.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.lang.Object var21 = var15.clone();
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 100.0d);
    boolean var26 = var24.contains((-1.0d));
    boolean var27 = var15.equals((java.lang.Object)(-1.0d));
    java.awt.Font var28 = var15.getFont();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var30 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    java.lang.Object var31 = var30.clone();
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var33.setLabelAngle(10.0d);
    boolean var36 = var30.equals((java.lang.Object)var33);
    java.awt.Paint var38 = var33.getTickLabelPaint((java.lang.Comparable)10L);
    org.jfree.chart.text.TextLine var39 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]", var28, var38);
    org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("hi!", var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test97"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 10.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.lang.Object var6 = var5.clone();
//     java.awt.Font var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     java.awt.Paint var14 = var13.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var8, (org.jfree.chart.plot.Plot)var13, true);
//     org.jfree.chart.title.Title var17 = null;
//     var16.removeSubtitle(var17);
//     org.jfree.chart.plot.Plot var19 = var16.getPlot();
//     org.jfree.chart.title.TextTitle var20 = var16.getTitle();
//     var20.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.lang.Object var26 = var20.clone();
//     java.awt.Image var30 = null;
//     org.jfree.chart.ui.ProjectInfo var34 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var30, "hi!", "hi!", "hi!");
//     boolean var36 = var34.equals((java.lang.Object)'a');
//     java.util.List var37 = var34.getContributors();
//     org.jfree.chart.ui.Library[] var38 = var34.getOptionalLibraries();
//     var5.add((org.jfree.chart.block.Block)var20, (java.lang.Object)var38);
//     java.awt.Font var41 = null;
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
//     java.awt.Paint var47 = var46.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", var41, (org.jfree.chart.plot.Plot)var46, true);
//     org.jfree.chart.title.Title var50 = null;
//     var49.removeSubtitle(var50);
//     org.jfree.chart.plot.Plot var52 = var49.getPlot();
//     org.jfree.chart.title.TextTitle var53 = var49.getTitle();
//     var53.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.lang.Object var59 = var53.clone();
//     org.jfree.chart.util.HorizontalAlignment var60 = var53.getTextAlignment();
//     org.jfree.chart.util.VerticalAlignment var61 = null;
//     org.jfree.chart.block.ColumnArrangement var64 = new org.jfree.chart.block.ColumnArrangement(var60, var61, 0.0d, 10.0d);
//     var20.setHorizontalAlignment(var60);
//     
//     // Checks the contract:  equals-hashcode on var13 and var46
//     assertTrue("Contract failed: equals-hashcode on var13 and var46", var13.equals(var46) ? var13.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var13
//     assertTrue("Contract failed: equals-hashcode on var46 and var13", var46.equals(var13) ? var46.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var49
//     assertTrue("Contract failed: equals-hashcode on var16 and var49", var16.equals(var49) ? var16.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var16
//     assertTrue("Contract failed: equals-hashcode on var49 and var16", var49.equals(var16) ? var49.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var52
//     assertTrue("Contract failed: equals-hashcode on var19 and var52", var19.equals(var52) ? var19.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var19
//     assertTrue("Contract failed: equals-hashcode on var52 and var19", var52.equals(var19) ? var52.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test98"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.axis.ValueAxis var26 = null;
    int var27 = var25.getDomainAxisIndex(var26);
    var25.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
    boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
    java.lang.String var32 = var30.toString();
    var20.setLegendItemGraphicEdge(var30);
    org.jfree.chart.util.RectangleAnchor var34 = null;
    var20.setLegendItemGraphicLocation(var34);
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var39 = var38.getCategoryLabelPositions();
    java.awt.Font var40 = var38.getTickLabelFont();
    org.jfree.data.xy.XYDataset var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
    var45.setForegroundAlpha(0.0f);
    float var48 = var45.getBackgroundImageAlpha();
    java.awt.Paint var49 = var45.getDomainZeroBaselinePaint();
    org.jfree.chart.text.TextMeasurer var51 = null;
    org.jfree.chart.text.TextBlock var52 = org.jfree.chart.text.TextUtilities.createTextBlock("", var40, var49, 100.0f, var51);
    var20.setItemFont(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "RectangleEdge.LEFT"+ "'", var32.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test99"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var13 = var12.isVisible();
    java.util.List var14 = var10.getCategoriesForAxis(var12);
    int var15 = var10.getDomainAxisCount();
    var10.clearDomainMarkers((-65536));
    org.jfree.chart.plot.CategoryMarker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addDomainMarker(0, var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test100"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    java.awt.Stroke var8 = var6.getDomainZeroBaselineStroke();
    var1.setOutlineStroke(var8);
    var1.setValue(100.0d);
    var1.setValue((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test101"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    var10.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test102"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleInsets var22 = var20.getLegendItemGraphicPadding();
    java.lang.String var23 = var20.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test103"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    var9.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.ChartRenderingInfo var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var16 = var9.createBufferedImage((-1), 10, (-65536), var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test104"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.configureDomainAxes();
    var4.clearRangeMarkers(1);
    org.jfree.data.general.DatasetGroup var22 = var4.getDatasetGroup();
    var4.mapDatasetToDomainAxis(0, (-1));
    var4.setDomainCrosshairLockedOnData(true);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    int var30 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var33 = var32.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var34 = null;
    var32.setTickUnit(var34, true, true);
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test105"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var6 = var4.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var1.setTickMarkPaint(var6);
    var1.setNegativeArrowVisible(false);
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 100.0d);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    boolean var18 = var16.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var13, var16);
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(100.0d, var16);
    var1.setRange(var16, true, false);
    var1.setAutoRangeMinimumSize(1.0d, false);
    var1.setUpperBound(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test106"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(1, var25);
    java.lang.String var27 = var10.getPlotType();
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var29);
    java.awt.Paint var31 = var10.getRangeGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Category Plot"+ "'", var27.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test107"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
    var1.distributeLabels((-1.0d), 100.0d);
    int var5 = var1.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test108"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("Range[100.0,100.0]", var1, var2, var3);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test109"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var10.getRangeMarkers(var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    var10.setRangeAxis(var16);
    boolean var18 = var10.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var20 = var10.getRangeAxisLocation((-10));
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    java.awt.Paint var26 = var25.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var25.zoomDomainAxes(100.0d, var28, var29, false);
    var25.setRangeCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var35 = var25.getOrientation();
    org.jfree.chart.util.RectangleEdge var36 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var20, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test110"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { (-1)};
    java.lang.Comparable[] var2 = null;
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test111"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    float var7 = var4.getBackgroundImageAlpha();
    boolean var8 = var4.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
    java.awt.Paint var11 = var4.getOutlinePaint();
    java.awt.Stroke var12 = var4.getRangeZeroBaselineStroke();
    var4.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test112"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    var4.setNoDataMessage("");
    java.awt.Graphics2D var12 = null;
    java.awt.Font var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    java.awt.Paint var20 = var19.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var19, true);
    org.jfree.chart.title.Title var23 = null;
    var22.removeSubtitle(var23);
    org.jfree.chart.plot.Plot var25 = var22.getPlot();
    org.jfree.chart.title.TextTitle var26 = var22.getTitle();
    var26.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var32 = var26.getBounds();
    java.util.List var33 = null;
    var4.drawRangeTickBands(var12, var32, var33);
    var4.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.RectangleEdge var38 = var4.getDomainAxisEdge(1);
    int var39 = var4.getRangeAxisCount();
    java.lang.String var40 = var4.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "XY Plot"+ "'", var40.equals("XY Plot"));

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test113"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test114"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.util.RectangleEdge var14 = var10.getDomainAxisEdge(0);
    boolean var15 = var10.isDomainZoomable();
    var10.setRangeCrosshairVisible(false);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    var23.setForegroundAlpha(0.0f);
    float var26 = var23.getBackgroundImageAlpha();
    boolean var27 = var23.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var28 = var23.getRangeAxisEdge();
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
    java.awt.Paint var30 = var23.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var34 = var32.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var35 = var32.getLowerMargin();
    var32.setCategoryLabelPositionOffset(1);
    double var38 = var32.getUpperMargin();
    java.awt.Stroke var39 = var32.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(100.0d, var30, var39);
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var40);
    var40.setLabel("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    java.awt.Font var45 = null;
    org.jfree.data.xy.XYDataset var46 = null;
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var46, var47, var48, var49);
    java.awt.Paint var51 = var50.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("", var45, (org.jfree.chart.plot.Plot)var50, true);
    org.jfree.chart.title.Title var54 = null;
    var53.removeSubtitle(var54);
    org.jfree.chart.plot.Plot var56 = var53.getPlot();
    org.jfree.chart.title.TextTitle var57 = var53.getTitle();
    var57.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.lang.Object var63 = var57.clone();
    org.jfree.data.Range var64 = null;
    org.jfree.data.Range var66 = org.jfree.data.Range.expandToInclude(var64, 100.0d);
    boolean var68 = var66.contains((-1.0d));
    boolean var69 = var57.equals((java.lang.Object)(-1.0d));
    java.awt.Font var70 = var57.getFont();
    var40.setLabelFont(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test115"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.RectangleEdge var22 = var4.getRangeAxisEdge(10);
    org.jfree.chart.util.RectangleInsets var23 = var4.getAxisOffset();
    java.lang.String var24 = var23.toString();
    double var26 = var23.calculateLeftInset((-1.0d));
    double var28 = var23.calculateRightOutset((-1.0d));
    double var30 = var23.calculateTopInset((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"+ "'", var24.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 4.0d);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test116"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     org.jfree.chart.title.TextTitle var13 = var9.getTitle();
//     org.jfree.chart.title.LegendTitle var14 = var9.getLegend();
//     java.lang.Object var15 = var9.getTextAntiAlias();
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     var9.handleClick((-65536), 100, var18);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test117"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 10.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    java.lang.Object var6 = var5.clone();
    java.awt.Font var8 = null;
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    java.awt.Paint var14 = var13.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var8, (org.jfree.chart.plot.Plot)var13, true);
    org.jfree.chart.title.Title var17 = null;
    var16.removeSubtitle(var17);
    org.jfree.chart.plot.Plot var19 = var16.getPlot();
    org.jfree.chart.title.TextTitle var20 = var16.getTitle();
    var20.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.lang.Object var26 = var20.clone();
    java.awt.Image var30 = null;
    org.jfree.chart.ui.ProjectInfo var34 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var30, "hi!", "hi!", "hi!");
    boolean var36 = var34.equals((java.lang.Object)'a');
    java.util.List var37 = var34.getContributors();
    org.jfree.chart.ui.Library[] var38 = var34.getOptionalLibraries();
    var5.add((org.jfree.chart.block.Block)var20, (java.lang.Object)var38);
    org.jfree.chart.block.Arrangement var40 = var5.getArrangement();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test118"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     org.jfree.chart.event.ChartProgressListener var12 = null;
//     var9.removeProgressListener(var12);
//     var9.clearSubtitles();
//     org.jfree.chart.title.TextTitle var15 = var9.getTitle();
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.FlowArrangement var20 = new org.jfree.chart.block.FlowArrangement(var16, var17, 100.0d, 10.0d);
//     org.jfree.chart.block.BlockContainer var21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var20);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     java.awt.Paint var33 = var32.getDomainCrosshairPaint();
//     var27.setBackgroundPaint(var33);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     java.awt.geom.Point2D var37 = null;
//     var27.zoomDomainAxes((-1.0d), var36, var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis[] var40 = new org.jfree.chart.axis.ValueAxis[] { var39};
//     var27.setDomainAxes(var40);
//     var27.setRangeCrosshairValue(100.0d);
//     org.jfree.chart.util.RectangleEdge var45 = var27.getRangeAxisEdge(10);
//     org.jfree.chart.util.RectangleInsets var46 = var27.getAxisOffset();
//     java.lang.String var47 = var46.toString();
//     double var49 = var46.calculateLeftOutset(10.0d);
//     double var51 = var46.extendWidth(100.0d);
//     double var53 = var46.calculateLeftOutset(0.0d);
//     var21.setPadding(var46);
//     java.lang.String var55 = var46.toString();
//     double var57 = var46.calculateRightOutset(9.0d);
//     var9.setPadding(var46);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test119"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    java.awt.Font var3 = var1.getTickLabelFont();
    var1.setTickLabelsVisible(false);
    int var6 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.util.RectangleInsets var7 = var1.getTickLabelInsets();
    double var9 = var7.calculateTopOutset((-8.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test120"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var1.setTickUnit(var3, true, true);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var10 = var9.getCategoryLabelPositions();
    java.awt.Font var11 = var9.getTickLabelFont();
    var9.setTickLabelsVisible(false);
    int var14 = var9.getCategoryLabelPositionOffset();
    org.jfree.chart.util.RectangleInsets var15 = var9.getTickLabelInsets();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    java.awt.Paint var21 = var20.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    java.awt.geom.Point2D var24 = null;
    var20.zoomDomainAxes(100.0d, var23, var24, false);
    var20.setRangeCrosshairValue(1.0d, true);
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.data.Range var31 = var20.getDataRange(var30);
    java.awt.Graphics2D var32 = null;
    java.awt.Font var34 = null;
    org.jfree.data.xy.XYDataset var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
    java.awt.Paint var40 = var39.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart("", var34, (org.jfree.chart.plot.Plot)var39, true);
    org.jfree.chart.title.Title var43 = null;
    var42.removeSubtitle(var43);
    org.jfree.chart.plot.Plot var45 = var42.getPlot();
    org.jfree.chart.title.TextTitle var46 = var42.getTitle();
    var46.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var52 = var46.getBounds();
    org.jfree.chart.plot.PlotRenderingInfo var54 = null;
    org.jfree.chart.plot.CrosshairState var55 = null;
    boolean var56 = var20.render(var32, var52, (-65536), var54, var55);
    org.jfree.chart.util.LengthAdjustmentType var57 = null;
    org.jfree.chart.util.LengthAdjustmentType var58 = null;
    java.awt.geom.Rectangle2D var59 = var15.createAdjustedRectangle(var52, var57, var58);
    org.jfree.data.xy.XYDataset var60 = null;
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
    org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
    var64.setForegroundAlpha(0.0f);
    float var67 = var64.getBackgroundImageAlpha();
    boolean var68 = var64.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var69 = var64.getRangeAxisEdge();
    double var70 = var1.valueToJava2D(0.0d, var52, var69);
    double var71 = var1.getFixedAutoRange();
    var1.setLabelAngle(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test121"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 10.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    java.lang.Object var6 = var5.clone();
    java.awt.Font var8 = null;
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    java.awt.Paint var14 = var13.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var8, (org.jfree.chart.plot.Plot)var13, true);
    org.jfree.chart.title.Title var17 = null;
    var16.removeSubtitle(var17);
    org.jfree.chart.plot.Plot var19 = var16.getPlot();
    org.jfree.chart.title.TextTitle var20 = var16.getTitle();
    var20.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.lang.Object var26 = var20.clone();
    java.awt.Image var30 = null;
    org.jfree.chart.ui.ProjectInfo var34 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var30, "hi!", "hi!", "hi!");
    boolean var36 = var34.equals((java.lang.Object)'a');
    java.util.List var37 = var34.getContributors();
    org.jfree.chart.ui.Library[] var38 = var34.getOptionalLibraries();
    var5.add((org.jfree.chart.block.Block)var20, (java.lang.Object)var38);
    var20.setText("PieSection: -10, 0(1)");
    var20.setExpandToFitSpace(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test122"); }


    float[] var12 = new float[] { 0.0f, 100.0f, 0.0f};
    float[] var13 = java.awt.Color.RGBtoHSB(10, (-1), 0, var12);
    float[] var14 = java.awt.Color.RGBtoHSB(1, (-10), (-1), var13);
    float[] var15 = java.awt.Color.RGBtoHSB(1, 10, 1, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test123"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     int var12 = var9.getBackgroundImageAlignment();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
//     java.awt.Paint var18 = var17.getPaint();
//     var9.setBorderPaint(var18);
//     org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     int var27 = var25.getDomainAxisIndex(var26);
//     var25.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
//     boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
//     java.lang.String var32 = var30.toString();
//     var20.setLegendItemGraphicEdge(var30);
//     org.jfree.chart.block.BlockContainer var34 = null;
//     var20.setWrapper(var34);
//     org.jfree.chart.util.RectangleAnchor var36 = null;
//     var20.setLegendItemGraphicLocation(var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
//     java.awt.Paint var48 = var47.getDomainCrosshairPaint();
//     var42.setBackgroundPaint(var48);
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     java.awt.geom.Point2D var52 = null;
//     var42.zoomDomainAxes((-1.0d), var51, var52);
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.axis.ValueAxis[] var55 = new org.jfree.chart.axis.ValueAxis[] { var54};
//     var42.setDomainAxes(var55);
//     var42.setRangeCrosshairValue(100.0d);
//     org.jfree.chart.util.RectangleEdge var60 = var42.getRangeAxisEdge(10);
//     org.jfree.chart.util.RectangleInsets var61 = var42.getAxisOffset();
//     java.lang.String var62 = var61.toString();
//     double var64 = var61.calculateLeftOutset(10.0d);
//     var20.setMargin(var61);
//     
//     // Checks the contract:  equals-hashcode on var6 and var47
//     assertTrue("Contract failed: equals-hashcode on var6 and var47", var6.equals(var47) ? var6.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var6
//     assertTrue("Contract failed: equals-hashcode on var47 and var6", var47.equals(var6) ? var47.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test124"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleInsets var22 = var20.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleEdge var23 = var20.getPosition();
    java.lang.String var24 = var23.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "RectangleEdge.BOTTOM"+ "'", var24.equals("RectangleEdge.BOTTOM"));

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test125"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.configureDomainAxes();
    var4.clearRangeMarkers(1);
    org.jfree.data.general.DatasetGroup var22 = var4.getDatasetGroup();
    var4.mapDatasetToDomainAxis(0, (-1));
    var4.setDomainCrosshairLockedOnData(true);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    var33.setForegroundAlpha(0.0f);
    float var36 = var33.getBackgroundImageAlpha();
    boolean var37 = var33.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var38 = var33.getRangeAxisEdge();
    java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var33);
    java.awt.Paint var40 = var33.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var44 = var42.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var45 = var42.getLowerMargin();
    var42.setCategoryLabelPositionOffset(1);
    double var48 = var42.getUpperMargin();
    java.awt.Stroke var49 = var42.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(100.0d, var40, var49);
    java.awt.Stroke var51 = var50.getStroke();
    org.jfree.chart.util.LengthAdjustmentType var52 = var50.getLabelOffsetType();
    org.jfree.chart.util.Layer var53 = null;
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var50, var53);
    org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var57 = var56.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var59 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var61 = var59.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var56.setTickMarkPaint(var61);
    int var63 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var56);
    org.jfree.data.Range var64 = null;
    org.jfree.data.Range var66 = org.jfree.data.Range.expandToInclude(var64, 100.0d);
    org.jfree.data.Range var67 = null;
    org.jfree.data.Range var69 = org.jfree.data.Range.expandToInclude(var67, 100.0d);
    boolean var71 = var69.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var72 = new org.jfree.chart.block.RectangleConstraint(var66, var69);
    boolean var74 = var66.contains(10.0d);
    org.jfree.data.Range var77 = org.jfree.data.Range.expand(var66, 1.0d, 1.0d);
    double var78 = var77.getUpperBound();
    var56.setRange(var77);
    boolean var80 = var56.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test126"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     java.text.NumberFormat var2 = var1.getNumberFormatOverride();
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.Font var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
//     java.awt.Paint var12 = var11.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, true);
//     org.jfree.chart.title.Title var15 = null;
//     var14.removeSubtitle(var15);
//     int var17 = var14.getBackgroundImageAlignment();
//     org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
//     java.awt.Paint var23 = var22.getPaint();
//     var14.setBorderPaint(var23);
//     org.jfree.chart.title.LegendTitle var25 = var14.getLegend();
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     int var32 = var30.getDomainAxisIndex(var31);
//     var30.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var35 = var30.getRangeAxisEdge();
//     boolean var36 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var35);
//     java.lang.String var37 = var35.toString();
//     var25.setLegendItemGraphicEdge(var35);
//     org.jfree.chart.util.RectangleEdge var39 = org.jfree.chart.util.RectangleEdge.opposite(var35);
//     double var40 = var1.valueToJava2D(208.0d, var4, var35);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test127"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
    var7.addOptionalLibrary("");
    var7.setLicenceText("");
    org.jfree.chart.ui.Library[] var12 = var7.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test128"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.Paint var5 = var4.getDomainCrosshairPaint();
//     java.awt.Stroke var6 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     boolean var10 = var9.isVerticalTickLabels();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Paint var14 = var12.getTickLabelPaint((java.lang.Comparable)(-1.0f));
//     var9.setTickMarkPaint(var14);
//     var4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.chart.axis.DateTickUnit var17 = null;
//     var9.setTickUnit(var17, false, false);
//     var9.setUpperBound((-8.0d));
//     org.jfree.data.Range var23 = var9.getDefaultAutoRange();
//     org.jfree.chart.axis.DateTickUnit var24 = null;
//     java.util.Date var25 = var9.calculateLowestVisibleTickValue(var24);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test129"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.RectangleEdge var22 = var4.getRangeAxisEdge(10);
    org.jfree.chart.util.RectangleInsets var23 = var4.getAxisOffset();
    java.lang.String var24 = var23.toString();
    double var26 = var23.calculateLeftOutset(10.0d);
    double var28 = var23.extendWidth(100.0d);
    double var30 = var23.calculateBottomOutset(100.0d);
    java.awt.Color var34 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
    int var35 = var34.getRed();
    int var36 = var34.getAlpha();
    float[] var46 = new float[] { 0.0f, 100.0f, 0.0f};
    float[] var47 = java.awt.Color.RGBtoHSB(10, (-1), 0, var46);
    float[] var48 = java.awt.Color.RGBtoHSB(1, (-10), (-1), var47);
    float[] var49 = var34.getRGBColorComponents(var47);
    boolean var50 = var23.equals((java.lang.Object)var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"+ "'", var24.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 108.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test130"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    float var7 = var4.getBackgroundImageAlpha();
    org.jfree.chart.plot.Plot var8 = var4.getRootPlot();
    org.jfree.chart.axis.AxisSpace var9 = var4.getFixedRangeAxisSpace();
    java.awt.Paint var10 = var4.getNoDataMessagePaint();
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    java.awt.Paint var22 = var21.getDomainCrosshairPaint();
    var16.setBackgroundPaint(var22);
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    java.awt.geom.Point2D var26 = null;
    var16.zoomDomainAxes((-1.0d), var25, var26);
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis[] var29 = new org.jfree.chart.axis.ValueAxis[] { var28};
    var16.setDomainAxes(var29);
    org.jfree.chart.axis.AxisLocation var32 = var16.getDomainAxisLocation(0);
    var4.setDomainAxisLocation(1, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = var4.getRenderer((-65536));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test131"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
    var7.addOptionalLibrary("");
    var7.setLicenceText("");
    java.lang.String var12 = var7.toString();
    java.lang.String var13 = var7.getVersion();
    var7.setInfo(" version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var12.equals(" version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "hi!"+ "'", var13.equals("hi!"));

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test132"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var22 = var20.getLegendItemGraphicEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test133"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 9.0d, 0.0d, (-10), (java.lang.Comparable)(-65536));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test134"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("PieSection: -10, 0(1)");
    boolean var2 = var1.getAutoRangeIncludesZero();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    java.awt.Paint var13 = var12.getDomainCrosshairPaint();
    var7.setBackgroundPaint(var13);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var7.zoomDomainAxes((-1.0d), var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var19};
    var7.setDomainAxes(var20);
    var7.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.RectangleEdge var25 = var7.getRangeAxisEdge(10);
    org.jfree.chart.util.RectangleInsets var26 = var7.getAxisOffset();
    java.lang.String var27 = var26.toString();
    double var29 = var26.extendWidth(0.0d);
    double var31 = var26.calculateTopOutset(0.0d);
    boolean var32 = var1.equals((java.lang.Object)var26);
    var1.setUpperBound(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"+ "'", var27.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test135"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 108.0d);
    org.jfree.chart.util.HorizontalAlignment var5 = null;
    org.jfree.chart.util.VerticalAlignment var6 = null;
    org.jfree.chart.block.FlowArrangement var9 = new org.jfree.chart.block.FlowArrangement(var5, var6, 100.0d, 10.0d);
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var9);
    boolean var11 = var10.isEmpty();
    java.lang.Object var12 = null;
    boolean var13 = var10.equals(var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 100.0d);
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 100.0d);
    boolean var22 = var20.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(var17, var20);
    org.jfree.chart.util.Size2D var24 = var4.arrange(var10, var14, var23);
    var24.setHeight((-8.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test136"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    var9.setBackgroundImageAlpha(0.0f);
    var9.setNotify(true);
    java.awt.image.BufferedImage var19 = var9.createBufferedImage(10, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test137"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var9.removeProgressListener(var12);
    var9.fireChartChanged();
    float var15 = var9.getBackgroundImageAlpha();
    java.awt.Stroke var16 = var9.getBorderStroke();
    var9.setBackgroundImageAlignment((-65536));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test138"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(1, var25);
    org.jfree.chart.util.Layer var28 = null;
    java.util.Collection var29 = var10.getRangeMarkers(0, var28);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    var34.setForegroundAlpha(0.0f);
    var34.mapDatasetToRangeAxis(0, 10);
    org.jfree.chart.axis.ValueAxis var40 = null;
    int var41 = var34.getRangeAxisIndex(var40);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
    java.awt.Paint var52 = var51.getDomainCrosshairPaint();
    var46.setBackgroundPaint(var52);
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    java.awt.geom.Point2D var56 = null;
    var46.zoomDomainAxes((-1.0d), var55, var56);
    var46.setNoDataMessage("hi!");
    var46.zoom(10.0d);
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.axis.ValueAxis[] var63 = new org.jfree.chart.axis.ValueAxis[] { var62};
    var46.setDomainAxes(var63);
    var34.setDomainAxes(var63);
    var10.setRangeAxes(var63);
    org.jfree.chart.util.Layer var67 = null;
    java.util.Collection var68 = var10.getDomainMarkers(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test139"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var10 = var4.getDomainAxisLocation();
    var4.mapDatasetToDomainAxis(0, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test140"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    float var7 = var4.getBackgroundImageAlpha();
    org.jfree.chart.plot.Plot var8 = var4.getRootPlot();
    var4.setDomainCrosshairLockedOnData(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test141"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.util.RectangleEdge var14 = var10.getDomainAxisEdge(0);
    boolean var15 = var10.isDomainZoomable();
    var10.setRangeCrosshairVisible(false);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    java.awt.Paint var23 = var22.getDomainCrosshairPaint();
    java.awt.Stroke var24 = var22.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.DatasetRenderingOrder var25 = var22.getDatasetRenderingOrder();
    var10.setDatasetRenderingOrder(var25);
    org.jfree.chart.axis.CategoryAxis var27 = var10.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test142"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     var4.setForegroundAlpha(0.0f);
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     boolean var9 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var8);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test143"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(1, var25);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
    java.awt.Paint var37 = var36.getDomainCrosshairPaint();
    var31.setBackgroundPaint(var37);
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    java.awt.geom.Point2D var41 = null;
    var31.zoomDomainAxes((-1.0d), var40, var41);
    var31.setNoDataMessage("hi!");
    var31.zoom(10.0d);
    org.jfree.chart.plot.DrawingSupplier var47 = null;
    var31.setDrawingSupplier(var47);
    var31.setDomainZeroBaselineVisible(true);
    java.awt.Paint var51 = var31.getDomainGridlinePaint();
    java.awt.Paint var52 = var31.getBackgroundPaint();
    var10.setRangeCrosshairPaint(var52);
    org.jfree.chart.plot.CategoryMarker var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addDomainMarker(var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test144"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     int var12 = var9.getBackgroundImageAlignment();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
//     java.awt.Paint var18 = var17.getPaint();
//     var9.setBorderPaint(var18);
//     org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     var25.setForegroundAlpha(0.0f);
//     float var28 = var25.getBackgroundImageAlpha();
//     boolean var29 = var25.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
//     var20.setPosition(var30);
//     org.jfree.chart.util.RectangleEdge var32 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.FlowArrangement var37 = new org.jfree.chart.block.FlowArrangement(var33, var34, 100.0d, 10.0d);
//     org.jfree.chart.block.BlockContainer var38 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var37);
//     java.lang.Object var39 = var38.clone();
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var40, var41, var42, var43);
//     org.jfree.data.xy.XYDataset var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var45, var46, var47, var48);
//     java.awt.Paint var50 = var49.getDomainCrosshairPaint();
//     var44.setBackgroundPaint(var50);
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     java.awt.geom.Point2D var54 = null;
//     var44.zoomDomainAxes((-1.0d), var53, var54);
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis[] var57 = new org.jfree.chart.axis.ValueAxis[] { var56};
//     var44.setDomainAxes(var57);
//     var44.setRangeCrosshairValue(100.0d);
//     org.jfree.chart.util.RectangleEdge var62 = var44.getRangeAxisEdge(10);
//     org.jfree.chart.util.RectangleInsets var63 = var44.getAxisOffset();
//     java.lang.String var64 = var63.toString();
//     double var66 = var63.calculateLeftOutset(10.0d);
//     double var68 = var63.extendWidth(100.0d);
//     double var70 = var63.calculateLeftOutset(0.0d);
//     var38.setPadding(var63);
//     java.lang.String var72 = var63.toString();
//     var20.setItemLabelPadding(var63);
//     
//     // Checks the contract:  equals-hashcode on var6 and var49
//     assertTrue("Contract failed: equals-hashcode on var6 and var49", var6.equals(var49) ? var6.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var6
//     assertTrue("Contract failed: equals-hashcode on var49 and var6", var49.equals(var6) ? var49.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test145"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(byte)100);
//     var1.setLabelURL("");
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     java.awt.Paint var19 = var18.getDomainCrosshairPaint();
//     var13.setBackgroundPaint(var19);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var13.zoomDomainAxes((-1.0d), var22, var23);
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis[] var26 = new org.jfree.chart.axis.ValueAxis[] { var25};
//     var13.setDomainAxes(var26);
//     var13.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var30 = var13.getDomainAxisLocation((-65536));
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     java.awt.Paint var36 = var35.getDomainCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     java.awt.geom.Point2D var39 = null;
//     var35.zoomDomainAxes(100.0d, var38, var39, false);
//     var35.setRangeCrosshairValue(1.0d, true);
//     org.jfree.chart.plot.PlotOrientation var45 = var35.getOrientation();
//     org.jfree.chart.util.RectangleEdge var46 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var30, var45);
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
//     var51.setForegroundAlpha(0.0f);
//     float var54 = var51.getBackgroundImageAlpha();
//     boolean var55 = var51.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var56 = var51.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotOrientation var57 = var51.getOrientation();
//     org.jfree.chart.util.RectangleEdge var58 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var30, var57);
//     double var59 = var1.getCategoryMiddle(10, (-65536), var8, var58);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test146"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    java.awt.Font var3 = var1.getTickLabelFont();
    var1.setLabelAngle(9.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test147"); }
// 
// 
//     java.awt.Image var3 = null;
//     org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
//     var7.addOptionalLibrary("");
//     var7.setLicenceText("");
//     java.lang.String var12 = var7.toString();
//     java.awt.Image var13 = var7.getLogo();
//     org.jfree.chart.ui.Library var14 = null;
//     var7.addLibrary(var14);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test148"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var9.removeProgressListener(var12);
    var9.clearSubtitles();
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var18 = var16.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var19 = var16.getLowerMargin();
    java.lang.Object var20 = var16.clone();
    var16.setMaximumCategoryLabelWidthRatio(0.0f);
    boolean var23 = var9.equals((java.lang.Object)var16);
    java.lang.String var24 = var16.getLabelToolTip();
    var16.setLabel("");
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var30 = var29.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var34 = var32.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var29.setTickMarkPaint(var34);
    var16.setTickLabelPaint((java.lang.Comparable)(short)100, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test149"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    org.jfree.chart.title.TextTitle var13 = var9.getTitle();
    var13.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var19 = var13.getBounds();
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
    org.jfree.chart.axis.ValueAxis var25 = null;
    int var26 = var24.getDomainAxisIndex(var25);
    var24.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var29 = var24.getRangeAxisEdge();
    double var30 = org.jfree.chart.util.RectangleEdge.coordinate(var19, var29);
    org.jfree.data.general.PieDataset var31 = null;
    org.jfree.chart.entity.PieSectionEntity var37 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var19, var31, (-10), (-1), (java.lang.Comparable)1, " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]");
    var37.setSectionIndex(0);
    java.lang.String var40 = var37.toString();
    int var41 = var37.getSectionIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "PieSection: -10, 0(1)"+ "'", var40.equals("PieSection: -10, 0(1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test150"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    var15.setForegroundAlpha(0.0f);
    float var18 = var15.getBackgroundImageAlpha();
    boolean var19 = var15.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var20 = var15.getRangeAxisEdge();
    org.jfree.chart.plot.PlotOrientation var21 = var15.getOrientation();
    var4.setOrientation(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test151"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.Paint var11 = var10.getDomainCrosshairPaint();
    var5.setBackgroundPaint(var11);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    var5.zoomDomainAxes((-1.0d), var14, var15);
    var5.setNoDataMessage("hi!");
    var5.zoom(10.0d);
    org.jfree.chart.plot.DrawingSupplier var21 = null;
    var5.setDrawingSupplier(var21);
    var5.setDomainZeroBaselineVisible(true);
    org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.Layer var28 = null;
    var5.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var27, var28);
    java.awt.Font var30 = var27.getLabelFont();
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle(" version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test152"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.util.RectangleEdge var14 = var10.getDomainAxisEdge(0);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    java.awt.Paint var28 = var27.getDomainCrosshairPaint();
    var22.setBackgroundPaint(var28);
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    java.awt.geom.Point2D var32 = null;
    var22.zoomDomainAxes((-1.0d), var31, var32);
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.axis.ValueAxis[] var35 = new org.jfree.chart.axis.ValueAxis[] { var34};
    var22.setDomainAxes(var35);
    org.jfree.chart.axis.AxisLocation var38 = var22.getDomainAxisLocation(0);
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    org.jfree.data.xy.XYDataset var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
    org.jfree.chart.axis.ValueAxis var46 = null;
    int var47 = var45.getDomainAxisIndex(var46);
    var45.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var50 = var45.getRangeAxisEdge();
    java.awt.Paint var51 = var45.getRangeTickBandPaint();
    var45.configureDomainAxes();
    java.awt.geom.Point2D var53 = var45.getQuadrantOrigin();
    var22.zoomDomainAxes(0.0d, var40, var53);
    var10.zoomDomainAxes(0.0d, 10.0d, var17, var53);
    org.jfree.chart.axis.CategoryAnchor var56 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setDomainGridlinePosition(var56);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test153"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.Paint var11 = var10.getDomainCrosshairPaint();
    var5.setBackgroundPaint(var11);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    var5.zoomDomainAxes((-1.0d), var14, var15);
    var5.setNoDataMessage("hi!");
    org.jfree.chart.plot.SeriesRenderingOrder var19 = var5.getSeriesRenderingOrder();
    org.jfree.chart.util.RectangleEdge var20 = var5.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var24 = var22.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var25 = var22.getLowerMargin();
    var22.setCategoryLabelPositionOffset(1);
    double var28 = var22.getUpperMargin();
    java.awt.Stroke var29 = var22.getAxisLineStroke();
    var5.setRangeGridlineStroke(var29);
    java.awt.Paint var31 = var5.getDomainGridlinePaint();
    var5.setBackgroundImageAlignment((-1));
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart(" version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", (org.jfree.chart.plot.Plot)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test154"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 108.0d);
    java.awt.Font var6 = null;
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    java.awt.Paint var12 = var11.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, true);
    org.jfree.chart.title.Title var15 = null;
    var14.removeSubtitle(var15);
    int var17 = var14.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var23 = var22.getPaint();
    var14.setBorderPaint(var23);
    org.jfree.chart.title.LegendTitle var25 = var14.getLegend();
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.ValueAxis var31 = null;
    int var32 = var30.getDomainAxisIndex(var31);
    var30.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var35 = var30.getRangeAxisEdge();
    boolean var36 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var35);
    java.lang.String var37 = var35.toString();
    var25.setLegendItemGraphicEdge(var35);
    org.jfree.chart.util.RectangleAnchor var39 = null;
    var25.setLegendItemGraphicLocation(var39);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
    var46.setForegroundAlpha(0.0f);
    float var49 = var46.getBackgroundImageAlpha();
    boolean var50 = var46.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var51 = var46.getRangeAxisEdge();
    java.lang.Object var52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var46);
    java.awt.Paint var53 = var46.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var57 = var55.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var58 = var55.getLowerMargin();
    var55.setCategoryLabelPositionOffset(1);
    double var61 = var55.getUpperMargin();
    java.awt.Stroke var62 = var55.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(100.0d, var53, var62);
    java.lang.String var64 = var63.getLabel();
    org.jfree.chart.util.RectangleAnchor var65 = var63.getLabelAnchor();
    var4.add((org.jfree.chart.block.Block)var25, (java.lang.Object)var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "RectangleEdge.LEFT"+ "'", var37.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test155"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    var4.setNoDataMessage("hi!");
    var4.zoom(10.0d);
    org.jfree.chart.plot.DrawingSupplier var20 = null;
    var4.setDrawingSupplier(var20);
    var4.setDomainZeroBaselineVisible(true);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var4.setFixedRangeAxisSpace(var24, true);
    java.awt.Stroke var27 = var4.getRangeZeroBaselineStroke();
    org.jfree.data.xy.XYDataset var29 = null;
    var4.setDataset(10, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test156"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    var25.setForegroundAlpha(0.0f);
    float var28 = var25.getBackgroundImageAlpha();
    boolean var29 = var25.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
    var20.setPosition(var30);
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var35 = var33.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var36 = var33.getLowerMargin();
    java.lang.Object var37 = var33.clone();
    var33.setMaximumCategoryLabelWidthRatio(0.0f);
    java.awt.Paint var40 = var33.getAxisLinePaint();
    boolean var41 = var30.equals((java.lang.Object)var33);
    var33.setTickMarksVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test157"); }


    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 100.0d);
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, 100.0d);
    org.jfree.chart.block.RectangleConstraint var8 = var7.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var10 = var7.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var11 = var10.getWidthConstraintType();
    java.lang.String var12 = var11.toString();
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 100.0d);
    boolean var21 = var19.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(var16, var19);
    org.jfree.data.Range var23 = null;
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var23, 100.0d);
    org.jfree.chart.block.RectangleConstraint var26 = var25.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var28 = var25.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var29 = var28.getWidthConstraintType();
    java.lang.String var30 = var29.toString();
    org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(100.0d, var4, var11, (-1.0d), var16, var29);
    java.lang.String var32 = var4.toString();
    org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(1.0d, var4);
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var36 = var35.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var40 = var38.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var35.setTickMarkPaint(var40);
    var35.setNegativeArrowVisible(false);
    double var44 = var35.getLowerBound();
    org.jfree.data.Range var45 = null;
    org.jfree.data.Range var47 = org.jfree.data.Range.expandToInclude(var45, 100.0d);
    var35.setRange(var47);
    org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(var4, var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var12.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var30.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "Range[100.0,100.0]"+ "'", var32.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test158"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.configureDomainAxes();
    var4.clearRangeMarkers(1);
    org.jfree.data.general.DatasetGroup var22 = var4.getDatasetGroup();
    var4.mapDatasetToDomainAxis(0, (-1));
    var4.setDomainCrosshairLockedOnData(true);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    var33.setForegroundAlpha(0.0f);
    float var36 = var33.getBackgroundImageAlpha();
    boolean var37 = var33.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var38 = var33.getRangeAxisEdge();
    java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var33);
    java.awt.Paint var40 = var33.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var44 = var42.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var45 = var42.getLowerMargin();
    var42.setCategoryLabelPositionOffset(1);
    double var48 = var42.getUpperMargin();
    java.awt.Stroke var49 = var42.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(100.0d, var40, var49);
    java.awt.Stroke var51 = var50.getStroke();
    org.jfree.chart.util.LengthAdjustmentType var52 = var50.getLabelOffsetType();
    org.jfree.chart.util.Layer var53 = null;
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var50, var53);
    org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var57 = var56.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var59 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var61 = var59.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var56.setTickMarkPaint(var61);
    int var63 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var56);
    org.jfree.data.Range var64 = null;
    org.jfree.data.Range var66 = org.jfree.data.Range.expandToInclude(var64, 100.0d);
    org.jfree.data.Range var67 = null;
    org.jfree.data.Range var69 = org.jfree.data.Range.expandToInclude(var67, 100.0d);
    boolean var71 = var69.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var72 = new org.jfree.chart.block.RectangleConstraint(var66, var69);
    boolean var74 = var66.contains(10.0d);
    org.jfree.data.Range var77 = org.jfree.data.Range.expand(var66, 1.0d, 1.0d);
    double var78 = var77.getUpperBound();
    var56.setRange(var77);
    java.lang.String var80 = var77.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var80 + "' != '" + "Range[100.0,100.0]"+ "'", var80.equals("Range[100.0,100.0]"));

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test159"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     int var6 = var4.getDomainAxisIndex(var5);
//     var4.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
//     var4.setNoDataMessage("");
//     java.awt.Graphics2D var12 = null;
//     java.awt.Font var14 = null;
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     java.awt.Paint var20 = var19.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var19, true);
//     org.jfree.chart.title.Title var23 = null;
//     var22.removeSubtitle(var23);
//     org.jfree.chart.plot.Plot var25 = var22.getPlot();
//     org.jfree.chart.title.TextTitle var26 = var22.getTitle();
//     var26.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.awt.geom.Rectangle2D var32 = var26.getBounds();
//     java.util.List var33 = null;
//     var4.drawRangeTickBands(var12, var32, var33);
//     var4.setRangeCrosshairValue(100.0d);
//     org.jfree.chart.util.RectangleEdge var38 = var4.getDomainAxisEdge(1);
//     int var39 = var4.getRangeAxisCount();
//     org.jfree.chart.LegendItemCollection var40 = var4.getFixedLegendItems();
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
//     var46.setForegroundAlpha(0.0f);
//     float var49 = var46.getBackgroundImageAlpha();
//     boolean var50 = var46.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var51 = var46.getRangeAxisEdge();
//     java.lang.Object var52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var46);
//     java.awt.Paint var53 = var46.getOutlinePaint();
//     org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var57 = var55.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var58 = var55.getLowerMargin();
//     var55.setCategoryLabelPositionOffset(1);
//     double var61 = var55.getUpperMargin();
//     java.awt.Stroke var62 = var55.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(100.0d, var53, var62);
//     java.awt.Stroke var64 = var63.getStroke();
//     boolean var65 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var63);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test160"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.Paint var10 = var9.getDomainCrosshairPaint();
//     var4.setBackgroundPaint(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var4.zoomDomainAxes((-1.0d), var13, var14);
//     var4.setNoDataMessage("hi!");
//     org.jfree.chart.plot.SeriesRenderingOrder var18 = var4.getSeriesRenderingOrder();
//     org.jfree.chart.util.RectangleEdge var19 = var4.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var23 = var21.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var24 = var21.getLowerMargin();
//     var21.setCategoryLabelPositionOffset(1);
//     double var27 = var21.getUpperMargin();
//     java.awt.Stroke var28 = var21.getAxisLineStroke();
//     var4.setRangeGridlineStroke(var28);
//     java.awt.Paint var30 = var4.getDomainGridlinePaint();
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     var36.setForegroundAlpha(0.0f);
//     float var39 = var36.getBackgroundImageAlpha();
//     boolean var40 = var36.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var41 = var36.getRangeAxisEdge();
//     java.lang.Object var42 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var36);
//     java.awt.Paint var43 = var36.getOutlinePaint();
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var47 = var45.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var48 = var45.getLowerMargin();
//     var45.setCategoryLabelPositionOffset(1);
//     double var51 = var45.getUpperMargin();
//     java.awt.Stroke var52 = var45.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(100.0d, var43, var52);
//     java.awt.Stroke var54 = var53.getStroke();
//     org.jfree.chart.util.LengthAdjustmentType var55 = var53.getLabelOffsetType();
//     java.awt.Font var57 = null;
//     org.jfree.data.xy.XYDataset var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var58, var59, var60, var61);
//     java.awt.Paint var63 = var62.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart("", var57, (org.jfree.chart.plot.Plot)var62, true);
//     org.jfree.chart.title.Title var66 = null;
//     var65.removeSubtitle(var66);
//     boolean var68 = var65.isNotify();
//     boolean var69 = var53.equals((java.lang.Object)var68);
//     org.jfree.chart.util.Layer var70 = null;
//     boolean var71 = var4.removeDomainMarker((org.jfree.chart.plot.Marker)var53, var70);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test161"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.util.RectangleEdge var14 = var10.getDomainAxisEdge(0);
    org.jfree.chart.util.RectangleEdge var16 = var10.getRangeAxisEdge(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test162"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var13 = var12.isVisible();
    java.util.List var14 = var10.getCategoriesForAxis(var12);
    int var15 = var10.getDomainAxisCount();
    var10.clearDomainMarkers((-65536));
    boolean var18 = var10.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test163"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
//     boolean var2 = var1.isVerticalTickLabels();
//     org.jfree.chart.axis.Timeline var3 = null;
//     var1.setTimeline(var3);
//     org.jfree.chart.axis.DateTickUnit var5 = null;
//     java.util.Date var6 = var1.calculateHighestVisibleTickValue(var5);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test164"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 100.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(0.0d);
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 100.0d);
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    boolean var12 = var10.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(var7, var10);
    boolean var15 = var7.contains(10.0d);
    org.jfree.data.Range var18 = org.jfree.data.Range.expand(var7, 1.0d, 1.0d);
    boolean var21 = var7.intersects(100.0d, (-8.0d));
    org.jfree.chart.block.RectangleConstraint var22 = var2.toRangeHeight(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test165"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.RectangleEdge var22 = var4.getRangeAxisEdge(10);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    var4.setRenderer(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test166"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieSection: -10, 0(1)");
    java.text.NumberFormat var2 = var1.getPercentFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test167"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    java.awt.Paint var13 = var12.getDomainCrosshairPaint();
    var7.setBackgroundPaint(var13);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var7.zoomDomainAxes((-1.0d), var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var19};
    var7.setDomainAxes(var20);
    var7.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var24 = var7.getDomainAxisLocation((-65536));
    org.jfree.chart.plot.PlotOrientation var25 = var7.getOrientation();
    boolean var26 = var2.equals((java.lang.Object)var7);
    org.jfree.chart.plot.DatasetRenderingOrder var27 = var7.getDatasetRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test168"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
    boolean var9 = var7.equals((java.lang.Object)'a');
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var13, "hi!", "hi!", "hi!");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test169"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.chart.plot.DatasetRenderingOrder var11 = var10.getDatasetRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test170"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var10.getRangeMarkers(var14);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var10.getDomainMarkers(var16);
    java.util.List var18 = var10.getCategories();
    boolean var19 = var10.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test171"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes(100.0d, var7, var8, false);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var13, true);
    var13.setLabelAngle((-1.0d));
    var13.setAutoRange(false);
    double var20 = var13.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test172"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var3 = var2.getCategoryLabelPositions();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var6 = var5.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var10 = var8.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var5.setTickMarkPaint(var10);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var5, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    java.awt.Paint var26 = var25.getDomainCrosshairPaint();
    var20.setBackgroundPaint(var26);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var20.zoomDomainAxes((-1.0d), var29, var30);
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.axis.ValueAxis[] var33 = new org.jfree.chart.axis.ValueAxis[] { var32};
    var20.setDomainAxes(var33);
    var20.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var37 = var20.getDomainAxisLocation((-65536));
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
    java.awt.Paint var43 = var42.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var42.zoomDomainAxes(100.0d, var45, var46, false);
    var42.setRangeCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var52 = var42.getOrientation();
    org.jfree.chart.util.RectangleEdge var53 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var37, var52);
    var15.setDomainAxisLocation(var37, false);
    org.jfree.data.category.CategoryDataset var57 = null;
    var15.setDataset(0, var57);
    org.jfree.chart.annotations.CategoryAnnotation var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var60 = var15.removeAnnotation(var59);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test173"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var9.removeProgressListener(var12);
    var9.fireChartChanged();
    float var15 = var9.getBackgroundImageAlpha();
    java.awt.RenderingHints var16 = var9.getRenderingHints();
    org.jfree.chart.title.LegendTitle var18 = var9.getLegend(100);
    org.jfree.chart.event.ChartProgressListener var19 = null;
    var9.addProgressListener(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test174"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.Paint var6 = var5.getDomainCrosshairPaint();
    java.awt.Stroke var7 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var11 = var10.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var15 = var13.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var10.setTickMarkPaint(var15);
    var5.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var20 = var19.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var21 = null;
    var19.setTickUnit(var21);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var19, var23);
    float var25 = var19.getTickMarkInsideLength();
    var19.setAutoRange(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0f);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test175"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test176"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var9.removeProgressListener(var12);
    var9.clearSubtitles();
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var18 = var16.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var19 = var16.getLowerMargin();
    java.lang.Object var20 = var16.clone();
    var16.setMaximumCategoryLabelWidthRatio(0.0f);
    boolean var23 = var9.equals((java.lang.Object)var16);
    java.lang.String var24 = var16.getLabelToolTip();
    java.awt.Paint var25 = var16.getLabelPaint();
    java.awt.Stroke var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setTickMarkStroke(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test177"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
    java.awt.color.ColorSpace var4 = var3.getColorSpace();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var5.equals("java.awt.Color[r=255,g=253,b=100]"));

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test178"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
    int var4 = var3.getRed();
    java.awt.Color var5 = var3.darker();
    java.awt.Font var7 = null;
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    java.awt.Paint var13 = var12.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, true);
    org.jfree.chart.title.Title var16 = null;
    var15.removeSubtitle(var16);
    org.jfree.chart.plot.Plot var18 = var15.getPlot();
    org.jfree.chart.title.TextTitle var19 = var15.getTitle();
    var19.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var25 = var19.getBounds();
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.ValueAxis var31 = null;
    int var32 = var30.getDomainAxisIndex(var31);
    var30.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var35 = var30.getRangeAxisEdge();
    double var36 = org.jfree.chart.util.RectangleEdge.coordinate(var25, var35);
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.entity.PieSectionEntity var43 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var25, var37, (-10), (-1), (java.lang.Comparable)1, " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]");
    java.lang.String var44 = var43.getShapeCoords();
    boolean var45 = var5.equals((java.lang.Object)var43);
    var43.setSectionKey((java.lang.Comparable)"RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "0,0,1,1"+ "'", var44.equals("0,0,1,1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test179"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var1.setTickUnit(var3, true, true);
    boolean var7 = var1.isInverted();
    org.jfree.chart.axis.TickUnitSource var8 = var1.getStandardTickUnits();
    var1.setLowerMargin(9.0d);
    var1.setTickMarksVisible(true);
    org.jfree.chart.axis.TickUnitSource var13 = null;
    var1.setStandardTickUnits(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    var10.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var16.setValue(0.0d);
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test181"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var9.removeProgressListener(var12);
    var9.clearSubtitles();
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var18 = var16.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var19 = var16.getLowerMargin();
    java.lang.Object var20 = var16.clone();
    var16.setMaximumCategoryLabelWidthRatio(0.0f);
    boolean var23 = var9.equals((java.lang.Object)var16);
    java.lang.String var24 = var16.getLabelToolTip();
    boolean var25 = var16.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test182"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    java.awt.Font var3 = var1.getTickLabelFont();
    var1.setTickLabelsVisible(false);
    int var6 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.util.RectangleInsets var7 = var1.getTickLabelInsets();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    java.awt.Paint var13 = var12.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var12.zoomDomainAxes(100.0d, var15, var16, false);
    var12.setRangeCrosshairValue(1.0d, true);
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.data.Range var23 = var12.getDataRange(var22);
    java.awt.Graphics2D var24 = null;
    java.awt.Font var26 = null;
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    java.awt.Paint var32 = var31.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("", var26, (org.jfree.chart.plot.Plot)var31, true);
    org.jfree.chart.title.Title var35 = null;
    var34.removeSubtitle(var35);
    org.jfree.chart.plot.Plot var37 = var34.getPlot();
    org.jfree.chart.title.TextTitle var38 = var34.getTitle();
    var38.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var44 = var38.getBounds();
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    org.jfree.chart.plot.CrosshairState var47 = null;
    boolean var48 = var12.render(var24, var44, (-65536), var46, var47);
    org.jfree.chart.util.LengthAdjustmentType var49 = null;
    org.jfree.chart.util.LengthAdjustmentType var50 = null;
    java.awt.geom.Rectangle2D var51 = var7.createAdjustedRectangle(var44, var49, var50);
    org.jfree.chart.entity.ChartEntity var52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var44);
    org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var53 = null;
    org.jfree.chart.imagemap.URLTagFragmentGenerator var54 = null;
    java.lang.String var55 = var52.getImageMapAreaTag(var53, var54);
    java.lang.String var56 = var52.getShapeCoords();
    java.lang.String var57 = var52.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + ""+ "'", var55.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + "0,0,1,1"+ "'", var56.equals("0,0,1,1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test183"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.Paint var6 = var5.getDomainCrosshairPaint();
    java.awt.Stroke var7 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var11 = var10.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var15 = var13.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var10.setTickMarkPaint(var15);
    var5.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var20 = var19.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var21 = null;
    var19.setTickUnit(var21);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var19, var23);
    org.jfree.chart.axis.DateTickUnit var25 = null;
    var19.setTickUnit(var25, true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test184"); }


    java.awt.Font var1 = null;
    java.awt.Font var3 = null;
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
    java.awt.Paint var9 = var8.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("", var3, (org.jfree.chart.plot.Plot)var8, true);
    org.jfree.chart.title.Title var12 = null;
    var11.removeSubtitle(var12);
    int var14 = var11.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var20 = var19.getPaint();
    var11.setBorderPaint(var20);
    org.jfree.chart.text.TextMeasurer var24 = null;
    org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var20, 10.0f, 100, var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.text.TextBlockAnchor var29 = null;
    java.awt.Shape var33 = var25.calculateBounds(var26, 0.0f, 100.0f, var29, 1.0f, 100.0f, 1.0d);
    java.util.List var34 = var25.getLines();
    org.jfree.chart.util.HorizontalAlignment var35 = var25.getLineAlignment();
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.text.TextBlockAnchor var39 = null;
    var25.draw(var36, 0.0f, 1.0f, var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test185"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 108.0d);
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    java.awt.Paint var12 = var11.getDomainCrosshairPaint();
    java.awt.Stroke var13 = var11.getDomainZeroBaselineStroke();
    var6.setOutlineStroke(var13);
    var6.setValue(100.0d);
    boolean var17 = var4.equals((java.lang.Object)100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test186"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     int var12 = var9.getBackgroundImageAlignment();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
//     java.awt.Paint var18 = var17.getPaint();
//     var9.setBorderPaint(var18);
//     org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     int var27 = var25.getDomainAxisIndex(var26);
//     var25.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
//     boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
//     java.lang.String var32 = var30.toString();
//     var20.setLegendItemGraphicEdge(var30);
//     org.jfree.chart.util.RectangleInsets var34 = var20.getLegendItemGraphicPadding();
//     java.awt.Font var36 = null;
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
//     java.awt.Paint var42 = var41.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("", var36, (org.jfree.chart.plot.Plot)var41, true);
//     org.jfree.chart.title.Title var45 = null;
//     var44.removeSubtitle(var45);
//     org.jfree.chart.event.ChartProgressListener var47 = null;
//     var44.removeProgressListener(var47);
//     var44.clearSubtitles();
//     org.jfree.chart.title.TextTitle var50 = var44.getTitle();
//     org.jfree.chart.util.RectangleEdge var51 = var50.getPosition();
//     org.jfree.chart.util.HorizontalAlignment var52 = var50.getTextAlignment();
//     var20.setHorizontalAlignment(var52);
//     
//     // Checks the contract:  equals-hashcode on var6 and var41
//     assertTrue("Contract failed: equals-hashcode on var6 and var41", var6.equals(var41) ? var6.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var6
//     assertTrue("Contract failed: equals-hashcode on var41 and var6", var41.equals(var6) ? var41.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test187"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var13 = var12.isVisible();
    java.util.List var14 = var10.getCategoriesForAxis(var12);
    java.util.List var15 = var10.getCategories();
    org.jfree.chart.util.RectangleEdge var17 = var10.getDomainAxisEdge((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test188"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.awt.Font var14 = null;
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     java.awt.Paint var20 = var19.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var19, true);
//     org.jfree.chart.title.Title var23 = null;
//     var22.removeSubtitle(var23);
//     org.jfree.chart.plot.Plot var25 = var22.getPlot();
//     org.jfree.chart.title.TextTitle var26 = var22.getTitle();
//     java.awt.Image var27 = var22.getBackgroundImage();
//     java.awt.RenderingHints var28 = var22.getRenderingHints();
//     var9.setRenderingHints(var28);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var22
//     assertTrue("Contract failed: equals-hashcode on var9 and var22", var9.equals(var22) ? var9.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var9
//     assertTrue("Contract failed: equals-hashcode on var22 and var9", var22.equals(var9) ? var22.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var25
//     assertTrue("Contract failed: equals-hashcode on var12 and var25", var12.equals(var25) ? var12.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var12
//     assertTrue("Contract failed: equals-hashcode on var25 and var12", var25.equals(var12) ? var25.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test189"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.Paint var10 = var9.getDomainCrosshairPaint();
//     var4.setBackgroundPaint(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var4.zoomDomainAxes((-1.0d), var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
//     var4.setDomainAxes(var17);
//     var4.configureDomainAxes();
//     var4.clearRangeMarkers(1);
//     org.jfree.data.general.DatasetGroup var22 = var4.getDatasetGroup();
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     int var30 = var28.getDomainAxisIndex(var29);
//     var28.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var33 = var28.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisLocation var34 = var28.getDomainAxisLocation();
//     var4.setRangeAxisLocation(100, var34);
//     org.jfree.chart.util.RectangleEdge var36 = var4.getRangeAxisEdge();
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     int var38 = var4.getRangeAxisIndex(var37);
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var46, var47, var48, var49);
//     java.awt.Paint var51 = var50.getDomainCrosshairPaint();
//     var45.setBackgroundPaint(var51);
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     java.awt.geom.Point2D var55 = null;
//     var45.zoomDomainAxes((-1.0d), var54, var55);
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.axis.ValueAxis[] var58 = new org.jfree.chart.axis.ValueAxis[] { var57};
//     var45.setDomainAxes(var58);
//     org.jfree.chart.axis.AxisLocation var61 = var45.getDomainAxisLocation(0);
//     org.jfree.chart.plot.PlotRenderingInfo var63 = null;
//     org.jfree.data.xy.XYDataset var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var67 = null;
//     org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot(var64, var65, var66, var67);
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     int var70 = var68.getDomainAxisIndex(var69);
//     var68.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var73 = var68.getRangeAxisEdge();
//     java.awt.Paint var74 = var68.getRangeTickBandPaint();
//     var68.configureDomainAxes();
//     java.awt.geom.Point2D var76 = var68.getQuadrantOrigin();
//     var45.zoomDomainAxes(108.0d, var63, var76, false);
//     var4.zoomDomainAxes((-1.0d), var40, var76);
//     
//     // Checks the contract:  equals-hashcode on var9 and var50
//     assertTrue("Contract failed: equals-hashcode on var9 and var50", var9.equals(var50) ? var9.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var68
//     assertTrue("Contract failed: equals-hashcode on var28 and var68", var28.equals(var68) ? var28.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var4
//     assertTrue("Contract failed: equals-hashcode on var45 and var4", var45.equals(var4) ? var45.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var9
//     assertTrue("Contract failed: equals-hashcode on var50 and var9", var50.equals(var9) ? var50.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var28
//     assertTrue("Contract failed: equals-hashcode on var68 and var28", var68.equals(var28) ? var68.hashCode() == var28.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var45 and var4.", var45.equals(var4) == var4.equals(var45));
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test190"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
    var7.addOptionalLibrary("");
    var7.setLicenceText("");
    java.lang.String var12 = var7.toString();
    java.awt.Image var13 = var7.getLogo();
    var7.setCopyright("RectangleEdge.BOTTOM");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var12.equals(" version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test191"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.axis.ValueAxis var26 = null;
    int var27 = var25.getDomainAxisIndex(var26);
    var25.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
    boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
    java.lang.String var32 = var30.toString();
    var20.setLegendItemGraphicEdge(var30);
    org.jfree.chart.block.BlockContainer var34 = null;
    var20.setWrapper(var34);
    java.lang.Object var36 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
    var20.setMargin((-1.0d), 0.0d, 100.0d, 100.0d);
    var20.setMargin(9.0d, 100.0d, 1.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "RectangleEdge.LEFT"+ "'", var32.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test192"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor((-10));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test193"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.util.RectangleEdge var14 = var10.getDomainAxisEdge(0);
    boolean var15 = var10.isDomainZoomable();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    java.awt.Paint var26 = var25.getDomainCrosshairPaint();
    var20.setBackgroundPaint(var26);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var20.zoomDomainAxes((-1.0d), var29, var30);
    var20.clearAnnotations();
    org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var36 = var34.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var37 = var34.getLowerMargin();
    var34.setCategoryLabelPositionOffset(1);
    double var40 = var34.getUpperMargin();
    java.awt.Stroke var41 = var34.getAxisLineStroke();
    var20.setDomainZeroBaselineStroke(var41);
    var10.setRangeCrosshairStroke(var41);
    org.jfree.data.xy.XYDataset var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
    var48.setForegroundAlpha(0.0f);
    org.jfree.data.xy.XYDataset var51 = null;
    int var52 = var48.indexOf(var51);
    java.awt.Image var53 = null;
    var48.setBackgroundImage(var53);
    org.jfree.chart.util.RectangleInsets var55 = var48.getInsets();
    boolean var56 = var10.equals((java.lang.Object)var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test194"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 100.0d);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedHeight(0.0d);
    org.jfree.data.Range var6 = var2.getHeightRange();
    double var7 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test195"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var9.removeProgressListener(var12);
    var9.fireChartChanged();
    float var15 = var9.getBackgroundImageAlpha();
    java.awt.RenderingHints var16 = var9.getRenderingHints();
    org.jfree.chart.title.LegendTitle var18 = var9.getLegend(100);
    var9.setBackgroundImageAlpha(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test196"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    org.jfree.chart.title.TextTitle var13 = var9.getTitle();
    var13.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var19 = var13.getBounds();
    var13.setToolTipText("hi!");
    org.jfree.chart.block.BlockFrame var22 = var13.getFrame();
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var25 = var24.getCategoryLabelPositions();
    java.awt.Font var26 = var24.getTickLabelFont();
    var13.setFont(var26);
    boolean var29 = var13.equals((java.lang.Object)1.0f);
    var13.setExpandToFitSpace(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test197"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    java.lang.Object var2 = null;
    boolean var3 = var1.equals(var2);
    java.awt.Font var5 = null;
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.Paint var11 = var10.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var10, true);
    org.jfree.chart.title.Title var14 = null;
    var13.removeSubtitle(var14);
    boolean var16 = var1.equals((java.lang.Object)var13);
    org.jfree.chart.title.Title var18 = var13.getSubtitle(0);
    org.jfree.chart.block.BlockFrame var19 = var18.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test198"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes(100.0d, var7, var8, false);
    var4.setRangeCrosshairValue(1.0d, true);
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.data.Range var15 = var4.getDataRange(var14);
    java.awt.Graphics2D var16 = null;
    java.awt.Font var18 = null;
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    java.awt.Paint var24 = var23.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("", var18, (org.jfree.chart.plot.Plot)var23, true);
    org.jfree.chart.title.Title var27 = null;
    var26.removeSubtitle(var27);
    org.jfree.chart.plot.Plot var29 = var26.getPlot();
    org.jfree.chart.title.TextTitle var30 = var26.getTitle();
    var30.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var36 = var30.getBounds();
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    org.jfree.chart.plot.CrosshairState var39 = null;
    boolean var40 = var4.render(var16, var36, (-65536), var38, var39);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
    var46.setForegroundAlpha(0.0f);
    var46.mapDatasetToRangeAxis(0, 10);
    var46.clearAnnotations();
    org.jfree.chart.axis.AxisLocation var54 = var46.getDomainAxisLocation(100);
    var4.setDomainAxisLocation(100, var54, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test199"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    var4.mapDatasetToRangeAxis(0, 10);
    java.lang.Object var10 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test200"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor(" version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "java.awt.Color[r=255,g=253,b=100]");

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test201"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    var9.setBorderVisible(false);
    var9.clearSubtitles();
    var9.fireChartChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test202"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    boolean var13 = var10.isDomainZoomable();
    java.awt.Graphics2D var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    int var21 = var19.getDomainAxisIndex(var20);
    var19.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var24 = var19.getRangeAxisEdge();
    var19.setNoDataMessage("");
    java.awt.Graphics2D var27 = null;
    java.awt.Font var29 = null;
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    java.awt.Paint var35 = var34.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("", var29, (org.jfree.chart.plot.Plot)var34, true);
    org.jfree.chart.title.Title var38 = null;
    var37.removeSubtitle(var38);
    org.jfree.chart.plot.Plot var40 = var37.getPlot();
    org.jfree.chart.title.TextTitle var41 = var37.getTitle();
    var41.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var47 = var41.getBounds();
    java.util.List var48 = null;
    var19.drawRangeTickBands(var27, var47, var48);
    org.jfree.chart.plot.PlotRenderingInfo var51 = null;
    boolean var52 = var10.render(var14, var47, 100, var51);
    var10.clearRangeMarkers();
    org.jfree.data.category.CategoryDataset var54 = null;
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var58 = var56.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var59 = var56.getLowerMargin();
    var56.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
    org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var54, var56, var62, var63);
    org.jfree.data.category.CategoryDataset var65 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var66 = var64.getRendererForDataset(var65);
    org.jfree.data.xy.XYDataset var68 = null;
    org.jfree.chart.axis.ValueAxis var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
    org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var68, var69, var70, var71);
    org.jfree.chart.axis.ValueAxis var73 = null;
    int var74 = var72.getDomainAxisIndex(var73);
    var72.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var77 = var72.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var79 = var72.getRangeAxisLocation((-1));
    var64.setDomainAxisLocation(1, var79);
    java.lang.String var81 = var64.getPlotType();
    org.jfree.chart.axis.DateAxis var84 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var85 = var84.isVerticalTickLabels();
    org.jfree.chart.util.RectangleInsets var86 = var84.getLabelInsets();
    var64.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var84);
    org.jfree.chart.axis.DateAxis var89 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var90 = var89.isVerticalTickLabels();
    org.jfree.chart.util.RectangleInsets var91 = var89.getLabelInsets();
    java.awt.Shape var92 = var89.getLeftArrow();
    var84.setRightArrow(var92);
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var84);
    boolean var95 = var84.isVerticalTickLabels();
    boolean var96 = var84.isNegativeArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var81 + "' != '" + "Category Plot"+ "'", var81.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test203"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = var3.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var6 = var3.getLowerMargin();
    var3.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var1, var3, var9, var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = var11.getRendererForDataset(var12);
    org.jfree.chart.util.RectangleEdge var15 = var11.getDomainAxisEdge(0);
    boolean var16 = var11.isDomainZoomable();
    var11.setRangeCrosshairVisible(false);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    java.awt.Paint var24 = var23.getDomainCrosshairPaint();
    java.awt.Stroke var25 = var23.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.DatasetRenderingOrder var26 = var23.getDatasetRenderingOrder();
    var11.setDatasetRenderingOrder(var26);
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]", (org.jfree.chart.plot.Plot)var11);
    org.jfree.chart.title.LegendTitle var29 = var28.getLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test204"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
    boolean var9 = var7.equals((java.lang.Object)'a');
    java.util.List var10 = var7.getContributors();
    var7.setVersion("RectangleEdge.BOTTOM");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test205"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    org.jfree.chart.title.TextTitle var13 = var9.getTitle();
    var13.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var19 = var13.getBounds();
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
    org.jfree.chart.axis.ValueAxis var25 = null;
    int var26 = var24.getDomainAxisIndex(var25);
    var24.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var29 = var24.getRangeAxisEdge();
    double var30 = org.jfree.chart.util.RectangleEdge.coordinate(var19, var29);
    org.jfree.data.general.PieDataset var31 = null;
    org.jfree.chart.entity.PieSectionEntity var37 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var19, var31, (-10), (-1), (java.lang.Comparable)1, " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]");
    var37.setSectionIndex(0);
    java.awt.Shape var40 = var37.getArea();
    org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    java.lang.Object var43 = var42.clone();
    var42.setLabelAngle(108.0d);
    boolean var46 = var37.equals((java.lang.Object)var42);
    var37.setSectionKey((java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test206"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    float var7 = var4.getBackgroundImageAlpha();
    boolean var8 = var4.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    org.jfree.chart.plot.PlotOrientation var10 = var4.getOrientation();
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var13 = var12.isVerticalTickLabels();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var12.setVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test207"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    java.text.NumberFormat var2 = var1.getPercentFormat();
    java.lang.Object var3 = var1.clone();
    java.text.NumberFormat var4 = var1.getPercentFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test208"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("PieSection: -10, 0(1)", " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "Range[100.0,100.0]", "RectangleEdge.BOTTOM", "java.awt.Color[r=255,g=253,b=100]");

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test209"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    int var12 = var9.getBackgroundImageAlignment();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 100.0d);
    java.awt.Paint var18 = var17.getPaint();
    var9.setBorderPaint(var18);
    org.jfree.chart.title.LegendTitle var20 = var9.getLegend();
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.axis.ValueAxis var26 = null;
    int var27 = var25.getDomainAxisIndex(var26);
    var25.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
    boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
    java.lang.String var32 = var30.toString();
    var20.setLegendItemGraphicEdge(var30);
    org.jfree.chart.block.BlockContainer var34 = null;
    var20.setWrapper(var34);
    java.lang.Object var36 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
    var20.setMargin((-1.0d), 0.0d, 100.0d, 100.0d);
    org.jfree.chart.util.RectangleInsets var42 = var20.getPadding();
    org.jfree.chart.util.RectangleInsets var43 = var20.getItemLabelPadding();
    org.jfree.chart.LegendItemSource[] var44 = var20.getSources();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "RectangleEdge.LEFT"+ "'", var32.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test210"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    org.jfree.chart.title.TextTitle var13 = var9.getTitle();
    org.jfree.chart.title.LegendTitle var14 = var9.getLegend();
    org.jfree.chart.util.RectangleInsets var15 = var14.getLegendItemGraphicPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test211"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     org.jfree.chart.title.TextTitle var13 = var9.getTitle();
//     java.awt.Image var14 = var9.getBackgroundImage();
//     java.awt.RenderingHints var15 = var9.getRenderingHints();
//     var9.setAntiAlias(true);
//     java.awt.Font var19 = null;
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     java.awt.Paint var25 = var24.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("", var19, (org.jfree.chart.plot.Plot)var24, true);
//     org.jfree.chart.title.Title var28 = null;
//     var27.removeSubtitle(var28);
//     org.jfree.chart.plot.Plot var30 = var27.getPlot();
//     org.jfree.chart.title.TextTitle var31 = var27.getTitle();
//     java.awt.Image var32 = var27.getBackgroundImage();
//     java.awt.RenderingHints var33 = var27.getRenderingHints();
//     var9.setRenderingHints(var33);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var27
//     assertTrue("Contract failed: equals-hashcode on var9 and var27", var9.equals(var27) ? var9.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var9
//     assertTrue("Contract failed: equals-hashcode on var27 and var9", var27.equals(var9) ? var27.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var30
//     assertTrue("Contract failed: equals-hashcode on var12 and var30", var12.equals(var30) ? var12.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var12
//     assertTrue("Contract failed: equals-hashcode on var30 and var12", var30.equals(var12) ? var30.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test212"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    java.lang.String var2 = var1.getLabelFormat();
    org.jfree.data.general.PieDataset var3 = null;
    java.lang.String var5 = var1.generateSectionLabel(var3, (java.lang.Comparable)'4');
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "hi!"+ "'", var2.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test213"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    float var7 = var4.getBackgroundImageAlpha();
    org.jfree.chart.plot.Plot var8 = var4.getRootPlot();
    org.jfree.chart.axis.AxisSpace var9 = var4.getFixedRangeAxisSpace();
    var4.setBackgroundImageAlpha(0.0f);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    java.awt.Paint var22 = var21.getDomainCrosshairPaint();
    var16.setBackgroundPaint(var22);
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    java.awt.geom.Point2D var26 = null;
    var16.zoomDomainAxes((-1.0d), var25, var26);
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis[] var29 = new org.jfree.chart.axis.ValueAxis[] { var28};
    var16.setDomainAxes(var29);
    var16.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.RectangleEdge var34 = var16.getRangeAxisEdge(10);
    org.jfree.chart.util.RectangleInsets var35 = var16.getAxisOffset();
    java.lang.String var36 = var35.toString();
    double var38 = var35.calculateLeftOutset(10.0d);
    double var40 = var35.extendWidth(100.0d);
    double var42 = var35.calculateBottomOutset(100.0d);
    var4.setInsets(var35, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"+ "'", var36.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 108.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 4.0d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test214"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var5 = null;
    org.jfree.chart.util.VerticalAlignment var6 = null;
    org.jfree.chart.block.FlowArrangement var9 = new org.jfree.chart.block.FlowArrangement(var5, var6, 100.0d, 10.0d);
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var9);
    boolean var11 = var10.isEmpty();
    java.awt.Graphics2D var12 = null;
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    org.jfree.data.Range var17 = null;
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, 100.0d);
    org.jfree.chart.block.RectangleConstraint var20 = var19.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var22 = var19.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    java.lang.String var24 = var23.toString();
    org.jfree.data.Range var26 = null;
    org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var26, 100.0d);
    org.jfree.data.Range var29 = null;
    org.jfree.data.Range var31 = org.jfree.data.Range.expandToInclude(var29, 100.0d);
    boolean var33 = var31.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(var28, var31);
    org.jfree.data.Range var35 = null;
    org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(var35, 100.0d);
    org.jfree.chart.block.RectangleConstraint var38 = var37.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var40 = var37.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var41 = var40.getWidthConstraintType();
    java.lang.String var42 = var41.toString();
    org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint(100.0d, var16, var23, (-1.0d), var28, var41);
    org.jfree.chart.util.Size2D var44 = var4.arrange(var10, var12, var43);
    var4.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var24.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var42.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test215"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(1, var25);
    var10.clearDomainMarkers();
    org.jfree.chart.LegendItemCollection var28 = var10.getFixedLegendItems();
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    org.jfree.chart.axis.ValueAxis var35 = null;
    int var36 = var34.getDomainAxisIndex(var35);
    var34.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var39 = var34.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var40 = var34.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var44 = var42.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var34.setRangeGridlinePaint(var44);
    org.jfree.chart.plot.PlotRenderingInfo var47 = null;
    java.awt.geom.Point2D var48 = null;
    var34.zoomDomainAxes((-1.0d), var47, var48);
    org.jfree.data.xy.XYDataset var50 = null;
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.axis.ValueAxis var52 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
    org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var50, var51, var52, var53);
    java.awt.Paint var55 = var54.getDomainCrosshairPaint();
    boolean var56 = var54.isDomainGridlinesVisible();
    var54.setBackgroundImageAlpha(1.0f);
    org.jfree.data.xy.XYDataset var59 = null;
    org.jfree.chart.axis.ValueAxis var60 = null;
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var62 = null;
    org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot(var59, var60, var61, var62);
    org.jfree.data.xy.XYDataset var64 = null;
    org.jfree.chart.axis.ValueAxis var65 = null;
    org.jfree.chart.axis.ValueAxis var66 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var67 = null;
    org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot(var64, var65, var66, var67);
    java.awt.Paint var69 = var68.getDomainCrosshairPaint();
    var63.setBackgroundPaint(var69);
    org.jfree.chart.plot.PlotRenderingInfo var72 = null;
    java.awt.geom.Point2D var73 = null;
    var63.zoomDomainAxes((-1.0d), var72, var73);
    org.jfree.chart.axis.ValueAxis var75 = null;
    org.jfree.chart.axis.ValueAxis[] var76 = new org.jfree.chart.axis.ValueAxis[] { var75};
    var63.setDomainAxes(var76);
    org.jfree.chart.axis.AxisLocation var79 = var63.getDomainAxisLocation(0);
    var54.setDomainAxisLocation(var79, false);
    var34.setDomainAxisLocation(var79, false);
    var10.setRangeAxisLocation(1, var79, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test216"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var4 = var1.getLowerMargin();
    java.lang.Object var5 = var1.clone();
    var1.setCategoryLabelPositionOffset(100);
    java.lang.String var8 = var1.getLabelURL();
    org.jfree.chart.axis.CategoryLabelPositions var9 = var1.getCategoryLabelPositions();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test217"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    var4.setNoDataMessage("hi!");
    var4.zoom(10.0d);
    org.jfree.chart.plot.DrawingSupplier var20 = null;
    var4.setDrawingSupplier(var20);
    var4.setDomainZeroBaselineVisible(true);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var28 = var26.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var29 = var26.getLowerMargin();
    var26.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var24, var26, var32, var33);
    org.jfree.data.category.CategoryDataset var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var34.getRendererForDataset(var35);
    org.jfree.chart.util.RectangleEdge var38 = var34.getDomainAxisEdge(0);
    boolean var39 = var34.isDomainZoomable();
    var34.setRangeCrosshairVisible(false);
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
    var47.setForegroundAlpha(0.0f);
    float var50 = var47.getBackgroundImageAlpha();
    boolean var51 = var47.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var52 = var47.getRangeAxisEdge();
    java.lang.Object var53 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var47);
    java.awt.Paint var54 = var47.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var58 = var56.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var59 = var56.getLowerMargin();
    var56.setCategoryLabelPositionOffset(1);
    double var62 = var56.getUpperMargin();
    java.awt.Stroke var63 = var56.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(100.0d, var54, var63);
    var34.addRangeMarker((org.jfree.chart.plot.Marker)var64);
    var64.setLabel("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var64);
    org.jfree.chart.event.MarkerChangeEvent var69 = null;
    var64.notifyListeners(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test218"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
    boolean var9 = var7.equals((java.lang.Object)'a');
    org.jfree.chart.ui.Library[] var10 = var7.getOptionalLibraries();
    java.awt.Font var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    java.awt.Paint var18 = var17.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var12, (org.jfree.chart.plot.Plot)var17, true);
    org.jfree.chart.title.Title var21 = null;
    var20.removeSubtitle(var21);
    org.jfree.chart.event.ChartProgressListener var23 = null;
    var20.removeProgressListener(var23);
    var20.clearSubtitles();
    boolean var26 = var20.isBorderVisible();
    org.jfree.chart.event.ChartChangeEventType var27 = null;
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var20, var27);
    var20.clearSubtitles();
    int var30 = var20.getBackgroundImageAlignment();
    var20.removeLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 15);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test219"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.Paint var10 = var9.getDomainCrosshairPaint();
//     var4.setBackgroundPaint(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var4.zoomDomainAxes((-1.0d), var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
//     var4.setDomainAxes(var17);
//     var4.setRangeCrosshairValue(100.0d);
//     org.jfree.chart.util.RectangleEdge var22 = var4.getRangeAxisEdge(10);
//     org.jfree.chart.util.RectangleInsets var23 = var4.getAxisOffset();
//     java.lang.String var24 = var23.toString();
//     double var26 = var23.extendWidth(0.0d);
//     double var28 = var23.calculateTopOutset(0.0d);
//     double var29 = var23.getLeft();
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var34 = var32.getTickLabelFont((java.lang.Comparable)(byte)100);
//     double var35 = var32.getLowerMargin();
//     var32.setCategoryLabelPositionOffset(1);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var30, var32, var38, var39);
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = var40.getRendererForDataset(var41);
//     boolean var43 = var40.isDomainZoomable();
//     java.awt.Graphics2D var44 = null;
//     org.jfree.data.xy.XYDataset var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var45, var46, var47, var48);
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     int var51 = var49.getDomainAxisIndex(var50);
//     var49.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var54 = var49.getRangeAxisEdge();
//     var49.setNoDataMessage("");
//     java.awt.Graphics2D var57 = null;
//     java.awt.Font var59 = null;
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
//     java.awt.Paint var65 = var64.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart("", var59, (org.jfree.chart.plot.Plot)var64, true);
//     org.jfree.chart.title.Title var68 = null;
//     var67.removeSubtitle(var68);
//     org.jfree.chart.plot.Plot var70 = var67.getPlot();
//     org.jfree.chart.title.TextTitle var71 = var67.getTitle();
//     var71.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.awt.geom.Rectangle2D var77 = var71.getBounds();
//     java.util.List var78 = null;
//     var49.drawRangeTickBands(var57, var77, var78);
//     org.jfree.chart.plot.PlotRenderingInfo var81 = null;
//     boolean var82 = var40.render(var44, var77, 100, var81);
//     java.awt.geom.Rectangle2D var83 = var23.createInsetRectangle(var77);
//     
//     // Checks the contract:  equals-hashcode on var9 and var64
//     assertTrue("Contract failed: equals-hashcode on var9 and var64", var9.equals(var64) ? var9.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var9
//     assertTrue("Contract failed: equals-hashcode on var64 and var9", var64.equals(var9) ? var64.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test220"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    var4.configureDomainAxes();
    var4.clearRangeMarkers(1);
    org.jfree.data.general.DatasetGroup var22 = var4.getDatasetGroup();
    var4.mapDatasetToDomainAxis(0, (-1));
    var4.setDomainCrosshairLockedOnData(true);
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLabelAnchor();
    var4.addDomainMarker((org.jfree.chart.plot.Marker)var29);
    double var32 = var29.getValue();
    java.lang.String var33 = var29.getLabel();
    java.awt.Font var34 = var29.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test221"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var10 = var4.getDomainAxisEdge(100);
    org.jfree.chart.axis.ValueAxis var11 = var4.getRangeAxis();
    java.lang.Object var12 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test222"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
    int var5 = var4.getRed();
    java.awt.Color var6 = var4.darker();
    java.awt.Color var7 = var4.darker();
    java.awt.Color var11 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
    int var12 = var11.getRed();
    java.awt.Color var13 = var11.darker();
    java.awt.Font var15 = null;
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    java.awt.Paint var21 = var20.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("", var15, (org.jfree.chart.plot.Plot)var20, true);
    org.jfree.chart.title.Title var24 = null;
    var23.removeSubtitle(var24);
    org.jfree.chart.plot.Plot var26 = var23.getPlot();
    org.jfree.chart.title.TextTitle var27 = var23.getTitle();
    var27.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var33 = var27.getBounds();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
    org.jfree.chart.axis.ValueAxis var39 = null;
    int var40 = var38.getDomainAxisIndex(var39);
    var38.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var43 = var38.getRangeAxisEdge();
    double var44 = org.jfree.chart.util.RectangleEdge.coordinate(var33, var43);
    org.jfree.data.general.PieDataset var45 = null;
    org.jfree.chart.entity.PieSectionEntity var51 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var33, var45, (-10), (-1), (java.lang.Comparable)1, " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]");
    java.lang.String var52 = var51.getShapeCoords();
    boolean var53 = var13.equals((java.lang.Object)var51);
    java.awt.Color var57 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
    java.awt.color.ColorSpace var58 = var57.getColorSpace();
    float[] var59 = null;
    float[] var60 = var13.getComponents(var58, var59);
    float[] var61 = var7.getComponents(var60);
    java.awt.Color var62 = java.awt.Color.getColor("", var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + "0,0,1,1"+ "'", var52.equals("0,0,1,1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test223"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    java.awt.Font var3 = var1.getTickLabelFont();
    var1.setTickLabelsVisible(false);
    int var6 = var1.getCategoryLabelPositionOffset();
    java.lang.String var7 = var1.getLabelToolTip();
    java.awt.Stroke var8 = var1.getAxisLineStroke();
    double var9 = var1.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test224"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.Paint var6 = var5.getDomainCrosshairPaint();
    java.awt.Stroke var7 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var11 = var10.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var15 = var13.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var10.setTickMarkPaint(var15);
    var5.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var20 = var19.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var21 = null;
    var19.setTickUnit(var21);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var19, var23);
    float var25 = var19.getTickMarkInsideLength();
    boolean var26 = var19.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test225"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 10.0d);
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, 100.0d);
    org.jfree.chart.block.RectangleConstraint var8 = var7.toUnconstrainedHeight();
    boolean var9 = var4.equals((java.lang.Object)var7);
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test226"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.util.RectangleEdge var14 = var10.getDomainAxisEdge(0);
    boolean var15 = var10.isDomainZoomable();
    int var16 = var10.getRangeAxisCount();
    java.awt.Stroke var17 = var10.getDomainGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test227"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var1.setTickUnit(var3, true, true);
    boolean var7 = var1.isInverted();
    org.jfree.chart.axis.TickUnitSource var8 = var1.getStandardTickUnits();
    var1.setLowerMargin(9.0d);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var14, "hi!", "hi!", "hi!");
    boolean var20 = var18.equals((java.lang.Object)'a');
    org.jfree.chart.ui.Library[] var21 = var18.getOptionalLibraries();
    java.awt.Font var23 = null;
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
    java.awt.Paint var29 = var28.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("", var23, (org.jfree.chart.plot.Plot)var28, true);
    org.jfree.chart.title.Title var32 = null;
    var31.removeSubtitle(var32);
    org.jfree.chart.event.ChartProgressListener var34 = null;
    var31.removeProgressListener(var34);
    var31.clearSubtitles();
    boolean var37 = var31.isBorderVisible();
    org.jfree.chart.event.ChartChangeEventType var38 = null;
    org.jfree.chart.event.ChartChangeEvent var39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var18, var31, var38);
    var31.clearSubtitles();
    org.jfree.chart.plot.XYPlot var41 = var31.getXYPlot();
    java.awt.Paint var42 = var31.getBackgroundPaint();
    var1.setAxisLinePaint(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test228"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var10 = var4.getDomainAxisEdge(100);
    var4.setDomainCrosshairLockedOnData(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test229"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var6 = var4.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var1.setTickMarkPaint(var6);
    var1.setNegativeArrowVisible(false);
    double var10 = var1.getUpperMargin();
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    java.awt.Paint var16 = var15.getDomainCrosshairPaint();
    java.awt.Stroke var17 = var15.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var21 = var20.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var25 = var23.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var20.setTickMarkPaint(var25);
    var15.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var20);
    org.jfree.chart.axis.DateTickUnit var28 = null;
    var20.setTickUnit(var28, false, false);
    var20.setUpperBound((-8.0d));
    org.jfree.data.Range var34 = var20.getDefaultAutoRange();
    var1.setRange(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test230"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     org.jfree.chart.title.TextTitle var13 = var9.getTitle();
//     var13.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.lang.Object var19 = var13.clone();
//     org.jfree.chart.util.HorizontalAlignment var20 = var13.getTextAlignment();
//     java.awt.Font var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
//     java.awt.Paint var28 = var27.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("", var22, (org.jfree.chart.plot.Plot)var27, true);
//     org.jfree.chart.title.Title var31 = null;
//     var30.removeSubtitle(var31);
//     org.jfree.chart.plot.Plot var33 = var30.getPlot();
//     org.jfree.chart.title.TextTitle var34 = var30.getTitle();
//     var34.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.lang.Object var40 = var34.clone();
//     org.jfree.chart.util.VerticalAlignment var41 = var34.getVerticalAlignment();
//     var13.setVerticalAlignment(var41);
//     
//     // Checks the contract:  equals-hashcode on var6 and var27
//     assertTrue("Contract failed: equals-hashcode on var6 and var27", var6.equals(var27) ? var6.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var6
//     assertTrue("Contract failed: equals-hashcode on var27 and var6", var27.equals(var6) ? var27.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var30
//     assertTrue("Contract failed: equals-hashcode on var9 and var30", var9.equals(var30) ? var9.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var9
//     assertTrue("Contract failed: equals-hashcode on var30 and var9", var30.equals(var9) ? var30.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var33
//     assertTrue("Contract failed: equals-hashcode on var12 and var33", var12.equals(var33) ? var12.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var12
//     assertTrue("Contract failed: equals-hashcode on var33 and var12", var33.equals(var12) ? var33.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test231"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("PieSection: -10, 0(1)");
    boolean var2 = var1.getAutoRangeIncludesZero();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    java.awt.Paint var13 = var12.getDomainCrosshairPaint();
    var7.setBackgroundPaint(var13);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var7.zoomDomainAxes((-1.0d), var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var19};
    var7.setDomainAxes(var20);
    var7.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.RectangleEdge var25 = var7.getRangeAxisEdge(10);
    org.jfree.chart.util.RectangleInsets var26 = var7.getAxisOffset();
    java.lang.String var27 = var26.toString();
    double var29 = var26.extendWidth(0.0d);
    double var31 = var26.calculateTopOutset(0.0d);
    boolean var32 = var1.equals((java.lang.Object)var26);
    boolean var33 = var1.getAutoRangeStickyZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"+ "'", var27.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test232"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    var10.configureDomainAxes();
    org.jfree.chart.axis.AxisSpace var15 = var10.getFixedDomainAxisSpace();
    var10.setForegroundAlpha(0.0f);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    var23.setForegroundAlpha(0.0f);
    float var26 = var23.getBackgroundImageAlpha();
    boolean var27 = var23.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var28 = var23.getRangeAxisEdge();
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
    java.awt.Paint var30 = var23.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var34 = var32.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var35 = var32.getLowerMargin();
    var32.setCategoryLabelPositionOffset(1);
    double var38 = var32.getUpperMargin();
    java.awt.Stroke var39 = var32.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(100.0d, var30, var39);
    java.awt.Stroke var41 = var40.getStroke();
    var10.setRangeCrosshairStroke(var41);
    org.jfree.chart.plot.DrawingSupplier var43 = var10.getDrawingSupplier();
    var10.clearDomainMarkers(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test233"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    var4.mapDatasetToRangeAxis(0, 10);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    var15.setForegroundAlpha(0.0f);
    float var18 = var15.getBackgroundImageAlpha();
    org.jfree.chart.plot.Plot var19 = var15.getRootPlot();
    org.jfree.chart.axis.AxisSpace var20 = var15.getFixedRangeAxisSpace();
    java.awt.Paint var21 = var15.getNoDataMessagePaint();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    java.awt.Paint var33 = var32.getDomainCrosshairPaint();
    var27.setBackgroundPaint(var33);
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    java.awt.geom.Point2D var37 = null;
    var27.zoomDomainAxes((-1.0d), var36, var37);
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.axis.ValueAxis[] var40 = new org.jfree.chart.axis.ValueAxis[] { var39};
    var27.setDomainAxes(var40);
    org.jfree.chart.axis.AxisLocation var43 = var27.getDomainAxisLocation(0);
    var15.setDomainAxisLocation(1, var43);
    var4.setRangeAxisLocation(100, var43, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test234"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test235"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var4 = var1.getLowerMargin();
    java.lang.Object var5 = var1.clone();
    var1.setCategoryLabelPositionOffset(100);
    java.awt.Paint var8 = var1.getLabelPaint();
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    var13.setForegroundAlpha(0.0f);
    var13.mapDatasetToRangeAxis(0, 10);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var13.getRangeAxisIndex(var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    int var22 = var13.getRangeAxisIndex(var21);
    var13.zoom(108.0d);
    org.jfree.chart.axis.ValueAxis var25 = null;
    var13.setDomainAxis(var25);
    java.awt.Stroke var27 = var13.getRangeZeroBaselineStroke();
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    org.jfree.chart.axis.ValueAxis var33 = null;
    int var34 = var32.getDomainAxisIndex(var33);
    org.jfree.chart.util.RectangleInsets var35 = var32.getAxisOffset();
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder(var8, var27, var35);
    java.awt.Paint var37 = var36.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test236"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setForegroundAlpha(0.0f);
    float var7 = var4.getBackgroundImageAlpha();
    boolean var8 = var4.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    org.jfree.chart.plot.PlotOrientation var10 = var4.getOrientation();
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var13 = var12.isVerticalTickLabels();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.axis.TickUnitSource var16 = null;
    var12.setStandardTickUnits(var16);
    var12.setRangeAboutValue(9.0d, 10.0d);
    java.text.DateFormat var21 = null;
    var12.setDateFormatOverride(var21);
    java.awt.Shape var23 = var12.getDownArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test237"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 100.0f, 1.0f);
    int var4 = var3.getRed();
    java.awt.Color var5 = var3.darker();
    java.awt.Font var7 = null;
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    java.awt.Paint var13 = var12.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, true);
    org.jfree.chart.title.Title var16 = null;
    var15.removeSubtitle(var16);
    org.jfree.chart.plot.Plot var18 = var15.getPlot();
    org.jfree.chart.title.TextTitle var19 = var15.getTitle();
    var19.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.awt.geom.Rectangle2D var25 = var19.getBounds();
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.ValueAxis var31 = null;
    int var32 = var30.getDomainAxisIndex(var31);
    var30.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var35 = var30.getRangeAxisEdge();
    double var36 = org.jfree.chart.util.RectangleEdge.coordinate(var25, var35);
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.entity.PieSectionEntity var43 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var25, var37, (-10), (-1), (java.lang.Comparable)1, " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "org.jfree.chart.event.ChartChangeEvent[source= version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!]");
    java.lang.String var44 = var43.getShapeCoords();
    boolean var45 = var5.equals((java.lang.Object)var43);
    java.lang.String var46 = var43.getShapeCoords();
    var43.setPieIndex(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "0,0,1,1"+ "'", var44.equals("0,0,1,1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "0,0,1,1"+ "'", var46.equals("0,0,1,1"));

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test238"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes(100.0d, var7, var8, false);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var13, true);
    var4.clearDomainMarkers();
    org.jfree.data.general.DatasetGroup var17 = var4.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test239"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge();
    var4.setNoDataMessage("");
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.FlowArrangement var22 = new org.jfree.chart.block.FlowArrangement(var18, var19, 100.0d, 10.0d);
    org.jfree.chart.block.BlockContainer var23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var22);
    boolean var24 = var23.isEmpty();
    java.awt.Graphics2D var25 = null;
    org.jfree.data.Range var27 = null;
    org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 100.0d);
    org.jfree.data.Range var30 = null;
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(var30, 100.0d);
    org.jfree.chart.block.RectangleConstraint var33 = var32.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var35 = var32.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var36 = var35.getWidthConstraintType();
    java.lang.String var37 = var36.toString();
    org.jfree.data.Range var39 = null;
    org.jfree.data.Range var41 = org.jfree.data.Range.expandToInclude(var39, 100.0d);
    org.jfree.data.Range var42 = null;
    org.jfree.data.Range var44 = org.jfree.data.Range.expandToInclude(var42, 100.0d);
    boolean var46 = var44.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint(var41, var44);
    org.jfree.data.Range var48 = null;
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint(var48, 100.0d);
    org.jfree.chart.block.RectangleConstraint var51 = var50.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var53 = var50.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var54 = var53.getWidthConstraintType();
    java.lang.String var55 = var54.toString();
    org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint(100.0d, var29, var36, (-1.0d), var41, var54);
    org.jfree.chart.util.Size2D var57 = var17.arrange(var23, var25, var56);
    org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.RectangleAnchor var62 = var61.getLabelAnchor();
    org.jfree.data.xy.XYDataset var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.axis.ValueAxis var65 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
    org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var63, var64, var65, var66);
    org.jfree.data.xy.XYDataset var68 = null;
    org.jfree.chart.axis.ValueAxis var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
    org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var68, var69, var70, var71);
    java.awt.Paint var73 = var72.getDomainCrosshairPaint();
    var67.setBackgroundPaint(var73);
    org.jfree.chart.plot.PlotRenderingInfo var76 = null;
    java.awt.geom.Point2D var77 = null;
    var67.zoomDomainAxes((-1.0d), var76, var77);
    org.jfree.chart.axis.ValueAxis var79 = null;
    org.jfree.chart.axis.ValueAxis[] var80 = new org.jfree.chart.axis.ValueAxis[] { var79};
    var67.setDomainAxes(var80);
    var67.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var84 = var67.getDomainAxisLocation((-65536));
    org.jfree.chart.plot.PlotOrientation var85 = var67.getOrientation();
    boolean var86 = var62.equals((java.lang.Object)var67);
    java.awt.geom.Rectangle2D var87 = org.jfree.chart.util.RectangleAnchor.createRectangle(var57, 108.0d, 100.0d, var62);
    org.jfree.chart.plot.PlotRenderingInfo var89 = null;
    org.jfree.chart.plot.CrosshairState var90 = null;
    boolean var91 = var4.render(var12, var87, (-65536), var89, var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var37.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var55.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test240"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(1, var25);
    java.lang.String var27 = var10.getPlotType();
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var29);
    java.awt.Paint var31 = var10.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Category Plot"+ "'", var27.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test241"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var1.setTickUnit(var3);
    java.awt.Paint var5 = var1.getAxisLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test242"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var6 = var4.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var1.setTickMarkPaint(var6);
    var1.setNegativeArrowVisible(false);
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 100.0d);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    boolean var18 = var16.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var13, var16);
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(100.0d, var16);
    var1.setRange(var16, true, false);
    double var24 = var1.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test243"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    org.jfree.chart.title.TextTitle var13 = var9.getTitle();
    var9.fireChartChanged();
    org.jfree.chart.event.ChartProgressListener var15 = null;
    var9.addProgressListener(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test244"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     java.awt.Paint var7 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.title.Title var10 = null;
//     var9.removeSubtitle(var10);
//     org.jfree.chart.event.ChartProgressListener var12 = null;
//     var9.removeProgressListener(var12);
//     var9.clearSubtitles();
//     boolean var15 = var9.isBorderVisible();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     var20.setForegroundAlpha(0.0f);
//     float var23 = var20.getBackgroundImageAlpha();
//     boolean var24 = var20.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var25 = var20.getRangeAxisEdge();
//     java.lang.Object var26 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
//     java.awt.Paint var27 = var20.getOutlinePaint();
//     java.awt.Stroke var28 = var20.getRangeZeroBaselineStroke();
//     var9.setBorderStroke(var28);
//     java.awt.Graphics2D var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
//     java.awt.Paint var42 = var41.getDomainCrosshairPaint();
//     var36.setBackgroundPaint(var42);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Point2D var46 = null;
//     var36.zoomDomainAxes((-1.0d), var45, var46);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis[] var49 = new org.jfree.chart.axis.ValueAxis[] { var48};
//     var36.setDomainAxes(var49);
//     org.jfree.chart.axis.AxisLocation var52 = var36.getDomainAxisLocation(0);
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var55, var56, var57, var58);
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     int var61 = var59.getDomainAxisIndex(var60);
//     var59.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var64 = var59.getRangeAxisEdge();
//     java.awt.Paint var65 = var59.getRangeTickBandPaint();
//     var59.configureDomainAxes();
//     java.awt.geom.Point2D var67 = var59.getQuadrantOrigin();
//     var36.zoomDomainAxes(108.0d, var54, var67, false);
//     org.jfree.chart.ChartRenderingInfo var70 = null;
//     var9.draw(var30, var31, var67, var70);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test245"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var13 = var12.isVisible();
    java.util.List var14 = var10.getCategoriesForAxis(var12);
    org.jfree.chart.util.RectangleEdge var16 = var10.getDomainAxisEdge((-10));
    org.jfree.chart.util.Layer var18 = null;
    java.util.Collection var19 = var10.getDomainMarkers((-10), var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test246"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "hi!", "hi!", "hi!");
    boolean var9 = var7.equals((java.lang.Object)'a');
    org.jfree.chart.ui.Library[] var10 = var7.getOptionalLibraries();
    java.awt.Font var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    java.awt.Paint var18 = var17.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var12, (org.jfree.chart.plot.Plot)var17, true);
    org.jfree.chart.title.Title var21 = null;
    var20.removeSubtitle(var21);
    org.jfree.chart.event.ChartProgressListener var23 = null;
    var20.removeProgressListener(var23);
    var20.clearSubtitles();
    boolean var26 = var20.isBorderVisible();
    org.jfree.chart.event.ChartChangeEventType var27 = null;
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var20, var27);
    var20.clearSubtitles();
    org.jfree.chart.plot.XYPlot var30 = var20.getXYPlot();
    java.awt.Paint var31 = var20.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var32 = var20.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test247"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.chart.LegendItemCollection var13 = var10.getFixedLegendItems();
    var10.configureDomainAxes();
    org.jfree.chart.axis.AxisSpace var15 = var10.getFixedDomainAxisSpace();
    var10.setForegroundAlpha(0.0f);
    org.jfree.chart.util.RectangleEdge var18 = var10.getRangeAxisEdge();
    boolean var19 = var10.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test248"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    org.jfree.chart.axis.AxisLocation var20 = var4.getDomainAxisLocation(0);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    org.jfree.chart.axis.ValueAxis var28 = null;
    int var29 = var27.getDomainAxisIndex(var28);
    var27.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var32 = var27.getRangeAxisEdge();
    java.awt.Paint var33 = var27.getRangeTickBandPaint();
    var27.configureDomainAxes();
    java.awt.geom.Point2D var35 = var27.getQuadrantOrigin();
    var4.zoomDomainAxes(108.0d, var22, var35, false);
    var4.setRangeZeroBaselineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test249"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    java.awt.Paint var10 = var9.getDomainCrosshairPaint();
    var4.setBackgroundPaint(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes((-1.0d), var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var4.setDomainAxes(var17);
    org.jfree.chart.axis.AxisLocation var20 = var4.getDomainAxisLocation(0);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    org.jfree.chart.axis.ValueAxis var28 = null;
    int var29 = var27.getDomainAxisIndex(var28);
    var27.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var32 = var27.getRangeAxisEdge();
    java.awt.Paint var33 = var27.getRangeTickBandPaint();
    var27.configureDomainAxes();
    java.awt.geom.Point2D var35 = var27.getQuadrantOrigin();
    var4.zoomDomainAxes(0.0d, var22, var35);
    org.jfree.chart.util.RectangleInsets var37 = var4.getInsets();
    org.jfree.data.xy.XYDataset var39 = var4.getDataset(0);
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRenderer((-10), var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test250"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    org.jfree.chart.title.TextTitle var13 = var9.getTitle();
    java.awt.Image var14 = var9.getBackgroundImage();
    java.awt.RenderingHints var15 = var9.getRenderingHints();
    var9.setAntiAlias(true);
    org.jfree.chart.ChartRenderingInfo var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var23 = var9.createBufferedImage(10, 0, 100.0d, (-1.0d), var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test251"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = var2.getTickLabelFont((java.lang.Comparable)(byte)100);
    double var5 = var2.getLowerMargin();
    var2.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var8, var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var10.getRendererForDataset(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var18.getDomainAxisIndex(var19);
    var18.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var23 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(1, var25);
    java.lang.String var27 = var10.getPlotType();
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var29);
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var34 = var32.getTickLabelFont((java.lang.Comparable)(byte)100);
    var32.setLabelURL("");
    org.jfree.chart.util.RectangleInsets var37 = var32.getTickLabelInsets();
    double var39 = var37.calculateBottomOutset((-1.0d));
    var10.setAxisOffset(var37);
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
    org.jfree.data.xy.XYDataset var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
    org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
    java.awt.Paint var53 = var52.getDomainCrosshairPaint();
    var47.setBackgroundPaint(var53);
    float var55 = var47.getBackgroundImageAlpha();
    var47.setBackgroundImageAlignment(100);
    java.awt.geom.Point2D var58 = var47.getQuadrantOrigin();
    var10.zoomRangeAxes(1.0d, var42, var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Category Plot"+ "'", var27.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test252"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var2 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var1.setTickUnit(var3, true, true);
    boolean var7 = var1.isInverted();
    boolean var8 = var1.isAutoRange();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    var10.configure();
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 100.0d);
    org.jfree.data.Range var16 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var16, 100.0d);
    org.jfree.chart.block.RectangleConstraint var19 = var18.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var21 = var18.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var22 = var21.getWidthConstraintType();
    java.lang.String var23 = var22.toString();
    org.jfree.data.Range var25 = null;
    org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, 100.0d);
    org.jfree.data.Range var28 = null;
    org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 100.0d);
    boolean var32 = var30.contains((-1.0d));
    org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(var27, var30);
    org.jfree.data.Range var34 = null;
    org.jfree.chart.block.RectangleConstraint var36 = new org.jfree.chart.block.RectangleConstraint(var34, 100.0d);
    org.jfree.chart.block.RectangleConstraint var37 = var36.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var39 = var36.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var40 = var39.getWidthConstraintType();
    java.lang.String var41 = var40.toString();
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(100.0d, var15, var22, (-1.0d), var27, var40);
    var10.setRange(var15, false, true);
    var1.setRange(var15, true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var23.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var41.equals("RectangleConstraintType.RANGE"));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test253"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var9.removeProgressListener(var12);
    var9.clearSubtitles();
    org.jfree.chart.title.TextTitle var15 = var9.getTitle();
    org.jfree.chart.util.RectangleInsets var16 = var15.getPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test254"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("");
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     var6.setForegroundAlpha(0.0f);
//     float var9 = var6.getBackgroundImageAlpha();
//     org.jfree.chart.plot.Plot var10 = var6.getRootPlot();
//     var6.setDomainZeroBaselineVisible(true);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     int var19 = var17.getDomainAxisIndex(var18);
//     var17.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var22 = var17.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisLocation var24 = var17.getRangeAxisLocation((-1));
//     var6.setRangeAxisLocation(var24);
//     var6.mapDatasetToRangeAxis(100, (-65536));
//     boolean var29 = var1.equals((java.lang.Object)(-65536));
//     org.jfree.chart.text.TextFragment var30 = var1.getLastTextFragment();
//     java.awt.Font var33 = null;
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     java.awt.Paint var39 = var38.getDomainCrosshairPaint();
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("", var33, (org.jfree.chart.plot.Plot)var38, true);
//     org.jfree.chart.title.Title var42 = null;
//     var41.removeSubtitle(var42);
//     org.jfree.chart.plot.Plot var44 = var41.getPlot();
//     org.jfree.chart.title.TextTitle var45 = var41.getTitle();
//     var45.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
//     java.awt.geom.Rectangle2D var51 = var45.getBounds();
//     var45.setToolTipText("hi!");
//     org.jfree.chart.block.BlockFrame var54 = var45.getFrame();
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var57 = var56.getCategoryLabelPositions();
//     java.awt.Font var58 = var56.getTickLabelFont();
//     var45.setFont(var58);
//     org.jfree.chart.text.TextFragment var60 = new org.jfree.chart.text.TextFragment("", var58);
//     var1.removeFragment(var60);
//     java.awt.Graphics2D var62 = null;
//     org.jfree.chart.text.TextAnchor var63 = null;
//     float var64 = var60.calculateBaselineOffset(var62, var63);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test255"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.Paint var7 = var6.getDomainCrosshairPaint();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.Title var10 = null;
    var9.removeSubtitle(var10);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    org.jfree.chart.title.TextTitle var13 = var9.getTitle();
    var13.setMargin(100.0d, 10.0d, 10.0d, 100.0d);
    java.lang.Object var19 = var13.clone();
    org.jfree.chart.util.HorizontalAlignment var20 = var13.getTextAlignment();
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 0.0d, 10.0d);
    var24.clear();
    boolean var27 = var24.equals((java.lang.Object)0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test256"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var3 = var2.getCategoryLabelPositions();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
    boolean var6 = var5.isVerticalTickLabels();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var10 = var8.getTickLabelPaint((java.lang.Comparable)(-1.0f));
    var5.setTickMarkPaint(var10);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var5, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    java.awt.Paint var26 = var25.getDomainCrosshairPaint();
    var20.setBackgroundPaint(var26);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var20.zoomDomainAxes((-1.0d), var29, var30);
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.axis.ValueAxis[] var33 = new org.jfree.chart.axis.ValueAxis[] { var32};
    var20.setDomainAxes(var33);
    var20.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var37 = var20.getDomainAxisLocation((-65536));
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
    java.awt.Paint var43 = var42.getDomainCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var42.zoomDomainAxes(100.0d, var45, var46, false);
    var42.setRangeCrosshairValue(1.0d, true);
    org.jfree.chart.plot.PlotOrientation var52 = var42.getOrientation();
    org.jfree.chart.util.RectangleEdge var53 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var37, var52);
    var15.setDomainAxisLocation(var37, false);
    org.jfree.data.category.CategoryDataset var57 = null;
    var15.setDataset(0, var57);
    org.jfree.chart.event.PlotChangeEvent var59 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var15);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var62.setLabelAngle(10.0d);
    var15.setDomainAxis(253, var62, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

}
