
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", var1, 1.0f, 1.0f, var4, 0.0d, var6);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", var1);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0d, 0.0f, 0.0f);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)10.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (-1.0d)};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)(-1)};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    org.jfree.chart.util.RectangleAnchor var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setLegendItemGraphicAnchor(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.DefaultDrawingSupplier var2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var3 = var2.getNextFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("hi!", var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("ThreadContext", var1, var2);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    double var6 = var5.getContentXOffset();
    java.awt.Paint var7 = var5.getItemPaint();
    java.awt.Font var8 = var5.getItemFont();
    org.jfree.chart.util.RectangleInsets var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setItemLabelPadding(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 4.0d);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.event.MarkerChangeEvent var2 = null;
    var1.notifyListeners(var2);
    org.jfree.chart.util.LengthAdjustmentType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffsetType(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
//     java.awt.Paint var5 = var4.getPaint();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     var4.draw(var6, var7);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    boolean var2 = var1.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var1.setURLGenerator(var3);
    org.jfree.chart.event.PlotChangeListener var5 = null;
    var1.addChangeListener(var5);
    java.awt.Shape var7 = var1.getLegendItemShape();
    java.awt.Paint var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseSectionOutlinePaint(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     java.awt.Stroke var3 = var1.getLabelOutlineStroke();
//     java.awt.Paint var4 = var1.getSeparatorPaint();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
//     java.awt.Stroke var8 = var6.getLabelOutlineStroke();
//     var1.setLabelLinkStroke(var8);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getNoDataMessageFont();
//     org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
//     java.awt.Paint var9 = var8.getPaint();
//     org.jfree.chart.text.TextMeasurer var11 = null;
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("ThreadContext", var3, var9, 100.0f, var11);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     org.jfree.chart.plot.PlotState var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var1.draw(var2, var3, var4, var5, var6);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     var5.draw(var6, var7);
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     java.util.List var4 = null;
//     var3.setSubtitles(var4);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, (-1.0d), false);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    double var5 = var4.getLabelLinkMargin();
    var4.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    double var9 = var8.getContentXOffset();
    java.awt.Paint var10 = var8.getItemPaint();
    java.awt.Font var11 = var8.getItemFont();
    var2.setLabelFont(var11);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var11);
    org.jfree.chart.util.RectangleInsets var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setMargin(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = var5.arrange(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var5.draw(var10, var11);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var5.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
    java.awt.Paint var9 = var5.getBackgroundPaint();
    var3.addSubtitle((org.jfree.chart.title.Title)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var11 = var3.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "", var3);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    double var6 = var5.getContentXOffset();
    java.awt.Paint var7 = var5.getItemPaint();
    org.jfree.chart.util.RectangleInsets var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setLegendItemGraphicPadding(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    float var5 = var1.getBackgroundAlpha();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    boolean var8 = var7.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var9 = null;
    var7.setURLGenerator(var9);
    boolean var11 = var1.equals((java.lang.Object)var7);
    boolean var12 = var7.getLabelLinksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     double var13 = var12.getContentXOffset();
//     java.awt.Paint var14 = var12.getItemPaint();
//     java.awt.Font var15 = var12.getItemFont();
//     var6.setLabelFont(var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
//     var3.removeSubtitle((org.jfree.chart.title.Title)var17);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     var3.draw(var19, var20, var21);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.awt.image.ColorModel var4 = null;
    java.awt.Rectangle var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    java.awt.geom.AffineTransform var7 = null;
    java.awt.RenderingHints var8 = null;
    java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.axis.CategoryAnchor var1 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var0.getCategoryJava2DCoordinate(var1, (-1), 1, var4, var5);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    org.jfree.chart.axis.AxisLocation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(0, var3, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     boolean var2 = var1.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var1.setURLGenerator(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var1.addChangeListener(var5);
//     java.awt.Shape var7 = var1.getLegendItemShape();
//     java.awt.Paint var8 = var1.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     boolean var11 = var10.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var12 = null;
//     var10.setURLGenerator(var12);
//     org.jfree.chart.event.PlotChangeListener var14 = null;
//     var10.addChangeListener(var14);
//     java.awt.Shape var16 = var10.getLegendItemShape();
//     java.awt.Stroke var17 = var10.getBaseSectionOutlineStroke();
//     var1.setBaseSectionOutlineStroke(var17);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    java.awt.Paint var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePaint(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     java.lang.Class var5 = null;
//     java.util.EventListener[] var6 = var1.getListeners(var5);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Pie 3D Plot", var3);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 10);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
//     java.lang.String var2 = var0.getPlotType();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var0.drawBackground(var3, var4);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     org.jfree.chart.plot.PlotState var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     var1.draw(var3, var4, var5, var6, var7);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    java.awt.Stroke var3 = var1.getLabelOutlineStroke();
    var1.setSectionOutlinesVisible(true);
    double var6 = var1.getLabelGap();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025d);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var5.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
    java.awt.Paint var9 = var5.getBackgroundPaint();
    var3.addSubtitle((org.jfree.chart.title.Title)var5);
    java.awt.Paint var11 = var3.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var3.removeSubtitle((org.jfree.chart.title.Title)var13);
    org.jfree.chart.event.ChartChangeListener var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.removeChangeListener(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    double var5 = var4.getLabelLinkMargin();
    var4.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    double var9 = var8.getContentXOffset();
    java.awt.Paint var10 = var8.getItemPaint();
    java.awt.Font var11 = var8.getItemFont();
    var1.setTickLabelFont((java.lang.Comparable)(-1.0d), var11);
    org.jfree.chart.axis.CategoryLabelPositions var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    double var6 = var5.getContentXOffset();
    java.awt.Paint var7 = var5.getItemPaint();
    java.awt.Font var8 = var5.getItemFont();
    org.jfree.chart.util.VerticalAlignment var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setVerticalAlignment(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     java.awt.RenderingHints var11 = null;
//     var3.setRenderingHints(var11);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    float[] var7 = new float[] { 1.0f, 10.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var8 = var3.getRGBComponents(var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    java.lang.String var2 = var0.getPlotType();
    boolean var3 = var0.getDrawSharedDomainAxis();
    var0.setRangeCrosshairValue(100.0d, true);
    java.awt.Paint var7 = var0.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, (-1.0d), 4.0d, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 0.0d);
    org.jfree.data.Range var3 = var2.getHeightRange();
    org.jfree.data.Range var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var5 = var2.toRangeWidth(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Pie Plot", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    java.awt.Color var1 = java.awt.Color.getColor("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    boolean var2 = var1.isSubplot();
    boolean var4 = var1.equals((java.lang.Object)"hi!");
    double var5 = var1.getOuterSeparatorExtension();
    var1.zoom(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", var1, 4.0d, 1.0f, 0.0f);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = var4.get(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    int var2 = var0.getBackgroundImageAlignment();
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    double var5 = var4.getLowerMargin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-16777216), (org.jfree.chart.axis.CategoryAxis)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     java.awt.Stroke var3 = var1.getLabelOutlineStroke();
//     var1.setSectionOutlinesVisible(true);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var7);
//     java.awt.Stroke var9 = var7.getLabelOutlineStroke();
//     var1.setOutlineStroke(var9);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getLowerMargin();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var7 = var6.getRangeCrosshairStroke();
//     java.lang.String var8 = var6.getPlotType();
//     boolean var9 = var6.getDrawSharedDomainAxis();
//     var6.mapDatasetToRangeAxis(0, 100);
//     org.jfree.chart.util.RectangleEdge var14 = var6.getDomainAxisEdge(10);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.chart.axis.AxisState var16 = var0.draw(var2, (-1.0d), var4, var5, var14, var15);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", var1, (-1.0d), 1.0f, (-1.0f));
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     var0.setDepthFactor((-1.0d));
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     org.jfree.chart.plot.PlotState var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     var0.draw(var3, var4, var5, var6, var7);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    java.lang.String var2 = var0.getPlotType();
    boolean var3 = var0.getDrawSharedDomainAxis();
    var0.setRangeCrosshairValue(100.0d, true);
    org.jfree.chart.plot.CategoryMarker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var1.setValue(1.0d);
    org.jfree.chart.util.LengthAdjustmentType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffsetType(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     double var6 = var5.getLabelLinkMargin();
//     var5.setLabelGap((-1.0d));
//     float var9 = var5.getBackgroundAlpha();
//     java.awt.Paint var10 = var5.getLabelBackgroundPaint();
//     var3.setRadiusGridlinePaint(var10);
//     java.awt.geom.Rectangle2D var14 = null;
//     java.awt.Point var15 = var3.translateValueThetaRadiusToJava2D(10.0d, 0.025d, var14);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("ThreadContext");
//     java.awt.Paint var2 = var1.getPaint();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var1.calculateDimensions(var3);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     double var6 = var5.getLabelLinkMargin();
//     var5.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     org.jfree.chart.event.TitleChangeListener var10 = null;
//     var9.addChangeListener(var10);
//     org.jfree.chart.block.BlockContainer var12 = null;
//     var9.setWrapper(var12);
//     var3.addSubtitle((org.jfree.chart.title.Title)var9);
//     java.awt.RenderingHints var15 = null;
//     var3.setRenderingHints(var15);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D();
    double var16 = var15.getLowerMargin();
    var0.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var15);
    var15.setUpperMargin(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(100.0d, 0.025d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)255);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     double var8 = var5.getContentYOffset();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     double var11 = var10.getLabelLinkMargin();
//     var10.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
//     double var15 = var14.getContentXOffset();
//     java.awt.Paint var16 = var14.getItemPaint();
//     java.awt.Font var17 = var14.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var18 = var14.getLegendItemGraphicAnchor();
//     var5.setLegendItemGraphicLocation(var18);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     double var8 = var5.getContentYOffset();
//     org.jfree.chart.util.RectangleAnchor var9 = var5.getLegendItemGraphicLocation();
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var5.draw(var10, var11);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    org.jfree.chart.event.TitleChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.block.BlockContainer var8 = null;
    var5.setWrapper(var8);
    org.jfree.chart.util.RectangleInsets var10 = var5.getPadding();
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var12 = var10.createOutsetRectangle(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var1);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var2 = var1.getRange();
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var3, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { "hi!"};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { "Category Plot"};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    java.awt.Color var1 = java.awt.Color.getColor("Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     double var6 = var5.getLabelLinkMargin();
//     var5.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     double var10 = var9.getContentXOffset();
//     java.awt.Paint var11 = var9.getItemPaint();
//     java.awt.Font var12 = var9.getItemFont();
//     var2.setTickLabelFont((java.lang.Comparable)(-1.0d), var12);
//     java.awt.Color var16 = java.awt.Color.getColor("Pie 3D Plot", 255);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.text.G2TextMeasurer var19 = new org.jfree.chart.text.G2TextMeasurer(var18);
//     org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("Pie Plot", var12, (java.awt.Paint)var16, 0.0f, (org.jfree.chart.text.TextMeasurer)var19);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    java.awt.Stroke var3 = var1.getLabelOutlineStroke();
    java.awt.Paint var4 = var1.getSeparatorPaint();
    boolean var5 = var1.isCircular();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var10 = var9.getGreen();
    var1.setSeparatorPaint((java.awt.Paint)var9);
    double var12 = var1.getOuterSeparatorExtension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     float var5 = var1.getBackgroundAlpha();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     boolean var8 = var7.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var9 = null;
//     var7.setURLGenerator(var9);
//     boolean var11 = var1.equals((java.lang.Object)var7);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var7.drawBackground(var12, var13);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     double var6 = var5.getLabelLinkMargin();
//     var5.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     double var10 = var9.getContentXOffset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.block.RectangleConstraint var12 = null;
//     org.jfree.chart.util.Size2D var13 = var9.arrange(var11, var12);
//     org.jfree.chart.util.RectangleEdge var14 = var9.getLegendItemGraphicEdge();
//     double var15 = var1.lengthToJava2D(0.2d, var3, var14);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = null;
//     var3.setDataset(var4);
//     java.awt.Paint var6 = var3.getRadiusGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     var3.zoomRangeAxes(0.0d, 0.025d, var9, var10);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("Category Plot");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     boolean var2 = var1.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var1.setURLGenerator(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var1.addChangeListener(var5);
//     java.awt.Shape var7 = var1.getLegendItemShape();
//     org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var7, "");
//     java.lang.String var10 = var9.getToolTipText();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     boolean var13 = var12.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var14 = null;
//     var12.setURLGenerator(var14);
//     org.jfree.chart.event.PlotChangeListener var16 = null;
//     var12.addChangeListener(var16);
//     java.awt.Shape var18 = var12.getLegendItemShape();
//     org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity(var18, "");
//     var9.setArea(var18);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    double var5 = var4.getLabelLinkMargin();
    var4.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    double var9 = var8.getContentXOffset();
    java.awt.Paint var10 = var8.getItemPaint();
    java.awt.Font var11 = var8.getItemFont();
    var2.setLabelFont(var11);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var11);
    java.lang.String var14 = var13.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     double var6 = var5.getLabelLinkMargin();
//     var5.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     org.jfree.chart.event.TitleChangeListener var10 = null;
//     var9.addChangeListener(var10);
//     org.jfree.chart.block.BlockContainer var12 = null;
//     var9.setWrapper(var12);
//     var3.addSubtitle((org.jfree.chart.title.Title)var9);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     boolean var17 = var16.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var16.setURLGenerator(var18);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var16.addChangeListener(var20);
//     java.awt.Shape var22 = var16.getLegendItemShape();
//     java.awt.Paint var23 = var16.getLabelShadowPaint();
//     var3.setBorderPaint(var23);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.axis.CategoryLabelPositions var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     java.awt.Stroke var5 = var1.getLabelOutlineStroke();
//     java.awt.Stroke var6 = var1.getLabelLinkStroke();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     java.awt.Font var9 = var8.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     double var13 = var12.getLabelLinkMargin();
//     var12.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
//     org.jfree.chart.event.TitleChangeListener var17 = null;
//     var16.addChangeListener(var17);
//     org.jfree.chart.block.BlockContainer var19 = null;
//     var16.setWrapper(var19);
//     var10.addSubtitle((org.jfree.chart.title.Title)var16);
//     org.jfree.chart.event.ChartChangeEvent var22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var10);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    org.jfree.chart.event.TitleChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setHorizontalAlignment(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge(1);
    org.jfree.chart.axis.CategoryAxis var4 = var0.getDomainAxis();
    int var5 = var0.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", var1, 0.2d, 10.0f, 10.0f);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var8.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var11 = var8.getFrame();
//     var5.setFrame(var11);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     double var15 = var14.getLabelLinkMargin();
//     var14.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getPadding();
//     double var20 = var19.getRight();
//     var5.setPadding(var19);
//     
//     // Checks the contract:  equals-hashcode on var1 and var14
//     assertTrue("Contract failed: equals-hashcode on var1 and var14", var1.equals(var14) ? var1.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var1
//     assertTrue("Contract failed: equals-hashcode on var14 and var1", var14.equals(var1) ? var14.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    var1.setInnerSeparatorExtension(0.025d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelDistributor(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
    double var6 = var5.getLabelLinkMargin();
    var5.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var10 = var9.getContentXOffset();
    java.awt.Paint var11 = var9.getItemPaint();
    java.awt.Font var12 = var9.getItemFont();
    var2.setTickLabelFont((java.lang.Comparable)(-1.0d), var12);
    java.awt.Paint var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("Pie 3D Plot", var12, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
    java.awt.Stroke var5 = var3.getLabelOutlineStroke();
    var0.setRangeCrosshairStroke(var5);
    org.jfree.chart.block.Arrangement var7 = null;
    org.jfree.chart.block.Arrangement var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     double var23 = var22.getContentXOffset();
//     java.awt.Paint var24 = var22.getItemPaint();
//     java.awt.Font var25 = var22.getItemFont();
//     var16.setLabelFont(var25);
//     org.jfree.chart.util.Layer var27 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
//     java.awt.Paint var29 = var16.getPaint();
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     boolean var34 = var31.equals((java.lang.Object)var33);
//     org.jfree.chart.text.TextAnchor var35 = var31.getLabelTextAnchor();
//     var16.setLabelTextAnchor(var35);
//     
//     // Checks the contract:  equals-hashcode on var6 and var33
//     assertTrue("Contract failed: equals-hashcode on var6 and var33", var6.equals(var33) ? var6.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var6
//     assertTrue("Contract failed: equals-hashcode on var33 and var6", var33.equals(var6) ? var33.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     boolean var8 = var5.equals((java.lang.Object)var7);
//     org.jfree.chart.text.TextAnchor var9 = var5.getLabelTextAnchor();
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     boolean var15 = var12.equals((java.lang.Object)var14);
//     org.jfree.chart.text.TextAnchor var16 = var12.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", var1, (-1.0f), 0.0f, var9, 10.0d, var16);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     boolean var15 = var12.equals((java.lang.Object)var14);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
//     double var18 = var17.getLabelLinkMargin();
//     var17.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     double var22 = var21.getContentXOffset();
//     java.awt.Paint var23 = var21.getItemPaint();
//     java.awt.Font var24 = var21.getItemFont();
//     var12.setLabelFont(var24);
//     java.awt.Paint var26 = var12.getLabelPaint();
//     var3.setBackgroundPaint(var26);
//     
//     // Checks the contract:  equals-hashcode on var1 and var14
//     assertTrue("Contract failed: equals-hashcode on var1 and var14", var1.equals(var14) ? var1.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var1
//     assertTrue("Contract failed: equals-hashcode on var14 and var1", var14.equals(var1) ? var14.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     java.awt.Paint var11 = var3.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var3.removeSubtitle((org.jfree.chart.title.Title)var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     org.jfree.data.general.DatasetChangeEvent var17 = null;
//     var16.datasetChanged(var17);
//     boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)var17);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     java.awt.Paint var11 = var3.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var3.removeSubtitle((org.jfree.chart.title.Title)var13);
//     org.jfree.chart.event.TitleChangeEvent var15 = null;
//     var3.titleChanged(var15);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.chart.axis.ValueAxis var5 = var3.getAxis();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     var3.zoomRangeAxes(0.0d, 1.0E-8d, var8, var9);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 0.0d);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeWidth(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     org.jfree.chart.event.PlotChangeEvent var3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     boolean var8 = var7.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var9 = null;
//     var7.setURLGenerator(var9);
//     org.jfree.chart.event.PlotChangeListener var11 = null;
//     var7.addChangeListener(var11);
//     java.awt.Paint var13 = var7.getBaseSectionOutlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.chart.plot.PiePlotState var16 = var1.initialise(var4, var5, (org.jfree.chart.plot.PiePlot)var7, (java.lang.Integer)10, var15);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.setVisible(false);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.axis.AxisState var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var10 = var7.getRangeAxisEdge(1);
//     java.util.List var11 = var1.refreshTicks(var4, var5, var6, var10);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getLowerMargin();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var0.getCategoryStart(100, 100, var4, var5);
//     org.jfree.chart.axis.CategoryAnchor var7 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var14 = var11.getRangeAxisEdge(1);
//     double var15 = var0.getCategoryJava2DCoordinate(var7, 0, 0, var10, var14);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Paint var7 = var5.getItemPaint();
//     java.awt.Font var8 = var5.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 0.2d, 0.025d);
//     org.jfree.chart.block.BlockContainer var14 = null;
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
//     double var19 = var18.getHeight();
//     org.jfree.chart.util.Size2D var20 = var13.arrange(var14, var15, var18);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     double var23 = var22.getContentXOffset();
//     java.awt.Paint var24 = var22.getItemPaint();
//     java.awt.Font var25 = var22.getItemFont();
//     var16.setLabelFont(var25);
//     org.jfree.chart.util.Layer var27 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
//     java.awt.Paint var29 = var16.getPaint();
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
//     boolean var32 = var31.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var33 = null;
//     var31.setURLGenerator(var33);
//     org.jfree.chart.event.PlotChangeListener var35 = null;
//     var31.addChangeListener(var35);
//     java.awt.Shape var37 = var31.getLegendItemShape();
//     java.awt.Stroke var38 = var31.getBaseSectionOutlineStroke();
//     var16.setOutlineStroke(var38);
//     
//     // Checks the contract:  equals-hashcode on var6 and var31
//     assertTrue("Contract failed: equals-hashcode on var6 and var31", var6.equals(var31) ? var6.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var6
//     assertTrue("Contract failed: equals-hashcode on var31 and var6", var31.equals(var6) ? var31.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     java.awt.Paint var11 = var3.getBackgroundPaint();
//     java.awt.Image var12 = null;
//     var3.setBackgroundImage(var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
//     java.awt.Font var18 = var17.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var21.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var24 = var21.getFrame();
//     java.awt.Paint var25 = var21.getBackgroundPaint();
//     var19.addSubtitle((org.jfree.chart.title.Title)var21);
//     java.awt.Paint var27 = var19.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var19.removeSubtitle((org.jfree.chart.title.Title)var29);
//     org.jfree.chart.event.ChartChangeEventType var31 = null;
//     org.jfree.chart.event.ChartChangeEvent var32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var19, var31);
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var34.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var37 = var34.getFrame();
//     java.awt.Paint var38 = var34.getBackgroundPaint();
//     var34.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var19.setTitle(var34);
//     java.awt.geom.Rectangle2D var45 = var34.getBounds();
//     org.jfree.chart.ChartRenderingInfo var46 = null;
//     var3.draw(var14, var45, var46);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     boolean var2 = var1.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var1.setURLGenerator(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var1.addChangeListener(var5);
//     java.awt.Shape var7 = var1.getLegendItemShape();
//     org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var7, "");
//     java.lang.String var10 = var9.getToolTipText();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     boolean var13 = var12.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var14 = null;
//     var12.setURLGenerator(var14);
//     org.jfree.chart.event.PlotChangeListener var16 = null;
//     var12.addChangeListener(var16);
//     java.awt.Shape var18 = var12.getLegendItemShape();
//     var9.setArea(var18);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.LegendItem var6 = null;
    var4.add(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("TextAnchor.CENTER", var1);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     double var6 = var5.getLabelLinkMargin();
//     var5.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     org.jfree.chart.event.TitleChangeListener var10 = null;
//     var9.addChangeListener(var10);
//     org.jfree.chart.block.BlockContainer var12 = null;
//     var9.setWrapper(var12);
//     var3.addSubtitle((org.jfree.chart.title.Title)var9);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var18);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var22.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var25 = var22.getFrame();
//     java.awt.Paint var26 = var22.getBackgroundPaint();
//     var20.addSubtitle((org.jfree.chart.title.Title)var22);
//     java.awt.Paint var28 = var20.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var20.removeSubtitle((org.jfree.chart.title.Title)var30);
//     org.jfree.chart.event.ChartChangeEventType var32 = null;
//     org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var20, var32);
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var35.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var38 = var35.getFrame();
//     java.awt.Paint var39 = var35.getBackgroundPaint();
//     var35.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var20.setTitle(var35);
//     java.awt.geom.Rectangle2D var46 = var35.getBounds();
//     var9.draw(var15, var46);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
//     java.lang.String var2 = var0.getPlotType();
//     boolean var3 = var0.getDrawSharedDomainAxis();
//     var0.mapDatasetToRangeAxis(0, 100);
//     org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(10);
//     org.jfree.chart.util.SortOrder var9 = var0.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     boolean var14 = var11.equals((java.lang.Object)var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     double var17 = var16.getLabelLinkMargin();
//     var16.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
//     double var21 = var20.getContentXOffset();
//     java.awt.Paint var22 = var20.getItemPaint();
//     java.awt.Font var23 = var20.getItemFont();
//     var11.setLabelFont(var23);
//     java.awt.Paint var25 = var11.getLabelPaint();
//     boolean var26 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var11);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var1.setMaximumCategoryLabelWidthRatio(0.0f);
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.AxisState var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     java.util.List var9 = var1.refreshTicks(var5, var6, var7, var8);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var11.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var14 = var11.getFrame();
//     java.awt.Paint var15 = var11.getBackgroundPaint();
//     var9.addSubtitle((org.jfree.chart.title.Title)var11);
//     java.awt.Paint var17 = var9.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var9.removeSubtitle((org.jfree.chart.title.Title)var19);
//     var9.setBackgroundImageAlignment(0);
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
//     double var25 = var24.getLabelLinkMargin();
//     var24.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
//     double var29 = var28.getContentXOffset();
//     java.awt.Paint var30 = var28.getItemPaint();
//     java.awt.Font var31 = var28.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var32 = var28.getHorizontalAlignment();
//     var9.addSubtitle((org.jfree.chart.title.Title)var28);
//     org.jfree.chart.util.RectangleAnchor var34 = var28.getLegendItemGraphicAnchor();
//     var5.setLegendItemGraphicLocation(var34);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var3.setAxis(var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var3.zoomRangeAxes(10.0d, var7, var8);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var8.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var11 = var8.getFrame();
//     java.awt.Paint var12 = var8.getBackgroundPaint();
//     var6.addSubtitle((org.jfree.chart.title.Title)var8);
//     java.awt.Paint var14 = var6.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var6.removeSubtitle((org.jfree.chart.title.Title)var16);
//     org.jfree.chart.event.ChartChangeEventType var18 = null;
//     org.jfree.chart.event.ChartChangeEvent var19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var6, var18);
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var21.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var24 = var21.getFrame();
//     java.awt.Paint var25 = var21.getBackgroundPaint();
//     var21.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var6.setTitle(var21);
//     java.awt.geom.Rectangle2D var32 = var21.getBounds();
//     java.lang.Object var34 = var0.draw(var1, var32, (java.lang.Object)10.0d);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     java.awt.Font var14 = var13.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var17.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var20 = var17.getFrame();
//     java.awt.Paint var21 = var17.getBackgroundPaint();
//     var15.addSubtitle((org.jfree.chart.title.Title)var17);
//     java.awt.Paint var23 = var15.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var15.removeSubtitle((org.jfree.chart.title.Title)var25);
//     org.jfree.chart.event.ChartChangeEventType var27 = null;
//     org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var15, var27);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var30.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var33 = var30.getFrame();
//     java.awt.Paint var34 = var30.getBackgroundPaint();
//     var30.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var15.setTitle(var30);
//     java.awt.geom.Rectangle2D var41 = var30.getBounds();
//     var5.setBounds(var41);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var5.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
    java.awt.Paint var9 = var5.getBackgroundPaint();
    var3.addSubtitle((org.jfree.chart.title.Title)var5);
    java.awt.Paint var11 = var3.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var3.removeSubtitle((org.jfree.chart.title.Title)var13);
    var3.setBackgroundImageAlignment(0);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    double var23 = var22.getContentXOffset();
    java.awt.Paint var24 = var22.getItemPaint();
    java.awt.Font var25 = var22.getItemFont();
    org.jfree.chart.util.HorizontalAlignment var26 = var22.getHorizontalAlignment();
    var3.addSubtitle((org.jfree.chart.title.Title)var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var29 = var3.getSubtitle(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("Category Plot", 15, 100);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisLocation var4 = var0.getDomainAxisLocation(0);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    boolean var9 = var0.equals((java.lang.Object)0.0f);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisLocation var14 = var10.getDomainAxisLocation(0);
    var0.setRangeAxisLocation(var14, false);
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var20 = var19.getRange();
    java.lang.Object var21 = var19.clone();
    var19.setUpperMargin(0.025d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var19, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var5.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
    java.awt.Paint var9 = var5.getBackgroundPaint();
    var3.addSubtitle((org.jfree.chart.title.Title)var5);
    java.awt.Paint var11 = var3.getBackgroundPaint();
    org.jfree.chart.ChartRenderingInfo var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var16 = var3.createBufferedImage(0, 0, (-16777216), var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    java.lang.Class var0 = null;
    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 1.0E-5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Pie Plot", var1, 0.0f, 0.0f, 0.0d, 0.0f, 100.0f);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var5 = var3.getSubtitle(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     double var8 = var7.getLabelLinkMargin();
//     var7.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
//     double var12 = var11.getContentXOffset();
//     java.awt.Paint var13 = var11.getItemPaint();
//     java.awt.Font var14 = var11.getItemFont();
//     var5.setLabelFont(var14);
//     org.jfree.chart.util.Layer var16 = null;
//     boolean var17 = var0.removeRangeMarker(100, (org.jfree.chart.plot.Marker)var5, var16);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    java.lang.String var2 = var0.getPlotType();
    boolean var3 = var0.getDrawSharedDomainAxis();
    var0.setRangeCrosshairValue(100.0d, true);
    org.jfree.chart.plot.Marker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = var0.removeRangeMarker(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var3 = var2.getPlot();
    org.jfree.chart.plot.Plot var4 = var3.getRootPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Paint var7 = var5.getItemPaint();
//     java.awt.Font var8 = var5.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var9 = var5.getLegendItemGraphicAnchor();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getLabelLinkMargin();
//     var11.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
//     double var16 = var15.getContentXOffset();
//     java.awt.Paint var17 = var15.getItemPaint();
//     java.awt.Font var18 = var15.getItemFont();
//     var5.setItemFont(var18);
//     
//     // Checks the contract:  equals-hashcode on var1 and var11
//     assertTrue("Contract failed: equals-hashcode on var1 and var11", var1.equals(var11) ? var1.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var1
//     assertTrue("Contract failed: equals-hashcode on var11 and var1", var11.equals(var1) ? var11.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Pie Plot", var1);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("ThreadContext");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = null;
//     var1.addFragment(var2);
//     org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("hi!");
//     var1.addFragment(var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     boolean var14 = var11.equals((java.lang.Object)var13);
//     org.jfree.chart.text.TextAnchor var15 = var11.getLabelTextAnchor();
//     java.lang.String var16 = var15.toString();
//     var1.draw(var7, (-1.0f), 100.0f, var15, 1.0f, 0.0f, 0.2d);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(short)1, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
    double var3 = var2.getHeight();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    org.jfree.chart.axis.ValueAxis var6 = var4.getAxis();
    org.jfree.chart.plot.PlotOrientation var7 = var4.getOrientation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var8 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.chart.axis.ValueAxis var5 = var3.getAxis();
    org.jfree.chart.plot.PlotOrientation var6 = var3.getOrientation();
    java.lang.String var7 = var6.toString();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.clearAnnotations();
    var8.clearDomainAxes();
    int var11 = var8.getBackgroundImageAlignment();
    java.awt.Paint var12 = null;
    var8.setOutlinePaint(var12);
    boolean var14 = var6.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "PlotOrientation.HORIZONTAL"+ "'", var7.equals("PlotOrientation.HORIZONTAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var16 = var15.getLowerMargin();
//     var0.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var15);
//     var15.setTickMarkOutsideLength(10.0f);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var24 = var20.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var26.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var29 = var20.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var34 = var30.getDomainAxisLocation(0);
//     var20.setRangeAxisLocation(var34, false);
//     org.jfree.chart.axis.CategoryAnchor var37 = var20.getDomainGridlinePosition();
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.RingPlot var42 = new org.jfree.chart.plot.RingPlot(var41);
//     java.awt.Font var43 = var42.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var42);
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var46.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var49 = var46.getFrame();
//     java.awt.Paint var50 = var46.getBackgroundPaint();
//     var44.addSubtitle((org.jfree.chart.title.Title)var46);
//     java.awt.Paint var52 = var44.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var54 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var44.removeSubtitle((org.jfree.chart.title.Title)var54);
//     org.jfree.chart.event.ChartChangeEventType var56 = null;
//     org.jfree.chart.event.ChartChangeEvent var57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var44, var56);
//     org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var59.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var62 = var59.getFrame();
//     java.awt.Paint var63 = var59.getBackgroundPaint();
//     var59.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var44.setTitle(var59);
//     java.awt.geom.Rectangle2D var70 = var59.getBounds();
//     org.jfree.data.general.PieDataset var71 = null;
//     org.jfree.chart.plot.RingPlot var72 = new org.jfree.chart.plot.RingPlot(var71);
//     double var73 = var72.getLabelLinkMargin();
//     var72.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var76 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var72);
//     double var77 = var76.getContentXOffset();
//     java.awt.Graphics2D var78 = null;
//     org.jfree.chart.block.RectangleConstraint var79 = null;
//     org.jfree.chart.util.Size2D var80 = var76.arrange(var78, var79);
//     org.jfree.chart.util.RectangleEdge var81 = var76.getLegendItemGraphicEdge();
//     double var82 = var15.getCategoryJava2DCoordinate(var37, 255, 10, var70, var81);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.setVisible(false);
//     var1.setUpperMargin(0.2d);
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var8 = var7.getRange();
//     java.lang.Object var9 = var7.clone();
//     org.jfree.chart.axis.NumberTickUnit var10 = var7.getTickUnit();
//     var1.setTickUnit(var10);
//     org.jfree.chart.axis.TickUnitSource var12 = var1.getStandardTickUnits();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
//     java.awt.Font var18 = var17.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var21.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var24 = var21.getFrame();
//     java.awt.Paint var25 = var21.getBackgroundPaint();
//     var19.addSubtitle((org.jfree.chart.title.Title)var21);
//     java.awt.Paint var27 = var19.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var19.removeSubtitle((org.jfree.chart.title.Title)var29);
//     org.jfree.chart.event.ChartChangeEventType var31 = null;
//     org.jfree.chart.event.ChartChangeEvent var32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var19, var31);
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var34.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var37 = var34.getFrame();
//     java.awt.Paint var38 = var34.getBackgroundPaint();
//     var34.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var19.setTitle(var34);
//     java.awt.geom.Rectangle2D var45 = var34.getBounds();
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     java.awt.Font var49 = var48.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var48);
//     org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var52.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var55 = var52.getFrame();
//     java.awt.Paint var56 = var52.getBackgroundPaint();
//     var50.addSubtitle((org.jfree.chart.title.Title)var52);
//     java.awt.Paint var58 = var50.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var50.removeSubtitle((org.jfree.chart.title.Title)var60);
//     org.jfree.chart.event.ChartChangeEventType var62 = null;
//     org.jfree.chart.event.ChartChangeEvent var63 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var50, var62);
//     org.jfree.chart.title.TextTitle var65 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var65.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var68 = var65.getFrame();
//     java.awt.Paint var69 = var65.getBackgroundPaint();
//     var65.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var50.setTitle(var65);
//     java.awt.geom.Rectangle2D var76 = var65.getBounds();
//     org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var78 = var77.getRangeCrosshairStroke();
//     java.lang.String var79 = var77.getPlotType();
//     boolean var80 = var77.getDrawSharedDomainAxis();
//     var77.mapDatasetToRangeAxis(0, 100);
//     org.jfree.chart.util.RectangleEdge var85 = var77.getDomainAxisEdge(10);
//     org.jfree.chart.plot.PlotRenderingInfo var86 = null;
//     org.jfree.chart.axis.AxisState var87 = var1.draw(var13, 0.025d, var45, var76, var85, var86);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, true);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var1);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     double var23 = var22.getContentXOffset();
//     java.awt.Paint var24 = var22.getItemPaint();
//     java.awt.Font var25 = var22.getItemFont();
//     var16.setLabelFont(var25);
//     org.jfree.chart.util.Layer var27 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
//     java.awt.Paint var29 = var16.getPaint();
//     boolean var31 = var16.equals((java.lang.Object)10);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     double var34 = var33.getLabelLinkMargin();
//     var33.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
//     double var38 = var37.getContentXOffset();
//     java.awt.Paint var39 = var37.getItemPaint();
//     var16.setLabelPaint(var39);
//     
//     // Checks the contract:  equals-hashcode on var18 and var33
//     assertTrue("Contract failed: equals-hashcode on var18 and var33", var18.equals(var33) ? var18.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var18
//     assertTrue("Contract failed: equals-hashcode on var33 and var18", var33.equals(var18) ? var33.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var16 = var15.getLowerMargin();
//     var0.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var15);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.clearAnnotations();
//     var18.clearDomainAxes();
//     int var21 = var18.getBackgroundImageAlignment();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var25 = null;
//     var23.setRangeAxisLocation(1, var25, false);
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
//     boolean var30 = var29.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var31 = null;
//     var29.setURLGenerator(var31);
//     org.jfree.chart.event.PlotChangeListener var33 = null;
//     var29.addChangeListener(var33);
//     java.awt.Shape var35 = var29.getLegendItemShape();
//     java.awt.Stroke var36 = var29.getBaseSectionOutlineStroke();
//     var23.setDomainGridlineStroke(var36);
//     double var38 = var23.getAnchorValue();
//     org.jfree.chart.axis.AxisLocation var39 = var23.getRangeAxisLocation();
//     var18.setDomainAxisLocation(0, var39);
//     var0.setDomainAxisLocation(var39);
//     
//     // Checks the contract:  equals-hashcode on var6 and var29
//     assertTrue("Contract failed: equals-hashcode on var6 and var29", var6.equals(var29) ? var6.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var6
//     assertTrue("Contract failed: equals-hashcode on var29 and var6", var29.equals(var6) ? var29.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     boolean var2 = var1.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var1.setURLGenerator(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var1.addChangeListener(var5);
//     java.awt.Paint var7 = var1.getBaseSectionOutlinePaint();
//     java.awt.Image var8 = null;
//     var1.setBackgroundImage(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var15 = var14.getGreen();
//     int var16 = var14.getRGB();
//     int var17 = var14.getAlpha();
//     float[] var18 = null;
//     float[] var19 = var14.getRGBComponents(var18);
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
//     java.awt.Font var25 = var24.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var28.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var31 = var28.getFrame();
//     java.awt.Paint var32 = var28.getBackgroundPaint();
//     var26.addSubtitle((org.jfree.chart.title.Title)var28);
//     java.awt.Paint var34 = var26.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var26.removeSubtitle((org.jfree.chart.title.Title)var36);
//     org.jfree.chart.event.ChartChangeEventType var38 = null;
//     org.jfree.chart.event.ChartChangeEvent var39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var26, var38);
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var41.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var44 = var41.getFrame();
//     java.awt.Paint var45 = var41.getBackgroundPaint();
//     var41.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var26.setTitle(var41);
//     java.awt.geom.Rectangle2D var52 = var41.getBounds();
//     java.awt.geom.AffineTransform var53 = null;
//     java.awt.RenderingHints var54 = null;
//     java.awt.PaintContext var55 = var14.createContext(var20, var21, var52, var53, var54);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.RingPlot var57 = new org.jfree.chart.plot.RingPlot(var56);
//     double var58 = var57.getLabelLinkMargin();
//     var57.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57);
//     var57.setInnerSeparatorExtension(0.025d);
//     org.jfree.chart.labels.PieSectionLabelGenerator var64 = var57.getLegendLabelGenerator();
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     org.jfree.chart.plot.PiePlotState var67 = var1.initialise(var10, (java.awt.geom.Rectangle2D)var21, (org.jfree.chart.plot.PiePlot)var57, (java.lang.Integer)100, var66);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = null;
//     org.jfree.chart.util.Size2D var9 = var5.arrange(var7, var8);
//     double var10 = var9.getWidth();
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     double var15 = var14.getLabelLinkMargin();
//     var14.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     double var19 = var18.getContentXOffset();
//     java.awt.Paint var20 = var18.getItemPaint();
//     java.awt.Font var21 = var18.getItemFont();
//     org.jfree.chart.util.RectangleInsets var22 = var18.getPadding();
//     org.jfree.chart.util.RectangleAnchor var23 = var18.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var24 = org.jfree.chart.util.RectangleAnchor.createRectangle(var9, 0.0d, 0.025d, var23);
//     
//     // Checks the contract:  equals-hashcode on var1 and var14
//     assertTrue("Contract failed: equals-hashcode on var1 and var14", var1.equals(var14) ? var1.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var1
//     assertTrue("Contract failed: equals-hashcode on var14 and var1", var14.equals(var1) ? var14.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    java.lang.String var2 = var0.getPlotType();
    boolean var3 = var0.getDrawSharedDomainAxis();
    var0.mapDatasetToRangeAxis(0, 100);
    java.awt.Stroke var7 = var0.getRangeGridlineStroke();
    org.jfree.chart.plot.CategoryMarker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(10, var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Category Plot");

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0E-8d, 0.0f, 0.0f);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = var5.arrange(var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
//     org.jfree.chart.util.Size2D var14 = var5.arrange(var10, var13);
//     
//     // Checks the contract:  equals-hashcode on var9 and var14
//     assertTrue("Contract failed: equals-hashcode on var9 and var14", var9.equals(var14) ? var9.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var9
//     assertTrue("Contract failed: equals-hashcode on var14 and var9", var14.equals(var9) ? var14.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var4 = var3.getGreen();
//     int var5 = var3.getRGB();
//     int var6 = var3.getAlpha();
//     float[] var7 = null;
//     float[] var8 = var3.getRGBComponents(var7);
//     java.awt.image.ColorModel var9 = null;
//     java.awt.Rectangle var10 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     java.awt.Font var14 = var13.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var17.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var20 = var17.getFrame();
//     java.awt.Paint var21 = var17.getBackgroundPaint();
//     var15.addSubtitle((org.jfree.chart.title.Title)var17);
//     java.awt.Paint var23 = var15.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var15.removeSubtitle((org.jfree.chart.title.Title)var25);
//     org.jfree.chart.event.ChartChangeEventType var27 = null;
//     org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var15, var27);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var30.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var33 = var30.getFrame();
//     java.awt.Paint var34 = var30.getBackgroundPaint();
//     var30.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var15.setTitle(var30);
//     java.awt.geom.Rectangle2D var41 = var30.getBounds();
//     java.awt.geom.AffineTransform var42 = null;
//     java.awt.RenderingHints var43 = null;
//     java.awt.PaintContext var44 = var3.createContext(var9, var10, var41, var42, var43);
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.RingPlot var46 = new org.jfree.chart.plot.RingPlot(var45);
//     java.awt.Font var47 = var46.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var46);
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var50.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var53 = var50.getFrame();
//     java.awt.Paint var54 = var50.getBackgroundPaint();
//     var48.addSubtitle((org.jfree.chart.title.Title)var50);
//     java.awt.Paint var56 = var48.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var58 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var48.removeSubtitle((org.jfree.chart.title.Title)var58);
//     var48.setBackgroundImageAlignment(0);
//     org.jfree.data.general.PieDataset var62 = null;
//     org.jfree.chart.plot.RingPlot var63 = new org.jfree.chart.plot.RingPlot(var62);
//     double var64 = var63.getLabelLinkMargin();
//     var63.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
//     double var68 = var67.getContentXOffset();
//     java.awt.Paint var69 = var67.getItemPaint();
//     java.awt.Font var70 = var67.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var71 = var67.getHorizontalAlignment();
//     var48.addSubtitle((org.jfree.chart.title.Title)var67);
//     org.jfree.chart.util.RectangleAnchor var73 = var67.getLegendItemGraphicAnchor();
//     java.awt.geom.Point2D var74 = org.jfree.chart.util.RectangleAnchor.coordinates((java.awt.geom.Rectangle2D)var10, var73);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
//     java.awt.Stroke var5 = var3.getLabelOutlineStroke();
//     var0.setRangeCrosshairStroke(var5);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var9 = null;
//     var7.setRangeAxisLocation(1, var9, false);
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     boolean var14 = var13.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var15 = null;
//     var13.setURLGenerator(var15);
//     org.jfree.chart.event.PlotChangeListener var17 = null;
//     var13.addChangeListener(var17);
//     java.awt.Shape var19 = var13.getLegendItemShape();
//     java.awt.Stroke var20 = var13.getBaseSectionOutlineStroke();
//     var7.setDomainGridlineStroke(var20);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var23 = var22.getLowerMargin();
//     var7.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var22.setUpperMargin(100.0d);
//     org.jfree.chart.axis.CategoryAxis[] var27 = new org.jfree.chart.axis.CategoryAxis[] { var22};
//     var0.setDomainAxes(var27);
//     
//     // Checks the contract:  equals-hashcode on var3 and var13
//     assertTrue("Contract failed: equals-hashcode on var3 and var13", var3.equals(var13) ? var3.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var3
//     assertTrue("Contract failed: equals-hashcode on var13 and var3", var13.equals(var3) ? var13.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     java.awt.Paint var11 = var3.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var3.removeSubtitle((org.jfree.chart.title.Title)var13);
//     var3.setBackgroundImageAlignment(0);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     double var23 = var22.getContentXOffset();
//     java.awt.Paint var24 = var22.getItemPaint();
//     java.awt.Font var25 = var22.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var26 = var22.getHorizontalAlignment();
//     var3.addSubtitle((org.jfree.chart.title.Title)var22);
//     var3.fireChartChanged();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     double var31 = var30.getLabelLinkMargin();
//     var30.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     org.jfree.chart.event.TitleChangeListener var35 = null;
//     var34.addChangeListener(var35);
//     org.jfree.chart.block.BlockContainer var37 = null;
//     var34.setWrapper(var37);
//     org.jfree.chart.util.RectangleInsets var39 = var34.getPadding();
//     double var40 = var39.getLeft();
//     var3.setPadding(var39);
//     
//     // Checks the contract:  equals-hashcode on var18 and var30
//     assertTrue("Contract failed: equals-hashcode on var18 and var30", var18.equals(var30) ? var18.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var18
//     assertTrue("Contract failed: equals-hashcode on var30 and var18", var30.equals(var18) ? var30.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     java.awt.Image var4 = var3.getBackgroundImage();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     double var7 = var6.getLabelLinkMargin();
//     var6.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     org.jfree.chart.event.TitleChangeListener var11 = null;
//     var10.addChangeListener(var11);
//     double var13 = var10.getContentYOffset();
//     java.awt.Paint var14 = var10.getBackgroundPaint();
//     var3.addLegend(var10);
//     java.awt.Graphics2D var16 = null;
//     java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var21 = var20.getGreen();
//     int var22 = var20.getRGB();
//     int var23 = var20.getAlpha();
//     float[] var24 = null;
//     float[] var25 = var20.getRGBComponents(var24);
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     java.awt.Font var31 = var30.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var30);
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var34.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var37 = var34.getFrame();
//     java.awt.Paint var38 = var34.getBackgroundPaint();
//     var32.addSubtitle((org.jfree.chart.title.Title)var34);
//     java.awt.Paint var40 = var32.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var32.removeSubtitle((org.jfree.chart.title.Title)var42);
//     org.jfree.chart.event.ChartChangeEventType var44 = null;
//     org.jfree.chart.event.ChartChangeEvent var45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var32, var44);
//     org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var47.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var50 = var47.getFrame();
//     java.awt.Paint var51 = var47.getBackgroundPaint();
//     var47.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var32.setTitle(var47);
//     java.awt.geom.Rectangle2D var58 = var47.getBounds();
//     java.awt.geom.AffineTransform var59 = null;
//     java.awt.RenderingHints var60 = null;
//     java.awt.PaintContext var61 = var20.createContext(var26, var27, var58, var59, var60);
//     org.jfree.chart.ChartRenderingInfo var62 = null;
//     var3.draw(var16, var58, var62);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = null;
    var3.setDataset(var4);
    java.awt.Paint var6 = var3.getRadiusGridlinePaint();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    double var9 = var8.getLabelLinkMargin();
    var8.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    org.jfree.chart.event.TitleChangeListener var13 = null;
    var12.addChangeListener(var13);
    org.jfree.chart.block.BlockContainer var15 = null;
    var12.setWrapper(var15);
    org.jfree.chart.util.RectangleInsets var17 = var12.getPadding();
    double var18 = var17.getLeft();
    var3.setInsets(var17);
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    var3.setRenderer(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    java.awt.Paint var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var1.setRangeAxisLocation(1, var3, false);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    boolean var8 = var7.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var9 = null;
    var7.setURLGenerator(var9);
    org.jfree.chart.event.PlotChangeListener var11 = null;
    var7.addChangeListener(var11);
    java.awt.Shape var13 = var7.getLegendItemShape();
    java.awt.Stroke var14 = var7.getBaseSectionOutlineStroke();
    var1.setDomainGridlineStroke(var14);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    double var18 = var17.getLabelLinkMargin();
    var17.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    org.jfree.chart.event.TitleChangeListener var22 = null;
    var21.addChangeListener(var22);
    org.jfree.chart.block.BlockContainer var24 = null;
    var21.setWrapper(var24);
    org.jfree.chart.util.RectangleInsets var26 = var21.getPadding();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var27 = new org.jfree.chart.block.LineBorder(var0, var14, var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
//     java.lang.String var2 = var0.getPlotType();
//     boolean var3 = var0.getDrawSharedDomainAxis();
//     var0.mapDatasetToRangeAxis(0, 100);
//     java.awt.Stroke var7 = var0.getRangeGridlineStroke();
//     java.awt.Graphics2D var8 = null;
//     java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var13 = var12.getGreen();
//     int var14 = var12.getRGB();
//     int var15 = var12.getAlpha();
//     float[] var16 = null;
//     float[] var17 = var12.getRGBComponents(var16);
//     java.awt.image.ColorModel var18 = null;
//     java.awt.Rectangle var19 = null;
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
//     java.awt.Font var23 = var22.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var26.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var29 = var26.getFrame();
//     java.awt.Paint var30 = var26.getBackgroundPaint();
//     var24.addSubtitle((org.jfree.chart.title.Title)var26);
//     java.awt.Paint var32 = var24.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var24.removeSubtitle((org.jfree.chart.title.Title)var34);
//     org.jfree.chart.event.ChartChangeEventType var36 = null;
//     org.jfree.chart.event.ChartChangeEvent var37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var24, var36);
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var39.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var42 = var39.getFrame();
//     java.awt.Paint var43 = var39.getBackgroundPaint();
//     var39.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var24.setTitle(var39);
//     java.awt.geom.Rectangle2D var50 = var39.getBounds();
//     java.awt.geom.AffineTransform var51 = null;
//     java.awt.RenderingHints var52 = null;
//     java.awt.PaintContext var53 = var12.createContext(var18, var19, var50, var51, var52);
//     var0.drawBackground(var8, (java.awt.geom.Rectangle2D)var19);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"ThreadContext", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     double var3 = var2.getLabelLinkMargin();
//     var2.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     org.jfree.chart.LegendItemSource[] var7 = var6.getSources();
//     var6.setID("ThreadContext");
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var13 = var10.getRangeAxisEdge(1);
//     var6.setPosition(var13);
//     double var15 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var13);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    double var8 = var7.getLabelLinkMargin();
    var7.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    double var12 = var11.getContentXOffset();
    java.awt.Paint var13 = var11.getItemPaint();
    java.awt.Font var14 = var11.getItemFont();
    var5.setLabelFont(var14);
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var14);
    var2.setLabelFont(var14);
    java.awt.Paint var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("TextAnchor.CENTER", var14, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var1.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var4 = var1.getFrame();
    java.awt.Paint var5 = var1.getBackgroundPaint();
    var1.setID("");
    java.lang.String var8 = var1.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setVisible(false);
    var1.setUpperMargin(0.2d);
    float var6 = var1.getTickMarkInsideLength();
    var1.setAutoRangeMinimumSize(1.0E-5d);
    var1.setUpperMargin(1.0E-8d);
    org.jfree.data.RangeType var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeType(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     java.awt.Paint var11 = var3.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var3.removeSubtitle((org.jfree.chart.title.Title)var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     double var17 = var16.getLabelLinkMargin();
//     org.jfree.chart.event.PlotChangeEvent var18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var16);
//     var3.plotChanged(var18);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisLocation var4 = var0.getDomainAxisLocation(0);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    boolean var9 = var0.equals((java.lang.Object)0.0f);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisLocation var14 = var10.getDomainAxisLocation(0);
    var0.setRangeAxisLocation(var14, false);
    org.jfree.chart.axis.CategoryAnchor var17 = var0.getDomainGridlinePosition();
    org.jfree.chart.plot.DatasetRenderingOrder var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     java.awt.Font var4 = var3.getAngleLabelFont();
//     boolean var5 = var3.isRadiusGridlinesVisible();
//     var3.zoom((-15.95d));
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("ThreadContext");
    java.awt.Paint var2 = var1.getPaint();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    boolean var5 = var4.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var4.setURLGenerator(var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var4.addChangeListener(var8);
    java.awt.Paint var10 = var4.getBaseSectionOutlinePaint();
    boolean var11 = var1.equals((java.lang.Object)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    var0.clearDomainAxes();
    int var3 = var0.getBackgroundImageAlignment();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setRangeAxisLocation(1, var7, false);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    boolean var12 = var11.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var13 = null;
    var11.setURLGenerator(var13);
    org.jfree.chart.event.PlotChangeListener var15 = null;
    var11.addChangeListener(var15);
    java.awt.Shape var17 = var11.getLegendItemShape();
    java.awt.Stroke var18 = var11.getBaseSectionOutlineStroke();
    var5.setDomainGridlineStroke(var18);
    double var20 = var5.getAnchorValue();
    org.jfree.chart.axis.AxisLocation var21 = var5.getRangeAxisLocation();
    var0.setDomainAxisLocation(0, var21);
    org.jfree.chart.axis.AxisLocation var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var23, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     org.jfree.chart.LegendItemCollection var9 = var8.getLegendItems();
//     var4.addAll(var9);
//     
//     // Checks the contract:  equals-hashcode on var3 and var8
//     assertTrue("Contract failed: equals-hashcode on var3 and var8", var3.equals(var8) ? var3.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var3
//     assertTrue("Contract failed: equals-hashcode on var8 and var3", var8.equals(var3) ? var8.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var9
//     assertTrue("Contract failed: equals-hashcode on var4 and var9", var4.equals(var9) ? var4.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var4
//     assertTrue("Contract failed: equals-hashcode on var9 and var4", var9.equals(var4) ? var9.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setVisible(false);
    var1.setUpperMargin(0.2d);
    float var6 = var1.getTickMarkInsideLength();
    var1.setAutoRangeMinimumSize(1.0E-5d);
    double var9 = var1.getLowerBound();
    org.jfree.data.RangeType var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeType(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = null;
//     var3.setDataset(var4);
//     java.awt.Paint var6 = var3.getRadiusGridlinePaint();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     org.jfree.chart.event.TitleChangeListener var13 = null;
//     var12.addChangeListener(var13);
//     org.jfree.chart.block.BlockContainer var15 = null;
//     var12.setWrapper(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var12.getPadding();
//     double var18 = var17.getLeft();
//     var3.setInsets(var17);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var20, var21, var22);
//     org.jfree.data.xy.XYDataset var24 = null;
//     var23.setDataset(var24);
//     boolean var26 = var23.isDomainZoomable();
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     boolean var31 = var28.equals((java.lang.Object)var30);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     double var34 = var33.getLabelLinkMargin();
//     var33.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
//     double var38 = var37.getContentXOffset();
//     java.awt.Paint var39 = var37.getItemPaint();
//     java.awt.Font var40 = var37.getItemFont();
//     var28.setLabelFont(var40);
//     java.awt.Paint var42 = var28.getLabelPaint();
//     var23.setAngleGridlinePaint(var42);
//     var3.setNoDataMessagePaint(var42);
//     
//     // Checks the contract:  equals-hashcode on var8 and var33
//     assertTrue("Contract failed: equals-hashcode on var8 and var33", var8.equals(var33) ? var8.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var8
//     assertTrue("Contract failed: equals-hashcode on var33 and var8", var33.equals(var8) ? var33.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.025d, (-1.0f), 100.0f);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.14d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.chart.ui.Licences var0 = org.jfree.chart.ui.Licences.getInstance();
    java.lang.String var1 = var0.getLGPL();
    java.lang.String var2 = var0.getLGPL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = null;
//     org.jfree.chart.util.Size2D var9 = var5.arrange(var7, var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getLabelLinkMargin();
//     var11.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
//     double var16 = var15.getContentXOffset();
//     java.awt.Paint var17 = var15.getItemPaint();
//     java.awt.Font var18 = var15.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var19 = var15.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var20 = null;
//     org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 0.2d, 0.025d);
//     org.jfree.chart.block.BlockContainer var24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var23);
//     var5.setWrapper(var24);
//     
//     // Checks the contract:  equals-hashcode on var1 and var11
//     assertTrue("Contract failed: equals-hashcode on var1 and var11", var1.equals(var11) ? var1.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var1
//     assertTrue("Contract failed: equals-hashcode on var11 and var1", var11.equals(var1) ? var11.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)true);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Pie Plot", var1);
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     double var23 = var22.getContentXOffset();
//     java.awt.Paint var24 = var22.getItemPaint();
//     java.awt.Font var25 = var22.getItemFont();
//     var16.setLabelFont(var25);
//     org.jfree.chart.util.Layer var27 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
//     java.awt.Paint var29 = var16.getPaint();
//     java.awt.Paint var30 = var16.getOutlinePaint();
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var33 = null;
//     org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot(var31, var32, var33);
//     org.jfree.data.xy.XYDataset var35 = null;
//     var34.setDataset(var35);
//     java.awt.Paint var37 = var34.getRadiusGridlinePaint();
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot(var38);
//     double var40 = var39.getLabelLinkMargin();
//     var39.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     org.jfree.chart.event.TitleChangeListener var44 = null;
//     var43.addChangeListener(var44);
//     org.jfree.chart.block.BlockContainer var46 = null;
//     var43.setWrapper(var46);
//     org.jfree.chart.util.RectangleInsets var48 = var43.getPadding();
//     double var49 = var48.getLeft();
//     var34.setInsets(var48);
//     var16.setLabelOffset(var48);
//     
//     // Checks the contract:  equals-hashcode on var18 and var39
//     assertTrue("Contract failed: equals-hashcode on var18 and var39", var18.equals(var39) ? var18.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var18
//     assertTrue("Contract failed: equals-hashcode on var39 and var18", var39.equals(var18) ? var39.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var4 = null;
//     var3.addFragment(var4);
//     org.jfree.chart.text.TextFragment var6 = null;
//     var3.addFragment(var6);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var10 = null;
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot(var8, var9, var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     var11.setDataset(var12);
//     java.awt.Paint var14 = var11.getRadiusGridlinePaint();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     org.jfree.chart.event.PlotChangeEvent var17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var16);
//     java.awt.Stroke var18 = var16.getLabelOutlineStroke();
//     var16.setSectionOutlinesVisible(true);
//     java.awt.Stroke var21 = var16.getLabelOutlineStroke();
//     var11.setAngleGridlineStroke(var21);
//     boolean var23 = var3.equals((java.lang.Object)var21);
//     boolean var24 = var0.equals((java.lang.Object)var21);
//     java.lang.Object var25 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var25
//     assertTrue("Contract failed: equals-hashcode on var1 and var25", var1.equals(var25) ? var1.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var1
//     assertTrue("Contract failed: equals-hashcode on var25 and var1", var25.equals(var1) ? var25.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Paint var7 = var5.getItemPaint();
//     java.awt.Font var8 = var5.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 0.2d, 0.025d);
//     org.jfree.chart.text.TextBlock var14 = new org.jfree.chart.text.TextBlock();
//     java.util.List var15 = var14.getLines();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
//     double var18 = var17.getLabelLinkMargin();
//     var17.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     double var22 = var21.getContentXOffset();
//     java.awt.Paint var23 = var21.getItemPaint();
//     java.awt.Font var24 = var21.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var25 = var21.getHorizontalAlignment();
//     var14.setLineAlignment(var25);
//     org.jfree.chart.text.TextLine var28 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var29 = null;
//     var28.addFragment(var29);
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.chart.renderer.RendererState var32 = new org.jfree.chart.renderer.RendererState(var31);
//     boolean var33 = var28.equals((java.lang.Object)var31);
//     var14.addLine(var28);
//     boolean var35 = var13.equals((java.lang.Object)var14);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     boolean var2 = var1.isSubplot();
//     boolean var4 = var1.equals((java.lang.Object)"hi!");
//     java.awt.Image var5 = var1.getBackgroundImage();
//     java.awt.Stroke var6 = var1.getBaseSectionOutlineStroke();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     java.awt.Font var9 = var8.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     java.awt.Image var11 = var10.getBackgroundImage();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     double var14 = var13.getLabelLinkMargin();
//     var13.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     org.jfree.chart.event.TitleChangeListener var18 = null;
//     var17.addChangeListener(var18);
//     double var20 = var17.getContentYOffset();
//     java.awt.Paint var21 = var17.getBackgroundPaint();
//     var10.addLegend(var17);
//     boolean var23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var10);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    java.lang.String var2 = var0.getPlotType();
    boolean var3 = var0.getDrawSharedDomainAxis();
    var0.mapDatasetToRangeAxis(0, 100);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(10);
    org.jfree.chart.util.SortOrder var9 = var0.getRowRenderingOrder();
    boolean var10 = var0.isRangeGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    java.awt.Paint var6 = var1.getShadowPaint();
    java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var11 = var10.getAlpha();
    java.awt.Color var12 = var10.brighter();
    var1.setSeparatorPaint((java.awt.Paint)var10);
    var1.setIgnoreZeroValues(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    var0.clearDomainAxes();
    int var3 = var0.getBackgroundImageAlignment();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setRangeAxisLocation(1, var7, false);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    boolean var12 = var11.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var13 = null;
    var11.setURLGenerator(var13);
    org.jfree.chart.event.PlotChangeListener var15 = null;
    var11.addChangeListener(var15);
    java.awt.Shape var17 = var11.getLegendItemShape();
    java.awt.Stroke var18 = var11.getBaseSectionOutlineStroke();
    var5.setDomainGridlineStroke(var18);
    double var20 = var5.getAnchorValue();
    org.jfree.chart.axis.AxisLocation var21 = var5.getRangeAxisLocation();
    var0.setDomainAxisLocation(0, var21);
    org.jfree.chart.plot.Marker var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var24 = var0.removeRangeMarker(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setVisible(false);
    var1.setUpperMargin(0.2d);
    float var6 = var1.getTickMarkInsideLength();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    double var9 = var8.getLabelLinkMargin();
    var8.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Paint var13 = var8.getShadowPaint();
    var1.setTickLabelPaint(var13);
    java.lang.String var15 = var1.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    double var23 = var22.getContentXOffset();
    java.awt.Paint var24 = var22.getItemPaint();
    java.awt.Font var25 = var22.getItemFont();
    var16.setLabelFont(var25);
    org.jfree.chart.util.Layer var27 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
    double var29 = var0.getRangeCrosshairValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    int var31 = var0.getIndexOf(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(2.14d, 1.0E-5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     float var2 = var1.getBaselineOffset();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var1.calculateDimensions(var3);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     double var23 = var22.getContentXOffset();
//     java.awt.Paint var24 = var22.getItemPaint();
//     java.awt.Font var25 = var22.getItemFont();
//     var16.setLabelFont(var25);
//     org.jfree.chart.util.Layer var27 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
//     java.awt.Stroke var29 = var0.getDomainGridlineStroke();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var32 = null;
//     var30.setRangeAxisLocation(1, var32, false);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     boolean var37 = var36.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var38 = null;
//     var36.setURLGenerator(var38);
//     org.jfree.chart.event.PlotChangeListener var40 = null;
//     var36.addChangeListener(var40);
//     java.awt.Shape var42 = var36.getLegendItemShape();
//     java.awt.Stroke var43 = var36.getBaseSectionOutlineStroke();
//     var30.setDomainGridlineStroke(var43);
//     org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     double var49 = var48.getLabelLinkMargin();
//     var48.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
//     double var53 = var52.getContentXOffset();
//     java.awt.Paint var54 = var52.getItemPaint();
//     java.awt.Font var55 = var52.getItemFont();
//     var46.setLabelFont(var55);
//     org.jfree.chart.util.Layer var57 = null;
//     var30.addRangeMarker((org.jfree.chart.plot.Marker)var46, var57);
//     double var59 = var30.getRangeCrosshairValue();
//     var30.setWeight(100);
//     org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var65 = null;
//     var64.notifyListeners(var65);
//     org.jfree.chart.plot.DefaultDrawingSupplier var67 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var68 = var67.getNextFillPaint();
//     var64.setPaint(var68);
//     org.jfree.chart.util.Layer var70 = null;
//     boolean var71 = var30.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var64, var70);
//     java.awt.Stroke var72 = var64.getStroke();
//     boolean var73 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var64);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     double var6 = var5.getLabelLinkMargin();
//     var5.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var10 = var5.getShadowPaint();
//     java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var15 = var14.getAlpha();
//     java.awt.Color var16 = var14.brighter();
//     var5.setSeparatorPaint((java.awt.Paint)var14);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var18, var19, var20);
//     org.jfree.chart.LegendItemCollection var22 = var21.getLegendItems();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
//     org.jfree.chart.event.PlotChangeEvent var25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var24);
//     java.awt.Stroke var26 = var24.getLabelOutlineStroke();
//     java.awt.Paint var27 = var24.getSeparatorPaint();
//     boolean var28 = var24.isCircular();
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var33 = var32.getGreen();
//     var24.setSeparatorPaint((java.awt.Paint)var32);
//     var21.setRadiusGridlinePaint((java.awt.Paint)var32);
//     java.awt.image.ColorModel var36 = null;
//     java.awt.Rectangle var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     java.awt.geom.AffineTransform var39 = null;
//     java.awt.RenderingHints var40 = null;
//     java.awt.PaintContext var41 = var32.createContext(var36, var37, var38, var39, var40);
//     var5.setLabelBackgroundPaint((java.awt.Paint)var32);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.text.G2TextMeasurer var46 = new org.jfree.chart.text.G2TextMeasurer(var45);
//     org.jfree.chart.text.TextBlock var47 = org.jfree.chart.text.TextUtilities.createTextBlock("Pie Plot", var3, (java.awt.Paint)var32, (-1.0f), 15, (org.jfree.chart.text.TextMeasurer)var46);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var2 = var1.getRange();
    double var3 = var2.getCentralValue();
    double var4 = var2.getUpperBound();
    double var5 = var2.getLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
//     java.awt.Stroke var8 = var6.getLabelOutlineStroke();
//     java.awt.Paint var9 = var6.getSeparatorPaint();
//     boolean var10 = var6.isCircular();
//     java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var15 = var14.getGreen();
//     var6.setSeparatorPaint((java.awt.Paint)var14);
//     var3.setRadiusGridlinePaint((java.awt.Paint)var14);
//     boolean var18 = var3.isAngleGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     java.awt.geom.Point2D var21 = null;
//     var3.zoomRangeAxes(10.0d, var20, var21, false);
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     java.awt.Font var4 = var3.getAngleLabelFont();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     java.awt.Font var10 = var9.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var13.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var16 = var13.getFrame();
//     java.awt.Paint var17 = var13.getBackgroundPaint();
//     var11.addSubtitle((org.jfree.chart.title.Title)var13);
//     java.awt.Paint var19 = var11.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var11.removeSubtitle((org.jfree.chart.title.Title)var21);
//     org.jfree.chart.event.ChartChangeEventType var23 = null;
//     org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var11, var23);
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var26.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var29 = var26.getFrame();
//     java.awt.Paint var30 = var26.getBackgroundPaint();
//     var26.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var11.setTitle(var26);
//     java.awt.geom.Rectangle2D var37 = var26.getBounds();
//     java.awt.Point var38 = var3.translateValueThetaRadiusToJava2D(0.14d, 1.0E-8d, var37);
// 
//   }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.chart.axis.ValueAxis var5 = var3.getAxis();
//     org.jfree.data.xy.XYDataset var6 = null;
//     var3.setDataset(var6);
//     double var8 = var3.getMaxRadius();
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    double var6 = var5.getContentXOffset();
    java.awt.Paint var7 = var5.getItemPaint();
    java.awt.Font var8 = var5.getItemFont();
    double var9 = var5.getContentYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    double var4 = var3.getLabelLinkMargin();
    var3.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
    double var8 = var7.getContentXOffset();
    java.awt.Paint var9 = var7.getItemPaint();
    java.awt.Font var10 = var7.getItemFont();
    org.jfree.chart.util.HorizontalAlignment var11 = var7.getHorizontalAlignment();
    var0.setLineAlignment(var11);
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLineAlignment(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setLicenceText("ThreadContext");
    var0.setInfo("TextAnchor.CENTER");

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    java.awt.Color var1 = java.awt.Color.getColor("ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
    org.jfree.chart.event.PlotChangeEvent var6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var7 = var5.getLabelOutlineStroke();
    java.awt.Paint var8 = var5.getSeparatorPaint();
    var1.setSectionOutlinePaint((java.lang.Comparable)(-1.0d), var8);
    double var10 = var1.getShadowYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 4.0d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
//     java.awt.Stroke var8 = var6.getLabelOutlineStroke();
//     java.awt.Paint var9 = var6.getSeparatorPaint();
//     boolean var10 = var6.isCircular();
//     java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var15 = var14.getGreen();
//     var6.setSeparatorPaint((java.awt.Paint)var14);
//     var3.setRadiusGridlinePaint((java.awt.Paint)var14);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
//     org.jfree.chart.event.PlotChangeEvent var20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var19);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
//     org.jfree.chart.event.PlotChangeEvent var24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var23);
//     java.awt.Stroke var25 = var23.getLabelOutlineStroke();
//     java.awt.Paint var26 = var23.getSeparatorPaint();
//     var19.setSectionOutlinePaint((java.lang.Comparable)(-1.0d), var26);
//     var3.setAngleGridlinePaint(var26);
//     boolean var29 = var3.isAngleLabelsVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     java.awt.geom.Point2D var32 = null;
//     var3.zoomRangeAxes(0.0d, var31, var32, false);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TextAnchor.CENTER", var1);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var1.setTickMarkOutsideLength((-1.0f));
//     var1.setTickMarkOutsideLength(1.0f);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var10 = var9.getRange();
//     double var11 = var9.getAutoRangeMinimumSize();
//     java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var17 = var16.getGreen();
//     int var18 = var16.getRGB();
//     int var19 = var16.getAlpha();
//     float[] var20 = null;
//     float[] var21 = var16.getRGBComponents(var20);
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     java.awt.Font var27 = var26.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var26);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var30.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var33 = var30.getFrame();
//     java.awt.Paint var34 = var30.getBackgroundPaint();
//     var28.addSubtitle((org.jfree.chart.title.Title)var30);
//     java.awt.Paint var36 = var28.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var28.removeSubtitle((org.jfree.chart.title.Title)var38);
//     org.jfree.chart.event.ChartChangeEventType var40 = null;
//     org.jfree.chart.event.ChartChangeEvent var41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var28, var40);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var43.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var46 = var43.getFrame();
//     java.awt.Paint var47 = var43.getBackgroundPaint();
//     var43.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var28.setTitle(var43);
//     java.awt.geom.Rectangle2D var54 = var43.getBounds();
//     java.awt.geom.AffineTransform var55 = null;
//     java.awt.RenderingHints var56 = null;
//     java.awt.PaintContext var57 = var16.createContext(var22, var23, var54, var55, var56);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
//     var58.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var61 = var58.getRangeAxisEdge(1);
//     double var62 = var9.valueToJava2D(0.2d, var54, var61);
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
//     var63.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var66 = var63.getRangeAxisEdge(1);
//     double var67 = var1.getCategoryStart(100, 0, var54, var66);
//     
//     // Checks the contract:  equals-hashcode on var58 and var63
//     assertTrue("Contract failed: equals-hashcode on var58 and var63", var58.equals(var63) ? var58.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var58
//     assertTrue("Contract failed: equals-hashcode on var63 and var58", var63.equals(var58) ? var63.hashCode() == var58.hashCode() : true);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var2 = var1.getFont();
//     org.jfree.chart.ui.BasicProjectInfo var8 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "ThreadContext");
//     org.jfree.chart.ui.BasicProjectInfo var14 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "ThreadContext", "hi!");
//     var8.addOptionalLibrary((org.jfree.chart.ui.Library)var14);
//     boolean var16 = var1.equals((java.lang.Object)var14);
//     java.awt.Paint var17 = var1.getPaint();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.util.Size2D var19 = var1.calculateDimensions(var18);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)(-24.921874999999996d), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "ThreadContext");
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "ThreadContext", "hi!");
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var11);
    java.lang.String var13 = var11.getVersion();
    var11.setVersion("ThreadContext");
    java.lang.String var16 = var11.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + ""+ "'", var13.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = null;
//     var1.addFragment(var2);
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.renderer.RendererState var5 = new org.jfree.chart.renderer.RendererState(var4);
//     boolean var6 = var1.equals((java.lang.Object)var4);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.Size2D var8 = var1.calculateDimensions(var7);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairLockedOnData(false);
    double var3 = var0.getRangeCrosshairValue();
    org.jfree.chart.util.SortOrder var4 = var0.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var6 = var0.getDomainAxis((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("TextAnchor.CENTER");

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     boolean var2 = var1.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var1.setURLGenerator(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var1.addChangeListener(var5);
//     java.awt.Shape var7 = var1.getLegendItemShape();
//     float var8 = var1.getForegroundAlpha();
//     java.lang.String var9 = var1.getPlotType();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     java.awt.Font var12 = var11.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var15.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var18 = var15.getFrame();
//     java.awt.Paint var19 = var15.getBackgroundPaint();
//     var13.addSubtitle((org.jfree.chart.title.Title)var15);
//     var1.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
//     
//     // Checks the contract:  equals-hashcode on var1 and var11
//     assertTrue("Contract failed: equals-hashcode on var1 and var11", var1.equals(var11) ? var1.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var1
//     assertTrue("Contract failed: equals-hashcode on var11 and var1", var11.equals(var1) ? var11.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
//     double var7 = var6.getRight();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var10 = var9.getRange();
//     double var11 = var9.getAutoRangeMinimumSize();
//     java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var17 = var16.getGreen();
//     int var18 = var16.getRGB();
//     int var19 = var16.getAlpha();
//     float[] var20 = null;
//     float[] var21 = var16.getRGBComponents(var20);
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     java.awt.Font var27 = var26.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var26);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var30.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var33 = var30.getFrame();
//     java.awt.Paint var34 = var30.getBackgroundPaint();
//     var28.addSubtitle((org.jfree.chart.title.Title)var30);
//     java.awt.Paint var36 = var28.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var28.removeSubtitle((org.jfree.chart.title.Title)var38);
//     org.jfree.chart.event.ChartChangeEventType var40 = null;
//     org.jfree.chart.event.ChartChangeEvent var41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var28, var40);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var43.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var46 = var43.getFrame();
//     java.awt.Paint var47 = var43.getBackgroundPaint();
//     var43.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var28.setTitle(var43);
//     java.awt.geom.Rectangle2D var54 = var43.getBounds();
//     java.awt.geom.AffineTransform var55 = null;
//     java.awt.RenderingHints var56 = null;
//     java.awt.PaintContext var57 = var16.createContext(var22, var23, var54, var55, var56);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
//     var58.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var61 = var58.getRangeAxisEdge(1);
//     double var62 = var9.valueToJava2D(0.2d, var54, var61);
//     var6.trim(var54);
//     org.jfree.data.general.PieDataset var65 = null;
//     org.jfree.chart.plot.RingPlot var66 = new org.jfree.chart.plot.RingPlot(var65);
//     java.awt.Font var67 = var66.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var68 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var66);
//     org.jfree.chart.title.TextTitle var70 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var70.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var73 = var70.getFrame();
//     java.awt.Paint var74 = var70.getBackgroundPaint();
//     var68.addSubtitle((org.jfree.chart.title.Title)var70);
//     java.awt.Paint var76 = var68.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var78 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var68.removeSubtitle((org.jfree.chart.title.Title)var78);
//     org.jfree.chart.event.ChartChangeEventType var80 = null;
//     org.jfree.chart.event.ChartChangeEvent var81 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var68, var80);
//     org.jfree.chart.title.TextTitle var83 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var83.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var86 = var83.getFrame();
//     java.awt.Paint var87 = var83.getBackgroundPaint();
//     var83.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var68.setTitle(var83);
//     java.awt.geom.Rectangle2D var94 = var83.getBounds();
//     org.jfree.chart.entity.ChartEntity var96 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var94, "poly");
//     var6.trim(var94);
//     
//     // Checks the contract:  equals-hashcode on var26 and var66
//     assertTrue("Contract failed: equals-hashcode on var26 and var66", var26.equals(var66) ? var26.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var26
//     assertTrue("Contract failed: equals-hashcode on var66 and var26", var66.equals(var26) ? var66.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var68
//     assertTrue("Contract failed: equals-hashcode on var28 and var68", var28.equals(var68) ? var28.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var28
//     assertTrue("Contract failed: equals-hashcode on var68 and var28", var68.equals(var28) ? var68.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     java.awt.Stroke var3 = var1.getLabelOutlineStroke();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     double var6 = var5.getLabelLinkMargin();
//     var5.setLabelGap((-1.0d));
//     java.awt.Stroke var9 = var5.getLabelOutlineStroke();
//     java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var14 = var13.getGreen();
//     int var15 = var13.getRGB();
//     int var16 = var13.getAlpha();
//     float[] var17 = null;
//     float[] var18 = var13.getRGBComponents(var17);
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
//     java.awt.Font var24 = var23.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var27.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var30 = var27.getFrame();
//     java.awt.Paint var31 = var27.getBackgroundPaint();
//     var25.addSubtitle((org.jfree.chart.title.Title)var27);
//     java.awt.Paint var33 = var25.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var25.removeSubtitle((org.jfree.chart.title.Title)var35);
//     org.jfree.chart.event.ChartChangeEventType var37 = null;
//     org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var25, var37);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var40.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var43 = var40.getFrame();
//     java.awt.Paint var44 = var40.getBackgroundPaint();
//     var40.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var25.setTitle(var40);
//     java.awt.geom.Rectangle2D var51 = var40.getBounds();
//     java.awt.geom.AffineTransform var52 = null;
//     java.awt.RenderingHints var53 = null;
//     java.awt.PaintContext var54 = var13.createContext(var19, var20, var51, var52, var53);
//     var5.setBaseSectionOutlinePaint((java.awt.Paint)var13);
//     var1.setLabelLinkPaint((java.awt.Paint)var13);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     double var8 = var5.getContentYOffset();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     java.awt.Font var12 = var11.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var15.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var18 = var15.getFrame();
//     java.awt.Paint var19 = var15.getBackgroundPaint();
//     var13.addSubtitle((org.jfree.chart.title.Title)var15);
//     java.awt.Paint var21 = var13.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var13.removeSubtitle((org.jfree.chart.title.Title)var23);
//     var13.setBackgroundImageAlignment(0);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot(var27);
//     double var29 = var28.getLabelLinkMargin();
//     var28.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
//     double var33 = var32.getContentXOffset();
//     java.awt.Paint var34 = var32.getItemPaint();
//     java.awt.Font var35 = var32.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var36 = var32.getHorizontalAlignment();
//     var13.addSubtitle((org.jfree.chart.title.Title)var32);
//     org.jfree.chart.util.RectangleAnchor var38 = var32.getLegendItemGraphicAnchor();
//     var5.setLegendItemGraphicLocation(var38);
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var1
//     assertTrue("Contract failed: equals-hashcode on var28 and var1", var28.equals(var1) ? var28.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     boolean var2 = var1.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var1.setURLGenerator(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var1.addChangeListener(var5);
//     java.awt.Shape var7 = var1.getLegendItemShape();
//     org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var7, "TextAnchor.CENTER", "Category Plot");
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
//     var12.setVisible(false);
//     var12.setUpperMargin(0.2d);
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var19 = var18.getRange();
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
//     boolean var22 = var21.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var23 = null;
//     var21.setURLGenerator(var23);
//     org.jfree.chart.event.PlotChangeListener var25 = null;
//     var21.addChangeListener(var25);
//     java.awt.Shape var27 = var21.getLegendItemShape();
//     org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity(var27, "");
//     var18.setRightArrow(var27);
//     var12.setLeftArrow(var27);
//     var10.setArea(var27);
//     
//     // Checks the contract:  equals-hashcode on var1 and var21
//     assertTrue("Contract failed: equals-hashcode on var1 and var21", var1.equals(var21) ? var1.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var1
//     assertTrue("Contract failed: equals-hashcode on var21 and var1", var21.equals(var1) ? var21.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     org.jfree.chart.event.ChartProgressListener var11 = null;
//     var3.addProgressListener(var11);
//     org.jfree.chart.title.LegendTitle var13 = var3.getLegend();
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
//     double var16 = var15.getLabelLinkMargin();
//     var15.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     org.jfree.chart.event.TitleChangeListener var20 = null;
//     var19.addChangeListener(var20);
//     org.jfree.chart.block.BlockContainer var22 = null;
//     var19.setWrapper(var22);
//     org.jfree.chart.util.RectangleInsets var24 = var19.getPadding();
//     double var25 = var24.getLeft();
//     var3.setPadding(var24);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot(var27);
//     double var29 = var28.getLabelLinkMargin();
//     var28.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
//     double var33 = var32.getContentXOffset();
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.block.RectangleConstraint var35 = null;
//     org.jfree.chart.util.Size2D var36 = var32.arrange(var34, var35);
//     org.jfree.chart.util.RectangleEdge var37 = var32.getLegendItemGraphicEdge();
//     var3.addLegend(var32);
//     
//     // Checks the contract:  equals-hashcode on var15 and var28
//     assertTrue("Contract failed: equals-hashcode on var15 and var28", var15.equals(var28) ? var15.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var15
//     assertTrue("Contract failed: equals-hashcode on var28 and var15", var28.equals(var15) ? var28.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
    java.awt.Stroke var5 = var3.getLabelOutlineStroke();
    var0.setRangeCrosshairStroke(var5);
    double var7 = var0.getAnchorValue();
    org.jfree.chart.plot.CategoryMarker var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var8.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var11 = var8.getFrame();
//     java.awt.Paint var12 = var8.getBackgroundPaint();
//     var6.addSubtitle((org.jfree.chart.title.Title)var8);
//     java.awt.Paint var14 = var6.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var6.removeSubtitle((org.jfree.chart.title.Title)var16);
//     org.jfree.chart.event.ChartChangeEventType var18 = null;
//     org.jfree.chart.event.ChartChangeEvent var19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var6, var18);
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var21.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var24 = var21.getFrame();
//     java.awt.Paint var25 = var21.getBackgroundPaint();
//     var21.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var6.setTitle(var21);
//     java.awt.geom.Rectangle2D var32 = var21.getBounds();
//     var0.add((org.jfree.chart.block.Block)var21);
//     java.awt.Graphics2D var34 = null;
//     java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var39 = var38.getGreen();
//     int var40 = var38.getRGB();
//     int var41 = var38.getAlpha();
//     float[] var42 = null;
//     float[] var43 = var38.getRGBComponents(var42);
//     java.awt.image.ColorModel var44 = null;
//     java.awt.Rectangle var45 = null;
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     java.awt.Font var49 = var48.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var48);
//     org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var52.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var55 = var52.getFrame();
//     java.awt.Paint var56 = var52.getBackgroundPaint();
//     var50.addSubtitle((org.jfree.chart.title.Title)var52);
//     java.awt.Paint var58 = var50.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var50.removeSubtitle((org.jfree.chart.title.Title)var60);
//     org.jfree.chart.event.ChartChangeEventType var62 = null;
//     org.jfree.chart.event.ChartChangeEvent var63 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var50, var62);
//     org.jfree.chart.title.TextTitle var65 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var65.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var68 = var65.getFrame();
//     java.awt.Paint var69 = var65.getBackgroundPaint();
//     var65.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var50.setTitle(var65);
//     java.awt.geom.Rectangle2D var76 = var65.getBounds();
//     java.awt.geom.AffineTransform var77 = null;
//     java.awt.RenderingHints var78 = null;
//     java.awt.PaintContext var79 = var38.createContext(var44, var45, var76, var77, var78);
//     var0.draw(var34, (java.awt.geom.Rectangle2D)var45);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.LegendItemSource[] var6 = var5.getSources();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 0.0d);
//     org.jfree.data.Range var11 = var10.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var13 = var10.toFixedHeight(0.2d);
//     org.jfree.data.Range var14 = var13.getWidthRange();
//     org.jfree.chart.util.Size2D var15 = var5.arrange(var7, var13);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.setRangeCrosshairLockedOnData(false);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
//     java.awt.Font var24 = var23.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var27.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var30 = var27.getFrame();
//     java.awt.Paint var31 = var27.getBackgroundPaint();
//     var25.addSubtitle((org.jfree.chart.title.Title)var27);
//     java.awt.Paint var33 = var25.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var25.removeSubtitle((org.jfree.chart.title.Title)var35);
//     org.jfree.chart.event.ChartChangeEventType var37 = null;
//     org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var25, var37);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var40.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var43 = var40.getFrame();
//     java.awt.Paint var44 = var40.getBackgroundPaint();
//     var40.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var25.setTitle(var40);
//     java.awt.geom.Rectangle2D var51 = var40.getBounds();
//     java.awt.geom.Point2D var52 = null;
//     org.jfree.chart.plot.PlotState var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     var17.draw(var20, var51, var52, var53, var54);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.RingPlot var57 = new org.jfree.chart.plot.RingPlot(var56);
//     java.awt.Font var58 = var57.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var57);
//     org.jfree.chart.title.TextTitle var61 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var61.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var64 = var61.getFrame();
//     java.awt.Paint var65 = var61.getBackgroundPaint();
//     var59.addSubtitle((org.jfree.chart.title.Title)var61);
//     java.awt.Paint var67 = var59.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var69 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var59.removeSubtitle((org.jfree.chart.title.Title)var69);
//     var59.setBackgroundImageAlignment(0);
//     org.jfree.data.general.PieDataset var73 = null;
//     org.jfree.chart.plot.RingPlot var74 = new org.jfree.chart.plot.RingPlot(var73);
//     double var75 = var74.getLabelLinkMargin();
//     var74.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var78 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var74);
//     double var79 = var78.getContentXOffset();
//     java.awt.Paint var80 = var78.getItemPaint();
//     java.awt.Font var81 = var78.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var82 = var78.getHorizontalAlignment();
//     var59.addSubtitle((org.jfree.chart.title.Title)var78);
//     java.awt.Image var84 = var59.getBackgroundImage();
//     java.lang.Object var85 = var5.draw(var16, var51, (java.lang.Object)var59);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Pie Plot", var3);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var1.setToolTipText("ThreadContext");
//     java.lang.Object var4 = var1.clone();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getLabelLinkMargin();
//     var11.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
//     double var16 = var15.getContentXOffset();
//     java.awt.Paint var17 = var15.getItemPaint();
//     java.awt.Font var18 = var15.getItemFont();
//     var6.setLabelFont(var18);
//     java.awt.Paint var20 = var6.getLabelPaint();
//     java.awt.Paint var21 = var6.getPaint();
//     boolean var22 = var1.equals((java.lang.Object)var6);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var25 = null;
//     var23.setRangeAxisLocation(1, var25, false);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var31 = null;
//     var29.setRangeAxisLocation(1, var31, false);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.RingPlot var35 = new org.jfree.chart.plot.RingPlot(var34);
//     boolean var36 = var35.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var37 = null;
//     var35.setURLGenerator(var37);
//     org.jfree.chart.event.PlotChangeListener var39 = null;
//     var35.addChangeListener(var39);
//     java.awt.Shape var41 = var35.getLegendItemShape();
//     java.awt.Stroke var42 = var35.getBaseSectionOutlineStroke();
//     var29.setDomainGridlineStroke(var42);
//     org.jfree.chart.axis.CategoryAxis3D var44 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var45 = var44.getLowerMargin();
//     var29.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var44);
//     java.lang.Object var47 = var44.clone();
//     var23.setDomainAxis(10, (org.jfree.chart.axis.CategoryAxis)var44);
//     org.jfree.data.general.PieDataset var49 = null;
//     org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot(var49);
//     double var51 = var50.getLabelLinkMargin();
//     var50.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
//     org.jfree.chart.event.TitleChangeListener var55 = null;
//     var54.addChangeListener(var55);
//     org.jfree.chart.block.BlockContainer var57 = null;
//     var54.setWrapper(var57);
//     org.jfree.chart.util.RectangleInsets var59 = var54.getPadding();
//     var44.setLabelInsets(var59);
//     var6.setLabelOffset(var59);
//     
//     // Checks the contract:  equals-hashcode on var8 and var35
//     assertTrue("Contract failed: equals-hashcode on var8 and var35", var8.equals(var35) ? var8.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var50
//     assertTrue("Contract failed: equals-hashcode on var11 and var50", var11.equals(var50) ? var11.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var8
//     assertTrue("Contract failed: equals-hashcode on var35 and var8", var35.equals(var8) ? var35.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var11
//     assertTrue("Contract failed: equals-hashcode on var50 and var11", var50.equals(var11) ? var50.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
    double var3 = var2.getHeight();
    org.jfree.data.Range var4 = var2.getHeightRange();
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 4.0d);
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var5, 0.025d);
    org.jfree.chart.block.RectangleConstraint var10 = var2.toRangeWidth(var9);
    java.lang.String var11 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Range[0.025,0.025]"+ "'", var11.equals("Range[0.025,0.025]"));

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    var0.clear();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    boolean var4 = var3.isSubplot();
    boolean var6 = var3.equals((java.lang.Object)"hi!");
    java.awt.Image var7 = var3.getBackgroundImage();
    java.awt.Stroke var8 = var3.getBaseSectionOutlineStroke();
    org.jfree.chart.util.Rotation var9 = var3.getDirection();
    double var10 = var9.getFactor();
    boolean var11 = var0.equals((java.lang.Object)var9);
    java.lang.String var12 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Rotation.CLOCKWISE"+ "'", var12.equals("Rotation.CLOCKWISE"));

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     double var8 = var5.getContentYOffset();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     java.awt.Font var13 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var16.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var19 = var16.getFrame();
//     java.awt.Paint var20 = var16.getBackgroundPaint();
//     var14.addSubtitle((org.jfree.chart.title.Title)var16);
//     java.awt.Paint var22 = var14.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var14.removeSubtitle((org.jfree.chart.title.Title)var24);
//     org.jfree.chart.event.ChartChangeEventType var26 = null;
//     org.jfree.chart.event.ChartChangeEvent var27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var14, var26);
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var29.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var32 = var29.getFrame();
//     java.awt.Paint var33 = var29.getBackgroundPaint();
//     var29.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var14.setTitle(var29);
//     java.awt.geom.Rectangle2D var40 = var29.getBounds();
//     org.jfree.chart.entity.ChartEntity var42 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var40, "poly");
//     var5.draw(var9, var40);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var7 = null;
//     var5.setRangeAxisLocation(1, var7, false);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     boolean var12 = var11.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var13 = null;
//     var11.setURLGenerator(var13);
//     org.jfree.chart.event.PlotChangeListener var15 = null;
//     var11.addChangeListener(var15);
//     java.awt.Shape var17 = var11.getLegendItemShape();
//     java.awt.Stroke var18 = var11.getBaseSectionOutlineStroke();
//     var5.setDomainGridlineStroke(var18);
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
//     double var24 = var23.getLabelLinkMargin();
//     var23.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
//     double var28 = var27.getContentXOffset();
//     java.awt.Paint var29 = var27.getItemPaint();
//     java.awt.Font var30 = var27.getItemFont();
//     var21.setLabelFont(var30);
//     org.jfree.chart.util.Layer var32 = null;
//     var5.addRangeMarker((org.jfree.chart.plot.Marker)var21, var32);
//     java.awt.Paint var34 = var21.getPaint();
//     java.awt.Paint var35 = var21.getOutlinePaint();
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var0.removeRangeMarker(255, (org.jfree.chart.plot.Marker)var21, var36);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.setVisible(false);
//     var1.setUpperMargin(0.2d);
//     float var6 = var1.getTickMarkInsideLength();
//     var1.setAutoRangeMinimumSize(1.0E-5d);
//     var1.setLabelURL("Category Plot");
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearAnnotations();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var21 = var17.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var23.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var26 = var17.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var31 = var27.getDomainAxisLocation(0);
//     var17.setRangeAxisLocation(var31, false);
//     var14.setDomainAxisLocation(15, var31, true);
//     java.awt.Graphics2D var36 = null;
//     java.awt.Color var40 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var41 = var40.getGreen();
//     int var42 = var40.getRGB();
//     int var43 = var40.getAlpha();
//     float[] var44 = null;
//     float[] var45 = var40.getRGBComponents(var44);
//     java.awt.image.ColorModel var46 = null;
//     java.awt.Rectangle var47 = null;
//     org.jfree.data.general.PieDataset var49 = null;
//     org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot(var49);
//     java.awt.Font var51 = var50.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var50);
//     org.jfree.chart.title.TextTitle var54 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var54.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var57 = var54.getFrame();
//     java.awt.Paint var58 = var54.getBackgroundPaint();
//     var52.addSubtitle((org.jfree.chart.title.Title)var54);
//     java.awt.Paint var60 = var52.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var52.removeSubtitle((org.jfree.chart.title.Title)var62);
//     org.jfree.chart.event.ChartChangeEventType var64 = null;
//     org.jfree.chart.event.ChartChangeEvent var65 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var52, var64);
//     org.jfree.chart.title.TextTitle var67 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var67.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var70 = var67.getFrame();
//     java.awt.Paint var71 = var67.getBackgroundPaint();
//     var67.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var52.setTitle(var67);
//     java.awt.geom.Rectangle2D var78 = var67.getBounds();
//     java.awt.geom.AffineTransform var79 = null;
//     java.awt.RenderingHints var80 = null;
//     java.awt.PaintContext var81 = var40.createContext(var46, var47, var78, var79, var80);
//     var14.drawBackgroundImage(var36, var78);
//     org.jfree.chart.entity.ChartEntity var84 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var78, "ThreadContext");
//     org.jfree.chart.plot.CategoryPlot var85 = new org.jfree.chart.plot.CategoryPlot();
//     var85.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var88 = var85.getRangeAxisEdge(1);
//     org.jfree.chart.plot.PlotRenderingInfo var89 = null;
//     org.jfree.chart.axis.AxisState var90 = var1.draw(var11, 2.14d, var13, var78, var88, var89);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    int var5 = var0.getDomainAxisCount();
    org.jfree.chart.event.RendererChangeEvent var6 = null;
    var0.rendererChanged(var6);
    org.jfree.chart.util.RectangleEdge var9 = var0.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var0.zoomDomainAxes(100.0d, var11, var12, false);
    java.awt.Image var15 = null;
    var0.setBackgroundImage(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(0);
    int var2 = var1.getItemCount();
    var1.distributeLabels(1.0E-8d, 1.0E-8d);
    java.lang.String var6 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     double var8 = var5.getContentYOffset();
//     org.jfree.chart.util.RectangleAnchor var9 = var5.getLegendItemGraphicLocation();
//     double var10 = var5.getHeight();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     java.awt.Font var13 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var16.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var19 = var16.getFrame();
//     java.awt.Paint var20 = var16.getBackgroundPaint();
//     var14.addSubtitle((org.jfree.chart.title.Title)var16);
//     org.jfree.chart.event.ChartProgressListener var22 = null;
//     var14.addProgressListener(var22);
//     org.jfree.chart.title.LegendTitle var24 = var14.getLegend();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     double var27 = var26.getLabelLinkMargin();
//     var26.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var30.addChangeListener(var31);
//     org.jfree.chart.block.BlockContainer var33 = null;
//     var30.setWrapper(var33);
//     org.jfree.chart.util.RectangleInsets var35 = var30.getPadding();
//     double var36 = var35.getLeft();
//     var14.setPadding(var35);
//     var5.setLegendItemGraphicPadding(var35);
//     
//     // Checks the contract:  equals-hashcode on var1 and var26
//     assertTrue("Contract failed: equals-hashcode on var1 and var26", var1.equals(var26) ? var1.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var1
//     assertTrue("Contract failed: equals-hashcode on var26 and var1", var26.equals(var1) ? var26.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var1.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var4 = var1.getFrame();
//     java.awt.Paint var5 = var1.getBackgroundPaint();
//     var1.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var1.setToolTipText("Pie 3D Plot");
//     org.jfree.chart.text.TextBlock var13 = new org.jfree.chart.text.TextBlock();
//     java.util.List var14 = var13.getLines();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     double var17 = var16.getLabelLinkMargin();
//     var16.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
//     double var21 = var20.getContentXOffset();
//     java.awt.Paint var22 = var20.getItemPaint();
//     java.awt.Font var23 = var20.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var24 = var20.getHorizontalAlignment();
//     var13.setLineAlignment(var24);
//     boolean var26 = var1.equals((java.lang.Object)var24);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot(var27);
//     java.awt.Font var29 = var28.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.RingPlot var32 = new org.jfree.chart.plot.RingPlot(var31);
//     double var33 = var32.getLabelLinkMargin();
//     var32.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var32);
//     org.jfree.chart.event.TitleChangeListener var37 = null;
//     var36.addChangeListener(var37);
//     org.jfree.chart.block.BlockContainer var39 = null;
//     var36.setWrapper(var39);
//     var30.addSubtitle((org.jfree.chart.title.Title)var36);
//     org.jfree.chart.util.VerticalAlignment var42 = var36.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var24, var42, 1.0E-8d, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var16 and var32
//     assertTrue("Contract failed: equals-hashcode on var16 and var32", var16.equals(var32) ? var16.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var16
//     assertTrue("Contract failed: equals-hashcode on var32 and var16", var32.equals(var16) ? var32.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
    boolean var2 = var1.getExpandToFitSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var3 = var2.getFont();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var6 = null;
//     var4.setRangeAxisLocation(1, var6, false);
//     var4.setAnchorValue(0.025d, false);
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     double var14 = var13.getLabelLinkMargin();
//     var13.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     org.jfree.chart.event.TitleChangeListener var18 = null;
//     var17.addChangeListener(var18);
//     org.jfree.chart.block.BlockContainer var20 = null;
//     var17.setWrapper(var20);
//     org.jfree.chart.util.RectangleInsets var22 = var17.getPadding();
//     var4.setInsets(var22, false);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var27 = null;
//     org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot(var25, var26, var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     var28.setDataset(var29);
//     java.awt.Paint var31 = var28.getRadiusGridlinePaint();
//     org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder(var22, var31);
//     java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var37 = var36.getAlpha();
//     java.awt.Color var38 = var36.brighter();
//     boolean var39 = var32.equals((java.lang.Object)var38);
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.text.G2TextMeasurer var43 = new org.jfree.chart.text.G2TextMeasurer(var42);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[0.025,0.025]", var3, (java.awt.Paint)var38, 1.0f, 4, (org.jfree.chart.text.TextMeasurer)var43);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    org.jfree.chart.event.PlotChangeEvent var3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var2);
    java.awt.Stroke var4 = var2.getLabelOutlineStroke();
    java.awt.Paint var5 = var2.getSeparatorPaint();
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
    java.awt.Paint var11 = var10.getPaint();
    var2.setBaseSectionPaint(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var0, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    java.awt.Stroke var3 = var1.getLabelOutlineStroke();
    java.awt.Paint var4 = var1.getSeparatorPaint();
    boolean var5 = var1.isCircular();
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeparatorPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var4 = var0.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var9 = var0.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var14 = var10.getDomainAxisLocation(0);
//     var0.setRangeAxisLocation(var14, false);
//     org.jfree.chart.axis.CategoryAnchor var17 = var0.getDomainGridlinePosition();
//     org.jfree.chart.event.MarkerChangeEvent var18 = null;
//     var0.markerChanged(var18);
//     var0.mapDatasetToDomainAxis(10, (-16777216));
//     java.awt.Stroke var23 = var0.getRangeGridlineStroke();
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot(var26);
//     boolean var28 = var25.equals((java.lang.Object)var27);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     double var31 = var30.getLabelLinkMargin();
//     var30.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     double var35 = var34.getContentXOffset();
//     java.awt.Paint var36 = var34.getItemPaint();
//     java.awt.Font var37 = var34.getItemFont();
//     var25.setLabelFont(var37);
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var25, var39);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Range[0.025,0.025]", var1);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     org.jfree.chart.event.PlotChangeEvent var3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     var1.setLabelGap(4.0d);
//     double var6 = var1.getShadowYOffset();
//     java.lang.Comparable var7 = null;
//     double var8 = var1.getExplodePercent(var7);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setVisible(false);
    var1.setUpperMargin(0.2d);
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var8 = var7.getRange();
    java.lang.Object var9 = var7.clone();
    org.jfree.chart.axis.NumberTickUnit var10 = var7.getTickUnit();
    var1.setTickUnit(var10);
    double var12 = var1.getLabelAngle();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var15 = var14.getRange();
    var1.setRangeWithMargins(var15, false, true);
    org.jfree.data.Range var19 = null;
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 4.0d);
    org.jfree.data.Range var23 = org.jfree.data.Range.expandToInclude(var19, 0.025d);
    var1.setRange(var23);
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var27 = var26.getRange();
    double var28 = var27.getCentralValue();
    var1.setRange(var27, true, false);
    var1.centerRange(10.0d);
    var1.setFixedDimension(0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.5d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    double var23 = var22.getContentXOffset();
    java.awt.Paint var24 = var22.getItemPaint();
    java.awt.Font var25 = var22.getItemFont();
    var16.setLabelFont(var25);
    org.jfree.chart.util.Layer var27 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
    double var29 = var0.getRangeCrosshairValue();
    var0.setWeight(100);
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.event.MarkerChangeEvent var35 = null;
    var34.notifyListeners(var35);
    org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var38 = var37.getNextFillPaint();
    var34.setPaint(var38);
    org.jfree.chart.util.Layer var40 = null;
    boolean var41 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var34, var40);
    int var42 = var0.getDatasetCount();
    var0.setRangeGridlinesVisible(false);
    var0.clearDomainMarkers(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var1.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var4 = var1.getFrame();
//     java.awt.Paint var5 = var1.getBackgroundPaint();
//     var1.setID("");
//     var1.setText("Pie Plot");
//     java.awt.Graphics2D var10 = null;
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     double var13 = var12.getLabelLinkMargin();
//     var12.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getPadding();
//     double var18 = var17.getRight();
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var21 = var20.getRange();
//     double var22 = var20.getAutoRangeMinimumSize();
//     java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var28 = var27.getGreen();
//     int var29 = var27.getRGB();
//     int var30 = var27.getAlpha();
//     float[] var31 = null;
//     float[] var32 = var27.getRGBComponents(var31);
//     java.awt.image.ColorModel var33 = null;
//     java.awt.Rectangle var34 = null;
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot(var36);
//     java.awt.Font var38 = var37.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var37);
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var41.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var44 = var41.getFrame();
//     java.awt.Paint var45 = var41.getBackgroundPaint();
//     var39.addSubtitle((org.jfree.chart.title.Title)var41);
//     java.awt.Paint var47 = var39.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var39.removeSubtitle((org.jfree.chart.title.Title)var49);
//     org.jfree.chart.event.ChartChangeEventType var51 = null;
//     org.jfree.chart.event.ChartChangeEvent var52 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var39, var51);
//     org.jfree.chart.title.TextTitle var54 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var54.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var57 = var54.getFrame();
//     java.awt.Paint var58 = var54.getBackgroundPaint();
//     var54.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var39.setTitle(var54);
//     java.awt.geom.Rectangle2D var65 = var54.getBounds();
//     java.awt.geom.AffineTransform var66 = null;
//     java.awt.RenderingHints var67 = null;
//     java.awt.PaintContext var68 = var27.createContext(var33, var34, var65, var66, var67);
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot();
//     var69.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var72 = var69.getRangeAxisEdge(1);
//     double var73 = var20.valueToJava2D(0.2d, var65, var72);
//     var17.trim(var65);
//     org.jfree.data.general.PieDataset var75 = null;
//     org.jfree.chart.plot.RingPlot var76 = new org.jfree.chart.plot.RingPlot(var75);
//     java.awt.Font var77 = var76.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var78 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var76);
//     org.jfree.chart.title.TextTitle var80 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var80.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var83 = var80.getFrame();
//     java.awt.Paint var84 = var80.getBackgroundPaint();
//     var78.addSubtitle((org.jfree.chart.title.Title)var80);
//     java.awt.Paint var86 = var78.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var88 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var78.removeSubtitle((org.jfree.chart.title.Title)var88);
//     java.lang.Object var90 = var1.draw(var10, var65, (java.lang.Object)var88);
//     
//     // Checks the contract:  equals-hashcode on var37 and var76
//     assertTrue("Contract failed: equals-hashcode on var37 and var76", var37.equals(var76) ? var37.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var37
//     assertTrue("Contract failed: equals-hashcode on var76 and var37", var76.equals(var37) ? var76.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("", (-16777216), (-16777216));
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.chart.axis.ValueAxis var5 = var3.getAxis();
//     org.jfree.data.xy.XYDataset var6 = var3.getDataset();
//     double var7 = var3.getMaxRadius();
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     var0.clearRangeAxes();
//     boolean var2 = var0.isDomainCrosshairLockedOnData();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var5 = null;
//     var3.setRangeAxisLocation(1, var5, false);
//     var3.setAnchorValue(0.025d, false);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     double var13 = var12.getLabelLinkMargin();
//     var12.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
//     org.jfree.chart.event.TitleChangeListener var17 = null;
//     var16.addChangeListener(var17);
//     org.jfree.chart.block.BlockContainer var19 = null;
//     var16.setWrapper(var19);
//     org.jfree.chart.util.RectangleInsets var21 = var16.getPadding();
//     var3.setInsets(var21, false);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var26 = null;
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var24, var25, var26);
//     org.jfree.data.xy.XYDataset var28 = null;
//     var27.setDataset(var28);
//     java.awt.Paint var30 = var27.getRadiusGridlinePaint();
//     org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(var21, var30);
//     java.awt.Color var35 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var36 = var35.getAlpha();
//     java.awt.Color var37 = var35.brighter();
//     boolean var38 = var31.equals((java.lang.Object)var37);
//     var0.setDomainGridlinePaint((java.awt.Paint)var37);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var44 = null;
//     var42.setRangeAxisLocation(1, var44, false);
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     boolean var49 = var48.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var50 = null;
//     var48.setURLGenerator(var50);
//     org.jfree.chart.event.PlotChangeListener var52 = null;
//     var48.addChangeListener(var52);
//     java.awt.Shape var54 = var48.getLegendItemShape();
//     java.awt.Stroke var55 = var48.getBaseSectionOutlineStroke();
//     var42.setDomainGridlineStroke(var55);
//     org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var59 = null;
//     org.jfree.chart.plot.RingPlot var60 = new org.jfree.chart.plot.RingPlot(var59);
//     double var61 = var60.getLabelLinkMargin();
//     var60.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var60);
//     double var65 = var64.getContentXOffset();
//     java.awt.Paint var66 = var64.getItemPaint();
//     java.awt.Font var67 = var64.getItemFont();
//     var58.setLabelFont(var67);
//     org.jfree.chart.util.Layer var69 = null;
//     var42.addRangeMarker((org.jfree.chart.plot.Marker)var58, var69);
//     java.awt.Stroke var71 = var42.getDomainGridlineStroke();
//     var41.setStroke(var71);
//     var0.setDomainGridlineStroke(var71);
//     
//     // Checks the contract:  equals-hashcode on var12 and var60
//     assertTrue("Contract failed: equals-hashcode on var12 and var60", var12.equals(var60) ? var12.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var12
//     assertTrue("Contract failed: equals-hashcode on var60 and var12", var60.equals(var12) ? var60.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.0d, (-13.95d), 2.00000001d, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairLockedOnData(false);
    double var3 = var0.getRangeCrosshairValue();
    org.jfree.chart.util.SortOrder var4 = var0.getColumnRenderingOrder();
    java.awt.Image var5 = null;
    var0.setBackgroundImage(var5);
    org.jfree.data.general.DatasetChangeEvent var7 = null;
    var0.datasetChanged(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
//     java.util.List var2 = var1.getLines();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     var1.draw(var3, (-1.0f), 0.0f, var6, 1.0f, 100.0f, 0.05d);
//     org.jfree.chart.util.HorizontalAlignment var11 = var1.getLineAlignment();
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var14 = null;
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot(var12, var13, var14);
//     java.awt.Font var16 = var15.getAngleLabelFont();
//     boolean var17 = var1.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var22 = var21.getAlpha();
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.text.G2TextMeasurer var26 = new org.jfree.chart.text.G2TextMeasurer(var25);
//     org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[0.025,0.025]", var16, (java.awt.Paint)var21, 10.0f, (-1), (org.jfree.chart.text.TextMeasurer)var26);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
    java.awt.Stroke var5 = var3.getLabelOutlineStroke();
    var0.setRangeCrosshairStroke(var5);
    org.jfree.chart.event.MarkerChangeEvent var7 = null;
    var0.markerChanged(var7);
    org.jfree.chart.plot.CategoryMarker var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 4);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var5.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
//     java.awt.Paint var9 = var5.getBackgroundPaint();
//     var3.addSubtitle((org.jfree.chart.title.Title)var5);
//     java.awt.Paint var11 = var3.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var3.removeSubtitle((org.jfree.chart.title.Title)var13);
//     var3.setBackgroundImageAlignment(0);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     double var23 = var22.getContentXOffset();
//     java.awt.Paint var24 = var22.getItemPaint();
//     java.awt.Font var25 = var22.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var26 = var22.getHorizontalAlignment();
//     var3.addSubtitle((org.jfree.chart.title.Title)var22);
//     org.jfree.chart.util.RectangleAnchor var28 = var22.getLegendItemGraphicAnchor();
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var31 = null;
//     var29.setRangeAxisLocation(1, var31, false);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.RingPlot var35 = new org.jfree.chart.plot.RingPlot(var34);
//     boolean var36 = var35.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var37 = null;
//     var35.setURLGenerator(var37);
//     org.jfree.chart.event.PlotChangeListener var39 = null;
//     var35.addChangeListener(var39);
//     java.awt.Shape var41 = var35.getLegendItemShape();
//     java.awt.Stroke var42 = var35.getBaseSectionOutlineStroke();
//     var29.setDomainGridlineStroke(var42);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.RingPlot var47 = new org.jfree.chart.plot.RingPlot(var46);
//     double var48 = var47.getLabelLinkMargin();
//     var47.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
//     double var52 = var51.getContentXOffset();
//     java.awt.Paint var53 = var51.getItemPaint();
//     java.awt.Font var54 = var51.getItemFont();
//     var45.setLabelFont(var54);
//     org.jfree.chart.util.Layer var56 = null;
//     var29.addRangeMarker((org.jfree.chart.plot.Marker)var45, var56);
//     org.jfree.chart.axis.CategoryAxis3D var59 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var59.setMaximumCategoryLabelWidthRatio(0.0f);
//     java.awt.Paint var63 = var59.getTickLabelPaint((java.lang.Comparable)(-16777216));
//     var45.setOutlinePaint(var63);
//     boolean var65 = var28.equals((java.lang.Object)var45);
//     
//     // Checks the contract:  equals-hashcode on var1 and var35
//     assertTrue("Contract failed: equals-hashcode on var1 and var35", var1.equals(var35) ? var1.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var47
//     assertTrue("Contract failed: equals-hashcode on var18 and var47", var18.equals(var47) ? var18.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var1
//     assertTrue("Contract failed: equals-hashcode on var35 and var1", var35.equals(var1) ? var35.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var18
//     assertTrue("Contract failed: equals-hashcode on var47 and var18", var47.equals(var18) ? var47.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    double var15 = var0.getAnchorValue();
    org.jfree.chart.axis.AxisLocation var16 = var0.getRangeAxisLocation();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var0.setRangeAxisLocation(10, var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxis((-1), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    java.awt.geom.Rectangle2D var2 = var1.getExplodedPieArea();
    var1.setPieWRadius(1.0d);
    double var5 = var1.getPieWRadius();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var6.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var9 = var6.getFrame();
//     java.awt.Paint var10 = var6.getBackgroundPaint();
//     var4.addSubtitle((org.jfree.chart.title.Title)var6);
//     java.awt.Paint var12 = var4.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var4.removeSubtitle((org.jfree.chart.title.Title)var14);
//     org.jfree.chart.event.ChartChangeEventType var16 = null;
//     org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var4, var16);
//     int var18 = var4.getSubtitleCount();
//     org.jfree.chart.text.TextBlock var19 = new org.jfree.chart.text.TextBlock();
//     java.util.List var20 = var19.getLines();
//     java.util.List var21 = var19.getLines();
//     var4.setSubtitles(var21);
//     var4.setBackgroundImageAlignment(4);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     java.awt.Font var27 = var26.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var26);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var30.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var33 = var30.getFrame();
//     java.awt.Paint var34 = var30.getBackgroundPaint();
//     var28.addSubtitle((org.jfree.chart.title.Title)var30);
//     java.awt.Paint var36 = var28.getBackgroundPaint();
//     var4.setBorderPaint(var36);
//     
//     // Checks the contract:  equals-hashcode on var2 and var26
//     assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)90.0d);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     double var13 = var12.getContentXOffset();
//     java.awt.Paint var14 = var12.getItemPaint();
//     java.awt.Font var15 = var12.getItemFont();
//     var6.setLabelFont(var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
//     var3.removeSubtitle((org.jfree.chart.title.Title)var17);
//     java.awt.Image var19 = null;
//     var3.setBackgroundImage(var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.clearDomainAxes();
//     java.awt.Graphics2D var24 = null;
//     java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var29 = var28.getGreen();
//     int var30 = var28.getRGB();
//     int var31 = var28.getAlpha();
//     float[] var32 = null;
//     float[] var33 = var28.getRGBComponents(var32);
//     java.awt.image.ColorModel var34 = null;
//     java.awt.Rectangle var35 = null;
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.RingPlot var38 = new org.jfree.chart.plot.RingPlot(var37);
//     java.awt.Font var39 = var38.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var38);
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var42.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var45 = var42.getFrame();
//     java.awt.Paint var46 = var42.getBackgroundPaint();
//     var40.addSubtitle((org.jfree.chart.title.Title)var42);
//     java.awt.Paint var48 = var40.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var40.removeSubtitle((org.jfree.chart.title.Title)var50);
//     org.jfree.chart.event.ChartChangeEventType var52 = null;
//     org.jfree.chart.event.ChartChangeEvent var53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var40, var52);
//     org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var55.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var58 = var55.getFrame();
//     java.awt.Paint var59 = var55.getBackgroundPaint();
//     var55.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var40.setTitle(var55);
//     java.awt.geom.Rectangle2D var66 = var55.getBounds();
//     java.awt.geom.AffineTransform var67 = null;
//     java.awt.RenderingHints var68 = null;
//     java.awt.PaintContext var69 = var28.createContext(var34, var35, var66, var67, var68);
//     java.awt.geom.Point2D var70 = null;
//     org.jfree.chart.plot.PlotState var71 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     var22.draw(var24, var66, var70, var71, var72);
//     org.jfree.chart.ChartRenderingInfo var74 = null;
//     var3.draw(var21, var66, var74);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.025, height=10.0]", var1, var2, var3);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var1.setMaximumCategoryLabelWidthRatio(0.0f);
//     double var4 = var1.getLowerMargin();
//     java.lang.Comparable var6 = null;
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     java.awt.Font var12 = var11.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var15.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var18 = var15.getFrame();
//     java.awt.Paint var19 = var15.getBackgroundPaint();
//     var13.addSubtitle((org.jfree.chart.title.Title)var15);
//     java.awt.Paint var21 = var13.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var13.removeSubtitle((org.jfree.chart.title.Title)var23);
//     org.jfree.chart.event.ChartChangeEventType var25 = null;
//     org.jfree.chart.event.ChartChangeEvent var26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var13, var25);
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var28.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var31 = var28.getFrame();
//     java.awt.Paint var32 = var28.getBackgroundPaint();
//     var28.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var13.setTitle(var28);
//     java.awt.geom.Rectangle2D var39 = var28.getBounds();
//     org.jfree.chart.entity.ChartEntity var41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var39, "poly");
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot(var42);
//     double var44 = var43.getLabelLinkMargin();
//     var43.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
//     double var48 = var47.getContentXOffset();
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.block.RectangleConstraint var50 = null;
//     org.jfree.chart.util.Size2D var51 = var47.arrange(var49, var50);
//     org.jfree.chart.util.RectangleEdge var52 = var47.getLegendItemGraphicEdge();
//     double var53 = var1.getCategorySeriesMiddle((java.lang.Comparable)(-1L), var6, var7, 0.5d, var39, var52);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     double var4 = var1.getLabelLinkMargin();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     org.jfree.data.general.DatasetChangeEvent var7 = null;
//     var6.datasetChanged(var7);
//     org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var11 = null;
//     var10.addFragment(var11);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.chart.renderer.RendererState var14 = new org.jfree.chart.renderer.RendererState(var13);
//     boolean var15 = var10.equals((java.lang.Object)var13);
//     boolean var16 = var6.equals((java.lang.Object)var10);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     var18.setInnerSeparatorExtension(0.025d);
//     org.jfree.chart.labels.PieSectionLabelGenerator var25 = var18.getLegendLabelGenerator();
//     var6.setLabelGenerator(var25);
//     var1.setLabelGenerator(var25);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    java.awt.Image var6 = null;
    var1.setBackgroundImage(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     org.jfree.chart.event.PlotChangeEvent var3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.clearAnnotations();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var17 = var13.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var19.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var22 = var13.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var27 = var23.getDomainAxisLocation(0);
//     var13.setRangeAxisLocation(var27, false);
//     var10.setDomainAxisLocation(15, var27, true);
//     java.awt.Graphics2D var32 = null;
//     java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var37 = var36.getGreen();
//     int var38 = var36.getRGB();
//     int var39 = var36.getAlpha();
//     float[] var40 = null;
//     float[] var41 = var36.getRGBComponents(var40);
//     java.awt.image.ColorModel var42 = null;
//     java.awt.Rectangle var43 = null;
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.RingPlot var46 = new org.jfree.chart.plot.RingPlot(var45);
//     java.awt.Font var47 = var46.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var46);
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var50.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var53 = var50.getFrame();
//     java.awt.Paint var54 = var50.getBackgroundPaint();
//     var48.addSubtitle((org.jfree.chart.title.Title)var50);
//     java.awt.Paint var56 = var48.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var58 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var48.removeSubtitle((org.jfree.chart.title.Title)var58);
//     org.jfree.chart.event.ChartChangeEventType var60 = null;
//     org.jfree.chart.event.ChartChangeEvent var61 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var48, var60);
//     org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var63.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var66 = var63.getFrame();
//     java.awt.Paint var67 = var63.getBackgroundPaint();
//     var63.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var48.setTitle(var63);
//     java.awt.geom.Rectangle2D var74 = var63.getBounds();
//     java.awt.geom.AffineTransform var75 = null;
//     java.awt.RenderingHints var76 = null;
//     java.awt.PaintContext var77 = var36.createContext(var42, var43, var74, var75, var76);
//     var10.drawBackgroundImage(var32, var74);
//     java.awt.geom.Point2D var79 = null;
//     org.jfree.chart.plot.PlotState var80 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var81 = null;
//     var8.draw(var9, var74, var79, var80, var81);
//     var1.drawBackgroundImage(var4, var74);
//     
//     // Checks the contract:  equals-hashcode on var1 and var46
//     assertTrue("Contract failed: equals-hashcode on var1 and var46", var1.equals(var46) ? var1.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var1
//     assertTrue("Contract failed: equals-hashcode on var46 and var1", var46.equals(var1) ? var46.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = null;
    var3.setDataset(var4);
    java.awt.Paint var6 = var3.getRadiusGridlinePaint();
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    var8.setVisible(false);
    var8.setUpperMargin(0.2d);
    float var13 = var8.getTickMarkInsideLength();
    var8.setAutoRangeMinimumSize(1.0E-5d);
    var3.setAxis((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var19 = var18.getRange();
    double var20 = var19.getCentralValue();
    org.jfree.data.Range var22 = org.jfree.data.Range.shift(var19, (-15.95d));
    var8.setRangeWithMargins(var19);
    java.awt.Paint var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setAxisLinePaint(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1);
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.clearAnnotations();
//     var3.clearDomainAxes();
//     int var6 = var3.getBackgroundImageAlignment();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var11 = var7.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var13.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var16 = var7.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var21 = var17.getDomainAxisLocation(0);
//     var7.setRangeAxisLocation(var21, false);
//     org.jfree.chart.axis.CategoryAnchor var24 = var7.getDomainGridlinePosition();
//     var3.setDomainGridlinePosition(var24);
//     var0.setDomainGridlinePosition(var24);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.clearRangeAxes();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    java.awt.Paint var4 = var0.getDomainGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Rotation.CLOCKWISE", var1);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleAnchor.CENTER", var1);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     double var4 = var3.getLabelLinkMargin();
//     var3.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
//     double var8 = var7.getContentXOffset();
//     java.awt.Paint var9 = var7.getItemPaint();
//     java.awt.Font var10 = var7.getItemFont();
//     var1.setLabelFont(var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
//     double var16 = var15.getLabelLinkMargin();
//     var15.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     double var20 = var19.getContentXOffset();
//     java.awt.Paint var21 = var19.getItemPaint();
//     java.awt.Font var22 = var19.getItemFont();
//     var13.setLabelFont(var22);
//     var1.setLabelFont(var22);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    org.jfree.chart.event.TitleChangeListener var6 = null;
    var5.addChangeListener(var6);
    double var8 = var5.getContentYOffset();
    org.jfree.chart.util.RectangleAnchor var9 = var5.getLegendItemGraphicLocation();
    org.jfree.chart.util.RectangleInsets var10 = var5.getMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.chart.axis.ValueAxis var5 = var3.getAxis();
    org.jfree.chart.plot.PlotOrientation var6 = var3.getOrientation();
    java.lang.Object var7 = null;
    boolean var8 = var6.equals(var7);
    java.lang.String var9 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "PlotOrientation.HORIZONTAL"+ "'", var9.equals("PlotOrientation.HORIZONTAL"));

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = null;
//     var1.addFragment(var2);
//     org.jfree.chart.text.TextFragment var4 = null;
//     var1.addFragment(var4);
//     org.jfree.chart.text.TextFragment var6 = var1.getFirstTextFragment();
//     java.lang.String var7 = var6.getText();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = var6.calculateDimensions(var8);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setMaximumCategoryLabelWidthRatio(0.0f);
    double var4 = var1.getLowerMargin();
    org.jfree.chart.plot.DefaultDrawingSupplier var6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var7 = var6.getNextFillPaint();
    java.awt.Paint var8 = var6.getNextFillPaint();
    var1.setTickLabelPaint((java.lang.Comparable)100L, var8);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    java.awt.Font var15 = var14.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var18.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var21 = var18.getFrame();
    java.awt.Paint var22 = var18.getBackgroundPaint();
    var16.addSubtitle((org.jfree.chart.title.Title)var18);
    java.awt.Paint var24 = var16.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var16.removeSubtitle((org.jfree.chart.title.Title)var26);
    org.jfree.chart.event.ChartChangeEventType var28 = null;
    org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var16, var28);
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var31.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var34 = var31.getFrame();
    java.awt.Paint var35 = var31.getBackgroundPaint();
    var31.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
    var16.setTitle(var31);
    java.awt.geom.Rectangle2D var42 = var31.getBounds();
    org.jfree.chart.entity.ChartEntity var44 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var42, "poly");
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
    var45.clearAnnotations();
    org.jfree.chart.util.RectangleEdge var48 = var45.getRangeAxisEdge(1);
    double var49 = var1.getCategoryStart(0, 10, var42, var48);
    org.jfree.chart.util.RectangleEdge var50 = org.jfree.chart.util.RectangleEdge.opposite(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getRangeGridlinePaint();
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    java.awt.Font var9 = var8.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var12.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var15 = var12.getFrame();
    java.awt.Paint var16 = var12.getBackgroundPaint();
    var10.addSubtitle((org.jfree.chart.title.Title)var12);
    java.awt.Paint var18 = var10.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var10.removeSubtitle((org.jfree.chart.title.Title)var20);
    org.jfree.chart.event.ChartChangeEventType var22 = null;
    org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var10, var22);
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var25.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var28 = var25.getFrame();
    java.awt.Paint var29 = var25.getBackgroundPaint();
    var25.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
    var10.setTitle(var25);
    java.awt.geom.Rectangle2D var36 = var25.getBounds();
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.RingPlot var38 = new org.jfree.chart.plot.RingPlot(var37);
    double var39 = var38.getLabelLinkMargin();
    var38.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
    double var43 = var42.getContentXOffset();
    java.awt.Paint var44 = var42.getItemPaint();
    java.awt.Font var45 = var42.getItemFont();
    org.jfree.chart.util.RectangleAnchor var46 = var42.getLegendItemGraphicAnchor();
    boolean var48 = var46.equals((java.lang.Object)0L);
    java.awt.geom.Point2D var49 = org.jfree.chart.util.RectangleAnchor.coordinates(var36, var46);
    var0.zoomDomainAxes(10.0d, var5, var49, false);
    org.jfree.chart.annotations.XYAnnotation var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var53 = var0.removeAnnotation(var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     boolean var1 = var0.isEmpty();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.clearAnnotations();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var10 = var6.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var12.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var15 = var6.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var20 = var16.getDomainAxisLocation(0);
//     var6.setRangeAxisLocation(var20, false);
//     var3.setDomainAxisLocation(15, var20, true);
//     java.awt.Graphics2D var25 = null;
//     java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var30 = var29.getGreen();
//     int var31 = var29.getRGB();
//     int var32 = var29.getAlpha();
//     float[] var33 = null;
//     float[] var34 = var29.getRGBComponents(var33);
//     java.awt.image.ColorModel var35 = null;
//     java.awt.Rectangle var36 = null;
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot(var38);
//     java.awt.Font var40 = var39.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var39);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var43.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var46 = var43.getFrame();
//     java.awt.Paint var47 = var43.getBackgroundPaint();
//     var41.addSubtitle((org.jfree.chart.title.Title)var43);
//     java.awt.Paint var49 = var41.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var51 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var41.removeSubtitle((org.jfree.chart.title.Title)var51);
//     org.jfree.chart.event.ChartChangeEventType var53 = null;
//     org.jfree.chart.event.ChartChangeEvent var54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var41, var53);
//     org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var56.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var59 = var56.getFrame();
//     java.awt.Paint var60 = var56.getBackgroundPaint();
//     var56.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var41.setTitle(var56);
//     java.awt.geom.Rectangle2D var67 = var56.getBounds();
//     java.awt.geom.AffineTransform var68 = null;
//     java.awt.RenderingHints var69 = null;
//     java.awt.PaintContext var70 = var29.createContext(var35, var36, var67, var68, var69);
//     var3.drawBackgroundImage(var25, var67);
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var74 = null;
//     var72.setRangeAxisLocation(1, var74, false);
//     org.jfree.data.general.PieDataset var77 = null;
//     org.jfree.chart.plot.RingPlot var78 = new org.jfree.chart.plot.RingPlot(var77);
//     boolean var79 = var78.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var80 = null;
//     var78.setURLGenerator(var80);
//     org.jfree.chart.event.PlotChangeListener var82 = null;
//     var78.addChangeListener(var82);
//     java.awt.Shape var84 = var78.getLegendItemShape();
//     java.awt.Stroke var85 = var78.getBaseSectionOutlineStroke();
//     var72.setDomainGridlineStroke(var85);
//     org.jfree.chart.axis.CategoryAxis3D var87 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var88 = var87.getLowerMargin();
//     var72.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var87);
//     var87.setTickMarkOutsideLength(10.0f);
//     java.awt.Stroke var92 = var87.getTickMarkStroke();
//     java.lang.Object var93 = var0.draw(var2, var67, (java.lang.Object)var87);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    java.lang.String var2 = var0.getPlotType();
    boolean var3 = var0.getDrawSharedDomainAxis();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    var6.setVisible(false);
    var6.setUpperMargin(0.2d);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var13 = var12.getRange();
    java.lang.Object var14 = var12.clone();
    org.jfree.chart.axis.NumberTickUnit var15 = var12.getTickUnit();
    var6.setTickUnit(var15);
    var0.setRangeAxis(15, (org.jfree.chart.axis.ValueAxis)var6, true);
    org.jfree.chart.plot.CategoryMarker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    double var6 = var5.getContentXOffset();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = null;
    org.jfree.chart.util.Size2D var9 = var5.arrange(var7, var8);
    double var10 = var9.getWidth();
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var12 = var11.getMargin();
    boolean var13 = var9.equals((java.lang.Object)var12);
    java.awt.geom.Rectangle2D var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var17 = var12.createOutsetRectangle(var14, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var4.equals((java.lang.Object)var6);
//     org.jfree.chart.text.TextAnchor var8 = var4.getLabelTextAnchor();
//     float var9 = var1.calculateBaselineOffset(var2, var8);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var6.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var9 = var6.getFrame();
//     java.awt.Paint var10 = var6.getBackgroundPaint();
//     var4.addSubtitle((org.jfree.chart.title.Title)var6);
//     java.awt.Paint var12 = var4.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var4.removeSubtitle((org.jfree.chart.title.Title)var14);
//     org.jfree.chart.event.ChartChangeEventType var16 = null;
//     org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var4, var16);
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var19.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var22 = var19.getFrame();
//     java.awt.Paint var23 = var19.getBackgroundPaint();
//     var19.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var4.setTitle(var19);
//     java.awt.geom.Rectangle2D var30 = var19.getBounds();
//     org.jfree.chart.entity.ChartEntity var32 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var30, "poly");
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var34.setMaximumCategoryLabelWidthRatio(0.0f);
//     double var37 = var34.getLowerMargin();
//     org.jfree.chart.plot.DefaultDrawingSupplier var39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var40 = var39.getNextFillPaint();
//     java.awt.Paint var41 = var39.getNextFillPaint();
//     var34.setTickLabelPaint((java.lang.Comparable)100L, var41);
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.RingPlot var47 = new org.jfree.chart.plot.RingPlot(var46);
//     java.awt.Font var48 = var47.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var47);
//     org.jfree.chart.title.TextTitle var51 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var51.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var54 = var51.getFrame();
//     java.awt.Paint var55 = var51.getBackgroundPaint();
//     var49.addSubtitle((org.jfree.chart.title.Title)var51);
//     java.awt.Paint var57 = var49.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var49.removeSubtitle((org.jfree.chart.title.Title)var59);
//     org.jfree.chart.event.ChartChangeEventType var61 = null;
//     org.jfree.chart.event.ChartChangeEvent var62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var49, var61);
//     org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var64.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var67 = var64.getFrame();
//     java.awt.Paint var68 = var64.getBackgroundPaint();
//     var64.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var49.setTitle(var64);
//     java.awt.geom.Rectangle2D var75 = var64.getBounds();
//     org.jfree.chart.entity.ChartEntity var77 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var75, "poly");
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot();
//     var78.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var81 = var78.getRangeAxisEdge(1);
//     double var82 = var34.getCategoryStart(0, 10, var75, var81);
//     double var83 = org.jfree.chart.util.RectangleEdge.coordinate(var30, var81);
//     
//     // Checks the contract:  equals-hashcode on var2 and var47
//     assertTrue("Contract failed: equals-hashcode on var2 and var47", var2.equals(var47) ? var2.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var2
//     assertTrue("Contract failed: equals-hashcode on var47 and var2", var47.equals(var2) ? var47.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var49
//     assertTrue("Contract failed: equals-hashcode on var4 and var49", var4.equals(var49) ? var4.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var4
//     assertTrue("Contract failed: equals-hashcode on var49 and var4", var49.equals(var4) ? var49.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
    boolean var4 = var2.equals((java.lang.Object)0.025d);
    double var5 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var6.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var9 = var6.getFrame();
    java.awt.Paint var10 = var6.getBackgroundPaint();
    var4.addSubtitle((org.jfree.chart.title.Title)var6);
    java.awt.Paint var12 = var4.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var4.removeSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var16 = null;
    org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var4, var16);
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var19.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var22 = var19.getFrame();
    java.awt.Paint var23 = var19.getBackgroundPaint();
    var19.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
    var4.setTitle(var19);
    java.awt.geom.Rectangle2D var30 = var19.getBounds();
    org.jfree.data.general.PieDataset var31 = null;
    org.jfree.chart.plot.RingPlot var32 = new org.jfree.chart.plot.RingPlot(var31);
    double var33 = var32.getLabelLinkMargin();
    var32.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var32);
    double var37 = var36.getContentXOffset();
    java.awt.Paint var38 = var36.getItemPaint();
    java.awt.Font var39 = var36.getItemFont();
    org.jfree.chart.util.RectangleAnchor var40 = var36.getLegendItemGraphicAnchor();
    boolean var42 = var40.equals((java.lang.Object)0L);
    java.awt.geom.Point2D var43 = org.jfree.chart.util.RectangleAnchor.coordinates(var30, var40);
    boolean var45 = var40.equals((java.lang.Object)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     double var13 = var12.getContentXOffset();
//     java.awt.Paint var14 = var12.getItemPaint();
//     java.awt.Font var15 = var12.getItemFont();
//     var6.setLabelFont(var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
//     var3.removeSubtitle((org.jfree.chart.title.Title)var17);
//     java.lang.Object var19 = var17.clone();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
//     java.awt.Font var23 = var22.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var26.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var29 = var26.getFrame();
//     java.awt.Paint var30 = var26.getBackgroundPaint();
//     var24.addSubtitle((org.jfree.chart.title.Title)var26);
//     java.awt.Paint var32 = var24.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var24.removeSubtitle((org.jfree.chart.title.Title)var34);
//     org.jfree.chart.event.ChartChangeEventType var36 = null;
//     org.jfree.chart.event.ChartChangeEvent var37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var24, var36);
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var39.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var42 = var39.getFrame();
//     java.awt.Paint var43 = var39.getBackgroundPaint();
//     var39.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var24.setTitle(var39);
//     java.awt.geom.Rectangle2D var50 = var39.getBounds();
//     org.jfree.data.general.PieDataset var51 = null;
//     org.jfree.chart.plot.RingPlot var52 = new org.jfree.chart.plot.RingPlot(var51);
//     double var53 = var52.getLabelLinkMargin();
//     var52.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
//     double var57 = var56.getContentXOffset();
//     java.awt.Paint var58 = var56.getItemPaint();
//     java.awt.Font var59 = var56.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var60 = var56.getLegendItemGraphicAnchor();
//     boolean var62 = var60.equals((java.lang.Object)0L);
//     java.awt.geom.Point2D var63 = org.jfree.chart.util.RectangleAnchor.coordinates(var50, var60);
//     boolean var64 = var17.equals((java.lang.Object)var63);
//     
//     // Checks the contract:  equals-hashcode on var1 and var22
//     assertTrue("Contract failed: equals-hashcode on var1 and var22", var1.equals(var22) ? var1.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var52
//     assertTrue("Contract failed: equals-hashcode on var8 and var52", var8.equals(var52) ? var8.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var1
//     assertTrue("Contract failed: equals-hashcode on var22 and var1", var22.equals(var1) ? var22.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var8
//     assertTrue("Contract failed: equals-hashcode on var52 and var8", var52.equals(var8) ? var52.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = null;
//     var3.setDataset(var4);
//     boolean var6 = var3.isDomainZoomable();
//     org.jfree.chart.axis.ValueAxis var7 = var3.getAxis();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var10.setMaximumCategoryLabelWidthRatio(0.0f);
//     double var13 = var10.getLowerMargin();
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var16 = var15.getNextFillPaint();
//     java.awt.Paint var17 = var15.getNextFillPaint();
//     var10.setTickLabelPaint((java.lang.Comparable)100L, var17);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
//     java.awt.Font var24 = var23.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var27.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var30 = var27.getFrame();
//     java.awt.Paint var31 = var27.getBackgroundPaint();
//     var25.addSubtitle((org.jfree.chart.title.Title)var27);
//     java.awt.Paint var33 = var25.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var25.removeSubtitle((org.jfree.chart.title.Title)var35);
//     org.jfree.chart.event.ChartChangeEventType var37 = null;
//     org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var25, var37);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var40.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var43 = var40.getFrame();
//     java.awt.Paint var44 = var40.getBackgroundPaint();
//     var40.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var25.setTitle(var40);
//     java.awt.geom.Rectangle2D var51 = var40.getBounds();
//     org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var51, "poly");
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var57 = var54.getRangeAxisEdge(1);
//     double var58 = var10.getCategoryStart(0, 10, var51, var57);
//     var3.drawOutline(var8, var51);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0d, 0.2d, 0, (java.lang.Comparable)4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.clearRangeAxes();
    var0.setDomainCrosshairValue((-24.921874999999996d));
    java.awt.geom.Point2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantOrigin(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     org.jfree.chart.LegendItemCollection var10 = var9.getLegendItems();
//     var4.addAll(var10);
//     
//     // Checks the contract:  equals-hashcode on var3 and var9
//     assertTrue("Contract failed: equals-hashcode on var3 and var9", var3.equals(var9) ? var3.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var3
//     assertTrue("Contract failed: equals-hashcode on var9 and var3", var9.equals(var3) ? var9.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var10
//     assertTrue("Contract failed: equals-hashcode on var4 and var10", var4.equals(var10) ? var4.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var4
//     assertTrue("Contract failed: equals-hashcode on var10 and var4", var10.equals(var4) ? var10.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     double var23 = var22.getContentXOffset();
//     java.awt.Paint var24 = var22.getItemPaint();
//     java.awt.Font var25 = var22.getItemFont();
//     var16.setLabelFont(var25);
//     org.jfree.chart.util.Layer var27 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
//     double var29 = var0.getRangeCrosshairValue();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var32 = null;
//     var30.setRangeAxisLocation(1, var32, false);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     boolean var37 = var36.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var38 = null;
//     var36.setURLGenerator(var38);
//     org.jfree.chart.event.PlotChangeListener var40 = null;
//     var36.addChangeListener(var40);
//     java.awt.Shape var42 = var36.getLegendItemShape();
//     java.awt.Stroke var43 = var36.getBaseSectionOutlineStroke();
//     var30.setDomainGridlineStroke(var43);
//     org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     double var49 = var48.getLabelLinkMargin();
//     var48.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
//     double var53 = var52.getContentXOffset();
//     java.awt.Paint var54 = var52.getItemPaint();
//     java.awt.Font var55 = var52.getItemFont();
//     var46.setLabelFont(var55);
//     org.jfree.chart.util.Layer var57 = null;
//     var30.addRangeMarker((org.jfree.chart.plot.Marker)var46, var57);
//     double var59 = var30.getRangeCrosshairValue();
//     var30.setWeight(100);
//     org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var65 = null;
//     var64.notifyListeners(var65);
//     org.jfree.chart.plot.DefaultDrawingSupplier var67 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var68 = var67.getNextFillPaint();
//     var64.setPaint(var68);
//     org.jfree.chart.util.Layer var70 = null;
//     boolean var71 = var30.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var64, var70);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var72 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var73 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var72};
//     var30.setRenderers(var73);
//     var0.setRenderers(var73);
//     
//     // Checks the contract:  equals-hashcode on var6 and var36
//     assertTrue("Contract failed: equals-hashcode on var6 and var36", var6.equals(var36) ? var6.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var48
//     assertTrue("Contract failed: equals-hashcode on var18 and var48", var18.equals(var48) ? var18.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var6
//     assertTrue("Contract failed: equals-hashcode on var36 and var6", var36.equals(var6) ? var36.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var18
//     assertTrue("Contract failed: equals-hashcode on var48 and var18", var48.equals(var18) ? var48.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var46
//     assertTrue("Contract failed: equals-hashcode on var16 and var46", var16.equals(var46) ? var16.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var16
//     assertTrue("Contract failed: equals-hashcode on var46 and var16", var46.equals(var16) ? var46.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var2.setRangeAxisLocation(1, var4, false);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     boolean var9 = var8.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var8.setURLGenerator(var10);
//     org.jfree.chart.event.PlotChangeListener var12 = null;
//     var8.addChangeListener(var12);
//     java.awt.Shape var14 = var8.getLegendItemShape();
//     java.awt.Stroke var15 = var8.getBaseSectionOutlineStroke();
//     var2.setDomainGridlineStroke(var15);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
//     double var21 = var20.getLabelLinkMargin();
//     var20.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
//     double var25 = var24.getContentXOffset();
//     java.awt.Paint var26 = var24.getItemPaint();
//     java.awt.Font var27 = var24.getItemFont();
//     var18.setLabelFont(var27);
//     org.jfree.chart.util.Layer var29 = null;
//     var2.addRangeMarker((org.jfree.chart.plot.Marker)var18, var29);
//     java.awt.Stroke var31 = var2.getDomainGridlineStroke();
//     var1.setStroke(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var35 = null;
//     var33.setRangeAxisLocation(1, var35, false);
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot(var38);
//     boolean var40 = var39.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var41 = null;
//     var39.setURLGenerator(var41);
//     org.jfree.chart.event.PlotChangeListener var43 = null;
//     var39.addChangeListener(var43);
//     java.awt.Shape var45 = var39.getLegendItemShape();
//     java.awt.Stroke var46 = var39.getBaseSectionOutlineStroke();
//     var33.setDomainGridlineStroke(var46);
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var50 = null;
//     org.jfree.chart.plot.RingPlot var51 = new org.jfree.chart.plot.RingPlot(var50);
//     double var52 = var51.getLabelLinkMargin();
//     var51.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
//     double var56 = var55.getContentXOffset();
//     java.awt.Paint var57 = var55.getItemPaint();
//     java.awt.Font var58 = var55.getItemFont();
//     var49.setLabelFont(var58);
//     org.jfree.chart.util.Layer var60 = null;
//     var33.addRangeMarker((org.jfree.chart.plot.Marker)var49, var60);
//     double var62 = var33.getRangeCrosshairValue();
//     var33.setWeight(100);
//     org.jfree.chart.plot.ValueMarker var67 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var68 = null;
//     var67.notifyListeners(var68);
//     org.jfree.chart.plot.DefaultDrawingSupplier var70 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var71 = var70.getNextFillPaint();
//     var67.setPaint(var71);
//     org.jfree.chart.util.Layer var73 = null;
//     boolean var74 = var33.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var67, var73);
//     int var75 = var33.getDatasetCount();
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var33);
//     
//     // Checks the contract:  equals-hashcode on var18 and var49
//     assertTrue("Contract failed: equals-hashcode on var18 and var49", var18.equals(var49) ? var18.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var18
//     assertTrue("Contract failed: equals-hashcode on var49 and var18", var49.equals(var18) ? var49.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var39
//     assertTrue("Contract failed: equals-hashcode on var8 and var39", var8.equals(var39) ? var8.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var51
//     assertTrue("Contract failed: equals-hashcode on var20 and var51", var20.equals(var51) ? var20.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var8
//     assertTrue("Contract failed: equals-hashcode on var39 and var8", var39.equals(var8) ? var39.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var20
//     assertTrue("Contract failed: equals-hashcode on var51 and var20", var51.equals(var20) ? var51.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var0.setRenderer(100, var16, false);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var22 = var21.getRangeGridlinePaint();
//     var21.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
//     java.awt.Font var30 = var29.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var29);
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var33.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var36 = var33.getFrame();
//     java.awt.Paint var37 = var33.getBackgroundPaint();
//     var31.addSubtitle((org.jfree.chart.title.Title)var33);
//     java.awt.Paint var39 = var31.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var31.removeSubtitle((org.jfree.chart.title.Title)var41);
//     org.jfree.chart.event.ChartChangeEventType var43 = null;
//     org.jfree.chart.event.ChartChangeEvent var44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var31, var43);
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var46.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var49 = var46.getFrame();
//     java.awt.Paint var50 = var46.getBackgroundPaint();
//     var46.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var31.setTitle(var46);
//     java.awt.geom.Rectangle2D var57 = var46.getBounds();
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.RingPlot var59 = new org.jfree.chart.plot.RingPlot(var58);
//     double var60 = var59.getLabelLinkMargin();
//     var59.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
//     double var64 = var63.getContentXOffset();
//     java.awt.Paint var65 = var63.getItemPaint();
//     java.awt.Font var66 = var63.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var67 = var63.getLegendItemGraphicAnchor();
//     boolean var69 = var67.equals((java.lang.Object)0L);
//     java.awt.geom.Point2D var70 = org.jfree.chart.util.RectangleAnchor.coordinates(var57, var67);
//     var21.zoomDomainAxes(10.0d, var26, var70, false);
//     var0.zoomRangeAxes(1.0E-8d, var20, var70, false);
//     
//     // Checks the contract:  equals-hashcode on var6 and var29
//     assertTrue("Contract failed: equals-hashcode on var6 and var29", var6.equals(var29) ? var6.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var6
//     assertTrue("Contract failed: equals-hashcode on var29 and var6", var29.equals(var6) ? var29.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var5.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
    java.awt.Paint var9 = var5.getBackgroundPaint();
    var3.addSubtitle((org.jfree.chart.title.Title)var5);
    java.awt.Image var11 = var3.getBackgroundImage();
    org.jfree.chart.plot.Plot var12 = var3.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = null;
//     var1.addFragment(var2);
//     org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("hi!");
//     var1.addFragment(var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var11.setValue(1.0d);
//     var11.setLabel("Pie 3D Plot");
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
//     double var18 = var17.getLabelLinkMargin();
//     var17.setLabelGap((-1.0d));
//     java.awt.Stroke var21 = var17.getLabelOutlineStroke();
//     java.awt.Stroke var22 = var17.getLabelLinkStroke();
//     var17.setLabelLinkMargin(0.0d);
//     java.awt.Paint var25 = var17.getShadowPaint();
//     var11.setPaint(var25);
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     boolean var31 = var28.equals((java.lang.Object)var30);
//     org.jfree.chart.text.TextAnchor var32 = var28.getLabelTextAnchor();
//     java.lang.String var33 = var32.toString();
//     java.lang.Object var34 = null;
//     boolean var35 = var32.equals(var34);
//     var11.setLabelTextAnchor(var32);
//     var1.draw(var7, 100.0f, 10.0f, var32, 0.5f, 1.0f, 0.12d);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainAxes();
    java.util.List var2 = var0.getCategories();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     int var5 = var0.getDomainAxisCount();
//     org.jfree.chart.event.RendererChangeEvent var6 = null;
//     var0.rendererChanged(var6);
//     org.jfree.chart.util.RectangleEdge var9 = var0.getDomainAxisEdge(255);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Point2D var12 = null;
//     var0.zoomDomainAxes(100.0d, var11, var12, false);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var0.zoomDomainAxes(0.05d, (-15.95d), var17, var18);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.clearAnnotations();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var28 = var24.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var30.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var33 = var24.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var38 = var34.getDomainAxisLocation(0);
//     var24.setRangeAxisLocation(var38, false);
//     var21.setDomainAxisLocation(15, var38, true);
//     java.awt.Graphics2D var43 = null;
//     java.awt.Color var47 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var48 = var47.getGreen();
//     int var49 = var47.getRGB();
//     int var50 = var47.getAlpha();
//     float[] var51 = null;
//     float[] var52 = var47.getRGBComponents(var51);
//     java.awt.image.ColorModel var53 = null;
//     java.awt.Rectangle var54 = null;
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.RingPlot var57 = new org.jfree.chart.plot.RingPlot(var56);
//     java.awt.Font var58 = var57.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var57);
//     org.jfree.chart.title.TextTitle var61 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var61.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var64 = var61.getFrame();
//     java.awt.Paint var65 = var61.getBackgroundPaint();
//     var59.addSubtitle((org.jfree.chart.title.Title)var61);
//     java.awt.Paint var67 = var59.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var69 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var59.removeSubtitle((org.jfree.chart.title.Title)var69);
//     org.jfree.chart.event.ChartChangeEventType var71 = null;
//     org.jfree.chart.event.ChartChangeEvent var72 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var59, var71);
//     org.jfree.chart.title.TextTitle var74 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var74.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var77 = var74.getFrame();
//     java.awt.Paint var78 = var74.getBackgroundPaint();
//     var74.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var59.setTitle(var74);
//     java.awt.geom.Rectangle2D var85 = var74.getBounds();
//     java.awt.geom.AffineTransform var86 = null;
//     java.awt.RenderingHints var87 = null;
//     java.awt.PaintContext var88 = var47.createContext(var53, var54, var85, var86, var87);
//     var21.drawBackgroundImage(var43, var85);
//     org.jfree.chart.plot.PlotRenderingInfo var91 = null;
//     boolean var92 = var0.render(var20, var85, 0, var91);
//     
//     // Checks the contract:  equals-hashcode on var0 and var21
//     assertTrue("Contract failed: equals-hashcode on var0 and var21", var0.equals(var21) ? var0.hashCode() == var21.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var21.", var0.equals(var21) == var21.equals(var0));
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var2 = var1.getRange();
//     double var3 = var1.getAutoRangeMinimumSize();
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var9 = var8.getGreen();
//     int var10 = var8.getRGB();
//     int var11 = var8.getAlpha();
//     float[] var12 = null;
//     float[] var13 = var8.getRGBComponents(var12);
//     java.awt.image.ColorModel var14 = null;
//     java.awt.Rectangle var15 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var18);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var22.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var25 = var22.getFrame();
//     java.awt.Paint var26 = var22.getBackgroundPaint();
//     var20.addSubtitle((org.jfree.chart.title.Title)var22);
//     java.awt.Paint var28 = var20.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var20.removeSubtitle((org.jfree.chart.title.Title)var30);
//     org.jfree.chart.event.ChartChangeEventType var32 = null;
//     org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var20, var32);
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var35.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var38 = var35.getFrame();
//     java.awt.Paint var39 = var35.getBackgroundPaint();
//     var35.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var20.setTitle(var35);
//     java.awt.geom.Rectangle2D var46 = var35.getBounds();
//     java.awt.geom.AffineTransform var47 = null;
//     java.awt.RenderingHints var48 = null;
//     java.awt.PaintContext var49 = var8.createContext(var14, var15, var46, var47, var48);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     var50.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var53 = var50.getRangeAxisEdge(1);
//     double var54 = var1.valueToJava2D(0.2d, var46, var53);
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.RingPlot var56 = new org.jfree.chart.plot.RingPlot(var55);
//     boolean var57 = var56.isSubplot();
//     boolean var59 = var56.equals((java.lang.Object)"hi!");
//     double var60 = var56.getOuterSeparatorExtension();
//     boolean var61 = var53.equals((java.lang.Object)var56);
//     
//     // Checks the contract:  equals-hashcode on var18 and var56
//     assertTrue("Contract failed: equals-hashcode on var18 and var56", var18.equals(var56) ? var18.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var18
//     assertTrue("Contract failed: equals-hashcode on var56 and var18", var56.equals(var18) ? var56.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.LegendItemSource[] var6 = var5.getSources();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 0.0d);
//     org.jfree.data.Range var11 = var10.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var13 = var10.toFixedHeight(0.2d);
//     org.jfree.data.Range var14 = var13.getWidthRange();
//     org.jfree.chart.util.Size2D var15 = var5.arrange(var7, var13);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var18 = null;
//     var16.setRangeAxisLocation(1, var18, false);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setRangeAxisLocation(1, var24, false);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot(var27);
//     boolean var29 = var28.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var30 = null;
//     var28.setURLGenerator(var30);
//     org.jfree.chart.event.PlotChangeListener var32 = null;
//     var28.addChangeListener(var32);
//     java.awt.Shape var34 = var28.getLegendItemShape();
//     java.awt.Stroke var35 = var28.getBaseSectionOutlineStroke();
//     var22.setDomainGridlineStroke(var35);
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var38 = var37.getLowerMargin();
//     var22.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var37);
//     java.lang.Object var40 = var37.clone();
//     var16.setDomainAxis(10, (org.jfree.chart.axis.CategoryAxis)var37);
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot(var42);
//     double var44 = var43.getLabelLinkMargin();
//     var43.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
//     org.jfree.chart.event.TitleChangeListener var48 = null;
//     var47.addChangeListener(var48);
//     org.jfree.chart.block.BlockContainer var50 = null;
//     var47.setWrapper(var50);
//     org.jfree.chart.util.RectangleInsets var52 = var47.getPadding();
//     var37.setLabelInsets(var52);
//     var5.setItemLabelPadding(var52);
//     
//     // Checks the contract:  equals-hashcode on var1 and var43
//     assertTrue("Contract failed: equals-hashcode on var1 and var43", var1.equals(var43) ? var1.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var1
//     assertTrue("Contract failed: equals-hashcode on var43 and var1", var43.equals(var1) ? var43.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    org.jfree.chart.ui.BasicProjectInfo var8 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "ThreadContext");
    org.jfree.chart.ui.BasicProjectInfo var14 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "ThreadContext", "hi!");
    var8.addOptionalLibrary((org.jfree.chart.ui.Library)var14);
    java.lang.String var16 = var14.getVersion();
    var14.setVersion("ThreadContext");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.set(0, (java.lang.Object)"ThreadContext");
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var1.setToolTipText("ThreadContext");
    java.lang.Object var4 = var1.clone();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    boolean var9 = var6.equals((java.lang.Object)var8);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    double var12 = var11.getLabelLinkMargin();
    var11.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    double var16 = var15.getContentXOffset();
    java.awt.Paint var17 = var15.getItemPaint();
    java.awt.Font var18 = var15.getItemFont();
    var6.setLabelFont(var18);
    java.awt.Paint var20 = var6.getLabelPaint();
    java.awt.Paint var21 = var6.getPaint();
    boolean var22 = var1.equals((java.lang.Object)var6);
    var1.setWidth(100.0d);
    java.lang.String var25 = var1.getToolTipText();
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var29 = var28.getRange();
    double var30 = var29.getCentralValue();
    org.jfree.data.Range var32 = org.jfree.data.Range.shift(var29, (-15.95d));
    org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(var29, 90.0d);
    org.jfree.data.Range var35 = var34.getHeightRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var36 = var1.arrange(var26, var34);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "ThreadContext"+ "'", var25.equals("ThreadContext"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     org.jfree.chart.event.PlotChangeEvent var3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     var1.setCircular(true);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     org.jfree.chart.util.RectangleInsets var13 = var12.getPadding();
//     double var14 = var13.getRight();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var17 = var16.getRange();
//     double var18 = var16.getAutoRangeMinimumSize();
//     java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var24 = var23.getGreen();
//     int var25 = var23.getRGB();
//     int var26 = var23.getAlpha();
//     float[] var27 = null;
//     float[] var28 = var23.getRGBComponents(var27);
//     java.awt.image.ColorModel var29 = null;
//     java.awt.Rectangle var30 = null;
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var37.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var40 = var37.getFrame();
//     java.awt.Paint var41 = var37.getBackgroundPaint();
//     var35.addSubtitle((org.jfree.chart.title.Title)var37);
//     java.awt.Paint var43 = var35.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var35.removeSubtitle((org.jfree.chart.title.Title)var45);
//     org.jfree.chart.event.ChartChangeEventType var47 = null;
//     org.jfree.chart.event.ChartChangeEvent var48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var35, var47);
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var50.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var53 = var50.getFrame();
//     java.awt.Paint var54 = var50.getBackgroundPaint();
//     var50.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var35.setTitle(var50);
//     java.awt.geom.Rectangle2D var61 = var50.getBounds();
//     java.awt.geom.AffineTransform var62 = null;
//     java.awt.RenderingHints var63 = null;
//     java.awt.PaintContext var64 = var23.createContext(var29, var30, var61, var62, var63);
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
//     var65.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var68 = var65.getRangeAxisEdge(1);
//     double var69 = var16.valueToJava2D(0.2d, var61, var68);
//     var13.trim(var61);
//     org.jfree.chart.plot.PiePlot3D var71 = new org.jfree.chart.plot.PiePlot3D();
//     var71.setDarkerSides(false);
//     double var74 = var71.getDepthFactor();
//     org.jfree.chart.plot.PlotRenderingInfo var76 = null;
//     org.jfree.chart.plot.PiePlotState var77 = var1.initialise(var6, var61, (org.jfree.chart.plot.PiePlot)var71, (java.lang.Integer)(-1), var76);
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    boolean var2 = var1.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var1.setURLGenerator(var3);
    org.jfree.chart.event.PlotChangeListener var5 = null;
    var1.addChangeListener(var5);
    java.awt.Shape var7 = var1.getLegendItemShape();
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var7, "PlotOrientation.HORIZONTAL", "poly");
    org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.clearRangeAxes();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.clearAnnotations();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisLocation var10 = var6.getDomainAxisLocation(0);
    org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D("");
    var12.setMaximumCategoryLabelWidthRatio(0.0f);
    boolean var15 = var6.equals((java.lang.Object)0.0f);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisLocation var20 = var16.getDomainAxisLocation(0);
    var6.setRangeAxisLocation(var20, false);
    var3.setDomainAxisLocation(15, var20, true);
    var0.setRangeAxisLocation(var20, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var28 = var0.getQuadrantPaint(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var3 = var2.getRange();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var6 = var5.getRange();
//     org.jfree.data.Range var7 = org.jfree.data.Range.combine(var3, var6);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     double var10 = var9.getLabelLinkMargin();
//     var9.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     org.jfree.chart.LegendItemSource[] var14 = var13.getSources();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.data.Range var16 = null;
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var16, 0.0d);
//     org.jfree.data.Range var19 = var18.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var21 = var18.toFixedHeight(0.2d);
//     org.jfree.data.Range var22 = var21.getWidthRange();
//     org.jfree.chart.util.Size2D var23 = var13.arrange(var15, var21);
//     org.jfree.chart.block.LengthConstraintType var24 = var21.getWidthConstraintType();
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var28 = var27.getRange();
//     double var29 = var28.getCentralValue();
//     org.jfree.data.Range var31 = org.jfree.data.Range.shift(var28, (-15.95d));
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     double var34 = var33.getLabelLinkMargin();
//     var33.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
//     org.jfree.chart.LegendItemSource[] var38 = var37.getSources();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.data.Range var40 = null;
//     org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(var40, 0.0d);
//     org.jfree.data.Range var43 = var42.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var45 = var42.toFixedHeight(0.2d);
//     org.jfree.data.Range var46 = var45.getWidthRange();
//     org.jfree.chart.util.Size2D var47 = var37.arrange(var39, var45);
//     org.jfree.chart.block.LengthConstraintType var48 = var45.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(0.0d, var3, var24, 0.025d, var28, var48);
//     
//     // Checks the contract:  equals-hashcode on var9 and var33
//     assertTrue("Contract failed: equals-hashcode on var9 and var33", var9.equals(var33) ? var9.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var9
//     assertTrue("Contract failed: equals-hashcode on var33 and var9", var33.equals(var9) ? var33.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var47
//     assertTrue("Contract failed: equals-hashcode on var23 and var47", var23.equals(var47) ? var23.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var23
//     assertTrue("Contract failed: equals-hashcode on var47 and var23", var47.equals(var23) ? var47.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Paint var7 = var5.getItemPaint();
//     java.awt.Font var8 = var5.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 0.2d, 0.025d);
//     org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var13);
//     java.util.List var15 = var14.getBlocks();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getPadding();
//     double var24 = var23.getRight();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var27 = var26.getRange();
//     double var28 = var26.getAutoRangeMinimumSize();
//     java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var34 = var33.getGreen();
//     int var35 = var33.getRGB();
//     int var36 = var33.getAlpha();
//     float[] var37 = null;
//     float[] var38 = var33.getRGBComponents(var37);
//     java.awt.image.ColorModel var39 = null;
//     java.awt.Rectangle var40 = null;
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot(var42);
//     java.awt.Font var44 = var43.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var43);
//     org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var47.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var50 = var47.getFrame();
//     java.awt.Paint var51 = var47.getBackgroundPaint();
//     var45.addSubtitle((org.jfree.chart.title.Title)var47);
//     java.awt.Paint var53 = var45.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var45.removeSubtitle((org.jfree.chart.title.Title)var55);
//     org.jfree.chart.event.ChartChangeEventType var57 = null;
//     org.jfree.chart.event.ChartChangeEvent var58 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var45, var57);
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var60.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var63 = var60.getFrame();
//     java.awt.Paint var64 = var60.getBackgroundPaint();
//     var60.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var45.setTitle(var60);
//     java.awt.geom.Rectangle2D var71 = var60.getBounds();
//     java.awt.geom.AffineTransform var72 = null;
//     java.awt.RenderingHints var73 = null;
//     java.awt.PaintContext var74 = var33.createContext(var39, var40, var71, var72, var73);
//     org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot();
//     var75.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var78 = var75.getRangeAxisEdge(1);
//     double var79 = var26.valueToJava2D(0.2d, var71, var78);
//     var23.trim(var71);
//     var14.draw(var16, var71);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.LegendItemSource[] var6 = var5.getSources();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 0.0d);
//     org.jfree.data.Range var11 = var10.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var13 = var10.toFixedHeight(0.2d);
//     org.jfree.data.Range var14 = var13.getWidthRange();
//     org.jfree.chart.util.Size2D var15 = var5.arrange(var7, var13);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.data.Range var17 = null;
//     org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, 0.0d);
//     org.jfree.data.Range var20 = var19.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var22 = var19.toFixedHeight(0.2d);
//     org.jfree.chart.util.Size2D var23 = var5.arrange(var16, var22);
//     
//     // Checks the contract:  equals-hashcode on var15 and var23
//     assertTrue("Contract failed: equals-hashcode on var15 and var23", var15.equals(var23) ? var15.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var15
//     assertTrue("Contract failed: equals-hashcode on var23 and var15", var23.equals(var15) ? var23.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)"RectangleEdge.RIGHT");
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.LegendItemSource[] var6 = var5.getSources();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 0.0d);
//     org.jfree.data.Range var11 = var10.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var13 = var10.toFixedHeight(0.2d);
//     org.jfree.data.Range var14 = var13.getWidthRange();
//     org.jfree.chart.util.Size2D var15 = var5.arrange(var7, var13);
//     org.jfree.chart.block.LengthConstraintType var16 = var13.getWidthConstraintType();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     org.jfree.chart.LegendItemSource[] var23 = var22.getSources();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.data.Range var25 = null;
//     org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var25, 0.0d);
//     org.jfree.data.Range var28 = var27.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var30 = var27.toFixedHeight(0.2d);
//     org.jfree.data.Range var31 = var30.getWidthRange();
//     org.jfree.chart.util.Size2D var32 = var22.arrange(var24, var30);
//     org.jfree.chart.util.Size2D var33 = var13.calculateConstrainedSize(var32);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.clearRangeAxes();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
    var0.clearDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var2.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var5 = var2.getFrame();
    java.awt.Paint var6 = var2.getBackgroundPaint();
    var2.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
    var2.setToolTipText("Pie 3D Plot");
    org.jfree.chart.text.TextBlock var14 = new org.jfree.chart.text.TextBlock();
    java.util.List var15 = var14.getLines();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    double var18 = var17.getLabelLinkMargin();
    var17.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    double var22 = var21.getContentXOffset();
    java.awt.Paint var23 = var21.getItemPaint();
    java.awt.Font var24 = var21.getItemFont();
    org.jfree.chart.util.HorizontalAlignment var25 = var21.getHorizontalAlignment();
    var14.setLineAlignment(var25);
    boolean var27 = var2.equals((java.lang.Object)var25);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var30 = null;
    var28.setRangeAxisLocation(1, var30, false);
    org.jfree.data.general.PieDataset var33 = null;
    org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot(var33);
    boolean var35 = var34.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var36 = null;
    var34.setURLGenerator(var36);
    org.jfree.chart.event.PlotChangeListener var38 = null;
    var34.addChangeListener(var38);
    java.awt.Shape var40 = var34.getLegendItemShape();
    java.awt.Stroke var41 = var34.getBaseSectionOutlineStroke();
    var28.setDomainGridlineStroke(var41);
    org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var45 = null;
    org.jfree.chart.plot.RingPlot var46 = new org.jfree.chart.plot.RingPlot(var45);
    double var47 = var46.getLabelLinkMargin();
    var46.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46);
    double var51 = var50.getContentXOffset();
    java.awt.Paint var52 = var50.getItemPaint();
    java.awt.Font var53 = var50.getItemFont();
    var44.setLabelFont(var53);
    org.jfree.chart.util.Layer var55 = null;
    var28.addRangeMarker((org.jfree.chart.plot.Marker)var44, var55);
    double var57 = var28.getRangeCrosshairValue();
    var28.setWeight(100);
    org.jfree.chart.axis.AxisSpace var60 = null;
    var28.setFixedDomainAxisSpace(var60);
    org.jfree.chart.plot.DatasetRenderingOrder var62 = var28.getDatasetRenderingOrder();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var2, (java.lang.Object)var28);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     java.awt.Stroke var3 = var1.getLabelOutlineStroke();
//     java.awt.Paint var4 = var1.getSeparatorPaint();
//     boolean var5 = var1.isCircular();
//     org.jfree.chart.text.TextFragment var8 = new org.jfree.chart.text.TextFragment("ThreadContext");
//     java.awt.Paint var9 = var8.getPaint();
//     var1.setSectionPaint((java.lang.Comparable)"", var9);
//     boolean var11 = var1.isCircular();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     double var15 = var14.getLabelLinkMargin();
//     var14.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     org.jfree.chart.LegendItemSource[] var19 = var18.getSources();
//     boolean var20 = var12.equals((java.lang.Object)var18);
//     var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     var22.clearRangeAxes();
//     boolean var24 = var22.isDomainCrosshairLockedOnData();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var27 = null;
//     var25.setRangeAxisLocation(1, var27, false);
//     var25.setAnchorValue(0.025d, false);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot(var33);
//     double var35 = var34.getLabelLinkMargin();
//     var34.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     org.jfree.chart.event.TitleChangeListener var39 = null;
//     var38.addChangeListener(var39);
//     org.jfree.chart.block.BlockContainer var41 = null;
//     var38.setWrapper(var41);
//     org.jfree.chart.util.RectangleInsets var43 = var38.getPadding();
//     var25.setInsets(var43, false);
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var48 = null;
//     org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot(var46, var47, var48);
//     org.jfree.data.xy.XYDataset var50 = null;
//     var49.setDataset(var50);
//     java.awt.Paint var52 = var49.getRadiusGridlinePaint();
//     org.jfree.chart.block.BlockBorder var53 = new org.jfree.chart.block.BlockBorder(var43, var52);
//     java.awt.Color var57 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var58 = var57.getAlpha();
//     java.awt.Color var59 = var57.brighter();
//     boolean var60 = var53.equals((java.lang.Object)var59);
//     var22.setDomainGridlinePaint((java.awt.Paint)var59);
//     boolean var62 = var1.equals((java.lang.Object)var22);
//     
//     // Checks the contract:  equals-hashcode on var14 and var34
//     assertTrue("Contract failed: equals-hashcode on var14 and var34", var14.equals(var34) ? var14.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var14
//     assertTrue("Contract failed: equals-hashcode on var34 and var14", var34.equals(var14) ? var34.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.clearRangeAxes();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
    java.awt.Stroke var8 = var6.getLabelOutlineStroke();
    java.awt.Paint var9 = var6.getSeparatorPaint();
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
    java.awt.Paint var15 = var14.getPaint();
    var6.setBaseSectionPaint(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint((-1), var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 1.0E-8d, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     var0.clearRangeAxes();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis();
//     org.jfree.chart.util.Layer var3 = null;
//     java.util.Collection var4 = var0.getRangeMarkers(var3);
//     var0.clearDomainAxes();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     java.awt.Font var9 = var8.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var12.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var15 = var12.getFrame();
//     java.awt.Paint var16 = var12.getBackgroundPaint();
//     var10.addSubtitle((org.jfree.chart.title.Title)var12);
//     java.awt.Paint var18 = var10.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var10.removeSubtitle((org.jfree.chart.title.Title)var20);
//     org.jfree.chart.event.ChartChangeEventType var22 = null;
//     org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var10, var22);
//     org.jfree.chart.JFreeChart var24 = var23.getChart();
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
//     java.awt.Paint var30 = var29.getPaint();
//     var24.setBorderPaint(var30);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var24);
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var37 = var36.getRangeCrosshairStroke();
//     java.lang.String var38 = var36.getPlotType();
//     boolean var39 = var36.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     var36.setRangeAxis(var40);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.RingPlot var47 = new org.jfree.chart.plot.RingPlot(var46);
//     java.awt.Font var48 = var47.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var47);
//     org.jfree.chart.title.TextTitle var51 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var51.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var54 = var51.getFrame();
//     java.awt.Paint var55 = var51.getBackgroundPaint();
//     var49.addSubtitle((org.jfree.chart.title.Title)var51);
//     java.awt.Paint var57 = var49.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var49.removeSubtitle((org.jfree.chart.title.Title)var59);
//     org.jfree.chart.event.ChartChangeEventType var61 = null;
//     org.jfree.chart.event.ChartChangeEvent var62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var49, var61);
//     org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var64.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var67 = var64.getFrame();
//     java.awt.Paint var68 = var64.getBackgroundPaint();
//     var64.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var49.setTitle(var64);
//     java.awt.geom.Rectangle2D var75 = var64.getBounds();
//     org.jfree.data.general.PieDataset var76 = null;
//     org.jfree.chart.plot.RingPlot var77 = new org.jfree.chart.plot.RingPlot(var76);
//     double var78 = var77.getLabelLinkMargin();
//     var77.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var81 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var77);
//     double var82 = var81.getContentXOffset();
//     java.awt.Paint var83 = var81.getItemPaint();
//     java.awt.Font var84 = var81.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var85 = var81.getLegendItemGraphicAnchor();
//     boolean var87 = var85.equals((java.lang.Object)0L);
//     java.awt.geom.Point2D var88 = org.jfree.chart.util.RectangleAnchor.coordinates(var75, var85);
//     var36.zoomDomainAxes((-1.0d), 0.0d, var44, var88);
//     var0.zoomRangeAxes(100.0d, 100.0d, var35, var88);
//     
//     // Checks the contract:  equals-hashcode on var8 and var47
//     assertTrue("Contract failed: equals-hashcode on var8 and var47", var8.equals(var47) ? var8.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var8
//     assertTrue("Contract failed: equals-hashcode on var47 and var8", var47.equals(var8) ? var47.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     java.awt.Image var4 = var3.getBackgroundImage();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     double var7 = var6.getLabelLinkMargin();
//     var6.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     org.jfree.chart.event.TitleChangeListener var11 = null;
//     var10.addChangeListener(var11);
//     double var13 = var10.getContentYOffset();
//     java.awt.Paint var14 = var10.getBackgroundPaint();
//     var3.addLegend(var10);
//     boolean var16 = var3.isNotify();
//     var3.setBackgroundImageAlpha((-1.0f));
//     var3.fireChartChanged();
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     var3.handleClick(255, 10, var22);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    java.lang.String var2 = var0.getPlotType();
    org.jfree.data.category.CategoryDataset var3 = null;
    var0.setDataset(var3);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setMaximumCategoryLabelWidthRatio(0.0f);
    double var4 = var1.getLowerMargin();
    org.jfree.chart.plot.DefaultDrawingSupplier var6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var7 = var6.getNextFillPaint();
    java.awt.Paint var8 = var6.getNextFillPaint();
    var1.setTickLabelPaint((java.lang.Comparable)100L, var8);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    java.awt.Font var15 = var14.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var18.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var21 = var18.getFrame();
    java.awt.Paint var22 = var18.getBackgroundPaint();
    var16.addSubtitle((org.jfree.chart.title.Title)var18);
    java.awt.Paint var24 = var16.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var16.removeSubtitle((org.jfree.chart.title.Title)var26);
    org.jfree.chart.event.ChartChangeEventType var28 = null;
    org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var16, var28);
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var31.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var34 = var31.getFrame();
    java.awt.Paint var35 = var31.getBackgroundPaint();
    var31.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
    var16.setTitle(var31);
    java.awt.geom.Rectangle2D var42 = var31.getBounds();
    org.jfree.chart.entity.ChartEntity var44 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var42, "poly");
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
    var45.clearAnnotations();
    org.jfree.chart.util.RectangleEdge var48 = var45.getRangeAxisEdge(1);
    double var49 = var1.getCategoryStart(0, 10, var42, var48);
    java.lang.String var50 = var48.toString();
    boolean var51 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + "RectangleEdge.RIGHT"+ "'", var50.equals("RectangleEdge.RIGHT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.chart.axis.ValueAxis var5 = var3.getAxis();
    org.jfree.data.xy.XYDataset var6 = var3.getDataset();
    var3.removeCornerTextItem("hi!");
    org.jfree.data.xy.XYDataset var9 = var3.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    double var23 = var22.getContentXOffset();
    java.awt.Paint var24 = var22.getItemPaint();
    java.awt.Font var25 = var22.getItemFont();
    var16.setLabelFont(var25);
    org.jfree.chart.util.Layer var27 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
    double var29 = var0.getRangeCrosshairValue();
    var0.setWeight(100);
    org.jfree.chart.axis.AxisSpace var32 = null;
    var0.setFixedDomainAxisSpace(var32);
    boolean var34 = var0.getDrawSharedDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    double var6 = var5.getContentXOffset();
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setItemPaint(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.text.TextBlockAnchor var5 = null;
    var0.draw(var2, (-1.0f), 0.0f, var5, 1.0f, 100.0f, 0.05d);
    org.jfree.chart.util.HorizontalAlignment var10 = var0.getLineAlignment();
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
    java.awt.Font var15 = var14.getAngleLabelFont();
    boolean var16 = var0.equals((java.lang.Object)var15);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var18.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var21 = var18.getFrame();
    java.awt.Paint var22 = var18.getBackgroundPaint();
    var18.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
    var18.setToolTipText("Pie 3D Plot");
    org.jfree.chart.text.TextBlock var30 = new org.jfree.chart.text.TextBlock();
    java.util.List var31 = var30.getLines();
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
    double var34 = var33.getLabelLinkMargin();
    var33.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
    double var38 = var37.getContentXOffset();
    java.awt.Paint var39 = var37.getItemPaint();
    java.awt.Font var40 = var37.getItemFont();
    org.jfree.chart.util.HorizontalAlignment var41 = var37.getHorizontalAlignment();
    var30.setLineAlignment(var41);
    boolean var43 = var18.equals((java.lang.Object)var41);
    var0.setLineAlignment(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    double var6 = var5.getContentXOffset();
    java.awt.Paint var7 = var5.getItemPaint();
    java.awt.Font var8 = var5.getItemFont();
    org.jfree.chart.util.HorizontalAlignment var9 = var5.getHorizontalAlignment();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.util.Size2D var11 = var5.arrange(var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var14 = null;
    var12.setRangeAxisLocation(1, var14, false);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    boolean var19 = var18.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var20 = null;
    var18.setURLGenerator(var20);
    org.jfree.chart.event.PlotChangeListener var22 = null;
    var18.addChangeListener(var22);
    java.awt.Shape var24 = var18.getLegendItemShape();
    java.awt.Stroke var25 = var18.getBaseSectionOutlineStroke();
    var12.setDomainGridlineStroke(var25);
    double var27 = var12.getAnchorValue();
    org.jfree.chart.axis.AxisLocation var28 = var12.getRangeAxisLocation();
    org.jfree.chart.axis.AxisLocation var30 = null;
    var12.setRangeAxisLocation(10, var30);
    boolean var32 = var12.isRangeZoomable();
    boolean var33 = var5.equals((java.lang.Object)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var1.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var4 = var1.getFrame();
    java.awt.Paint var5 = var1.getBackgroundPaint();
    var1.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
    java.awt.Paint var16 = var15.getPaint();
    var1.setFrame((org.jfree.chart.block.BlockFrame)var15);
    org.jfree.chart.util.RectangleInsets var18 = var15.getInsets();
    org.jfree.chart.util.RectangleInsets var19 = var15.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    java.awt.Stroke var3 = var1.getLabelOutlineStroke();
    java.awt.Paint var4 = var1.getSeparatorPaint();
    org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
    java.awt.Paint var10 = var9.getPaint();
    var1.setBaseSectionPaint(var10);
    var1.setPieIndex((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge(1);
    org.jfree.chart.axis.CategoryAxis var4 = var0.getDomainAxis();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    java.awt.Font var7 = var6.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    var8.setTextAntiAlias(false);
    org.jfree.chart.event.ChartChangeEvent var11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var14 = var8.createBufferedImage(15, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.2d, (-13.95d), (-1), (java.lang.Comparable)0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Pie 3D Plot");

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    var0.setAnchorValue(0.025d, false);
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D("");
    var9.setMaximumCategoryLabelWidthRatio(0.0f);
    java.awt.Paint var13 = var9.getTickLabelPaint((java.lang.Comparable)(-16777216));
    int var14 = var9.getCategoryLabelPositionOffset();
    int var15 = var0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var9);
    double var16 = var9.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     var0.clearRangeAxes();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis();
//     org.jfree.chart.util.Layer var3 = null;
//     java.util.Collection var4 = var0.getRangeMarkers(var3);
//     var0.clearDomainAxes();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     java.awt.Font var9 = var8.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var12.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var15 = var12.getFrame();
//     java.awt.Paint var16 = var12.getBackgroundPaint();
//     var10.addSubtitle((org.jfree.chart.title.Title)var12);
//     java.awt.Paint var18 = var10.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var10.removeSubtitle((org.jfree.chart.title.Title)var20);
//     org.jfree.chart.event.ChartChangeEventType var22 = null;
//     org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var10, var22);
//     org.jfree.chart.JFreeChart var24 = var23.getChart();
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
//     java.awt.Paint var30 = var29.getPaint();
//     var24.setBorderPaint(var30);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var24);
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var34.setToolTipText("ThreadContext");
//     java.lang.Object var37 = var34.clone();
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.RingPlot var41 = new org.jfree.chart.plot.RingPlot(var40);
//     boolean var42 = var39.equals((java.lang.Object)var41);
//     org.jfree.data.general.PieDataset var43 = null;
//     org.jfree.chart.plot.RingPlot var44 = new org.jfree.chart.plot.RingPlot(var43);
//     double var45 = var44.getLabelLinkMargin();
//     var44.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var44);
//     double var49 = var48.getContentXOffset();
//     java.awt.Paint var50 = var48.getItemPaint();
//     java.awt.Font var51 = var48.getItemFont();
//     var39.setLabelFont(var51);
//     java.awt.Paint var53 = var39.getLabelPaint();
//     java.awt.Paint var54 = var39.getPaint();
//     boolean var55 = var34.equals((java.lang.Object)var39);
//     var34.setWidth(100.0d);
//     var24.removeSubtitle((org.jfree.chart.title.Title)var34);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    var2.setMaximumCategoryLabelWidthRatio(0.0f);
    double var5 = var2.getLowerMargin();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    org.jfree.data.xy.XYDataset var10 = null;
    var9.setDataset(var10);
    java.awt.Paint var12 = var9.getRadiusGridlinePaint();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    var14.setVisible(false);
    var14.setUpperMargin(0.2d);
    float var19 = var14.getTickMarkInsideLength();
    var14.setAutoRangeMinimumSize(1.0E-5d);
    var9.setAxis((org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var14, var23);
    double var25 = var14.getLabelAngle();
    java.awt.Shape var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setRightArrow(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    java.lang.Object var0 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Font var4 = var3.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var7.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var10 = var7.getFrame();
    java.awt.Paint var11 = var7.getBackgroundPaint();
    var5.addSubtitle((org.jfree.chart.title.Title)var7);
    java.awt.Paint var13 = var5.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var5.removeSubtitle((org.jfree.chart.title.Title)var15);
    org.jfree.chart.event.ChartChangeEventType var17 = null;
    org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var5, var17);
    int var19 = var5.getSubtitleCount();
    org.jfree.chart.text.TextBlock var20 = new org.jfree.chart.text.TextBlock();
    java.util.List var21 = var20.getLines();
    java.util.List var22 = var20.getLines();
    var5.setSubtitles(var22);
    var5.removeLegend();
    org.jfree.chart.event.ChartChangeEventType var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var26 = new org.jfree.chart.event.ChartChangeEvent(var0, var5, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    boolean var2 = var1.isSubplot();
    boolean var4 = var1.equals((java.lang.Object)"hi!");
    java.awt.Image var5 = var1.getBackgroundImage();
    java.awt.Stroke var6 = var1.getBaseSectionOutlineStroke();
    org.jfree.chart.util.Rotation var7 = var1.getDirection();
    var1.setLabelLinkMargin(0.0d);
    java.awt.Font var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    int var2 = var0.getBackgroundImageAlignment();
    boolean var3 = var0.isRangeZoomable();
    org.jfree.chart.annotations.CategoryAnnotation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     var0.setDepthFactor((-1.0d));
//     java.awt.Font var3 = var0.getNoDataMessageFont();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var11.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var14 = var11.getFrame();
//     java.awt.Paint var15 = var11.getBackgroundPaint();
//     var9.addSubtitle((org.jfree.chart.title.Title)var11);
//     java.awt.Paint var17 = var9.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var9.removeSubtitle((org.jfree.chart.title.Title)var19);
//     org.jfree.chart.event.ChartChangeEventType var21 = null;
//     org.jfree.chart.event.ChartChangeEvent var22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var9, var21);
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var24.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var27 = var24.getFrame();
//     java.awt.Paint var28 = var24.getBackgroundPaint();
//     var24.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var9.setTitle(var24);
//     java.awt.geom.Rectangle2D var35 = var24.getBounds();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.RingPlot var38 = new org.jfree.chart.plot.RingPlot(var37);
//     java.awt.Font var39 = var38.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var38);
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var42.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var45 = var42.getFrame();
//     java.awt.Paint var46 = var42.getBackgroundPaint();
//     var40.addSubtitle((org.jfree.chart.title.Title)var42);
//     java.awt.Paint var48 = var40.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var40.removeSubtitle((org.jfree.chart.title.Title)var50);
//     org.jfree.chart.event.ChartChangeEventType var52 = null;
//     org.jfree.chart.event.ChartChangeEvent var53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var40, var52);
//     org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var55.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var58 = var55.getFrame();
//     java.awt.Paint var59 = var55.getBackgroundPaint();
//     var55.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var40.setTitle(var55);
//     java.awt.geom.Rectangle2D var66 = var55.getBounds();
//     org.jfree.data.general.PieDataset var67 = null;
//     org.jfree.chart.plot.RingPlot var68 = new org.jfree.chart.plot.RingPlot(var67);
//     double var69 = var68.getLabelLinkMargin();
//     var68.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var72 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var68);
//     double var73 = var72.getContentXOffset();
//     java.awt.Paint var74 = var72.getItemPaint();
//     java.awt.Font var75 = var72.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var76 = var72.getLegendItemGraphicAnchor();
//     boolean var78 = var76.equals((java.lang.Object)0L);
//     java.awt.geom.Point2D var79 = org.jfree.chart.util.RectangleAnchor.coordinates(var66, var76);
//     org.jfree.chart.plot.PlotState var80 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var81 = null;
//     var0.draw(var4, var35, var79, var80, var81);
// 
//   }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var1.setValue(1.0d);
//     var1.setLabel("Pie 3D Plot");
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     double var8 = var7.getLabelLinkMargin();
//     var7.setLabelGap((-1.0d));
//     java.awt.Stroke var11 = var7.getLabelOutlineStroke();
//     java.awt.Stroke var12 = var7.getLabelLinkStroke();
//     var7.setLabelLinkMargin(0.0d);
//     java.awt.Paint var15 = var7.getShadowPaint();
//     var1.setPaint(var15);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
//     boolean var21 = var18.equals((java.lang.Object)var20);
//     org.jfree.chart.text.TextAnchor var22 = var18.getLabelTextAnchor();
//     java.lang.String var23 = var22.toString();
//     java.lang.Object var24 = null;
//     boolean var25 = var22.equals(var24);
//     var1.setLabelTextAnchor(var22);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var31 = var27.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var33.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var36 = var27.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     var37.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var41 = var37.getDomainAxisLocation(0);
//     var27.setRangeAxisLocation(var41, false);
//     org.jfree.chart.axis.CategoryAnchor var44 = var27.getDomainGridlinePosition();
//     org.jfree.chart.event.MarkerChangeEvent var45 = null;
//     var27.markerChanged(var45);
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     boolean var49 = var48.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var50 = null;
//     var48.setURLGenerator(var50);
//     org.jfree.chart.event.PlotChangeListener var52 = null;
//     var48.addChangeListener(var52);
//     java.awt.Paint var54 = var48.getBaseSectionOutlinePaint();
//     var27.setRangeGridlinePaint(var54);
//     var1.setLabelPaint(var54);
//     
//     // Checks the contract:  equals-hashcode on var20 and var48
//     assertTrue("Contract failed: equals-hashcode on var20 and var48", var20.equals(var48) ? var20.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var20
//     assertTrue("Contract failed: equals-hashcode on var48 and var20", var48.equals(var20) ? var48.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.util.Size2D var3 = var0.calculateDimensions(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    double var23 = var22.getContentXOffset();
    java.awt.Paint var24 = var22.getItemPaint();
    java.awt.Font var25 = var22.getItemFont();
    var16.setLabelFont(var25);
    org.jfree.chart.util.Layer var27 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
    java.awt.Paint var29 = var16.getPaint();
    var16.setAlpha(0.0f);
    java.awt.Stroke var32 = var16.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var5.draw(var7, var8);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var1.setTickMarkOutsideLength((-1.0f));
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.setRangeCrosshairLockedOnData(false);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     java.awt.Font var15 = var14.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var18.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var21 = var18.getFrame();
//     java.awt.Paint var22 = var18.getBackgroundPaint();
//     var16.addSubtitle((org.jfree.chart.title.Title)var18);
//     java.awt.Paint var24 = var16.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var16.removeSubtitle((org.jfree.chart.title.Title)var26);
//     org.jfree.chart.event.ChartChangeEventType var28 = null;
//     org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var16, var28);
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var31.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var34 = var31.getFrame();
//     java.awt.Paint var35 = var31.getBackgroundPaint();
//     var31.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var16.setTitle(var31);
//     java.awt.geom.Rectangle2D var42 = var31.getBounds();
//     java.awt.geom.Point2D var43 = null;
//     org.jfree.chart.plot.PlotState var44 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     var8.draw(var11, var42, var43, var44, var45);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var48 = var47.getRangeCrosshairStroke();
//     java.lang.String var49 = var47.getPlotType();
//     boolean var50 = var47.getDrawSharedDomainAxis();
//     var47.mapDatasetToRangeAxis(0, 100);
//     org.jfree.chart.util.RectangleEdge var55 = var47.getDomainAxisEdge(10);
//     double var56 = org.jfree.chart.util.RectangleEdge.coordinate(var42, var55);
//     org.jfree.data.general.PieDataset var57 = null;
//     org.jfree.chart.plot.RingPlot var58 = new org.jfree.chart.plot.RingPlot(var57);
//     double var59 = var58.getLabelLinkMargin();
//     var58.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58);
//     double var63 = var62.getContentXOffset();
//     java.awt.Graphics2D var64 = null;
//     org.jfree.chart.block.RectangleConstraint var65 = null;
//     org.jfree.chart.util.Size2D var66 = var62.arrange(var64, var65);
//     org.jfree.chart.util.RectangleEdge var67 = var62.getLegendItemGraphicEdge();
//     double var68 = var1.getCategorySeriesMiddle((java.lang.Comparable)(-1.0f), (java.lang.Comparable)10.0f, var6, 0.2d, var42, var67);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     org.jfree.chart.block.BlockContainer var8 = null;
//     var5.setWrapper(var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearAnnotations();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var18 = var14.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var20.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var23 = var14.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var28 = var24.getDomainAxisLocation(0);
//     var14.setRangeAxisLocation(var28, false);
//     var11.setDomainAxisLocation(15, var28, true);
//     java.awt.Graphics2D var33 = null;
//     java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var38 = var37.getGreen();
//     int var39 = var37.getRGB();
//     int var40 = var37.getAlpha();
//     float[] var41 = null;
//     float[] var42 = var37.getRGBComponents(var41);
//     java.awt.image.ColorModel var43 = null;
//     java.awt.Rectangle var44 = null;
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.RingPlot var47 = new org.jfree.chart.plot.RingPlot(var46);
//     java.awt.Font var48 = var47.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var47);
//     org.jfree.chart.title.TextTitle var51 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var51.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var54 = var51.getFrame();
//     java.awt.Paint var55 = var51.getBackgroundPaint();
//     var49.addSubtitle((org.jfree.chart.title.Title)var51);
//     java.awt.Paint var57 = var49.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var49.removeSubtitle((org.jfree.chart.title.Title)var59);
//     org.jfree.chart.event.ChartChangeEventType var61 = null;
//     org.jfree.chart.event.ChartChangeEvent var62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var49, var61);
//     org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var64.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var67 = var64.getFrame();
//     java.awt.Paint var68 = var64.getBackgroundPaint();
//     var64.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var49.setTitle(var64);
//     java.awt.geom.Rectangle2D var75 = var64.getBounds();
//     java.awt.geom.AffineTransform var76 = null;
//     java.awt.RenderingHints var77 = null;
//     java.awt.PaintContext var78 = var37.createContext(var43, var44, var75, var76, var77);
//     var11.drawBackgroundImage(var33, var75);
//     var5.draw(var10, var75);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getRangeGridlinePaint();
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var6 = var5.getRange();
    java.lang.Object var7 = var5.clone();
    var5.setUpperMargin(0.025d);
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var12 = var11.getRange();
    java.lang.Object var13 = var11.clone();
    org.jfree.chart.axis.NumberTickUnit var14 = var11.getTickUnit();
    java.awt.Shape var15 = var11.getRightArrow();
    var5.setDownArrow(var15);
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
    org.jfree.chart.axis.NumberTickUnit var20 = var18.getTickUnit();
    var5.setTickUnit(var20, false, true);
    int var24 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.plot.PlotOrientation var25 = var0.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    var0.clear();
    var0.clear();
    boolean var4 = var0.containsKey((java.lang.Comparable)"Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    java.awt.Image var4 = var3.getBackgroundImage();
    java.lang.Object var5 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
//     java.awt.Stroke var8 = var6.getLabelOutlineStroke();
//     java.awt.Paint var9 = var6.getSeparatorPaint();
//     boolean var10 = var6.isCircular();
//     java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var15 = var14.getGreen();
//     var6.setSeparatorPaint((java.awt.Paint)var14);
//     var3.setRadiusGridlinePaint((java.awt.Paint)var14);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
//     org.jfree.chart.event.PlotChangeEvent var20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var19);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
//     org.jfree.chart.event.PlotChangeEvent var24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var23);
//     java.awt.Stroke var25 = var23.getLabelOutlineStroke();
//     java.awt.Paint var26 = var23.getSeparatorPaint();
//     var19.setSectionOutlinePaint((java.lang.Comparable)(-1.0d), var26);
//     var3.setAngleGridlinePaint(var26);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     var32.setDataset(var33);
//     java.awt.Paint var35 = var32.getRadiusGridlinePaint();
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot(var36);
//     org.jfree.chart.event.PlotChangeEvent var38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var37);
//     java.awt.Stroke var39 = var37.getLabelOutlineStroke();
//     var37.setSectionOutlinesVisible(true);
//     java.awt.Stroke var42 = var37.getLabelOutlineStroke();
//     var32.setAngleGridlineStroke(var42);
//     var3.setAngleGridlineStroke(var42);
//     
//     // Checks the contract:  equals-hashcode on var23 and var37
//     assertTrue("Contract failed: equals-hashcode on var23 and var37", var23.equals(var37) ? var23.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var23
//     assertTrue("Contract failed: equals-hashcode on var37 and var23", var37.equals(var23) ? var37.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.RIGHT", "Range[0.025,0.025]", var3);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var1.setToolTipText("ThreadContext");
//     java.lang.Object var4 = var1.clone();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getLabelLinkMargin();
//     var11.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
//     double var16 = var15.getContentXOffset();
//     java.awt.Paint var17 = var15.getItemPaint();
//     java.awt.Font var18 = var15.getItemFont();
//     var6.setLabelFont(var18);
//     java.awt.Paint var20 = var6.getLabelPaint();
//     java.awt.Paint var21 = var6.getPaint();
//     boolean var22 = var1.equals((java.lang.Object)var6);
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     boolean var27 = var24.equals((java.lang.Object)var26);
//     org.jfree.chart.text.TextAnchor var28 = var24.getLabelTextAnchor();
//     var6.setLabelTextAnchor(var28);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    java.awt.Image var4 = var3.getBackgroundImage();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    double var7 = var6.getLabelLinkMargin();
    var6.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    org.jfree.chart.event.TitleChangeListener var11 = null;
    var10.addChangeListener(var11);
    double var13 = var10.getContentYOffset();
    java.awt.Paint var14 = var10.getBackgroundPaint();
    var3.addLegend(var10);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
    org.jfree.data.xy.XYDataset var20 = null;
    var19.setDataset(var20);
    java.awt.Paint var22 = var19.getRadiusGridlinePaint();
    var3.setBackgroundPaint(var22);
    java.awt.Paint var24 = var3.getBackgroundPaint();
    var3.setTitle("ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    boolean var2 = var0.containsKey("Pie Plot");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject("Size2D[width=0.0, height=0.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    double var5 = var4.getLabelLinkMargin();
    var4.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    double var9 = var8.getContentXOffset();
    java.awt.Paint var10 = var8.getItemPaint();
    java.awt.Font var11 = var8.getItemFont();
    var1.setTickLabelFont((java.lang.Comparable)(-1.0d), var11);
    var1.configure();
    java.lang.Comparable var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Font var15 = var1.getTickLabelFont(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var6.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var9 = var6.getFrame();
    java.awt.Paint var10 = var6.getBackgroundPaint();
    var4.addSubtitle((org.jfree.chart.title.Title)var6);
    java.awt.Paint var12 = var4.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var4.removeSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var16 = null;
    org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var4, var16);
    boolean var18 = var4.isBorderVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     var0.clearRangeAxes();
//     var0.clearRangeMarkers((-16777216));
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var0.handleClick(1, 0, var6);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     double var7 = var6.getLabelLinkMargin();
//     var6.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     double var11 = var10.getContentXOffset();
//     java.awt.Paint var12 = var10.getItemPaint();
//     java.awt.Font var13 = var10.getItemFont();
//     var1.setLabelFont(var13);
//     java.awt.Stroke var15 = var1.getOutlineStroke();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
//     double var18 = var17.getLabelLinkMargin();
//     double var19 = var17.getMaximumExplodePercent();
//     java.awt.Paint var20 = var17.getBaseSectionOutlinePaint();
//     var1.setOutlinePaint(var20);
//     
//     // Checks the contract:  equals-hashcode on var3 and var17
//     assertTrue("Contract failed: equals-hashcode on var3 and var17", var3.equals(var17) ? var3.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var3
//     assertTrue("Contract failed: equals-hashcode on var17 and var3", var17.equals(var3) ? var17.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    float var5 = var1.getBackgroundAlpha();
    java.awt.Paint var6 = var1.getLabelBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    java.lang.String var2 = var0.getPlotType();
    boolean var3 = var0.getDrawSharedDomainAxis();
    var0.setRangeCrosshairValue(100.0d, true);
    java.awt.Paint var7 = var0.getRangeGridlinePaint();
    var0.setRangeCrosshairValue(2.00000001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleAnchor.CENTER", var1, var2);
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Pie Plot", var1);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Paint var7 = var5.getItemPaint();
//     java.awt.Font var8 = var5.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 0.2d, 0.025d);
//     org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
//     double var20 = var19.getLabelLinkMargin();
//     var19.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
//     double var24 = var23.getContentXOffset();
//     java.awt.Paint var25 = var23.getItemPaint();
//     java.awt.Font var26 = var23.getItemFont();
//     var17.setLabelFont(var26);
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("", var26);
//     double var29 = var28.getHeight();
//     var14.add((org.jfree.chart.block.Block)var28);
//     
//     // Checks the contract:  equals-hashcode on var1 and var19
//     assertTrue("Contract failed: equals-hashcode on var1 and var19", var1.equals(var19) ? var1.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var1
//     assertTrue("Contract failed: equals-hashcode on var19 and var1", var19.equals(var1) ? var19.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 0);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.clearRangeAxes();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis();
    org.jfree.chart.util.Layer var3 = null;
    java.util.Collection var4 = var0.getRangeMarkers(var3);
    var0.clearDomainAxes();
    org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var8.setValue(1.0d);
    var8.setLabel("Pie 3D Plot");
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(15, (org.jfree.chart.plot.Marker)var8, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    java.awt.Font var4 = var3.getAngleLabelFont();
    java.lang.Object var5 = var3.clone();
    org.jfree.chart.LegendItemCollection var6 = var3.getLegendItems();
    org.jfree.chart.LegendItem var7 = null;
    var6.add(var7);
    int var9 = var6.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var1 = var0.getPlotType();
    java.lang.String var2 = var0.getNoDataMessage();
    org.jfree.data.general.PieDataset var3 = null;
    var0.setDataset(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
    java.awt.Stroke var5 = var3.getLabelOutlineStroke();
    var0.setRangeCrosshairStroke(var5);
    org.jfree.chart.event.MarkerChangeEvent var7 = null;
    var0.markerChanged(var7);
    var0.clearRangeMarkers(255);
    var0.clearRangeMarkers(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var2 = var1.getRange();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var5 = var4.getRange();
    org.jfree.data.Range var6 = org.jfree.data.Range.combine(var2, var5);
    double var8 = var5.constrain(10.0d);
    double var9 = var5.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    org.jfree.chart.event.PlotChangeEvent var3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.urls.PieURLGenerator var4 = null;
    var1.setLegendLabelURLGenerator(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     double var10 = var9.getLabelLinkMargin();
//     var9.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     double var14 = var13.getContentXOffset();
//     java.awt.Paint var15 = var13.getItemPaint();
//     java.awt.Font var16 = var13.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var17 = var13.getHorizontalAlignment();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.util.Size2D var19 = var13.arrange(var18);
//     org.jfree.chart.LegendItemSource[] var20 = var13.getSources();
//     var5.setSources(var20);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getRangeGridlinePaint();
    boolean var2 = var0.isRangeGridlinesVisible();
    java.awt.Stroke var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainCrosshairStroke(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     var0.clearRangeAxes();
//     boolean var2 = var0.isDomainCrosshairLockedOnData();
//     org.jfree.chart.util.Layer var4 = null;
//     java.util.Collection var5 = var0.getDomainMarkers(15, var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setRangeCrosshairLockedOnData(false);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     java.awt.Font var14 = var13.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var17.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var20 = var17.getFrame();
//     java.awt.Paint var21 = var17.getBackgroundPaint();
//     var15.addSubtitle((org.jfree.chart.title.Title)var17);
//     java.awt.Paint var23 = var15.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var15.removeSubtitle((org.jfree.chart.title.Title)var25);
//     org.jfree.chart.event.ChartChangeEventType var27 = null;
//     org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var15, var27);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var30.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var33 = var30.getFrame();
//     java.awt.Paint var34 = var30.getBackgroundPaint();
//     var30.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var15.setTitle(var30);
//     java.awt.geom.Rectangle2D var41 = var30.getBounds();
//     java.awt.geom.Point2D var42 = null;
//     org.jfree.chart.plot.PlotState var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     var7.draw(var10, var41, var42, var43, var44);
//     var0.drawBackground(var6, var41);
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     double var13 = var12.getContentXOffset();
//     java.awt.Paint var14 = var12.getItemPaint();
//     java.awt.Font var15 = var12.getItemFont();
//     var6.setLabelFont(var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
//     var3.removeSubtitle((org.jfree.chart.title.Title)var17);
//     java.awt.Image var19 = null;
//     var3.setBackgroundImage(var19);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var22.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var25 = var22.getFrame();
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     double var31 = var30.getLabelLinkMargin();
//     var30.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     double var35 = var34.getContentXOffset();
//     java.awt.Paint var36 = var34.getItemPaint();
//     java.awt.Font var37 = var34.getItemFont();
//     var27.setTickLabelFont((java.lang.Comparable)(-1.0d), var37);
//     var22.setFont(var37);
//     var22.setURLText("java.awt.Color[r=0,g=0,b=0]");
//     org.jfree.chart.event.TitleChangeEvent var42 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var22);
//     var3.titleChanged(var42);
//     
//     // Checks the contract:  equals-hashcode on var8 and var30
//     assertTrue("Contract failed: equals-hashcode on var8 and var30", var8.equals(var30) ? var8.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var8
//     assertTrue("Contract failed: equals-hashcode on var30 and var8", var30.equals(var8) ? var30.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     var0.clearRangeAxes();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     var0.zoomRangeAxes(0.5d, (-1.0d), var5, var6);
//     org.jfree.chart.axis.ValueAxis var9 = var0.getDomainAxis(0);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var13 = var12.getRangeGridlinePaint();
//     var12.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
//     java.awt.Font var21 = var20.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var24.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var27 = var24.getFrame();
//     java.awt.Paint var28 = var24.getBackgroundPaint();
//     var22.addSubtitle((org.jfree.chart.title.Title)var24);
//     java.awt.Paint var30 = var22.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var22.removeSubtitle((org.jfree.chart.title.Title)var32);
//     org.jfree.chart.event.ChartChangeEventType var34 = null;
//     org.jfree.chart.event.ChartChangeEvent var35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var22, var34);
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var37.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var40 = var37.getFrame();
//     java.awt.Paint var41 = var37.getBackgroundPaint();
//     var37.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var22.setTitle(var37);
//     java.awt.geom.Rectangle2D var48 = var37.getBounds();
//     org.jfree.data.general.PieDataset var49 = null;
//     org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot(var49);
//     double var51 = var50.getLabelLinkMargin();
//     var50.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
//     double var55 = var54.getContentXOffset();
//     java.awt.Paint var56 = var54.getItemPaint();
//     java.awt.Font var57 = var54.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var58 = var54.getLegendItemGraphicAnchor();
//     boolean var60 = var58.equals((java.lang.Object)0L);
//     java.awt.geom.Point2D var61 = org.jfree.chart.util.RectangleAnchor.coordinates(var48, var58);
//     var12.zoomDomainAxes(10.0d, var17, var61, false);
//     var0.zoomDomainAxes(0.12d, var11, var61, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getRangeGridlinePaint();
//     boolean var2 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     var0.setRenderer(4, var4, false);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var11 = var10.getRangeGridlinePaint();
//     var10.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var18);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var22.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var25 = var22.getFrame();
//     java.awt.Paint var26 = var22.getBackgroundPaint();
//     var20.addSubtitle((org.jfree.chart.title.Title)var22);
//     java.awt.Paint var28 = var20.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var20.removeSubtitle((org.jfree.chart.title.Title)var30);
//     org.jfree.chart.event.ChartChangeEventType var32 = null;
//     org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var20, var32);
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var35.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var38 = var35.getFrame();
//     java.awt.Paint var39 = var35.getBackgroundPaint();
//     var35.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var20.setTitle(var35);
//     java.awt.geom.Rectangle2D var46 = var35.getBounds();
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     double var49 = var48.getLabelLinkMargin();
//     var48.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
//     double var53 = var52.getContentXOffset();
//     java.awt.Paint var54 = var52.getItemPaint();
//     java.awt.Font var55 = var52.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var56 = var52.getLegendItemGraphicAnchor();
//     boolean var58 = var56.equals((java.lang.Object)0L);
//     java.awt.geom.Point2D var59 = org.jfree.chart.util.RectangleAnchor.coordinates(var46, var56);
//     var10.zoomDomainAxes(10.0d, var15, var59, false);
//     var0.zoomDomainAxes(4.0d, 0.2d, var9, var59);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     double var8 = var7.getLabelLinkMargin();
//     var7.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
//     double var12 = var11.getContentXOffset();
//     java.awt.Paint var13 = var11.getItemPaint();
//     java.awt.Font var14 = var11.getItemFont();
//     var2.setLabelFont(var14);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var17 = var16.getRangeGridlinePaint();
//     org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var14, var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
//     boolean var24 = var21.equals((java.lang.Object)var23);
//     org.jfree.chart.text.TextAnchor var25 = var21.getLabelTextAnchor();
//     java.lang.String var26 = var25.toString();
//     java.lang.Object var27 = null;
//     boolean var28 = var25.equals(var27);
//     float var29 = var18.calculateBaselineOffset(var19, var25);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.clearRangeAxes();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis();
    org.jfree.chart.util.Layer var3 = null;
    java.util.Collection var4 = var0.getRangeMarkers(var3);
    boolean var5 = var0.isRangeCrosshairLockedOnData();
    java.awt.Paint var6 = var0.getRangeTickBandPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    var0.clearDomainAxes();
    int var3 = var0.getBackgroundImageAlignment();
    java.awt.Paint var4 = null;
    var0.setOutlinePaint(var4);
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeCrosshairPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     double var5 = var4.getLabelLinkMargin();
//     var4.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     double var9 = var8.getContentXOffset();
//     java.awt.Paint var10 = var8.getItemPaint();
//     java.awt.Font var11 = var8.getItemFont();
//     var1.setTickLabelFont((java.lang.Comparable)(-1.0d), var11);
//     java.awt.Font var14 = null;
//     var1.setTickLabelFont((java.lang.Comparable)(-1), var14);
//     var1.setMaximumCategoryLabelWidthRatio(0.0f);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.axis.AxisState var19 = null;
//     java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var24 = var23.getGreen();
//     int var25 = var23.getRGB();
//     int var26 = var23.getAlpha();
//     float[] var27 = null;
//     float[] var28 = var23.getRGBComponents(var27);
//     java.awt.image.ColorModel var29 = null;
//     java.awt.Rectangle var30 = null;
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var37.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var40 = var37.getFrame();
//     java.awt.Paint var41 = var37.getBackgroundPaint();
//     var35.addSubtitle((org.jfree.chart.title.Title)var37);
//     java.awt.Paint var43 = var35.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var35.removeSubtitle((org.jfree.chart.title.Title)var45);
//     org.jfree.chart.event.ChartChangeEventType var47 = null;
//     org.jfree.chart.event.ChartChangeEvent var48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var35, var47);
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var50.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var53 = var50.getFrame();
//     java.awt.Paint var54 = var50.getBackgroundPaint();
//     var50.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var35.setTitle(var50);
//     java.awt.geom.Rectangle2D var61 = var50.getBounds();
//     java.awt.geom.AffineTransform var62 = null;
//     java.awt.RenderingHints var63 = null;
//     java.awt.PaintContext var64 = var23.createContext(var29, var30, var61, var62, var63);
//     org.jfree.data.general.PieDataset var65 = null;
//     org.jfree.chart.plot.RingPlot var66 = new org.jfree.chart.plot.RingPlot(var65);
//     double var67 = var66.getLabelLinkMargin();
//     var66.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66);
//     double var71 = var70.getContentXOffset();
//     java.awt.Graphics2D var72 = null;
//     org.jfree.chart.block.RectangleConstraint var73 = null;
//     org.jfree.chart.util.Size2D var74 = var70.arrange(var72, var73);
//     org.jfree.chart.util.RectangleEdge var75 = var70.getPosition();
//     java.util.List var76 = var1.refreshTicks(var18, var19, (java.awt.geom.Rectangle2D)var30, var75);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=0,g=0,b=0]", var1);
// 
//   }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     var0.clearRangeAxes();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     var0.zoomRangeAxes(0.5d, (-1.0d), var5, var6);
//     org.jfree.chart.axis.ValueAxis var9 = var0.getDomainAxis(0);
//     var0.configureDomainAxes();
//     org.jfree.chart.util.Layer var11 = null;
//     java.util.Collection var12 = var0.getRangeMarkers(var11);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     var0.setRangeAxis(1, var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
//     java.awt.Font var20 = var19.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var23.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var26 = var23.getFrame();
//     java.awt.Paint var27 = var23.getBackgroundPaint();
//     var21.addSubtitle((org.jfree.chart.title.Title)var23);
//     java.awt.Paint var29 = var21.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var21.removeSubtitle((org.jfree.chart.title.Title)var31);
//     org.jfree.chart.event.ChartChangeEventType var33 = null;
//     org.jfree.chart.event.ChartChangeEvent var34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var21, var33);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var36.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var39 = var36.getFrame();
//     java.awt.Paint var40 = var36.getBackgroundPaint();
//     var36.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var21.setTitle(var36);
//     java.awt.geom.Rectangle2D var47 = var36.getBounds();
//     var0.drawBackground(var16, var47);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    var0.clearDomainAxes();
    int var3 = var0.getBackgroundImageAlignment();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setRangeAxisLocation(1, var7, false);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    boolean var12 = var11.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var13 = null;
    var11.setURLGenerator(var13);
    org.jfree.chart.event.PlotChangeListener var15 = null;
    var11.addChangeListener(var15);
    java.awt.Shape var17 = var11.getLegendItemShape();
    java.awt.Stroke var18 = var11.getBaseSectionOutlineStroke();
    var5.setDomainGridlineStroke(var18);
    double var20 = var5.getAnchorValue();
    org.jfree.chart.axis.AxisLocation var21 = var5.getRangeAxisLocation();
    var0.setDomainAxisLocation(0, var21);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.clearAnnotations();
    var24.clearDomainAxes();
    int var27 = var24.getBackgroundImageAlignment();
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var31 = null;
    var29.setRangeAxisLocation(1, var31, false);
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.plot.RingPlot var35 = new org.jfree.chart.plot.RingPlot(var34);
    boolean var36 = var35.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var37 = null;
    var35.setURLGenerator(var37);
    org.jfree.chart.event.PlotChangeListener var39 = null;
    var35.addChangeListener(var39);
    java.awt.Shape var41 = var35.getLegendItemShape();
    java.awt.Stroke var42 = var35.getBaseSectionOutlineStroke();
    var29.setDomainGridlineStroke(var42);
    double var44 = var29.getAnchorValue();
    org.jfree.chart.axis.AxisLocation var45 = var29.getRangeAxisLocation();
    var24.setDomainAxisLocation(0, var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-1), var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var2 = var1.getRange();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    boolean var5 = var4.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var4.setURLGenerator(var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var4.addChangeListener(var8);
    java.awt.Shape var10 = var4.getLegendItemShape();
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "");
    var1.setRightArrow(var10);
    var1.setFixedAutoRange((-15.95d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    float var5 = var1.getBackgroundAlpha();
    java.awt.Paint var6 = var1.getLabelBackgroundPaint();
    boolean var7 = var1.isSubplot();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = var1.getLegendLabelToolTipGenerator();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var1.getLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var4 = var0.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var9 = var0.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var14 = var10.getDomainAxisLocation(0);
//     var0.setRangeAxisLocation(var14, false);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     var18.clearRangeAxes();
//     boolean var20 = var18.isDomainCrosshairLockedOnData();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.clearAnnotations();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var28 = var24.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var30.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var33 = var24.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var38 = var34.getDomainAxisLocation(0);
//     var24.setRangeAxisLocation(var38, false);
//     var21.setDomainAxisLocation(15, var38, true);
//     var18.setRangeAxisLocation(var38, true);
//     var0.setRangeAxisLocation(15, var38, false);
//     
//     // Checks the contract:  equals-hashcode on var10 and var34
//     assertTrue("Contract failed: equals-hashcode on var10 and var34", var10.equals(var34) ? var10.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var0
//     assertTrue("Contract failed: equals-hashcode on var24 and var0", var24.equals(var0) ? var24.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var10
//     assertTrue("Contract failed: equals-hashcode on var34 and var10", var34.equals(var10) ? var34.hashCode() == var10.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var0.", var24.equals(var0) == var0.equals(var24));
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var1.setToolTipText("ThreadContext");
    java.lang.Object var4 = var1.clone();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    boolean var9 = var6.equals((java.lang.Object)var8);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    double var12 = var11.getLabelLinkMargin();
    var11.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    double var16 = var15.getContentXOffset();
    java.awt.Paint var17 = var15.getItemPaint();
    java.awt.Font var18 = var15.getItemFont();
    var6.setLabelFont(var18);
    java.awt.Paint var20 = var6.getLabelPaint();
    java.awt.Paint var21 = var6.getPaint();
    boolean var22 = var1.equals((java.lang.Object)var6);
    java.lang.String var23 = var1.getText();
    double var24 = var1.getContentYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "ThreadContext"+ "'", var23.equals("ThreadContext"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    double var15 = var0.getAnchorValue();
    org.jfree.chart.axis.AxisLocation var16 = var0.getRangeAxisLocation();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    double var23 = var22.getContentXOffset();
    java.awt.Paint var24 = var22.getItemPaint();
    java.awt.Font var25 = var22.getItemFont();
    org.jfree.chart.util.HorizontalAlignment var26 = var22.getHorizontalAlignment();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var28 = var27.getRangeCrosshairStroke();
    java.lang.String var29 = var27.getPlotType();
    boolean var30 = var27.getDrawSharedDomainAxis();
    var27.mapDatasetToRangeAxis(0, 100);
    org.jfree.chart.util.RectangleEdge var35 = var27.getDomainAxisEdge(10);
    org.jfree.chart.util.SortOrder var36 = var27.getRowRenderingOrder();
    boolean var37 = var26.equals((java.lang.Object)var36);
    var0.setColumnRenderingOrder(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "Category Plot"+ "'", var29.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getRangeGridlinePaint();
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var6 = var5.getRange();
//     java.lang.Object var7 = var5.clone();
//     var5.setUpperMargin(0.025d);
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var12 = var11.getRange();
//     java.lang.Object var13 = var11.clone();
//     org.jfree.chart.axis.NumberTickUnit var14 = var11.getTickUnit();
//     java.awt.Shape var15 = var11.getRightArrow();
//     var5.setDownArrow(var15);
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
//     org.jfree.chart.axis.NumberTickUnit var20 = var18.getTickUnit();
//     var5.setTickUnit(var20, false, true);
//     int var24 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var27 = null;
//     org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot(var25, var26, var27);
//     org.jfree.chart.LegendItemCollection var29 = var28.getLegendItems();
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
//     org.jfree.chart.event.PlotChangeEvent var32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var31);
//     java.awt.Stroke var33 = var31.getLabelOutlineStroke();
//     java.awt.Paint var34 = var31.getSeparatorPaint();
//     boolean var35 = var31.isCircular();
//     java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var40 = var39.getGreen();
//     var31.setSeparatorPaint((java.awt.Paint)var39);
//     var28.setRadiusGridlinePaint((java.awt.Paint)var39);
//     java.awt.Color var43 = var39.darker();
//     boolean var44 = var0.equals((java.lang.Object)var39);
//     org.jfree.chart.util.Layer var45 = null;
//     java.util.Collection var46 = var0.getRangeMarkers(var45);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     var47.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisLocation var51 = var47.getDomainAxisLocation(0);
//     org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var53.setMaximumCategoryLabelWidthRatio(0.0f);
//     boolean var56 = var47.equals((java.lang.Object)0.0f);
//     org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var59 = null;
//     var58.notifyListeners(var59);
//     var47.addRangeMarker((org.jfree.chart.plot.Marker)var58);
//     org.jfree.chart.util.LengthAdjustmentType var62 = var58.getLabelOffsetType();
//     org.jfree.chart.util.Layer var63 = null;
//     boolean var64 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var58, var63);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
//     var0.clear();
//     var0.clear();
//     org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var6 = null;
//     var5.addFragment(var6);
//     org.jfree.chart.text.TextFragment var8 = null;
//     var5.addFragment(var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var12 = null;
//     org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot(var10, var11, var12);
//     org.jfree.data.xy.XYDataset var14 = null;
//     var13.setDataset(var14);
//     java.awt.Paint var16 = var13.getRadiusGridlinePaint();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     org.jfree.chart.event.PlotChangeEvent var19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var18);
//     java.awt.Stroke var20 = var18.getLabelOutlineStroke();
//     var18.setSectionOutlinesVisible(true);
//     java.awt.Stroke var23 = var18.getLabelOutlineStroke();
//     var13.setAngleGridlineStroke(var23);
//     boolean var25 = var5.equals((java.lang.Object)var23);
//     var0.put((java.lang.Comparable)(-15.95d), var23);
//     var0.clear();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     double var31 = var30.getLabelLinkMargin();
//     var30.setLabelGap((-1.0d));
//     float var34 = var30.getBackgroundAlpha();
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     java.awt.Font var37 = var36.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var36);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var40.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var43 = var40.getFrame();
//     java.awt.Paint var44 = var40.getBackgroundPaint();
//     var38.addSubtitle((org.jfree.chart.title.Title)var40);
//     java.awt.Paint var46 = var38.getBackgroundPaint();
//     var30.setLabelLinkPaint(var46);
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.RingPlot var49 = new org.jfree.chart.plot.RingPlot(var48);
//     double var50 = var49.getLabelLinkMargin();
//     var49.setLabelGap((-1.0d));
//     java.awt.Stroke var53 = var49.getLabelOutlineStroke();
//     java.awt.Stroke var54 = var49.getLabelLinkStroke();
//     var30.setBaseSectionOutlineStroke(var54);
//     var0.put((java.lang.Comparable)"RectangleAnchor.CENTER", var54);
//     
//     // Checks the contract:  equals-hashcode on var18 and var36
//     assertTrue("Contract failed: equals-hashcode on var18 and var36", var18.equals(var36) ? var18.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var18
//     assertTrue("Contract failed: equals-hashcode on var36 and var18", var36.equals(var18) ? var36.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setVisible(false);
    var1.setUpperMargin(0.2d);
    float var6 = var1.getTickMarkInsideLength();
    var1.setVisible(false);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    boolean var11 = var10.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var10.setURLGenerator(var12);
    org.jfree.chart.event.PlotChangeListener var14 = null;
    var10.addChangeListener(var14);
    java.awt.Shape var16 = var10.getLegendItemShape();
    java.awt.Stroke var17 = var10.getBaseSectionOutlineStroke();
    var1.setTickMarkStroke(var17);
    org.jfree.data.RangeType var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeType(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
    double var6 = var5.getLabelLinkMargin();
    var5.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    org.jfree.chart.event.TitleChangeListener var10 = null;
    var9.addChangeListener(var10);
    org.jfree.chart.block.BlockContainer var12 = null;
    var9.setWrapper(var12);
    var3.addSubtitle((org.jfree.chart.title.Title)var9);
    java.awt.Paint var15 = null;
    var9.setBackgroundPaint(var15);
    org.jfree.chart.util.HorizontalAlignment var17 = var9.getHorizontalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    var0.setDepthFactor((-1.0d));
    var0.setSectionOutlinesVisible(false);
    var0.setDarkerSides(true);
    java.lang.String var7 = var0.getPlotType();
    var0.setLabelLinkMargin(0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Pie 3D Plot"+ "'", var7.equals("Pie 3D Plot"));

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleEdge.RIGHT", var1);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("RectangleAnchor.CENTER", var1, var2);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    var0.setAnchorValue(0.025d, false);
    var0.setRangeCrosshairLockedOnData(false);
    java.lang.Object var10 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
    var0.setRangeCrosshairLockedOnData(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("TextAnchor.CENTER", var1);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(100.0d, 0.05d, 0.12d, 10.0d);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Paint var7 = var5.getItemPaint();
//     java.awt.Font var8 = var5.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 0.2d, 0.025d);
//     org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var13);
//     java.lang.Object var15 = var14.clone();
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var17.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var20 = var17.getFrame();
//     java.awt.Paint var21 = var17.getBackgroundPaint();
//     var17.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
//     java.awt.Paint var32 = var31.getPaint();
//     var17.setFrame((org.jfree.chart.block.BlockFrame)var31);
//     java.lang.Object var34 = var17.clone();
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     double var37 = var36.getLabelLinkMargin();
//     var36.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
//     double var41 = var40.getContentXOffset();
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var43.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var46 = var43.getFrame();
//     var40.setFrame(var46);
//     org.jfree.chart.event.TitleChangeEvent var48 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var40);
//     var14.add((org.jfree.chart.block.Block)var17, (java.lang.Object)var40);
//     
//     // Checks the contract:  equals-hashcode on var1 and var36
//     assertTrue("Contract failed: equals-hashcode on var1 and var36", var1.equals(var36) ? var1.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var1
//     assertTrue("Contract failed: equals-hashcode on var36 and var1", var36.equals(var1) ? var36.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
//     java.awt.Stroke var5 = var3.getLabelOutlineStroke();
//     var0.setRangeCrosshairStroke(var5);
//     org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
//     org.jfree.chart.plot.Marker var8 = null;
//     org.jfree.chart.util.Layer var9 = null;
//     boolean var10 = var0.removeDomainMarker(var8, var9);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    double var5 = var4.getLabelLinkMargin();
    var4.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    double var9 = var8.getContentXOffset();
    java.awt.Paint var10 = var8.getItemPaint();
    java.awt.Font var11 = var8.getItemFont();
    var1.setTickLabelFont((java.lang.Comparable)(-1.0d), var11);
    var1.configure();
    org.jfree.chart.axis.CategoryLabelPositions var14 = var1.getCategoryLabelPositions();
    var1.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     double var13 = var12.getContentXOffset();
//     java.awt.Paint var14 = var12.getItemPaint();
//     java.awt.Font var15 = var12.getItemFont();
//     var6.setLabelFont(var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
//     var3.removeSubtitle((org.jfree.chart.title.Title)var17);
//     java.lang.Object var19 = var17.clone();
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
//     double var25 = var24.getLabelLinkMargin();
//     var24.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
//     double var29 = var28.getContentXOffset();
//     java.awt.Paint var30 = var28.getItemPaint();
//     java.awt.Font var31 = var28.getItemFont();
//     var21.setTickLabelFont((java.lang.Comparable)(-1.0d), var31);
//     java.awt.Font var34 = null;
//     var21.setTickLabelFont((java.lang.Comparable)(-1), var34);
//     double var36 = var21.getFixedDimension();
//     boolean var37 = var21.isTickLabelsVisible();
//     java.awt.Paint var38 = var21.getTickLabelPaint();
//     var17.setPaint(var38);
//     
//     // Checks the contract:  equals-hashcode on var8 and var24
//     assertTrue("Contract failed: equals-hashcode on var8 and var24", var8.equals(var24) ? var8.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var8
//     assertTrue("Contract failed: equals-hashcode on var24 and var8", var24.equals(var8) ? var24.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
//     java.util.List var2 = var1.getLines();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     double var5 = var4.getLabelLinkMargin();
//     var4.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     double var9 = var8.getContentXOffset();
//     java.awt.Paint var10 = var8.getItemPaint();
//     java.awt.Font var11 = var8.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var12 = var8.getHorizontalAlignment();
//     var1.setLineAlignment(var12);
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var16 = null;
//     var15.addFragment(var16);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.chart.renderer.RendererState var19 = new org.jfree.chart.renderer.RendererState(var18);
//     boolean var20 = var15.equals((java.lang.Object)var18);
//     var1.addLine(var15);
//     boolean var22 = var0.equals((java.lang.Object)var15);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.util.Size2D var24 = var15.calculateDimensions(var23);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)'4');
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainAxes();
//     java.awt.Graphics2D var2 = null;
//     java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var7 = var6.getGreen();
//     int var8 = var6.getRGB();
//     int var9 = var6.getAlpha();
//     float[] var10 = null;
//     float[] var11 = var6.getRGBComponents(var10);
//     java.awt.image.ColorModel var12 = null;
//     java.awt.Rectangle var13 = null;
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     java.awt.Font var17 = var16.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var20.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var23 = var20.getFrame();
//     java.awt.Paint var24 = var20.getBackgroundPaint();
//     var18.addSubtitle((org.jfree.chart.title.Title)var20);
//     java.awt.Paint var26 = var18.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var18.removeSubtitle((org.jfree.chart.title.Title)var28);
//     org.jfree.chart.event.ChartChangeEventType var30 = null;
//     org.jfree.chart.event.ChartChangeEvent var31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var18, var30);
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var33.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var36 = var33.getFrame();
//     java.awt.Paint var37 = var33.getBackgroundPaint();
//     var33.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var18.setTitle(var33);
//     java.awt.geom.Rectangle2D var44 = var33.getBounds();
//     java.awt.geom.AffineTransform var45 = null;
//     java.awt.RenderingHints var46 = null;
//     java.awt.PaintContext var47 = var6.createContext(var12, var13, var44, var45, var46);
//     java.awt.geom.Point2D var48 = null;
//     org.jfree.chart.plot.PlotState var49 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     var0.draw(var2, var44, var48, var49, var50);
//     org.jfree.chart.plot.ValueMarker var54 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var55 = null;
//     var54.notifyListeners(var55);
//     org.jfree.chart.util.Layer var57 = null;
//     boolean var58 = var0.removeRangeMarker(10, (org.jfree.chart.plot.Marker)var54, var57);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = null;
//     org.jfree.chart.util.Size2D var9 = var5.arrange(var7, var8);
//     org.jfree.chart.util.RectangleEdge var10 = var5.getPosition();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     double var13 = var12.getLabelLinkMargin();
//     var12.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
//     org.jfree.chart.event.TitleChangeListener var17 = null;
//     var16.addChangeListener(var17);
//     double var19 = var16.getContentYOffset();
//     org.jfree.chart.util.RectangleAnchor var20 = var16.getLegendItemGraphicLocation();
//     var5.setLegendItemGraphicAnchor(var20);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.chart.axis.ValueAxis var5 = var3.getAxis();
    org.jfree.data.xy.XYDataset var6 = null;
    var3.setDataset(var6);
    java.awt.Color var11 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    var3.setAngleGridlinePaint((java.awt.Paint)var11);
    java.awt.Paint var13 = var3.getAngleLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     var0.clear();
//     org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var3.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var6 = var3.getFrame();
//     java.awt.Paint var7 = var3.getBackgroundPaint();
//     var3.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
//     java.awt.Paint var18 = var17.getPaint();
//     var3.setFrame((org.jfree.chart.block.BlockFrame)var17);
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     var20.clearRangeAxes();
//     org.jfree.chart.event.RendererChangeEvent var22 = null;
//     var20.rendererChanged(var22);
//     var0.add((org.jfree.chart.block.Block)var3, (java.lang.Object)var22);
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var26.setToolTipText("ThreadContext");
//     java.lang.Object var29 = var26.clone();
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     boolean var34 = var31.equals((java.lang.Object)var33);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     double var37 = var36.getLabelLinkMargin();
//     var36.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
//     double var41 = var40.getContentXOffset();
//     java.awt.Paint var42 = var40.getItemPaint();
//     java.awt.Font var43 = var40.getItemFont();
//     var31.setLabelFont(var43);
//     java.awt.Paint var45 = var31.getLabelPaint();
//     java.awt.Paint var46 = var31.getPaint();
//     boolean var47 = var26.equals((java.lang.Object)var31);
//     var26.setWidth(100.0d);
//     java.lang.String var50 = var26.getToolTipText();
//     org.jfree.chart.text.TextBlock var51 = new org.jfree.chart.text.TextBlock();
//     java.util.List var52 = var51.getLines();
//     org.jfree.data.general.PieDataset var53 = null;
//     org.jfree.chart.plot.RingPlot var54 = new org.jfree.chart.plot.RingPlot(var53);
//     double var55 = var54.getLabelLinkMargin();
//     var54.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54);
//     double var59 = var58.getContentXOffset();
//     java.awt.Paint var60 = var58.getItemPaint();
//     java.awt.Font var61 = var58.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var62 = var58.getHorizontalAlignment();
//     var51.setLineAlignment(var62);
//     org.jfree.chart.util.VerticalAlignment var64 = null;
//     org.jfree.chart.block.ColumnArrangement var67 = new org.jfree.chart.block.ColumnArrangement(var62, var64, 4.0d, 0.14d);
//     var0.add((org.jfree.chart.block.Block)var26, (java.lang.Object)4.0d);
//     
//     // Checks the contract:  equals-hashcode on var36 and var54
//     assertTrue("Contract failed: equals-hashcode on var36 and var54", var36.equals(var54) ? var36.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var36
//     assertTrue("Contract failed: equals-hashcode on var54 and var36", var54.equals(var36) ? var54.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.LegendItemSource[] var6 = var5.getSources();
//     var5.setID("ThreadContext");
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var10 = var9.getRangeCrosshairStroke();
//     java.lang.String var11 = var9.getPlotType();
//     boolean var12 = var9.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     var9.setRangeAxis(var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     double var17 = var16.getLabelLinkMargin();
//     var16.setLabelGap((-1.0d));
//     java.awt.Stroke var20 = var16.getLabelOutlineStroke();
//     var9.setRangeCrosshairStroke(var20);
//     org.jfree.chart.axis.CategoryAxis var23 = var9.getDomainAxis(0);
//     org.jfree.chart.util.RectangleEdge var25 = var9.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var26 = org.jfree.chart.util.RectangleEdge.opposite(var25);
//     var5.setPosition(var25);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     double var13 = var12.getContentXOffset();
//     java.awt.Paint var14 = var12.getItemPaint();
//     java.awt.Font var15 = var12.getItemFont();
//     var6.setLabelFont(var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
//     var3.removeSubtitle((org.jfree.chart.title.Title)var17);
//     java.awt.Image var19 = null;
//     var3.setBackgroundImage(var19);
//     org.jfree.chart.title.TextTitle var21 = var3.getTitle();
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var23 = var22.getRangeCrosshairStroke();
//     java.lang.String var24 = var22.getPlotType();
//     boolean var25 = var22.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
//     var28.setVisible(false);
//     var28.setUpperMargin(0.2d);
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var35 = var34.getRange();
//     java.lang.Object var36 = var34.clone();
//     org.jfree.chart.axis.NumberTickUnit var37 = var34.getTickUnit();
//     var28.setTickUnit(var37);
//     var22.setRangeAxis(15, (org.jfree.chart.axis.ValueAxis)var28, true);
//     var28.setAutoRange(false);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var45 = null;
//     var43.setRangeAxisLocation(1, var45, false);
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.RingPlot var49 = new org.jfree.chart.plot.RingPlot(var48);
//     boolean var50 = var49.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var51 = null;
//     var49.setURLGenerator(var51);
//     org.jfree.chart.event.PlotChangeListener var53 = null;
//     var49.addChangeListener(var53);
//     java.awt.Shape var55 = var49.getLegendItemShape();
//     java.awt.Stroke var56 = var49.getBaseSectionOutlineStroke();
//     var43.setDomainGridlineStroke(var56);
//     org.jfree.chart.axis.CategoryAxis3D var58 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var59 = var58.getLowerMargin();
//     var43.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var58);
//     var58.setTickMarkOutsideLength(10.0f);
//     java.awt.Stroke var63 = var58.getTickMarkStroke();
//     var28.setAxisLineStroke(var63);
//     var3.setBorderStroke(var63);
//     
//     // Checks the contract:  equals-hashcode on var1 and var49
//     assertTrue("Contract failed: equals-hashcode on var1 and var49", var1.equals(var49) ? var1.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var1
//     assertTrue("Contract failed: equals-hashcode on var49 and var1", var49.equals(var1) ? var49.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var1 = var0.clone();
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var3 = var0.getTickLabelPaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     double var6 = var5.getLabelLinkMargin();
//     var5.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     org.jfree.chart.event.TitleChangeListener var10 = null;
//     var9.addChangeListener(var10);
//     org.jfree.chart.block.BlockContainer var12 = null;
//     var9.setWrapper(var12);
//     var3.addSubtitle((org.jfree.chart.title.Title)var9);
//     var3.setBackgroundImageAlpha((-1.0f));
//     org.jfree.chart.util.Size2D var19 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
//     java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var24 = var23.getAlpha();
//     java.awt.Color var25 = var23.brighter();
//     boolean var26 = var19.equals((java.lang.Object)var23);
//     var3.setBorderPaint((java.awt.Paint)var23);
//     int var28 = var23.getTransparency();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
//     org.jfree.chart.event.PlotChangeEvent var31 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var30);
//     java.awt.Stroke var32 = var30.getLabelOutlineStroke();
//     java.awt.Paint var33 = var30.getSeparatorPaint();
//     boolean var34 = var30.isCircular();
//     java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var39 = var38.getGreen();
//     var30.setSeparatorPaint((java.awt.Paint)var38);
//     java.awt.color.ColorSpace var41 = var38.getColorSpace();
//     java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var46 = var45.getAlpha();
//     java.awt.Color var47 = var45.brighter();
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.RingPlot var49 = new org.jfree.chart.plot.RingPlot(var48);
//     org.jfree.chart.event.PlotChangeEvent var50 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var49);
//     java.awt.Stroke var51 = var49.getLabelOutlineStroke();
//     java.awt.Paint var52 = var49.getSeparatorPaint();
//     boolean var53 = var49.isCircular();
//     java.awt.Color var57 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var58 = var57.getGreen();
//     var49.setSeparatorPaint((java.awt.Paint)var57);
//     java.awt.color.ColorSpace var60 = var57.getColorSpace();
//     float[] var64 = new float[] { 10.0f, 1.0f, 100.0f};
//     float[] var65 = var47.getColorComponents(var60, var64);
//     float[] var66 = var23.getColorComponents(var41, var65);
//     
//     // Checks the contract:  equals-hashcode on var30 and var49
//     assertTrue("Contract failed: equals-hashcode on var30 and var49", var30.equals(var49) ? var30.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var30
//     assertTrue("Contract failed: equals-hashcode on var49 and var30", var49.equals(var30) ? var49.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
    java.lang.Object var3 = var2.clone();
    var0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var5 = null;
    var3.setRangeAxisLocation(1, var5, false);
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    boolean var10 = var9.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var11 = null;
    var9.setURLGenerator(var11);
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var9.addChangeListener(var13);
    java.awt.Shape var15 = var9.getLegendItemShape();
    java.awt.Stroke var16 = var9.getBaseSectionOutlineStroke();
    var3.setDomainGridlineStroke(var16);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
    double var22 = var21.getLabelLinkMargin();
    var21.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
    double var26 = var25.getContentXOffset();
    java.awt.Paint var27 = var25.getItemPaint();
    java.awt.Font var28 = var25.getItemFont();
    var19.setLabelFont(var28);
    org.jfree.chart.util.Layer var30 = null;
    var3.addRangeMarker((org.jfree.chart.plot.Marker)var19, var30);
    java.awt.Paint var32 = var19.getPaint();
    java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var37 = var36.getGreen();
    int var38 = var36.getRGB();
    int var39 = var36.getAlpha();
    float[] var40 = null;
    float[] var41 = var36.getRGBComponents(var40);
    var19.setOutlinePaint((java.awt.Paint)var36);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var19);
    org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D("");
    var46.setVisible(false);
    var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var46, true);
    org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D();
    double var52 = var51.getLowerMargin();
    org.jfree.data.xy.XYDataset var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.PolarItemRenderer var56 = null;
    org.jfree.chart.plot.PolarPlot var57 = new org.jfree.chart.plot.PolarPlot(var54, var55, var56);
    java.awt.Font var58 = var57.getAngleLabelFont();
    java.awt.Font var59 = var57.getAngleLabelFont();
    java.awt.Color var63 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var64 = var63.getGreen();
    int var65 = var63.getRGB();
    int var66 = var63.getAlpha();
    float[] var67 = null;
    float[] var68 = var63.getRGBComponents(var67);
    int var69 = var63.getAlpha();
    var57.setRadiusGridlinePaint((java.awt.Paint)var63);
    var51.setTickLabelPaint((java.lang.Comparable)(short)(-1), (java.awt.Paint)var63);
    java.util.List var72 = var0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var51);
    java.lang.String var73 = var0.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Pie Plot", var1, var2);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     var0.clearRangeAxes();
//     java.awt.Stroke var2 = var0.getRangeGridlineStroke();
//     org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var4.equals((java.lang.Object)var6);
//     boolean var8 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var4);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    double var3 = var1.getMaximumExplodePercent();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
    double var6 = var5.getLabelLinkMargin();
    var5.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var10 = var9.getContentXOffset();
    java.awt.Paint var11 = var9.getItemPaint();
    var1.setLabelLinkPaint(var11);
    org.jfree.chart.util.Rotation var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDirection(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     double var8 = var7.getLabelLinkMargin();
//     var7.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
//     org.jfree.chart.util.RectangleInsets var12 = var11.getPadding();
//     double var13 = var12.getRight();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var16 = var15.getRange();
//     double var17 = var15.getAutoRangeMinimumSize();
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var23 = var22.getGreen();
//     int var24 = var22.getRGB();
//     int var25 = var22.getAlpha();
//     float[] var26 = null;
//     float[] var27 = var22.getRGBComponents(var26);
//     java.awt.image.ColorModel var28 = null;
//     java.awt.Rectangle var29 = null;
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.RingPlot var32 = new org.jfree.chart.plot.RingPlot(var31);
//     java.awt.Font var33 = var32.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var32);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var36.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var39 = var36.getFrame();
//     java.awt.Paint var40 = var36.getBackgroundPaint();
//     var34.addSubtitle((org.jfree.chart.title.Title)var36);
//     java.awt.Paint var42 = var34.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var34.removeSubtitle((org.jfree.chart.title.Title)var44);
//     org.jfree.chart.event.ChartChangeEventType var46 = null;
//     org.jfree.chart.event.ChartChangeEvent var47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var34, var46);
//     org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var49.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var52 = var49.getFrame();
//     java.awt.Paint var53 = var49.getBackgroundPaint();
//     var49.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var34.setTitle(var49);
//     java.awt.geom.Rectangle2D var60 = var49.getBounds();
//     java.awt.geom.AffineTransform var61 = null;
//     java.awt.RenderingHints var62 = null;
//     java.awt.PaintContext var63 = var22.createContext(var28, var29, var60, var61, var62);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     var64.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var67 = var64.getRangeAxisEdge(1);
//     double var68 = var15.valueToJava2D(0.2d, var60, var67);
//     var12.trim(var60);
//     org.jfree.chart.plot.PiePlot var70 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     org.jfree.chart.plot.PiePlotState var73 = var1.initialise(var5, var60, var70, (java.lang.Integer)4, var72);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     var0.setAnchorValue(0.025d, false);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     double var10 = var9.getLabelLinkMargin();
//     var9.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     org.jfree.chart.event.TitleChangeListener var14 = null;
//     var13.addChangeListener(var14);
//     org.jfree.chart.block.BlockContainer var16 = null;
//     var13.setWrapper(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var13.getPadding();
//     var0.setInsets(var18, false);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var23 = null;
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot(var21, var22, var23);
//     org.jfree.data.xy.XYDataset var25 = null;
//     var24.setDataset(var25);
//     java.awt.Paint var27 = var24.getRadiusGridlinePaint();
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("");
//     var29.setVisible(false);
//     var29.setUpperMargin(0.2d);
//     float var34 = var29.getTickMarkInsideLength();
//     var29.setAutoRangeMinimumSize(1.0E-5d);
//     var24.setAxis((org.jfree.chart.axis.ValueAxis)var29);
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var29);
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     var39.clearRangeAxes();
//     org.jfree.chart.axis.ValueAxis var41 = var39.getDomainAxis();
//     org.jfree.chart.util.Layer var42 = null;
//     java.util.Collection var43 = var39.getRangeMarkers(var42);
//     org.jfree.chart.plot.PiePlot3D var44 = new org.jfree.chart.plot.PiePlot3D();
//     var44.setDepthFactor((-1.0d));
//     var44.setCircular(true);
//     org.jfree.data.general.PieDataset var49 = null;
//     org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot(var49);
//     double var51 = var50.getLabelLinkMargin();
//     var50.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
//     double var55 = var54.getContentXOffset();
//     java.awt.Paint var56 = var54.getItemPaint();
//     org.jfree.data.general.PieDataset var57 = null;
//     org.jfree.chart.plot.RingPlot var58 = new org.jfree.chart.plot.RingPlot(var57);
//     org.jfree.chart.event.PlotChangeEvent var59 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var58);
//     java.awt.Stroke var60 = var58.getLabelOutlineStroke();
//     var58.setSectionOutlinesVisible(true);
//     java.awt.Stroke var63 = var58.getLabelOutlineStroke();
//     boolean var64 = var54.equals((java.lang.Object)var63);
//     var44.setLabelOutlineStroke(var63);
//     var39.setDomainZeroBaselineStroke(var63);
//     var0.setDomainGridlineStroke(var63);
//     
//     // Checks the contract:  equals-hashcode on var9 and var50
//     assertTrue("Contract failed: equals-hashcode on var9 and var50", var9.equals(var50) ? var9.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var9
//     assertTrue("Contract failed: equals-hashcode on var50 and var9", var50.equals(var9) ? var50.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     boolean var7 = var6.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var6.setURLGenerator(var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var6.addChangeListener(var10);
//     java.awt.Shape var12 = var6.getLegendItemShape();
//     java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
//     var0.setDomainGridlineStroke(var13);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     double var19 = var18.getLabelLinkMargin();
//     var18.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     double var23 = var22.getContentXOffset();
//     java.awt.Paint var24 = var22.getItemPaint();
//     java.awt.Font var25 = var22.getItemFont();
//     var16.setLabelFont(var25);
//     org.jfree.chart.util.Layer var27 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var30.setMaximumCategoryLabelWidthRatio(0.0f);
//     java.awt.Paint var34 = var30.getTickLabelPaint((java.lang.Comparable)(-16777216));
//     var16.setOutlinePaint(var34);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot(var38);
//     boolean var40 = var37.equals((java.lang.Object)var39);
//     org.jfree.chart.text.TextAnchor var41 = var37.getLabelTextAnchor();
//     java.lang.String var42 = var41.toString();
//     var16.setLabelTextAnchor(var41);
//     
//     // Checks the contract:  equals-hashcode on var6 and var39
//     assertTrue("Contract failed: equals-hashcode on var6 and var39", var6.equals(var39) ? var6.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var6
//     assertTrue("Contract failed: equals-hashcode on var39 and var6", var39.equals(var6) ? var39.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.clearRangeAxes();
    org.jfree.chart.event.RendererChangeEvent var2 = null;
    var0.rendererChanged(var2);
    org.jfree.chart.plot.PlotOrientation var4 = var0.getOrientation();
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    org.jfree.chart.LegendItemCollection var10 = var9.getLegendItems();
    java.lang.Object var11 = var10.clone();
    boolean var13 = var10.equals((java.lang.Object)false);
    var0.setFixedLegendItems(var10);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var16.setValue(1.0d);
    var16.setLabel("Pie 3D Plot");
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
    double var23 = var22.getLabelLinkMargin();
    var22.setLabelGap((-1.0d));
    java.awt.Stroke var26 = var22.getLabelOutlineStroke();
    java.awt.Stroke var27 = var22.getLabelLinkStroke();
    var22.setLabelLinkMargin(0.0d);
    java.awt.Paint var30 = var22.getShadowPaint();
    var16.setPaint(var30);
    org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.plot.RingPlot var35 = new org.jfree.chart.plot.RingPlot(var34);
    boolean var36 = var33.equals((java.lang.Object)var35);
    org.jfree.chart.text.TextAnchor var37 = var33.getLabelTextAnchor();
    java.lang.String var38 = var37.toString();
    java.lang.Object var39 = null;
    boolean var40 = var37.equals(var39);
    var16.setLabelTextAnchor(var37);
    org.jfree.chart.util.Layer var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var16, var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "TextAnchor.CENTER"+ "'", var38.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.clearRangeAxes();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis();
    org.jfree.chart.util.Layer var3 = null;
    java.util.Collection var4 = var0.getRangeMarkers(var3);
    var0.clearDomainAxes();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    java.awt.Font var9 = var8.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var12.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var15 = var12.getFrame();
    java.awt.Paint var16 = var12.getBackgroundPaint();
    var10.addSubtitle((org.jfree.chart.title.Title)var12);
    java.awt.Paint var18 = var10.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var10.removeSubtitle((org.jfree.chart.title.Title)var20);
    org.jfree.chart.event.ChartChangeEventType var22 = null;
    org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var10, var22);
    org.jfree.chart.JFreeChart var24 = var23.getChart();
    org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
    java.awt.Paint var30 = var29.getPaint();
    var24.setBorderPaint(var30);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var24);
    var0.setRangeZeroBaselineVisible(false);
    org.jfree.data.general.PieDataset var36 = null;
    org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot(var36);
    java.awt.Font var38 = var37.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var37);
    org.jfree.data.general.PieDataset var40 = null;
    org.jfree.chart.plot.RingPlot var41 = new org.jfree.chart.plot.RingPlot(var40);
    double var42 = var41.getLabelLinkMargin();
    var41.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
    org.jfree.chart.event.TitleChangeListener var46 = null;
    var45.addChangeListener(var46);
    org.jfree.chart.block.BlockContainer var48 = null;
    var45.setWrapper(var48);
    var39.addSubtitle((org.jfree.chart.title.Title)var45);
    var39.setBackgroundImageAlpha((-1.0f));
    org.jfree.chart.util.Size2D var55 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
    java.awt.Color var59 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var60 = var59.getAlpha();
    java.awt.Color var61 = var59.brighter();
    boolean var62 = var55.equals((java.lang.Object)var59);
    var39.setBorderPaint((java.awt.Paint)var59);
    java.awt.Color var64 = var59.brighter();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint(255, (java.awt.Paint)var64);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var3.setMaximumCategoryLabelWidthRatio(0.0f);
//     double var6 = var3.getLowerMargin();
//     org.jfree.chart.plot.DefaultDrawingSupplier var8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var9 = var8.getNextFillPaint();
//     java.awt.Paint var10 = var8.getNextFillPaint();
//     var3.setTickLabelPaint((java.lang.Comparable)100L, var10);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     java.awt.Font var17 = var16.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var20.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var23 = var20.getFrame();
//     java.awt.Paint var24 = var20.getBackgroundPaint();
//     var18.addSubtitle((org.jfree.chart.title.Title)var20);
//     java.awt.Paint var26 = var18.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var18.removeSubtitle((org.jfree.chart.title.Title)var28);
//     org.jfree.chart.event.ChartChangeEventType var30 = null;
//     org.jfree.chart.event.ChartChangeEvent var31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var18, var30);
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var33.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var36 = var33.getFrame();
//     java.awt.Paint var37 = var33.getBackgroundPaint();
//     var33.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var18.setTitle(var33);
//     java.awt.geom.Rectangle2D var44 = var33.getBounds();
//     org.jfree.chart.entity.ChartEntity var46 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var44, "poly");
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     var47.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var50 = var47.getRangeAxisEdge(1);
//     double var51 = var3.getCategoryStart(0, 10, var44, var50);
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var54 = null;
//     var52.setRangeAxisLocation(1, var54, false);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var60 = null;
//     var58.setRangeAxisLocation(1, var60, false);
//     org.jfree.data.general.PieDataset var63 = null;
//     org.jfree.chart.plot.RingPlot var64 = new org.jfree.chart.plot.RingPlot(var63);
//     boolean var65 = var64.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var66 = null;
//     var64.setURLGenerator(var66);
//     org.jfree.chart.event.PlotChangeListener var68 = null;
//     var64.addChangeListener(var68);
//     java.awt.Shape var70 = var64.getLegendItemShape();
//     java.awt.Stroke var71 = var64.getBaseSectionOutlineStroke();
//     var58.setDomainGridlineStroke(var71);
//     org.jfree.chart.axis.CategoryAxis3D var73 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var74 = var73.getLowerMargin();
//     var58.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var73);
//     java.lang.Object var76 = var73.clone();
//     var52.setDomainAxis(10, (org.jfree.chart.axis.CategoryAxis)var73);
//     org.jfree.data.general.PieDataset var78 = null;
//     org.jfree.chart.plot.RingPlot var79 = new org.jfree.chart.plot.RingPlot(var78);
//     double var80 = var79.getLabelLinkMargin();
//     var79.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var83 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var79);
//     org.jfree.chart.event.TitleChangeListener var84 = null;
//     var83.addChangeListener(var84);
//     org.jfree.chart.block.BlockContainer var86 = null;
//     var83.setWrapper(var86);
//     org.jfree.chart.util.RectangleInsets var88 = var83.getPadding();
//     var73.setLabelInsets(var88);
//     java.lang.Object var90 = var0.draw(var1, var44, (java.lang.Object)var88);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    double var23 = var22.getContentXOffset();
    java.awt.Paint var24 = var22.getItemPaint();
    java.awt.Font var25 = var22.getItemFont();
    var16.setLabelFont(var25);
    org.jfree.chart.util.Layer var27 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
    double var29 = var0.getRangeCrosshairValue();
    var0.setWeight(100);
    var0.setDomainGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    java.awt.Stroke var3 = var1.getLabelOutlineStroke();
    java.awt.Paint var4 = var1.getSeparatorPaint();
    org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 10.0d, 10.0d);
    java.awt.Paint var10 = var9.getPaint();
    var1.setBaseSectionPaint(var10);
    java.lang.String var12 = var1.getPlotType();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    java.awt.Font var15 = var14.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    org.jfree.chart.event.TitleChangeListener var23 = null;
    var22.addChangeListener(var23);
    org.jfree.chart.block.BlockContainer var25 = null;
    var22.setWrapper(var25);
    var16.addSubtitle((org.jfree.chart.title.Title)var22);
    var16.setBackgroundImageAlpha((-1.0f));
    org.jfree.chart.util.Size2D var32 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
    java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var37 = var36.getAlpha();
    java.awt.Color var38 = var36.brighter();
    boolean var39 = var32.equals((java.lang.Object)var36);
    var16.setBorderPaint((java.awt.Paint)var36);
    int var41 = var36.getTransparency();
    var1.setLabelPaint((java.awt.Paint)var36);
    int var43 = var36.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Pie Plot"+ "'", var12.equals("Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 255);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearAnnotations();
//     var0.clearDomainAxes();
//     int var3 = var0.getBackgroundImageAlignment();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     org.jfree.chart.event.PlotChangeEvent var6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var5);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     org.jfree.chart.event.PlotChangeEvent var10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var9);
//     java.awt.Stroke var11 = var9.getLabelOutlineStroke();
//     java.awt.Paint var12 = var9.getSeparatorPaint();
//     var5.setSectionOutlinePaint((java.lang.Comparable)(-1.0d), var12);
//     org.jfree.chart.util.RectangleInsets var14 = var5.getSimpleLabelOffset();
//     double var16 = var14.extendWidth((-15.95d));
//     var0.setInsets(var14, false);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var20 = var19.getRangeCrosshairStroke();
//     java.lang.String var21 = var19.getPlotType();
//     boolean var22 = var19.getDrawSharedDomainAxis();
//     var19.mapDatasetToRangeAxis(0, 100);
//     org.jfree.chart.util.RectangleEdge var27 = var19.getDomainAxisEdge(10);
//     org.jfree.chart.util.SortOrder var28 = var19.getRowRenderingOrder();
//     var0.setColumnRenderingOrder(var28);
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var32, var33, var34);
//     java.awt.Stroke var36 = null;
//     var35.setRadiusGridlineStroke(var36);
//     org.jfree.data.xy.XYDataset var38 = var35.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var43 = var42.getRangeCrosshairStroke();
//     java.lang.String var44 = var42.getPlotType();
//     boolean var45 = var42.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     var42.setRangeAxis(var46);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.RingPlot var53 = new org.jfree.chart.plot.RingPlot(var52);
//     java.awt.Font var54 = var53.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var53);
//     org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var57.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var60 = var57.getFrame();
//     java.awt.Paint var61 = var57.getBackgroundPaint();
//     var55.addSubtitle((org.jfree.chart.title.Title)var57);
//     java.awt.Paint var63 = var55.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var65 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var55.removeSubtitle((org.jfree.chart.title.Title)var65);
//     org.jfree.chart.event.ChartChangeEventType var67 = null;
//     org.jfree.chart.event.ChartChangeEvent var68 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var55, var67);
//     org.jfree.chart.title.TextTitle var70 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var70.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var73 = var70.getFrame();
//     java.awt.Paint var74 = var70.getBackgroundPaint();
//     var70.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var55.setTitle(var70);
//     java.awt.geom.Rectangle2D var81 = var70.getBounds();
//     org.jfree.data.general.PieDataset var82 = null;
//     org.jfree.chart.plot.RingPlot var83 = new org.jfree.chart.plot.RingPlot(var82);
//     double var84 = var83.getLabelLinkMargin();
//     var83.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var87 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var83);
//     double var88 = var87.getContentXOffset();
//     java.awt.Paint var89 = var87.getItemPaint();
//     java.awt.Font var90 = var87.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var91 = var87.getLegendItemGraphicAnchor();
//     boolean var93 = var91.equals((java.lang.Object)0L);
//     java.awt.geom.Point2D var94 = org.jfree.chart.util.RectangleAnchor.coordinates(var81, var91);
//     var42.zoomDomainAxes((-1.0d), 0.0d, var50, var94);
//     var35.zoomDomainAxes(100.0d, 0.12d, var41, var94);
//     var0.zoomRangeAxes((-24.921874999999996d), var31, var94);
//     
//     // Checks the contract:  equals-hashcode on var9 and var53
//     assertTrue("Contract failed: equals-hashcode on var9 and var53", var9.equals(var53) ? var9.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var9
//     assertTrue("Contract failed: equals-hashcode on var53 and var9", var53.equals(var9) ? var53.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var1.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var4 = var1.getFrame();
    java.awt.Paint var5 = var1.getBackgroundPaint();
    var1.setID("");
    java.lang.String var8 = var1.getToolTipText();
    var1.setText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "ThreadContext"+ "'", var8.equals("ThreadContext"));

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     double var13 = var12.getContentXOffset();
//     java.awt.Paint var14 = var12.getItemPaint();
//     java.awt.Font var15 = var12.getItemFont();
//     var6.setLabelFont(var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
//     var3.removeSubtitle((org.jfree.chart.title.Title)var17);
//     java.lang.Object var19 = var3.clone();
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
//     java.awt.Font var22 = var21.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var21);
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var25.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var28 = var25.getFrame();
//     java.awt.Paint var29 = var25.getBackgroundPaint();
//     var23.addSubtitle((org.jfree.chart.title.Title)var25);
//     var3.setTitle(var25);
//     
//     // Checks the contract:  equals-hashcode on var1 and var21
//     assertTrue("Contract failed: equals-hashcode on var1 and var21", var1.equals(var21) ? var1.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var1
//     assertTrue("Contract failed: equals-hashcode on var21 and var1", var21.equals(var1) ? var21.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    boolean var2 = var1.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var1.setURLGenerator(var3);
    org.jfree.chart.event.PlotChangeListener var5 = null;
    var1.addChangeListener(var5);
    java.awt.Shape var7 = var1.getLegendItemShape();
    java.awt.Paint var8 = var1.getLabelShadowPaint();
    java.awt.Font var9 = var1.getNoDataMessageFont();
    var1.setExplodePercent((java.lang.Comparable)true, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.12d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=0,b=0]", "Rotation.CLOCKWISE", var3);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     int var5 = var0.getDomainAxisCount();
//     org.jfree.chart.event.RendererChangeEvent var6 = null;
//     var0.rendererChanged(var6);
//     org.jfree.chart.util.RectangleEdge var9 = var0.getDomainAxisEdge(255);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Point2D var12 = null;
//     var0.zoomDomainAxes(100.0d, var11, var12, false);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var0.zoomDomainAxes(0.05d, (-15.95d), var17, var18);
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("");
//     var21.setVisible(false);
//     var21.setUpperMargin(0.2d);
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.Range var28 = var27.getRange();
//     java.lang.Object var29 = var27.clone();
//     org.jfree.chart.axis.NumberTickUnit var30 = var27.getTickUnit();
//     var21.setTickUnit(var30);
//     java.awt.Shape var32 = var21.getLeftArrow();
//     boolean var33 = var21.getAutoRangeIncludesZero();
//     org.jfree.chart.axis.ValueAxis[] var34 = new org.jfree.chart.axis.ValueAxis[] { var21};
//     var0.setRangeAxes(var34);
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     var0.handleClick(4, 15, var38);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
    java.awt.Stroke var5 = var3.getLabelOutlineStroke();
    var0.setRangeCrosshairStroke(var5);
    org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataset((-16777216), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(1, var2, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var6.setRangeAxisLocation(1, var8, false);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     boolean var13 = var12.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var14 = null;
//     var12.setURLGenerator(var14);
//     org.jfree.chart.event.PlotChangeListener var16 = null;
//     var12.addChangeListener(var16);
//     java.awt.Shape var18 = var12.getLegendItemShape();
//     java.awt.Stroke var19 = var12.getBaseSectionOutlineStroke();
//     var6.setDomainGridlineStroke(var19);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var22 = var21.getLowerMargin();
//     var6.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var21);
//     java.lang.Object var24 = var21.clone();
//     var0.setDomainAxis(10, (org.jfree.chart.axis.CategoryAxis)var21);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var27 = var26.getRangeCrosshairStroke();
//     org.jfree.data.category.CategoryDataset var28 = var26.getDataset();
//     java.awt.Paint var29 = var26.getDomainGridlinePaint();
//     var21.setAxisLinePaint(var29);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var0.", var26.equals(var0) == var0.equals(var26));
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    java.awt.geom.Rectangle2D var2 = var1.getExplodedPieArea();
    var1.setLatestAngle((-13.95d));
    double var5 = var1.getLatestAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-13.95d));

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.LegendItemSource[] var6 = var5.getSources();
//     var5.setID("ThreadContext");
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     double var11 = var10.getLabelLinkMargin();
//     var10.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
//     org.jfree.chart.util.RectangleInsets var15 = var14.getPadding();
//     var5.setPadding(var15);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("", (-16777216), 4);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    var0.clear();
    var0.clear();
    org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var6 = null;
    var5.addFragment(var6);
    org.jfree.chart.text.TextFragment var8 = null;
    var5.addFragment(var8);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.PolarItemRenderer var12 = null;
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot(var10, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    var13.setDataset(var14);
    java.awt.Paint var16 = var13.getRadiusGridlinePaint();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    org.jfree.chart.event.PlotChangeEvent var19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var18);
    java.awt.Stroke var20 = var18.getLabelOutlineStroke();
    var18.setSectionOutlinesVisible(true);
    java.awt.Stroke var23 = var18.getLabelOutlineStroke();
    var13.setAngleGridlineStroke(var23);
    boolean var25 = var5.equals((java.lang.Object)var23);
    var0.put((java.lang.Comparable)(-15.95d), var23);
    var0.clear();
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
    org.jfree.chart.LegendItemCollection var33 = var32.getLegendItems();
    org.jfree.chart.axis.ValueAxis var34 = var32.getAxis();
    org.jfree.data.xy.XYDataset var35 = null;
    var32.setDataset(var35);
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    java.awt.geom.Point2D var39 = null;
    var32.zoomDomainAxes(1.0E-8d, var38, var39, true);
    java.awt.Stroke var42 = var32.getRadiusGridlineStroke();
    var0.put((java.lang.Comparable)true, var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var45 = var0.containsKey((java.lang.Comparable)(short)100);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     boolean var2 = var1.isSubplot();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var1.setURLGenerator(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var1.addChangeListener(var5);
//     java.awt.Paint var7 = var1.getBaseSectionOutlinePaint();
//     java.awt.Image var8 = null;
//     var1.setBackgroundImage(var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     org.jfree.data.general.DatasetChangeEvent var12 = null;
//     var11.datasetChanged(var12);
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var16 = null;
//     var15.addFragment(var16);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.chart.renderer.RendererState var19 = new org.jfree.chart.renderer.RendererState(var18);
//     boolean var20 = var15.equals((java.lang.Object)var18);
//     boolean var21 = var11.equals((java.lang.Object)var15);
//     org.jfree.chart.util.Rotation var22 = var11.getDirection();
//     boolean var24 = var22.equals((java.lang.Object)(-13.95d));
//     java.lang.String var25 = var22.toString();
//     var1.setDirection(var22);
//     
//     // Checks the contract:  equals-hashcode on var1 and var11
//     assertTrue("Contract failed: equals-hashcode on var1 and var11", var1.equals(var11) ? var1.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var1
//     assertTrue("Contract failed: equals-hashcode on var11 and var1", var11.equals(var1) ? var11.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = null;
//     var3.setDataset(var4);
//     java.awt.Paint var6 = var3.getRadiusGridlinePaint();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getLabelLinkMargin();
//     var8.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     org.jfree.chart.event.TitleChangeListener var13 = null;
//     var12.addChangeListener(var13);
//     org.jfree.chart.block.BlockContainer var15 = null;
//     var12.setWrapper(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var12.getPadding();
//     double var18 = var17.getLeft();
//     var3.setInsets(var17);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     var22.clearRangeAxes();
//     boolean var24 = var22.isDomainCrosshairLockedOnData();
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var29 = var28.getRangeCrosshairStroke();
//     java.lang.String var30 = var28.getPlotType();
//     boolean var31 = var28.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     var28.setRangeAxis(var32);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot(var38);
//     java.awt.Font var40 = var39.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var39);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var43.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var46 = var43.getFrame();
//     java.awt.Paint var47 = var43.getBackgroundPaint();
//     var41.addSubtitle((org.jfree.chart.title.Title)var43);
//     java.awt.Paint var49 = var41.getBackgroundPaint();
//     org.jfree.chart.title.TextTitle var51 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var41.removeSubtitle((org.jfree.chart.title.Title)var51);
//     org.jfree.chart.event.ChartChangeEventType var53 = null;
//     org.jfree.chart.event.ChartChangeEvent var54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d, var41, var53);
//     org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var56.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var59 = var56.getFrame();
//     java.awt.Paint var60 = var56.getBackgroundPaint();
//     var56.setMargin(0.0d, 100.0d, 4.0d, 0.025d);
//     var41.setTitle(var56);
//     java.awt.geom.Rectangle2D var67 = var56.getBounds();
//     org.jfree.data.general.PieDataset var68 = null;
//     org.jfree.chart.plot.RingPlot var69 = new org.jfree.chart.plot.RingPlot(var68);
//     double var70 = var69.getLabelLinkMargin();
//     var69.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var69);
//     double var74 = var73.getContentXOffset();
//     java.awt.Paint var75 = var73.getItemPaint();
//     java.awt.Font var76 = var73.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var77 = var73.getLegendItemGraphicAnchor();
//     boolean var79 = var77.equals((java.lang.Object)0L);
//     java.awt.geom.Point2D var80 = org.jfree.chart.util.RectangleAnchor.coordinates(var67, var77);
//     var28.zoomDomainAxes((-1.0d), 0.0d, var36, var80);
//     var22.zoomDomainAxes(100.0d, 0.05d, var27, var80);
//     var3.zoomDomainAxes((-1.99999d), var21, var80);
//     
//     // Checks the contract:  equals-hashcode on var8 and var69
//     assertTrue("Contract failed: equals-hashcode on var8 and var69", var8.equals(var69) ? var8.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var8
//     assertTrue("Contract failed: equals-hashcode on var69 and var8", var69.equals(var8) ? var69.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)10, var1, var2);
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    var3.setType(var4);
    java.lang.Object var6 = var3.getSource();
    org.jfree.chart.event.ChartChangeEventType var7 = var3.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10+ "'", var6.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.LegendItemSource[] var6 = var5.getSources();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 0.0d);
//     org.jfree.data.Range var11 = var10.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var13 = var10.toFixedHeight(0.2d);
//     org.jfree.data.Range var14 = var13.getWidthRange();
//     org.jfree.chart.util.Size2D var15 = var5.arrange(var7, var13);
//     org.jfree.chart.event.TitleChangeEvent var16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var5);
//     java.awt.Font var17 = var5.getItemFont();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
//     java.awt.Font var20 = var19.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("ThreadContext");
//     var23.setToolTipText("ThreadContext");
//     org.jfree.chart.block.BlockFrame var26 = var23.getFrame();
//     java.awt.Paint var27 = var23.getBackgroundPaint();
//     var21.addSubtitle((org.jfree.chart.title.Title)var23);
//     org.jfree.chart.event.ChartProgressListener var29 = null;
//     var21.addProgressListener(var29);
//     org.jfree.chart.title.LegendTitle var31 = var21.getLegend();
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     double var34 = var33.getLabelLinkMargin();
//     var33.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
//     double var38 = var37.getContentXOffset();
//     java.awt.Paint var39 = var37.getItemPaint();
//     java.awt.Font var40 = var37.getItemFont();
//     org.jfree.chart.util.RectangleAnchor var41 = var37.getLegendItemGraphicAnchor();
//     java.lang.String var42 = var41.toString();
//     var31.setLegendItemGraphicLocation(var41);
//     var5.setLegendItemGraphicLocation(var41);
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    int var5 = var0.getDomainAxisCount();
    org.jfree.chart.event.RendererChangeEvent var6 = null;
    var0.rendererChanged(var6);
    org.jfree.chart.util.RectangleEdge var9 = var0.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var0.zoomDomainAxes(100.0d, var11, var12, false);
    int var15 = var0.getWeight();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var0.setFixedRangeAxisSpace(var16);
    org.jfree.chart.plot.PlotOrientation var18 = var0.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    java.awt.Image var4 = var3.getBackgroundImage();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    double var7 = var6.getLabelLinkMargin();
    var6.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    org.jfree.chart.event.TitleChangeListener var11 = null;
    var10.addChangeListener(var11);
    double var13 = var10.getContentYOffset();
    java.awt.Paint var14 = var10.getBackgroundPaint();
    var3.addLegend(var10);
    boolean var16 = var3.isNotify();
    org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("ThreadContext");
    java.awt.Paint var19 = var18.getPaint();
    var3.setBorderPaint(var19);
    var3.clearSubtitles();
    org.jfree.chart.event.ChartChangeListener var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.removeChangeListener(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Paint var7 = var5.getItemPaint();
//     java.awt.Font var8 = var5.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getHorizontalAlignment();
//     org.jfree.chart.text.TextBlock var10 = new org.jfree.chart.text.TextBlock();
//     java.util.List var11 = var10.getLines();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.text.TextBlockAnchor var15 = null;
//     var10.draw(var12, (-1.0f), 0.0f, var15, 1.0f, 100.0f, 0.05d);
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
//     double var22 = var21.getLabelLinkMargin();
//     var21.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
//     double var26 = var25.getContentXOffset();
//     java.awt.Paint var27 = var25.getItemPaint();
//     java.awt.Font var28 = var25.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var29 = var25.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 0.2d, 0.025d);
//     var10.setLineAlignment(var29);
//     var5.setHorizontalAlignment(var29);
//     
//     // Checks the contract:  equals-hashcode on var1 and var21
//     assertTrue("Contract failed: equals-hashcode on var1 and var21", var1.equals(var21) ? var1.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var1
//     assertTrue("Contract failed: equals-hashcode on var21 and var1", var21.equals(var1) ? var21.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(1, var2, false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    boolean var7 = var6.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var6.setURLGenerator(var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var6.addChangeListener(var10);
    java.awt.Shape var12 = var6.getLegendItemShape();
    java.awt.Stroke var13 = var6.getBaseSectionOutlineStroke();
    var0.setDomainGridlineStroke(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    double var23 = var22.getContentXOffset();
    java.awt.Paint var24 = var22.getItemPaint();
    java.awt.Font var25 = var22.getItemFont();
    var16.setLabelFont(var25);
    org.jfree.chart.util.Layer var27 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var27);
    double var29 = var0.getRangeCrosshairValue();
    var0.setWeight(100);
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.event.MarkerChangeEvent var35 = null;
    var34.notifyListeners(var35);
    org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var38 = var37.getNextFillPaint();
    var34.setPaint(var38);
    org.jfree.chart.util.Layer var40 = null;
    boolean var41 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var34, var40);
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var43 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var42};
    var0.setRenderers(var43);
    org.jfree.chart.plot.PlotRenderingInfo var47 = null;
    java.awt.geom.Point2D var48 = null;
    var0.zoomRangeAxes(0.05d, 100.0d, var47, var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxis((-16777216), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearAnnotations();
    org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge(1);
    org.jfree.chart.axis.CategoryAxis var4 = var0.getDomainAxis();
    java.util.List var5 = var0.getCategories();
    boolean var6 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var5 = null;
    var3.setRangeAxisLocation(1, var5, false);
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    boolean var10 = var9.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var11 = null;
    var9.setURLGenerator(var11);
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var9.addChangeListener(var13);
    java.awt.Shape var15 = var9.getLegendItemShape();
    java.awt.Stroke var16 = var9.getBaseSectionOutlineStroke();
    var3.setDomainGridlineStroke(var16);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
    double var22 = var21.getLabelLinkMargin();
    var21.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
    double var26 = var25.getContentXOffset();
    java.awt.Paint var27 = var25.getItemPaint();
    java.awt.Font var28 = var25.getItemFont();
    var19.setLabelFont(var28);
    org.jfree.chart.util.Layer var30 = null;
    var3.addRangeMarker((org.jfree.chart.plot.Marker)var19, var30);
    java.awt.Paint var32 = var19.getPaint();
    java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var37 = var36.getGreen();
    int var38 = var36.getRGB();
    int var39 = var36.getAlpha();
    float[] var40 = null;
    float[] var41 = var36.getRGBComponents(var40);
    var19.setOutlinePaint((java.awt.Paint)var36);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var19);
    org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D("");
    var46.setVisible(false);
    var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var46, true);
    org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D();
    double var52 = var51.getLowerMargin();
    org.jfree.data.xy.XYDataset var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.PolarItemRenderer var56 = null;
    org.jfree.chart.plot.PolarPlot var57 = new org.jfree.chart.plot.PolarPlot(var54, var55, var56);
    java.awt.Font var58 = var57.getAngleLabelFont();
    java.awt.Font var59 = var57.getAngleLabelFont();
    java.awt.Color var63 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var64 = var63.getGreen();
    int var65 = var63.getRGB();
    int var66 = var63.getAlpha();
    float[] var67 = null;
    float[] var68 = var63.getRGBComponents(var67);
    int var69 = var63.getAlpha();
    var57.setRadiusGridlinePaint((java.awt.Paint)var63);
    var51.setTickLabelPaint((java.lang.Comparable)(short)(-1), (java.awt.Paint)var63);
    java.util.List var72 = var0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var51);
    org.jfree.chart.util.Layer var74 = null;
    java.util.Collection var75 = var0.getRangeMarkers(100, var74);
    var0.clearRangeMarkers();
    org.jfree.chart.util.RectangleEdge var77 = var0.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 255, 10);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     double var6 = var5.getContentXOffset();
//     java.awt.Paint var7 = var5.getItemPaint();
//     java.awt.Font var8 = var5.getItemFont();
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 0.2d, 0.025d);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
//     double var16 = var15.getLabelLinkMargin();
//     var15.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     org.jfree.chart.event.TitleChangeListener var20 = null;
//     var19.addChangeListener(var20);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.util.Size2D var23 = var19.arrange(var22);
//     java.awt.Paint[] var24 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     var13.add((org.jfree.chart.block.Block)var19, (java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var1 and var15
//     assertTrue("Contract failed: equals-hashcode on var1 and var15", var1.equals(var15) ? var1.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var1
//     assertTrue("Contract failed: equals-hashcode on var15 and var1", var15.equals(var1) ? var15.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     var1.setInnerSeparatorExtension(0.025d);
//     double var8 = var1.getSectionDepth();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getLabelLinkMargin();
//     var11.setLabelGap((-1.0d));
//     float var15 = var11.getBackgroundAlpha();
//     java.awt.Paint var16 = var11.getLabelShadowPaint();
//     var1.setSectionOutlinePaint((java.lang.Comparable)(short)0, var16);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var19 = var18.getRangeGridlinePaint();
//     var18.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.event.RendererChangeEvent var22 = null;
//     var18.rendererChanged(var22);
//     boolean var24 = var18.isRangeCrosshairVisible();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     double var27 = var26.getLabelLinkMargin();
//     var26.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
//     double var31 = var30.getContentXOffset();
//     java.awt.Paint var32 = var30.getItemPaint();
//     java.awt.Font var33 = var30.getItemFont();
//     org.jfree.chart.util.RectangleInsets var34 = var30.getPadding();
//     double var36 = var34.extendWidth(1.0E-8d);
//     var18.setAxisOffset(var34);
//     var1.setSimpleLabelOffset(var34);
//     
//     // Checks the contract:  equals-hashcode on var11 and var26
//     assertTrue("Contract failed: equals-hashcode on var11 and var26", var11.equals(var26) ? var11.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var11
//     assertTrue("Contract failed: equals-hashcode on var26 and var11", var26.equals(var11) ? var26.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     org.jfree.data.general.PieDataset var1 = null;
//     java.text.AttributedString var3 = var0.generateAttributedSectionLabel(var1, (java.lang.Comparable)0);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var5.setToolTipText("ThreadContext");
    org.jfree.chart.block.BlockFrame var8 = var5.getFrame();
    java.awt.Paint var9 = var5.getBackgroundPaint();
    var3.addSubtitle((org.jfree.chart.title.Title)var5);
    java.awt.Paint var11 = var3.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("ThreadContext");
    var3.removeSubtitle((org.jfree.chart.title.Title)var13);
    var3.setBackgroundImageAlignment(0);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getLabelLinkMargin();
    var18.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    double var23 = var22.getContentXOffset();
    java.awt.Paint var24 = var22.getItemPaint();
    java.awt.Font var25 = var22.getItemFont();
    org.jfree.chart.util.HorizontalAlignment var26 = var22.getHorizontalAlignment();
    var3.addSubtitle((org.jfree.chart.title.Title)var22);
    var3.fireChartChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var29 = var3.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.Range var2 = var1.getRange();
    java.lang.Object var3 = var1.clone();
    java.awt.Shape var4 = var1.getLeftArrow();
    boolean var5 = var1.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getLabelLinkMargin();
    var1.setLabelGap((-1.0d));
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    var1.setInnerSeparatorExtension(0.025d);
    double var8 = var1.getSectionDepth();
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var13 = var12.getAlpha();
    java.awt.Color var14 = var12.brighter();
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getAlpha();
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
    org.jfree.chart.event.PlotChangeEvent var22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var21);
    java.awt.Stroke var23 = var21.getLabelOutlineStroke();
    java.awt.Paint var24 = var21.getSeparatorPaint();
    boolean var25 = var21.isCircular();
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var30 = var29.getGreen();
    var21.setSeparatorPaint((java.awt.Paint)var29);
    java.awt.color.ColorSpace var32 = var29.getColorSpace();
    java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var37 = var36.getGreen();
    int var38 = var36.getRGB();
    int var39 = var36.getAlpha();
    float[] var40 = null;
    float[] var41 = var36.getRGBComponents(var40);
    float[] var42 = var18.getColorComponents(var32, var41);
    java.awt.Color var46 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var47 = var46.getGreen();
    int var48 = var46.getRGB();
    int var49 = var46.getAlpha();
    float[] var50 = null;
    float[] var51 = var46.getRGBComponents(var50);
    float[] var52 = var12.getComponents(var32, var50);
    var1.setLabelLinkPaint((java.awt.Paint)var12);
    int var54 = var12.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = null;
    var3.setDataset(var4);
    java.awt.Paint var6 = var3.getRadiusGridlinePaint();
    var3.addCornerTextItem("");
    java.awt.Paint var9 = var3.getAngleLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.025, height=10.0]");

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getLabelLinkMargin();
//     var1.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = var5.arrange(var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getLabelLinkMargin();
//     var11.setLabelGap((-1.0d));
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var15.addChangeListener(var16);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.util.Size2D var19 = var15.arrange(var18);
//     org.jfree.chart.block.BlockContainer var20 = new org.jfree.chart.block.BlockContainer();
//     boolean var21 = var20.isEmpty();
//     var15.setWrapper(var20);
//     java.lang.Object var23 = var20.clone();
//     var20.setWidth(0.05d);
//     var5.setWrapper(var20);
//     
//     // Checks the contract:  equals-hashcode on var1 and var11
//     assertTrue("Contract failed: equals-hashcode on var1 and var11", var1.equals(var11) ? var1.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var1
//     assertTrue("Contract failed: equals-hashcode on var11 and var1", var11.equals(var1) ? var11.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var19
//     assertTrue("Contract failed: equals-hashcode on var9 and var19", var9.equals(var19) ? var9.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var9
//     assertTrue("Contract failed: equals-hashcode on var19 and var9", var19.equals(var9) ? var19.hashCode() == var9.hashCode() : true);
// 
//   }

}
