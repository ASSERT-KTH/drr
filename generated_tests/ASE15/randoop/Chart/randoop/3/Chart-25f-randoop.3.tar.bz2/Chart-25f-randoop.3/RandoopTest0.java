
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0d, 0.0f, 10.0f);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 100);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(-1.0f), var1, var2, var3, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", var1, var2);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 100.0d, var4, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     org.jfree.chart.plot.Plot var1 = null;
//     org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart("", var1);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem(var0, "", "", "hi!", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 1.0d, (-1.0d), 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 10.0f, 1.0f, var4, 100.0d, 0.0f, 100.0f);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.awt.Shape var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("", "", "hi!", "", var4, var5, (java.awt.Paint)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.Plot var2 = null;
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("hi!", var1, var2, true);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    float[] var6 = new float[] { 0.0f, 0.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var2.getComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(0.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("hi!");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)100L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    java.awt.Paint var7 = null;
    java.awt.Stroke var8 = null;
    java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "", var6, var7, var8, (java.awt.Paint)var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var7, "hi!", "");
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem(var0, "", "hi!", "", var7, (java.awt.Paint)var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.0d, 10.0d, 0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("hi!", var1, var2, var3);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.Stroke var3 = null;
    org.jfree.chart.util.RectangleInsets var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var5 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var2, var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var7, "hi!", "");
    java.awt.Stroke var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("hi!", 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem(var0, "", "", "", var7, var11, (java.awt.Paint)var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)(byte)10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    boolean var2 = var1.getNotify();
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemGraphicAnchor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var7, "hi!", "");
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "", var7, (java.awt.Paint)var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "", "hi!", "");

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemGraphicEdge(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, (-1.0f), 100.0f, 1.0d, 10.0f, (-1.0f));
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     boolean var2 = var1.getNotify();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.draw(var3, var4);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var7, "hi!", "");
    java.awt.Shape var11 = var10.getArea();
    java.awt.Stroke var12 = null;
    java.awt.Color var15 = java.awt.Color.getColor("hi!", 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("hi!", "", "", "hi!", var11, var12, (java.awt.Paint)var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.RectangleEdge var8 = null;
    double var9 = var5.lengthToJava2D((-1.0d), var7, var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var5.setLeftArrow(var12);
    java.awt.Stroke var14 = null;
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem(var0, "", "", "", var12, var14, (java.awt.Paint)var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, 10.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    org.jfree.data.Range var6 = var1.getDefaultAutoRange();
    org.jfree.chart.util.RectangleInsets var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setLabelToolTip("");
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.axis.AxisState var9 = var0.draw(var3, 100.0d, var5, var6, var7, var8);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getStdDevValue((-16777215), 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 10.0f, 1.0f, var4, 0.0d, (-1.0f), 10.0f);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var11);
    java.awt.Color var16 = java.awt.Color.getColor("hi!", 1);
    java.awt.Stroke var17 = null;
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var20.lengthToJava2D((-1.0d), var22, var23);
    java.awt.Shape var25 = var20.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var28 = new org.jfree.chart.entity.TickLabelEntity(var25, "", "");
    java.awt.Stroke var29 = null;
    java.awt.Color var32 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var32);
    int var34 = var32.getRGB();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", true, var7, true, (java.awt.Paint)var11, false, (java.awt.Paint)var16, var17, false, var25, var29, (java.awt.Paint)var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-16777215));

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var7, "hi!", "");
    java.awt.Shape var11 = var10.getArea();
    java.awt.Paint var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Color var16 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var16);
    int var18 = var16.getRGB();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("", "", "hi!", "", var11, var12, var13, (java.awt.Paint)var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-16777215));

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, Double.NaN);
//     
//     // Checks the contract:  var2.equals(var2)
//     assertTrue("Contract failed: var2.equals(var2)", var2.equals(var2));
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 10.0f, (-1.0f), 0.0d, 0.0f, 100.0f);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)1, "", var2, var3, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "");
//     var5.addOptionalLibrary("hi!");
//     java.lang.String var8 = var5.getCopyright();
//     org.jfree.chart.ui.Library var9 = null;
//     var5.addLibrary(var9);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("", var1);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    var1.setLabelToolTip("");
    java.awt.Paint var5 = var1.getTickLabelPaint((java.lang.Comparable)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var6 = new org.jfree.chart.block.BlockBorder(var0, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.Plot var2 = null;
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, var2, false);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 100.0f);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    boolean var2 = var1.getNotify();
    java.lang.Object var3 = var1.clone();
    org.jfree.chart.util.RectangleEdge var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPosition(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=, tooltip=hi!, url=", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setTickMarkInsideLength(100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize((-1.0d), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(Double.NaN, (-1.0d), 10.0d, Double.NaN);
//     java.awt.geom.Rectangle2D var5 = null;
//     var4.trim(var5);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.axis.TickUnit var1 = null;
//     var0.add(var1);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var1.setLeftArrow(var8);
    org.jfree.chart.axis.NumberTickUnit var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    org.jfree.chart.event.RendererChangeListener var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addChangeListener(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.Class var2 = null;
//     java.lang.ClassLoader var3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var2);
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("CategoryLabelEntity: category=, tooltip=hi!, url=", var1, var3);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var0.addChangeListener(var2);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var6 = var0.getColumnKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("CategoryLabelEntity: category=, tooltip=hi!, url=");

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    boolean var2 = var1.getNotify();
    org.jfree.chart.LegendItemSource var3 = null;
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
    boolean var5 = var4.getNotify();
    org.jfree.chart.block.BlockContainer var6 = var4.getItemContainer();
    var1.setWrapper(var6);
    org.jfree.chart.util.RectangleAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemGraphicAnchor(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    boolean var2 = var1.getNotify();
    org.jfree.chart.block.BlockContainer var3 = var1.getItemContainer();
    org.jfree.chart.util.RectangleEdge var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemGraphicEdge(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1, false);
    java.awt.Paint var5 = var0.getSeriesFillPaint(10);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var9, "hi!", "");
    java.awt.Shape var13 = var12.getArea();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var15.setLeftArrow(var22);
    var12.setArea(var22);
    java.awt.Shape var25 = var12.getArea();
    var0.setBaseShape(var25, true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendItemLabelGenerator(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    org.jfree.chart.util.RectangleEdge var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemGraphicEdge(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    var1.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
    org.jfree.chart.util.RectangleEdge var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPosition(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    org.jfree.chart.event.RendererChangeListener var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeChangeListener(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, (-1.0d), var4, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryLabelEntity: category=, tooltip=hi!, url=", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, (-1.0f));
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setLabelToolTip("");
    org.jfree.chart.axis.CategoryAnchor var3 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var0.getCategoryJava2DCoordinate(var3, 0, 0, var6, var7);
    java.awt.Font var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelFont(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryLabelEntity var4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)1L, var1, "", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1, false);
//     java.awt.Paint var5 = var0.getSeriesFillPaint(10);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setLabelToolTip("");
//     var8.setUpperMargin((-1.0d));
//     org.jfree.chart.plot.Plot var13 = null;
//     var8.setPlot(var13);
//     java.lang.String var16 = var8.getCategoryLabelToolTip((java.lang.Comparable)'#');
//     java.lang.Object var17 = var8.clone();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     boolean var20 = var19.getAutoRangeStickyZero();
//     org.jfree.chart.util.Layer var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     var0.drawAnnotations(var6, var7, var8, (org.jfree.chart.axis.ValueAxis)var19, var21, var22);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var1.setLeftArrow(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize((-1.0d), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    var1.setAutoRange(false);
    org.jfree.chart.axis.NumberTickUnit var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.RectangleEdge var8 = null;
    double var9 = var5.lengthToJava2D((-1.0d), var7, var8);
    java.awt.Shape var10 = var5.getLeftArrow();
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var14 = var13.brighter();
    boolean var16 = var13.equals((java.lang.Object)(short)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem(var0, "", "", "", var10, (java.awt.Paint)var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.ui.BasicProjectInfo var2 = new org.jfree.chart.ui.BasicProjectInfo();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var1, (java.lang.Object)var2);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getItemLabelPadding();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var1.draw(var4, var5);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(short)(-1), "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", var2, var3, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     var1.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
//     org.jfree.chart.event.TitleChangeListener var7 = null;
//     var1.removeChangeListener(var7);
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var11);
//     var1.setItemPaint((java.awt.Paint)var11);
//     java.awt.color.ColorSpace var14 = null;
//     java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
//     float[] var21 = new float[] { 10.0f, 0.0f, 1.0f};
//     float[] var22 = var17.getColorComponents(var21);
//     float[] var23 = var11.getComponents(var14, var22);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getUpperClip();
//     java.lang.Boolean var3 = null;
//     var0.setSeriesItemLabelsVisible(100, var3, true);
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var8.lengthToJava2D((-1.0d), var10, var11);
//     var8.setAutoRange(false);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var16 = var15.getUpperClip();
//     java.awt.Stroke var17 = var15.getBaseStroke();
//     var8.setTickMarkStroke(var17);
//     var0.setSeriesOutlineStroke(10, var17, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var0.", var15.equals(var0) == var0.equals(var15));
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.RectangleEdge var8 = null;
    double var9 = var5.lengthToJava2D((-1.0d), var7, var8);
    java.awt.Shape var10 = var5.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var13 = new org.jfree.chart.entity.TickLabelEntity(var10, "", "");
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, (-1.0d), 10.0f, 0.0f);
    java.awt.Paint var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem(var0, "", "", "CategoryLabelEntity: category=, tooltip=hi!, url=", var10, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 0.0f, 10.0f, var4, 0.0d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("CategoryLabelEntity: category=, tooltip=hi!, url=");

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "");
    java.lang.String var6 = var5.getCopyright();
    org.jfree.chart.ui.Library[] var7 = var5.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "hi!"+ "'", var6.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getColumnKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var3 = var2.getStroke();
//     org.jfree.chart.util.RectangleAnchor var4 = var2.getLabelAnchor();
//     java.awt.geom.Point2D var5 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var4);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getInsets();
    double var6 = var4.trimWidth(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.0d);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var1 = null;
//     boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var1);
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     var3.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var9 = var3.getPadding();
//     org.jfree.chart.block.Arrangement var10 = var3.getArrangement();
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, (-1.0d), 10.0d);
//     org.jfree.chart.block.Block var16 = null;
//     java.lang.Object var17 = null;
//     var15.add(var16, var17);
//     org.jfree.chart.ui.BasicProjectInfo var24 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "");
//     var24.addOptionalLibrary("hi!");
//     boolean var27 = var15.equals((java.lang.Object)var24);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var34 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var31, "hi!", "");
//     org.jfree.chart.block.CenterArrangement var35 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var36 = null;
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, var36);
//     org.jfree.chart.block.BlockContainer var38 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var35);
//     boolean var39 = var34.equals((java.lang.Object)var38);
//     var38.setWidth(10.0d);
//     var15.add((org.jfree.chart.block.Block)var38, (java.lang.Object)true);
//     var3.setArrangement((org.jfree.chart.block.Arrangement)var15);
//     
//     // Checks the contract:  equals-hashcode on var0 and var35
//     assertTrue("Contract failed: equals-hashcode on var0 and var35", var0.equals(var35) ? var0.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var0
//     assertTrue("Contract failed: equals-hashcode on var35 and var0", var35.equals(var0) ? var35.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
//     java.awt.Shape var7 = var6.getArea();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var9.lengthToJava2D((-1.0d), var11, var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var9.setLeftArrow(var16);
//     var6.setArea(var16);
//     java.awt.Shape var19 = var6.getArea();
//     java.lang.String var20 = var6.getShapeCoords();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var21 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var22 = null;
//     java.lang.String var23 = var6.getImageMapAreaTag(var21, var22);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    java.awt.Stroke var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-16777215), var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     boolean var2 = var1.getNotify();
//     java.lang.Object var3 = var1.clone();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.lang.Object var6 = null;
//     java.lang.Object var7 = var1.draw(var4, var5, var6);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    org.jfree.chart.labels.CategoryToolTipGenerator var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-1), var30, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
    java.awt.geom.Rectangle2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var2.createOutsetRectangle(var3, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getUpperClip();
//     java.awt.Stroke var2 = var0.getBaseStroke();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var4);
//     org.jfree.chart.entity.EntityCollection var6 = var5.getEntityCollection();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setLabelToolTip("");
//     var9.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var14 = null;
//     var9.removeChangeListener(var14);
//     var9.removeCategoryLabelToolTip((java.lang.Comparable)255);
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var19.lengthToJava2D((-1.0d), var21, var22);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var19.setLeftArrow(var26);
//     var19.setRangeWithMargins(Double.NaN, 0.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var33 = var31.getRangeLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.drawItem(var3, var5, var7, var8, var9, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.data.category.CategoryDataset)var31, 10, (-16777215), 100);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == Double.NaN);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
    double var4 = var2.extendHeight(10.0d);
    java.awt.geom.Rectangle2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var2.createOutsetRectangle(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 16.0d);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
//     java.awt.Shape var7 = var6.getArea();
//     java.lang.Object var8 = var6.clone();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var9 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var10 = null;
//     java.lang.String var11 = var6.getImageMapAreaTag(var9, var10);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    boolean var2 = var1.getNotify();
    double var3 = var1.getWidth();
    java.awt.Paint var4 = var1.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("NOID", var1);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    org.jfree.chart.util.RectangleInsets var3 = var1.getItemLabelPadding();
    java.lang.Object var4 = var1.clone();
    org.jfree.chart.util.RectangleAnchor var5 = var1.getLegendItemGraphicAnchor();
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    org.jfree.chart.text.TextAnchor var7 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var11 = new org.jfree.chart.axis.CategoryLabelPosition(var5, var6, var7, 0.0d, var9, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 100.0d, 100.0f, 0.0f);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var7 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var4, "hi!", "");
    java.awt.Shape var8 = var7.getArea();
    boolean var9 = var0.equals((java.lang.Object)var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
    java.awt.Shape var7 = var6.getArea();
    var6.setToolTipText("hi!");
    java.lang.String var10 = var6.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "poly"+ "'", var10.equals("poly"));

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = null;
//     var1.setBaseURLGenerator(var2, false);
//     java.awt.Paint var6 = var1.getSeriesFillPaint(10);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var10, "hi!", "");
//     java.awt.Shape var14 = var13.getArea();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var16.lengthToJava2D((-1.0d), var18, var19);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var16.setLeftArrow(var23);
//     var13.setArea(var23);
//     java.awt.Shape var26 = var13.getArea();
//     var1.setBaseShape(var26, true);
//     java.awt.Font var31 = var1.getItemLabelFont(100, 10);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("hi!", var31);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.text.TextAnchor var36 = null;
//     var32.draw(var33, 1.0f, 10.0f, var36, 0.0f, 10.0f, 3.0d);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTextAlignment(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     var1.draw(var2, var3);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), 10.0d);
    org.jfree.chart.block.Block var5 = null;
    java.lang.Object var6 = null;
    var4.add(var5, var6);
    org.jfree.chart.ui.BasicProjectInfo var13 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "");
    var13.addOptionalLibrary("hi!");
    boolean var16 = var4.equals((java.lang.Object)var13);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var23 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var20, "hi!", "");
    org.jfree.chart.block.CenterArrangement var24 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var25 = null;
    boolean var26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var24, var25);
    org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var24);
    boolean var28 = var23.equals((java.lang.Object)var27);
    var27.setWidth(10.0d);
    var4.add((org.jfree.chart.block.Block)var27, (java.lang.Object)true);
    java.awt.Graphics2D var33 = null;
    org.jfree.data.Range var35 = null;
    org.jfree.chart.block.RectangleConstraint var36 = new org.jfree.chart.block.RectangleConstraint(0.0d, var35);
    org.jfree.chart.block.RectangleConstraint var38 = var36.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var40 = var38.toFixedHeight((-1.0d));
    org.jfree.chart.block.RectangleConstraint var42 = var40.toFixedHeight(Double.NaN);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var43 = var27.arrange(var33, var40);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.lang.Boolean var3 = null;
    var0.setSeriesItemLabelsVisible(100, var3, true);
    org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
    var0.setBasePaint((java.awt.Paint)var10, false);
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
    org.jfree.chart.block.CenterArrangement var7 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var8 = null;
    boolean var9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, var8);
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var7);
    boolean var11 = var6.equals((java.lang.Object)var10);
    org.jfree.chart.block.Arrangement var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setArrangement(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setLabelToolTip("");
//     var0.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var5 = null;
//     var0.removeChangeListener(var5);
//     org.jfree.chart.axis.CategoryLabelPositions var7 = var0.getCategoryLabelPositions();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.AxisState var9 = new org.jfree.chart.axis.AxisState();
//     var9.setCursor(0.0d);
//     java.util.List var12 = var9.getTicks();
//     var9.setCursor(Double.NaN);
//     double var15 = var9.getCursor();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.LegendItemSource var17 = null;
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var17);
//     boolean var19 = var18.getNotify();
//     double var20 = var18.getWidth();
//     org.jfree.chart.util.RectangleEdge var21 = var18.getLegendItemGraphicEdge();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var22.getCategoryStart(10, (-16777215), var25, var26);
//     java.awt.Font var29 = null;
//     var22.setTickLabelFont((java.lang.Comparable)1, var29);
//     java.lang.String var31 = var22.getLabel();
//     org.jfree.chart.axis.CategoryAnchor var32 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.LegendItemSource var36 = null;
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle(var36);
//     boolean var38 = var37.getNotify();
//     double var39 = var37.getWidth();
//     org.jfree.chart.util.RectangleEdge var40 = var37.getLegendItemGraphicEdge();
//     double var41 = var22.getCategoryJava2DCoordinate(var32, (-1), (-16777215), var35, var40);
//     var18.setLegendItemGraphicEdge(var40);
//     java.util.List var43 = var0.refreshTicks(var8, var9, var16, var40);
// 
//   }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var1 = null;
//     boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var1);
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var7 = null;
//     var6.setBaseURLGenerator(var7, false);
//     java.awt.Paint var11 = var6.getSeriesFillPaint(10);
//     boolean var14 = var6.isItemLabelVisible(0, (-16777215));
//     double var15 = var6.getBase();
//     java.lang.Object var16 = var3.draw(var4, var5, (java.lang.Object)var6);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var1 = null;
    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var1);
    org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    var3.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var9 = var3.getPadding();
    org.jfree.chart.util.RectangleInsets var10 = var3.getMargin();
    java.awt.Graphics2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var12 = var3.arrange(var11);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    java.awt.Color var1 = java.awt.Color.getColor("NOID");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", var1);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
    int var4 = var2.getRGB();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    float[] var11 = new float[] { 10.0f, 0.0f, 1.0f};
    float[] var12 = var7.getColorComponents(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var13 = var2.getComponents(var11);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-16777215));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getUpperClip();
//     java.awt.Stroke var2 = var0.getBaseStroke();
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var5 = var4.getUpperClip();
//     java.lang.Boolean var7 = null;
//     var4.setSeriesItemLabelsVisible(100, var7, true);
//     org.jfree.chart.util.GradientPaintTransformer var10 = var4.getGradientPaintTransformer();
//     java.awt.Paint var11 = var4.getBaseFillPaint();
//     var0.setSeriesItemLabelPaint(0, var11, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var0.", var4.equals(var0) == var0.equals(var4));
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var1 = null;
//     boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var1);
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     var3.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var9 = var3.getPadding();
//     org.jfree.chart.block.Arrangement var10 = var3.getArrangement();
//     org.jfree.chart.util.RectangleInsets var11 = var3.getPadding();
//     org.jfree.chart.block.CenterArrangement var12 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var13 = null;
//     boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var12, var13);
//     org.jfree.chart.block.BlockContainer var15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var12);
//     var15.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.LegendItemSource var21 = null;
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
//     var22.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
//     java.lang.Object var28 = null;
//     var15.add((org.jfree.chart.block.Block)var22, var28);
//     var3.add((org.jfree.chart.block.Block)var15);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
    java.awt.Shape var7 = var2.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var8 = var2.getMarkerBand();
    org.jfree.data.Range var9 = var2.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var11.lengthToJava2D((-1.0d), var13, var14);
    java.awt.Shape var16 = var11.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var17 = var11.getMarkerBand();
    org.jfree.data.Range var18 = var11.getDefaultAutoRange();
    var2.setDefaultAutoRange(var18);
    org.jfree.chart.block.LengthConstraintType var20 = null;
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var23 = null;
    var22.setBaseToolTipGenerator(var23);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var28.lengthToJava2D((-1.0d), var30, var31);
    java.awt.Shape var33 = var28.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var34 = var28.getMarkerBand();
    org.jfree.data.Range var35 = var28.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.util.RectangleEdge var40 = null;
    double var41 = var37.lengthToJava2D((-1.0d), var39, var40);
    java.awt.Shape var42 = var37.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var43 = var37.getMarkerBand();
    org.jfree.data.Range var44 = var37.getDefaultAutoRange();
    var28.setDefaultAutoRange(var44);
    org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var48 = var47.getStroke();
    java.awt.geom.Rectangle2D var49 = null;
    var22.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.plot.Marker)var47, var49);
    boolean var51 = var28.isAxisLineVisible();
    org.jfree.data.RangeType var52 = var28.getRangeType();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var58 = null;
    org.jfree.chart.util.RectangleEdge var59 = null;
    double var60 = var56.lengthToJava2D((-1.0d), var58, var59);
    org.jfree.data.Range var61 = var56.getDefaultAutoRange();
    org.jfree.data.Range var63 = null;
    org.jfree.chart.block.RectangleConstraint var64 = new org.jfree.chart.block.RectangleConstraint(0.0d, var63);
    org.jfree.chart.block.RectangleConstraint var66 = var64.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var68 = var66.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var72 = null;
    org.jfree.chart.util.RectangleEdge var73 = null;
    double var74 = var70.lengthToJava2D((-1.0d), var72, var73);
    org.jfree.data.Range var75 = var70.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var76 = var68.toRangeWidth(var75);
    org.jfree.data.Range var77 = org.jfree.data.Range.combine(var61, var75);
    var54.setRange(var61);
    var28.setRange(var61);
    double var80 = var61.getLowerBound();
    double var81 = var61.getCentralValue();
    org.jfree.chart.block.LengthConstraintType var82 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var83 = new org.jfree.chart.block.RectangleConstraint(0.5d, var18, var20, 1.0d, var61, var82);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.5d);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
//     java.awt.Shape var7 = var6.getArea();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var9.lengthToJava2D((-1.0d), var11, var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var9.setLeftArrow(var16);
//     var6.setArea(var16);
//     var6.setToolTipText("CategoryLabelEntity: category=, tooltip=hi!, url=");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var21 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var22 = null;
//     java.lang.String var23 = var6.getImageMapAreaTag(var21, var22);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getUpperClip();
//     java.lang.Boolean var3 = null;
//     var0.setSeriesItemLabelsVisible(100, var3, true);
//     org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
//     org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
//     var0.setBasePaint((java.awt.Paint)var10, false);
//     int var13 = var0.getColumnCount();
//     java.awt.Paint var14 = var0.getBaseItemLabelPaint();
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     var17.setLabelToolTip("");
//     var17.setUpperMargin((-1.0d));
//     org.jfree.chart.plot.Plot var22 = null;
//     var17.setPlot(var22);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var25.setLeftArrow(var32);
//     var25.setRangeWithMargins(Double.NaN, 0.0d);
//     var25.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var40 = null;
//     var39.setBaseURLGenerator(var40, false);
//     java.awt.Paint var44 = var39.getSeriesFillPaint(10);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var51 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var48, "hi!", "");
//     java.awt.Shape var52 = var51.getArea();
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var56 = null;
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     double var58 = var54.lengthToJava2D((-1.0d), var56, var57);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var54.setLeftArrow(var61);
//     var51.setArea(var61);
//     java.awt.Shape var64 = var51.getArea();
//     var39.setBaseShape(var64, true);
//     java.awt.Font var69 = var39.getItemLabelFont(100, 10);
//     var25.setLabelFont(var69);
//     org.jfree.chart.util.Layer var71 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     var0.drawAnnotations(var15, var16, var17, (org.jfree.chart.axis.ValueAxis)var25, var71, var72);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
//     org.jfree.chart.block.BlockContainer var3 = var2.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var4 = var2.getItemLabelPadding();
//     java.lang.Object var5 = var2.clone();
//     org.jfree.chart.util.RectangleEdge var6 = var2.getPosition();
//     double var7 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var6);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("poly");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", var1, var2);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var7 = var1.getMarkerBand();
    var1.setAutoRangeMinimumSize(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1, false);
//     java.awt.Paint var5 = var0.getSeriesFillPaint(10);
//     boolean var8 = var0.isItemLabelVisible(0, (-16777215));
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
//     var11.setLabelToolTip("");
//     java.awt.Paint var15 = var11.getTickLabelPaint((java.lang.Comparable)(-1));
//     org.jfree.chart.plot.CategoryMarker var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     var0.drawDomainMarker(var9, var10, var11, var16, var17);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var0.getCategoryStart(10, (-16777215), var3, var4);
//     java.awt.Font var7 = null;
//     var0.setTickLabelFont((java.lang.Comparable)1, var7);
//     java.lang.String var9 = var0.getLabel();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     var13.setLabelToolTip("");
//     var13.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var18 = null;
//     var13.removeChangeListener(var18);
//     org.jfree.chart.axis.CategoryLabelPositions var20 = var13.getCategoryLabelPositions();
//     org.jfree.chart.LegendItemSource var21 = null;
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
//     boolean var23 = var22.getNotify();
//     double var24 = var22.getWidth();
//     org.jfree.chart.util.RectangleEdge var25 = var22.getLegendItemGraphicEdge();
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var26.getCategoryStart(10, (-16777215), var29, var30);
//     java.awt.Font var33 = null;
//     var26.setTickLabelFont((java.lang.Comparable)1, var33);
//     java.lang.String var35 = var26.getLabel();
//     org.jfree.chart.axis.CategoryAnchor var36 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.LegendItemSource var40 = null;
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle(var40);
//     boolean var42 = var41.getNotify();
//     double var43 = var41.getWidth();
//     org.jfree.chart.util.RectangleEdge var44 = var41.getLegendItemGraphicEdge();
//     double var45 = var26.getCategoryJava2DCoordinate(var36, (-1), (-16777215), var39, var44);
//     var22.setLegendItemGraphicEdge(var44);
//     org.jfree.chart.axis.CategoryLabelPosition var47 = var20.getLabelPosition(var44);
//     double var48 = var0.getCategoryStart(1, (-1), var12, var44);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var2 = var0.getRangeLowerBound(false);
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Comparable var6 = var0.getRowKey(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     var1.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
//     org.jfree.chart.event.TitleChangeListener var7 = null;
//     var1.removeChangeListener(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var13 = var11.getRangeLowerBound(false);
//     org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var11, false);
//     org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var11);
//     java.util.EventListener var17 = null;
//     boolean var18 = var11.hasListener(var17);
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var11);
//     java.lang.Object var20 = var1.draw(var9, var10, (java.lang.Object)var11);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    float[] var6 = new float[] { 10.0f, 0.0f, 1.0f};
    float[] var7 = var2.getColorComponents(var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    var9.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
    org.jfree.chart.event.TitleChangeListener var15 = null;
    var9.removeChangeListener(var15);
    java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var19);
    var9.setItemPaint((java.awt.Paint)var19);
    java.awt.color.ColorSpace var22 = var19.getColorSpace();
    java.awt.Color var25 = java.awt.Color.getColor("hi!", 1);
    float[] var29 = new float[] { 10.0f, 0.0f, 1.0f};
    float[] var30 = var25.getColorComponents(var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var31 = var2.getComponents(var22, var29);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    var1.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
    org.jfree.chart.util.RectangleAnchor var7 = null;
    var1.setLegendItemGraphicLocation(var7);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1);
//     org.jfree.chart.util.Size2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 8.0d, "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", var3, var4, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtLeft();
    java.util.List var2 = var0.getAxesAtLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    boolean var29 = var6.isAxisLineVisible();
    org.jfree.data.RangeType var30 = var6.getRangeType();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    double var38 = var34.lengthToJava2D((-1.0d), var36, var37);
    org.jfree.data.Range var39 = var34.getDefaultAutoRange();
    org.jfree.data.Range var41 = null;
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(0.0d, var41);
    org.jfree.chart.block.RectangleConstraint var44 = var42.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var46 = var44.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var50 = null;
    org.jfree.chart.util.RectangleEdge var51 = null;
    double var52 = var48.lengthToJava2D((-1.0d), var50, var51);
    org.jfree.data.Range var53 = var48.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var54 = var46.toRangeWidth(var53);
    org.jfree.data.Range var55 = org.jfree.data.Range.combine(var39, var53);
    var32.setRange(var39);
    var6.setRange(var39);
    org.jfree.data.Range var60 = org.jfree.data.Range.expand(var39, 8.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("poly", var1, var2);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setLabelToolTip("");
//     var0.setUpperMargin((-1.0d));
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.RectangleInsets var7 = var6.getLabelOffset();
//     var0.setTickLabelInsets(var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.LegendItemSource var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
//     org.jfree.chart.block.BlockContainer var14 = var13.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var15 = var13.getItemLabelPadding();
//     java.lang.Object var16 = var13.clone();
//     org.jfree.chart.util.RectangleEdge var17 = var13.getPosition();
//     org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var19 = null;
//     var18.setBaseURLGenerator(var19, false);
//     java.awt.Paint var23 = var18.getSeriesItemLabelPaint(0);
//     boolean var24 = var17.equals((java.lang.Object)0);
//     double var25 = var0.getCategoryMiddle(10, 100, var11, var17);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var1);
    org.jfree.chart.event.ChartChangeEventType var3 = null;
    var2.setType(var3);
    org.jfree.chart.event.ChartChangeEventType var5 = null;
    var2.setType(var5);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.ChartColor var7 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var8 = var7.getAlpha();
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var9.setBaseToolTipGenerator(var10);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var24.lengthToJava2D((-1.0d), var26, var27);
    java.awt.Shape var29 = var24.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var30 = var24.getMarkerBand();
    org.jfree.data.Range var31 = var24.getDefaultAutoRange();
    var15.setDefaultAutoRange(var31);
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var35 = var34.getStroke();
    java.awt.geom.Rectangle2D var36 = null;
    var9.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.plot.Marker)var34, var36);
    java.awt.Stroke var38 = var9.getBaseStroke();
    org.jfree.chart.block.CenterArrangement var39 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var40 = null;
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var39, var40);
    org.jfree.chart.block.BlockContainer var42 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var39);
    var42.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var48 = var42.getPadding();
    org.jfree.chart.block.Arrangement var49 = var42.getArrangement();
    org.jfree.chart.util.RectangleInsets var50 = var42.getPadding();
    org.jfree.chart.block.LineBorder var51 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var7, var38, var50);
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.util.RectangleEdge var56 = null;
    double var57 = var53.lengthToJava2D((-1.0d), var55, var56);
    java.awt.Shape var58 = var53.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var59 = var53.getMarkerBand();
    var53.setRange(0.0d, 1.0d);
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var69 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var66, "hi!", "");
    java.awt.Shape var70 = var69.getArea();
    var53.setDownArrow(var70);
    boolean var72 = var50.equals((java.lang.Object)var70);
    org.jfree.chart.util.ObjectList var73 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.plot.ValueMarker var75 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var76 = var75.getStroke();
    java.awt.Paint var77 = var75.getLabelPaint();
    int var78 = var73.indexOf((java.lang.Object)var77);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var79 = new org.jfree.chart.LegendItem(var0, "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", var70, var77);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == (-1));

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var4 = var3.getAlpha();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var5.setBaseToolTipGenerator(var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var11.lengthToJava2D((-1.0d), var13, var14);
    java.awt.Shape var16 = var11.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var17 = var11.getMarkerBand();
    org.jfree.data.Range var18 = var11.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var20.lengthToJava2D((-1.0d), var22, var23);
    java.awt.Shape var25 = var20.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var26 = var20.getMarkerBand();
    org.jfree.data.Range var27 = var20.getDefaultAutoRange();
    var11.setDefaultAutoRange(var27);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var31 = var30.getStroke();
    java.awt.geom.Rectangle2D var32 = null;
    var5.drawRangeMarker(var8, var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.plot.Marker)var30, var32);
    java.awt.Stroke var34 = var5.getBaseStroke();
    org.jfree.chart.block.CenterArrangement var35 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var36 = null;
    boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, var36);
    org.jfree.chart.block.BlockContainer var38 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var35);
    var38.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var44 = var38.getPadding();
    org.jfree.chart.block.Arrangement var45 = var38.getArrangement();
    org.jfree.chart.util.RectangleInsets var46 = var38.getPadding();
    org.jfree.chart.block.LineBorder var47 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var34, var46);
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var51 = null;
    org.jfree.chart.util.RectangleEdge var52 = null;
    double var53 = var49.lengthToJava2D((-1.0d), var51, var52);
    java.awt.Shape var54 = var49.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var55 = var49.getMarkerBand();
    var49.setRange(0.0d, 1.0d);
    java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var65 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var62, "hi!", "");
    java.awt.Shape var66 = var65.getArea();
    var49.setDownArrow(var66);
    boolean var68 = var46.equals((java.lang.Object)var66);
    double var70 = var46.calculateRightOutset(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var2 = var1.getStroke();
//     java.awt.Paint var3 = var1.getLabelPaint();
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var6 = var5.getStroke();
//     var1.setOutlineStroke(var6);
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var2 = var1.getStroke();
//     java.awt.Stroke var3 = var1.getOutlineStroke();
//     java.lang.Class var4 = null;
//     java.util.EventListener[] var5 = var1.getListeners(var4);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    org.jfree.chart.plot.Plot var29 = null;
    var6.setPlot(var29);
    var6.setTickLabelsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    var1.setURLText("CategoryLabelEntity: category=, tooltip=hi!, url=");
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var6.setBaseURLGenerator(var7, false);
    java.awt.Paint var11 = var6.getSeriesFillPaint(10);
    boolean var14 = var6.isItemLabelVisible(0, (-16777215));
    java.lang.Object var15 = var1.draw(var4, var5, (java.lang.Object)0);
    var1.setToolTipText("");
    java.awt.geom.Rectangle2D var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBounds(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    org.jfree.chart.util.RectangleInsets var3 = var1.getItemLabelPadding();
    java.lang.Object var4 = var1.clone();
    org.jfree.chart.util.RectangleAnchor var5 = var1.getLegendItemGraphicAnchor();
    org.jfree.chart.util.BooleanList var6 = new org.jfree.chart.util.BooleanList();
    boolean var7 = var5.equals((java.lang.Object)var6);
    org.jfree.chart.text.TextBlockAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var9 = new org.jfree.chart.axis.CategoryLabelPosition(var5, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Enumeration var2 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var0.getString("CategoryLabelEntity: category=, tooltip=hi!, url=");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var4 = var3.getAlpha();
    java.awt.Paint[] var5 = new java.awt.Paint[] { var3};
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var7.lengthToJava2D((-1.0d), var9, var10);
    java.awt.Shape var12 = var7.getLeftArrow();
    var7.setAutoRangeMinimumSize(100.0d);
    var7.configure();
    var7.setVisible(true);
    var7.setInverted(true);
    java.awt.Paint var20 = var7.getLabelPaint();
    java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
    org.jfree.chart.ChartColor var25 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var26 = var25.getAlpha();
    java.awt.Paint[] var27 = new java.awt.Paint[] { var25};
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var30 = var28.lookupSeriesStroke(255);
    java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
    org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var34 = var32.lookupSeriesStroke(255);
    java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.util.RectangleEdge var40 = null;
    double var41 = var37.lengthToJava2D((-1.0d), var39, var40);
    java.awt.Shape var42 = var37.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var43 = var37.getMarkerBand();
    var37.setRange(0.0d, 1.0d);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var53 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var50, "hi!", "");
    java.awt.Shape var54 = var53.getArea();
    var37.setDownArrow(var54);
    java.awt.Shape[] var56 = new java.awt.Shape[] { var54};
    org.jfree.chart.plot.DefaultDrawingSupplier var57 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var21, var27, var31, var35, var56);
    boolean var59 = var57.equals((java.lang.Object)"NOID");
    java.lang.Object var60 = var57.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    var1.setURLText("CategoryLabelEntity: category=, tooltip=hi!, url=");
    java.awt.Font var4 = var1.getFont();
    java.awt.Graphics2D var5 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(0.0d, var7);
    org.jfree.chart.block.RectangleConstraint var10 = var8.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var12 = var10.toFixedHeight((-1.0d));
    org.jfree.chart.block.RectangleConstraint var14 = var12.toFixedHeight(Double.NaN);
    org.jfree.chart.block.RectangleConstraint var15 = var12.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var16 = var1.arrange(var5, var12);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + ""+ "'", var0.equals(""));

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseSeriesVisible();
    boolean var3 = var0.getAutoPopulateSeriesShape();
    var0.setBaseSeriesVisible(true, true);
    boolean var8 = var0.isSeriesItemLabelsVisible(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     var0.clearRangeMarkers(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var6 = var5.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     var5.zoomDomainAxes(2.0d, 16.0d, var9, var10);
//     java.lang.Object var12 = var5.clone();
//     org.jfree.chart.axis.AxisLocation var13 = var5.getDomainAxisLocation();
//     var0.setRangeAxisLocation(255, var13);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var0.", var5.equals(var0) == var0.equals(var5));
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.get((-16777215));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 100.0f, 10.0f, var4, 16.0d, 1.0f, 100.0f);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Enumeration var2 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var0.getString("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelTextAnchor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var2 = var0.getRangeLowerBound(false);
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var3.getCategoryStart(10, (-16777215), var6, var7);
//     java.awt.Font var10 = null;
//     var3.setTickLabelFont((java.lang.Comparable)1, var10);
//     java.lang.String var12 = var3.getLabel();
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
//     var13.setBaseToolTipGenerator(var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = null;
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var19.lengthToJava2D((-1.0d), var21, var22);
//     java.awt.Shape var24 = var19.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var25 = var19.getMarkerBand();
//     org.jfree.data.Range var26 = var19.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var28.lengthToJava2D((-1.0d), var30, var31);
//     java.awt.Shape var33 = var28.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var34 = var28.getMarkerBand();
//     org.jfree.data.Range var35 = var28.getDefaultAutoRange();
//     var19.setDefaultAutoRange(var35);
//     org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var39 = var38.getStroke();
//     java.awt.geom.Rectangle2D var40 = null;
//     var13.drawRangeMarker(var16, var17, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.plot.Marker)var38, var40);
//     boolean var42 = var19.isAxisLineVisible();
//     org.jfree.data.RangeType var43 = var19.getRangeType();
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var47.lengthToJava2D((-1.0d), var49, var50);
//     org.jfree.data.Range var52 = var47.getDefaultAutoRange();
//     org.jfree.data.Range var54 = null;
//     org.jfree.chart.block.RectangleConstraint var55 = new org.jfree.chart.block.RectangleConstraint(0.0d, var54);
//     org.jfree.chart.block.RectangleConstraint var57 = var55.toFixedHeight(0.0d);
//     org.jfree.chart.block.RectangleConstraint var59 = var57.toFixedHeight((-1.0d));
//     org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var61.lengthToJava2D((-1.0d), var63, var64);
//     org.jfree.data.Range var66 = var61.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var67 = var59.toRangeWidth(var66);
//     org.jfree.data.Range var68 = org.jfree.data.Range.combine(var52, var66);
//     var45.setRange(var52);
//     var19.setRange(var52);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var71 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Object var72 = var71.clone();
//     org.jfree.data.general.DatasetChangeListener var73 = null;
//     var71.addChangeListener(var73);
//     org.jfree.data.Range var75 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var71);
//     org.jfree.data.general.DatasetChangeEvent var76 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var19, (org.jfree.data.general.Dataset)var71);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var77 = null;
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, (org.jfree.chart.axis.ValueAxis)var19, var77);
//     
//     // Checks the contract:  equals-hashcode on var0 and var71
//     assertTrue("Contract failed: equals-hashcode on var0 and var71", var0.equals(var71) ? var0.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var0
//     assertTrue("Contract failed: equals-hashcode on var71 and var0", var71.equals(var0) ? var71.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var1);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    double var2 = var0.getRangeCrosshairValue();
    java.awt.Stroke var3 = var0.getRangeGridlineStroke();
    org.jfree.chart.annotations.CategoryAnnotation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var5 = var0.removeAnnotation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var0.getPositiveItemLabelPosition((-16777215), 1);
//     java.lang.Boolean var6 = var0.getSeriesVisibleInLegend(4);
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var8 = var7.getUpperClip();
//     var7.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var11 = var7.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var14 = var7.getPositiveItemLabelPosition(10, 100);
//     var0.setBasePositiveItemLabelPosition(var14);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), 10.0d);
//     var4.clear();
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, (-1.0d), 10.0d);
//     org.jfree.chart.block.Block var11 = null;
//     java.lang.Object var12 = null;
//     var10.add(var11, var12);
//     org.jfree.chart.ui.BasicProjectInfo var19 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "");
//     var19.addOptionalLibrary("hi!");
//     boolean var22 = var10.equals((java.lang.Object)var19);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var26, "hi!", "");
//     org.jfree.chart.block.CenterArrangement var30 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var31 = null;
//     boolean var32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var30, var31);
//     org.jfree.chart.block.BlockContainer var33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var30);
//     boolean var34 = var29.equals((java.lang.Object)var33);
//     var33.setWidth(10.0d);
//     var10.add((org.jfree.chart.block.Block)var33, (java.lang.Object)true);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var39 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     boolean var40 = var33.equals((java.lang.Object)var39);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.data.Range var43 = null;
//     org.jfree.chart.block.RectangleConstraint var44 = new org.jfree.chart.block.RectangleConstraint(0.0d, var43);
//     org.jfree.chart.block.RectangleConstraint var46 = var44.toFixedHeight(0.0d);
//     org.jfree.chart.block.RectangleConstraint var48 = var46.toFixedHeight((-1.0d));
//     org.jfree.chart.block.RectangleConstraint var50 = var48.toFixedHeight(Double.NaN);
//     org.jfree.chart.block.RectangleConstraint var51 = var48.toUnconstrainedWidth();
//     org.jfree.chart.util.Size2D var52 = var4.arrange(var33, var41, var51);
//     
//     // Checks the contract:  equals-hashcode on var4 and var10
//     assertTrue("Contract failed: equals-hashcode on var4 and var10", var4.equals(var10) ? var4.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var4
//     assertTrue("Contract failed: equals-hashcode on var10 and var4", var10.equals(var4) ? var10.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setLabelToolTip("");
//     var1.setUpperMargin((-1.0d));
//     var1.setLabelURL("hi!");
//     double var8 = var1.getUpperMargin();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var11.lengthToJava2D((-1.0d), var13, var14);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var11.setLeftArrow(var18);
//     var11.setRangeWithMargins(Double.NaN, 0.0d);
//     var11.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var26 = null;
//     var25.setBaseURLGenerator(var26, false);
//     java.awt.Paint var30 = var25.getSeriesFillPaint(10);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var37 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var34, "hi!", "");
//     java.awt.Shape var38 = var37.getArea();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     double var44 = var40.lengthToJava2D((-1.0d), var42, var43);
//     java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var40.setLeftArrow(var47);
//     var37.setArea(var47);
//     java.awt.Shape var50 = var37.getArea();
//     var25.setBaseShape(var50, true);
//     java.awt.Font var55 = var25.getItemLabelFont(100, 10);
//     var11.setLabelFont(var55);
//     java.awt.Color var59 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var60 = org.jfree.chart.text.TextUtilities.createTextBlock("", var55, (java.awt.Paint)var59);
//     var1.setLabelFont(var55);
//     org.jfree.chart.LegendItemSource var62 = null;
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle(var62);
//     var63.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
//     org.jfree.chart.event.TitleChangeListener var69 = null;
//     var63.removeChangeListener(var69);
//     java.awt.Color var73 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var74 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var73);
//     var63.setItemPaint((java.awt.Paint)var73);
//     java.awt.color.ColorSpace var76 = var73.getColorSpace();
//     org.jfree.chart.block.LabelBlock var77 = new org.jfree.chart.block.LabelBlock("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", var55, (java.awt.Paint)var73);
//     java.awt.Graphics2D var78 = null;
//     java.awt.geom.Rectangle2D var79 = null;
//     java.lang.Object var80 = null;
//     java.lang.Object var81 = var77.draw(var78, var79, var80);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var2 = var1.getStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.Range var5 = null;
//     org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, var5);
//     org.jfree.chart.block.RectangleConstraint var8 = var6.toFixedHeight(0.0d);
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
//     var9.setBaseToolTipGenerator(var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var20 = var15.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
//     org.jfree.data.Range var22 = var15.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var24.lengthToJava2D((-1.0d), var26, var27);
//     java.awt.Shape var29 = var24.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var30 = var24.getMarkerBand();
//     org.jfree.data.Range var31 = var24.getDefaultAutoRange();
//     var15.setDefaultAutoRange(var31);
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var35 = var34.getStroke();
//     java.awt.geom.Rectangle2D var36 = null;
//     var9.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.plot.Marker)var34, var36);
//     boolean var38 = var15.isAxisLineVisible();
//     org.jfree.data.RangeType var39 = var15.getRangeType();
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var43.lengthToJava2D((-1.0d), var45, var46);
//     org.jfree.data.Range var48 = var43.getDefaultAutoRange();
//     org.jfree.data.Range var50 = null;
//     org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(0.0d, var50);
//     org.jfree.chart.block.RectangleConstraint var53 = var51.toFixedHeight(0.0d);
//     org.jfree.chart.block.RectangleConstraint var55 = var53.toFixedHeight((-1.0d));
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var57.lengthToJava2D((-1.0d), var59, var60);
//     org.jfree.data.Range var62 = var57.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var63 = var55.toRangeWidth(var62);
//     org.jfree.data.Range var64 = org.jfree.data.Range.combine(var48, var62);
//     var41.setRange(var48);
//     var15.setRange(var48);
//     org.jfree.data.Range var68 = org.jfree.data.Range.expandToInclude(var48, 3.0d);
//     org.jfree.chart.block.RectangleConstraint var69 = var6.toRangeWidth(var48);
//     org.jfree.chart.util.Size2D var70 = var2.arrange(var3, var6);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setRangeWithMargins(3.0d, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getUpperClip();
//     java.lang.Boolean var3 = null;
//     var0.setSeriesItemLabelsVisible(100, var3, true);
//     org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
//     org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
//     var0.setBasePaint((java.awt.Paint)var10, false);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     var15.setLabelToolTip("");
//     var15.setUpperMargin((-1.0d));
//     var15.setLabelURL("hi!");
//     double var22 = var15.getUpperMargin();
//     boolean var24 = var15.equals((java.lang.Object)(-1.0d));
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleEdge var29 = null;
//     double var30 = var26.lengthToJava2D((-1.0d), var28, var29);
//     java.awt.Shape var31 = var26.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var32 = var26.getMarkerBand();
//     org.jfree.data.Range var33 = var26.getDefaultAutoRange();
//     org.jfree.chart.util.Layer var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     var0.drawAnnotations(var13, var14, var15, (org.jfree.chart.axis.ValueAxis)var26, var34, var35);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
//     var0.setBaseToolTipGenerator(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
//     java.awt.Shape var11 = var6.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
//     org.jfree.data.Range var13 = var6.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var20 = var15.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
//     org.jfree.data.Range var22 = var15.getDefaultAutoRange();
//     var6.setDefaultAutoRange(var22);
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var26 = var25.getStroke();
//     java.awt.geom.Rectangle2D var27 = null;
//     var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
//     org.jfree.chart.labels.CategoryToolTipGenerator var30 = null;
//     var0.setSeriesToolTipGenerator(4, var30, false);
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var35 = var34.getStroke();
//     java.awt.Paint var36 = var34.getLabelPaint();
//     var0.setBaseFillPaint(var36);
//     
//     // Checks the contract:  equals-hashcode on var25 and var34
//     assertTrue("Contract failed: equals-hashcode on var25 and var34", var25.equals(var34) ? var25.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var25
//     assertTrue("Contract failed: equals-hashcode on var34 and var25", var34.equals(var25) ? var34.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var4 = var3.getAlpha();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var5.setBaseToolTipGenerator(var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var11.lengthToJava2D((-1.0d), var13, var14);
    java.awt.Shape var16 = var11.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var17 = var11.getMarkerBand();
    org.jfree.data.Range var18 = var11.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var20.lengthToJava2D((-1.0d), var22, var23);
    java.awt.Shape var25 = var20.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var26 = var20.getMarkerBand();
    org.jfree.data.Range var27 = var20.getDefaultAutoRange();
    var11.setDefaultAutoRange(var27);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var31 = var30.getStroke();
    java.awt.geom.Rectangle2D var32 = null;
    var5.drawRangeMarker(var8, var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.plot.Marker)var30, var32);
    java.awt.Stroke var34 = var5.getBaseStroke();
    org.jfree.chart.block.CenterArrangement var35 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var36 = null;
    boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, var36);
    org.jfree.chart.block.BlockContainer var38 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var35);
    var38.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var44 = var38.getPadding();
    org.jfree.chart.block.Arrangement var45 = var38.getArrangement();
    org.jfree.chart.util.RectangleInsets var46 = var38.getPadding();
    org.jfree.chart.block.LineBorder var47 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var34, var46);
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var51 = null;
    org.jfree.chart.util.RectangleEdge var52 = null;
    double var53 = var49.lengthToJava2D((-1.0d), var51, var52);
    java.awt.Shape var54 = var49.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var55 = var49.getMarkerBand();
    var49.setRange(0.0d, 1.0d);
    java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var65 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var62, "hi!", "");
    java.awt.Shape var66 = var65.getArea();
    var49.setDownArrow(var66);
    boolean var68 = var46.equals((java.lang.Object)var66);
    double var70 = var46.calculateTopInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.0d, 0.5d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    boolean var18 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.util.GradientPaintTransformer var4 = var0.getGradientPaintTransformer();
    org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPosition(10, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-16777215), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    boolean var16 = var15.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var15.zoomDomainAxes(2.0d, 16.0d, var19, var20);
    java.lang.Object var22 = var15.clone();
    org.jfree.chart.axis.AxisLocation var23 = var15.getDomainAxisLocation();
    var0.setDomainAxisLocation(var23, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxis((-1), (-16777215));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     var0.clearRangeMarkers(10);
//     boolean var4 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var5.setLabelToolTip("");
//     var5.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var10 = null;
//     var5.removeChangeListener(var10);
//     org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
//     org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
//     var0.setDomainAxes(var13);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var16 = var15.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     java.awt.geom.Point2D var20 = null;
//     var15.zoomDomainAxes(2.0d, 16.0d, var19, var20);
//     java.lang.Object var22 = var15.clone();
//     org.jfree.chart.axis.AxisLocation var23 = var15.getDomainAxisLocation();
//     var0.setDomainAxisLocation(var23, false);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var27 = var26.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     java.awt.geom.Point2D var31 = null;
//     var26.zoomDomainAxes(2.0d, 16.0d, var30, var31);
//     java.lang.Object var33 = var26.clone();
//     org.jfree.chart.axis.AxisLocation var34 = var26.getDomainAxisLocation();
//     var0.setRangeAxisLocation(var34);
//     
//     // Checks the contract:  equals-hashcode on var15 and var26
//     assertTrue("Contract failed: equals-hashcode on var15 and var26", var15.equals(var26) ? var15.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var15
//     assertTrue("Contract failed: equals-hashcode on var26 and var15", var26.equals(var15) ? var26.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var33
//     assertTrue("Contract failed: equals-hashcode on var22 and var33", var22.equals(var33) ? var22.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var22
//     assertTrue("Contract failed: equals-hashcode on var33 and var22", var33.equals(var22) ? var33.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    boolean var4 = var3.getNotify();
    java.awt.Font var5 = var3.getItemFont();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    double var7 = var6.getUpperClip();
    boolean var8 = var6.getBaseSeriesVisible();
    java.awt.Color var12 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var13 = var12.brighter();
    var6.setSeriesItemLabelPaint(0, (java.awt.Paint)var12, false);
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", var5, (java.awt.Paint)var12);
    java.awt.Paint var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var18 = new org.jfree.chart.text.TextLine("hi!", var5, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Enumeration var2 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var4 = var0.getStringArray("CategoryLabelEntity: category=, tooltip=hi!, url=");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    var6.centerRange(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var2.setLeftArrow(var9);
//     var2.setRangeWithMargins(Double.NaN, 0.0d);
//     var2.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var16.setBaseURLGenerator(var17, false);
//     java.awt.Paint var21 = var16.getSeriesFillPaint(10);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var25, "hi!", "");
//     java.awt.Shape var29 = var28.getArea();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var31.setLeftArrow(var38);
//     var28.setArea(var38);
//     java.awt.Shape var41 = var28.getArea();
//     var16.setBaseShape(var41, true);
//     java.awt.Font var46 = var16.getItemLabelFont(100, 10);
//     var2.setLabelFont(var46);
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, (java.awt.Paint)var50);
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.util.Size2D var53 = var51.calculateDimensions(var52);
//     org.jfree.chart.text.TextLine var54 = null;
//     var51.addLine(var54);
//     org.jfree.chart.util.HorizontalAlignment var56 = var51.getLineAlignment();
//     java.awt.Graphics2D var57 = null;
//     org.jfree.chart.util.Size2D var58 = var51.calculateDimensions(var57);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", var1, 10.0f, 100.0f, var4);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var3 = var0.get(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    var0.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getSeriesURLGenerator(0);
    java.awt.Font var7 = var0.getBaseItemLabelFont();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-16777215), var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
//     var0.setBaseToolTipGenerator(var1);
//     var0.setAutoPopulateSeriesStroke(false);
//     boolean var5 = var0.getBaseSeriesVisibleInLegend();
//     boolean var6 = var0.getAutoPopulateSeriesOutlinePaint();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var9.getCategoryStart(10, (-16777215), var12, var13);
//     java.awt.Font var16 = null;
//     var9.setTickLabelFont((java.lang.Comparable)1, var16);
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     boolean var20 = var19.getAutoRangeStickyZero();
//     org.jfree.chart.util.Layer var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     var0.drawAnnotations(var7, var8, var9, (org.jfree.chart.axis.ValueAxis)var19, var21, var22);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("NOID", var1, (-1.0f), 1.0f, var4, (-1.0d), var6);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var2.setLeftArrow(var9);
//     var2.setRangeWithMargins(Double.NaN, 0.0d);
//     var2.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var16.setBaseURLGenerator(var17, false);
//     java.awt.Paint var21 = var16.getSeriesFillPaint(10);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var25, "hi!", "");
//     java.awt.Shape var29 = var28.getArea();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var31.setLeftArrow(var38);
//     var28.setArea(var38);
//     java.awt.Shape var41 = var28.getArea();
//     var16.setBaseShape(var41, true);
//     java.awt.Font var46 = var16.getItemLabelFont(100, 10);
//     var2.setLabelFont(var46);
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, (java.awt.Paint)var50);
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.util.Size2D var53 = var51.calculateDimensions(var52);
//     org.jfree.chart.text.TextLine var54 = null;
//     var51.addLine(var54);
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.text.TextBlockAnchor var59 = null;
//     var51.draw(var56, 100.0f, 0.0f, var59, 10.0f, 10.0f, 1.0d);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, (-1.0d), "CategoryLabelEntity: category=, tooltip=hi!, url=", var3, var4, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library var5 = new org.jfree.chart.ui.Library("CategoryLabelEntity: category=, tooltip=hi!, url=", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "hi!", "");
    var0.addOptionalLibrary(var5);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     java.awt.Paint var2 = var0.getBackgroundPaint();
//     org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var3.setBaseURLGenerator(var4, false);
//     java.awt.Paint var8 = var3.getSeriesFillPaint(10);
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
//     var9.setBaseToolTipGenerator(var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var20 = var15.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
//     org.jfree.data.Range var22 = var15.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var24.lengthToJava2D((-1.0d), var26, var27);
//     java.awt.Shape var29 = var24.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var30 = var24.getMarkerBand();
//     org.jfree.data.Range var31 = var24.getDefaultAutoRange();
//     var15.setDefaultAutoRange(var31);
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var35 = var34.getStroke();
//     java.awt.geom.Rectangle2D var36 = null;
//     var9.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.plot.Marker)var34, var36);
//     java.awt.Stroke var38 = var9.getBaseStroke();
//     var3.setBaseStroke(var38, true);
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
//     var41.setLabelToolTip("");
//     var41.setUpperMargin((-1.0d));
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.RectangleInsets var48 = var47.getLabelOffset();
//     var41.setTickLabelInsets(var48);
//     org.jfree.chart.block.LineBorder var50 = new org.jfree.chart.block.LineBorder(var2, var38, var48);
//     
//     // Checks the contract:  equals-hashcode on var34 and var47
//     assertTrue("Contract failed: equals-hashcode on var34 and var47", var34.equals(var47) ? var34.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var34
//     assertTrue("Contract failed: equals-hashcode on var47 and var34", var47.equals(var34) ? var47.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setLabelToolTip("");
    var0.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var5 = null;
    var0.removeChangeListener(var5);
    org.jfree.chart.axis.CategoryLabelPositions var7 = var0.getCategoryLabelPositions();
    org.jfree.chart.util.RectangleEdge var8 = null;
    org.jfree.chart.axis.CategoryLabelPosition var9 = var7.getLabelPosition(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var3 = null;
    var2.setBaseURLGenerator(var3, false);
    java.awt.Paint var7 = var2.getSeriesFillPaint(10);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var11, "hi!", "");
    java.awt.Shape var15 = var14.getArea();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var17.lengthToJava2D((-1.0d), var19, var20);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var17.setLeftArrow(var24);
    var14.setArea(var24);
    java.awt.Shape var27 = var14.getArea();
    var2.setBaseShape(var27, true);
    java.awt.Font var32 = var2.getItemLabelFont(100, 10);
    org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("hi!", var32);
    org.jfree.chart.LegendItemSource var34 = null;
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle(var34);
    org.jfree.chart.block.BlockContainer var36 = var35.getItemContainer();
    org.jfree.chart.util.RectangleInsets var37 = var35.getItemLabelPadding();
    java.lang.Object var38 = var35.clone();
    org.jfree.chart.util.RectangleAnchor var39 = var35.getLegendItemGraphicAnchor();
    boolean var40 = var33.equals((java.lang.Object)var39);
    java.awt.Font var41 = var33.getFont();
    java.awt.Paint var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var43 = new org.jfree.chart.block.LabelBlock("hi!", var41, var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("AxisLocation.BOTTOM_OR_LEFT", var1);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.TickUnit var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getLargerTickUnit(var1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, 100.0d, 1.0d, 10.0d);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var4.draw(var5, var6);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setLabelToolTip("");
    var0.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var5 = null;
    var0.removeChangeListener(var5);
    org.jfree.chart.axis.CategoryLabelPositions var7 = var0.getCategoryLabelPositions();
    java.lang.String var9 = var0.getCategoryLabelToolTip((java.lang.Comparable)(-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setLabelToolTip("");
//     var0.setUpperMargin((-1.0d));
//     var0.setLabelURL("hi!");
//     double var7 = var0.getUpperMargin();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var10.lengthToJava2D((-1.0d), var12, var13);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var10.setLeftArrow(var17);
//     var10.setRangeWithMargins(Double.NaN, 0.0d);
//     var10.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var25 = null;
//     var24.setBaseURLGenerator(var25, false);
//     java.awt.Paint var29 = var24.getSeriesFillPaint(10);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var36 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var33, "hi!", "");
//     java.awt.Shape var37 = var36.getArea();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     double var43 = var39.lengthToJava2D((-1.0d), var41, var42);
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var39.setLeftArrow(var46);
//     var36.setArea(var46);
//     java.awt.Shape var49 = var36.getArea();
//     var24.setBaseShape(var49, true);
//     java.awt.Font var54 = var24.getItemLabelFont(100, 10);
//     var10.setLabelFont(var54);
//     java.awt.Color var58 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var59 = org.jfree.chart.text.TextUtilities.createTextBlock("", var54, (java.awt.Paint)var58);
//     var0.setLabelFont(var54);
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var67 = null;
//     org.jfree.chart.util.RectangleEdge var68 = null;
//     double var69 = var64.getCategoryStart(10, (-16777215), var67, var68);
//     java.awt.Font var71 = null;
//     var64.setTickLabelFont((java.lang.Comparable)1, var71);
//     java.lang.String var73 = var64.getLabel();
//     org.jfree.chart.axis.CategoryAnchor var74 = null;
//     java.awt.geom.Rectangle2D var77 = null;
//     org.jfree.chart.LegendItemSource var78 = null;
//     org.jfree.chart.title.LegendTitle var79 = new org.jfree.chart.title.LegendTitle(var78);
//     boolean var80 = var79.getNotify();
//     double var81 = var79.getWidth();
//     org.jfree.chart.util.RectangleEdge var82 = var79.getLegendItemGraphicEdge();
//     double var83 = var64.getCategoryJava2DCoordinate(var74, (-1), (-16777215), var77, var82);
//     double var84 = var0.getCategoryMiddle(15, 0, var63, var82);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(8.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    boolean var2 = var1.getNotify();
    org.jfree.chart.block.BlockContainer var3 = var1.getItemContainer();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var4.setLabelToolTip("");
    var4.setUpperMargin((-1.0d));
    org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelOffset();
    var4.setTickLabelInsets(var11);
    var3.setPadding(var11);
    double var15 = var11.calculateTopOutset(0.0d);
    double var17 = var11.extendHeight(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 7.0d);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
//     float[] var7 = new float[] { (-1.0f), 10.0f, 1.0f};
//     float[] var8 = var2.getRGBColorComponents(var7);
//     int var9 = var2.getRed();
//     org.jfree.chart.LegendItemSource var10 = null;
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
//     var11.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
//     org.jfree.chart.event.TitleChangeListener var17 = null;
//     var11.removeChangeListener(var17);
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var21);
//     var11.setItemPaint((java.awt.Paint)var21);
//     java.awt.color.ColorSpace var24 = var21.getColorSpace();
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
//     org.jfree.chart.block.BlockContainer var27 = var26.getItemContainer();
//     var26.setNotify(false);
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var33 = var32.brighter();
//     java.awt.Color var34 = var32.brighter();
//     var26.setItemPaint((java.awt.Paint)var32);
//     java.awt.Color var38 = java.awt.Color.getColor("hi!", 1);
//     float[] var42 = new float[] { 10.0f, 0.0f, 1.0f};
//     float[] var43 = var38.getColorComponents(var42);
//     float[] var44 = var32.getColorComponents(var43);
//     float[] var45 = var2.getColorComponents(var24, var43);
//     
//     // Checks the contract:  equals-hashcode on var3 and var22
//     assertTrue("Contract failed: equals-hashcode on var3 and var22", var3.equals(var22) ? var3.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var3
//     assertTrue("Contract failed: equals-hashcode on var22 and var3", var22.equals(var3) ? var22.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
//     org.jfree.data.Range var2 = null;
//     org.jfree.chart.block.RectangleConstraint var3 = new org.jfree.chart.block.RectangleConstraint(0.0d, var2);
//     org.jfree.chart.block.RectangleConstraint var5 = var3.toFixedHeight(0.0d);
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     org.jfree.chart.util.Size2D var7 = null;
//     org.jfree.chart.util.Size2D var8 = var3.calculateConstrainedSize(var7);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var3 = var2.isDomainGridlinesVisible();
//     java.awt.Paint var4 = var2.getBackgroundPaint();
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("RangeType.FULL", var1, var4, 1.0f, 15, var7);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Enumeration var2 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject("0,0,2,-2,2,2,2,2");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Shape var2 = var1.getDownArrow();
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(0.0d, var4);
    org.jfree.chart.block.RectangleConstraint var7 = var5.toFixedHeight(0.0d);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = null;
    var8.setBaseToolTipGenerator(var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var14.lengthToJava2D((-1.0d), var16, var17);
    java.awt.Shape var19 = var14.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var20 = var14.getMarkerBand();
    org.jfree.data.Range var21 = var14.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var23.lengthToJava2D((-1.0d), var25, var26);
    java.awt.Shape var28 = var23.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var29 = var23.getMarkerBand();
    org.jfree.data.Range var30 = var23.getDefaultAutoRange();
    var14.setDefaultAutoRange(var30);
    org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var34 = var33.getStroke();
    java.awt.geom.Rectangle2D var35 = null;
    var8.drawRangeMarker(var11, var12, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.plot.Marker)var33, var35);
    boolean var37 = var14.isAxisLineVisible();
    org.jfree.data.RangeType var38 = var14.getRangeType();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleEdge var45 = null;
    double var46 = var42.lengthToJava2D((-1.0d), var44, var45);
    org.jfree.data.Range var47 = var42.getDefaultAutoRange();
    org.jfree.data.Range var49 = null;
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint(0.0d, var49);
    org.jfree.chart.block.RectangleConstraint var52 = var50.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var54 = var52.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var58 = null;
    org.jfree.chart.util.RectangleEdge var59 = null;
    double var60 = var56.lengthToJava2D((-1.0d), var58, var59);
    org.jfree.data.Range var61 = var56.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var62 = var54.toRangeWidth(var61);
    org.jfree.data.Range var63 = org.jfree.data.Range.combine(var47, var61);
    var40.setRange(var47);
    var14.setRange(var47);
    org.jfree.data.Range var67 = org.jfree.data.Range.expandToInclude(var47, 3.0d);
    org.jfree.chart.block.RectangleConstraint var68 = var5.toRangeWidth(var47);
    var1.setDefaultAutoRange(var47);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeAboutValue(100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    double var2 = var0.getRangeCrosshairValue();
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(100);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, 100.0d, 1.0d, 10.0d);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.LegendItemSource var6 = null;
//     org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
//     boolean var8 = var7.getNotify();
//     java.awt.geom.Rectangle2D var9 = var7.getBounds();
//     var4.draw(var5, var9);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var2 = var0.getRangeLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var5 = var0.getValue(100, (-1));
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    boolean var3 = var2.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var2.zoomDomainAxes(2.0d, 16.0d, var6, var7);
    java.awt.Paint var9 = var2.getNoDataMessagePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine("NOID", var1, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     double var2 = var0.getRangeCrosshairValue();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var4 = var3.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var3.zoomDomainAxes(2.0d, 16.0d, var7, var8);
//     java.lang.Object var10 = var3.clone();
//     org.jfree.chart.axis.AxisLocation var11 = var3.getDomainAxisLocation();
//     var0.setDomainAxisLocation(var11);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseSeriesVisible();
    boolean var3 = var0.getAutoPopulateSeriesOutlinePaint();
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getURLGenerator(255, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var0.addChangeListener(var2);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)0);
    boolean var7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var6);
    org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var6, (java.lang.Comparable)(short)100, 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
//     java.awt.Shape var7 = var6.getArea();
//     java.lang.String var8 = var6.getToolTipText();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var9 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var10 = null;
//     java.lang.String var11 = var6.getImageMapAreaTag(var9, var10);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var1.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var1.zoomDomainAxes(2.0d, 16.0d, var5, var6);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var1);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var11.setTickMarkInsideLength(100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setLabelToolTip("");
    var0.setUpperMargin((-1.0d));
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var7 = var6.getLabelOffset();
    var0.setTickLabelInsets(var7);
    var0.addCategoryLabelToolTip((java.lang.Comparable)(short)0, "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    double var2 = var1.getUpperClip();
    var1.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.util.GradientPaintTransformer var5 = var1.getGradientPaintTransformer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var1.getPositiveItemLabelPosition(10, 100);
    double var9 = var8.getAngle();
    org.jfree.chart.text.TextAnchor var10 = var8.getTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition(var0, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    boolean var2 = var1.getNotify();
    java.awt.Font var3 = var1.getItemFont();
    java.awt.Paint var4 = var1.getItemPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var2 = var0.getRangeLowerBound(false);
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
//     java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var10 = var0.getValue(100, 15);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("CategoryLabelEntity: category=, tooltip=hi!, url=", var1);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setLabelToolTip("");
    org.jfree.chart.axis.CategoryAnchor var3 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var0.getCategoryJava2DCoordinate(var3, 0, 0, var6, var7);
    var0.setAxisLineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getItemLabelPadding();
//     java.lang.Object var4 = var1.clone();
//     org.jfree.chart.util.RectangleEdge var5 = var1.getPosition();
//     org.jfree.chart.LegendItemSource var6 = null;
//     org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
//     org.jfree.chart.block.BlockContainer var8 = var7.getItemContainer();
//     var7.setNotify(false);
//     org.jfree.chart.event.TitleChangeListener var11 = null;
//     var7.removeChangeListener(var11);
//     org.jfree.chart.util.VerticalAlignment var13 = var7.getVerticalAlignment();
//     var1.setVerticalAlignment(var13);
//     
//     // Checks the contract:  equals-hashcode on var2 and var8
//     assertTrue("Contract failed: equals-hashcode on var2 and var8", var2.equals(var8) ? var2.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var2
//     assertTrue("Contract failed: equals-hashcode on var8 and var2", var8.equals(var2) ? var8.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     org.jfree.data.KeyedObject var2 = new org.jfree.data.KeyedObject(var0, (java.lang.Object)var1);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var5 = var3.getRangeLowerBound(false);
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var3, false);
//     org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var3);
//     java.util.EventListener var9 = null;
//     boolean var10 = var3.hasListener(var9);
//     org.jfree.data.Range var11 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var1.generateLabel((org.jfree.data.category.CategoryDataset)var3, 10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", var1);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomDomainAxes(2.0d, 16.0d, var4, var5);
//     java.awt.Paint var7 = var0.getNoDataMessagePaint();
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     var0.zoom(2.0d);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     boolean var1 = var0.getBaseSeriesVisible();
//     java.awt.Font var2 = var0.getBaseItemLabelFont();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var5 = var4.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     var4.zoomDomainAxes(2.0d, 16.0d, var8, var9);
//     java.awt.Paint var11 = var4.getNoDataMessagePaint();
//     var4.setForegroundAlpha(0.0f);
//     java.util.List var14 = var4.getCategories();
//     org.jfree.chart.block.LineBorder var15 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var18);
//     boolean var20 = var15.equals((java.lang.Object)var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.LegendItemSource var22 = null;
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var22);
//     boolean var24 = var23.getNotify();
//     java.awt.geom.Rectangle2D var25 = var23.getBounds();
//     var15.draw(var21, var25);
//     var0.drawOutline(var3, var4, var25);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = var0.get(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var17 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var17);
    org.jfree.chart.plot.CategoryMarker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "", "");
    java.lang.String var10 = var9.getShapeCoords();
    var9.setToolTipText("UnitType.ABSOLUTE");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0,0,2,-2,2,2,2,2"+ "'", var10.equals("0,0,2,-2,2,2,2,2"));

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(Double.NaN);
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.block.BlockContainer var4 = var3.getItemContainer();
//     var3.setNotify(false);
//     org.jfree.chart.util.RectangleInsets var7 = var3.getItemLabelPadding();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setLabelToolTip("");
//     var8.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var13 = null;
//     var8.removeChangeListener(var13);
//     org.jfree.chart.axis.CategoryLabelPositions var15 = var8.getCategoryLabelPositions();
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     boolean var18 = var17.getNotify();
//     double var19 = var17.getWidth();
//     org.jfree.chart.util.RectangleEdge var20 = var17.getLegendItemGraphicEdge();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var21.getCategoryStart(10, (-16777215), var24, var25);
//     java.awt.Font var28 = null;
//     var21.setTickLabelFont((java.lang.Comparable)1, var28);
//     java.lang.String var30 = var21.getLabel();
//     org.jfree.chart.axis.CategoryAnchor var31 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.LegendItemSource var35 = null;
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle(var35);
//     boolean var37 = var36.getNotify();
//     double var38 = var36.getWidth();
//     org.jfree.chart.util.RectangleEdge var39 = var36.getLegendItemGraphicEdge();
//     double var40 = var21.getCategoryJava2DCoordinate(var31, (-1), (-16777215), var34, var39);
//     var17.setLegendItemGraphicEdge(var39);
//     org.jfree.chart.axis.CategoryLabelPosition var42 = var15.getLabelPosition(var39);
//     var3.setLegendItemGraphicEdge(var39);
//     org.jfree.chart.axis.CategoryLabelPosition var44 = var1.getLabelPosition(var39);
//     org.jfree.chart.axis.CategoryLabelPositions var46 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(Double.NaN);
//     org.jfree.chart.LegendItemSource var47 = null;
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle(var47);
//     org.jfree.chart.block.BlockContainer var49 = var48.getItemContainer();
//     var48.setNotify(false);
//     org.jfree.chart.util.RectangleInsets var52 = var48.getItemLabelPadding();
//     org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis();
//     var53.setLabelToolTip("");
//     var53.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var58 = null;
//     var53.removeChangeListener(var58);
//     org.jfree.chart.axis.CategoryLabelPositions var60 = var53.getCategoryLabelPositions();
//     org.jfree.chart.LegendItemSource var61 = null;
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle(var61);
//     boolean var63 = var62.getNotify();
//     double var64 = var62.getWidth();
//     org.jfree.chart.util.RectangleEdge var65 = var62.getLegendItemGraphicEdge();
//     org.jfree.chart.axis.CategoryAxis var66 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var69 = null;
//     org.jfree.chart.util.RectangleEdge var70 = null;
//     double var71 = var66.getCategoryStart(10, (-16777215), var69, var70);
//     java.awt.Font var73 = null;
//     var66.setTickLabelFont((java.lang.Comparable)1, var73);
//     java.lang.String var75 = var66.getLabel();
//     org.jfree.chart.axis.CategoryAnchor var76 = null;
//     java.awt.geom.Rectangle2D var79 = null;
//     org.jfree.chart.LegendItemSource var80 = null;
//     org.jfree.chart.title.LegendTitle var81 = new org.jfree.chart.title.LegendTitle(var80);
//     boolean var82 = var81.getNotify();
//     double var83 = var81.getWidth();
//     org.jfree.chart.util.RectangleEdge var84 = var81.getLegendItemGraphicEdge();
//     double var85 = var66.getCategoryJava2DCoordinate(var76, (-1), (-16777215), var79, var84);
//     var62.setLegendItemGraphicEdge(var84);
//     org.jfree.chart.axis.CategoryLabelPosition var87 = var60.getLabelPosition(var84);
//     var48.setLegendItemGraphicEdge(var84);
//     org.jfree.chart.axis.CategoryLabelPosition var89 = var46.getLabelPosition(var84);
//     org.jfree.chart.axis.CategoryLabelPosition var90 = var1.getLabelPosition(var84);
//     
//     // Checks the contract:  equals-hashcode on var4 and var49
//     assertTrue("Contract failed: equals-hashcode on var4 and var49", var4.equals(var49) ? var4.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var4
//     assertTrue("Contract failed: equals-hashcode on var49 and var4", var49.equals(var4) ? var49.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var3 = var0.isItemLabelVisible(10, 10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var6 = var5.isDomainGridlinesVisible();
//     double var7 = var5.getRangeCrosshairValue();
//     java.awt.Stroke var8 = var5.getRangeGridlineStroke();
//     var0.setSeriesOutlineStroke(255, var8, false);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var12 = var11.getUpperClip();
//     var11.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var15 = var11.getGradientPaintTransformer();
//     var0.setGradientPaintTransformer(var15);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var0.", var11.equals(var0) == var0.equals(var11));
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(10.0d, 1.0d, 3.0d, 8.0d, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var4.lengthToJava2D((-1.0d), var6, var7);
    java.awt.Shape var9 = var4.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var12 = new org.jfree.chart.entity.TickLabelEntity(var9, "", "");
    boolean var13 = var2.equals((java.lang.Object)var9);
    org.jfree.chart.block.LineBorder var14 = new org.jfree.chart.block.LineBorder();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
    boolean var19 = var14.equals((java.lang.Object)var18);
    java.awt.Paint var20 = var14.getPaint();
    java.awt.Paint var21 = var14.getPaint();
    org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic(var9, var21);
    org.jfree.chart.util.RectangleAnchor var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setShapeAnchor(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var3 = var2.brighter();
    boolean var5 = var2.equals((java.lang.Object)(short)100);
    int var6 = var2.getRed();
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    var8.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
    org.jfree.chart.event.TitleChangeListener var14 = null;
    var8.removeChangeListener(var14);
    java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var18);
    var8.setItemPaint((java.awt.Paint)var18);
    java.awt.color.ColorSpace var21 = var18.getColorSpace();
    org.jfree.chart.LegendItemSource var22 = null;
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var22);
    org.jfree.chart.block.BlockContainer var24 = var23.getItemContainer();
    var23.setNotify(false);
    java.awt.Color var29 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var30 = var29.brighter();
    java.awt.Color var31 = var29.brighter();
    var23.setItemPaint((java.awt.Paint)var29);
    java.awt.Color var35 = java.awt.Color.getColor("hi!", 1);
    float[] var39 = new float[] { 10.0f, 0.0f, 1.0f};
    float[] var40 = var35.getColorComponents(var39);
    float[] var41 = var29.getColorComponents(var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var42 = var2.getComponents(var21, var40);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getInsets();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    org.jfree.data.Range var11 = var6.getDefaultAutoRange();
    boolean var12 = var3.equals((java.lang.Object)var6);
    java.awt.Font var13 = var6.getTickLabelFont();
    org.jfree.chart.axis.NumberTickUnit var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setTickUnit(var14, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var4 = var3.getAlpha();
    java.awt.Paint[] var5 = new java.awt.Paint[] { var3};
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var7.lengthToJava2D((-1.0d), var9, var10);
    java.awt.Shape var12 = var7.getLeftArrow();
    var7.setAutoRangeMinimumSize(100.0d);
    var7.configure();
    var7.setVisible(true);
    var7.setInverted(true);
    java.awt.Paint var20 = var7.getLabelPaint();
    java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
    org.jfree.chart.ChartColor var25 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var26 = var25.getAlpha();
    java.awt.Paint[] var27 = new java.awt.Paint[] { var25};
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var30 = var28.lookupSeriesStroke(255);
    java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
    org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var34 = var32.lookupSeriesStroke(255);
    java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.util.RectangleEdge var40 = null;
    double var41 = var37.lengthToJava2D((-1.0d), var39, var40);
    java.awt.Shape var42 = var37.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var43 = var37.getMarkerBand();
    var37.setRange(0.0d, 1.0d);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var53 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var50, "hi!", "");
    java.awt.Shape var54 = var53.getArea();
    var37.setDownArrow(var54);
    java.awt.Shape[] var56 = new java.awt.Shape[] { var54};
    org.jfree.chart.plot.DefaultDrawingSupplier var57 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var21, var27, var31, var35, var56);
    java.lang.Object var58 = var57.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    boolean var29 = var6.isAxisLineVisible();
    org.jfree.data.RangeType var30 = var6.getRangeType();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    double var38 = var34.lengthToJava2D((-1.0d), var36, var37);
    org.jfree.data.Range var39 = var34.getDefaultAutoRange();
    org.jfree.data.Range var41 = null;
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(0.0d, var41);
    org.jfree.chart.block.RectangleConstraint var44 = var42.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var46 = var44.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var50 = null;
    org.jfree.chart.util.RectangleEdge var51 = null;
    double var52 = var48.lengthToJava2D((-1.0d), var50, var51);
    org.jfree.data.Range var53 = var48.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var54 = var46.toRangeWidth(var53);
    org.jfree.data.Range var55 = org.jfree.data.Range.combine(var39, var53);
    var32.setRange(var39);
    var6.setRange(var39);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var59 = var58.clone();
    org.jfree.data.general.DatasetChangeListener var60 = null;
    var58.addChangeListener(var60);
    org.jfree.data.Range var62 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var58);
    org.jfree.data.general.DatasetChangeEvent var63 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var6, (org.jfree.data.general.Dataset)var58);
    org.jfree.data.general.DatasetGroup var65 = new org.jfree.data.general.DatasetGroup("hi!");
    java.lang.Object var66 = var65.clone();
    var58.setGroup(var65);
    org.jfree.data.Range var68 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var58);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var71 = var58.getMeanValue(0, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var1);
    java.lang.Object var4 = var0.getObject((java.lang.Comparable)"hi!");
    org.jfree.chart.LegendItemSource var6 = null;
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
    org.jfree.chart.block.BlockContainer var8 = var7.getItemContainer();
    var7.setNotify(false);
    org.jfree.chart.event.TitleChangeListener var11 = null;
    var7.removeChangeListener(var11);
    org.jfree.chart.util.VerticalAlignment var13 = var7.getVerticalAlignment();
    org.jfree.chart.util.RectangleInsets var14 = var7.getLegendItemGraphicPadding();
    var0.addObject((java.lang.Comparable)0.5d, (java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var2
//     assertTrue("Contract failed: equals-hashcode on var1 and var2", var1.equals(var2) ? var1.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var1
//     assertTrue("Contract failed: equals-hashcode on var2 and var1", var2.equals(var1) ? var2.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var2 = var1.getStroke();
    java.awt.Paint var3 = var1.getLabelPaint();
    org.jfree.chart.util.LengthAdjustmentType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffsetType(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    org.jfree.chart.util.RectangleInsets var3 = var1.getItemLabelPadding();
    java.lang.Object var4 = var1.clone();
    org.jfree.chart.util.RectangleAnchor var5 = var1.getLegendItemGraphicAnchor();
    org.jfree.chart.block.CenterArrangement var6 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var7 = null;
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, var7);
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var6);
    var9.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var15 = var9.getPadding();
    org.jfree.chart.util.RectangleInsets var16 = var9.getMargin();
    var1.setWrapper(var9);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder();
    var9.setFrame((org.jfree.chart.block.BlockFrame)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var7 = var1.getMarkerBand();
    var1.setRange(0.0d, 1.0d);
    double var11 = var1.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Shape var6 = var5.getDownArrow();
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, Double.NaN, 1.0f, 100.0f);
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var13);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var17 = var16.getStroke();
//     java.awt.Stroke var18 = var16.getOutlineStroke();
//     org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(100, 0, 10);
//     int var23 = var22.getAlpha();
//     org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "0,0,2,-2,2,2,2,2", "", var10, (java.awt.Paint)var13, var18, (java.awt.Paint)var22);
//     java.awt.Paint var25 = var24.getOutlinePaint();
//     org.jfree.data.general.Dataset var26 = var24.getDataset();
//     var24.setDatasetIndex(1);
//     org.jfree.chart.util.StandardGradientPaintTransformer var29 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.lang.Object var30 = var29.clone();
//     var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var29);
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Shape var38 = var37.getDownArrow();
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.rotateShape(var38, Double.NaN, 1.0f, 100.0f);
//     java.awt.Color var45 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var45);
//     org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var49 = var48.getStroke();
//     java.awt.Stroke var50 = var48.getOutlineStroke();
//     org.jfree.chart.ChartColor var54 = new org.jfree.chart.ChartColor(100, 0, 10);
//     int var55 = var54.getAlpha();
//     org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("hi!", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "0,0,2,-2,2,2,2,2", "", var42, (java.awt.Paint)var45, var50, (java.awt.Paint)var54);
//     java.awt.Paint var57 = var56.getOutlinePaint();
//     org.jfree.data.general.Dataset var58 = var56.getDataset();
//     var56.setDatasetIndex(1);
//     org.jfree.chart.util.StandardGradientPaintTransformer var61 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.lang.Object var62 = var61.clone();
//     var56.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var61);
//     var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var61);
//     
//     // Checks the contract:  equals-hashcode on var14 and var46
//     assertTrue("Contract failed: equals-hashcode on var14 and var46", var14.equals(var46) ? var14.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var14
//     assertTrue("Contract failed: equals-hashcode on var46 and var14", var46.equals(var14) ? var46.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var48
//     assertTrue("Contract failed: equals-hashcode on var16 and var48", var16.equals(var48) ? var16.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var16
//     assertTrue("Contract failed: equals-hashcode on var48 and var16", var48.equals(var16) ? var48.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    var1.setURLText("CategoryLabelEntity: category=, tooltip=hi!, url=");
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var6.setBaseURLGenerator(var7, false);
    java.awt.Paint var11 = var6.getSeriesFillPaint(10);
    boolean var14 = var6.isItemLabelVisible(0, (-16777215));
    java.lang.Object var15 = var1.draw(var4, var5, (java.lang.Object)0);
    java.lang.String var16 = var1.getToolTipText();
    var1.setURLText("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    var1.setBaseURLGenerator(var2, false);
    java.awt.Paint var6 = var1.getSeriesFillPaint(10);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var10, "hi!", "");
    java.awt.Shape var14 = var13.getArea();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var16.lengthToJava2D((-1.0d), var18, var19);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var16.setLeftArrow(var23);
    var13.setArea(var23);
    java.awt.Shape var26 = var13.getArea();
    var1.setBaseShape(var26, true);
    java.awt.Font var31 = var1.getItemLabelFont(100, 10);
    org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("CategoryLabelEntity: category=, tooltip=hi!, url=", var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var3 = var2.getUpperClip();
//     var2.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var6 = var2.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var2.getPositiveItemLabelPosition(10, 100);
//     double var10 = var9.getAngle();
//     org.jfree.chart.text.TextAnchor var11 = var9.getTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var13 = var12.getUpperClip();
//     var12.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var16 = var12.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var12.getPositiveItemLabelPosition(10, 100);
//     double var20 = var19.getAngle();
//     org.jfree.chart.text.TextAnchor var21 = var19.getTextAnchor();
//     org.jfree.chart.axis.NumberTick var23 = new org.jfree.chart.axis.NumberTick((java.lang.Number)10.0d, "RangeType.FULL", var11, var21, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var9 and var19
//     assertTrue("Contract failed: equals-hashcode on var9 and var19", var9.equals(var19) ? var9.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var9
//     assertTrue("Contract failed: equals-hashcode on var19 and var9", var19.equals(var9) ? var19.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var4 = null;
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle(var4);
//     boolean var6 = var5.getNotify();
//     org.jfree.chart.block.BlockContainer var7 = var5.getItemContainer();
//     org.jfree.chart.block.Arrangement var8 = var7.getArrangement();
//     var1.setWrapper(var7);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var2
//     assertTrue("Contract failed: equals-hashcode on var7 and var2", var7.equals(var2) ? var7.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomDomainAxes(2.0d, 16.0d, var4, var5);
    java.lang.Object var7 = var0.clone();
    org.jfree.chart.axis.AxisLocation var8 = var0.getRangeAxisLocation();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var10.lengthToJava2D((-1.0d), var12, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var10.setLeftArrow(var17);
    var10.setRangeWithMargins(Double.NaN, 0.0d);
    org.jfree.data.Range var22 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.centerRange(0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    org.jfree.chart.util.RectangleInsets var3 = var1.getItemLabelPadding();
    java.lang.Object var4 = var1.clone();
    org.jfree.chart.util.RectangleAnchor var5 = var1.getLegendItemGraphicAnchor();
    org.jfree.chart.event.TitleChangeEvent var6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    org.jfree.chart.event.ChartChangeEventType var7 = null;
    var6.setType(var7);
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var6.setType(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var3.setLeftArrow(var10);
//     var3.setRangeWithMargins(Double.NaN, 0.0d);
//     var3.setTickLabelsVisible(true);
//     int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
//     java.awt.Paint var18 = var0.getRangeGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var20 = var19.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var22.lengthToJava2D((-1.0d), var24, var25);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var22.setLeftArrow(var29);
//     var22.setRangeWithMargins(Double.NaN, 0.0d);
//     var22.setTickLabelsVisible(true);
//     int var36 = var19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var22);
//     java.awt.Paint var37 = var19.getRangeGridlinePaint();
//     var0.setRangeGridlinePaint(var37);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.setCursor(0.0d);
    java.util.List var3 = var0.getTicks();
    var0.setCursor(0.0d);
    var0.setCursor((-1.0d));
    var0.cursorRight((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", var3);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.lang.Boolean var3 = null;
    var0.setSeriesItemLabelsVisible(100, var3, true);
    org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
    var0.setBasePaint((java.awt.Paint)var10, false);
    double var13 = var0.getLowerClip();
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var0.setBaseURLGenerator(var14);
    var0.setIncludeBaseInRange(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var5 = var4.getUpperClip();
//     var4.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var8 = var4.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var4.getPositiveItemLabelPosition(10, 100);
//     double var12 = var11.getAngle();
//     org.jfree.chart.text.TextAnchor var13 = var11.getTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var16 = var15.getUpperClip();
//     var15.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var19 = var15.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var15.getPositiveItemLabelPosition(10, 100);
//     double var23 = var22.getAngle();
//     org.jfree.chart.text.TextAnchor var24 = var22.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("0,0,2,-2,2,2,2,2", var1, 100.0f, 100.0f, var13, 7.0d, var24);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseSeriesVisible();
    boolean var3 = var0.getAutoPopulateSeriesShape();
    var0.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var8 = var7.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.ItemLabelPosition var11 = var7.getPositiveItemLabelPosition((-16777215), 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-16777215), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
//     var0.setBaseToolTipGenerator(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
//     java.awt.Shape var11 = var6.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
//     org.jfree.data.Range var13 = var6.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var20 = var15.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
//     org.jfree.data.Range var22 = var15.getDefaultAutoRange();
//     var6.setDefaultAutoRange(var22);
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var26 = var25.getStroke();
//     java.awt.geom.Rectangle2D var27 = null;
//     var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
//     boolean var29 = var6.isAxisLineVisible();
//     org.jfree.data.RangeType var30 = var6.getRangeType();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var34.lengthToJava2D((-1.0d), var36, var37);
//     org.jfree.data.Range var39 = var34.getDefaultAutoRange();
//     org.jfree.data.Range var41 = null;
//     org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(0.0d, var41);
//     org.jfree.chart.block.RectangleConstraint var44 = var42.toFixedHeight(0.0d);
//     org.jfree.chart.block.RectangleConstraint var46 = var44.toFixedHeight((-1.0d));
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.util.RectangleEdge var51 = null;
//     double var52 = var48.lengthToJava2D((-1.0d), var50, var51);
//     org.jfree.data.Range var53 = var48.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var54 = var46.toRangeWidth(var53);
//     org.jfree.data.Range var55 = org.jfree.data.Range.combine(var39, var53);
//     var32.setRange(var39);
//     var6.setRange(var39);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Object var59 = var58.clone();
//     org.jfree.data.general.DatasetChangeListener var60 = null;
//     var58.addChangeListener(var60);
//     org.jfree.data.Range var62 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var58);
//     org.jfree.data.general.DatasetChangeEvent var63 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var6, (org.jfree.data.general.Dataset)var58);
//     org.jfree.data.general.DatasetGroup var65 = new org.jfree.data.general.DatasetGroup("hi!");
//     java.lang.Object var66 = var65.clone();
//     var58.setGroup(var65);
//     java.lang.Object var68 = var65.clone();
//     
//     // Checks the contract:  equals-hashcode on var66 and var68
//     assertTrue("Contract failed: equals-hashcode on var66 and var68", var66.equals(var68) ? var66.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var66
//     assertTrue("Contract failed: equals-hashcode on var68 and var66", var68.equals(var66) ? var68.hashCode() == var66.hashCode() : true);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     boolean var2 = var1.getNotify();
//     double var3 = var1.getWidth();
//     org.jfree.chart.util.RectangleEdge var4 = var1.getLegendItemGraphicEdge();
//     boolean var5 = var1.getNotify();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(0.0d, var8);
//     org.jfree.chart.block.RectangleConstraint var11 = var9.toFixedHeight(0.0d);
//     org.jfree.chart.util.Size2D var12 = var1.arrange(var6, var9);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1, false);
    java.awt.Paint var5 = var0.getSeriesItemLabelPaint(0);
    org.jfree.chart.annotations.CategoryAnnotation var6 = null;
    boolean var7 = var0.removeAnnotation(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelEntity: category=, tooltip=hi!, url=");
    boolean var2 = var1.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    var1.setNotify(false);
    org.jfree.chart.util.RectangleInsets var5 = var1.getItemLabelPadding();
    org.jfree.chart.util.UnitType var6 = var5.getUnitType();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    double var12 = var8.lengthToJava2D((-1.0d), var10, var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var8.setLeftArrow(var15);
    var8.setRangeWithMargins(Double.NaN, 0.0d);
    boolean var20 = var6.equals((java.lang.Object)var8);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    var21.setLabelToolTip("");
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    boolean var26 = var25.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var28.lengthToJava2D((-1.0d), var30, var31);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var28.setLeftArrow(var35);
    var28.setRangeWithMargins(Double.NaN, 0.0d);
    var28.setTickLabelsVisible(true);
    int var42 = var25.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var28);
    java.awt.Paint var43 = var25.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
    double var45 = var44.getUpperClip();
    var25.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var44);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Shape var53 = var52.getDownArrow();
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.rotateShape(var53, Double.NaN, 1.0f, 100.0f);
    java.awt.Color var60 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var61 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var60);
    org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var64 = var63.getStroke();
    java.awt.Stroke var65 = var63.getOutlineStroke();
    org.jfree.chart.ChartColor var69 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var70 = var69.getAlpha();
    org.jfree.chart.LegendItem var71 = new org.jfree.chart.LegendItem("hi!", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "0,0,2,-2,2,2,2,2", "", var57, (java.awt.Paint)var60, var65, (java.awt.Paint)var69);
    java.awt.Paint var72 = var71.getOutlinePaint();
    java.awt.Paint var73 = var71.getOutlinePaint();
    int var74 = var71.getDatasetIndex();
    java.lang.String var75 = var71.getLabel();
    java.awt.Paint var76 = var71.getFillPaint();
    var25.setNoDataMessagePaint(var76);
    var21.setTickLabelPaint((java.lang.Comparable)10.0d, var76);
    boolean var79 = var6.equals((java.lang.Object)var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + "hi!"+ "'", var75.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    var0.setAutoPopulateSeriesStroke(false);
    boolean var5 = var0.getBaseSeriesVisibleInLegend();
    boolean var6 = var0.getAutoPopulateSeriesOutlinePaint();
    var0.setItemLabelAnchorOffset(8.0d);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var11.lengthToJava2D((-1.0d), var13, var14);
    java.awt.Shape var16 = var11.getLeftArrow();
    var11.setAutoRangeMinimumSize(100.0d);
    var11.configure();
    var11.setVisible(true);
    var11.setInverted(true);
    java.awt.Paint var24 = var11.getLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var3 = var0.isItemLabelVisible(10, 10);
    var0.setIncludeBaseInRange(false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
    var0.setBaseItemLabelGenerator(var6, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.TickUnit var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(var1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
//     var1.setNotify(false);
//     org.jfree.chart.util.RectangleEdge var5 = var1.getPosition();
//     org.jfree.chart.block.BlockContainer var6 = var1.getItemContainer();
//     java.awt.Paint var7 = var1.getBackgroundPaint();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.data.Range var10 = null;
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(0.0d, var10);
//     org.jfree.chart.block.RectangleConstraint var13 = var11.toFixedHeight(0.0d);
//     org.jfree.chart.block.RectangleConstraint var15 = var13.toFixedHeight((-1.0d));
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var17.lengthToJava2D((-1.0d), var19, var20);
//     org.jfree.data.Range var22 = var17.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var23 = var15.toRangeWidth(var22);
//     org.jfree.chart.block.RectangleConstraint var24 = var23.toUnconstrainedHeight();
//     java.lang.String var25 = var23.toString();
//     org.jfree.chart.util.Size2D var26 = var1.arrange(var8, var23);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(0.2d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    boolean var16 = var15.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var15.zoomDomainAxes(2.0d, 16.0d, var19, var20);
    java.lang.Object var22 = var15.clone();
    org.jfree.chart.axis.AxisLocation var23 = var15.getDomainAxisLocation();
    var0.setDomainAxisLocation(var23, false);
    org.jfree.chart.plot.CategoryMarker var26 = null;
    org.jfree.chart.util.Layer var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var26, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomDomainAxes(2.0d, 16.0d, var4, var5);
    java.lang.Object var7 = var0.clone();
    org.jfree.chart.plot.DrawingSupplier var8 = var0.getDrawingSupplier();
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxisForDataset(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1, false);
    java.awt.Paint var5 = var0.getSeriesFillPaint(10);
    boolean var8 = var0.isItemLabelVisible(0, (-16777215));
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var9.setBaseToolTipGenerator(var10);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    double var13 = var12.getUpperClip();
    java.awt.Stroke var14 = var12.getBaseStroke();
    org.jfree.chart.labels.ItemLabelPosition var17 = var12.getPositiveItemLabelPosition((-16777215), 10);
    org.jfree.chart.labels.ItemLabelAnchor var18 = var17.getItemLabelAnchor();
    var9.setBaseNegativeItemLabelPosition(var17);
    var0.setBaseNegativeItemLabelPosition(var17, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
//     java.lang.String var2 = var1.getToolTipText();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.draw(var3, var4);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.data.Range var2 = null;
    org.jfree.chart.block.RectangleConstraint var3 = new org.jfree.chart.block.RectangleConstraint(0.0d, var2);
    org.jfree.chart.block.RectangleConstraint var5 = var3.toFixedHeight(0.0d);
    boolean var6 = var0.equals((java.lang.Object)var3);
    java.lang.Object var7 = null;
    boolean var8 = var0.equals(var7);
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setLabelToolTip("");
    var0.setUpperMargin((-1.0d));
    org.jfree.chart.plot.Plot var5 = null;
    var0.setPlot(var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)'#');
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var10.setBaseURLGenerator(var11, false);
    java.awt.Paint var15 = var10.getSeriesFillPaint(10);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var19, "hi!", "");
    java.awt.Shape var23 = var22.getArea();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var25.setLeftArrow(var32);
    var22.setArea(var32);
    java.awt.Shape var35 = var22.getArea();
    var10.setBaseShape(var35, true);
    java.awt.Font var40 = var10.getItemLabelFont(100, 10);
    var0.setTickLabelFont((java.lang.Comparable)"NOID", var40);
    var0.setLowerMargin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.0d, 0.5d, (-1.0d), Double.NaN);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "");
    var5.addOptionalLibrary("hi!");
    var5.setName("0,0,2,-2,2,2,2,2");
    var5.setInfo("UnitType.ABSOLUTE");

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getUpperClip();
//     java.lang.Boolean var3 = null;
//     var0.setSeriesItemLabelsVisible(100, var3, true);
//     org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
//     org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
//     var0.setBasePaint((java.awt.Paint)var10, false);
//     double var13 = var0.getLowerClip();
//     java.awt.Stroke var15 = var0.getSeriesStroke(10);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var22);
//     boolean var24 = var19.equals((java.lang.Object)var23);
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.LegendItemSource var26 = null;
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle(var26);
//     boolean var28 = var27.getNotify();
//     java.awt.geom.Rectangle2D var29 = var27.getBounds();
//     var19.draw(var25, var29);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var29, 7.0d, 100.0f, 1.0f);
//     java.awt.geom.Point2D var35 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(7.0d, 1.0d, var29);
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var38 = var37.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     java.awt.geom.Point2D var42 = null;
//     var37.zoomDomainAxes(2.0d, 16.0d, var41, var42);
//     var36.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.util.RectangleEdge var49 = null;
//     double var50 = var46.lengthToJava2D((-1.0d), var48, var49);
//     var46.setAutoRange(false);
//     org.jfree.chart.util.Layer var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     var0.drawAnnotations(var16, var29, var36, (org.jfree.chart.axis.ValueAxis)var46, var53, var54);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    org.jfree.data.Range var6 = var1.getDefaultAutoRange();
    var1.resizeRange(1.0d);
    boolean var9 = var1.isTickLabelsVisible();
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    boolean var13 = var12.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var15.setLeftArrow(var22);
    var15.setRangeWithMargins(Double.NaN, 0.0d);
    var15.setTickLabelsVisible(true);
    int var29 = var12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var15);
    java.awt.Paint var30 = var12.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    double var32 = var31.getUpperClip();
    var12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    boolean var35 = var34.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.util.RectangleEdge var40 = null;
    double var41 = var37.lengthToJava2D((-1.0d), var39, var40);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var37.setLeftArrow(var44);
    var37.setRangeWithMargins(Double.NaN, 0.0d);
    var37.setTickLabelsVisible(true);
    int var51 = var34.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var37);
    java.awt.Paint var52 = var34.getRangeGridlinePaint();
    var12.setDomainGridlinePaint(var52);
    var12.setRangeCrosshairVisible(false);
    java.awt.Graphics2D var56 = null;
    org.jfree.chart.LegendItemSource var57 = null;
    org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle(var57);
    boolean var59 = var58.getNotify();
    java.awt.geom.Rectangle2D var60 = var58.getBounds();
    org.jfree.chart.plot.PlotRenderingInfo var62 = null;
    boolean var63 = var12.render(var56, var60, 0, var62);
    org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis();
    var64.setLabelToolTip("");
    var64.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var69 = null;
    var64.removeChangeListener(var69);
    org.jfree.chart.axis.CategoryLabelPositions var71 = var64.getCategoryLabelPositions();
    org.jfree.chart.LegendItemSource var72 = null;
    org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle(var72);
    boolean var74 = var73.getNotify();
    double var75 = var73.getWidth();
    org.jfree.chart.util.RectangleEdge var76 = var73.getLegendItemGraphicEdge();
    org.jfree.chart.axis.CategoryAxis var77 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var80 = null;
    org.jfree.chart.util.RectangleEdge var81 = null;
    double var82 = var77.getCategoryStart(10, (-16777215), var80, var81);
    java.awt.Font var84 = null;
    var77.setTickLabelFont((java.lang.Comparable)1, var84);
    java.lang.String var86 = var77.getLabel();
    org.jfree.chart.axis.CategoryAnchor var87 = null;
    java.awt.geom.Rectangle2D var90 = null;
    org.jfree.chart.LegendItemSource var91 = null;
    org.jfree.chart.title.LegendTitle var92 = new org.jfree.chart.title.LegendTitle(var91);
    boolean var93 = var92.getNotify();
    double var94 = var92.getWidth();
    org.jfree.chart.util.RectangleEdge var95 = var92.getLegendItemGraphicEdge();
    double var96 = var77.getCategoryJava2DCoordinate(var87, (-1), (-16777215), var90, var95);
    var73.setLegendItemGraphicEdge(var95);
    org.jfree.chart.axis.CategoryLabelPosition var98 = var71.getLabelPosition(var95);
    double var99 = var1.lengthToJava2D(2.0d, var60, var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 0.0d);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var2 = var0.getRangeLowerBound(false);
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
//     java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var8 = var0.getValue(15, 1);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(Double.NaN);
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.block.BlockContainer var4 = var3.getItemContainer();
//     var3.setNotify(false);
//     org.jfree.chart.util.RectangleInsets var7 = var3.getItemLabelPadding();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setLabelToolTip("");
//     var8.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var13 = null;
//     var8.removeChangeListener(var13);
//     org.jfree.chart.axis.CategoryLabelPositions var15 = var8.getCategoryLabelPositions();
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     boolean var18 = var17.getNotify();
//     double var19 = var17.getWidth();
//     org.jfree.chart.util.RectangleEdge var20 = var17.getLegendItemGraphicEdge();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var21.getCategoryStart(10, (-16777215), var24, var25);
//     java.awt.Font var28 = null;
//     var21.setTickLabelFont((java.lang.Comparable)1, var28);
//     java.lang.String var30 = var21.getLabel();
//     org.jfree.chart.axis.CategoryAnchor var31 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.LegendItemSource var35 = null;
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle(var35);
//     boolean var37 = var36.getNotify();
//     double var38 = var36.getWidth();
//     org.jfree.chart.util.RectangleEdge var39 = var36.getLegendItemGraphicEdge();
//     double var40 = var21.getCategoryJava2DCoordinate(var31, (-1), (-16777215), var34, var39);
//     var17.setLegendItemGraphicEdge(var39);
//     org.jfree.chart.axis.CategoryLabelPosition var42 = var15.getLabelPosition(var39);
//     var3.setLegendItemGraphicEdge(var39);
//     org.jfree.chart.axis.CategoryLabelPosition var44 = var1.getLabelPosition(var39);
//     org.jfree.chart.axis.CategoryLabelPositions var46 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(Double.NaN);
//     org.jfree.chart.LegendItemSource var47 = null;
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle(var47);
//     org.jfree.chart.block.BlockContainer var49 = var48.getItemContainer();
//     var48.setNotify(false);
//     org.jfree.chart.util.RectangleInsets var52 = var48.getItemLabelPadding();
//     org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis();
//     var53.setLabelToolTip("");
//     var53.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var58 = null;
//     var53.removeChangeListener(var58);
//     org.jfree.chart.axis.CategoryLabelPositions var60 = var53.getCategoryLabelPositions();
//     org.jfree.chart.LegendItemSource var61 = null;
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle(var61);
//     boolean var63 = var62.getNotify();
//     double var64 = var62.getWidth();
//     org.jfree.chart.util.RectangleEdge var65 = var62.getLegendItemGraphicEdge();
//     org.jfree.chart.axis.CategoryAxis var66 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var69 = null;
//     org.jfree.chart.util.RectangleEdge var70 = null;
//     double var71 = var66.getCategoryStart(10, (-16777215), var69, var70);
//     java.awt.Font var73 = null;
//     var66.setTickLabelFont((java.lang.Comparable)1, var73);
//     java.lang.String var75 = var66.getLabel();
//     org.jfree.chart.axis.CategoryAnchor var76 = null;
//     java.awt.geom.Rectangle2D var79 = null;
//     org.jfree.chart.LegendItemSource var80 = null;
//     org.jfree.chart.title.LegendTitle var81 = new org.jfree.chart.title.LegendTitle(var80);
//     boolean var82 = var81.getNotify();
//     double var83 = var81.getWidth();
//     org.jfree.chart.util.RectangleEdge var84 = var81.getLegendItemGraphicEdge();
//     double var85 = var66.getCategoryJava2DCoordinate(var76, (-1), (-16777215), var79, var84);
//     var62.setLegendItemGraphicEdge(var84);
//     org.jfree.chart.axis.CategoryLabelPosition var87 = var60.getLabelPosition(var84);
//     var48.setLegendItemGraphicEdge(var84);
//     org.jfree.chart.axis.CategoryLabelPosition var89 = var46.getLabelPosition(var84);
//     org.jfree.chart.axis.CategoryLabelPositions var90 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var89);
//     
//     // Checks the contract:  equals-hashcode on var4 and var49
//     assertTrue("Contract failed: equals-hashcode on var4 and var49", var4.equals(var49) ? var4.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var4
//     assertTrue("Contract failed: equals-hashcode on var49 and var4", var49.equals(var4) ? var49.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var2 = var0.getRangeLowerBound(false);
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
//     org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
//     java.util.EventListener var6 = null;
//     boolean var7 = var0.hasListener(var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var10 = var0.getValue(10, 15);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     double var2 = var0.getRangeCrosshairValue();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     java.awt.RenderingHints var4 = null;
//     var3.setRenderingHints(var4);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    java.awt.Paint var18 = var0.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getUpperClip();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    boolean var23 = var22.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var25.setLeftArrow(var32);
    var25.setRangeWithMargins(Double.NaN, 0.0d);
    var25.setTickLabelsVisible(true);
    int var39 = var22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var40 = var22.getRangeGridlinePaint();
    var0.setDomainGridlinePaint(var40);
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.annotations.CategoryAnnotation var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var45 = var0.removeAnnotation(var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var1.setLeftArrow(var8);
    var1.setRangeWithMargins(Double.NaN, 0.0d);
    var1.setTickLabelsVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var15.setBaseURLGenerator(var16, false);
    java.awt.Paint var20 = var15.getSeriesFillPaint(10);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var27 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var24, "hi!", "");
    java.awt.Shape var28 = var27.getArea();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.util.RectangleEdge var33 = null;
    double var34 = var30.lengthToJava2D((-1.0d), var32, var33);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var30.setLeftArrow(var37);
    var27.setArea(var37);
    java.awt.Shape var40 = var27.getArea();
    var15.setBaseShape(var40, true);
    java.awt.Font var45 = var15.getItemLabelFont(100, 10);
    var1.setLabelFont(var45);
    var1.setAutoRange(true);
    var1.setLowerBound(0.0d);
    java.lang.String var51 = var1.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("CategoryLabelEntity: category=, tooltip=hi!, url=");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var3 = var2.brighter();
    java.awt.Color var4 = var2.brighter();
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
    var6.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
    org.jfree.chart.event.TitleChangeListener var12 = null;
    var6.removeChangeListener(var12);
    java.awt.Color var16 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var16);
    var6.setItemPaint((java.awt.Paint)var16);
    java.awt.color.ColorSpace var19 = var16.getColorSpace();
    org.jfree.chart.LegendItemSource var20 = null;
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle(var20);
    org.jfree.chart.block.BlockContainer var22 = var21.getItemContainer();
    var21.setNotify(false);
    java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var28 = var27.brighter();
    java.awt.Color var29 = var27.brighter();
    var21.setItemPaint((java.awt.Paint)var27);
    java.awt.Color var33 = java.awt.Color.getColor("hi!", 1);
    float[] var37 = new float[] { 10.0f, 0.0f, 1.0f};
    float[] var38 = var33.getColorComponents(var37);
    float[] var39 = var27.getColorComponents(var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var40 = var4.getComponents(var19, var38);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "", "");
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var12 = null;
    var11.setBaseURLGenerator(var12, false);
    java.awt.Paint var16 = var11.getSeriesFillPaint(10);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var23 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var20, "hi!", "");
    java.awt.Shape var24 = var23.getArea();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var26.lengthToJava2D((-1.0d), var28, var29);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var26.setLeftArrow(var33);
    var23.setArea(var33);
    java.awt.Shape var36 = var23.getArea();
    var11.setBaseShape(var36, true);
    java.awt.Font var41 = var11.getItemLabelFont(100, 10);
    org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("hi!", var41);
    org.jfree.chart.LegendItemSource var43 = null;
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle(var43);
    org.jfree.chart.block.BlockContainer var45 = var44.getItemContainer();
    org.jfree.chart.util.RectangleInsets var46 = var44.getItemLabelPadding();
    java.lang.Object var47 = var44.clone();
    org.jfree.chart.util.RectangleAnchor var48 = var44.getLegendItemGraphicAnchor();
    boolean var49 = var42.equals((java.lang.Object)var48);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, var48, Double.NaN, 2.0d);
    org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity(var52);
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var60 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var57, "hi!", "");
    java.awt.Shape var61 = var60.getArea();
    org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var65 = null;
    org.jfree.chart.util.RectangleEdge var66 = null;
    double var67 = var63.lengthToJava2D((-1.0d), var65, var66);
    java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var63.setLeftArrow(var70);
    var60.setArea(var70);
    var53.setArea(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(7.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("AxisLocation.BOTTOM_OR_LEFT", var1);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    var6.setRange(2.0d, 7.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.data.KeyedObject var2 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)"0,0,2,-2,2,2,2,2");

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var6 = var5.getStroke();
//     java.awt.Stroke var7 = var5.getOutlineStroke();
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.block.BlockContainer var10 = var9.getItemContainer();
//     var9.setNotify(false);
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var16 = var15.brighter();
//     java.awt.Color var17 = var15.brighter();
//     var9.setItemPaint((java.awt.Paint)var15);
//     var5.setOutlinePaint((java.awt.Paint)var15);
//     java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var22);
//     float[] var27 = new float[] { (-1.0f), 10.0f, 1.0f};
//     float[] var28 = var22.getRGBColorComponents(var27);
//     float[] var29 = var15.getRGBColorComponents(var28);
//     float[] var30 = var2.getColorComponents(var28);
//     
//     // Checks the contract:  equals-hashcode on var3 and var23
//     assertTrue("Contract failed: equals-hashcode on var3 and var23", var3.equals(var23) ? var3.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var3
//     assertTrue("Contract failed: equals-hashcode on var23 and var3", var23.equals(var3) ? var23.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.Layer var1 = null;
    java.util.Collection var2 = var0.getDomainMarkers(var1);
    org.jfree.chart.axis.CategoryAxis var4 = var0.getDomainAxis((-16777215));
    org.jfree.chart.plot.PlotOrientation var5 = var0.getOrientation();
    double var6 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    boolean var9 = var8.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var8.zoomDomainAxes(2.0d, 16.0d, var12, var13);
    java.lang.Object var15 = var8.clone();
    org.jfree.chart.axis.AxisLocation var16 = var8.getDomainAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-16777215), var16, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.lang.Comparable var6 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var9.lengthToJava2D((-1.0d), var11, var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var9.setLeftArrow(var16);
//     var9.setRangeWithMargins(Double.NaN, 0.0d);
//     var9.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var24 = null;
//     var23.setBaseURLGenerator(var24, false);
//     java.awt.Paint var28 = var23.getSeriesFillPaint(10);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var35 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var32, "hi!", "");
//     java.awt.Shape var36 = var35.getArea();
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     double var42 = var38.lengthToJava2D((-1.0d), var40, var41);
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var38.setLeftArrow(var45);
//     var35.setArea(var45);
//     java.awt.Shape var48 = var35.getArea();
//     var23.setBaseShape(var48, true);
//     java.awt.Font var53 = var23.getItemLabelFont(100, 10);
//     var9.setLabelFont(var53);
//     java.awt.Color var57 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var58 = org.jfree.chart.text.TextUtilities.createTextBlock("", var53, (java.awt.Paint)var57);
//     java.awt.Graphics2D var59 = null;
//     org.jfree.chart.util.Size2D var60 = var58.calculateDimensions(var59);
//     org.jfree.chart.text.TextLine var61 = null;
//     var58.addLine(var61);
//     java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var69 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var66, "hi!", "");
//     java.awt.Shape var70 = var69.getArea();
//     boolean var71 = var58.equals((java.lang.Object)var69);
//     org.jfree.chart.text.TextBlockAnchor var72 = null;
//     org.jfree.chart.renderer.category.BarRenderer var73 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var74 = var73.getUpperClip();
//     var73.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var77 = var73.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var80 = var73.getPositiveItemLabelPosition(10, 100);
//     double var81 = var80.getAngle();
//     org.jfree.chart.text.TextAnchor var82 = var80.getTextAnchor();
//     org.jfree.chart.axis.CategoryTick var84 = new org.jfree.chart.axis.CategoryTick(var6, var58, var72, var82, 1.0d);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("NOID", var1, 100.0f, 10.0f, var4, 10.0d, var82);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Locale var1 = var0.getLocale();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.getString("RangeType.FULL");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    double var2 = var0.getRangeCrosshairValue();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    java.util.List var4 = var3.getSubtitles();
    org.jfree.chart.ChartRenderingInfo var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var10 = var3.createBufferedImage(100, 0, 0.2d, 8.0d, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    boolean var29 = var6.isAxisLineVisible();
    org.jfree.data.RangeType var30 = var6.getRangeType();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    double var38 = var34.lengthToJava2D((-1.0d), var36, var37);
    org.jfree.data.Range var39 = var34.getDefaultAutoRange();
    org.jfree.data.Range var41 = null;
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(0.0d, var41);
    org.jfree.chart.block.RectangleConstraint var44 = var42.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var46 = var44.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var50 = null;
    org.jfree.chart.util.RectangleEdge var51 = null;
    double var52 = var48.lengthToJava2D((-1.0d), var50, var51);
    org.jfree.data.Range var53 = var48.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var54 = var46.toRangeWidth(var53);
    org.jfree.data.Range var55 = org.jfree.data.Range.combine(var39, var53);
    var32.setRange(var39);
    var6.setRange(var39);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var59 = var58.clone();
    org.jfree.data.general.DatasetChangeListener var60 = null;
    var58.addChangeListener(var60);
    org.jfree.data.Range var62 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var58);
    org.jfree.data.general.DatasetChangeEvent var63 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var6, (org.jfree.data.general.Dataset)var58);
    org.jfree.data.general.DatasetGroup var65 = new org.jfree.data.general.DatasetGroup("hi!");
    java.lang.Object var66 = var65.clone();
    var58.setGroup(var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var70 = var58.getValue(1, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("AxisLocation.BOTTOM_OR_LEFT", var1);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.data.Range var2 = null;
    org.jfree.chart.block.RectangleConstraint var3 = new org.jfree.chart.block.RectangleConstraint(0.0d, var2);
    org.jfree.chart.block.RectangleConstraint var5 = var3.toFixedHeight(0.0d);
    boolean var6 = var0.equals((java.lang.Object)var3);
    org.jfree.data.Range var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var8 = var3.toRangeHeight(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemURLGenerator();
    var0.removeAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Enumeration var2 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var0.getString("UnitType.ABSOLUTE");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var2 = var0.getPaint(15);
    java.awt.Paint var4 = var0.getPaint(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
//     java.awt.Shape var7 = var6.getArea();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var9.lengthToJava2D((-1.0d), var11, var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var9.setLeftArrow(var16);
//     var6.setArea(var16);
//     java.awt.Shape var19 = var6.getArea();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var24 = var22.getRangeLowerBound(false);
//     org.jfree.data.Range var26 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var22, false);
//     org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var22);
//     java.util.EventListener var28 = null;
//     boolean var29 = var22.hasListener(var28);
//     org.jfree.data.Range var30 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var22);
//     org.jfree.chart.entity.CategoryItemEntity var33 = new org.jfree.chart.entity.CategoryItemEntity(var19, "poly", "UnitType.ABSOLUTE", (org.jfree.data.category.CategoryDataset)var22, (java.lang.Comparable)(short)0, (java.lang.Comparable)(short)0);
//     boolean var35 = var33.equals((java.lang.Object)10L);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var36 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Object var37 = var36.clone();
//     org.jfree.data.general.DatasetChangeListener var38 = null;
//     var36.addChangeListener(var38);
//     org.jfree.data.Range var40 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var36);
//     java.util.EventListener var41 = null;
//     boolean var42 = var36.hasListener(var41);
//     var33.setDataset((org.jfree.data.category.CategoryDataset)var36);
//     
//     // Checks the contract:  equals-hashcode on var22 and var36
//     assertTrue("Contract failed: equals-hashcode on var22 and var36", var22.equals(var36) ? var22.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var22
//     assertTrue("Contract failed: equals-hashcode on var36 and var22", var36.equals(var22) ? var36.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
//     var1.setNotify(false);
//     org.jfree.chart.util.RectangleEdge var5 = var1.getPosition();
//     org.jfree.chart.block.BlockContainer var6 = var1.getItemContainer();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.Size2D var8 = var1.arrange(var7);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-16777215));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var3 = var0.get(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
//     java.awt.Shape var7 = var6.getArea();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var9.lengthToJava2D((-1.0d), var11, var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var9.setLeftArrow(var16);
//     var6.setArea(var16);
//     java.awt.Shape var19 = var6.getArea();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var24 = var22.getRangeLowerBound(false);
//     org.jfree.data.Range var26 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var22, false);
//     org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var22);
//     java.util.EventListener var28 = null;
//     boolean var29 = var22.hasListener(var28);
//     org.jfree.data.Range var30 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var22);
//     org.jfree.chart.entity.CategoryItemEntity var33 = new org.jfree.chart.entity.CategoryItemEntity(var19, "poly", "UnitType.ABSOLUTE", (org.jfree.data.category.CategoryDataset)var22, (java.lang.Comparable)(short)0, (java.lang.Comparable)(short)0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var36 = var22.getStdDevValue((-1), 10);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     double var2 = var0.getRangeCrosshairValue();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.ChartColor var7 = new org.jfree.chart.ChartColor(100, 0, 10);
//     int var8 = var7.getAlpha();
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
//     var9.setBaseToolTipGenerator(var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var20 = var15.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
//     org.jfree.data.Range var22 = var15.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var24.lengthToJava2D((-1.0d), var26, var27);
//     java.awt.Shape var29 = var24.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var30 = var24.getMarkerBand();
//     org.jfree.data.Range var31 = var24.getDefaultAutoRange();
//     var15.setDefaultAutoRange(var31);
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var35 = var34.getStroke();
//     java.awt.geom.Rectangle2D var36 = null;
//     var9.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.plot.Marker)var34, var36);
//     java.awt.Stroke var38 = var9.getBaseStroke();
//     org.jfree.chart.block.CenterArrangement var39 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var40 = null;
//     boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var39, var40);
//     org.jfree.chart.block.BlockContainer var42 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var39);
//     var42.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var48 = var42.getPadding();
//     org.jfree.chart.block.Arrangement var49 = var42.getArrangement();
//     org.jfree.chart.util.RectangleInsets var50 = var42.getPadding();
//     org.jfree.chart.block.LineBorder var51 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var7, var38, var50);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     double var57 = var53.lengthToJava2D((-1.0d), var55, var56);
//     java.awt.Shape var58 = var53.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var59 = var53.getMarkerBand();
//     var53.setRange(0.0d, 1.0d);
//     java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var69 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var66, "hi!", "");
//     java.awt.Shape var70 = var69.getArea();
//     var53.setDownArrow(var70);
//     boolean var72 = var50.equals((java.lang.Object)var70);
//     org.jfree.chart.LegendItemSource var73 = null;
//     org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
//     boolean var75 = var74.getNotify();
//     java.awt.geom.Rectangle2D var76 = var74.getBounds();
//     java.awt.geom.Rectangle2D var77 = var50.createOutsetRectangle(var76);
//     var3.setPadding(var50);
//     org.jfree.chart.event.PlotChangeEvent var79 = null;
//     var3.plotChanged(var79);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(0.05d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    var1.setAutoRangeMinimumSize(100.0d);
    var1.configure();
    var1.setVisible(true);
    var1.setFixedAutoRange(100.0d);
    var1.setLabel("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0");
    var1.setLabel("CategoryLabelEntity: category=, tooltip=hi!, url=");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getURLGenerator(0, 100);
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPosition(0, (-1));
//     var0.setBaseCreateEntities(true);
//     java.awt.Paint var9 = var0.getErrorIndicatorPaint();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var12 = var11.isDomainGridlinesVisible();
//     var11.clearRangeMarkers(10);
//     boolean var15 = var11.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     var16.setLabelToolTip("");
//     var16.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var21 = null;
//     var16.removeChangeListener(var21);
//     org.jfree.chart.axis.CategoryLabelPositions var23 = var16.getCategoryLabelPositions();
//     org.jfree.chart.axis.CategoryAxis[] var24 = new org.jfree.chart.axis.CategoryAxis[] { var16};
//     var11.setDomainAxes(var24);
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.Layer var28 = null;
//     var11.addRangeMarker((org.jfree.chart.plot.Marker)var27, var28);
//     org.jfree.chart.util.RectangleInsets var30 = var11.getInsets();
//     var11.setForegroundAlpha((-1.0f));
//     org.jfree.chart.axis.AxisLocation var34 = var11.getRangeAxisLocation((-1));
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var36.getCategoryStart(10, (-16777215), var39, var40);
//     java.awt.Font var43 = null;
//     var36.setTickLabelFont((java.lang.Comparable)1, var43);
//     var11.setDomainAxis(0, var36);
//     org.jfree.chart.LegendItemSource var46 = null;
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle(var46);
//     boolean var48 = var47.getNotify();
//     double var49 = var47.getWidth();
//     org.jfree.chart.util.RectangleEdge var50 = var47.getLegendItemGraphicEdge();
//     boolean var51 = var47.getNotify();
//     java.awt.geom.Rectangle2D var52 = var47.getBounds();
//     var0.drawDomainGridline(var10, var11, var52, (-1.0d));
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setLabelToolTip("");
//     org.jfree.chart.axis.CategoryAnchor var4 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var1.getCategoryJava2DCoordinate(var4, 0, 0, var7, var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.axis.AxisState var11 = new org.jfree.chart.axis.AxisState();
//     var11.setCursor(0.0d);
//     java.util.List var14 = var11.getTicks();
//     var11.setCursor(0.0d);
//     var11.setCursor((-1.0d));
//     var11.cursorLeft(16.0d);
//     org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var24);
//     boolean var26 = var21.equals((java.lang.Object)var25);
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.LegendItemSource var28 = null;
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var28);
//     boolean var30 = var29.getNotify();
//     java.awt.geom.Rectangle2D var31 = var29.getBounds();
//     var21.draw(var27, var31);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var31, 7.0d, 100.0f, 1.0f);
//     org.jfree.chart.LegendItemSource var37 = null;
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
//     org.jfree.chart.block.BlockContainer var39 = var38.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var40 = var38.getItemLabelPadding();
//     java.lang.Object var41 = var38.clone();
//     org.jfree.chart.util.RectangleEdge var42 = var38.getPosition();
//     java.util.List var43 = var1.refreshTicks(var10, var11, var31, var42);
//     org.jfree.chart.block.LineBorder var46 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var49 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var50 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var49);
//     boolean var51 = var46.equals((java.lang.Object)var50);
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.LegendItemSource var53 = null;
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var53);
//     boolean var55 = var54.getNotify();
//     java.awt.geom.Rectangle2D var56 = var54.getBounds();
//     var46.draw(var52, var56);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var56, 7.0d, 100.0f, 1.0f);
//     java.awt.geom.Point2D var62 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(7.0d, 1.0d, var56);
//     java.awt.geom.Rectangle2D var63 = var0.shrink(var31, var56);
//     
//     // Checks the contract:  equals-hashcode on var21 and var46
//     assertTrue("Contract failed: equals-hashcode on var21 and var46", var21.equals(var46) ? var21.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var21
//     assertTrue("Contract failed: equals-hashcode on var46 and var21", var46.equals(var21) ? var46.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var50
//     assertTrue("Contract failed: equals-hashcode on var25 and var50", var25.equals(var50) ? var25.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var25
//     assertTrue("Contract failed: equals-hashcode on var50 and var25", var50.equals(var25) ? var50.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var7 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var4, "hi!", "");
    java.awt.Shape var8 = var7.getArea();
    boolean var9 = var0.equals((java.lang.Object)var8);
    int var11 = var0.getIndex((java.lang.Comparable)(byte)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var17 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var17);
    org.jfree.chart.util.RectangleInsets var19 = var0.getInsets();
    double var21 = var19.extendWidth(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 26.0d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var3 = var0.get(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var7 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var4, "hi!", "");
    java.awt.Shape var8 = var7.getArea();
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.lang.Object var11 = var0.getObject((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = null;
//     var1.setBaseURLGenerator(var2, false);
//     java.awt.Paint var6 = var1.getSeriesFillPaint(10);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var10, "hi!", "");
//     java.awt.Shape var14 = var13.getArea();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var16.lengthToJava2D((-1.0d), var18, var19);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var16.setLeftArrow(var23);
//     var13.setArea(var23);
//     java.awt.Shape var26 = var13.getArea();
//     var1.setBaseShape(var26, true);
//     java.awt.Font var31 = var1.getItemLabelFont(100, 10);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("hi!", var31);
//     org.jfree.chart.LegendItemSource var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
//     org.jfree.chart.block.BlockContainer var35 = var34.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var36 = var34.getItemLabelPadding();
//     java.lang.Object var37 = var34.clone();
//     org.jfree.chart.util.RectangleAnchor var38 = var34.getLegendItemGraphicAnchor();
//     boolean var39 = var32.equals((java.lang.Object)var38);
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var44 = var43.getUpperClip();
//     var43.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var47 = var43.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var50 = var43.getPositiveItemLabelPosition(10, 100);
//     double var51 = var50.getAngle();
//     org.jfree.chart.text.TextAnchor var52 = var50.getTextAnchor();
//     var32.draw(var40, 1.0f, 0.5f, var52, (-1.0f), 0.5f, 0.0d);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateY(0.0d);
    boolean var3 = var0.getGenerateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    org.jfree.data.Range var6 = var1.getDefaultAutoRange();
    var1.resizeRange(1.0d);
    boolean var9 = var1.isTickLabelsVisible();
    boolean var10 = var1.isInverted();
    boolean var11 = var1.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.JFreeChart var2 = null;
    org.jfree.chart.event.ChartProgressEvent var5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)100.0d, var2, 100, (-1));
    int var6 = var5.getPercent();
    org.jfree.chart.JFreeChart var7 = var5.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var2.setLeftArrow(var9);
    var2.setRangeWithMargins(Double.NaN, 0.0d);
    var2.setTickLabelsVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var16.setBaseURLGenerator(var17, false);
    java.awt.Paint var21 = var16.getSeriesFillPaint(10);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var25, "hi!", "");
    java.awt.Shape var29 = var28.getArea();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var31.setLeftArrow(var38);
    var28.setArea(var38);
    java.awt.Shape var41 = var28.getArea();
    var16.setBaseShape(var41, true);
    java.awt.Font var46 = var16.getItemLabelFont(100, 10);
    var2.setLabelFont(var46);
    java.awt.Paint var48 = null;
    org.jfree.chart.text.TextMeasurer var51 = null;
    org.jfree.chart.text.TextBlock var52 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, var48, (-1.0f), 0, var51);
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.util.RectangleEdge var57 = null;
    double var58 = var54.lengthToJava2D((-1.0d), var56, var57);
    org.jfree.data.Range var59 = var54.getDefaultAutoRange();
    var54.resizeRange(1.0d);
    java.awt.Stroke var62 = var54.getAxisLineStroke();
    var54.setAutoTickUnitSelection(true, true);
    var54.setAutoTickUnitSelection(false, false);
    var54.setLabel("NOID");
    boolean var71 = var52.equals((java.lang.Object)"NOID");
    java.awt.Graphics2D var72 = null;
    org.jfree.chart.util.Size2D var73 = var52.calculateDimensions(var72);
    var73.setWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    double var2 = var0.getRangeCrosshairValue();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.ChartColor var7 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var8 = var7.getAlpha();
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var9.setBaseToolTipGenerator(var10);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var24.lengthToJava2D((-1.0d), var26, var27);
    java.awt.Shape var29 = var24.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var30 = var24.getMarkerBand();
    org.jfree.data.Range var31 = var24.getDefaultAutoRange();
    var15.setDefaultAutoRange(var31);
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var35 = var34.getStroke();
    java.awt.geom.Rectangle2D var36 = null;
    var9.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.plot.Marker)var34, var36);
    java.awt.Stroke var38 = var9.getBaseStroke();
    org.jfree.chart.block.CenterArrangement var39 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var40 = null;
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var39, var40);
    org.jfree.chart.block.BlockContainer var42 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var39);
    var42.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var48 = var42.getPadding();
    org.jfree.chart.block.Arrangement var49 = var42.getArrangement();
    org.jfree.chart.util.RectangleInsets var50 = var42.getPadding();
    org.jfree.chart.block.LineBorder var51 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var7, var38, var50);
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.util.RectangleEdge var56 = null;
    double var57 = var53.lengthToJava2D((-1.0d), var55, var56);
    java.awt.Shape var58 = var53.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var59 = var53.getMarkerBand();
    var53.setRange(0.0d, 1.0d);
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var69 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var66, "hi!", "");
    java.awt.Shape var70 = var69.getArea();
    var53.setDownArrow(var70);
    boolean var72 = var50.equals((java.lang.Object)var70);
    org.jfree.chart.LegendItemSource var73 = null;
    org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
    boolean var75 = var74.getNotify();
    java.awt.geom.Rectangle2D var76 = var74.getBounds();
    java.awt.geom.Rectangle2D var77 = var50.createOutsetRectangle(var76);
    var3.setPadding(var50);
    org.jfree.chart.ChartRenderingInfo var83 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var84 = var3.createBufferedImage(0, 0, 100.0d, 0.2d, var83);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.lang.Boolean var3 = null;
    var0.setSeriesItemLabelsVisible(100, var3, true);
    org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
    var0.setBasePaint((java.awt.Paint)var10, false);
    java.awt.Paint var15 = var0.getItemPaint(0, (-16777215));
    var0.setBaseSeriesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     double var2 = var0.getRangeCrosshairValue();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     java.util.List var4 = var3.getSubtitles();
//     boolean var5 = var3.isNotify();
//     java.awt.RenderingHints var6 = null;
//     var3.setRenderingHints(var6);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    var1.setFixedDimension(10.0d);
    java.awt.Paint var8 = var1.getLabelPaint();
    var1.setUpperBound(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseSeriesVisible();
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var7 = var6.brighter();
    var0.setSeriesItemLabelPaint(0, (java.awt.Paint)var6, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-16777215), var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var17 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var17);
    org.jfree.chart.event.MarkerChangeEvent var19 = null;
    var16.notifyListeners(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"+ "'", var1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseSeriesVisible();
    boolean var3 = var0.getAutoPopulateSeriesShape();
    var0.setItemLabelAnchorOffset(0.0d);
    var0.setMaximumBarWidth(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var3 = var2.getUpperClip();
//     var2.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var6 = var2.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var2.getPositiveItemLabelPosition(10, 100);
//     double var10 = var9.getAngle();
//     org.jfree.chart.text.TextAnchor var11 = var9.getTextAnchor();
//     java.lang.Comparable var12 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var15.setLeftArrow(var22);
//     var15.setRangeWithMargins(Double.NaN, 0.0d);
//     var15.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var30 = null;
//     var29.setBaseURLGenerator(var30, false);
//     java.awt.Paint var34 = var29.getSeriesFillPaint(10);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var41 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var38, "hi!", "");
//     java.awt.Shape var42 = var41.getArea();
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.util.RectangleEdge var47 = null;
//     double var48 = var44.lengthToJava2D((-1.0d), var46, var47);
//     java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var44.setLeftArrow(var51);
//     var41.setArea(var51);
//     java.awt.Shape var54 = var41.getArea();
//     var29.setBaseShape(var54, true);
//     java.awt.Font var59 = var29.getItemLabelFont(100, 10);
//     var15.setLabelFont(var59);
//     java.awt.Color var63 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var64 = org.jfree.chart.text.TextUtilities.createTextBlock("", var59, (java.awt.Paint)var63);
//     java.awt.Graphics2D var65 = null;
//     org.jfree.chart.util.Size2D var66 = var64.calculateDimensions(var65);
//     org.jfree.chart.text.TextLine var67 = null;
//     var64.addLine(var67);
//     java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var75 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var72, "hi!", "");
//     java.awt.Shape var76 = var75.getArea();
//     boolean var77 = var64.equals((java.lang.Object)var75);
//     org.jfree.chart.text.TextBlockAnchor var78 = null;
//     org.jfree.chart.renderer.category.BarRenderer var79 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var80 = var79.getUpperClip();
//     var79.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var83 = var79.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var86 = var79.getPositiveItemLabelPosition(10, 100);
//     double var87 = var86.getAngle();
//     org.jfree.chart.text.TextAnchor var88 = var86.getTextAnchor();
//     org.jfree.chart.axis.CategoryTick var90 = new org.jfree.chart.axis.CategoryTick(var12, var64, var78, var88, 1.0d);
//     java.lang.Comparable var91 = var90.getCategory();
//     org.jfree.chart.text.TextAnchor var92 = var90.getTextAnchor();
//     org.jfree.chart.axis.NumberTick var94 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)0, "RectangleAnchor.CENTER", var11, var92, 0.5d);
//     
//     // Checks the contract:  equals-hashcode on var9 and var86
//     assertTrue("Contract failed: equals-hashcode on var9 and var86", var9.equals(var86) ? var9.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var9
//     assertTrue("Contract failed: equals-hashcode on var86 and var9", var86.equals(var9) ? var86.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
//     org.jfree.data.Range var7 = var2.getDefaultAutoRange();
//     var2.resizeRange(1.0d);
//     boolean var10 = var2.isTickLabelsVisible();
//     boolean var11 = var2.isInverted();
//     java.awt.Shape var12 = var2.getDownArrow();
//     org.jfree.chart.entity.LegendItemEntity var13 = new org.jfree.chart.entity.LegendItemEntity(var12);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var18 = var16.getRangeLowerBound(false);
//     org.jfree.data.Range var20 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var16, false);
//     java.lang.Number var21 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var16);
//     org.jfree.chart.entity.CategoryItemEntity var24 = new org.jfree.chart.entity.CategoryItemEntity(var12, "", "RangeType.FULL", (org.jfree.data.category.CategoryDataset)var16, (java.lang.Comparable)"RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", (java.lang.Comparable)0.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var12, 1.0d, 0.0f, 100.0f);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var17 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var17);
    org.jfree.chart.util.RectangleInsets var19 = var0.getInsets();
    var0.setForegroundAlpha((-1.0f));
    org.jfree.chart.axis.AxisLocation var23 = var0.getRangeAxisLocation((-1));
    org.jfree.chart.util.Layer var24 = null;
    java.util.Collection var25 = var0.getRangeMarkers(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var2.setLeftArrow(var9);
//     var2.setRangeWithMargins(Double.NaN, 0.0d);
//     var2.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var16.setBaseURLGenerator(var17, false);
//     java.awt.Paint var21 = var16.getSeriesFillPaint(10);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var25, "hi!", "");
//     java.awt.Shape var29 = var28.getArea();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var31.setLeftArrow(var38);
//     var28.setArea(var38);
//     java.awt.Shape var41 = var28.getArea();
//     var16.setBaseShape(var41, true);
//     java.awt.Font var46 = var16.getItemLabelFont(100, 10);
//     var2.setLabelFont(var46);
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, (java.awt.Paint)var50);
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.util.Size2D var53 = var51.calculateDimensions(var52);
//     org.jfree.chart.text.TextLine var54 = null;
//     var51.addLine(var54);
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var62 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var59, "hi!", "");
//     java.awt.Shape var63 = var62.getArea();
//     boolean var64 = var51.equals((java.lang.Object)var62);
//     java.awt.Graphics2D var65 = null;
//     org.jfree.chart.text.TextBlockAnchor var68 = null;
//     var51.draw(var65, 0.0f, 0.0f, var68);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var3);
//     boolean var5 = var0.equals((java.lang.Object)var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
//     int var11 = var10.getAlpha();
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var13 = null;
//     var12.setBaseToolTipGenerator(var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = null;
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var18.lengthToJava2D((-1.0d), var20, var21);
//     java.awt.Shape var23 = var18.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var24 = var18.getMarkerBand();
//     org.jfree.data.Range var25 = var18.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var27.lengthToJava2D((-1.0d), var29, var30);
//     java.awt.Shape var32 = var27.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var33 = var27.getMarkerBand();
//     org.jfree.data.Range var34 = var27.getDefaultAutoRange();
//     var18.setDefaultAutoRange(var34);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var38 = var37.getStroke();
//     java.awt.geom.Rectangle2D var39 = null;
//     var12.drawRangeMarker(var15, var16, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.plot.Marker)var37, var39);
//     java.awt.Stroke var41 = var12.getBaseStroke();
//     org.jfree.chart.block.CenterArrangement var42 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var43 = null;
//     boolean var44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, var43);
//     org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var42);
//     var45.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var51 = var45.getPadding();
//     org.jfree.chart.block.Arrangement var52 = var45.getArrangement();
//     org.jfree.chart.util.RectangleInsets var53 = var45.getPadding();
//     org.jfree.chart.block.LineBorder var54 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var10, var41, var53);
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var58 = null;
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = var56.lengthToJava2D((-1.0d), var58, var59);
//     java.awt.Shape var61 = var56.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var62 = var56.getMarkerBand();
//     var56.setRange(0.0d, 1.0d);
//     java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var72 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var69, "hi!", "");
//     java.awt.Shape var73 = var72.getArea();
//     var56.setDownArrow(var73);
//     boolean var75 = var53.equals((java.lang.Object)var73);
//     org.jfree.chart.LegendItemSource var76 = null;
//     org.jfree.chart.title.LegendTitle var77 = new org.jfree.chart.title.LegendTitle(var76);
//     boolean var78 = var77.getNotify();
//     java.awt.geom.Rectangle2D var79 = var77.getBounds();
//     java.awt.geom.Rectangle2D var80 = var53.createOutsetRectangle(var79);
//     org.jfree.chart.block.LineBorder var81 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var84 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var85 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var84);
//     boolean var86 = var81.equals((java.lang.Object)var85);
//     java.awt.Graphics2D var87 = null;
//     org.jfree.chart.LegendItemSource var88 = null;
//     org.jfree.chart.title.LegendTitle var89 = new org.jfree.chart.title.LegendTitle(var88);
//     boolean var90 = var89.getNotify();
//     java.awt.geom.Rectangle2D var91 = var89.getBounds();
//     var81.draw(var87, var91);
//     java.awt.Shape var96 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var91, 7.0d, 100.0f, 1.0f);
//     boolean var97 = org.jfree.chart.util.ShapeUtilities.intersects(var80, var91);
//     var0.draw(var6, var80);
//     
//     // Checks the contract:  equals-hashcode on var0 and var81
//     assertTrue("Contract failed: equals-hashcode on var0 and var81", var0.equals(var81) ? var0.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var0
//     assertTrue("Contract failed: equals-hashcode on var81 and var0", var81.equals(var0) ? var81.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var85
//     assertTrue("Contract failed: equals-hashcode on var4 and var85", var4.equals(var85) ? var4.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var4
//     assertTrue("Contract failed: equals-hashcode on var85 and var4", var85.equals(var4) ? var85.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
//     org.jfree.data.Range var6 = var1.getDefaultAutoRange();
//     var1.resizeRange(1.0d);
//     boolean var9 = var1.isTickLabelsVisible();
//     boolean var10 = var1.isInverted();
//     java.awt.Shape var11 = var1.getDownArrow();
//     org.jfree.chart.entity.LegendItemEntity var12 = new org.jfree.chart.entity.LegendItemEntity(var11);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var17 = var15.getRangeLowerBound(false);
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var15, false);
//     java.lang.Number var20 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var15);
//     org.jfree.chart.entity.CategoryItemEntity var23 = new org.jfree.chart.entity.CategoryItemEntity(var11, "", "RangeType.FULL", (org.jfree.data.category.CategoryDataset)var15, (java.lang.Comparable)"RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", (java.lang.Comparable)0.0d);
//     org.jfree.data.general.PieDataset var25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var15, (-16777215));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + Double.NaN+ "'", var20.equals(Double.NaN));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "", "");
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var12 = null;
    var11.setBaseURLGenerator(var12, false);
    java.awt.Paint var16 = var11.getSeriesFillPaint(10);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var23 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var20, "hi!", "");
    java.awt.Shape var24 = var23.getArea();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var26.lengthToJava2D((-1.0d), var28, var29);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var26.setLeftArrow(var33);
    var23.setArea(var33);
    java.awt.Shape var36 = var23.getArea();
    var11.setBaseShape(var36, true);
    java.awt.Font var41 = var11.getItemLabelFont(100, 10);
    org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("hi!", var41);
    org.jfree.chart.LegendItemSource var43 = null;
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle(var43);
    org.jfree.chart.block.BlockContainer var45 = var44.getItemContainer();
    org.jfree.chart.util.RectangleInsets var46 = var44.getItemLabelPadding();
    java.lang.Object var47 = var44.clone();
    org.jfree.chart.util.RectangleAnchor var48 = var44.getLegendItemGraphicAnchor();
    boolean var49 = var42.equals((java.lang.Object)var48);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, var48, Double.NaN, 2.0d);
    org.jfree.chart.text.TextBlockAnchor var53 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var56 = new org.jfree.chart.axis.CategoryLabelPosition(var48, var53, var54, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("0,0,2,-2,2,2,2,2");
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var3 = var2.clone();
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var2, true);
    java.lang.Number var6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var8 = var1.generateLabel((org.jfree.data.category.CategoryDataset)var2, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + Double.NaN+ "'", var6.equals(Double.NaN));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.getInfo();
    var0.setLicenceName("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var1 = null;
//     boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var1);
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     var3.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var9 = var3.getPadding();
//     org.jfree.chart.util.RectangleInsets var10 = var3.getMargin();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.block.RectangleConstraint var12 = null;
//     org.jfree.chart.util.Size2D var13 = var3.arrange(var11, var12);
// 
//   }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.plot.PlotRenderingInfo var0 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
//     org.jfree.chart.entity.EntityCollection var2 = var1.getEntityCollection();
//     double var3 = var1.getBarWidth();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var5 = var4.isDomainGridlinesVisible();
//     double var6 = var4.getRangeCrosshairValue();
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.util.List var8 = var7.getSubtitles();
//     boolean var9 = var7.isNotify();
//     var7.setBackgroundImageAlignment(10);
//     org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var7);
//     org.jfree.chart.resources.JFreeChartResources var13 = new org.jfree.chart.resources.JFreeChartResources();
//     java.util.Locale var14 = var13.getLocale();
//     java.util.Enumeration var15 = var13.getKeys();
//     java.util.Enumeration var16 = var13.getKeys();
//     boolean var17 = var7.equals((java.lang.Object)var16);
//     java.awt.RenderingHints var18 = null;
//     var7.setRenderingHints(var18);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("NOID");
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var3 = var2.clone();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var2.addChangeListener(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var1.generateLabel((org.jfree.data.category.CategoryDataset)var2, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var0.addChangeListener(var2);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var6 = var0.getRowKey(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]");
//     java.awt.Graphics2D var2 = null;
//     java.lang.Comparable var3 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var6.setLeftArrow(var13);
//     var6.setRangeWithMargins(Double.NaN, 0.0d);
//     var6.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var21 = null;
//     var20.setBaseURLGenerator(var21, false);
//     java.awt.Paint var25 = var20.getSeriesFillPaint(10);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var32 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var29, "hi!", "");
//     java.awt.Shape var33 = var32.getArea();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var35.lengthToJava2D((-1.0d), var37, var38);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var35.setLeftArrow(var42);
//     var32.setArea(var42);
//     java.awt.Shape var45 = var32.getArea();
//     var20.setBaseShape(var45, true);
//     java.awt.Font var50 = var20.getItemLabelFont(100, 10);
//     var6.setLabelFont(var50);
//     java.awt.Color var54 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var55 = org.jfree.chart.text.TextUtilities.createTextBlock("", var50, (java.awt.Paint)var54);
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.util.Size2D var57 = var55.calculateDimensions(var56);
//     org.jfree.chart.text.TextLine var58 = null;
//     var55.addLine(var58);
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var66 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var63, "hi!", "");
//     java.awt.Shape var67 = var66.getArea();
//     boolean var68 = var55.equals((java.lang.Object)var66);
//     org.jfree.chart.text.TextBlockAnchor var69 = null;
//     org.jfree.chart.renderer.category.BarRenderer var70 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var71 = var70.getUpperClip();
//     var70.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var74 = var70.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var77 = var70.getPositiveItemLabelPosition(10, 100);
//     double var78 = var77.getAngle();
//     org.jfree.chart.text.TextAnchor var79 = var77.getTextAnchor();
//     org.jfree.chart.axis.CategoryTick var81 = new org.jfree.chart.axis.CategoryTick(var3, var55, var69, var79, 1.0d);
//     float var82 = var1.calculateBaselineOffset(var2, var79);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    java.awt.Paint var2 = var0.getBackgroundPaint();
    org.jfree.chart.plot.CategoryMarker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(10, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomDomainAxes(2.0d, 16.0d, var4, var5);
//     java.awt.Paint var7 = var0.getNoDataMessagePaint();
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var10 = var9.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.annotations.CategoryAnnotation var11 = null;
//     boolean var12 = var9.removeAnnotation(var11);
//     java.awt.Stroke var14 = var9.lookupSeriesStroke((-1));
//     boolean var15 = var8.equals((java.lang.Object)var9);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Shape var18 = var17.getDownArrow();
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, Double.NaN, 1.0f, 100.0f);
//     boolean var23 = var8.equals((java.lang.Object)Double.NaN);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var25 = var24.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     java.awt.geom.Point2D var29 = null;
//     var24.zoomDomainAxes(2.0d, 16.0d, var28, var29);
//     java.lang.Object var31 = var24.clone();
//     org.jfree.chart.axis.AxisLocation var32 = var24.getRangeAxisLocation();
//     boolean var33 = var8.equals((java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var0 and var24
//     assertTrue("Contract failed: equals-hashcode on var0 and var24", var0.equals(var24) ? var0.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var0
//     assertTrue("Contract failed: equals-hashcode on var24 and var0", var24.equals(var0) ? var24.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1, false);
    org.jfree.chart.plot.DrawingSupplier var4 = var0.getDrawingSupplier();
    boolean var6 = var0.isSeriesItemLabelsVisible(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-16777215), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var3.setLeftArrow(var10);
//     var3.setRangeWithMargins(Double.NaN, 0.0d);
//     var3.setTickLabelsVisible(true);
//     int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
//     var0.zoom(0.05d);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    var1.setURLText("CategoryLabelEntity: category=, tooltip=hi!, url=");
    java.awt.Font var4 = var1.getFont();
    org.jfree.chart.util.RectangleInsets var5 = var1.getMargin();
    double var6 = var5.getLeft();
    java.lang.String var7 = var5.toString();
    double var8 = var5.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"+ "'", var7.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var2 = var1.getStroke();
//     java.awt.Paint var3 = var1.getLabelPaint();
//     java.awt.Font var4 = var1.getLabelFont();
//     double var5 = var1.getValue();
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
//     var6.setBaseToolTipGenerator(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var12.lengthToJava2D((-1.0d), var14, var15);
//     java.awt.Shape var17 = var12.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var18 = var12.getMarkerBand();
//     org.jfree.data.Range var19 = var12.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var21.lengthToJava2D((-1.0d), var23, var24);
//     java.awt.Shape var26 = var21.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var27 = var21.getMarkerBand();
//     org.jfree.data.Range var28 = var21.getDefaultAutoRange();
//     var12.setDefaultAutoRange(var28);
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var32 = var31.getStroke();
//     java.awt.geom.Rectangle2D var33 = null;
//     var6.drawRangeMarker(var9, var10, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.plot.Marker)var31, var33);
//     java.awt.Paint var35 = var31.getOutlinePaint();
//     org.jfree.chart.util.LengthAdjustmentType var36 = var31.getLabelOffsetType();
//     var1.setLabelOffsetType(var36);
//     
//     // Checks the contract:  equals-hashcode on var1 and var31
//     assertTrue("Contract failed: equals-hashcode on var1 and var31", var1.equals(var31) ? var1.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var1
//     assertTrue("Contract failed: equals-hashcode on var31 and var1", var31.equals(var1) ? var31.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    java.awt.Paint var1 = null;
    org.jfree.data.general.DatasetGroup var2 = new org.jfree.data.general.DatasetGroup();
    java.lang.String var3 = var2.getID();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.RectangleEdge var8 = null;
    double var9 = var5.lengthToJava2D((-1.0d), var7, var8);
    var5.setAutoRange(false);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    double var13 = var12.getUpperClip();
    java.awt.Stroke var14 = var12.getBaseStroke();
    var5.setTickMarkStroke(var14);
    boolean var16 = var2.equals((java.lang.Object)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(0.05d, var1, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "NOID"+ "'", var3.equals("NOID"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
    org.jfree.chart.block.CenterArrangement var7 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var8 = null;
    boolean var9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, var8);
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var7);
    boolean var11 = var6.equals((java.lang.Object)var10);
    java.lang.String var12 = var6.toString();
    var6.setToolTipText("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "CategoryLabelEntity: category=, tooltip=hi!, url="+ "'", var12.equals("CategoryLabelEntity: category=, tooltip=hi!, url="));

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var1 = null;
//     boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var1);
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     var3.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var9 = var3.getPadding();
//     org.jfree.chart.block.Arrangement var10 = var3.getArrangement();
//     org.jfree.chart.ChartColor var14 = new org.jfree.chart.ChartColor(100, 0, 10);
//     int var15 = var14.getAlpha();
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var17 = null;
//     var16.setBaseToolTipGenerator(var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var22.lengthToJava2D((-1.0d), var24, var25);
//     java.awt.Shape var27 = var22.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var28 = var22.getMarkerBand();
//     org.jfree.data.Range var29 = var22.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
//     java.awt.Shape var36 = var31.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var37 = var31.getMarkerBand();
//     org.jfree.data.Range var38 = var31.getDefaultAutoRange();
//     var22.setDefaultAutoRange(var38);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var42 = var41.getStroke();
//     java.awt.geom.Rectangle2D var43 = null;
//     var16.drawRangeMarker(var19, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.plot.Marker)var41, var43);
//     java.awt.Stroke var45 = var16.getBaseStroke();
//     org.jfree.chart.block.CenterArrangement var46 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var47 = null;
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var46, var47);
//     org.jfree.chart.block.BlockContainer var49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var46);
//     var49.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var55 = var49.getPadding();
//     org.jfree.chart.block.Arrangement var56 = var49.getArrangement();
//     org.jfree.chart.util.RectangleInsets var57 = var49.getPadding();
//     org.jfree.chart.block.LineBorder var58 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var14, var45, var57);
//     double var60 = var57.extendWidth(Double.NaN);
//     var3.setMargin(var57);
//     
//     // Checks the contract:  equals-hashcode on var0 and var46
//     assertTrue("Contract failed: equals-hashcode on var0 and var46", var0.equals(var46) ? var0.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var0
//     assertTrue("Contract failed: equals-hashcode on var46 and var0", var46.equals(var0) ? var46.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var56
//     assertTrue("Contract failed: equals-hashcode on var10 and var56", var10.equals(var56) ? var10.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var10
//     assertTrue("Contract failed: equals-hashcode on var56 and var10", var56.equals(var10) ? var56.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("RectangleAnchor.CENTER");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var4.lengthToJava2D((-1.0d), var6, var7);
    java.awt.Shape var9 = var4.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var12 = new org.jfree.chart.entity.TickLabelEntity(var9, "", "");
    boolean var13 = var2.equals((java.lang.Object)var9);
    java.lang.Number var14 = var2.getMean();
    java.lang.Number var15 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 3.0d+ "'", var14.equals(3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 3.0d+ "'", var15.equals(3.0d));

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 10.0d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var4.lengthToJava2D((-1.0d), var6, var7);
    java.awt.Shape var9 = var4.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var12 = new org.jfree.chart.entity.TickLabelEntity(var9, "", "");
    boolean var13 = var2.equals((java.lang.Object)var9);
    org.jfree.chart.block.LineBorder var14 = new org.jfree.chart.block.LineBorder();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
    boolean var19 = var14.equals((java.lang.Object)var18);
    java.awt.Paint var20 = var14.getPaint();
    java.awt.Paint var21 = var14.getPaint();
    org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic(var9, var21);
    boolean var23 = var22.isLineVisible();
    var22.setShapeVisible(false);
    java.awt.Paint var26 = var22.getOutlinePaint();
    java.awt.Graphics2D var27 = null;
    org.jfree.data.Range var29 = null;
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(0.0d, var29);
    org.jfree.chart.block.RectangleConstraint var32 = var30.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var34 = var32.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    double var40 = var36.lengthToJava2D((-1.0d), var38, var39);
    org.jfree.data.Range var41 = var36.getDefaultAutoRange();
    var36.resizeRange(1.0d);
    boolean var44 = var36.isTickLabelsVisible();
    org.jfree.data.Range var45 = var36.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var46 = var32.toRangeHeight(var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var47 = var22.arrange(var27, var46);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var1.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var1.zoomDomainAxes(2.0d, 16.0d, var5, var6);
    java.awt.Paint var8 = var1.getNoDataMessagePaint();
    var1.setForegroundAlpha(0.0f);
    java.util.List var11 = var1.getCategories();
    float var12 = var1.getBackgroundImageAlpha();
    var1.setBackgroundAlpha(100.0f);
    java.awt.Paint var15 = var1.getNoDataMessagePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var0, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var3 = var2.getUpperClip();
//     var2.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var6 = var2.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var2.getPositiveItemLabelPosition(10, 100);
//     double var10 = var9.getAngle();
//     org.jfree.chart.text.TextAnchor var11 = var9.getTextAnchor();
//     java.lang.Comparable var12 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var15.setLeftArrow(var22);
//     var15.setRangeWithMargins(Double.NaN, 0.0d);
//     var15.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var30 = null;
//     var29.setBaseURLGenerator(var30, false);
//     java.awt.Paint var34 = var29.getSeriesFillPaint(10);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var41 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var38, "hi!", "");
//     java.awt.Shape var42 = var41.getArea();
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.util.RectangleEdge var47 = null;
//     double var48 = var44.lengthToJava2D((-1.0d), var46, var47);
//     java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var44.setLeftArrow(var51);
//     var41.setArea(var51);
//     java.awt.Shape var54 = var41.getArea();
//     var29.setBaseShape(var54, true);
//     java.awt.Font var59 = var29.getItemLabelFont(100, 10);
//     var15.setLabelFont(var59);
//     java.awt.Color var63 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var64 = org.jfree.chart.text.TextUtilities.createTextBlock("", var59, (java.awt.Paint)var63);
//     java.awt.Graphics2D var65 = null;
//     org.jfree.chart.util.Size2D var66 = var64.calculateDimensions(var65);
//     org.jfree.chart.text.TextLine var67 = null;
//     var64.addLine(var67);
//     java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var75 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var72, "hi!", "");
//     java.awt.Shape var76 = var75.getArea();
//     boolean var77 = var64.equals((java.lang.Object)var75);
//     org.jfree.chart.text.TextBlockAnchor var78 = null;
//     org.jfree.chart.renderer.category.BarRenderer var79 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var80 = var79.getUpperClip();
//     var79.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var83 = var79.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var86 = var79.getPositiveItemLabelPosition(10, 100);
//     double var87 = var86.getAngle();
//     org.jfree.chart.text.TextAnchor var88 = var86.getTextAnchor();
//     org.jfree.chart.axis.CategoryTick var90 = new org.jfree.chart.axis.CategoryTick(var12, var64, var78, var88, 1.0d);
//     java.lang.Comparable var91 = var90.getCategory();
//     org.jfree.chart.text.TextAnchor var92 = var90.getTextAnchor();
//     org.jfree.chart.axis.NumberTick var94 = new org.jfree.chart.axis.NumberTick((java.lang.Number)1.0E-8d, "", var11, var92, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var9 and var86
//     assertTrue("Contract failed: equals-hashcode on var9 and var86", var9.equals(var86) ? var9.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var9
//     assertTrue("Contract failed: equals-hashcode on var86 and var9", var86.equals(var9) ? var86.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var0.lookupSeriesStroke(255);
    org.jfree.chart.annotations.CategoryAnnotation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Locale var1 = var0.getLocale();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.getString("NOID");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.Layer var1 = null;
//     java.util.Collection var2 = var0.getDomainMarkers(var1);
//     org.jfree.chart.axis.CategoryAxis var4 = var0.getDomainAxis((-16777215));
//     org.jfree.chart.plot.PlotOrientation var5 = var0.getOrientation();
//     double var6 = var0.getRangeCrosshairValue();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var13 = var12.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var15.setLeftArrow(var22);
//     var15.setRangeWithMargins(Double.NaN, 0.0d);
//     var15.setTickLabelsVisible(true);
//     int var29 = var12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var15);
//     java.awt.Paint var30 = var12.getRangeGridlinePaint();
//     org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var32 = var31.getUpperClip();
//     var12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var35 = var34.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var37.lengthToJava2D((-1.0d), var39, var40);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var37.setLeftArrow(var44);
//     var37.setRangeWithMargins(Double.NaN, 0.0d);
//     var37.setTickLabelsVisible(true);
//     int var51 = var34.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var37);
//     java.awt.Paint var52 = var34.getRangeGridlinePaint();
//     var12.setDomainGridlinePaint(var52);
//     var12.setRangeCrosshairVisible(false);
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.LegendItemSource var57 = null;
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle(var57);
//     boolean var59 = var58.getNotify();
//     java.awt.geom.Rectangle2D var60 = var58.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     boolean var63 = var12.render(var56, var60, 0, var62);
//     java.awt.geom.Point2D var64 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.2d, (-1.0d), var60);
//     var0.zoomRangeAxes(8.0d, 0.0d, var9, var64);
//     
//     // Checks the contract:  equals-hashcode on var0 and var34
//     assertTrue("Contract failed: equals-hashcode on var0 and var34", var0.equals(var34) ? var0.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var0
//     assertTrue("Contract failed: equals-hashcode on var34 and var0", var34.equals(var0) ? var34.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    java.awt.Paint var18 = var0.getRangeGridlinePaint();
    org.jfree.chart.LegendItemCollection var19 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var21 = var19.get(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseSeriesVisible();
    boolean var3 = var0.getAutoPopulateSeriesShape();
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.lang.Boolean var3 = null;
    var0.setSeriesItemLabelsVisible(100, var3, true);
    org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
    var0.setBasePaint((java.awt.Paint)var10, false);
    int var13 = var0.getColumnCount();
    var0.setSeriesVisible(4, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var17 = var0.getPositiveItemLabelPositionFallback();
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var23 = var22.brighter();
    java.awt.color.ColorSpace var24 = var23.getColorSpace();
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var26.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var27);
    var27.setOutlineVisible(false);
    java.awt.Stroke var31 = var27.getRangeCrosshairStroke();
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(100.0d, (java.awt.Paint)var23, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), (java.awt.Paint)var23, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    org.jfree.data.Range var8 = var3.getDefaultAutoRange();
    org.jfree.data.Range var10 = null;
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(0.0d, var10);
    org.jfree.chart.block.RectangleConstraint var13 = var11.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var15 = var13.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var17.lengthToJava2D((-1.0d), var19, var20);
    org.jfree.data.Range var22 = var17.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var23 = var15.toRangeWidth(var22);
    org.jfree.data.Range var24 = org.jfree.data.Range.combine(var8, var22);
    var1.setRange(var8);
    java.awt.Font var26 = var1.getLabelFont();
    java.awt.Shape var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDownArrow(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var17 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var17);
    org.jfree.chart.util.RectangleInsets var19 = var0.getInsets();
    double var20 = var19.getRight();
    double var22 = var19.calculateRightOutset(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 8.0d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var7 = var1.getMarkerBand();
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Paint var9 = var1.getLabelPaint();
    var1.resizeRange(3.0d, 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var2 = var0.getRangeLowerBound(false);
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
//     java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Comparable var9 = var0.getColumnKey((-16777215));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var4.lengthToJava2D((-1.0d), var6, var7);
//     java.awt.Shape var9 = var4.getLeftArrow();
//     org.jfree.chart.entity.TickLabelEntity var12 = new org.jfree.chart.entity.TickLabelEntity(var9, "", "");
//     boolean var13 = var2.equals((java.lang.Object)var9);
//     org.jfree.chart.block.LineBorder var14 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
//     boolean var19 = var14.equals((java.lang.Object)var18);
//     java.awt.Paint var20 = var14.getPaint();
//     java.awt.Paint var21 = var14.getPaint();
//     org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic(var9, var21);
//     boolean var23 = var22.isLineVisible();
//     var22.setShapeVisible(false);
//     java.awt.Paint var26 = var22.getOutlinePaint();
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
//     var27.setLabelToolTip("");
//     boolean var30 = var27.isTickLabelsVisible();
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var34 = var33.getStroke();
//     java.awt.Stroke var35 = var33.getOutlineStroke();
//     org.jfree.chart.LegendItemSource var36 = null;
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle(var36);
//     org.jfree.chart.block.BlockContainer var38 = var37.getItemContainer();
//     var37.setNotify(false);
//     java.awt.Color var43 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var44 = var43.brighter();
//     java.awt.Color var45 = var43.brighter();
//     var37.setItemPaint((java.awt.Paint)var43);
//     var33.setOutlinePaint((java.awt.Paint)var43);
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var50);
//     float[] var55 = new float[] { (-1.0f), 10.0f, 1.0f};
//     float[] var56 = var50.getRGBColorComponents(var55);
//     float[] var57 = var43.getRGBColorComponents(var56);
//     var27.setTickLabelPaint((java.lang.Comparable)16.0d, (java.awt.Paint)var43);
//     var22.setFillPaint((java.awt.Paint)var43);
//     
//     // Checks the contract:  equals-hashcode on var18 and var51
//     assertTrue("Contract failed: equals-hashcode on var18 and var51", var18.equals(var51) ? var18.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var18
//     assertTrue("Contract failed: equals-hashcode on var51 and var18", var51.equals(var18) ? var51.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var3 = var0.getCeilingTickUnit(2.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
//     var1.setNotify(false);
//     org.jfree.chart.event.TitleChangeListener var5 = null;
//     var1.removeChangeListener(var5);
//     org.jfree.chart.util.VerticalAlignment var7 = var1.getVerticalAlignment();
//     org.jfree.chart.util.RectangleInsets var8 = var1.getLegendItemGraphicPadding();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.LegendItemSource var10 = null;
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
//     boolean var12 = var11.getNotify();
//     double var13 = var11.getWidth();
//     org.jfree.chart.util.RectangleEdge var14 = var11.getLegendItemGraphicEdge();
//     boolean var15 = var11.getNotify();
//     java.awt.geom.Rectangle2D var16 = var11.getBounds();
//     var1.draw(var9, var16);
// 
//   }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1, false);
//     java.awt.Paint var5 = var0.getSeriesFillPaint(10);
//     boolean var8 = var0.isItemLabelVisible(0, (-16777215));
//     boolean var10 = var0.isSeriesItemLabelsVisible((-1));
//     java.awt.Stroke var12 = null;
//     var0.setSeriesStroke(15, var12, true);
//     boolean var15 = var0.getAutoPopulateSeriesStroke();
//     boolean var16 = var0.getAutoPopulateSeriesOutlineStroke();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.LegendItemSource var18 = null;
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
//     boolean var20 = var19.getNotify();
//     java.awt.geom.Rectangle2D var21 = var19.getBounds();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var24 = var23.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var23.zoomDomainAxes(2.0d, 16.0d, var27, var28);
//     java.awt.Paint var30 = var23.getNoDataMessagePaint();
//     org.jfree.chart.plot.DatasetRenderingOrder var31 = var23.getDatasetRenderingOrder();
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var33 = null;
//     var32.setBaseURLGenerator(var33, false);
//     java.awt.Paint var37 = var32.getSeriesFillPaint(10);
//     boolean var38 = var32.getBaseCreateEntities();
//     var23.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var32, false);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var42.setTickMarkInsideLength(100.0f);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.util.RectangleEdge var49 = null;
//     double var50 = var46.lengthToJava2D((-1.0d), var48, var49);
//     java.awt.Shape var51 = var46.getLeftArrow();
//     var42.setRightArrow(var51);
//     org.jfree.data.Range var53 = var23.getDataRange((org.jfree.chart.axis.ValueAxis)var42);
//     org.jfree.chart.axis.MarkerAxisBand var54 = var42.getMarkerBand();
//     org.jfree.chart.util.Layer var55 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     var0.drawAnnotations(var17, var21, var22, (org.jfree.chart.axis.ValueAxis)var42, var55, var56);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setLabelToolTip("");
    var0.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var5 = null;
    var0.removeChangeListener(var5);
    org.jfree.chart.axis.CategoryLabelPositions var7 = var0.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    var8.setLabelToolTip("");
    var8.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var13 = null;
    var8.removeChangeListener(var13);
    org.jfree.chart.axis.CategoryLabelPositions var15 = var8.getCategoryLabelPositions();
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    boolean var18 = var17.getNotify();
    double var19 = var17.getWidth();
    org.jfree.chart.util.RectangleEdge var20 = var17.getLegendItemGraphicEdge();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    double var26 = var21.getCategoryStart(10, (-16777215), var24, var25);
    java.awt.Font var28 = null;
    var21.setTickLabelFont((java.lang.Comparable)1, var28);
    java.lang.String var30 = var21.getLabel();
    org.jfree.chart.axis.CategoryAnchor var31 = null;
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.LegendItemSource var35 = null;
    org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle(var35);
    boolean var37 = var36.getNotify();
    double var38 = var36.getWidth();
    org.jfree.chart.util.RectangleEdge var39 = var36.getLegendItemGraphicEdge();
    double var40 = var21.getCategoryJava2DCoordinate(var31, (-1), (-16777215), var34, var39);
    var17.setLegendItemGraphicEdge(var39);
    org.jfree.chart.axis.CategoryLabelPosition var42 = var15.getLabelPosition(var39);
    org.jfree.chart.axis.CategoryLabelPositions var43 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var7, var42);
    org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
    double var45 = var44.getUpperClip();
    java.lang.Boolean var47 = null;
    var44.setSeriesItemLabelsVisible(100, var47, true);
    org.jfree.chart.util.GradientPaintTransformer var50 = var44.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var54 = new org.jfree.chart.ChartColor(100, 0, 10);
    var44.setBasePaint((java.awt.Paint)var54, false);
    double var57 = var44.getLowerClip();
    java.awt.Paint var60 = var44.getItemLabelPaint(0, 0);
    var44.setItemLabelAnchorOffset(0.05d);
    boolean var63 = var43.equals((java.lang.Object)0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    org.jfree.chart.util.RectangleInsets var3 = var1.getItemLabelPadding();
    java.lang.Object var4 = var1.clone();
    org.jfree.chart.util.RectangleEdge var5 = var1.getPosition();
    org.jfree.chart.ChartColor var9 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var10 = var9.getAlpha();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
    var11.setBaseToolTipGenerator(var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var17.lengthToJava2D((-1.0d), var19, var20);
    java.awt.Shape var22 = var17.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var23 = var17.getMarkerBand();
    org.jfree.data.Range var24 = var17.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var26.lengthToJava2D((-1.0d), var28, var29);
    java.awt.Shape var31 = var26.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var32 = var26.getMarkerBand();
    org.jfree.data.Range var33 = var26.getDefaultAutoRange();
    var17.setDefaultAutoRange(var33);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var37 = var36.getStroke();
    java.awt.geom.Rectangle2D var38 = null;
    var11.drawRangeMarker(var14, var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.plot.Marker)var36, var38);
    java.awt.Stroke var40 = var11.getBaseStroke();
    org.jfree.chart.block.CenterArrangement var41 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var42 = null;
    boolean var43 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var41, var42);
    org.jfree.chart.block.BlockContainer var44 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var41);
    var44.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var50 = var44.getPadding();
    org.jfree.chart.block.Arrangement var51 = var44.getArrangement();
    org.jfree.chart.util.RectangleInsets var52 = var44.getPadding();
    org.jfree.chart.block.LineBorder var53 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var9, var40, var52);
    var1.setLegendItemGraphicPadding(var52);
    java.lang.String var55 = var52.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"+ "'", var55.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var3.setLeftArrow(var10);
//     var3.setRangeWithMargins(Double.NaN, 0.0d);
//     var3.setTickLabelsVisible(true);
//     int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
//     java.awt.Paint var18 = var0.getRangeGridlinePaint();
//     org.jfree.chart.LegendItemCollection var19 = var0.getLegendItems();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var21 = var20.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var23.lengthToJava2D((-1.0d), var25, var26);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var23.setLeftArrow(var30);
//     var23.setRangeWithMargins(Double.NaN, 0.0d);
//     var23.setTickLabelsVisible(true);
//     int var37 = var20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var23);
//     java.awt.Paint var38 = var20.getRangeGridlinePaint();
//     org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var40 = var39.getUpperClip();
//     var20.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var43 = var42.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var47 = null;
//     org.jfree.chart.util.RectangleEdge var48 = null;
//     double var49 = var45.lengthToJava2D((-1.0d), var47, var48);
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var45.setLeftArrow(var52);
//     var45.setRangeWithMargins(Double.NaN, 0.0d);
//     var45.setTickLabelsVisible(true);
//     int var59 = var42.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var45);
//     java.awt.Paint var60 = var42.getRangeGridlinePaint();
//     var20.setDomainGridlinePaint(var60);
//     java.awt.Image var62 = null;
//     var20.setBackgroundImage(var62);
//     org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.RectangleInsets var66 = var65.getLabelOffset();
//     java.lang.Object var67 = var65.clone();
//     var20.addRangeMarker((org.jfree.chart.plot.Marker)var65);
//     float var69 = var20.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var70 = new org.jfree.chart.axis.CategoryAxis();
//     var70.setLabelToolTip("");
//     var70.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var75 = null;
//     var70.removeChangeListener(var75);
//     org.jfree.chart.util.RectangleInsets var77 = var70.getTickLabelInsets();
//     org.jfree.chart.axis.NumberAxis var79 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var81 = null;
//     org.jfree.chart.util.RectangleEdge var82 = null;
//     double var83 = var79.lengthToJava2D((-1.0d), var81, var82);
//     java.awt.Shape var84 = var79.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var85 = var79.getMarkerBand();
//     org.jfree.data.Range var86 = var79.getDefaultAutoRange();
//     java.awt.Paint var87 = var79.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var88 = new org.jfree.chart.block.BlockBorder(var77, var87);
//     boolean var89 = var20.equals((java.lang.Object)var77);
//     boolean var90 = var19.equals((java.lang.Object)var77);
//     
//     // Checks the contract:  equals-hashcode on var0 and var42
//     assertTrue("Contract failed: equals-hashcode on var0 and var42", var0.equals(var42) ? var0.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var0
//     assertTrue("Contract failed: equals-hashcode on var42 and var0", var42.equals(var0) ? var42.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Shape var6 = var5.getDownArrow();
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, Double.NaN, 1.0f, 100.0f);
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var17 = var16.getStroke();
    java.awt.Stroke var18 = var16.getOutlineStroke();
    org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var23 = var22.getAlpha();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "0,0,2,-2,2,2,2,2", "", var10, (java.awt.Paint)var13, var18, (java.awt.Paint)var22);
    java.awt.Paint var25 = var24.getOutlinePaint();
    java.lang.String var26 = var24.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "0,0,2,-2,2,2,2,2"+ "'", var26.equals("0,0,2,-2,2,2,2,2"));

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var1.setBaseToolTipGenerator(var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var7.lengthToJava2D((-1.0d), var9, var10);
    java.awt.Shape var12 = var7.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var13 = var7.getMarkerBand();
    org.jfree.data.Range var14 = var7.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var16.lengthToJava2D((-1.0d), var18, var19);
    java.awt.Shape var21 = var16.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var22 = var16.getMarkerBand();
    org.jfree.data.Range var23 = var16.getDefaultAutoRange();
    var7.setDefaultAutoRange(var23);
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var27 = var26.getStroke();
    java.awt.geom.Rectangle2D var28 = null;
    var1.drawRangeMarker(var4, var5, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.plot.Marker)var26, var28);
    boolean var30 = var7.isAxisLineVisible();
    org.jfree.data.RangeType var31 = var7.getRangeType();
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.util.RectangleEdge var38 = null;
    double var39 = var35.lengthToJava2D((-1.0d), var37, var38);
    org.jfree.data.Range var40 = var35.getDefaultAutoRange();
    org.jfree.data.Range var42 = null;
    org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint(0.0d, var42);
    org.jfree.chart.block.RectangleConstraint var45 = var43.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var47 = var45.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var51 = null;
    org.jfree.chart.util.RectangleEdge var52 = null;
    double var53 = var49.lengthToJava2D((-1.0d), var51, var52);
    org.jfree.data.Range var54 = var49.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var55 = var47.toRangeWidth(var54);
    org.jfree.data.Range var56 = org.jfree.data.Range.combine(var40, var54);
    var33.setRange(var40);
    var7.setRange(var40);
    double var59 = var40.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var60 = new org.jfree.chart.block.RectangleConstraint(16.0d, var40);
    boolean var62 = var40.contains(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var2 = null;
    var1.setBackgroundPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    java.lang.Object var6 = null;
    java.lang.Object var7 = var1.draw(var4, var5, var6);
    var1.setURLText("UnitType.ABSOLUTE");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomDomainAxes(2.0d, 16.0d, var4, var5);
//     java.awt.Paint var7 = var0.getNoDataMessagePaint();
//     var0.setForegroundAlpha(0.0f);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var12 = var11.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var11.zoomDomainAxes(2.0d, 16.0d, var15, var16);
//     java.lang.Object var18 = var11.clone();
//     org.jfree.chart.axis.AxisLocation var19 = var11.getDomainAxisLocation();
//     java.lang.String var20 = var19.toString();
//     var0.setRangeAxisLocation(0, var19);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var23 = var22.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     java.awt.geom.Point2D var27 = null;
//     var22.zoomDomainAxes(2.0d, 16.0d, var26, var27);
//     java.lang.Object var29 = var22.clone();
//     org.jfree.chart.axis.AxisLocation var30 = var22.getRangeAxisLocation();
//     org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
//     var31.setBaseToolTipGenerator(var32);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var37.lengthToJava2D((-1.0d), var39, var40);
//     java.awt.Shape var42 = var37.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var43 = var37.getMarkerBand();
//     org.jfree.data.Range var44 = var37.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.util.RectangleEdge var49 = null;
//     double var50 = var46.lengthToJava2D((-1.0d), var48, var49);
//     java.awt.Shape var51 = var46.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var52 = var46.getMarkerBand();
//     org.jfree.data.Range var53 = var46.getDefaultAutoRange();
//     var37.setDefaultAutoRange(var53);
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var57 = var56.getStroke();
//     java.awt.geom.Rectangle2D var58 = null;
//     var31.drawRangeMarker(var34, var35, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.plot.Marker)var56, var58);
//     boolean var60 = var37.isAxisLineVisible();
//     org.jfree.data.RangeType var61 = var37.getRangeType();
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var67 = null;
//     org.jfree.chart.util.RectangleEdge var68 = null;
//     double var69 = var65.lengthToJava2D((-1.0d), var67, var68);
//     org.jfree.data.Range var70 = var65.getDefaultAutoRange();
//     org.jfree.data.Range var72 = null;
//     org.jfree.chart.block.RectangleConstraint var73 = new org.jfree.chart.block.RectangleConstraint(0.0d, var72);
//     org.jfree.chart.block.RectangleConstraint var75 = var73.toFixedHeight(0.0d);
//     org.jfree.chart.block.RectangleConstraint var77 = var75.toFixedHeight((-1.0d));
//     org.jfree.chart.axis.NumberAxis var79 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var81 = null;
//     org.jfree.chart.util.RectangleEdge var82 = null;
//     double var83 = var79.lengthToJava2D((-1.0d), var81, var82);
//     org.jfree.data.Range var84 = var79.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var85 = var77.toRangeWidth(var84);
//     org.jfree.data.Range var86 = org.jfree.data.Range.combine(var70, var84);
//     var63.setRange(var70);
//     var37.setRange(var70);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var89 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Object var90 = var89.clone();
//     org.jfree.data.general.DatasetChangeListener var91 = null;
//     var89.addChangeListener(var91);
//     org.jfree.data.Range var93 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var89);
//     org.jfree.data.general.DatasetChangeEvent var94 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var37, (org.jfree.data.general.Dataset)var89);
//     var22.datasetChanged(var94);
//     var0.datasetChanged(var94);
//     
//     // Checks the contract:  equals-hashcode on var11 and var22
//     assertTrue("Contract failed: equals-hashcode on var11 and var22", var11.equals(var22) ? var11.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var11
//     assertTrue("Contract failed: equals-hashcode on var22 and var11", var22.equals(var11) ? var22.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var29
//     assertTrue("Contract failed: equals-hashcode on var18 and var29", var18.equals(var29) ? var18.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var18
//     assertTrue("Contract failed: equals-hashcode on var29 and var18", var29.equals(var18) ? var29.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
//     var1.setAutoRange(false);
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var9 = var8.getUpperClip();
//     java.awt.Stroke var10 = var8.getBaseStroke();
//     var1.setTickMarkStroke(var10);
//     var1.setLowerMargin((-1.0d));
//     var1.setAxisLineVisible(false);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var17 = var16.isDomainGridlinesVisible();
//     var16.clearRangeMarkers(10);
//     boolean var20 = var16.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     var21.setLabelToolTip("");
//     var21.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var26 = null;
//     var21.removeChangeListener(var26);
//     org.jfree.chart.axis.CategoryLabelPositions var28 = var21.getCategoryLabelPositions();
//     org.jfree.chart.axis.CategoryAxis[] var29 = new org.jfree.chart.axis.CategoryAxis[] { var21};
//     var16.setDomainAxes(var29);
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.Layer var33 = null;
//     var16.addRangeMarker((org.jfree.chart.plot.Marker)var32, var33);
//     boolean var35 = var1.hasListener((java.util.EventListener)var16);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var37 = null;
//     var36.setFixedLegendItems(var37);
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     var39.setLabelToolTip("");
//     java.awt.Paint var43 = var39.getTickLabelPaint((java.lang.Comparable)(-1));
//     var36.setDomainAxis(var39);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var46 = var45.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var45.zoomDomainAxes(2.0d, 16.0d, var49, var50);
//     var45.setDrawSharedDomainAxis(true);
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var56 = var55.isDomainGridlinesVisible();
//     var55.clearRangeMarkers(10);
//     boolean var59 = var55.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis();
//     var60.setLabelToolTip("");
//     var60.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var65 = null;
//     var60.removeChangeListener(var65);
//     org.jfree.chart.axis.CategoryLabelPositions var67 = var60.getCategoryLabelPositions();
//     org.jfree.chart.axis.CategoryAxis[] var68 = new org.jfree.chart.axis.CategoryAxis[] { var60};
//     var55.setDomainAxes(var68);
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var71 = var70.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var74 = null;
//     java.awt.geom.Point2D var75 = null;
//     var70.zoomDomainAxes(2.0d, 16.0d, var74, var75);
//     java.lang.Object var77 = var70.clone();
//     org.jfree.chart.axis.AxisLocation var78 = var70.getDomainAxisLocation();
//     var55.setDomainAxisLocation(var78, false);
//     var45.setDomainAxisLocation(10, var78, true);
//     java.lang.String var83 = var78.toString();
//     var36.setRangeAxisLocation(var78, false);
//     var16.setDomainAxisLocation(var78);
//     
//     // Checks the contract:  equals-hashcode on var16 and var55
//     assertTrue("Contract failed: equals-hashcode on var16 and var55", var16.equals(var55) ? var16.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var16
//     assertTrue("Contract failed: equals-hashcode on var55 and var16", var55.equals(var16) ? var55.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var2 = null;
    var1.setBackgroundPaint(var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.data.Range var6 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(0.0d, var6);
    org.jfree.chart.block.RectangleConstraint var9 = var7.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var11 = var9.toFixedHeight((-1.0d));
    org.jfree.chart.block.RectangleConstraint var13 = var11.toFixedHeight(Double.NaN);
    double var14 = var13.getWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var15 = var1.arrange(var4, var13);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var3.setLeftArrow(var10);
//     var3.setRangeWithMargins(Double.NaN, 0.0d);
//     var3.setTickLabelsVisible(true);
//     int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
//     java.awt.Paint var18 = var0.getRangeGridlinePaint();
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var20 = var19.getUpperClip();
//     var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Shape var28 = var27.getDownArrow();
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, Double.NaN, 1.0f, 100.0f);
//     java.awt.Color var35 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var36 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var35);
//     org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var39 = var38.getStroke();
//     java.awt.Stroke var40 = var38.getOutlineStroke();
//     org.jfree.chart.ChartColor var44 = new org.jfree.chart.ChartColor(100, 0, 10);
//     int var45 = var44.getAlpha();
//     org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("hi!", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "0,0,2,-2,2,2,2,2", "", var32, (java.awt.Paint)var35, var40, (java.awt.Paint)var44);
//     java.awt.Paint var47 = var46.getOutlinePaint();
//     java.awt.Paint var48 = var46.getOutlinePaint();
//     int var49 = var46.getDatasetIndex();
//     java.lang.String var50 = var46.getLabel();
//     java.awt.Paint var51 = var46.getFillPaint();
//     var0.setNoDataMessagePaint(var51);
//     org.jfree.chart.block.BlockBorder var53 = new org.jfree.chart.block.BlockBorder(var51);
//     
//     // Checks the contract:  equals-hashcode on var36 and var53
//     assertTrue("Contract failed: equals-hashcode on var36 and var53", var36.equals(var53) ? var36.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var36
//     assertTrue("Contract failed: equals-hashcode on var53 and var36", var53.equals(var36) ? var53.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    java.lang.Object var2 = var0.clone();
    var0.setItemMargin(0.0d);
    java.awt.Paint var7 = var0.getItemLabelPaint(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var9.setBaseURLGenerator(var10, false);
    java.awt.Paint var14 = var9.getSeriesFillPaint(10);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var21 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var18, "hi!", "");
    java.awt.Shape var22 = var21.getArea();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var24.lengthToJava2D((-1.0d), var26, var27);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var24.setLeftArrow(var31);
    var21.setArea(var31);
    java.awt.Shape var34 = var21.getArea();
    var9.setBaseShape(var34, true);
    java.awt.Font var39 = var9.getItemLabelFont(100, 10);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    double var42 = var41.getUpperClip();
    java.awt.Stroke var43 = var41.getBaseStroke();
    var9.setSeriesStroke(100, var43, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-16777215), var43, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("UnitType.ABSOLUTE", 0, 15);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var6 = var5.brighter();
//     boolean var8 = var5.equals((java.lang.Object)(short)100);
//     var2.setPaint((java.awt.Paint)var5);
//     org.jfree.chart.LegendItemSource var10 = null;
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
//     boolean var12 = var11.getNotify();
//     java.awt.Font var13 = var11.getItemFont();
//     var2.setFont(var13);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
//     var15.setBaseToolTipGenerator(var16);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = null;
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var21.lengthToJava2D((-1.0d), var23, var24);
//     java.awt.Shape var26 = var21.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var27 = var21.getMarkerBand();
//     org.jfree.data.Range var28 = var21.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var30.lengthToJava2D((-1.0d), var32, var33);
//     java.awt.Shape var35 = var30.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var36 = var30.getMarkerBand();
//     org.jfree.data.Range var37 = var30.getDefaultAutoRange();
//     var21.setDefaultAutoRange(var37);
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var41 = var40.getStroke();
//     java.awt.geom.Rectangle2D var42 = null;
//     var15.drawRangeMarker(var18, var19, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.plot.Marker)var40, var42);
//     java.awt.Stroke var44 = var15.getBaseStroke();
//     double var45 = var15.getLowerClip();
//     org.jfree.chart.labels.CategoryToolTipGenerator var48 = var15.getToolTipGenerator((-16777215), 15);
//     org.jfree.data.statistics.MeanAndStandardDeviation var51 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     double var57 = var53.lengthToJava2D((-1.0d), var55, var56);
//     java.awt.Shape var58 = var53.getLeftArrow();
//     org.jfree.chart.entity.TickLabelEntity var61 = new org.jfree.chart.entity.TickLabelEntity(var58, "", "");
//     boolean var62 = var51.equals((java.lang.Object)var58);
//     org.jfree.chart.block.LineBorder var63 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var66 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var67 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var66);
//     boolean var68 = var63.equals((java.lang.Object)var67);
//     java.awt.Paint var69 = var63.getPaint();
//     java.awt.Paint var70 = var63.getPaint();
//     org.jfree.chart.title.LegendGraphic var71 = new org.jfree.chart.title.LegendGraphic(var58, var70);
//     java.awt.Paint var72 = var71.getFillPaint();
//     var15.setBaseFillPaint(var72);
//     java.awt.Graphics2D var75 = null;
//     org.jfree.chart.text.G2TextMeasurer var76 = new org.jfree.chart.text.G2TextMeasurer(var75);
//     org.jfree.chart.text.TextBlock var77 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", var13, var72, 0.5f, (org.jfree.chart.text.TextMeasurer)var76);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    org.jfree.chart.annotations.CategoryAnnotation var2 = null;
    org.jfree.chart.util.Layer var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     java.lang.Comparable var3 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var6.setLeftArrow(var13);
//     var6.setRangeWithMargins(Double.NaN, 0.0d);
//     var6.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var21 = null;
//     var20.setBaseURLGenerator(var21, false);
//     java.awt.Paint var25 = var20.getSeriesFillPaint(10);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var32 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var29, "hi!", "");
//     java.awt.Shape var33 = var32.getArea();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var35.lengthToJava2D((-1.0d), var37, var38);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var35.setLeftArrow(var42);
//     var32.setArea(var42);
//     java.awt.Shape var45 = var32.getArea();
//     var20.setBaseShape(var45, true);
//     java.awt.Font var50 = var20.getItemLabelFont(100, 10);
//     var6.setLabelFont(var50);
//     java.awt.Color var54 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var55 = org.jfree.chart.text.TextUtilities.createTextBlock("", var50, (java.awt.Paint)var54);
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.util.Size2D var57 = var55.calculateDimensions(var56);
//     org.jfree.chart.text.TextLine var58 = null;
//     var55.addLine(var58);
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var66 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var63, "hi!", "");
//     java.awt.Shape var67 = var66.getArea();
//     boolean var68 = var55.equals((java.lang.Object)var66);
//     org.jfree.chart.text.TextBlockAnchor var69 = null;
//     org.jfree.chart.renderer.category.BarRenderer var70 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var71 = var70.getUpperClip();
//     var70.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var74 = var70.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var77 = var70.getPositiveItemLabelPosition(10, 100);
//     double var78 = var77.getAngle();
//     org.jfree.chart.text.TextAnchor var79 = var77.getTextAnchor();
//     org.jfree.chart.axis.CategoryTick var81 = new org.jfree.chart.axis.CategoryTick(var3, var55, var69, var79, 1.0d);
//     float var82 = var1.calculateBaselineOffset(var2, var79);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    java.awt.Paint var18 = var0.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getUpperClip();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    boolean var23 = var22.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var25.setLeftArrow(var32);
    var25.setRangeWithMargins(Double.NaN, 0.0d);
    var25.setTickLabelsVisible(true);
    int var39 = var22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var40 = var22.getRangeGridlinePaint();
    var0.setDomainGridlinePaint(var40);
    java.awt.Image var42 = null;
    var0.setBackgroundImage(var42);
    org.jfree.data.category.CategoryDataset var45 = var0.getDataset(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    boolean var3 = var2.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var2.zoomDomainAxes(2.0d, 16.0d, var6, var7);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var2);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var2.getRenderer();
    var2.setRangeCrosshairValue(1.0d);
    float var13 = var2.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var15 = var2.getDomainAxisForDataset(0);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.plot.DrawingSupplier var17 = var2.getDrawingSupplier();
    double var18 = var2.getRangeCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    boolean var4 = var3.getNotify();
    java.awt.Font var5 = var3.getItemFont();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    double var7 = var6.getUpperClip();
    boolean var8 = var6.getBaseSeriesVisible();
    java.awt.Color var12 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var13 = var12.brighter();
    var6.setSeriesItemLabelPaint(0, (java.awt.Paint)var12, false);
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", var5, (java.awt.Paint)var12);
    org.jfree.chart.ChartColor var20 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var21 = var20.getAlpha();
    org.jfree.chart.text.TextLine var22 = new org.jfree.chart.text.TextLine("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var5, (java.awt.Paint)var20);
    org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var24.setBaseURLGenerator(var25, false);
    java.awt.Paint var29 = var24.getSeriesFillPaint(10);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var36 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var33, "hi!", "");
    java.awt.Shape var37 = var36.getArea();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var41 = null;
    org.jfree.chart.util.RectangleEdge var42 = null;
    double var43 = var39.lengthToJava2D((-1.0d), var41, var42);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var39.setLeftArrow(var46);
    var36.setArea(var46);
    java.awt.Shape var49 = var36.getArea();
    var24.setBaseShape(var49, true);
    java.awt.Font var54 = var24.getItemLabelFont(100, 10);
    org.jfree.chart.text.TextFragment var55 = new org.jfree.chart.text.TextFragment("hi!", var54);
    org.jfree.chart.LegendItemSource var56 = null;
    org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle(var56);
    org.jfree.chart.block.BlockContainer var58 = var57.getItemContainer();
    org.jfree.chart.util.RectangleInsets var59 = var57.getItemLabelPadding();
    java.lang.Object var60 = var57.clone();
    org.jfree.chart.util.RectangleAnchor var61 = var57.getLegendItemGraphicAnchor();
    boolean var62 = var55.equals((java.lang.Object)var61);
    var22.removeFragment(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.JFreeChart var2 = null;
    org.jfree.chart.event.ChartProgressEvent var5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)100.0d, var2, 100, (-1));
    org.jfree.chart.JFreeChart var6 = null;
    var5.setChart(var6);
    int var8 = var5.getPercent();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    java.util.List var1 = var0.getTicks();
    java.util.Collection var2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     boolean var2 = var1.getNotify();
//     double var3 = var1.getWidth();
//     org.jfree.chart.util.RectangleEdge var4 = var1.getLegendItemGraphicEdge();
//     boolean var5 = var1.getNotify();
//     java.awt.geom.Rectangle2D var6 = var1.getBounds();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     boolean var10 = var9.getNotify();
//     java.awt.geom.Rectangle2D var11 = var9.getBounds();
//     org.jfree.chart.axis.AxisState var12 = new org.jfree.chart.axis.AxisState();
//     var12.setCursor(0.0d);
//     java.util.List var15 = var12.getTicks();
//     var12.cursorLeft(16.0d);
//     var12.setMax(16.0d);
//     java.lang.Object var20 = var1.draw(var7, var11, (java.lang.Object)var12);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    org.jfree.chart.util.RectangleInsets var3 = var1.getItemLabelPadding();
    java.lang.Object var4 = var1.clone();
    org.jfree.chart.util.RectangleAnchor var5 = var1.getLegendItemGraphicAnchor();
    org.jfree.chart.event.TitleChangeEvent var6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    org.jfree.chart.event.ChartChangeEventType var7 = null;
    var6.setType(var7);
    java.lang.Object var9 = var6.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomDomainAxes(2.0d, 16.0d, var4, var5);
//     java.lang.Object var7 = var0.clone();
//     org.jfree.chart.axis.AxisLocation var8 = var0.getRangeAxisLocation();
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
//     var9.setBaseToolTipGenerator(var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var20 = var15.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
//     org.jfree.data.Range var22 = var15.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var24.lengthToJava2D((-1.0d), var26, var27);
//     java.awt.Shape var29 = var24.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var30 = var24.getMarkerBand();
//     org.jfree.data.Range var31 = var24.getDefaultAutoRange();
//     var15.setDefaultAutoRange(var31);
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var35 = var34.getStroke();
//     java.awt.geom.Rectangle2D var36 = null;
//     var9.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.plot.Marker)var34, var36);
//     boolean var38 = var15.isAxisLineVisible();
//     org.jfree.data.RangeType var39 = var15.getRangeType();
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var43.lengthToJava2D((-1.0d), var45, var46);
//     org.jfree.data.Range var48 = var43.getDefaultAutoRange();
//     org.jfree.data.Range var50 = null;
//     org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(0.0d, var50);
//     org.jfree.chart.block.RectangleConstraint var53 = var51.toFixedHeight(0.0d);
//     org.jfree.chart.block.RectangleConstraint var55 = var53.toFixedHeight((-1.0d));
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var57.lengthToJava2D((-1.0d), var59, var60);
//     org.jfree.data.Range var62 = var57.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var63 = var55.toRangeWidth(var62);
//     org.jfree.data.Range var64 = org.jfree.data.Range.combine(var48, var62);
//     var41.setRange(var48);
//     var15.setRange(var48);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var67 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Object var68 = var67.clone();
//     org.jfree.data.general.DatasetChangeListener var69 = null;
//     var67.addChangeListener(var69);
//     org.jfree.data.Range var71 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var67);
//     org.jfree.data.general.DatasetChangeEvent var72 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var15, (org.jfree.data.general.Dataset)var67);
//     var0.datasetChanged(var72);
//     int var74 = var0.getBackgroundImageAlignment();
//     org.jfree.chart.util.Layer var75 = null;
//     java.util.Collection var76 = var0.getRangeMarkers(var75);
//     int var77 = var0.getBackgroundImageAlignment();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var78 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var80 = var78.getRangeLowerBound(false);
//     var0.setDataset((org.jfree.data.category.CategoryDataset)var78);
//     
//     // Checks the contract:  equals-hashcode on var67 and var78
//     assertTrue("Contract failed: equals-hashcode on var67 and var78", var67.equals(var78) ? var67.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var67
//     assertTrue("Contract failed: equals-hashcode on var78 and var67", var78.equals(var67) ? var78.hashCode() == var67.hashCode() : true);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    java.awt.Stroke var29 = var0.getBaseStroke();
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var0.setSeriesToolTipGenerator(0, var31);
    boolean var35 = var0.getItemCreateEntity(15, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    var1.setNotify(false);
    org.jfree.chart.util.RectangleEdge var5 = var1.getPosition();
    java.awt.Paint var6 = var1.getBackgroundPaint();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    boolean var8 = var7.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var7.zoomDomainAxes(2.0d, 16.0d, var11, var12);
    java.lang.Object var14 = var7.clone();
    org.jfree.chart.axis.AxisLocation var15 = var7.getRangeAxisLocation();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = null;
    var16.setBaseToolTipGenerator(var17);
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = null;
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    double var26 = var22.lengthToJava2D((-1.0d), var24, var25);
    java.awt.Shape var27 = var22.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var28 = var22.getMarkerBand();
    org.jfree.data.Range var29 = var22.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
    java.awt.Shape var36 = var31.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var37 = var31.getMarkerBand();
    org.jfree.data.Range var38 = var31.getDefaultAutoRange();
    var22.setDefaultAutoRange(var38);
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var42 = var41.getStroke();
    java.awt.geom.Rectangle2D var43 = null;
    var16.drawRangeMarker(var19, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.plot.Marker)var41, var43);
    boolean var45 = var22.isAxisLineVisible();
    org.jfree.data.RangeType var46 = var22.getRangeType();
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var52 = null;
    org.jfree.chart.util.RectangleEdge var53 = null;
    double var54 = var50.lengthToJava2D((-1.0d), var52, var53);
    org.jfree.data.Range var55 = var50.getDefaultAutoRange();
    org.jfree.data.Range var57 = null;
    org.jfree.chart.block.RectangleConstraint var58 = new org.jfree.chart.block.RectangleConstraint(0.0d, var57);
    org.jfree.chart.block.RectangleConstraint var60 = var58.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var62 = var60.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var66 = null;
    org.jfree.chart.util.RectangleEdge var67 = null;
    double var68 = var64.lengthToJava2D((-1.0d), var66, var67);
    org.jfree.data.Range var69 = var64.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var70 = var62.toRangeWidth(var69);
    org.jfree.data.Range var71 = org.jfree.data.Range.combine(var55, var69);
    var48.setRange(var55);
    var22.setRange(var55);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var74 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var75 = var74.clone();
    org.jfree.data.general.DatasetChangeListener var76 = null;
    var74.addChangeListener(var76);
    org.jfree.data.Range var78 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var74);
    org.jfree.data.general.DatasetChangeEvent var79 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var22, (org.jfree.data.general.Dataset)var74);
    var7.datasetChanged(var79);
    int var81 = var7.getBackgroundImageAlignment();
    org.jfree.chart.util.RectangleEdge var82 = var7.getDomainAxisEdge();
    var1.setPosition(var82);
    boolean var84 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var17 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var17);
    org.jfree.chart.util.RectangleInsets var19 = var0.getInsets();
    var0.setForegroundAlpha((-1.0f));
    java.awt.Paint var22 = var0.getBackgroundPaint();
    org.jfree.chart.annotations.CategoryAnnotation var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var2.setLeftArrow(var9);
    var2.setRangeWithMargins(Double.NaN, 0.0d);
    var2.setTickLabelsVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var16.setBaseURLGenerator(var17, false);
    java.awt.Paint var21 = var16.getSeriesFillPaint(10);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var25, "hi!", "");
    java.awt.Shape var29 = var28.getArea();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var31.setLeftArrow(var38);
    var28.setArea(var38);
    java.awt.Shape var41 = var28.getArea();
    var16.setBaseShape(var41, true);
    java.awt.Font var46 = var16.getItemLabelFont(100, 10);
    var2.setLabelFont(var46);
    java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, (java.awt.Paint)var50);
    java.awt.Graphics2D var52 = null;
    org.jfree.chart.util.Size2D var53 = var51.calculateDimensions(var52);
    org.jfree.chart.text.TextLine var54 = null;
    var51.addLine(var54);
    org.jfree.chart.util.HorizontalAlignment var56 = var51.getLineAlignment();
    java.lang.String var57 = var56.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var57.equals("HorizontalAlignment.CENTER"));

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
//     var0.setBaseToolTipGenerator(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
//     java.awt.Shape var11 = var6.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
//     org.jfree.data.Range var13 = var6.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
//     java.awt.Shape var20 = var15.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
//     org.jfree.data.Range var22 = var15.getDefaultAutoRange();
//     var6.setDefaultAutoRange(var22);
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var26 = var25.getStroke();
//     java.awt.geom.Rectangle2D var27 = null;
//     var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
//     java.awt.Stroke var29 = var0.getBaseStroke();
//     org.jfree.chart.labels.CategoryToolTipGenerator var32 = var0.getToolTipGenerator(1, 100);
//     org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var35 = var34.getUpperClip();
//     java.awt.Stroke var36 = var34.getBaseStroke();
//     var0.setSeriesOutlineStroke(1, var36);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var34 and var0.", var34.equals(var0) == var0.equals(var34));
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    var1.setURLText("CategoryLabelEntity: category=, tooltip=hi!, url=");
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var6.setBaseURLGenerator(var7, false);
    java.awt.Paint var11 = var6.getSeriesFillPaint(10);
    boolean var14 = var6.isItemLabelVisible(0, (-16777215));
    java.lang.Object var15 = var1.draw(var4, var5, (java.lang.Object)0);
    var1.setToolTipText("");
    org.jfree.chart.LegendItemSource var18 = null;
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
    org.jfree.chart.block.BlockContainer var20 = var19.getItemContainer();
    org.jfree.chart.util.HorizontalAlignment var21 = var19.getHorizontalAlignment();
    var1.setHorizontalAlignment(var21);
    org.jfree.chart.util.RectangleInsets var23 = var1.getMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    double var2 = var1.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "", "");
    java.lang.String var10 = var9.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setLabelToolTip("");
//     var1.setUpperMargin((-1.0d));
//     var1.setLabelURL("hi!");
//     double var8 = var1.getUpperMargin();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var11.lengthToJava2D((-1.0d), var13, var14);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var11.setLeftArrow(var18);
//     var11.setRangeWithMargins(Double.NaN, 0.0d);
//     var11.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var26 = null;
//     var25.setBaseURLGenerator(var26, false);
//     java.awt.Paint var30 = var25.getSeriesFillPaint(10);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var37 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var34, "hi!", "");
//     java.awt.Shape var38 = var37.getArea();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     double var44 = var40.lengthToJava2D((-1.0d), var42, var43);
//     java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var40.setLeftArrow(var47);
//     var37.setArea(var47);
//     java.awt.Shape var50 = var37.getArea();
//     var25.setBaseShape(var50, true);
//     java.awt.Font var55 = var25.getItemLabelFont(100, 10);
//     var11.setLabelFont(var55);
//     java.awt.Color var59 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var60 = org.jfree.chart.text.TextUtilities.createTextBlock("", var55, (java.awt.Paint)var59);
//     var1.setLabelFont(var55);
//     org.jfree.chart.LegendItemSource var62 = null;
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle(var62);
//     var63.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
//     org.jfree.chart.event.TitleChangeListener var69 = null;
//     var63.removeChangeListener(var69);
//     java.awt.Color var73 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var74 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var73);
//     var63.setItemPaint((java.awt.Paint)var73);
//     java.awt.color.ColorSpace var76 = var73.getColorSpace();
//     org.jfree.chart.block.LabelBlock var77 = new org.jfree.chart.block.LabelBlock("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", var55, (java.awt.Paint)var73);
//     java.awt.Graphics2D var78 = null;
//     org.jfree.data.Range var80 = null;
//     org.jfree.chart.block.RectangleConstraint var81 = new org.jfree.chart.block.RectangleConstraint(0.0d, var80);
//     org.jfree.chart.block.RectangleConstraint var83 = var81.toFixedHeight(0.0d);
//     org.jfree.chart.block.RectangleConstraint var85 = var83.toFixedHeight((-1.0d));
//     org.jfree.chart.block.RectangleConstraint var87 = var85.toFixedHeight(Double.NaN);
//     org.jfree.chart.block.RectangleConstraint var88 = var85.toUnconstrainedWidth();
//     org.jfree.chart.util.Size2D var89 = var77.arrange(var78, var88);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject(0);
    java.lang.Object var4 = null;
    var0.setObject((java.lang.Comparable)255, var4);
    int var6 = var0.getItemCount();
    java.util.List var7 = var0.getKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1, false);
//     java.awt.Paint var5 = var0.getSeriesFillPaint(10);
//     boolean var8 = var0.isItemLabelVisible(0, (-16777215));
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var11 = var10.getUpperClip();
//     java.awt.Stroke var12 = var10.getBaseStroke();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var10.getPositiveItemLabelPosition((-16777215), 10);
//     org.jfree.chart.labels.ItemLabelAnchor var16 = var15.getItemLabelAnchor();
//     var0.setSeriesPositiveItemLabelPosition(15, var15, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var0.", var10.equals(var0) == var0.equals(var10));
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var2);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.RectangleEdge var8 = null;
    double var9 = var5.lengthToJava2D((-1.0d), var7, var8);
    org.jfree.data.Range var10 = var5.getDefaultAutoRange();
    var5.resizeRange(1.0d);
    java.awt.Stroke var13 = var5.getAxisLineStroke();
    var5.setAutoTickUnitSelection(true, true);
    var5.setAutoTickUnitSelection(false, false);
    var5.setLabel("NOID");
    int var22 = var2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var5);
    boolean var23 = var5.getAutoRangeIncludesZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    org.jfree.data.Range var8 = var3.getDefaultAutoRange();
    org.jfree.data.Range var10 = null;
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(0.0d, var10);
    org.jfree.chart.block.RectangleConstraint var13 = var11.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var15 = var13.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var17.lengthToJava2D((-1.0d), var19, var20);
    org.jfree.data.Range var22 = var17.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var23 = var15.toRangeWidth(var22);
    org.jfree.data.Range var24 = org.jfree.data.Range.combine(var8, var22);
    var1.setRange(var8);
    org.jfree.data.Range var28 = org.jfree.data.Range.expand(var8, 1.0E-8d, 7.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    double var1 = var0.getTranslateX();
    boolean var2 = var0.getGenerateEntities();
    var0.setTranslateY((-1.0d));
    double var5 = var0.getTranslateX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    org.jfree.data.Range var6 = var1.getDefaultAutoRange();
    org.jfree.data.Range var8 = null;
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(0.0d, var8);
    org.jfree.chart.block.RectangleConstraint var11 = var9.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var13 = var11.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    org.jfree.data.Range var20 = var15.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var21 = var13.toRangeWidth(var20);
    org.jfree.data.Range var22 = org.jfree.data.Range.combine(var6, var20);
    double var23 = var22.getUpperBound();
    double var24 = var22.getLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPlot(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    var0.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getSeriesURLGenerator(0);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getBaseToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.axis.TickUnit var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var4 = var0.getLargerTickUnit(var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.data.Range var2 = var1.getRange();
    java.awt.Font var3 = var1.getLabelFont();
    var1.setVisible(false);
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelInsets(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    org.jfree.data.Range var6 = var1.getDefaultAutoRange();
    var1.resizeRange(1.0d);
    java.awt.Stroke var9 = var1.getAxisLineStroke();
    var1.setAutoTickUnitSelection(true, true);
    var1.setAutoTickUnitSelection(false, false);
    var1.setLabel("NOID");
    var1.setVerticalTickLabels(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.util.GradientPaintTransformer var4 = var0.getGradientPaintTransformer();
    org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPosition(10, 100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    var0.setBaseItemLabelGenerator(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.lang.Boolean var3 = null;
    var0.setSeriesItemLabelsVisible(100, var3, true);
    org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
    var0.setBasePaint((java.awt.Paint)var10, false);
    int var13 = var10.getTransparency();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.lang.Boolean var3 = null;
    var0.setSeriesItemLabelsVisible(100, var3, true);
    org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
    var0.setBasePaint((java.awt.Paint)var10, false);
    int var13 = var0.getColumnCount();
    java.awt.Shape var15 = null;
    var0.setSeriesShape(255, var15, true);
    double var18 = var0.getLowerClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.LegendItemCollection var2 = var0.getFixedLegendItems();
    org.jfree.chart.plot.CategoryMarker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var4.lengthToJava2D((-1.0d), var6, var7);
//     java.awt.Shape var9 = var4.getLeftArrow();
//     org.jfree.chart.entity.TickLabelEntity var12 = new org.jfree.chart.entity.TickLabelEntity(var9, "", "");
//     boolean var13 = var2.equals((java.lang.Object)var9);
//     org.jfree.chart.block.LineBorder var14 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
//     boolean var19 = var14.equals((java.lang.Object)var18);
//     java.awt.Paint var20 = var14.getPaint();
//     java.awt.Paint var21 = var14.getPaint();
//     org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic(var9, var21);
//     boolean var23 = var22.isLineVisible();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     var24.setLabelToolTip("");
//     var24.setUpperMargin((-1.0d));
//     var24.setLabelURL("hi!");
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var32.lengthToJava2D((-1.0d), var34, var35);
//     java.awt.Shape var37 = var32.getLeftArrow();
//     var32.setAutoRangeMinimumSize(100.0d);
//     var32.configure();
//     var32.setVisible(true);
//     var32.setInverted(true);
//     java.awt.Paint var45 = var32.getLabelPaint();
//     var24.setAxisLinePaint(var45);
//     var22.setFillPaint(var45);
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.block.CenterArrangement var49 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var50 = null;
//     boolean var51 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var49, var50);
//     org.jfree.chart.block.BlockContainer var52 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var49);
//     var52.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var58 = var52.getPadding();
//     org.jfree.chart.block.Arrangement var59 = var52.getArrangement();
//     org.jfree.chart.util.RectangleInsets var60 = var52.getPadding();
//     double var62 = var60.calculateRightInset(100.0d);
//     org.jfree.chart.block.LineBorder var63 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var66 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var67 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var66);
//     boolean var68 = var63.equals((java.lang.Object)var67);
//     java.awt.Graphics2D var69 = null;
//     org.jfree.chart.LegendItemSource var70 = null;
//     org.jfree.chart.title.LegendTitle var71 = new org.jfree.chart.title.LegendTitle(var70);
//     boolean var72 = var71.getNotify();
//     java.awt.geom.Rectangle2D var73 = var71.getBounds();
//     var63.draw(var69, var73);
//     java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var73, 0.5d, 1.0f, 0.5f);
//     java.awt.geom.Rectangle2D var81 = var60.createOutsetRectangle(var73, false, true);
//     org.jfree.chart.plot.ValueMarker var83 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var84 = var83.getStroke();
//     java.awt.Stroke var85 = var83.getOutlineStroke();
//     org.jfree.chart.util.LengthAdjustmentType var86 = var83.getLabelOffsetType();
//     java.lang.Object var87 = var22.draw(var48, var81, (java.lang.Object)var83);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    java.awt.Paint var18 = var0.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getUpperClip();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    boolean var23 = var22.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var25.setLeftArrow(var32);
    var25.setRangeWithMargins(Double.NaN, 0.0d);
    var25.setTickLabelsVisible(true);
    int var39 = var22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var40 = var22.getRangeGridlinePaint();
    var0.setDomainGridlinePaint(var40);
    org.jfree.chart.plot.CategoryMarker var42 = null;
    org.jfree.chart.util.Layer var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var42, var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    var1.setNotify(false);
    org.jfree.chart.event.TitleChangeListener var5 = null;
    var1.removeChangeListener(var5);
    org.jfree.chart.util.VerticalAlignment var7 = var1.getVerticalAlignment();
    java.awt.Paint var8 = var1.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    java.awt.Paint var18 = var0.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getUpperClip();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    boolean var23 = var22.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var25.setLeftArrow(var32);
    var25.setRangeWithMargins(Double.NaN, 0.0d);
    var25.setTickLabelsVisible(true);
    int var39 = var22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var40 = var22.getRangeGridlinePaint();
    var0.setDomainGridlinePaint(var40);
    java.awt.Image var42 = null;
    var0.setBackgroundImage(var42);
    org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var46 = var45.getLabelOffset();
    java.lang.Object var47 = var45.clone();
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var45);
    var0.clearAnnotations();
    var0.clearDomainAxes();
    org.jfree.chart.plot.CategoryMarker var51 = null;
    org.jfree.chart.util.Layer var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var51, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("0,0,2,-2,2,2,2,2");
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setLabelToolTip("");
//     var2.setUpperMargin((-1.0d));
//     var2.setLabelURL("hi!");
//     double var9 = var2.getUpperMargin();
//     boolean var11 = var2.equals((java.lang.Object)(-1.0d));
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var14 = var12.getRangeLowerBound(false);
//     org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var12, false);
//     java.lang.Number var17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var12);
//     int var18 = var12.getColumnCount();
//     boolean var19 = var2.equals((java.lang.Object)var12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var21 = var1.generateLabel((org.jfree.data.category.CategoryDataset)var12, 0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + Double.NaN+ "'", var17.equals(Double.NaN));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(0.0d);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var5.setBaseToolTipGenerator(var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var11.lengthToJava2D((-1.0d), var13, var14);
    java.awt.Shape var16 = var11.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var17 = var11.getMarkerBand();
    org.jfree.data.Range var18 = var11.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var20.lengthToJava2D((-1.0d), var22, var23);
    java.awt.Shape var25 = var20.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var26 = var20.getMarkerBand();
    org.jfree.data.Range var27 = var20.getDefaultAutoRange();
    var11.setDefaultAutoRange(var27);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var31 = var30.getStroke();
    java.awt.geom.Rectangle2D var32 = null;
    var5.drawRangeMarker(var8, var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.plot.Marker)var30, var32);
    boolean var34 = var11.isAxisLineVisible();
    org.jfree.data.RangeType var35 = var11.getRangeType();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var41 = null;
    org.jfree.chart.util.RectangleEdge var42 = null;
    double var43 = var39.lengthToJava2D((-1.0d), var41, var42);
    org.jfree.data.Range var44 = var39.getDefaultAutoRange();
    org.jfree.data.Range var46 = null;
    org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint(0.0d, var46);
    org.jfree.chart.block.RectangleConstraint var49 = var47.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var51 = var49.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.util.RectangleEdge var56 = null;
    double var57 = var53.lengthToJava2D((-1.0d), var55, var56);
    org.jfree.data.Range var58 = var53.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var59 = var51.toRangeWidth(var58);
    org.jfree.data.Range var60 = org.jfree.data.Range.combine(var44, var58);
    var37.setRange(var44);
    var11.setRange(var44);
    org.jfree.data.Range var64 = org.jfree.data.Range.expandToInclude(var44, 3.0d);
    org.jfree.chart.block.RectangleConstraint var65 = var2.toRangeWidth(var44);
    org.jfree.chart.block.RectangleConstraint var67 = var65.toFixedWidth(0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var4.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    double var12 = var8.lengthToJava2D((-1.0d), var10, var11);
    org.jfree.data.Range var13 = var8.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var14 = var6.toRangeWidth(var13);
    org.jfree.data.Range var15 = var14.getWidthRange();
    org.jfree.data.Range var17 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(0.0d, var17);
    org.jfree.chart.block.RectangleConstraint var20 = var18.toFixedHeight(0.0d);
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var21.setBaseToolTipGenerator(var22);
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = null;
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleEdge var30 = null;
    double var31 = var27.lengthToJava2D((-1.0d), var29, var30);
    java.awt.Shape var32 = var27.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var33 = var27.getMarkerBand();
    org.jfree.data.Range var34 = var27.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    double var40 = var36.lengthToJava2D((-1.0d), var38, var39);
    java.awt.Shape var41 = var36.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var42 = var36.getMarkerBand();
    org.jfree.data.Range var43 = var36.getDefaultAutoRange();
    var27.setDefaultAutoRange(var43);
    org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var47 = var46.getStroke();
    java.awt.geom.Rectangle2D var48 = null;
    var21.drawRangeMarker(var24, var25, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.plot.Marker)var46, var48);
    boolean var50 = var27.isAxisLineVisible();
    org.jfree.data.RangeType var51 = var27.getRangeType();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var57 = null;
    org.jfree.chart.util.RectangleEdge var58 = null;
    double var59 = var55.lengthToJava2D((-1.0d), var57, var58);
    org.jfree.data.Range var60 = var55.getDefaultAutoRange();
    org.jfree.data.Range var62 = null;
    org.jfree.chart.block.RectangleConstraint var63 = new org.jfree.chart.block.RectangleConstraint(0.0d, var62);
    org.jfree.chart.block.RectangleConstraint var65 = var63.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var67 = var65.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var71 = null;
    org.jfree.chart.util.RectangleEdge var72 = null;
    double var73 = var69.lengthToJava2D((-1.0d), var71, var72);
    org.jfree.data.Range var74 = var69.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var75 = var67.toRangeWidth(var74);
    org.jfree.data.Range var76 = org.jfree.data.Range.combine(var60, var74);
    var53.setRange(var60);
    var27.setRange(var60);
    org.jfree.data.Range var80 = org.jfree.data.Range.expandToInclude(var60, 3.0d);
    org.jfree.chart.block.RectangleConstraint var81 = var18.toRangeWidth(var60);
    org.jfree.chart.block.RectangleConstraint var82 = var14.toRangeWidth(var60);
    org.jfree.chart.axis.NumberAxis var84 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var86 = null;
    org.jfree.chart.util.RectangleEdge var87 = null;
    double var88 = var84.lengthToJava2D((-1.0d), var86, var87);
    org.jfree.data.Range var89 = var84.getDefaultAutoRange();
    var84.resizeRange(1.0d);
    boolean var92 = var84.isTickLabelsVisible();
    org.jfree.data.Range var93 = var84.getDefaultAutoRange();
    boolean var94 = var60.equals((java.lang.Object)var84);
    java.lang.Comparable var95 = null;
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var96 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.KeyedObject var97 = new org.jfree.data.KeyedObject(var95, (java.lang.Object)var96);
    java.lang.Object var98 = var97.getObject();
    boolean var99 = var84.equals(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == false);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var2 = var0.getRangeLowerBound(false);
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
//     org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
//     java.util.EventListener var6 = null;
//     boolean var7 = var0.hasListener(var6);
//     org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
//     java.lang.Number var9 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var11 = var0.getColumnIndex((java.lang.Comparable)255);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var14 = var0.getMeanValue(4, 0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + 0.0d+ "'", var9.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1));
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.lang.Boolean var3 = null;
    var0.setSeriesItemLabelsVisible(100, var3, true);
    org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
    var0.setBasePaint((java.awt.Paint)var10, false);
    int var13 = var0.getColumnCount();
    java.awt.Paint var14 = var0.getBaseItemLabelPaint();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var0.setSeriesURLGenerator(10, var18, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var2 = var0.getRangeLowerBound(false);
//     java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     java.lang.Number var5 = null;
//     java.lang.Comparable var6 = null;
//     var0.add((java.lang.Number)0, var5, var6, (java.lang.Comparable)(byte)(-1));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)16.0d);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var2);
//     java.lang.Object var4 = var1.clone();
//     org.jfree.chart.util.RectangleInsets var5 = var1.getLabelOffset();
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Color var10 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var11 = var10.brighter();
//     boolean var13 = var10.equals((java.lang.Object)(short)100);
//     var7.setPaint((java.awt.Paint)var10);
//     org.jfree.chart.LegendItemSource var15 = null;
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
//     boolean var17 = var16.getNotify();
//     java.awt.Font var18 = var16.getItemFont();
//     var7.setFont(var18);
//     var1.setLabelFont(var18);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var22 = var21.isDomainGridlinesVisible();
//     double var23 = var21.getRangeCrosshairValue();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var21);
//     java.util.List var25 = var24.getSubtitles();
//     boolean var26 = var24.isNotify();
//     var24.setBackgroundImageAlignment(10);
//     org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var18, var24);
//     
//     // Checks the contract:  equals-hashcode on var2 and var21
//     assertTrue("Contract failed: equals-hashcode on var2 and var21", var2.equals(var21) ? var2.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var2
//     assertTrue("Contract failed: equals-hashcode on var21 and var2", var21.equals(var2) ? var21.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.block.CenterArrangement var1 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var2 = null;
//     boolean var3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, var2);
//     org.jfree.chart.block.BlockContainer var4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var1);
//     var4.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var10 = var4.getPadding();
//     org.jfree.chart.block.Arrangement var11 = var4.getArrangement();
//     org.jfree.chart.util.RectangleInsets var12 = var4.getPadding();
//     boolean var13 = var0.equals((java.lang.Object)var4);
//     java.awt.GradientPaint var14 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var17 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var19.lengthToJava2D((-1.0d), var21, var22);
//     java.awt.Shape var24 = var19.getLeftArrow();
//     org.jfree.chart.entity.TickLabelEntity var27 = new org.jfree.chart.entity.TickLabelEntity(var24, "", "");
//     boolean var28 = var17.equals((java.lang.Object)var24);
//     org.jfree.chart.block.LineBorder var29 = new org.jfree.chart.block.LineBorder();
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var32);
//     boolean var34 = var29.equals((java.lang.Object)var33);
//     java.awt.Paint var35 = var29.getPaint();
//     java.awt.Paint var36 = var29.getPaint();
//     org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic(var24, var36);
//     boolean var38 = var37.isLineVisible();
//     var37.setShapeVisible(false);
//     java.awt.Paint var41 = var37.getOutlinePaint();
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var37.setLine(var44);
//     java.awt.GradientPaint var46 = var0.transform(var14, var44);
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
//     java.lang.Object var3 = var1.clone();
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var5 = null;
//     var4.setBaseURLGenerator(var5, false);
//     java.awt.Paint var9 = var4.getSeriesFillPaint(10);
//     java.util.EventListener var10 = null;
//     boolean var11 = var4.hasListener(var10);
//     double var12 = var4.getUpperClip();
//     var4.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var17 = var16.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     java.awt.geom.Point2D var21 = null;
//     var16.zoomDomainAxes(2.0d, 16.0d, var20, var21);
//     java.lang.Object var23 = var16.clone();
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Shape var30 = var29.getDownArrow();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var30, Double.NaN, 1.0f, 100.0f);
//     java.awt.Color var37 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var37);
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var41 = var40.getStroke();
//     java.awt.Stroke var42 = var40.getOutlineStroke();
//     org.jfree.chart.ChartColor var46 = new org.jfree.chart.ChartColor(100, 0, 10);
//     int var47 = var46.getAlpha();
//     org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem("hi!", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "0,0,2,-2,2,2,2,2", "", var34, (java.awt.Paint)var37, var42, (java.awt.Paint)var46);
//     var16.setDomainGridlineStroke(var42);
//     var4.setSeriesOutlineStroke(255, var42, false);
//     var1.setStroke(var42);
//     
//     // Checks the contract:  equals-hashcode on var1 and var40
//     assertTrue("Contract failed: equals-hashcode on var1 and var40", var1.equals(var40) ? var1.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var1
//     assertTrue("Contract failed: equals-hashcode on var40 and var1", var40.equals(var1) ? var40.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var3, "hi!", "");
    java.awt.Shape var7 = var6.getArea();
    java.lang.Object var8 = var6.clone();
    var6.setToolTipText("UnitType.ABSOLUTE");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
//     org.jfree.data.Range var6 = var1.getDefaultAutoRange();
//     var1.resizeRange(1.0d);
//     boolean var9 = var1.isTickLabelsVisible();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var12 = var11.isDomainGridlinesVisible();
//     java.awt.Paint var13 = var11.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     var15.setLabelToolTip("");
//     var15.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var20 = null;
//     var15.removeChangeListener(var20);
//     org.jfree.chart.axis.CategoryLabelPositions var22 = var15.getCategoryLabelPositions();
//     org.jfree.chart.LegendItemSource var23 = null;
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle(var23);
//     boolean var25 = var24.getNotify();
//     double var26 = var24.getWidth();
//     org.jfree.chart.util.RectangleEdge var27 = var24.getLegendItemGraphicEdge();
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     double var33 = var28.getCategoryStart(10, (-16777215), var31, var32);
//     java.awt.Font var35 = null;
//     var28.setTickLabelFont((java.lang.Comparable)1, var35);
//     java.lang.String var37 = var28.getLabel();
//     org.jfree.chart.axis.CategoryAnchor var38 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.LegendItemSource var42 = null;
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle(var42);
//     boolean var44 = var43.getNotify();
//     double var45 = var43.getWidth();
//     org.jfree.chart.util.RectangleEdge var46 = var43.getLegendItemGraphicEdge();
//     double var47 = var28.getCategoryJava2DCoordinate(var38, (-1), (-16777215), var41, var46);
//     var24.setLegendItemGraphicEdge(var46);
//     org.jfree.chart.axis.CategoryLabelPosition var49 = var22.getLabelPosition(var46);
//     org.jfree.chart.axis.AxisSpace var50 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.AxisState var53 = new org.jfree.chart.axis.AxisState((-1.0d));
//     org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis();
//     var55.setLabelToolTip("");
//     var55.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var60 = null;
//     var55.removeChangeListener(var60);
//     org.jfree.chart.axis.CategoryLabelPositions var62 = var55.getCategoryLabelPositions();
//     org.jfree.chart.LegendItemSource var63 = null;
//     org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle(var63);
//     boolean var65 = var64.getNotify();
//     double var66 = var64.getWidth();
//     org.jfree.chart.util.RectangleEdge var67 = var64.getLegendItemGraphicEdge();
//     org.jfree.chart.axis.CategoryAxis var68 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var71 = null;
//     org.jfree.chart.util.RectangleEdge var72 = null;
//     double var73 = var68.getCategoryStart(10, (-16777215), var71, var72);
//     java.awt.Font var75 = null;
//     var68.setTickLabelFont((java.lang.Comparable)1, var75);
//     java.lang.String var77 = var68.getLabel();
//     org.jfree.chart.axis.CategoryAnchor var78 = null;
//     java.awt.geom.Rectangle2D var81 = null;
//     org.jfree.chart.LegendItemSource var82 = null;
//     org.jfree.chart.title.LegendTitle var83 = new org.jfree.chart.title.LegendTitle(var82);
//     boolean var84 = var83.getNotify();
//     double var85 = var83.getWidth();
//     org.jfree.chart.util.RectangleEdge var86 = var83.getLegendItemGraphicEdge();
//     double var87 = var68.getCategoryJava2DCoordinate(var78, (-1), (-16777215), var81, var86);
//     var64.setLegendItemGraphicEdge(var86);
//     org.jfree.chart.axis.CategoryLabelPosition var89 = var62.getLabelPosition(var86);
//     var53.moveCursor(10.0d, var86);
//     var50.add(100.0d, var86);
//     double var92 = var50.getLeft();
//     org.jfree.chart.axis.AxisSpace var93 = var1.reserveSpace(var10, (org.jfree.chart.plot.Plot)var11, var14, var46, var50);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.annotations.CategoryAnnotation var2 = null;
    boolean var3 = var0.removeAnnotation(var2);
    java.awt.Stroke var5 = var0.lookupSeriesStroke((-1));
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var0.setSeriesURLGenerator(255, var7, true);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    double var12 = var11.getUpperClip();
    java.lang.Boolean var14 = null;
    var11.setSeriesItemLabelsVisible(100, var14, true);
    org.jfree.chart.util.GradientPaintTransformer var17 = var11.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var21 = new org.jfree.chart.ChartColor(100, 0, 10);
    var11.setBasePaint((java.awt.Paint)var21, false);
    var0.setSeriesFillPaint(100, (java.awt.Paint)var21);
    org.jfree.chart.labels.ItemLabelPosition var26 = var0.getSeriesNegativeItemLabelPosition(10);
    boolean var27 = var0.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.lang.Boolean var3 = null;
    var0.setSeriesItemLabelsVisible(100, var3, true);
    org.jfree.chart.util.GradientPaintTransformer var6 = var0.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
    var0.setBasePaint((java.awt.Paint)var10, false);
    double var13 = var0.getLowerClip();
    java.awt.Stroke var15 = var0.getSeriesStroke(10);
    org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var18 = null;
    var17.setBaseToolTipGenerator(var18);
    var17.setAutoPopulateSeriesStroke(false);
    boolean var22 = var17.getBaseSeriesVisibleInLegend();
    boolean var23 = var17.getAutoPopulateSeriesOutlinePaint();
    java.lang.Boolean var25 = var17.getSeriesCreateEntities(10);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    boolean var28 = var27.getBaseSeriesVisible();
    org.jfree.chart.labels.ItemLabelPosition var29 = new org.jfree.chart.labels.ItemLabelPosition();
    var27.setPositiveItemLabelPositionFallback(var29);
    var17.setSeriesPositiveItemLabelPosition(0, var29, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-1), var29, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var1.setLeftArrow(var8);
    boolean var10 = var1.isAutoTickUnitSelection();
    double var11 = var1.getLowerBound();
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var13 = null;
    var12.setBaseURLGenerator(var13, false);
    java.awt.Paint var17 = var12.getSeriesFillPaint(10);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var24 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var21, "hi!", "");
    java.awt.Shape var25 = var24.getArea();
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleEdge var30 = null;
    double var31 = var27.lengthToJava2D((-1.0d), var29, var30);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var27.setLeftArrow(var34);
    var24.setArea(var34);
    java.awt.Shape var37 = var24.getArea();
    var12.setBaseShape(var37, true);
    java.awt.Font var42 = var12.getItemLabelFont(100, 10);
    var1.setLabelFont(var42);
    boolean var44 = var1.getAutoRangeIncludesZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.block.CenterArrangement var2 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var3 = null;
    boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, var3);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var2);
    var5.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
    var12.setPadding((-1.0d), 0.0d, 1.0d, (-1.0d));
    java.lang.Object var18 = null;
    var5.add((org.jfree.chart.block.Block)var12, var18);
    boolean var20 = var5.isEmpty();
    boolean var21 = var1.equals((java.lang.Object)var5);
    java.lang.Object var22 = null;
    boolean var23 = var1.equals(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    java.awt.Paint var18 = var0.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getUpperClip();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    boolean var23 = var22.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var25.setLeftArrow(var32);
    var25.setRangeWithMargins(Double.NaN, 0.0d);
    var25.setTickLabelsVisible(true);
    int var39 = var22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var40 = var22.getRangeGridlinePaint();
    var0.setDomainGridlinePaint(var40);
    java.awt.Image var42 = null;
    var0.setBackgroundImage(var42);
    org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var46 = var45.getLabelOffset();
    java.lang.Object var47 = var45.clone();
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var45);
    java.awt.Stroke var49 = var0.getDomainGridlineStroke();
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var54 = null;
    org.jfree.chart.util.RectangleEdge var55 = null;
    double var56 = var52.lengthToJava2D((-1.0d), var54, var55);
    var52.setFixedDimension(10.0d);
    java.awt.Paint var59 = var52.getLabelPaint();
    org.jfree.chart.axis.TickUnitSource var60 = var52.getStandardTickUnits();
    var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var52, false);
    var52.setAutoTickUnitSelection(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     double var1 = var0.getBottom();
//     var0.setRight(0.2d);
//     org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
//     var0.ensureAtLeast(var4);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(100, 0, 10);
//     int var11 = var10.getAlpha();
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var13 = null;
//     var12.setBaseToolTipGenerator(var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = null;
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var18.lengthToJava2D((-1.0d), var20, var21);
//     java.awt.Shape var23 = var18.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var24 = var18.getMarkerBand();
//     org.jfree.data.Range var25 = var18.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var27.lengthToJava2D((-1.0d), var29, var30);
//     java.awt.Shape var32 = var27.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var33 = var27.getMarkerBand();
//     org.jfree.data.Range var34 = var27.getDefaultAutoRange();
//     var18.setDefaultAutoRange(var34);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var38 = var37.getStroke();
//     java.awt.geom.Rectangle2D var39 = null;
//     var12.drawRangeMarker(var15, var16, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.plot.Marker)var37, var39);
//     java.awt.Stroke var41 = var12.getBaseStroke();
//     org.jfree.chart.block.CenterArrangement var42 = new org.jfree.chart.block.CenterArrangement();
//     java.lang.Object var43 = null;
//     boolean var44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, var43);
//     org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var42);
//     var45.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
//     org.jfree.chart.util.RectangleInsets var51 = var45.getPadding();
//     org.jfree.chart.block.Arrangement var52 = var45.getArrangement();
//     org.jfree.chart.util.RectangleInsets var53 = var45.getPadding();
//     org.jfree.chart.block.LineBorder var54 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var10, var41, var53);
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var58 = null;
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = var56.lengthToJava2D((-1.0d), var58, var59);
//     java.awt.Shape var61 = var56.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var62 = var56.getMarkerBand();
//     var56.setRange(0.0d, 1.0d);
//     java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var72 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var69, "hi!", "");
//     java.awt.Shape var73 = var72.getArea();
//     var56.setDownArrow(var73);
//     boolean var75 = var53.equals((java.lang.Object)var73);
//     org.jfree.chart.LegendItemSource var76 = null;
//     org.jfree.chart.title.LegendTitle var77 = new org.jfree.chart.title.LegendTitle(var76);
//     boolean var78 = var77.getNotify();
//     java.awt.geom.Rectangle2D var79 = var77.getBounds();
//     java.awt.geom.Rectangle2D var80 = var53.createOutsetRectangle(var79);
//     java.awt.geom.Rectangle2D var81 = var4.expand(var6, var79);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Shape var6 = var5.getDownArrow();
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, Double.NaN, 1.0f, 100.0f);
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var17 = var16.getStroke();
    java.awt.Stroke var18 = var16.getOutlineStroke();
    org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var23 = var22.getAlpha();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "0,0,2,-2,2,2,2,2", "", var10, (java.awt.Paint)var13, var18, (java.awt.Paint)var22);
    java.awt.Paint var25 = var24.getOutlinePaint();
    java.awt.Paint var26 = var24.getOutlinePaint();
    int var27 = var24.getDatasetIndex();
    java.lang.String var28 = var24.getLabel();
    java.awt.Paint var29 = var24.getFillPaint();
    boolean var30 = var24.isShapeVisible();
    int var31 = var24.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "hi!"+ "'", var28.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    java.awt.Paint var18 = var0.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getUpperClip();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    boolean var23 = var22.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var25.setLeftArrow(var32);
    var25.setRangeWithMargins(Double.NaN, 0.0d);
    var25.setTickLabelsVisible(true);
    int var39 = var22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var40 = var22.getRangeGridlinePaint();
    var0.setDomainGridlinePaint(var40);
    var0.setBackgroundImageAlignment((-16777215));
    org.jfree.chart.util.Layer var45 = null;
    java.util.Collection var46 = var0.getDomainMarkers(255, var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var4.lengthToJava2D((-1.0d), var6, var7);
    java.awt.Shape var9 = var4.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var12 = new org.jfree.chart.entity.TickLabelEntity(var9, "", "");
    boolean var13 = var2.equals((java.lang.Object)var9);
    org.jfree.chart.block.LineBorder var14 = new org.jfree.chart.block.LineBorder();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
    boolean var19 = var14.equals((java.lang.Object)var18);
    java.awt.Paint var20 = var14.getPaint();
    java.awt.Paint var21 = var14.getPaint();
    org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic(var9, var21);
    boolean var23 = var22.isShapeVisible();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.block.RectangleConstraint var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var26 = var22.arrange(var24, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     double[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RangeType.FULL", "", var2);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var17 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var17);
    org.jfree.chart.util.RectangleInsets var19 = var16.getLabelOffset();
    double var21 = var19.calculateTopOutset(1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3.0d);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomDomainAxes(2.0d, 16.0d, var4, var5);
//     java.lang.Object var7 = var0.clone();
//     org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
//     java.lang.String var9 = var8.toString();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var11 = var10.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     java.awt.geom.Point2D var15 = null;
//     var10.zoomDomainAxes(2.0d, 16.0d, var14, var15);
//     java.lang.Object var17 = var10.clone();
//     org.jfree.chart.axis.AxisLocation var18 = var10.getRangeAxisLocation();
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var20 = null;
//     var19.setBaseToolTipGenerator(var20);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
//     java.awt.Shape var30 = var25.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var31 = var25.getMarkerBand();
//     org.jfree.data.Range var32 = var25.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var34.lengthToJava2D((-1.0d), var36, var37);
//     java.awt.Shape var39 = var34.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var40 = var34.getMarkerBand();
//     org.jfree.data.Range var41 = var34.getDefaultAutoRange();
//     var25.setDefaultAutoRange(var41);
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var45 = var44.getStroke();
//     java.awt.geom.Rectangle2D var46 = null;
//     var19.drawRangeMarker(var22, var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.plot.Marker)var44, var46);
//     boolean var48 = var25.isAxisLineVisible();
//     org.jfree.data.RangeType var49 = var25.getRangeType();
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     double var57 = var53.lengthToJava2D((-1.0d), var55, var56);
//     org.jfree.data.Range var58 = var53.getDefaultAutoRange();
//     org.jfree.data.Range var60 = null;
//     org.jfree.chart.block.RectangleConstraint var61 = new org.jfree.chart.block.RectangleConstraint(0.0d, var60);
//     org.jfree.chart.block.RectangleConstraint var63 = var61.toFixedHeight(0.0d);
//     org.jfree.chart.block.RectangleConstraint var65 = var63.toFixedHeight((-1.0d));
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var69 = null;
//     org.jfree.chart.util.RectangleEdge var70 = null;
//     double var71 = var67.lengthToJava2D((-1.0d), var69, var70);
//     org.jfree.data.Range var72 = var67.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var73 = var65.toRangeWidth(var72);
//     org.jfree.data.Range var74 = org.jfree.data.Range.combine(var58, var72);
//     var51.setRange(var58);
//     var25.setRange(var58);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var77 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Object var78 = var77.clone();
//     org.jfree.data.general.DatasetChangeListener var79 = null;
//     var77.addChangeListener(var79);
//     org.jfree.data.Range var81 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var77);
//     org.jfree.data.general.DatasetChangeEvent var82 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var25, (org.jfree.data.general.Dataset)var77);
//     var10.datasetChanged(var82);
//     int var84 = var10.getBackgroundImageAlignment();
//     org.jfree.chart.util.RectangleEdge var85 = var10.getDomainAxisEdge();
//     org.jfree.chart.plot.PlotOrientation var86 = var10.getOrientation();
//     org.jfree.chart.util.RectangleEdge var87 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var8, var86);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var17
//     assertTrue("Contract failed: equals-hashcode on var7 and var17", var7.equals(var17) ? var7.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var7
//     assertTrue("Contract failed: equals-hashcode on var17 and var7", var17.equals(var7) ? var17.hashCode() == var7.hashCode() : true);
// 
//   }

}
