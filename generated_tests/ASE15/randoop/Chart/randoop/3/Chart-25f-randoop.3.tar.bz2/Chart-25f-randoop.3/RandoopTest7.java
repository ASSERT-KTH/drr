
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
    java.lang.Number var3 = var2.getMean();
    java.lang.Number var4 = var2.getStandardDeviation();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    boolean var6 = var5.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    java.awt.geom.Point2D var10 = null;
    var5.zoomDomainAxes(2.0d, 16.0d, var9, var10);
    java.lang.Object var12 = var5.clone();
    org.jfree.chart.axis.AxisLocation var13 = var5.getRangeAxisLocation();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var15.setLeftArrow(var22);
    var15.setRangeWithMargins(Double.NaN, 0.0d);
    org.jfree.data.Range var27 = var5.getDataRange((org.jfree.chart.axis.ValueAxis)var15);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    boolean var29 = var28.isDomainGridlinesVisible();
    var28.clearRangeMarkers(10);
    boolean var32 = var28.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
    var33.setLabelToolTip("");
    var33.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var38 = null;
    var33.removeChangeListener(var38);
    org.jfree.chart.axis.CategoryLabelPositions var40 = var33.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var41 = new org.jfree.chart.axis.CategoryAxis[] { var33};
    var28.setDomainAxes(var41);
    org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var45 = null;
    var28.addRangeMarker((org.jfree.chart.plot.Marker)var44, var45);
    org.jfree.chart.util.RectangleInsets var47 = var28.getInsets();
    var28.setForegroundAlpha((-1.0f));
    org.jfree.chart.axis.AxisLocation var51 = var28.getRangeAxisLocation((-1));
    var5.setDomainAxisLocation(var51, true);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.Layer var55 = null;
    java.util.Collection var56 = var54.getDomainMarkers(var55);
    org.jfree.chart.axis.CategoryAxis var58 = var54.getDomainAxis((-16777215));
    org.jfree.chart.plot.PlotOrientation var59 = var54.getOrientation();
    org.jfree.chart.util.RectangleEdge var60 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var51, var59);
    boolean var61 = var2.equals((java.lang.Object)var51);
    java.lang.Number var62 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 3.0d+ "'", var3.equals(3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 16.0d+ "'", var4.equals(16.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + 3.0d+ "'", var62.equals(3.0d));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(-7471090));
    org.jfree.data.KeyedObjects var3 = new org.jfree.data.KeyedObjects();
    java.lang.Object var5 = var3.getObject(0);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var7.lengthToJava2D((-1.0d), var9, var10);
    org.jfree.data.Range var12 = var7.getDefaultAutoRange();
    var7.resizeRange(1.0d);
    java.awt.Stroke var15 = var7.getAxisLineStroke();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.axis.AxisState var17 = new org.jfree.chart.axis.AxisState();
    var17.setCursor(0.0d);
    java.util.List var20 = var17.getTicks();
    var17.setCursor(Double.NaN);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    java.util.List var25 = var7.refreshTicks(var16, var17, var23, var24);
    org.jfree.chart.axis.NumberTickUnit var26 = var7.getTickUnit();
    org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = null;
    var27.setBaseToolTipGenerator(var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = null;
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var33.lengthToJava2D((-1.0d), var35, var36);
    java.awt.Shape var38 = var33.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var39 = var33.getMarkerBand();
    org.jfree.data.Range var40 = var33.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleEdge var45 = null;
    double var46 = var42.lengthToJava2D((-1.0d), var44, var45);
    java.awt.Shape var47 = var42.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var48 = var42.getMarkerBand();
    org.jfree.data.Range var49 = var42.getDefaultAutoRange();
    var33.setDefaultAutoRange(var49);
    org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var53 = var52.getStroke();
    java.awt.geom.Rectangle2D var54 = null;
    var27.drawRangeMarker(var30, var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.plot.Marker)var52, var54);
    org.jfree.chart.plot.Plot var56 = null;
    var33.setPlot(var56);
    org.jfree.chart.axis.NumberTickUnit var58 = var33.getTickUnit();
    double var59 = var58.getSize();
    var7.setTickUnit(var58);
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var64 = null;
    org.jfree.chart.util.RectangleEdge var65 = null;
    double var66 = var62.lengthToJava2D((-1.0d), var64, var65);
    org.jfree.data.Range var67 = var62.getDefaultAutoRange();
    var62.resizeRange(1.0d);
    boolean var70 = var62.isTickLabelsVisible();
    boolean var71 = var62.isInverted();
    java.awt.Shape var72 = var62.getDownArrow();
    org.jfree.chart.entity.LegendItemEntity var73 = new org.jfree.chart.entity.LegendItemEntity(var72);
    java.lang.Object var74 = var73.clone();
    var3.addObject((java.lang.Comparable)var58, var74);
    int var76 = var0.getRowIndex((java.lang.Comparable)var58);
    int var77 = var58.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var7 = var1.getMarkerBand();
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Paint var9 = var1.getLabelPaint();
    java.awt.Paint var10 = var1.getTickLabelPaint();
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var14 = var13.brighter();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
    float[] var22 = new float[] { (-1.0f), 10.0f, 1.0f};
    float[] var23 = var17.getRGBColorComponents(var22);
    float[] var24 = var14.getRGBColorComponents(var23);
    var1.setTickMarkPaint((java.awt.Paint)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var3 = var2.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     var2.zoomDomainAxes(2.0d, 16.0d, var6, var7);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var2);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var2.getRenderer();
//     var2.setRangeCrosshairValue(1.0d);
//     float var13 = var2.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var15 = var2.getDomainAxisForDataset(0);
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var18.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var19);
//     java.lang.Object var21 = var18.clone();
//     org.jfree.chart.util.RectangleInsets var22 = var18.getLabelOffset();
//     java.awt.Stroke var23 = var18.getOutlineStroke();
//     var2.addRangeMarker((org.jfree.chart.plot.Marker)var18);
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var26 = null;
//     var25.setBaseToolTipGenerator(var26);
//     var25.setAutoPopulateSeriesStroke(false);
//     boolean var30 = var25.getBaseItemLabelsVisible();
//     var2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var2.getRangeMarkers(var32);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var35 = var34.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     java.awt.geom.Point2D var39 = null;
//     var34.zoomDomainAxes(2.0d, 16.0d, var38, var39);
//     java.lang.Object var41 = var34.clone();
//     org.jfree.chart.axis.AxisLocation var42 = var34.getRangeAxisLocation();
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.util.RectangleEdge var47 = null;
//     double var48 = var44.lengthToJava2D((-1.0d), var46, var47);
//     java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var44.setLeftArrow(var51);
//     var44.setRangeWithMargins(Double.NaN, 0.0d);
//     org.jfree.data.Range var56 = var34.getDataRange((org.jfree.chart.axis.ValueAxis)var44);
//     org.jfree.chart.axis.AxisLocation var57 = var34.getRangeAxisLocation();
//     var2.setRangeAxisLocation(var57);
//     
//     // Checks the contract:  equals-hashcode on var19 and var34
//     assertTrue("Contract failed: equals-hashcode on var19 and var34", var19.equals(var34) ? var19.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var19
//     assertTrue("Contract failed: equals-hashcode on var34 and var19", var34.equals(var19) ? var34.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(26.0d, (-3.99999999d));
    java.lang.Number var3 = var2.getStandardDeviation();
    java.lang.Number var4 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-3.99999999d)+ "'", var3.equals((-3.99999999d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-3.99999999d)+ "'", var4.equals((-3.99999999d)));

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomDomainAxes(2.0d, 16.0d, var4, var5);
    java.awt.Paint var7 = var0.getNoDataMessagePaint();
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge();
    org.jfree.chart.util.RectangleInsets var9 = var0.getInsets();
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var0.getRenderer(1);
    org.jfree.chart.plot.CategoryMarker var12 = null;
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    org.jfree.data.Range var8 = var3.getDefaultAutoRange();
    var3.resizeRange(1.0d);
    java.awt.Stroke var11 = var3.getAxisLineStroke();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.axis.AxisState var13 = new org.jfree.chart.axis.AxisState();
    var13.setCursor(0.0d);
    java.util.List var16 = var13.getTicks();
    var13.setCursor(Double.NaN);
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    java.util.List var21 = var3.refreshTicks(var12, var13, var19, var20);
    org.jfree.chart.axis.NumberTickUnit var22 = var3.getTickUnit();
    int var23 = var22.getMinorTickCount();
    var0.add((org.jfree.chart.axis.TickUnit)var22);
    java.lang.Object var25 = var0.clone();
    int var26 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)3.0d, (java.lang.Number)(-1.0d));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1, false);
    java.awt.Paint var5 = var0.getSeriesFillPaint(10);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var9, "hi!", "");
    java.awt.Shape var13 = var12.getArea();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var15.setLeftArrow(var22);
    var12.setArea(var22);
    java.awt.Shape var25 = var12.getArea();
    var0.setBaseShape(var25, true);
    java.awt.Font var30 = var0.getItemLabelFont(100, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-246), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = null;
//     var1.setBaseURLGenerator(var2, false);
//     java.awt.Paint var6 = var1.getSeriesFillPaint(10);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var10, "hi!", "");
//     java.awt.Shape var14 = var13.getArea();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var16.lengthToJava2D((-1.0d), var18, var19);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var16.setLeftArrow(var23);
//     var13.setArea(var23);
//     java.awt.Shape var26 = var13.getArea();
//     var1.setBaseShape(var26, true);
//     java.awt.Font var31 = var1.getItemLabelFont(100, 10);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("hi!", var31);
//     org.jfree.chart.LegendItemSource var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
//     org.jfree.chart.block.BlockContainer var35 = var34.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var36 = var34.getItemLabelPadding();
//     java.lang.Object var37 = var34.clone();
//     org.jfree.chart.util.RectangleAnchor var38 = var34.getLegendItemGraphicAnchor();
//     boolean var39 = var32.equals((java.lang.Object)var38);
//     java.awt.Font var40 = var32.getFont();
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.util.Size2D var42 = var32.calculateDimensions(var41);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var2 = var1.getFont();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var7 = var6.getUpperClip();
//     var6.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.util.GradientPaintTransformer var10 = var6.getGradientPaintTransformer();
//     org.jfree.chart.labels.ItemLabelPosition var13 = var6.getPositiveItemLabelPosition(10, 100);
//     double var14 = var13.getAngle();
//     org.jfree.chart.text.TextAnchor var15 = var13.getTextAnchor();
//     var1.draw(var3, 100.0f, 2.0f, var15, 0.0f, 2.0f, 7.0d);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("RectangleAnchor.CENTER");
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    boolean var3 = var2.isDomainGridlinesVisible();
    var2.clearRangeMarkers(10);
    boolean var6 = var2.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setLabelToolTip("");
    var7.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var12 = null;
    var7.removeChangeListener(var12);
    org.jfree.chart.axis.CategoryLabelPositions var14 = var7.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var15 = new org.jfree.chart.axis.CategoryAxis[] { var7};
    var2.setDomainAxes(var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    boolean var18 = var17.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    java.awt.geom.Point2D var22 = null;
    var17.zoomDomainAxes(2.0d, 16.0d, var21, var22);
    java.lang.Object var24 = var17.clone();
    org.jfree.chart.axis.AxisLocation var25 = var17.getDomainAxisLocation();
    var2.setDomainAxisLocation(var25, false);
    var2.setRangeCrosshairValue(1.0d);
    boolean var30 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.util.RectangleEdge var32 = var2.getRangeAxisEdge(10);
    var2.setBackgroundAlpha(0.0f);
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    boolean var36 = var35.isDomainGridlinesVisible();
    var35.clearRangeMarkers(10);
    boolean var39 = var35.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis();
    var40.setLabelToolTip("");
    var40.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var45 = null;
    var40.removeChangeListener(var45);
    org.jfree.chart.axis.CategoryLabelPositions var47 = var40.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var48 = new org.jfree.chart.axis.CategoryAxis[] { var40};
    var35.setDomainAxes(var48);
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var52 = null;
    var35.addRangeMarker((org.jfree.chart.plot.Marker)var51, var52);
    org.jfree.chart.util.RectangleInsets var54 = var35.getInsets();
    var35.setForegroundAlpha((-1.0f));
    org.jfree.chart.util.PaintList var57 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var59 = var57.getPaint(15);
    java.awt.Paint var61 = var57.getPaint(255);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis();
    var62.setLabelToolTip("");
    var62.setUpperMargin((-1.0d));
    var62.setLabelURL("hi!");
    double var69 = var62.getUpperMargin();
    boolean var70 = var57.equals((java.lang.Object)var62);
    var35.setDomainAxis(var62);
    int var72 = var62.getCategoryLabelPositionOffset();
    java.util.List var73 = var2.getCategoriesForAxis(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("SortOrder.ASCENDING", var1, 117.0d, (-1.0f), 0.8f);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(-246));
    var3.setToolTipText("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var4 = var3.getAlpha();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var5.setBaseToolTipGenerator(var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var11.lengthToJava2D((-1.0d), var13, var14);
    java.awt.Shape var16 = var11.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var17 = var11.getMarkerBand();
    org.jfree.data.Range var18 = var11.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var20.lengthToJava2D((-1.0d), var22, var23);
    java.awt.Shape var25 = var20.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var26 = var20.getMarkerBand();
    org.jfree.data.Range var27 = var20.getDefaultAutoRange();
    var11.setDefaultAutoRange(var27);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var31 = var30.getStroke();
    java.awt.geom.Rectangle2D var32 = null;
    var5.drawRangeMarker(var8, var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.plot.Marker)var30, var32);
    java.awt.Stroke var34 = var5.getBaseStroke();
    org.jfree.chart.block.CenterArrangement var35 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var36 = null;
    boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, var36);
    org.jfree.chart.block.BlockContainer var38 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var35);
    var38.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var44 = var38.getPadding();
    org.jfree.chart.block.Arrangement var45 = var38.getArrangement();
    org.jfree.chart.util.RectangleInsets var46 = var38.getPadding();
    org.jfree.chart.block.LineBorder var47 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var34, var46);
    boolean var49 = var47.equals((java.lang.Object)"0,0,2,-2,2,2,2,2");
    org.jfree.chart.util.RectangleInsets var50 = var47.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setLabelToolTip("");
//     var1.setUpperMargin((-1.0d));
//     var1.setLabelURL("hi!");
//     double var8 = var1.getUpperMargin();
//     boolean var10 = var1.equals((java.lang.Object)(-1.0d));
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var13 = var11.getRangeLowerBound(false);
//     org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var11, false);
//     java.lang.Number var16 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var11);
//     int var17 = var11.getColumnCount();
//     boolean var18 = var1.equals((java.lang.Object)var11);
//     var11.add(10.0d, 0.0d, (java.lang.Comparable)(short)1, (java.lang.Comparable)"AxisLocation.BOTTOM_OR_LEFT");
//     org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var11, true);
//     org.jfree.data.Range var27 = org.jfree.data.Range.shift(var25, 100.00000001d);
//     org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(1.0E-8d, var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + Double.NaN+ "'", var16.equals(Double.NaN));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.8f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    java.awt.Paint var5 = var0.getSeriesFillPaint((-16777215));
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setSeriesToolTipGenerator(0, var7);
    var0.setBaseItemLabelsVisible(false, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var12 = var0.getBaseToolTipGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var14 = var0.getSeriesURLGenerator(100);
    java.awt.Shape var17 = var0.getItemShape((-39579), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtLeft();
    java.util.List var2 = var0.getAxesAtTop();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var3.setLabelToolTip("");
    var3.setUpperMargin((-1.0d));
    var3.setLabelURL("hi!");
    double var10 = var3.getUpperMargin();
    boolean var12 = var3.equals((java.lang.Object)(-1.0d));
    var3.setMaximumCategoryLabelLines(0);
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.block.BlockContainer var17 = var16.getItemContainer();
    var16.setNotify(false);
    org.jfree.chart.util.RectangleEdge var20 = var16.getPosition();
    var0.add((org.jfree.chart.axis.Axis)var3, var20);
    org.jfree.chart.axis.CategoryLabelPositions var22 = var3.getCategoryLabelPositions();
    org.jfree.chart.util.RectangleInsets var23 = var3.getTickLabelInsets();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
    org.jfree.data.Range var30 = var25.getDefaultAutoRange();
    var25.resizeRange(1.0d);
    java.awt.Stroke var33 = var25.getAxisLineStroke();
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.axis.AxisState var35 = new org.jfree.chart.axis.AxisState();
    var35.setCursor(0.0d);
    java.util.List var38 = var35.getTicks();
    var35.setCursor(Double.NaN);
    java.awt.geom.Rectangle2D var41 = null;
    org.jfree.chart.util.RectangleEdge var42 = null;
    java.util.List var43 = var25.refreshTicks(var34, var35, var41, var42);
    org.jfree.chart.axis.NumberTickUnit var44 = var25.getTickUnit();
    int var45 = var44.getMinorTickCount();
    java.lang.String var47 = var44.valueToString(8.0d);
    var3.removeCategoryLabelToolTip((java.lang.Comparable)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "8"+ "'", var47.equals("8"));

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "", "");
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), 10.0f, 0.0f);
    org.jfree.chart.entity.LegendItemEntity var14 = new org.jfree.chart.entity.LegendItemEntity(var13);
    var14.setURLText("CategoryLabelEntity: category=, tooltip=CategoryLabelEntity: category=, tooltip=hi!, url=, url=");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.block.BlockContainer var4 = var3.getItemContainer();
    var3.setNotify(false);
    org.jfree.chart.util.RectangleEdge var7 = var3.getPosition();
    java.awt.Paint var8 = var3.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.util.RectangleEdge var15 = null;
    double var16 = var12.lengthToJava2D((-1.0d), var14, var15);
    org.jfree.data.Range var17 = var12.getDefaultAutoRange();
    org.jfree.data.Range var19 = null;
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(0.0d, var19);
    org.jfree.chart.block.RectangleConstraint var22 = var20.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var24 = var22.toFixedHeight((-1.0d));
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var26.lengthToJava2D((-1.0d), var28, var29);
    org.jfree.data.Range var31 = var26.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var32 = var24.toRangeWidth(var31);
    org.jfree.data.Range var33 = org.jfree.data.Range.combine(var17, var31);
    var10.setRange(var17);
    java.awt.Font var35 = var10.getLabelFont();
    var3.setItemFont(var35);
    org.jfree.chart.text.TextLine var37 = new org.jfree.chart.text.TextLine("Size2D[width=100.0, height=2.0]", var35);
    org.jfree.chart.text.TextLine var38 = new org.jfree.chart.text.TextLine("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", var35);
    org.jfree.chart.text.TextFragment var39 = var38.getFirstTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.data.Range var2 = var1.getRange();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.data.Range var4 = var1.getDefaultAutoRange();
    var1.resizeRange((-25.199999999999996d));
    java.lang.String var7 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + ""+ "'", var7.equals(""));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    java.awt.Paint var5 = var0.getSeriesFillPaint((-16777215));
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setSeriesToolTipGenerator(0, var7);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    boolean var10 = var9.isDomainGridlinesVisible();
    var9.clearRangeMarkers(10);
    var9.clearRangeMarkers();
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var9);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    boolean var16 = var15.isDomainGridlinesVisible();
    var15.clearRangeMarkers(10);
    boolean var19 = var15.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
    var20.setLabelToolTip("");
    var20.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var25 = null;
    var20.removeChangeListener(var25);
    org.jfree.chart.axis.CategoryLabelPositions var27 = var20.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var28 = new org.jfree.chart.axis.CategoryAxis[] { var20};
    var15.setDomainAxes(var28);
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var32 = null;
    var15.addRangeMarker((org.jfree.chart.plot.Marker)var31, var32);
    org.jfree.chart.util.RectangleInsets var34 = var15.getInsets();
    var15.setForegroundAlpha((-1.0f));
    org.jfree.chart.axis.CategoryAnchor var37 = var15.getDomainGridlinePosition();
    var9.setDomainGridlinePosition(var37);
    java.lang.String var39 = var37.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "CategoryAnchor.MIDDLE"+ "'", var39.equals("CategoryAnchor.MIDDLE"));

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var1.setLeftArrow(var8);
    var1.setRangeWithMargins(Double.NaN, 0.0d);
    var1.setTickLabelsVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var15.setBaseURLGenerator(var16, false);
    java.awt.Paint var20 = var15.getSeriesFillPaint(10);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var27 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var24, "hi!", "");
    java.awt.Shape var28 = var27.getArea();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.util.RectangleEdge var33 = null;
    double var34 = var30.lengthToJava2D((-1.0d), var32, var33);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var30.setLeftArrow(var37);
    var27.setArea(var37);
    java.awt.Shape var40 = var27.getArea();
    var15.setBaseShape(var40, true);
    java.awt.Font var45 = var15.getItemLabelFont(100, 10);
    var1.setLabelFont(var45);
    var1.setAutoRange(true);
    boolean var49 = var1.isAutoRange();
    org.jfree.chart.axis.TickUnits var50 = new org.jfree.chart.axis.TickUnits();
    int var51 = var50.size();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.util.RectangleEdge var56 = null;
    double var57 = var53.lengthToJava2D((-1.0d), var55, var56);
    org.jfree.data.Range var58 = var53.getDefaultAutoRange();
    var53.resizeRange(1.0d);
    java.awt.Stroke var61 = var53.getAxisLineStroke();
    java.awt.Graphics2D var62 = null;
    org.jfree.chart.axis.AxisState var63 = new org.jfree.chart.axis.AxisState();
    var63.setCursor(0.0d);
    java.util.List var66 = var63.getTicks();
    var63.setCursor(Double.NaN);
    java.awt.geom.Rectangle2D var69 = null;
    org.jfree.chart.util.RectangleEdge var70 = null;
    java.util.List var71 = var53.refreshTicks(var62, var63, var69, var70);
    org.jfree.chart.axis.NumberTickUnit var72 = var53.getTickUnit();
    int var73 = var72.getMinorTickCount();
    var50.add((org.jfree.chart.axis.TickUnit)var72);
    org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var78 = null;
    org.jfree.chart.util.RectangleEdge var79 = null;
    double var80 = var76.lengthToJava2D((-1.0d), var78, var79);
    org.jfree.data.Range var81 = var76.getDefaultAutoRange();
    var76.resizeRange(1.0d);
    java.awt.Stroke var84 = var76.getAxisLineStroke();
    java.awt.Graphics2D var85 = null;
    org.jfree.chart.axis.AxisState var86 = new org.jfree.chart.axis.AxisState();
    var86.setCursor(0.0d);
    java.util.List var89 = var86.getTicks();
    var86.setCursor(Double.NaN);
    java.awt.geom.Rectangle2D var92 = null;
    org.jfree.chart.util.RectangleEdge var93 = null;
    java.util.List var94 = var76.refreshTicks(var85, var86, var92, var93);
    org.jfree.chart.axis.NumberTickUnit var95 = var76.getTickUnit();
    var50.add((org.jfree.chart.axis.TickUnit)var95);
    int var97 = var95.getMinorTickCount();
    var1.setTickUnit(var95);
    boolean var99 = var1.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == false);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    double var2 = var0.getRangeCrosshairValue();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.ChartColor var7 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var8 = var7.getAlpha();
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var9.setBaseToolTipGenerator(var10);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var24.lengthToJava2D((-1.0d), var26, var27);
    java.awt.Shape var29 = var24.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var30 = var24.getMarkerBand();
    org.jfree.data.Range var31 = var24.getDefaultAutoRange();
    var15.setDefaultAutoRange(var31);
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var35 = var34.getStroke();
    java.awt.geom.Rectangle2D var36 = null;
    var9.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.plot.Marker)var34, var36);
    java.awt.Stroke var38 = var9.getBaseStroke();
    org.jfree.chart.block.CenterArrangement var39 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var40 = null;
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var39, var40);
    org.jfree.chart.block.BlockContainer var42 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var39);
    var42.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var48 = var42.getPadding();
    org.jfree.chart.block.Arrangement var49 = var42.getArrangement();
    org.jfree.chart.util.RectangleInsets var50 = var42.getPadding();
    org.jfree.chart.block.LineBorder var51 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var7, var38, var50);
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.util.RectangleEdge var56 = null;
    double var57 = var53.lengthToJava2D((-1.0d), var55, var56);
    java.awt.Shape var58 = var53.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var59 = var53.getMarkerBand();
    var53.setRange(0.0d, 1.0d);
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var69 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var66, "hi!", "");
    java.awt.Shape var70 = var69.getArea();
    var53.setDownArrow(var70);
    boolean var72 = var50.equals((java.lang.Object)var70);
    org.jfree.chart.LegendItemSource var73 = null;
    org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
    boolean var75 = var74.getNotify();
    java.awt.geom.Rectangle2D var76 = var74.getBounds();
    java.awt.geom.Rectangle2D var77 = var50.createOutsetRectangle(var76);
    var3.setPadding(var50);
    java.lang.Object var79 = var3.getTextAntiAlias();
    var3.clearSubtitles();
    var3.clearSubtitles();
    org.jfree.chart.title.LegendTitle var83 = var3.getLegend(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(-7471090));
    org.jfree.data.KeyedObjects var3 = new org.jfree.data.KeyedObjects();
    java.lang.Object var5 = var3.getObject(0);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var7.lengthToJava2D((-1.0d), var9, var10);
    org.jfree.data.Range var12 = var7.getDefaultAutoRange();
    var7.resizeRange(1.0d);
    java.awt.Stroke var15 = var7.getAxisLineStroke();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.axis.AxisState var17 = new org.jfree.chart.axis.AxisState();
    var17.setCursor(0.0d);
    java.util.List var20 = var17.getTicks();
    var17.setCursor(Double.NaN);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    java.util.List var25 = var7.refreshTicks(var16, var17, var23, var24);
    org.jfree.chart.axis.NumberTickUnit var26 = var7.getTickUnit();
    org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = null;
    var27.setBaseToolTipGenerator(var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = null;
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var33.lengthToJava2D((-1.0d), var35, var36);
    java.awt.Shape var38 = var33.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var39 = var33.getMarkerBand();
    org.jfree.data.Range var40 = var33.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleEdge var45 = null;
    double var46 = var42.lengthToJava2D((-1.0d), var44, var45);
    java.awt.Shape var47 = var42.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var48 = var42.getMarkerBand();
    org.jfree.data.Range var49 = var42.getDefaultAutoRange();
    var33.setDefaultAutoRange(var49);
    org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var53 = var52.getStroke();
    java.awt.geom.Rectangle2D var54 = null;
    var27.drawRangeMarker(var30, var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.plot.Marker)var52, var54);
    org.jfree.chart.plot.Plot var56 = null;
    var33.setPlot(var56);
    org.jfree.chart.axis.NumberTickUnit var58 = var33.getTickUnit();
    double var59 = var58.getSize();
    var7.setTickUnit(var58);
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var64 = null;
    org.jfree.chart.util.RectangleEdge var65 = null;
    double var66 = var62.lengthToJava2D((-1.0d), var64, var65);
    org.jfree.data.Range var67 = var62.getDefaultAutoRange();
    var62.resizeRange(1.0d);
    boolean var70 = var62.isTickLabelsVisible();
    boolean var71 = var62.isInverted();
    java.awt.Shape var72 = var62.getDownArrow();
    org.jfree.chart.entity.LegendItemEntity var73 = new org.jfree.chart.entity.LegendItemEntity(var72);
    java.lang.Object var74 = var73.clone();
    var3.addObject((java.lang.Comparable)var58, var74);
    int var76 = var0.getRowIndex((java.lang.Comparable)var58);
    int var77 = var0.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.Layer var17 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var16, var17);
    org.jfree.chart.util.RectangleInsets var19 = var0.getInsets();
    var0.setForegroundAlpha((-1.0f));
    java.awt.Paint var22 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var24 = var0.getRangeAxis(100);
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    boolean var28 = var27.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    java.awt.geom.Point2D var32 = null;
    var27.zoomDomainAxes(2.0d, 16.0d, var31, var32);
    var26.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = var27.getRenderer();
    var27.setRangeCrosshairValue(1.0d);
    float var38 = var27.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var40 = var27.getDomainAxisForDataset(0);
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var27);
    org.jfree.chart.plot.DrawingSupplier var42 = var27.getDrawingSupplier();
    org.jfree.data.category.CategoryDataset var44 = var27.getDataset(255);
    org.jfree.chart.plot.Plot var45 = var27.getRootPlot();
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
    boolean var48 = var47.isDomainGridlinesVisible();
    var47.clearRangeMarkers(10);
    boolean var51 = var47.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
    var52.setLabelToolTip("");
    var52.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var57 = null;
    var52.removeChangeListener(var57);
    org.jfree.chart.axis.CategoryLabelPositions var59 = var52.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var60 = new org.jfree.chart.axis.CategoryAxis[] { var52};
    var47.setDomainAxes(var60);
    org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
    boolean var63 = var62.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var66 = null;
    java.awt.geom.Point2D var67 = null;
    var62.zoomDomainAxes(2.0d, 16.0d, var66, var67);
    java.lang.Object var69 = var62.clone();
    org.jfree.chart.axis.AxisLocation var70 = var62.getDomainAxisLocation();
    var47.setDomainAxisLocation(var70, false);
    var27.setRangeAxisLocation(4, var70, true);
    org.jfree.chart.axis.AxisLocation var75 = var70.getOpposite();
    org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var79 = null;
    org.jfree.chart.util.RectangleEdge var80 = null;
    double var81 = var77.lengthToJava2D((-1.0d), var79, var80);
    java.awt.Shape var82 = var77.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var85 = new org.jfree.chart.entity.TickLabelEntity(var82, "", "");
    java.lang.String var86 = var85.getShapeCoords();
    java.lang.String var87 = var85.getToolTipText();
    org.jfree.chart.JFreeChart var88 = null;
    org.jfree.chart.event.ChartChangeEventType var89 = null;
    org.jfree.chart.event.ChartChangeEvent var90 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var85, var88, var89);
    boolean var91 = var70.equals((java.lang.Object)var85);
    var0.setDomainAxisLocation(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var86 + "' != '" + "0,0,2,-2,2,2,2,2"+ "'", var86.equals("0,0,2,-2,2,2,2,2"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var87 + "' != '" + ""+ "'", var87.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.awt.Stroke var2 = var0.getBaseStroke();
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition((-16777215), 10);
    org.jfree.chart.labels.ItemLabelAnchor var6 = var5.getItemLabelAnchor();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    boolean var8 = var7.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var7.zoomDomainAxes(2.0d, 16.0d, var11, var12);
    java.awt.Paint var14 = var7.getNoDataMessagePaint();
    var7.setForegroundAlpha(0.0f);
    java.util.List var17 = var7.getCategories();
    float var18 = var7.getBackgroundImageAlpha();
    var7.setNoDataMessage("java.awt.Color[r=0,g=0,b=1]");
    boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var7);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    var22.setURLText("RangeType.FULL");
    java.awt.Paint var25 = var22.getBackgroundPaint();
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var27 = var26.getBaseSeriesVisibleInLegend();
    org.jfree.chart.annotations.CategoryAnnotation var28 = null;
    boolean var29 = var26.removeAnnotation(var28);
    java.awt.Stroke var31 = var26.lookupSeriesStroke((-1));
    java.awt.Paint var34 = var26.getItemFillPaint(15, 100);
    var22.setPaint(var34);
    var7.setOutlinePaint(var34);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var40 = var37.getURLGenerator(0, 100);
    org.jfree.chart.labels.ItemLabelPosition var41 = var37.getBaseNegativeItemLabelPosition();
    int var42 = var7.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
    org.jfree.chart.plot.Plot var43 = var7.getParent();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(3.0d, 16.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var4.lengthToJava2D((-1.0d), var6, var7);
    java.awt.Shape var9 = var4.getLeftArrow();
    org.jfree.chart.entity.TickLabelEntity var12 = new org.jfree.chart.entity.TickLabelEntity(var9, "", "");
    boolean var13 = var2.equals((java.lang.Object)var9);
    org.jfree.chart.block.LineBorder var14 = new org.jfree.chart.block.LineBorder();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
    boolean var19 = var14.equals((java.lang.Object)var18);
    java.awt.Paint var20 = var14.getPaint();
    java.awt.Paint var21 = var14.getPaint();
    org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic(var9, var21);
    boolean var23 = var22.isShapeVisible();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleEdge var30 = null;
    double var31 = var27.lengthToJava2D((-1.0d), var29, var30);
    java.awt.Shape var32 = var27.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var33 = var27.getMarkerBand();
    var27.setRange(0.0d, 1.0d);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var43 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var40, "hi!", "");
    java.awt.Shape var44 = var43.getArea();
    var27.setDownArrow(var44);
    var25.setUpArrow(var44);
    var22.setShape(var44);
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var48.setBaseToolTipGenerator(var49);
    var48.setAutoPopulateSeriesStroke(false);
    boolean var53 = var48.getBaseSeriesVisibleInLegend();
    boolean var54 = var48.getAutoPopulateSeriesOutlinePaint();
    java.lang.Boolean var56 = var48.getSeriesCreateEntities(10);
    boolean var57 = var22.equals((java.lang.Object)var48);
    java.awt.Paint var59 = var48.getSeriesOutlinePaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    boolean var1 = var0.getBaseSeriesVisible();
    java.awt.Stroke var3 = var0.getSeriesStroke((-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var2);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var5.lengthToJava2D((-1.0d), var7, var8);
//     var5.setAutoRange(false);
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var13 = var12.getUpperClip();
//     java.awt.Stroke var14 = var12.getBaseStroke();
//     var5.setTickMarkStroke(var14);
//     var1.setStroke(var14);
//     double var17 = var1.getValue();
//     org.jfree.chart.util.RectangleInsets var18 = var1.getLabelOffset();
//     java.awt.Font var19 = var1.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var21 = var20.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var23.lengthToJava2D((-1.0d), var25, var26);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var23.setLeftArrow(var30);
//     var23.setRangeWithMargins(Double.NaN, 0.0d);
//     var23.setTickLabelsVisible(true);
//     int var37 = var20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var23);
//     java.awt.Stroke var38 = var20.getDomainGridlineStroke();
//     var1.setStroke(var38);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0");
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    var1.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    java.lang.Object var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    double var2 = var1.getUpperClip();
    java.awt.Paint var5 = var1.getItemPaint(4, 10);
    boolean var6 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var1);
    boolean var7 = var1.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.setMax(10.0d);
    double var3 = var0.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.ItemLabelPosition var4 = var0.getPositiveItemLabelPosition((-16777215), 1);
    org.jfree.chart.labels.ItemLabelAnchor var5 = var4.getItemLabelAnchor();
    org.jfree.chart.text.TextAnchor var6 = var4.getTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    var1.setAutoRangeMinimumSize(100.0d);
    var1.configure();
    var1.setVisible(true);
    var1.setInverted(true);
    java.awt.Paint var14 = var1.getLabelPaint();
    org.jfree.chart.axis.TickUnitSource var15 = var1.getStandardTickUnits();
    java.text.NumberFormat var16 = var1.getNumberFormatOverride();
    java.awt.Shape var17 = var1.getDownArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Comparable var2 = var0.getKey(4);
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var8 = var7.brighter();
    boolean var10 = var7.equals((java.lang.Object)(short)100);
    var4.setPaint((java.awt.Paint)var7);
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var7);
    java.awt.Color var13 = var7.brighter();
    boolean var14 = var0.equals((java.lang.Object)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(101);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1, false);
    java.awt.Paint var5 = var0.getSeriesFillPaint(10);
    boolean var8 = var0.isItemLabelVisible(0, (-16777215));
    boolean var10 = var0.isSeriesItemLabelsVisible((-1));
    boolean var12 = var0.isSeriesVisibleInLegend(0);
    org.jfree.chart.LegendItemCollection var13 = var0.getLegendItems();
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = var0.getToolTipGenerator(10, (-16777215));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.util.Iterator var1 = var0.iterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var3 = var0.get(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }
// 
// 
//     org.jfree.chart.plot.PlotRenderingInfo var0 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
//     org.jfree.chart.entity.EntityCollection var2 = var1.getEntityCollection();
//     double var3 = var1.getBarWidth();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var5 = var4.isDomainGridlinesVisible();
//     double var6 = var4.getRangeCrosshairValue();
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.util.List var8 = var7.getSubtitles();
//     boolean var9 = var7.isNotify();
//     var7.setBackgroundImageAlignment(10);
//     org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var7);
//     org.jfree.chart.event.ChartChangeEventType var13 = var12.getType();
//     org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.awt.Stroke var16 = var15.getStroke();
//     java.awt.Stroke var17 = var15.getOutlineStroke();
//     org.jfree.chart.LegendItemSource var18 = null;
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
//     org.jfree.chart.block.BlockContainer var20 = var19.getItemContainer();
//     var19.setNotify(false);
//     java.awt.Color var25 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var26 = var25.brighter();
//     java.awt.Color var27 = var25.brighter();
//     var19.setItemPaint((java.awt.Paint)var25);
//     var15.setOutlinePaint((java.awt.Paint)var25);
//     java.awt.Stroke var30 = var15.getOutlineStroke();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var32 = var31.isDomainGridlinesVisible();
//     var31.clearRangeMarkers(10);
//     boolean var35 = var31.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     var36.setLabelToolTip("");
//     var36.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var41 = null;
//     var36.removeChangeListener(var41);
//     org.jfree.chart.axis.CategoryLabelPositions var43 = var36.getCategoryLabelPositions();
//     org.jfree.chart.axis.CategoryAxis[] var44 = new org.jfree.chart.axis.CategoryAxis[] { var36};
//     var31.setDomainAxes(var44);
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.Layer var48 = null;
//     var31.addRangeMarker((org.jfree.chart.plot.Marker)var47, var48);
//     org.jfree.chart.util.RectangleInsets var50 = var31.getInsets();
//     var31.setForegroundAlpha((-1.0f));
//     org.jfree.chart.axis.AxisLocation var54 = var31.getRangeAxisLocation((-1));
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var56.getCategoryStart(10, (-16777215), var59, var60);
//     java.awt.Font var63 = null;
//     var56.setTickLabelFont((java.lang.Comparable)1, var63);
//     var31.setDomainAxis(0, var56);
//     var15.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var31);
//     org.jfree.chart.renderer.category.BarRenderer var67 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var68 = var67.getUpperClip();
//     boolean var69 = var67.getBaseSeriesVisible();
//     boolean var70 = var67.getAutoPopulateSeriesOutlinePaint();
//     java.awt.Color var74 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var75 = var74.brighter();
//     java.awt.Color var76 = var74.brighter();
//     var67.setSeriesOutlinePaint(10, (java.awt.Paint)var74, false);
//     var31.setBackgroundPaint((java.awt.Paint)var74);
//     boolean var80 = var13.equals((java.lang.Object)var31);
//     var31.zoom(100.0d);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var2.setLeftArrow(var9);
    var2.setRangeWithMargins(Double.NaN, 0.0d);
    var2.setTickLabelsVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var16.setBaseURLGenerator(var17, false);
    java.awt.Paint var21 = var16.getSeriesFillPaint(10);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var25, "hi!", "");
    java.awt.Shape var29 = var28.getArea();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var31.setLeftArrow(var38);
    var28.setArea(var38);
    java.awt.Shape var41 = var28.getArea();
    var16.setBaseShape(var41, true);
    java.awt.Font var46 = var16.getItemLabelFont(100, 10);
    var2.setLabelFont(var46);
    java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, (java.awt.Paint)var50);
    java.awt.Color var52 = var50.darker();
    int var53 = var52.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    double var1 = var0.getBottom();
    var0.setRight(0.2d);
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    var0.ensureAtLeast(var4);
    java.lang.Object var6 = var0.clone();
    var0.setLeft(0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    java.lang.Object var2 = var0.clone();
    var0.setItemMargin(0.0d);
    java.awt.Stroke var7 = var0.getItemStroke((-7471090), 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var2.setLeftArrow(var9);
    var2.setRangeWithMargins(Double.NaN, 0.0d);
    var2.setTickLabelsVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var16.setBaseURLGenerator(var17, false);
    java.awt.Paint var21 = var16.getSeriesFillPaint(10);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var25, "hi!", "");
    java.awt.Shape var29 = var28.getArea();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var31.setLeftArrow(var38);
    var28.setArea(var38);
    java.awt.Shape var41 = var28.getArea();
    var16.setBaseShape(var41, true);
    java.awt.Font var46 = var16.getItemLabelFont(100, 10);
    var2.setLabelFont(var46);
    java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, (java.awt.Paint)var50);
    java.awt.Graphics2D var52 = null;
    org.jfree.chart.util.Size2D var53 = var51.calculateDimensions(var52);
    org.jfree.chart.text.TextLine var54 = null;
    var51.addLine(var54);
    org.jfree.chart.util.HorizontalAlignment var56 = var51.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var57 = null;
    org.jfree.chart.block.FlowArrangement var60 = new org.jfree.chart.block.FlowArrangement(var56, var57, 10.0d, 0.0d);
    org.jfree.chart.LegendItemSource var61 = null;
    org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle(var61);
    org.jfree.chart.block.BlockContainer var63 = var62.getItemContainer();
    var62.setNotify(false);
    org.jfree.chart.event.TitleChangeListener var66 = null;
    var62.removeChangeListener(var66);
    org.jfree.chart.util.VerticalAlignment var68 = var62.getVerticalAlignment();
    org.jfree.chart.block.FlowArrangement var71 = new org.jfree.chart.block.FlowArrangement(var56, var68, 88.0d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("java.awt.Color[r=0,g=0,b=1]", var1);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Paint var2 = var1.getPaint();
//     float var3 = var1.getBaselineOffset();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var6 = var5.getUpperClip();
//     var5.setAutoPopulateSeriesOutlineStroke(false);
//     java.awt.Paint var10 = var5.getSeriesFillPaint((-16777215));
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var12 = null;
//     var11.setBaseURLGenerator(var12, false);
//     java.awt.Paint var16 = var11.getSeriesFillPaint(10);
//     var11.setAutoPopulateSeriesStroke(false);
//     org.jfree.chart.labels.ItemLabelPosition var19 = new org.jfree.chart.labels.ItemLabelPosition();
//     var11.setPositiveItemLabelPositionFallback(var19);
//     var5.setBasePositiveItemLabelPosition(var19, true);
//     org.jfree.chart.text.TextAnchor var23 = var19.getTextAnchor();
//     float var24 = var1.calculateBaselineOffset(var4, var23);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.JFreeChart var2 = null;
    org.jfree.chart.event.ChartProgressEvent var5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)100.0d, var2, 100, (-1));
    int var6 = var5.getPercent();
    int var7 = var5.getPercent();
    int var8 = var5.getType();
    int var9 = var5.getPercent();
    org.jfree.chart.JFreeChart var10 = null;
    var5.setChart(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Shape var6 = var5.getDownArrow();
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, Double.NaN, 1.0f, 100.0f);
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var17 = var16.getStroke();
    java.awt.Stroke var18 = var16.getOutlineStroke();
    org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var23 = var22.getAlpha();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "0,0,2,-2,2,2,2,2", "", var10, (java.awt.Paint)var13, var18, (java.awt.Paint)var22);
    java.awt.Paint var25 = var24.getOutlinePaint();
    java.awt.Paint var26 = var24.getOutlinePaint();
    int var27 = var24.getDatasetIndex();
    java.lang.String var28 = var24.getLabel();
    java.lang.String var29 = var24.getDescription();
    var24.setDatasetIndex(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "hi!"+ "'", var28.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0"+ "'", var29.equals("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0"));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    var0.clear();
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.block.BlockContainer var4 = var3.getItemContainer();
    org.jfree.chart.util.RectangleInsets var5 = var3.getItemLabelPadding();
    java.lang.Object var6 = var3.clone();
    org.jfree.chart.util.RectangleEdge var7 = var3.getPosition();
    org.jfree.data.Range var9 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(0.0d, var9);
    org.jfree.chart.block.RectangleConstraint var12 = var10.toFixedHeight(0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = var12.toFixedHeight((-1.0d));
    org.jfree.chart.block.RectangleConstraint var16 = var14.toFixedHeight(Double.NaN);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var18.lengthToJava2D((-1.0d), var20, var21);
    java.awt.Shape var23 = var18.getLeftArrow();
    org.jfree.data.Range var24 = var18.getRange();
    org.jfree.chart.block.RectangleConstraint var25 = var14.toRangeWidth(var24);
    var0.add((org.jfree.chart.block.Block)var3, (java.lang.Object)var25);
    org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Color var32 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var33 = var32.brighter();
    boolean var35 = var32.equals((java.lang.Object)(short)100);
    var29.setPaint((java.awt.Paint)var32);
    org.jfree.chart.LegendItemSource var37 = null;
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
    boolean var39 = var38.getNotify();
    java.awt.Font var40 = var38.getItemFont();
    var29.setFont(var40);
    org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("NOID", var40);
    boolean var43 = var42.getNotify();
    java.awt.Paint var44 = var42.getBackgroundPaint();
    java.awt.Color var47 = java.awt.Color.getColor("CategoryLabelEntity: category=, tooltip=CategoryLabelEntity: category=, tooltip=hi!, url=, url=", 0);
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var49 = null;
    var48.setBaseURLGenerator(var49, false);
    java.awt.Paint var53 = var48.getSeriesFillPaint(10);
    var48.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.labels.ItemLabelPosition var56 = new org.jfree.chart.labels.ItemLabelPosition();
    var48.setPositiveItemLabelPositionFallback(var56);
    boolean var58 = var47.equals((java.lang.Object)var48);
    var0.add((org.jfree.chart.block.Block)var42, (java.lang.Object)var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.block.BlockContainer var2 = var1.getItemContainer();
    var1.setNotify(false);
    org.jfree.chart.util.RectangleInsets var5 = var1.getItemLabelPadding();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var6.setLabelToolTip("");
    var6.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var11 = null;
    var6.removeChangeListener(var11);
    org.jfree.chart.axis.CategoryLabelPositions var13 = var6.getCategoryLabelPositions();
    org.jfree.chart.LegendItemSource var14 = null;
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
    boolean var16 = var15.getNotify();
    double var17 = var15.getWidth();
    org.jfree.chart.util.RectangleEdge var18 = var15.getLegendItemGraphicEdge();
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var19.getCategoryStart(10, (-16777215), var22, var23);
    java.awt.Font var26 = null;
    var19.setTickLabelFont((java.lang.Comparable)1, var26);
    java.lang.String var28 = var19.getLabel();
    org.jfree.chart.axis.CategoryAnchor var29 = null;
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.LegendItemSource var33 = null;
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
    boolean var35 = var34.getNotify();
    double var36 = var34.getWidth();
    org.jfree.chart.util.RectangleEdge var37 = var34.getLegendItemGraphicEdge();
    double var38 = var19.getCategoryJava2DCoordinate(var29, (-1), (-16777215), var32, var37);
    var15.setLegendItemGraphicEdge(var37);
    org.jfree.chart.axis.CategoryLabelPosition var40 = var13.getLabelPosition(var37);
    var1.setLegendItemGraphicEdge(var37);
    java.awt.Paint var42 = var1.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "LegendItemEntity: seriesKey=null, dataset=null");
    java.lang.String var3 = var2.getEmail();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var3.equals("LegendItemEntity: seriesKey=null, dataset=null"));

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    boolean var3 = var2.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var2.zoomDomainAxes(2.0d, 16.0d, var6, var7);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var2);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var2.getRenderer();
    var2.setRangeCrosshairValue(1.0d);
    float var13 = var2.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var15 = var2.getDomainAxisForDataset(0);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.plot.DrawingSupplier var17 = var2.getDrawingSupplier();
    org.jfree.data.category.CategoryDataset var19 = var2.getDataset(255);
    org.jfree.chart.plot.Plot var20 = var2.getRootPlot();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.brighter();
    java.awt.Color var26 = java.awt.Color.getColor("poly", var24);
    var20.setNoDataMessagePaint((java.awt.Paint)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var6.lengthToJava2D((-1.0d), var8, var9);
    java.awt.Shape var11 = var6.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var12 = var6.getMarkerBand();
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var20 = var15.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var21 = var15.getMarkerBand();
    org.jfree.data.Range var22 = var15.getDefaultAutoRange();
    var6.setDefaultAutoRange(var22);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var26 = var25.getStroke();
    java.awt.geom.Rectangle2D var27 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var25, var27);
    java.awt.Stroke var29 = var0.getBaseStroke();
    org.jfree.chart.labels.ItemLabelPosition var30 = var0.getPositiveItemLabelPositionFallback();
    java.awt.Paint var32 = var0.lookupSeriesFillPaint((-7471090));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    boolean var1 = var0.getBaseSeriesVisible();
    java.awt.Font var3 = var0.getSeriesItemLabelFont(0);
    double var4 = var0.getItemLabelAnchorOffset();
    double var5 = var0.getBase();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var8 = var6.lookupSeriesStroke(255);
    var0.setBaseOutlineStroke(var8);
    org.jfree.chart.LegendItem var12 = var0.getLegendItem(255, 0);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Paint var15 = var0.getBasePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.lang.Object var2 = var1.clone();
    int var3 = var1.getSubplotCount();
    org.jfree.chart.ChartRenderingInfo var4 = var1.getOwner();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var6 = var1.getSubplotInfo(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Shape var6 = var5.getDownArrow();
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, Double.NaN, 1.0f, 100.0f);
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var13);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var17 = var16.getStroke();
    java.awt.Stroke var18 = var16.getOutlineStroke();
    org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var23 = var22.getAlpha();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0", "0,0,2,-2,2,2,2,2", "", var10, (java.awt.Paint)var13, var18, (java.awt.Paint)var22);
    java.awt.Paint var25 = var24.getOutlinePaint();
    org.jfree.data.general.Dataset var26 = var24.getDataset();
    java.awt.Paint var27 = var24.getOutlinePaint();
    boolean var28 = var24.isShapeOutlineVisible();
    java.awt.Shape var29 = var24.getLine();
    org.jfree.data.general.Dataset var30 = var24.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }


    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    boolean var5 = var4.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var7.lengthToJava2D((-1.0d), var9, var10);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var7.setLeftArrow(var14);
    var7.setRangeWithMargins(Double.NaN, 0.0d);
    var7.setTickLabelsVisible(true);
    int var21 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var7);
    java.awt.Paint var22 = var4.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    double var24 = var23.getUpperClip();
    var4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    boolean var27 = var26.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    double var33 = var29.lengthToJava2D((-1.0d), var31, var32);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var29.setLeftArrow(var36);
    var29.setRangeWithMargins(Double.NaN, 0.0d);
    var29.setTickLabelsVisible(true);
    int var43 = var26.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
    java.awt.Paint var44 = var26.getRangeGridlinePaint();
    var4.setDomainGridlinePaint(var44);
    var4.setRangeCrosshairVisible(false);
    java.awt.Graphics2D var48 = null;
    org.jfree.chart.LegendItemSource var49 = null;
    org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle(var49);
    boolean var51 = var50.getNotify();
    java.awt.geom.Rectangle2D var52 = var50.getBounds();
    org.jfree.chart.plot.PlotRenderingInfo var54 = null;
    boolean var55 = var4.render(var48, var52, 0, var54);
    java.awt.geom.Point2D var56 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.2d, (-1.0d), var52);
    java.awt.geom.Point2D var57 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(10.0d, 10.0d, var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    var0.clearRangeMarkers(10);
    boolean var4 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setLabelToolTip("");
    var5.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var5.removeChangeListener(var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var5.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis[] var13 = new org.jfree.chart.axis.CategoryAxis[] { var5};
    var0.setDomainAxes(var13);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    boolean var16 = var15.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var15.zoomDomainAxes(2.0d, 16.0d, var19, var20);
    java.lang.Object var22 = var15.clone();
    org.jfree.chart.axis.AxisLocation var23 = var15.getDomainAxisLocation();
    var0.setDomainAxisLocation(var23, false);
    var0.setAnchorValue(1.0E-8d);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var29 = null;
    var28.setBaseToolTipGenerator(var29);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = null;
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    double var38 = var34.lengthToJava2D((-1.0d), var36, var37);
    java.awt.Shape var39 = var34.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var40 = var34.getMarkerBand();
    org.jfree.data.Range var41 = var34.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var45 = null;
    org.jfree.chart.util.RectangleEdge var46 = null;
    double var47 = var43.lengthToJava2D((-1.0d), var45, var46);
    java.awt.Shape var48 = var43.getLeftArrow();
    org.jfree.chart.axis.MarkerAxisBand var49 = var43.getMarkerBand();
    org.jfree.data.Range var50 = var43.getDefaultAutoRange();
    var34.setDefaultAutoRange(var50);
    org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Stroke var54 = var53.getStroke();
    java.awt.geom.Rectangle2D var55 = null;
    var28.drawRangeMarker(var31, var32, (org.jfree.chart.axis.ValueAxis)var34, (org.jfree.chart.plot.Marker)var53, var55);
    org.jfree.chart.labels.CategoryToolTipGenerator var58 = null;
    var28.setSeriesToolTipGenerator(4, var58, false);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    boolean var64 = var28.getItemCreateEntity((-16777215), (-16777215));
    java.awt.Stroke var66 = var28.getSeriesStroke((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    java.awt.Paint var5 = var0.getSeriesFillPaint((-16777215));
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var6.setBaseURLGenerator(var7, false);
    java.awt.Paint var11 = var6.getSeriesFillPaint(10);
    var6.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.labels.ItemLabelPosition var14 = new org.jfree.chart.labels.ItemLabelPosition();
    var6.setPositiveItemLabelPositionFallback(var14);
    var0.setBasePositiveItemLabelPosition(var14, true);
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var20 = var19.getBaseSeriesVisibleInLegend();
    org.jfree.chart.annotations.CategoryAnnotation var21 = null;
    boolean var22 = var19.removeAnnotation(var21);
    java.awt.Stroke var24 = var19.lookupSeriesStroke((-1));
    org.jfree.chart.urls.CategoryURLGenerator var26 = null;
    var19.setSeriesURLGenerator(255, var26, true);
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    double var31 = var30.getUpperClip();
    java.lang.Boolean var33 = null;
    var30.setSeriesItemLabelsVisible(100, var33, true);
    org.jfree.chart.util.GradientPaintTransformer var36 = var30.getGradientPaintTransformer();
    org.jfree.chart.ChartColor var40 = new org.jfree.chart.ChartColor(100, 0, 10);
    var30.setBasePaint((java.awt.Paint)var40, false);
    var19.setSeriesFillPaint(100, (java.awt.Paint)var40);
    var0.setSeriesOutlinePaint(255, (java.awt.Paint)var40, false);
    java.lang.Boolean var47 = var0.getSeriesCreateEntities((-1));
    var0.setMaximumBarWidth(0.0d);
    java.awt.Paint var51 = var0.getSeriesItemLabelPaint((-39579));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1, false);
    java.awt.Paint var5 = var0.getSeriesFillPaint(10);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var9, "hi!", "");
    java.awt.Shape var13 = var12.getArea();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.lengthToJava2D((-1.0d), var17, var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var15.setLeftArrow(var22);
    var12.setArea(var22);
    java.awt.Shape var25 = var12.getArea();
    var0.setBaseShape(var25, true);
    java.awt.Font var30 = var0.getItemLabelFont(100, 10);
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var32 = var31.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.ItemLabelPosition var35 = var31.getPositiveItemLabelPosition((-16777215), 1);
    org.jfree.chart.labels.ItemLabelPosition var38 = var31.getNegativeItemLabelPosition(0, (-1));
    var0.setBasePositiveItemLabelPosition(var38, false);
    double var41 = var38.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var2.lengthToJava2D((-1.0d), var4, var5);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var2.setLeftArrow(var9);
//     var2.setRangeWithMargins(Double.NaN, 0.0d);
//     var2.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var16.setBaseURLGenerator(var17, false);
//     java.awt.Paint var21 = var16.getSeriesFillPaint(10);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var25, "hi!", "");
//     java.awt.Shape var29 = var28.getArea();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     var31.setLeftArrow(var38);
//     var28.setArea(var38);
//     java.awt.Shape var41 = var28.getArea();
//     var16.setBaseShape(var41, true);
//     java.awt.Font var46 = var16.getItemLabelFont(100, 10);
//     var2.setLabelFont(var46);
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, (java.awt.Paint)var50);
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.util.Size2D var53 = var51.calculateDimensions(var52);
//     java.awt.Graphics2D var54 = null;
//     org.jfree.chart.text.TextBlockAnchor var57 = null;
//     java.awt.Shape var61 = var51.calculateBounds(var54, 100.0f, (-1.0f), var57, (-1.0f), 1.0f, 8.0d);
//     java.awt.Graphics2D var62 = null;
//     org.jfree.chart.util.Size2D var63 = var51.calculateDimensions(var62);
//     
//     // Checks the contract:  equals-hashcode on var53 and var63
//     assertTrue("Contract failed: equals-hashcode on var53 and var63", var53.equals(var63) ? var53.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var53
//     assertTrue("Contract failed: equals-hashcode on var63 and var53", var63.equals(var53) ? var63.hashCode() == var53.hashCode() : true);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var0.addChangeListener(var2);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)"hi!");
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var6, (java.lang.Comparable)"UnitType.ABSOLUTE", 10.0d);
    double var10 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var6);
    org.jfree.data.general.PieDataset var14 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var6, (java.lang.Comparable)0.5f, 8.0d, 101);
    org.jfree.data.KeyedObjects2D var15 = new org.jfree.data.KeyedObjects2D();
    int var17 = var15.getColumnIndex((java.lang.Comparable)(-7471090));
    var15.removeObject((java.lang.Comparable)(-16777215), (java.lang.Comparable)1.0f);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var23.lengthToJava2D((-1.0d), var25, var26);
    java.awt.Shape var28 = var23.getLeftArrow();
    var23.setAutoRangeMinimumSize(100.0d);
    var23.configure();
    var23.setVisible(true);
    var23.setFixedAutoRange(100.0d);
    var23.setLabel("-11,9,9,-11,0,-14,-9,-11,11,9,14,0,11,-9,-9,11,0,14,9,11,-11,-9,-14,0,-14,0");
    java.awt.Shape var38 = var23.getRightArrow();
    boolean var39 = var23.getAutoRangeStickyZero();
    var23.setUpperBound(0.0d);
    org.jfree.chart.axis.NumberTickUnit var42 = var23.getTickUnit();
    var15.removeObject((java.lang.Comparable)(short)0, (java.lang.Comparable)var42);
    org.jfree.data.general.PieDataset var45 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var14, (java.lang.Comparable)var42, 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var1 = null;
    var0.setBaseToolTipGenerator(var1);
    java.awt.Font var5 = var0.getItemLabelFont((-16777215), 255);
    var0.setSeriesVisibleInLegend(1, (java.lang.Boolean)false);
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = null;
    var0.setBaseToolTipGenerator(var9, false);
    org.jfree.chart.plot.CategoryPlot var12 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var3.lengthToJava2D((-1.0d), var5, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var3.setLeftArrow(var10);
    var3.setRangeWithMargins(Double.NaN, 0.0d);
    var3.setTickLabelsVisible(true);
    int var17 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
    var0.setWeight((-1));
    boolean var20 = var0.isRangeGridlinesVisible();
    int var21 = var0.getWeight();
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    boolean var23 = var22.isDomainGridlinesVisible();
    double var24 = var22.getRangeCrosshairValue();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
    org.jfree.chart.block.CenterArrangement var26 = new org.jfree.chart.block.CenterArrangement();
    java.lang.Object var27 = null;
    boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var26, var27);
    org.jfree.chart.block.BlockContainer var29 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var26);
    var29.setMargin(1.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var35 = var29.getPadding();
    org.jfree.chart.block.Arrangement var36 = var29.getArrangement();
    org.jfree.chart.util.RectangleInsets var37 = var29.getPadding();
    double var39 = var37.calculateRightInset(100.0d);
    org.jfree.chart.block.LineBorder var40 = new org.jfree.chart.block.LineBorder();
    java.awt.Color var43 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var43);
    boolean var45 = var40.equals((java.lang.Object)var44);
    java.awt.Graphics2D var46 = null;
    org.jfree.chart.LegendItemSource var47 = null;
    org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle(var47);
    boolean var49 = var48.getNotify();
    java.awt.geom.Rectangle2D var50 = var48.getBounds();
    var40.draw(var46, var50);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var50, 0.5d, 1.0f, 0.5f);
    java.awt.geom.Rectangle2D var58 = var37.createOutsetRectangle(var50, false, true);
    var25.setPadding(var37);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
    var1.setAutoRange(false);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    double var9 = var8.getUpperClip();
    java.awt.Stroke var10 = var8.getBaseStroke();
    var1.setTickMarkStroke(var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    boolean var13 = var12.isDomainGridlinesVisible();
    var1.setPlot((org.jfree.chart.plot.Plot)var12);
    java.awt.Shape var15 = var1.getDownArrow();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var16.setBaseURLGenerator(var17, false);
    java.awt.Paint var21 = var16.getSeriesFillPaint(10);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var25, "hi!", "");
    java.awt.Shape var29 = var28.getArea();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    double var35 = var31.lengthToJava2D((-1.0d), var33, var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var31.setLeftArrow(var38);
    var28.setArea(var38);
    java.awt.Shape var41 = var28.getArea();
    var16.setBaseShape(var41, true);
    java.awt.Font var46 = var16.getItemLabelFont(100, 10);
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    double var49 = var48.getUpperClip();
    java.awt.Stroke var50 = var48.getBaseStroke();
    var16.setSeriesStroke(100, var50, true);
    boolean var53 = var1.equals((java.lang.Object)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "");
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "");
    var11.addOptionalLibrary("hi!");
    java.lang.String var14 = var11.getCopyright();
    java.lang.String var15 = var11.getLicenceName();
    var5.addLibrary((org.jfree.chart.ui.Library)var11);
    var5.setLicenceName("CategoryLabelEntity: category=, tooltip=hi!, url=");
    org.jfree.chart.ui.Library[] var19 = var5.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "hi!"+ "'", var14.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + ""+ "'", var15.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1, false);
    java.awt.Paint var5 = var0.getSeriesFillPaint(10);
    java.util.EventListener var6 = null;
    boolean var7 = var0.hasListener(var6);
    java.awt.Stroke var9 = null;
    var0.setSeriesOutlineStroke(10, var9, false);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    double var13 = var12.getUpperClip();
    boolean var14 = var12.getBaseSeriesVisible();
    boolean var15 = var12.getAutoPopulateSeriesShape();
    boolean var16 = var12.getBaseSeriesVisibleInLegend();
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var24 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var21, "hi!", "");
    java.awt.Shape var25 = var24.getArea();
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleEdge var30 = null;
    double var31 = var27.lengthToJava2D((-1.0d), var29, var30);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var27.setLeftArrow(var34);
    var24.setArea(var34);
    java.awt.Shape var37 = var24.getArea();
    var12.setSeriesShape(10, var37);
    var0.setBaseShape(var37);
    boolean var42 = var0.isItemLabelVisible(0, (-7471090));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    java.awt.Font var4 = var0.getItemLabelFont(100, 0);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    boolean var6 = var5.isDomainGridlinesVisible();
    double var7 = var5.getRangeCrosshairValue();
    java.awt.Stroke var8 = var5.getRangeGridlineStroke();
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var5);
    org.jfree.chart.axis.ValueAxis var11 = var5.getRangeAxisForDataset((-246));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var1.lengthToJava2D((-1.0d), var3, var4);
//     java.awt.Shape var6 = var1.getLeftArrow();
//     org.jfree.chart.axis.MarkerAxisBand var7 = var1.getMarkerBand();
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Paint var9 = var1.getLabelPaint();
//     java.awt.Paint var10 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var12 = var11.isDomainGridlinesVisible();
//     var11.clearRangeMarkers(10);
//     boolean var15 = var11.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     var16.setLabelToolTip("");
//     var16.setUpperMargin((-1.0d));
//     org.jfree.chart.event.AxisChangeListener var21 = null;
//     var16.removeChangeListener(var21);
//     org.jfree.chart.axis.CategoryLabelPositions var23 = var16.getCategoryLabelPositions();
//     org.jfree.chart.axis.CategoryAxis[] var24 = new org.jfree.chart.axis.CategoryAxis[] { var16};
//     var11.setDomainAxes(var24);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var27 = var26.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     java.awt.geom.Point2D var31 = null;
//     var26.zoomDomainAxes(2.0d, 16.0d, var30, var31);
//     java.lang.Object var33 = var26.clone();
//     org.jfree.chart.axis.AxisLocation var34 = var26.getDomainAxisLocation();
//     var11.setDomainAxisLocation(var34, false);
//     boolean var37 = var11.getDrawSharedDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     var11.setRenderer(var38);
//     org.jfree.chart.block.FlowArrangement var41 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis();
//     var42.setLabelToolTip("");
//     var42.setUpperMargin((-1.0d));
//     var42.setLabelURL("hi!");
//     double var49 = var42.getUpperMargin();
//     boolean var51 = var42.equals((java.lang.Object)(-1.0d));
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var52 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var54 = var52.getRangeLowerBound(false);
//     org.jfree.data.Range var56 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var52, false);
//     java.lang.Number var57 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var52);
//     int var58 = var52.getColumnCount();
//     boolean var59 = var42.equals((java.lang.Object)var52);
//     org.jfree.chart.title.LegendItemBlockContainer var61 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var41, (org.jfree.data.general.Dataset)var52, (java.lang.Comparable)10L);
//     double var63 = var52.getRangeLowerBound(false);
//     var11.setDataset(10, (org.jfree.data.category.CategoryDataset)var52);
//     boolean var65 = var1.equals((java.lang.Object)var52);
//     java.text.NumberFormat var66 = var1.getNumberFormatOverride();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + Double.NaN+ "'", var57.equals(Double.NaN));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var66);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setLabelToolTip("");
    var0.setUpperMargin((-1.0d));
    org.jfree.chart.plot.Plot var5 = null;
    var0.setPlot(var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)'#');
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var10.setBaseURLGenerator(var11, false);
    java.awt.Paint var15 = var10.getSeriesFillPaint(10);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"", var19, "hi!", "");
    java.awt.Shape var23 = var22.getArea();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var25.lengthToJava2D((-1.0d), var27, var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    var25.setLeftArrow(var32);
    var22.setArea(var32);
    java.awt.Shape var35 = var22.getArea();
    var10.setBaseShape(var35, true);
    java.awt.Font var40 = var10.getItemLabelFont(100, 10);
    var0.setTickLabelFont((java.lang.Comparable)"NOID", var40);
    java.lang.String var43 = var0.getCategoryLabelToolTip((java.lang.Comparable)0.2d);
    float var44 = var0.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0f);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(1.0d, 8.0d);
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Size2D[width=1.0, height=8.0]"+ "'", var3.equals("Size2D[width=1.0, height=8.0]"));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(Double.NaN);
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.block.BlockContainer var4 = var3.getItemContainer();
    var3.setNotify(false);
    org.jfree.chart.util.RectangleInsets var7 = var3.getItemLabelPadding();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    var8.setLabelToolTip("");
    var8.setUpperMargin((-1.0d));
    org.jfree.chart.event.AxisChangeListener var13 = null;
    var8.removeChangeListener(var13);
    org.jfree.chart.axis.CategoryLabelPositions var15 = var8.getCategoryLabelPositions();
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    boolean var18 = var17.getNotify();
    double var19 = var17.getWidth();
    org.jfree.chart.util.RectangleEdge var20 = var17.getLegendItemGraphicEdge();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    double var26 = var21.getCategoryStart(10, (-16777215), var24, var25);
    java.awt.Font var28 = null;
    var21.setTickLabelFont((java.lang.Comparable)1, var28);
    java.lang.String var30 = var21.getLabel();
    org.jfree.chart.axis.CategoryAnchor var31 = null;
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.LegendItemSource var35 = null;
    org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle(var35);
    boolean var37 = var36.getNotify();
    double var38 = var36.getWidth();
    org.jfree.chart.util.RectangleEdge var39 = var36.getLegendItemGraphicEdge();
    double var40 = var21.getCategoryJava2DCoordinate(var31, (-1), (-16777215), var34, var39);
    var17.setLegendItemGraphicEdge(var39);
    org.jfree.chart.axis.CategoryLabelPosition var42 = var15.getLabelPosition(var39);
    var3.setLegendItemGraphicEdge(var39);
    org.jfree.chart.axis.CategoryLabelPosition var44 = var1.getLabelPosition(var39);
    org.jfree.chart.axis.CategoryLabelWidthType var45 = var44.getWidthType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var7);
    boolean var9 = var4.equals((java.lang.Object)var8);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
    boolean var13 = var12.getNotify();
    java.awt.geom.Rectangle2D var14 = var12.getBounds();
    var4.draw(var10, var14);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var14, 0.5d, 1.0f, 0.5f);
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var21 = null;
    var20.setBaseURLGenerator(var21, false);
    var20.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Shape var27 = var20.getSeriesShape(255);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var29 = var28.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.ItemLabelPosition var32 = var28.getPositiveItemLabelPosition((-16777215), 1);
    org.jfree.chart.labels.ItemLabelPosition var35 = var28.getNegativeItemLabelPosition(0, (-1));
    var20.setBaseNegativeItemLabelPosition(var35, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var40 = var20.getItemLabelGenerator(10, 15);
    boolean var42 = var20.isSeriesVisibleInLegend((-127));
    java.awt.Paint var44 = var20.lookupSeriesFillPaint(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem(var0, "NOID", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=-1.0]", "0,0,-2,-2,2,-2,2,-2", (java.awt.Shape)var14, var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    org.jfree.chart.entity.EntityCollection var2 = var1.getEntityCollection();
    double var3 = var1.getBarWidth();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    boolean var5 = var4.isDomainGridlinesVisible();
    double var6 = var4.getRangeCrosshairValue();
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.util.List var8 = var7.getSubtitles();
    boolean var9 = var7.isNotify();
    var7.setBackgroundImageAlignment(10);
    org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var7);
    org.jfree.chart.resources.JFreeChartResources var13 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Locale var14 = var13.getLocale();
    java.util.Enumeration var15 = var13.getKeys();
    java.util.Enumeration var16 = var13.getKeys();
    boolean var17 = var7.equals((java.lang.Object)var16);
    var7.setTitle("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    java.awt.Stroke var20 = null;
    var7.setBorderStroke(var20);
    org.jfree.chart.util.RectangleInsets var22 = var7.getPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

}
