
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.LengthConstraintType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1, var2, (-1.0d), var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLeftArrow(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.RectangleInsets var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var1, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRightArrow(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var1 = null;
//     var0.datasetChanged(var1);
//     org.jfree.chart.plot.Marker var3 = null;
//     var0.addRangeMarker(var3);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var1 = null;
//     var0.datasetChanged(var1);
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     org.jfree.chart.plot.Marker var4 = null;
//     org.jfree.chart.util.Layer var5 = null;
//     boolean var6 = var0.removeDomainMarker(var4, var5);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 100.0f, 10.0f, var4, (-1.0d), var6);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
//     java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setDomainAxisLocation(1, var17, false);
//     java.awt.Stroke var20 = var15.getRangeCrosshairStroke();
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     java.awt.Shape var29 = null;
//     java.awt.Shape[] var30 = new java.awt.Shape[] { var29};
//     org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var9, var14, var21, var28, var30);
//     
//     // Checks the contract:  equals-hashcode on var15 and var22
//     assertTrue("Contract failed: equals-hashcode on var15 and var22", var15.equals(var22) ? var15.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var15
//     assertTrue("Contract failed: equals-hashcode on var22 and var15", var22.equals(var15) ? var22.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.Marker var2 = null;
    org.jfree.chart.util.Layer var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var4 = var0.removeRangeMarker(0, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.getDomainAxisIndex(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
//     org.jfree.chart.util.HorizontalAlignment var7 = null;
//     org.jfree.chart.util.VerticalAlignment var8 = null;
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement(var7, var8, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var14 = null;
//     var12.setDomainAxisLocation(1, var14, false);
//     java.awt.Stroke var17 = var12.getRangeCrosshairStroke();
//     boolean var18 = var11.equals((java.lang.Object)var17);
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var23 = null;
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var5, var17, (java.awt.Paint)var22, var23, 1.0f);
//     boolean var26 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var25);
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var3);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    org.jfree.chart.text.TextAnchor var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var24.setLabelTextAnchor(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.AxisLocation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.awt.geom.Rectangle2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var2 = var0.createOutsetRectangle(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var4 = var0.getDomainAxisForDataset(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var26 = var25.getQuadrantOrigin();
//     boolean var27 = var21.equals((java.lang.Object)var25);
//     
//     // Checks the contract:  equals-hashcode on var11 and var25
//     assertTrue("Contract failed: equals-hashcode on var11 and var25", var11.equals(var25) ? var11.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var11
//     assertTrue("Contract failed: equals-hashcode on var25 and var11", var25.equals(var11) ? var25.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, (-1.0f), 0.0f, (-1.0d), 100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
//     var0.setAxisOffset(var10);
//     java.awt.geom.Rectangle2D var12 = null;
//     var10.trim(var12);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
//     var1.setSectionOutlinesVisible(true);
//     java.lang.Comparable var5 = null;
//     double var6 = var1.getExplodePercent(var5);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    java.awt.Font var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var24.setLabelFont(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    double var10 = var9.getFixedDimension();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var9, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.awt.Shape var0 = null;
    org.jfree.data.general.PieDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PieSectionEntity var7 = new org.jfree.chart.entity.PieSectionEntity(var0, var1, 10, 1, (java.lang.Comparable)(short)10, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "hi!", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1, true);
//     var0.clearDomainMarkers(100);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var7 = null;
//     var6.datasetChanged(var7);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     var6.setRenderer(1, var10);
//     var0.setParent((org.jfree.chart.plot.Plot)var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     java.awt.geom.Point2D var8 = var0.getQuadrantOrigin();
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var9 = null;
//     var0.setRenderers(var9);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.util.List var12 = null;
    var0.drawRangeTickBands(var10, var11, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var15 = var0.getDomainAxisForDataset(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setTextAlignment(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     float var25 = var24.getAlpha();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var27 = var26.clone();
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
//     org.jfree.chart.util.RectangleInsets var30 = var29.getLabelPadding();
//     var29.setSectionOutlinesVisible(true);
//     java.awt.Paint var33 = var29.getBaseSectionPaint();
//     var26.setAxisLinePaint(var33);
//     var24.setPaint(var33);
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
//     org.jfree.chart.util.RectangleInsets var38 = var37.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var39 = null;
//     var37.setToolTipGenerator(var39);
//     org.jfree.chart.labels.PieSectionLabelGenerator var41 = var37.getLegendLabelToolTipGenerator();
//     var37.setLabelLinkMargin(100.0d);
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot(var44);
//     org.jfree.chart.util.RectangleInsets var46 = var45.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var47 = null;
//     var45.setToolTipGenerator(var47);
//     java.awt.Stroke var49 = var45.getBaseSectionOutlineStroke();
//     var37.setLabelOutlineStroke(var49);
//     var24.setOutlineStroke(var49);
//     
//     // Checks the contract:  equals-hashcode on var29 and var45
//     assertTrue("Contract failed: equals-hashcode on var29 and var45", var29.equals(var45) ? var29.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var29
//     assertTrue("Contract failed: equals-hashcode on var45 and var29", var45.equals(var29) ? var45.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, true);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(10, (-1), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     java.lang.Object var25 = var24.clone();
//     java.lang.Object var26 = var24.clone();
//     
//     // Checks the contract:  equals-hashcode on var25 and var26
//     assertTrue("Contract failed: equals-hashcode on var25 and var26", var25.equals(var26) ? var25.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var25
//     assertTrue("Contract failed: equals-hashcode on var26 and var25", var26.equals(var25) ? var26.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var3 = null;
//     var1.setToolTipGenerator(var3);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var7 = null;
//     var5.setDomainAxisLocation(1, var7, false);
//     java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
//     var1.setBaseSectionOutlineStroke(var10);
//     java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var16);
//     org.jfree.chart.util.HorizontalAlignment var18 = null;
//     org.jfree.chart.util.VerticalAlignment var19 = null;
//     org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var25 = null;
//     var23.setDomainAxisLocation(1, var25, false);
//     java.awt.Stroke var28 = var23.getRangeCrosshairStroke();
//     boolean var29 = var22.equals((java.lang.Object)var28);
//     java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var34 = null;
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var16, var28, (java.awt.Paint)var33, var34, 1.0f);
//     float var37 = var36.getAlpha();
//     boolean var38 = var1.equals((java.lang.Object)var36);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("hi!");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    java.awt.Shape var0 = null;
    org.jfree.data.general.PieDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PieSectionEntity var7 = new org.jfree.chart.entity.PieSectionEntity(var0, var1, 0, 0, (java.lang.Comparable)10L, "Multiple Pie Plot", "Range[0.0,1.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     boolean var3 = var0.isDomainGridlinesVisible();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var7 = var6.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var0.draw(var4, var5, var7, var8, var9);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxis((-1), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     org.jfree.chart.util.RectangleInsets var9 = var8.getLabelPadding();
//     var8.setSectionOutlinesVisible(true);
//     java.awt.Paint var12 = var8.getBaseSectionPaint();
//     org.jfree.chart.text.TextFragment var14 = new org.jfree.chart.text.TextFragment("hi!", var6, var12, 10.0f);
//     
//     // Checks the contract:  equals-hashcode on var2 and var8
//     assertTrue("Contract failed: equals-hashcode on var2 and var8", var2.equals(var8) ? var2.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var2
//     assertTrue("Contract failed: equals-hashcode on var8 and var2", var8.equals(var2) ? var8.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var11 = var10.clone();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLabelPadding();
    var13.setSectionOutlinesVisible(true);
    java.awt.Paint var17 = var13.getBaseSectionPaint();
    var10.setAxisLinePaint(var17);
    org.jfree.data.Range var19 = var10.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(100.0d, var19);
    org.jfree.chart.block.LengthConstraintType var21 = var20.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var22 = var20.toUnconstrainedHeight();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var23 = var7.arrange(var8, var20);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    java.lang.Comparable var0 = null;
    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.event.ChartChangeListener var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addChangeListener(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var10 = var7.createBufferedImage((-1), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.DatasetRenderingOrder var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setMaximumCategoryLabelLines((-1));
//     org.jfree.data.category.CategoryDataset var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var10 = null;
//     var9.datasetChanged(var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     var9.setRenderer(1, var13);
//     org.jfree.chart.util.RectangleEdge var16 = var9.getDomainAxisEdge(10);
//     double var17 = var1.getCategorySeriesMiddle((java.lang.Comparable)(-1), (java.lang.Comparable)0.05d, var6, (-1.0d), var8, var16);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     java.awt.color.ColorSpace var25 = null;
//     float[] var26 = new float[] { };
//     float[] var27 = var4.getComponents(var25, var26);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    var0.setRenderer(1, var4);
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
    boolean var9 = var0.equals((java.lang.Object)(-1));
    org.jfree.chart.plot.PlotOrientation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    java.awt.Font var1 = null;
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var6);
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var15 = null;
    var13.setDomainAxisLocation(1, var15, false);
    java.awt.Stroke var18 = var13.getRangeCrosshairStroke();
    boolean var19 = var12.equals((java.lang.Object)var18);
    java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var24 = null;
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var6, var18, (java.awt.Paint)var23, var24, 1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("RectangleConstraintType.RANGE", var1, (java.awt.Paint)var23, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var7.setFixedDomainAxisSpace(var8, true);
//     var7.clearDomainMarkers(100);
//     org.jfree.chart.util.RectangleEdge var14 = var7.getRangeAxisEdge(0);
//     boolean var15 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var14);
//     double var16 = var1.getCategoryStart(1, 0, var6, var14);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    double var4 = var2.calculateRightOutset(100.0d);
    java.lang.String var5 = var2.toString();
    double var7 = var2.calculateRightOutset((-7.0d));
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var2.createOutsetRectangle(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
    org.jfree.chart.plot.SeriesRenderingOrder var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesRenderingOrder(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.Plot var8 = var0.getRootPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(var9);
//     java.awt.Paint var11 = var0.getDomainZeroBaselinePaint();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var15 = null;
//     var13.setDomainAxisLocation(1, var15, false);
//     java.awt.Stroke var18 = var13.getRangeCrosshairStroke();
//     var13.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     var13.setRenderer(var21);
//     java.awt.Graphics2D var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     java.util.List var25 = null;
//     var13.drawRangeTickBands(var23, var24, var25);
//     float var27 = var13.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = null;
//     var28.setFixedLegendItems(var29);
//     java.awt.Graphics2D var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     boolean var35 = var28.render(var31, var32, 10, var34);
//     org.jfree.chart.axis.AxisLocation var36 = var28.getDomainAxisLocation();
//     var13.setDomainAxisLocation(var36);
//     var0.setDomainAxisLocation(0, var36);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     java.util.List var9 = null;
//     var7.setSubtitles(var9);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.color.ColorSpace var4 = null;
//     float[] var7 = new float[] { 100.0f, 10.0f};
//     float[] var8 = var3.getColorComponents(var4, var7);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Range[0.0,1.0]", var1);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     java.awt.Stroke var9 = var7.getBorderStroke();
//     java.awt.RenderingHints var10 = null;
//     var7.setRenderingHints(var10);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1, true);
//     var0.clearDomainMarkers(100);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var0.handleClick((-1), 10, var8);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    float[] var28 = new float[] { 0.0f, 100.0f, 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var29 = var4.getRGBComponents(var28);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var2 = var1.getUpperMargin();
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var7 = null;
//     var6.setFixedDomainAxisSpace(var7, true);
//     var6.clearDomainMarkers(100);
//     org.jfree.chart.util.RectangleEdge var13 = var6.getRangeAxisEdge(0);
//     double var14 = var1.getCategoryEnd((-1), (-1), var5, var13);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    int var9 = var0.getIndexOf(var8);
    var0.setDomainZeroBaselineVisible(false);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var14 = var13.clone();
    org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var13};
    var12.setDomainAxes(var15);
    org.jfree.data.xy.XYDataset var18 = var12.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    var12.setRenderer(100, var20, false);
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
    org.jfree.chart.util.HorizontalAlignment var29 = null;
    org.jfree.chart.util.VerticalAlignment var30 = null;
    org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var36 = null;
    var34.setDomainAxisLocation(1, var36, false);
    java.awt.Stroke var39 = var34.getRangeCrosshairStroke();
    boolean var40 = var33.equals((java.lang.Object)var39);
    java.awt.Color var44 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var45 = null;
    org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var27, var39, (java.awt.Paint)var44, var45, 1.0f);
    java.lang.Object var48 = var47.clone();
    var12.addDomainMarker((org.jfree.chart.plot.Marker)var47);
    org.jfree.chart.util.Layer var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var47, var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), (-1), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var3 = var2.getPercentFormat();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var6 = var5.getPercentFormat();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var3, var6);
//     
//     // Checks the contract:  equals-hashcode on var2 and var5
//     assertTrue("Contract failed: equals-hashcode on var2 and var5", var2.equals(var5) ? var2.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var2
//     assertTrue("Contract failed: equals-hashcode on var5 and var2", var5.equals(var2) ? var5.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    double var4 = var2.calculateRightOutset(100.0d);
    double var6 = var2.trimHeight((-1.0d));
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(var2, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-7.0d));

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.setForegroundAlpha(1.0f);
//     java.awt.Font var12 = var9.getNoDataMessageFont();
//     var9.setAnchorValue(100.0d);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var16.setMaximumCategoryLabelLines((-1));
//     int var19 = var9.getDomainAxisIndex(var16);
//     var1.setDomainAxis(10, var16, true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var1.", var9.equals(var1) == var1.equals(var9));
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var9 = var7.getSubtitle((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    java.awt.Paint var15 = var7.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
//     org.jfree.chart.util.HorizontalAlignment var14 = null;
//     org.jfree.chart.util.VerticalAlignment var15 = null;
//     org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setDomainAxisLocation(1, var21, false);
//     java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
//     boolean var25 = var18.equals((java.lang.Object)var24);
//     java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var30 = null;
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var24, (java.awt.Paint)var29, var30, 1.0f);
//     java.lang.Object var33 = var32.clone();
//     org.jfree.chart.text.TextAnchor var34 = var32.getLabelTextAnchor();
//     org.jfree.chart.util.Layer var35 = null;
//     boolean var36 = var1.removeDomainMarker((org.jfree.chart.plot.Marker)var32, var35);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    boolean var4 = var0.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var18 = var17.clone();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
    org.jfree.chart.util.RectangleInsets var21 = var20.getLabelPadding();
    var20.setSectionOutlinesVisible(true);
    java.awt.Paint var24 = var20.getBaseSectionPaint();
    var17.setAxisLinePaint(var24);
    org.jfree.data.Range var26 = var17.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(100.0d, var26);
    org.jfree.chart.block.LengthConstraintType var28 = var27.getHeightConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var29 = var7.arrange(var15, var27);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedDimension();
    org.jfree.data.RangeType var2 = var0.getRangeType();
    org.jfree.data.RangeType var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var17 = var16.clone();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     org.jfree.chart.util.RectangleInsets var20 = var19.getLabelPadding();
//     var19.setSectionOutlinesVisible(true);
//     java.awt.Paint var23 = var19.getBaseSectionPaint();
//     var16.setAxisLinePaint(var23);
//     org.jfree.data.Range var25 = var16.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(100.0d, var25);
//     org.jfree.chart.block.LengthConstraintType var27 = var26.getHeightConstraintType();
//     org.jfree.chart.block.RectangleConstraint var28 = var26.toUnconstrainedHeight();
//     boolean var29 = var7.equals((java.lang.Object)var26);
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
//     var0.clearDomainAxes();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.setForegroundAlpha(1.0f);
//     java.awt.Paint var9 = var6.getRangeCrosshairPaint();
//     org.jfree.chart.util.SortOrder var10 = var6.getRowRenderingOrder();
//     var0.setColumnRenderingOrder(var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("RectangleConstraintType.RANGE", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    org.jfree.chart.LegendItemCollection var6 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var8 = var6.get(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
//     int var9 = var0.getRangeAxisCount();
//     org.jfree.chart.axis.AxisLocation var11 = var0.getDomainAxisLocation(100);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var0.drawOutline(var12, var13);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.util.Layer var7 = null;
//     java.util.Collection var8 = var0.getRangeMarkers(10, var7);
//     java.util.List var9 = var0.getAnnotations();
//     org.jfree.chart.plot.PlotOrientation var10 = var0.getOrientation();
//     java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     boolean var28 = var21.equals((java.lang.Object)var27);
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var33 = null;
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
//     java.lang.Object var36 = var35.clone();
//     boolean var37 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var35);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("UnitType.ABSOLUTE", var1, var2);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var1 = null;
//     var0.datasetChanged(var1);
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     boolean var4 = var0.isDomainZoomable();
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var0.setDomainAxis(1, var6, true);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var16 = var15.getQuadrantOrigin();
//     var11.zoomDomainAxes((-1.0d), 3.0d, var14, var16);
//     var0.zoomRangeAxes(0.05d, var10, var16, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    var0.setAnchorValue(0.0d, false);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(10);
    int var9 = var0.getRangeAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var7.setURLText("Range[0.0,1.0]");
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var20 = var19.clone();
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
    var22.setSectionOutlinesVisible(true);
    java.awt.Paint var26 = var22.getBaseSectionPaint();
    var19.setAxisLinePaint(var26);
    org.jfree.data.Range var28 = var19.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var29 = new org.jfree.chart.block.RectangleConstraint(100.0d, var28);
    org.jfree.chart.block.LengthConstraintType var30 = var29.getHeightConstraintType();
    double var31 = var29.getHeight();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var32 = var7.arrange(var17, var29);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-7.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     var7.fireChartChanged();
//     java.awt.RenderingHints var10 = null;
//     var7.setRenderingHints(var10);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var6 = null;
//     var4.setToolTipGenerator(var6);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.PiePlotState var10 = var0.initialise(var1, var2, var4, (java.lang.Integer)(-65536), var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    boolean var22 = var15.equals((java.lang.Object)var21);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var27 = null;
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var30 = null;
    var29.addChangeListener(var30);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var29);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.setForegroundAlpha(1.0f);
    java.awt.Font var37 = var34.getNoDataMessageFont();
    var34.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var41.setMaximumCategoryLabelLines((-1));
    int var44 = var34.getDomainAxisIndex(var41);
    var0.setDomainAxis(100, var41);
    org.jfree.chart.util.RectangleInsets var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var41.setLabelInsets(var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-1));

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    org.jfree.chart.ChartRenderingInfo var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var12 = var7.createBufferedImage((-65536), (-65536), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.Plot var5 = var4.getPlot();
//     org.jfree.chart.event.ChartChangeEventType var6 = var4.getType();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setForegroundAlpha(1.0f);
//     java.awt.Paint var10 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     org.jfree.chart.event.ChartChangeEventType var13 = var11.getType();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var15 = var14.clone();
//     double var16 = var14.getLowerBound();
//     boolean var17 = var13.equals((java.lang.Object)var14);
//     var4.setType(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var12
//     assertTrue("Contract failed: equals-hashcode on var5 and var12", var5.equals(var12) ? var5.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var5
//     assertTrue("Contract failed: equals-hashcode on var12 and var5", var12.equals(var5) ? var12.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = var1.getLegendLabelToolTipGenerator();
    var1.setLabelLinkMargin(100.0d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var8 = var1.getLabelDistributor();
    java.lang.Object var9 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     float var3 = var1.getTickMarkInsideLength();
//     boolean var4 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var6 = var5.clone();
//     org.jfree.data.Range var7 = var5.getRange();
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.setForegroundAlpha(1.0f);
//     java.awt.Font var17 = var14.getNoDataMessageFont();
//     var14.setAnchorValue(0.0d, false);
//     org.jfree.chart.util.RectangleEdge var22 = var14.getDomainAxisEdge(10);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.axis.AxisState var24 = var5.draw(var10, 0.0d, var12, var13, var22, var23);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = null;
//     org.jfree.chart.plot.PlotState var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var0.draw(var1, var2, var3, var4, var5);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var13 = var7.getURLText();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.setForegroundAlpha(1.0f);
//     java.awt.Font var17 = var14.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     org.jfree.chart.util.RectangleInsets var20 = var19.getLabelPadding();
//     var19.setSectionOutlinesVisible(true);
//     java.awt.Paint var23 = var19.getBaseSectionPaint();
//     var14.setRangeCrosshairPaint(var23);
//     var7.setPaint(var23);
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.text.TextAnchor var26 = var24.getLabelTextAnchor();
//     java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var31);
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement(var33, var34, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var40 = null;
//     var38.setDomainAxisLocation(1, var40, false);
//     java.awt.Stroke var43 = var38.getRangeCrosshairStroke();
//     boolean var44 = var37.equals((java.lang.Object)var43);
//     java.awt.Color var48 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var49 = null;
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var31, var43, (java.awt.Paint)var48, var49, 1.0f);
//     float var52 = var51.getAlpha();
//     java.awt.Paint var53 = var51.getLabelPaint();
//     java.awt.Paint var54 = var51.getPaint();
//     var24.setPaint(var54);
//     
//     // Checks the contract:  equals-hashcode on var5 and var32
//     assertTrue("Contract failed: equals-hashcode on var5 and var32", var5.equals(var32) ? var5.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var5
//     assertTrue("Contract failed: equals-hashcode on var32 and var5", var32.equals(var5) ? var32.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var38
//     assertTrue("Contract failed: equals-hashcode on var11 and var38", var11.equals(var38) ? var11.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var11
//     assertTrue("Contract failed: equals-hashcode on var38 and var11", var38.equals(var11) ? var38.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var51
//     assertTrue("Contract failed: equals-hashcode on var24 and var51", var24.equals(var51) ? var24.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var24
//     assertTrue("Contract failed: equals-hashcode on var51 and var24", var51.equals(var24) ? var51.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = var1.getLegendLabelToolTipGenerator();
    var1.setLabelLinkMargin(100.0d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var8 = var1.getLabelDistributor();
    org.jfree.chart.plot.PieLabelRecord var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addPieLabelRecord(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    boolean var3 = var0.isDomainGridlinesVisible();
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    var0.setRenderer(var4, true);
    org.jfree.chart.plot.CategoryMarker var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.setForegroundAlpha(1.0f);
//     java.awt.Paint var11 = var8.getRangeCrosshairPaint();
//     org.jfree.chart.util.SortOrder var12 = var8.getRowRenderingOrder();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
//     org.jfree.chart.util.HorizontalAlignment var19 = null;
//     org.jfree.chart.util.VerticalAlignment var20 = null;
//     org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var26 = null;
//     var24.setDomainAxisLocation(1, var26, false);
//     java.awt.Stroke var29 = var24.getRangeCrosshairStroke();
//     boolean var30 = var23.equals((java.lang.Object)var29);
//     java.awt.Color var34 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var35 = null;
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var17, var29, (java.awt.Paint)var34, var35, 1.0f);
//     org.jfree.chart.event.MarkerChangeListener var38 = null;
//     var37.addChangeListener(var38);
//     var8.addRangeMarker((org.jfree.chart.plot.Marker)var37);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     var42.setForegroundAlpha(1.0f);
//     java.awt.Font var45 = var42.getNoDataMessageFont();
//     var42.setAnchorValue(100.0d);
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var49.setMaximumCategoryLabelLines((-1));
//     int var52 = var42.getDomainAxisIndex(var49);
//     var8.setDomainAxis(100, var49);
//     var0.setDomainAxis(1, var49);
//     
//     // Checks the contract:  equals-hashcode on var4 and var24
//     assertTrue("Contract failed: equals-hashcode on var4 and var24", var4.equals(var24) ? var4.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var4
//     assertTrue("Contract failed: equals-hashcode on var24 and var4", var24.equals(var4) ? var24.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisSpace var8 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var11 = null;
    var10.setFixedLegendItems(var11);
    java.awt.Graphics2D var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    boolean var17 = var10.render(var13, var14, 10, var16);
    org.jfree.chart.axis.AxisLocation var18 = var10.getDomainAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-65536), var18, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     var1.setAxisLinePaint(var8);
//     org.jfree.data.Range var10 = var1.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
//     org.jfree.chart.util.Size2D var12 = null;
//     org.jfree.chart.util.Size2D var13 = var11.calculateConstrainedSize(var12);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     float var25 = var24.getAlpha();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var27 = var26.clone();
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
//     org.jfree.chart.util.RectangleInsets var30 = var29.getLabelPadding();
//     var29.setSectionOutlinesVisible(true);
//     java.awt.Paint var33 = var29.getBaseSectionPaint();
//     var26.setAxisLinePaint(var33);
//     var24.setPaint(var33);
//     java.awt.Paint var36 = var24.getOutlinePaint();
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var38 = null;
//     var37.setFixedDomainAxisSpace(var38, true);
//     var37.clearDomainMarkers(100);
//     var37.setOutlineVisible(true);
//     org.jfree.chart.axis.ValueAxis var46 = var37.getRangeAxis(0);
//     java.awt.Paint var47 = var37.getRangeGridlinePaint();
//     var24.setPaint(var47);
//     
//     // Checks the contract:  equals-hashcode on var11 and var37
//     assertTrue("Contract failed: equals-hashcode on var11 and var37", var11.equals(var37) ? var11.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var11
//     assertTrue("Contract failed: equals-hashcode on var37 and var11", var37.equals(var11) ? var37.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var13 = var7.getURLText();
    var7.setURLText("RectangleConstraintType.RANGE");
    java.awt.Paint var16 = var7.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Multiple Pie Plot", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    var0.setAnchorValue(0.0d, false);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(10);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var12 = var9.createBufferedImage((-1), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    java.awt.Paint var1 = null;
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var6);
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var15 = null;
    var13.setDomainAxisLocation(1, var15, false);
    java.awt.Stroke var18 = var13.getRangeCrosshairStroke();
    boolean var19 = var12.equals((java.lang.Object)var18);
    java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var24 = null;
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var6, var18, (java.awt.Paint)var23, var24, 1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(4.0d, var1, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
//     org.jfree.chart.axis.AxisSpace var7 = null;
//     var0.setFixedRangeAxisSpace(var7);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
//     org.jfree.chart.util.UnitType var12 = var11.getUnitType();
//     var0.setAxisOffset(var11);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var16 = null;
//     var14.setDomainAxisLocation(1, var16, false);
//     java.awt.Stroke var19 = var14.getRangeCrosshairStroke();
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var14.getRangeMarkers(10, var21);
//     java.util.List var23 = var14.getAnnotations();
//     org.jfree.chart.plot.PlotOrientation var24 = var14.getOrientation();
//     var0.setOrientation(var24);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setDomainAxisLocation(1, var7, false);
    java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
    var1.setBaseSectionOutlineStroke(var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setForegroundAlpha(1.0f);
    java.awt.Font var15 = var12.getNoDataMessageFont();
    var1.setLabelFont(var15);
    java.awt.Paint var17 = var1.getBaseSectionPaint();
    boolean var18 = var1.getSectionOutlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    boolean var4 = var0.isDomainZoomable();
    org.jfree.chart.axis.ValueAxis var6 = null;
    var0.setDomainAxis(1, var6, true);
    boolean var9 = var0.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.setForegroundAlpha(1.0f);
//     java.awt.Font var9 = var6.getNoDataMessageFont();
//     var6.setAnchorValue(0.0d, false);
//     org.jfree.chart.util.RectangleEdge var14 = var6.getDomainAxisEdge(10);
//     double var15 = var0.getCategorySeriesMiddle((java.lang.Comparable)0.08d, (java.lang.Comparable)"", var3, 0.0d, var5, var14);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setTextAlignment(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(short)10);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.setForegroundAlpha(1.0f);
//     java.awt.Font var8 = var5.getNoDataMessageFont();
//     var5.setAnchorValue(0.0d, false);
//     org.jfree.chart.util.RectangleEdge var13 = var5.getDomainAxisEdge(10);
//     double var14 = var1.getCategoryMiddle(100, 0, var4, var13);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    var0.setVisible(false);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var6 = var5.clone();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    org.jfree.chart.util.RectangleInsets var9 = var8.getLabelPadding();
    var8.setSectionOutlinesVisible(true);
    java.awt.Paint var12 = var8.getBaseSectionPaint();
    var5.setAxisLinePaint(var12);
    org.jfree.data.Range var14 = var5.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(100.0d, var14);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var17 = var16.clone();
    org.jfree.data.Range var18 = var16.getRange();
    org.jfree.data.Range var19 = org.jfree.data.Range.combine(var14, var18);
    var0.setRangeWithMargins(var18);
    var0.setAutoTickUnitSelection(false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = null;
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(1.0d, 0.0d);
//     java.lang.String var6 = var5.toString();
//     org.jfree.chart.util.Size2D var7 = var0.arrange(var1, var2, var5);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var1 = null;
//     var0.datasetChanged(var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     var0.setRenderer(1, var4);
//     org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
//     boolean var9 = var0.equals((java.lang.Object)(-1));
//     org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.setForegroundAlpha(1.0f);
//     java.awt.Font var16 = var13.getNoDataMessageFont();
//     var13.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var13);
//     java.awt.Paint var20 = var19.getBackgroundPaint();
//     java.awt.Stroke var21 = var19.getBorderStroke();
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var19);
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var24.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var26 = null;
//     var24.setToolTipGenerator(var26);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var30 = null;
//     var28.setDomainAxisLocation(1, var30, false);
//     java.awt.Stroke var33 = var28.getRangeCrosshairStroke();
//     var24.setBaseSectionOutlineStroke(var33);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.setForegroundAlpha(1.0f);
//     java.awt.Font var38 = var35.getNoDataMessageFont();
//     var24.setLabelFont(var38);
//     java.awt.Paint var40 = var24.getBaseSectionPaint();
//     var19.setBackgroundPaint(var40);
//     
//     // Checks the contract:  equals-hashcode on var0 and var28
//     assertTrue("Contract failed: equals-hashcode on var0 and var28", var0.equals(var28) ? var0.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var0
//     assertTrue("Contract failed: equals-hashcode on var28 and var0", var28.equals(var0) ? var28.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getUpperMargin();
    var1.addCategoryLabelToolTip((java.lang.Comparable)10.0d, "RectangleConstraintType.RANGE");
    java.lang.Comparable var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Font var7 = var1.getTickLabelFont(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
//     var3.setSectionOutlinesVisible(true);
//     java.awt.Paint var7 = var3.getBaseSectionPaint();
//     var0.setAxisLinePaint(var7);
//     double var9 = var0.getLowerMargin();
//     boolean var10 = var0.isVerticalTickLabels();
//     var0.setPositiveArrowVisible(true);
//     org.jfree.data.Range var13 = var0.getRange();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var15 = var14.clone();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getLabelPadding();
//     var17.setSectionOutlinesVisible(true);
//     java.awt.Paint var21 = var17.getBaseSectionPaint();
//     var14.setAxisLinePaint(var21);
//     org.jfree.data.Range var23 = var14.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(var13, var23);
//     
//     // Checks the contract:  equals-hashcode on var3 and var17
//     assertTrue("Contract failed: equals-hashcode on var3 and var17", var3.equals(var17) ? var3.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var3
//     assertTrue("Contract failed: equals-hashcode on var17 and var3", var17.equals(var3) ? var17.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    org.jfree.data.general.WaferMapDataset var2 = null;
    var1.setDataset(var2);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1, true);
//     var0.clearDomainMarkers(100);
//     var0.setOutlineVisible(true);
//     org.jfree.data.general.DatasetGroup var8 = var0.getDatasetGroup();
//     boolean var9 = var0.isDomainCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var14 = null;
//     var12.setDomainAxisLocation(1, var14, false);
//     java.awt.Stroke var17 = var12.getRangeCrosshairStroke();
//     var12.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var23 = var22.getQuadrantOrigin();
//     var12.zoomRangeAxes(0.0d, var21, var23, false);
//     var0.zoomRangeAxes(3.0d, var11, var23);
//     
//     // Checks the contract:  equals-hashcode on var0 and var22
//     assertTrue("Contract failed: equals-hashcode on var0 and var22", var0.equals(var22) ? var0.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var2 = var1.getUpperMargin();
//     var1.addCategoryLabelToolTip((java.lang.Comparable)10.0d, "RectangleConstraintType.RANGE");
//     float var6 = var1.getMaximumCategoryLabelWidthRatio();
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = null;
//     var10.setFixedLegendItems(var11);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     boolean var17 = var10.render(var13, var14, 10, var16);
//     org.jfree.chart.axis.AxisLocation var18 = var10.getDomainAxisLocation();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var10.getRenderer();
//     org.jfree.chart.util.RectangleEdge var20 = var10.getRangeAxisEdge();
//     double var21 = var1.getCategoryMiddle(10, 0, var9, var20);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Multiple Pie Plot");

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
//     org.jfree.chart.axis.AxisSpace var7 = null;
//     var0.setFixedRangeAxisSpace(var7);
//     org.jfree.chart.plot.Marker var9 = null;
//     org.jfree.chart.util.Layer var10 = null;
//     boolean var11 = var0.removeDomainMarker(var9, var10);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
//     var0.setRangeCrosshairValue(10.0d, true);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = var0.getRendererForDataset(var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = var0.getRenderer(0);
//     var0.clearDomainAxes();
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var12 = var11.clone();
//     org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var11};
//     var10.setDomainAxes(var13);
//     org.jfree.data.xy.XYDataset var16 = var10.getDataset(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     var10.setRenderer(100, var18, false);
//     java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var25);
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var34 = null;
//     var32.setDomainAxisLocation(1, var34, false);
//     java.awt.Stroke var37 = var32.getRangeCrosshairStroke();
//     boolean var38 = var31.equals((java.lang.Object)var37);
//     java.awt.Color var42 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var43 = null;
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var25, var37, (java.awt.Paint)var42, var43, 1.0f);
//     java.lang.Object var46 = var45.clone();
//     var10.addDomainMarker((org.jfree.chart.plot.Marker)var45);
//     org.jfree.chart.util.Layer var48 = null;
//     boolean var49 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var45, var48);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    double var15 = var7.getContentXOffset();
    java.awt.Font var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setFont(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-7.0d));

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var12 = null;
//     var10.setDomainAxisLocation(1, var12, false);
//     java.awt.Stroke var15 = var10.getRangeCrosshairStroke();
//     var10.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     var10.setRenderer(var18);
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     java.util.List var22 = null;
//     var10.drawRangeTickBands(var20, var21, var22);
//     float var24 = var10.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var26 = null;
//     var25.setFixedLegendItems(var26);
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     boolean var32 = var25.render(var28, var29, 10, var31);
//     org.jfree.chart.axis.AxisLocation var33 = var25.getDomainAxisLocation();
//     var10.setDomainAxisLocation(var33);
//     var1.setDomainAxisLocation(var33);
//     java.awt.Color var41 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var41);
//     org.jfree.chart.util.HorizontalAlignment var43 = null;
//     org.jfree.chart.util.VerticalAlignment var44 = null;
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var50 = null;
//     var48.setDomainAxisLocation(1, var50, false);
//     java.awt.Stroke var53 = var48.getRangeCrosshairStroke();
//     boolean var54 = var47.equals((java.lang.Object)var53);
//     java.awt.Color var58 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var59 = null;
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var41, var53, (java.awt.Paint)var58, var59, 1.0f);
//     float var62 = var61.getAlpha();
//     java.awt.Paint var63 = var61.getPaint();
//     org.jfree.chart.util.Layer var64 = null;
//     boolean var65 = var1.removeDomainMarker(10, (org.jfree.chart.plot.Marker)var61, var64);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
//     org.jfree.chart.util.HorizontalAlignment var14 = null;
//     org.jfree.chart.util.VerticalAlignment var15 = null;
//     org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setDomainAxisLocation(1, var21, false);
//     java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
//     boolean var25 = var18.equals((java.lang.Object)var24);
//     java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var30 = null;
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var24, (java.awt.Paint)var29, var30, 1.0f);
//     java.lang.Object var33 = var32.clone();
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var35 = var34.getQuadrantOrigin();
//     var34.setRangeCrosshairValue(10.0d, true);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = var34.getRendererForDataset(var39);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     var42.setForegroundAlpha(1.0f);
//     java.awt.Font var45 = var42.getNoDataMessageFont();
//     var42.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var42);
//     org.jfree.chart.axis.AxisLocation var49 = var42.getDomainAxisLocation();
//     var34.setRangeAxisLocation(var49);
//     boolean var51 = var32.equals((java.lang.Object)var34);
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     var53.setForegroundAlpha(1.0f);
//     boolean var56 = var53.isDomainGridlinesVisible();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     var53.setRenderer(var57, true);
//     org.jfree.chart.axis.AxisLocation var61 = var53.getRangeAxisLocation((-1));
//     var34.setDomainAxisLocation(0, var61, true);
//     var1.setDomainAxisLocation(var61);
//     org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var67 = var66.getTickLabelFont();
//     var66.setAutoRange(false);
//     org.jfree.data.Range var70 = var1.getDataRange((org.jfree.chart.axis.ValueAxis)var66);
//     java.awt.Color var75 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var76 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var75);
//     org.jfree.chart.util.HorizontalAlignment var77 = null;
//     org.jfree.chart.util.VerticalAlignment var78 = null;
//     org.jfree.chart.block.ColumnArrangement var81 = new org.jfree.chart.block.ColumnArrangement(var77, var78, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var82 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var84 = null;
//     var82.setDomainAxisLocation(1, var84, false);
//     java.awt.Stroke var87 = var82.getRangeCrosshairStroke();
//     boolean var88 = var81.equals((java.lang.Object)var87);
//     java.awt.Color var92 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var93 = null;
//     org.jfree.chart.plot.ValueMarker var95 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var75, var87, (java.awt.Paint)var92, var93, 1.0f);
//     float var96 = var95.getAlpha();
//     boolean var97 = var1.removeRangeMarker((org.jfree.chart.plot.Marker)var95);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    org.jfree.chart.ChartRenderingInfo var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var13 = var7.createBufferedImage(0, (-1), 1, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.setForegroundAlpha(1.0f);
//     java.awt.Font var11 = var8.getNoDataMessageFont();
//     var8.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getDomainAxisLocation();
//     var0.setDomainAxisLocation(var15);
//     org.jfree.chart.axis.ValueAxis var18 = var0.getRangeAxis((-65536));
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setForegroundAlpha(1.0f);
//     java.awt.Font var24 = var21.getNoDataMessageFont();
//     var21.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var21);
//     org.jfree.chart.axis.AxisLocation var28 = var21.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var29 = var21.getDomainAxisLocation();
//     var0.setRangeAxisLocation(0, var29);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var27
//     assertTrue("Contract failed: equals-hashcode on var14 and var27", var14.equals(var27) ? var14.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var14
//     assertTrue("Contract failed: equals-hashcode on var27 and var14", var27.equals(var14) ? var27.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Font var3 = var0.getNoDataMessageFont();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var4.setMarkerBand(var5);
//     org.jfree.data.Range var7 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var4);
//     var0.setAnchorValue(0.08d);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var0.handleClick(0, 100, var12);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.AttributedString var3 = null;
//     var1.setAttributedLabel(0, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     java.text.AttributedString var7 = var1.generateAttributedSectionLabel(var5, (java.lang.Comparable)100L);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.configureRangeAxes();
    org.jfree.chart.LegendItemCollection var6 = var0.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
//     boolean var3 = var1.getLabelLinksVisible();
//     boolean var4 = var1.getSimpleLabels();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var6 = var5.clone();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     org.jfree.chart.util.RectangleInsets var9 = var8.getLabelPadding();
//     var8.setSectionOutlinesVisible(true);
//     java.awt.Paint var12 = var8.getBaseSectionPaint();
//     var5.setAxisLinePaint(var12);
//     var1.setBaseSectionPaint(var12);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var19 = null;
//     var17.setToolTipGenerator(var19);
//     java.awt.Font var21 = var17.getLabelFont();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var21);
//     var22.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var22.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var22.setURLText("Range[0.0,1.0]");
//     org.jfree.chart.util.HorizontalAlignment var32 = var22.getHorizontalAlignment();
//     var7.setHorizontalAlignment(var32);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var5.setLicenceName("hi!");
//     org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo();
//     java.util.List var9 = var8.getContributors();
//     var5.addOptionalLibrary((org.jfree.chart.ui.Library)var8);
//     org.jfree.chart.JFreeChart var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setForegroundAlpha(1.0f);
//     java.awt.Paint var15 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var12);
//     org.jfree.chart.plot.Plot var17 = var16.getPlot();
//     org.jfree.chart.event.ChartChangeEventType var18 = var16.getType();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var20 = var19.clone();
//     double var21 = var19.getLowerBound();
//     boolean var22 = var18.equals((java.lang.Object)var19);
//     org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var5, var11, var18);
//     org.jfree.chart.ui.Library var24 = null;
//     var5.addOptionalLibrary(var24);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var8 = var0.getRootPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(var9);
    java.awt.Paint var11 = var0.getDomainZeroBaselinePaint();
    org.jfree.chart.util.RectangleInsets var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var12, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var4.setMarkerBand(var5);
    org.jfree.data.Range var7 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var4);
    var4.setLabelAngle((-1.0d));
    boolean var10 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTickUnit(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     float var3 = var1.getTickMarkInsideLength();
//     boolean var4 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var6 = var5.clone();
//     org.jfree.data.Range var7 = var5.getRange();
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setForegroundAlpha(1.0f);
//     java.awt.Font var14 = var11.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
//     var16.setSectionOutlinesVisible(true);
//     java.awt.Paint var20 = var16.getBaseSectionPaint();
//     var11.setRangeCrosshairPaint(var20);
//     java.lang.Object var22 = var11.clone();
//     org.jfree.chart.LegendItemCollection var23 = var11.getLegendItems();
//     var11.setRangeCrosshairVisible(true);
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var28 = null;
//     var27.setFixedDomainAxisSpace(var28, true);
//     var27.clearDomainMarkers(100);
//     org.jfree.chart.util.RectangleEdge var34 = var27.getRangeAxisEdge(0);
//     boolean var35 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var34);
//     boolean var36 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var34);
//     org.jfree.chart.axis.AxisSpace var37 = null;
//     org.jfree.chart.axis.AxisSpace var38 = var5.reserveSpace(var10, (org.jfree.chart.plot.Plot)var11, var26, var34, var37);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.Range var14 = var12.getRange();
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setForegroundAlpha(1.0f);
    java.awt.Paint var19 = var16.getRangeCrosshairPaint();
    boolean var20 = var15.equals((java.lang.Object)var16);
    double var22 = var15.constrain(0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.08d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var0.setAnchorValue(0.0d);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var19 = var0.getDomainAxisIndex(var18);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var22 = var21.clone();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var20.setDomainAxes(var23);
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
    var20.setRenderer(var25);
    java.awt.Stroke var27 = var20.getRangeCrosshairStroke();
    var18.setAxisLineStroke(var27);
    java.lang.Comparable var29 = null;
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var32 = var31.getTickLabelFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setTickLabelFont(var29, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
    org.jfree.chart.labels.PieSectionLabelGenerator var7 = var1.getLegendLabelToolTipGenerator();
    boolean var8 = var1.getSectionOutlinesVisible();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var1.getLegendLabelToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var5 = null;
//     var3.setDomainAxisLocation(1, var5, false);
//     java.awt.Stroke var8 = var3.getRangeCrosshairStroke();
//     var3.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var14 = var13.getQuadrantOrigin();
//     var3.zoomRangeAxes(0.0d, var12, var14, false);
//     org.jfree.chart.plot.PlotState var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var0.draw(var1, var2, var14, var17, var18);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.setForegroundAlpha(1.0f);
//     java.awt.Font var26 = var23.getNoDataMessageFont();
//     var23.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var23);
//     java.awt.Paint var30 = var29.getBackgroundPaint();
//     var29.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var32 = var29.getPadding();
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     org.jfree.chart.util.RectangleInsets var35 = var34.getLabelPadding();
//     boolean var36 = var32.equals((java.lang.Object)var34);
//     boolean var37 = var21.equals((java.lang.Object)var34);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var29
//     assertTrue("Contract failed: equals-hashcode on var7 and var29", var7.equals(var29) ? var7.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var7
//     assertTrue("Contract failed: equals-hashcode on var29 and var7", var29.equals(var7) ? var29.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = var1.getLegendLabelToolTipGenerator();
    var1.setLabelLinkMargin(100.0d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var8 = var1.getLabelDistributor();
    java.awt.Paint var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseSectionOutlinePaint(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     java.lang.Class var25 = null;
//     java.util.EventListener[] var26 = var24.getListeners(var25);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.Range var14 = var12.getRange();
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
    org.jfree.data.Range var17 = org.jfree.data.Range.shift(var14, 10.0d);
    double var18 = var17.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10.5d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var3 = var2.clone();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var2.setAxisLinePaint(var9);
    org.jfree.data.Range var11 = var2.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(100.0d, var11);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var14 = var13.clone();
    org.jfree.data.Range var15 = var13.getRange();
    org.jfree.data.Range var16 = org.jfree.data.Range.combine(var11, var15);
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(3.0d, var15);
    org.jfree.chart.block.RectangleConstraint var18 = var17.toUnconstrainedWidth();
    java.lang.String var19 = var17.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]"+ "'", var19.equals("RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]"));

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var14);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var23 = null;
    var21.setDomainAxisLocation(1, var23, false);
    java.awt.Stroke var26 = var21.getRangeCrosshairStroke();
    boolean var27 = var20.equals((java.lang.Object)var26);
    java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var32 = null;
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var14, var26, (java.awt.Paint)var31, var32, 1.0f);
    var0.setDomainGridlinePaint((java.awt.Paint)var14);
    var0.setDomainCrosshairLockedOnData(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var1 = null;
//     var0.datasetChanged(var1);
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setForegroundAlpha(1.0f);
//     java.awt.Paint var10 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var7);
//     var7.configureRangeAxes();
//     boolean var13 = var7.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     java.util.List var15 = var7.getCategoriesForAxis(var14);
//     var0.drawDomainTickBands(var5, var6, var15);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     var0.drawBackground(var17, var18);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = var0.getRendererForDataset(var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = var0.getRenderer(0);
    var0.clearDomainAxes();
    java.awt.Paint var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainZeroBaselinePaint(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var13 = var7.getURLText();
    var7.setURLText("RectangleConstraintType.RANGE");
    var7.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
//     var3.setSectionOutlinesVisible(true);
//     java.awt.Paint var7 = var3.getBaseSectionPaint();
//     var0.setAxisLinePaint(var7);
//     org.jfree.data.Range var9 = var0.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var12 = var11.getTickLabelFont();
//     var0.setLabelFont(var12);
//     boolean var14 = var0.isInverted();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var18 = var17.clone();
//     float var19 = var17.getTickMarkInsideLength();
//     boolean var20 = var17.isAutoRange();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var22 = var21.clone();
//     org.jfree.data.Range var23 = var21.getRange();
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var21, var24);
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.setForegroundAlpha(1.0f);
//     java.awt.Font var30 = var27.getNoDataMessageFont();
//     var27.setAnchorValue(0.0d, false);
//     org.jfree.chart.util.RectangleEdge var35 = var27.getDomainAxisEdge(10);
//     org.jfree.chart.axis.AxisSpace var36 = null;
//     org.jfree.chart.axis.AxisSpace var37 = var0.reserveSpace(var15, (org.jfree.chart.plot.Plot)var25, var26, var35, var36);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     var1.setAxisLinePaint(var8);
//     org.jfree.data.Range var10 = var1.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var13 = var12.clone();
//     org.jfree.data.Range var14 = var12.getRange();
//     org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.setForegroundAlpha(1.0f);
//     java.awt.Paint var19 = var16.getRangeCrosshairPaint();
//     boolean var20 = var15.equals((java.lang.Object)var16);
//     org.jfree.chart.ui.BasicProjectInfo var26 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var26.setLicenceName("hi!");
//     java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var33);
//     org.jfree.chart.util.HorizontalAlignment var35 = null;
//     org.jfree.chart.util.VerticalAlignment var36 = null;
//     org.jfree.chart.block.ColumnArrangement var39 = new org.jfree.chart.block.ColumnArrangement(var35, var36, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var42 = null;
//     var40.setDomainAxisLocation(1, var42, false);
//     java.awt.Stroke var45 = var40.getRangeCrosshairStroke();
//     boolean var46 = var39.equals((java.lang.Object)var45);
//     java.awt.Color var50 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var51 = null;
//     org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var33, var45, (java.awt.Paint)var50, var51, 1.0f);
//     java.lang.Object var54 = var53.clone();
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var56 = var55.getQuadrantOrigin();
//     var55.setRangeCrosshairValue(10.0d, true);
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = var55.getRendererForDataset(var60);
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
//     var63.setForegroundAlpha(1.0f);
//     java.awt.Font var66 = var63.getNoDataMessageFont();
//     var63.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var63);
//     org.jfree.chart.axis.AxisLocation var70 = var63.getDomainAxisLocation();
//     var55.setRangeAxisLocation(var70);
//     boolean var72 = var53.equals((java.lang.Object)var55);
//     boolean var73 = var26.equals((java.lang.Object)var53);
//     boolean var74 = var16.removeDomainMarker((org.jfree.chart.plot.Marker)var53);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
    var3.setSectionOutlinesVisible(true);
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    var0.setAxisLinePaint(var7);
    double var9 = var0.getLowerMargin();
    boolean var10 = var0.isVerticalTickLabels();
    var0.setPositiveArrowVisible(true);
    java.lang.String var13 = var0.getLabelURL();
    var0.setVerticalTickLabels(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var3 = null;
//     var1.setToolTipGenerator(var3);
//     org.jfree.chart.labels.PieSectionLabelGenerator var5 = var1.getLegendLabelToolTipGenerator();
//     var1.setLabelLinkMargin(100.0d);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var10 = var9.getPercentFormat();
//     var1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var9);
//     org.jfree.data.general.PieDataset var12 = null;
//     java.text.AttributedString var14 = var9.generateAttributedSectionLabel(var12, (java.lang.Comparable)100.0f);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    double var4 = var2.calculateRightOutset(100.0d);
    java.lang.String var5 = var2.toString();
    double var7 = var2.calculateBottomOutset((-7.0d));
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var11 = var2.createOutsetRectangle(var8, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=255,g=0,b=0]", var1, (-1.0f), 100.0f, 10.5d, 10.0f, 0.0f);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var7.setURLText("Range[0.0,1.0]");
//     org.jfree.chart.util.RectangleEdge var17 = var7.getPosition();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     org.jfree.chart.util.RectangleInsets var21 = var20.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var22 = null;
//     var20.setToolTipGenerator(var22);
//     java.awt.Font var24 = var20.getLabelFont();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var24);
//     var25.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var25.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var25.setURLText("Range[0.0,1.0]");
//     var25.setURLText("");
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getLabelPadding();
//     boolean var40 = var38.getLabelLinksVisible();
//     org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var43 = var42.getNextFillPaint();
//     var38.setSectionOutlinePaint((java.lang.Comparable)"UnitType.ABSOLUTE", var43);
//     var25.setPaint(var43);
//     boolean var46 = var17.equals((java.lang.Object)var43);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("WMAP_Plot", "UnitType.ABSOLUTE", var3);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
//     var7.setSectionOutlinesVisible(true);
//     java.awt.Paint var11 = var7.getBaseSectionPaint();
//     var4.setAxisLinePaint(var11);
//     double var13 = var4.getLowerMargin();
//     boolean var14 = var4.isVerticalTickLabels();
//     var4.setPositiveArrowVisible(true);
//     org.jfree.data.Range var17 = var4.getRange();
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(3.0d, var17);
//     org.jfree.chart.util.Size2D var19 = var0.arrange(var1, var2, var18);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var24 = null;
//     var22.setToolTipGenerator(var24);
//     java.awt.Font var26 = var22.getLabelFont();
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var26);
//     double var28 = var27.getHeight();
//     boolean var29 = var1.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var7 and var22
//     assertTrue("Contract failed: equals-hashcode on var7 and var22", var7.equals(var22) ? var7.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var7
//     assertTrue("Contract failed: equals-hashcode on var22 and var7", var22.equals(var7) ? var22.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    var1.setSimpleLabels(true);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
    var0.setRangeCrosshairVisible(true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
//     var0.setDomainAxes(var3);
//     org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     var0.setRenderer(100, var8, false);
//     java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     boolean var28 = var21.equals((java.lang.Object)var27);
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var33 = null;
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
//     java.lang.Object var36 = var35.clone();
//     var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
//     java.awt.Graphics2D var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     var0.drawBackground(var38, var39);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setDomainAxisLocation(1, var7, false);
    java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
    var1.setBaseSectionOutlineStroke(var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setForegroundAlpha(1.0f);
    java.awt.Font var15 = var12.getNoDataMessageFont();
    var1.setLabelFont(var15);
    java.awt.Paint var17 = var1.getBaseSectionPaint();
    double var18 = var1.getMaximumLabelWidth();
    var1.setSectionOutlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.14d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("UnitType.ABSOLUTE");

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     var0.zoom(0.0d);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("WMAP_Plot", var1, 1.0f, 100.0f, (-7.0d), 0.0f, 0.0f);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 0);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var24.setAlpha(2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Font var3 = var0.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
//     var5.setSectionOutlinesVisible(true);
//     java.awt.Paint var9 = var5.getBaseSectionPaint();
//     var0.setRangeCrosshairPaint(var9);
//     java.lang.Object var11 = var0.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     var0.handleClick(0, (-65536), var14);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    var7.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var10 = var7.getPadding();
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    org.jfree.chart.util.RectangleInsets var13 = var12.getLabelPadding();
    boolean var14 = var10.equals((java.lang.Object)var12);
    java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var19);
    org.jfree.chart.util.HorizontalAlignment var21 = null;
    org.jfree.chart.util.VerticalAlignment var22 = null;
    org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var28 = null;
    var26.setDomainAxisLocation(1, var28, false);
    java.awt.Stroke var31 = var26.getRangeCrosshairStroke();
    boolean var32 = var25.equals((java.lang.Object)var31);
    java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var37 = null;
    org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var19, var31, (java.awt.Paint)var36, var37, 1.0f);
    var12.setBackgroundPaint((java.awt.Paint)var36);
    java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var45);
    org.jfree.chart.util.HorizontalAlignment var47 = null;
    org.jfree.chart.util.VerticalAlignment var48 = null;
    org.jfree.chart.block.ColumnArrangement var51 = new org.jfree.chart.block.ColumnArrangement(var47, var48, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var54 = null;
    var52.setDomainAxisLocation(1, var54, false);
    java.awt.Stroke var57 = var52.getRangeCrosshairStroke();
    boolean var58 = var51.equals((java.lang.Object)var57);
    java.awt.Color var62 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var63 = null;
    org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var45, var57, (java.awt.Paint)var62, var63, 1.0f);
    java.awt.color.ColorSpace var66 = var45.getColorSpace();
    float[] var67 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var68 = var36.getComponents(var66, var67);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var7 = var6.clone();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
    var9.setSectionOutlinesVisible(true);
    java.awt.Paint var13 = var9.getBaseSectionPaint();
    var6.setAxisLinePaint(var13);
    org.jfree.data.Range var15 = var6.getDefaultAutoRange();
    var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var19 = null;
    var17.setDomainAxisLocation(1, var19, false);
    java.awt.Stroke var22 = var17.getRangeCrosshairStroke();
    var17.setRangeCrosshairLockedOnData(false);
    java.awt.geom.Point2D var25 = var17.getQuadrantOrigin();
    boolean var26 = var6.hasListener((java.util.EventListener)var17);
    boolean var27 = var6.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Multiple Pie Plot", "Other", var3);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
    int var9 = var8.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1, true);
//     var0.clearDomainMarkers(100);
//     var0.setOutlineVisible(true);
//     org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
//     java.awt.Paint var10 = var0.getRangeGridlinePaint();
//     var0.clearRangeMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     var0.handleClick((-65536), 0, var14);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setDomainAxisLocation(1, var7, false);
    java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
    var1.setBaseSectionOutlineStroke(var10);
    java.lang.Comparable var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var13 = var1.getSectionOutlinePaint(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     var0.setRenderer(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     java.util.List var12 = null;
//     var0.drawRangeTickBands(var10, var11, var12);
//     float var14 = var0.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.setForegroundAlpha(1.0f);
//     java.awt.Paint var18 = var15.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var15);
//     java.awt.Color var24 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var24);
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setDomainAxisLocation(1, var33, false);
//     java.awt.Stroke var36 = var31.getRangeCrosshairStroke();
//     boolean var37 = var30.equals((java.lang.Object)var36);
//     java.awt.Color var41 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var42 = null;
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var24, var36, (java.awt.Paint)var41, var42, 1.0f);
//     org.jfree.chart.event.MarkerChangeListener var45 = null;
//     var44.addChangeListener(var45);
//     org.jfree.chart.util.Layer var47 = null;
//     boolean var48 = var15.removeRangeMarker((org.jfree.chart.plot.Marker)var44, var47);
//     boolean var49 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var44);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var12 = null;
//     var10.setToolTipGenerator(var12);
//     java.awt.Font var14 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var14);
//     var15.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var15.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var15.setURLText("Range[0.0,1.0]");
//     var7.setTitle(var15);
//     org.jfree.chart.ChartRenderingInfo var28 = null;
//     var7.handleClick(0, 1, var28);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.util.RectangleInsets var3 = var1.getSimpleLabelOffset();
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var7 = var3.createOutsetRectangle(var4, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
    java.awt.Stroke var5 = var0.getOutlineStroke();
    org.jfree.data.general.DatasetChangeEvent var6 = null;
    var0.datasetChanged(var6);
    org.jfree.chart.LegendItemCollection var8 = var0.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var19 = null;
//     var17.setToolTipGenerator(var19);
//     java.awt.Font var21 = var17.getLabelFont();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var21);
//     org.jfree.chart.text.TextLine var23 = new org.jfree.chart.text.TextLine("Other", var21);
//     java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var28);
//     org.jfree.chart.util.HorizontalAlignment var30 = null;
//     org.jfree.chart.util.VerticalAlignment var31 = null;
//     org.jfree.chart.block.ColumnArrangement var34 = new org.jfree.chart.block.ColumnArrangement(var30, var31, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var37 = null;
//     var35.setDomainAxisLocation(1, var37, false);
//     java.awt.Stroke var40 = var35.getRangeCrosshairStroke();
//     boolean var41 = var34.equals((java.lang.Object)var40);
//     java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var46 = null;
//     org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var28, var40, (java.awt.Paint)var45, var46, 1.0f);
//     float var49 = var48.getAlpha();
//     java.awt.Paint var50 = var48.getLabelPaint();
//     java.awt.Paint var51 = var48.getPaint();
//     org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var21, var51, (-1.0f));
//     var7.setFont(var21);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
    java.awt.Stroke var5 = var0.getOutlineStroke();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var9 = null;
    var7.setToolTipGenerator(var9);
    org.jfree.chart.labels.PieSectionLabelGenerator var11 = var7.getLegendLabelToolTipGenerator();
    var7.setLabelLinkMargin(100.0d);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var17 = null;
    var15.setToolTipGenerator(var17);
    java.awt.Stroke var19 = var15.getBaseSectionOutlineStroke();
    var7.setLabelOutlineStroke(var19);
    var0.setRangeCrosshairStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var23 = var22.clone();
    int var24 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var22);
    var0.clearRangeMarkers(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var7 = var6.clone();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
//     var9.setSectionOutlinesVisible(true);
//     java.awt.Paint var13 = var9.getBaseSectionPaint();
//     var6.setAxisLinePaint(var13);
//     org.jfree.data.Range var15 = var6.getDefaultAutoRange();
//     var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var6);
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var20 = null;
//     var19.datasetChanged(var20);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     var19.setRenderer(1, var23);
//     org.jfree.chart.util.RectangleEdge var26 = var19.getDomainAxisEdge(10);
//     double var27 = var6.valueToJava2D((-7.0d), var18, var26);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getRangeMarkers(var5);
    org.jfree.data.general.DatasetChangeEvent var7 = null;
    var0.datasetChanged(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var11.setCategoryLabelPositionOffset((-65536));
    java.awt.Paint var18 = null;
    var11.setTickLabelPaint((java.lang.Comparable)"Other", var18);
    double var20 = var11.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
    java.awt.Stroke var5 = var0.getOutlineStroke();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var9 = null;
    var7.setToolTipGenerator(var9);
    org.jfree.chart.labels.PieSectionLabelGenerator var11 = var7.getLegendLabelToolTipGenerator();
    var7.setLabelLinkMargin(100.0d);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var17 = null;
    var15.setToolTipGenerator(var17);
    java.awt.Stroke var19 = var15.getBaseSectionOutlineStroke();
    var7.setLabelOutlineStroke(var19);
    var0.setRangeCrosshairStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var23 = var22.clone();
    int var24 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var22);
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var26 = var25.getQuadrantOrigin();
    var25.setRangeCrosshairValue(10.0d, true);
    boolean var30 = var25.isDomainZeroBaselineVisible();
    org.jfree.chart.plot.DatasetRenderingOrder var31 = var25.getDatasetRenderingOrder();
    var0.setDatasetRenderingOrder(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var1 = var0.getLabelURL();
    var0.configure();
    java.awt.Paint var3 = var0.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var4 = var0.getTickLabelInsets();
    double var6 = var4.calculateTopOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var1.axisChanged(var3);
    java.awt.Stroke var6 = var1.getSectionOutlineStroke((java.lang.Comparable)0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
//     var0.zoomRangeAxes(0.0d, var9, var11, false);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var16 = null;
//     var14.setDomainAxisLocation(1, var16, false);
//     java.awt.Stroke var19 = var14.getRangeCrosshairStroke();
//     var14.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     var14.setRenderer(var22);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     java.util.List var26 = null;
//     var14.drawRangeTickBands(var24, var25, var26);
//     float var28 = var14.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var30 = null;
//     var29.setFixedLegendItems(var30);
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     boolean var36 = var29.render(var32, var33, 10, var35);
//     org.jfree.chart.axis.AxisLocation var37 = var29.getDomainAxisLocation();
//     var14.setDomainAxisLocation(var37);
//     var0.setDomainAxisLocation(var37);
//     
//     // Checks the contract:  equals-hashcode on var0 and var14
//     assertTrue("Contract failed: equals-hashcode on var0 and var14", var0.equals(var14) ? var0.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    float[] var27 = new float[] { 0.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var28 = var21.getComponents(var27);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 100.0f, 1.0f, 0.0d, 100.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var7.setWidth((-1.0d));
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var20 = null;
//     var18.setToolTipGenerator(var20);
//     var18.setSectionOutlinesVisible(true);
//     double var24 = var18.getInteriorGap();
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D(var27);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.chart.plot.PiePlotState var31 = var18.initialise(var25, var26, (org.jfree.chart.plot.PiePlot)var28, (java.lang.Integer)0, var30);
//     boolean var32 = var7.equals((java.lang.Object)var31);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     var0.configureRangeAxes();
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var0.getCategoriesForAxis(var7);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.geom.Point2D var16 = var11.getQuadrantOrigin();
//     var0.zoomRangeAxes(6.0d, var10, var16, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     var0.setRenderer(var19, true);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.setForegroundAlpha(1.0f);
//     boolean var25 = var22.isDomainGridlinesVisible();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     var22.setRenderer(var26, true);
//     org.jfree.chart.axis.AxisLocation var30 = var22.getRangeAxisLocation((-1));
//     org.jfree.chart.axis.CategoryAnchor var31 = var22.getDomainGridlinePosition();
//     boolean var32 = var0.equals((java.lang.Object)var22);
//     
//     // Checks the contract:  equals-hashcode on var0 and var22
//     assertTrue("Contract failed: equals-hashcode on var0 and var22", var0.equals(var22) ? var0.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var5.setLicenceName("hi!");
    org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var9 = var8.getContributors();
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var8);
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setForegroundAlpha(1.0f);
    java.awt.Paint var15 = var12.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var12);
    org.jfree.chart.plot.Plot var17 = var16.getPlot();
    org.jfree.chart.event.ChartChangeEventType var18 = var16.getType();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var20 = var19.clone();
    double var21 = var19.getLowerBound();
    boolean var22 = var18.equals((java.lang.Object)var19);
    org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var5, var11, var18);
    java.lang.String var24 = var23.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.ChartRenderingInfo var10 = null;
//     var7.draw(var8, var9, var10);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    double var4 = var2.calculateRightOutset(100.0d);
    double var5 = var2.getLeft();
    java.awt.geom.Rectangle2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var2.createOutsetRectangle(var6, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3.0d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var7.setURLText("Range[0.0,1.0]");
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var22 = var21.getQuadrantOrigin();
//     var17.zoomDomainAxes((-1.0d), 3.0d, var20, var22);
//     org.jfree.chart.axis.AxisSpace var24 = null;
//     var17.setFixedRangeAxisSpace(var24);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     org.jfree.chart.util.RectangleInsets var28 = var27.getLabelPadding();
//     org.jfree.chart.util.UnitType var29 = var28.getUnitType();
//     var17.setAxisOffset(var28);
//     var7.setMargin(var28);
//     
//     // Checks the contract:  equals-hashcode on var2 and var27
//     assertTrue("Contract failed: equals-hashcode on var2 and var27", var2.equals(var27) ? var2.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var2
//     assertTrue("Contract failed: equals-hashcode on var27 and var2", var27.equals(var2) ? var27.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedDimension();
//     var0.setLabelAngle((-1.0d));
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var7 = null;
//     var6.setFixedDomainAxisSpace(var7, true);
//     var6.clearDomainMarkers(100);
//     org.jfree.chart.util.RectangleEdge var13 = var6.getRangeAxisEdge(0);
//     boolean var14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var13);
//     boolean var15 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var13);
//     double var16 = var0.valueToJava2D(3.0d, var5, var13);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var1 = null;
//     var0.datasetChanged(var1);
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
//     java.awt.Stroke var5 = var0.getOutlineStroke();
//     var0.mapDatasetToRangeAxis(100, 0);
//     java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var14);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var21.setDomainAxisLocation(1, var23, false);
//     java.awt.Stroke var26 = var21.getRangeCrosshairStroke();
//     boolean var27 = var20.equals((java.lang.Object)var26);
//     java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var32 = null;
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var14, var26, (java.awt.Paint)var31, var32, 1.0f);
//     java.lang.Object var35 = var34.clone();
//     org.jfree.chart.text.TextAnchor var36 = var34.getLabelTextAnchor();
//     org.jfree.chart.util.Layer var37 = null;
//     boolean var38 = var0.removeRangeMarker(10, (org.jfree.chart.plot.Marker)var34, var37);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var5.setLicenceName("hi!");
    java.lang.String var8 = var5.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    java.lang.Object var11 = var0.clone();
    int var12 = var0.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     java.lang.String var2 = var1.getPlotType();
//     java.awt.Paint var3 = var1.getAggregatedItemsPaint();
//     double var4 = var1.getLimit();
//     org.jfree.chart.LegendItemCollection var5 = var1.getLegendItems();
//     var1.setAggregatedItemsKey((java.lang.Comparable)0.14d);
//     org.jfree.chart.LegendItemCollection var8 = var1.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var5 and var8
//     assertTrue("Contract failed: equals-hashcode on var5 and var8", var5.equals(var8) ? var5.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var5
//     assertTrue("Contract failed: equals-hashcode on var8 and var5", var8.equals(var5) ? var8.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     var0.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(0);
//     var0.zoom(4.0d);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
    java.awt.Paint var10 = var0.getRangeGridlinePaint();
    org.jfree.chart.annotations.XYAnnotation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var8);
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setDomainAxisLocation(1, var17, false);
//     java.awt.Stroke var20 = var15.getRangeCrosshairStroke();
//     boolean var21 = var14.equals((java.lang.Object)var20);
//     java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var26 = null;
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var8, var20, (java.awt.Paint)var25, var26, 1.0f);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.text.TextAnchor var30 = var28.getLabelTextAnchor();
//     java.awt.geom.Rectangle2D var31 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var1, 100.0f, 100.0f, var30);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     var1.setAxisLinePaint(var8);
//     org.jfree.data.Range var10 = var1.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var13 = var12.clone();
//     org.jfree.data.Range var14 = var12.getRange();
//     org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.setForegroundAlpha(1.0f);
//     java.awt.Paint var19 = var16.getRangeCrosshairPaint();
//     boolean var20 = var15.equals((java.lang.Object)var16);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var23 = var22.clone();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getLabelPadding();
//     var25.setSectionOutlinesVisible(true);
//     java.awt.Paint var29 = var25.getBaseSectionPaint();
//     var22.setAxisLinePaint(var29);
//     org.jfree.data.Range var31 = var22.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(100.0d, var31);
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var34 = var33.clone();
//     org.jfree.data.Range var35 = var33.getRange();
//     org.jfree.data.Range var36 = org.jfree.data.Range.combine(var31, var35);
//     boolean var38 = var36.contains(100.0d);
//     java.lang.Object var39 = null;
//     boolean var40 = var36.equals(var39);
//     org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(var15, var36);
//     
//     // Checks the contract:  equals-hashcode on var4 and var25
//     assertTrue("Contract failed: equals-hashcode on var4 and var25", var4.equals(var25) ? var4.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var4
//     assertTrue("Contract failed: equals-hashcode on var25 and var4", var25.equals(var4) ? var25.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var13 = var7.getURLText();
//     var7.setURLText("RectangleConstraintType.RANGE");
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.setForegroundAlpha(1.0f);
//     java.awt.Font var21 = var18.getNoDataMessageFont();
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var23 = null;
//     var22.datasetChanged(var23);
//     java.awt.Stroke var25 = var22.getOutlineStroke();
//     java.awt.Paint var26 = var22.getRangeZeroBaselinePaint();
//     org.jfree.chart.text.TextLine var27 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var21, var26);
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var21);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var33 = null;
//     var31.setToolTipGenerator(var33);
//     java.awt.Font var35 = var31.getLabelFont();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var35);
//     var36.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var42 = var36.getURLText();
//     org.jfree.chart.block.BlockFrame var43 = var36.getFrame();
//     var28.setFrame(var43);
//     org.jfree.chart.util.VerticalAlignment var45 = var28.getVerticalAlignment();
//     var7.setVerticalAlignment(var45);
//     
//     // Checks the contract:  equals-hashcode on var2 and var31
//     assertTrue("Contract failed: equals-hashcode on var2 and var31", var2.equals(var31) ? var2.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var2
//     assertTrue("Contract failed: equals-hashcode on var31 and var2", var31.equals(var2) ? var31.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     var7.fireChartChanged();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setForegroundAlpha(1.0f);
//     java.awt.Font var14 = var11.getNoDataMessageFont();
//     var11.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var11);
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     org.jfree.chart.util.RectangleInsets var21 = var20.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var22 = null;
//     var20.setToolTipGenerator(var22);
//     java.awt.Font var24 = var20.getLabelFont();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var24);
//     var25.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var25.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var25.setURLText("Range[0.0,1.0]");
//     var17.setTitle(var25);
//     java.awt.RenderingHints var36 = var17.getRenderingHints();
//     var7.setRenderingHints(var36);
//     
//     // Checks the contract:  equals-hashcode on var1 and var11
//     assertTrue("Contract failed: equals-hashcode on var1 and var11", var1.equals(var11) ? var1.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var1
//     assertTrue("Contract failed: equals-hashcode on var11 and var1", var11.equals(var1) ? var11.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var13 = var7.getURLText();
//     org.jfree.chart.block.BlockFrame var14 = var7.getFrame();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
//     org.jfree.chart.util.RectangleInsets var18 = var16.getSimpleLabelOffset();
//     boolean var19 = var7.equals((java.lang.Object)var18);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Shape var2 = var0.getLeftArrow();
//     org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "Pie 3D Plot");
//     var4.setURLText("");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var7 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var8 = null;
//     java.lang.String var9 = var4.getImageMapAreaTag(var7, var8);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
    var0.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var0.setFixedDomainAxisSpace(var15);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var19 = var18.clone();
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
    org.jfree.chart.util.RectangleInsets var22 = var21.getLabelPadding();
    var21.setSectionOutlinesVisible(true);
    java.awt.Paint var25 = var21.getBaseSectionPaint();
    var18.setAxisLinePaint(var25);
    double var27 = var18.getLowerMargin();
    boolean var28 = var18.isVerticalTickLabels();
    var18.setPositiveArrowVisible(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-65536), (org.jfree.chart.axis.ValueAxis)var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
//     var3.setSectionOutlinesVisible(true);
//     java.awt.Paint var7 = var3.getBaseSectionPaint();
//     var0.setAxisLinePaint(var7);
//     org.jfree.data.Range var9 = var0.getDefaultAutoRange();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.setForegroundAlpha(1.0f);
//     java.awt.Font var13 = var10.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getLabelPadding();
//     var15.setSectionOutlinesVisible(true);
//     java.awt.Paint var19 = var15.getBaseSectionPaint();
//     var10.setRangeCrosshairPaint(var19);
//     var0.setTickLabelPaint(var19);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var18 = null;
//     var16.setDomainAxisLocation(1, var18, false);
//     java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
//     boolean var22 = var15.equals((java.lang.Object)var21);
//     java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
//     org.jfree.chart.event.MarkerChangeListener var30 = null;
//     var29.addChangeListener(var30);
//     org.jfree.chart.util.Layer var32 = null;
//     boolean var33 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var29, var32);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.setForegroundAlpha(1.0f);
//     java.awt.Paint var38 = var35.getRangeCrosshairPaint();
//     org.jfree.chart.util.SortOrder var39 = var35.getRowRenderingOrder();
//     java.awt.Color var44 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var45 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var44);
//     org.jfree.chart.util.HorizontalAlignment var46 = null;
//     org.jfree.chart.util.VerticalAlignment var47 = null;
//     org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var46, var47, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var53 = null;
//     var51.setDomainAxisLocation(1, var53, false);
//     java.awt.Stroke var56 = var51.getRangeCrosshairStroke();
//     boolean var57 = var50.equals((java.lang.Object)var56);
//     java.awt.Color var61 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var62 = null;
//     org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var44, var56, (java.awt.Paint)var61, var62, 1.0f);
//     org.jfree.chart.event.MarkerChangeListener var65 = null;
//     var64.addChangeListener(var65);
//     var35.addRangeMarker((org.jfree.chart.plot.Marker)var64);
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot();
//     var69.setForegroundAlpha(1.0f);
//     java.awt.Font var72 = var69.getNoDataMessageFont();
//     var69.setAnchorValue(100.0d);
//     org.jfree.chart.axis.CategoryAxis var76 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var76.setMaximumCategoryLabelLines((-1));
//     int var79 = var69.getDomainAxisIndex(var76);
//     var35.setDomainAxis(100, var76);
//     org.jfree.chart.axis.CategoryAxis var83 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var35.setDomainAxis(1, var83, true);
//     var0.setDomainAxis(100, var83);
//     
//     // Checks the contract:  equals-hashcode on var10 and var45
//     assertTrue("Contract failed: equals-hashcode on var10 and var45", var10.equals(var45) ? var10.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var10
//     assertTrue("Contract failed: equals-hashcode on var45 and var10", var45.equals(var10) ? var45.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var50
//     assertTrue("Contract failed: equals-hashcode on var15 and var50", var15.equals(var50) ? var15.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var15
//     assertTrue("Contract failed: equals-hashcode on var50 and var15", var50.equals(var15) ? var50.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var51
//     assertTrue("Contract failed: equals-hashcode on var16 and var51", var16.equals(var51) ? var16.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var16
//     assertTrue("Contract failed: equals-hashcode on var51 and var16", var51.equals(var16) ? var51.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var64
//     assertTrue("Contract failed: equals-hashcode on var29 and var64", var29.equals(var64) ? var29.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var29
//     assertTrue("Contract failed: equals-hashcode on var64 and var29", var64.equals(var29) ? var64.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     boolean var7 = var0.render(var3, var4, 10, var6);
//     org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var12 = var11.getUpperMargin();
//     var0.setDomainAxis(10, var11, false);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var19 = null;
//     var18.setFixedDomainAxisSpace(var19, true);
//     var18.clearDomainMarkers(100);
//     org.jfree.chart.util.RectangleEdge var25 = var18.getRangeAxisEdge(0);
//     double var26 = var11.getCategoryEnd(0, (-1), var17, var25);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.configureRangeAxes();
    boolean var6 = var0.isDomainZoomable();
    boolean var7 = var0.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     var22.setRangeCrosshairLockedOnData(false);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
//     var22.setAxisOffset(var32);
//     var20.setItemLabelPadding(var32);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     var36.setForegroundAlpha(1.0f);
//     java.awt.Font var39 = var36.getNoDataMessageFont();
//     var36.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var36);
//     java.awt.Paint var43 = var42.getBackgroundPaint();
//     var42.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var45 = var42.getPadding();
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
//     org.jfree.chart.util.RectangleInsets var48 = var47.getLabelPadding();
//     boolean var49 = var45.equals((java.lang.Object)var47);
//     double var51 = var45.calculateLeftOutset(0.05d);
//     var20.setLegendItemGraphicPadding(var45);
//     
//     // Checks the contract:  equals-hashcode on var1 and var36
//     assertTrue("Contract failed: equals-hashcode on var1 and var36", var1.equals(var36) ? var1.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var1
//     assertTrue("Contract failed: equals-hashcode on var36 and var1", var36.equals(var1) ? var36.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var42
//     assertTrue("Contract failed: equals-hashcode on var7 and var42", var7.equals(var42) ? var7.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var7
//     assertTrue("Contract failed: equals-hashcode on var42 and var7", var42.equals(var7) ? var42.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var47
//     assertTrue("Contract failed: equals-hashcode on var31 and var47", var31.equals(var47) ? var31.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var31
//     assertTrue("Contract failed: equals-hashcode on var47 and var31", var47.equals(var31) ? var47.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.event.RendererChangeEvent var3 = null;
//     var2.rendererChanged(var3);
//     org.jfree.chart.LegendItemCollection var5 = var2.getLegendItems();
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var3 = null;
//     var1.setToolTipGenerator(var3);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var7 = null;
//     var5.setDomainAxisLocation(1, var7, false);
//     java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
//     var1.setBaseSectionOutlineStroke(var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setForegroundAlpha(1.0f);
//     java.awt.Font var15 = var12.getNoDataMessageFont();
//     var1.setLabelFont(var15);
//     java.awt.Paint var17 = var1.getBaseSectionPaint();
//     double var18 = var1.getMaximumLabelWidth();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     org.jfree.chart.util.RectangleInsets var21 = var20.getLabelPadding();
//     boolean var22 = var20.getLabelLinksVisible();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var20.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var24);
//     org.jfree.chart.labels.PieSectionLabelGenerator var26 = var20.getLegendLabelToolTipGenerator();
//     boolean var27 = var20.getSectionOutlinesVisible();
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.ColumnArrangement var32 = new org.jfree.chart.block.ColumnArrangement(var28, var29, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var35 = null;
//     var33.setDomainAxisLocation(1, var35, false);
//     java.awt.Stroke var38 = var33.getRangeCrosshairStroke();
//     boolean var39 = var32.equals((java.lang.Object)var38);
//     var20.setLabelLinkStroke(var38);
//     var1.setLabelLinkStroke(var38);
//     
//     // Checks the contract:  equals-hashcode on var5 and var33
//     assertTrue("Contract failed: equals-hashcode on var5 and var33", var5.equals(var33) ? var5.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var5
//     assertTrue("Contract failed: equals-hashcode on var33 and var5", var33.equals(var5) ? var33.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var24 = null;
    var22.setToolTipGenerator(var24);
    java.awt.Stroke var26 = var22.getBaseSectionOutlineStroke();
    java.awt.Paint var27 = var22.getLabelLinkPaint();
    var20.setItemPaint(var27);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var33 = var32.darker();
    var20.setBackgroundPaint((java.awt.Paint)var33);
    java.awt.Color var35 = var33.brighter();
    java.awt.Paint[] var36 = new java.awt.Paint[] { var33};
    java.awt.Paint[] var37 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke[] var38 = null;
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var40 = var39.getQuadrantOrigin();
    var39.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var44 = var39.getDomainCrosshairPaint();
    java.awt.Paint[] var45 = new java.awt.Paint[] { var44};
    org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var47 = var46.getNextPaint();
    java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
    java.awt.Color var52 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var53 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var52);
    java.awt.Paint[] var54 = new java.awt.Paint[] { var52};
    org.jfree.chart.plot.DefaultDrawingSupplier var55 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var56 = var55.getNextFillPaint();
    java.awt.Stroke var57 = var55.getNextOutlineStroke();
    java.awt.Stroke var58 = var55.getNextOutlineStroke();
    java.awt.Stroke[] var59 = new java.awt.Stroke[] { var58};
    org.jfree.data.general.PieDataset var60 = null;
    org.jfree.chart.plot.PiePlot var61 = new org.jfree.chart.plot.PiePlot(var60);
    org.jfree.chart.util.RectangleInsets var62 = var61.getLabelPadding();
    boolean var63 = var61.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var65 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var61.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var65);
    org.jfree.chart.labels.PieSectionLabelGenerator var67 = var61.getLegendLabelToolTipGenerator();
    java.awt.Stroke var68 = var61.getBaseSectionOutlineStroke();
    java.awt.Stroke[] var69 = new java.awt.Stroke[] { var68};
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var71 = var70.clone();
    java.awt.Shape var72 = var70.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var74 = new org.jfree.chart.entity.ChartEntity(var72, "Pie 3D Plot");
    java.awt.Shape[] var75 = new java.awt.Shape[] { var72};
    org.jfree.chart.plot.DefaultDrawingSupplier var76 = new org.jfree.chart.plot.DefaultDrawingSupplier(var45, var48, var54, var59, var69, var75);
    org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var78 = var77.clone();
    java.awt.Shape var79 = var77.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var81 = new org.jfree.chart.entity.ChartEntity(var79, "Pie 3D Plot");
    org.jfree.chart.entity.ChartEntity var82 = new org.jfree.chart.entity.ChartEntity(var79);
    java.awt.Shape[] var83 = new java.awt.Shape[] { var79};
    org.jfree.chart.plot.DefaultDrawingSupplier var84 = new org.jfree.chart.plot.DefaultDrawingSupplier(var36, var37, var38, var59, var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
//     var1.setSectionOutlinesVisible(true);
//     java.awt.Paint var5 = var1.getShadowPaint();
//     int var6 = var1.getPieIndex();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setForegroundAlpha(1.0f);
//     java.awt.Paint var10 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var7);
//     java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var16);
//     org.jfree.chart.util.HorizontalAlignment var18 = null;
//     org.jfree.chart.util.VerticalAlignment var19 = null;
//     org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var25 = null;
//     var23.setDomainAxisLocation(1, var25, false);
//     java.awt.Stroke var28 = var23.getRangeCrosshairStroke();
//     boolean var29 = var22.equals((java.lang.Object)var28);
//     java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var34 = null;
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var16, var28, (java.awt.Paint)var33, var34, 1.0f);
//     org.jfree.chart.event.MarkerChangeListener var37 = null;
//     var36.addChangeListener(var37);
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var7.removeRangeMarker((org.jfree.chart.plot.Marker)var36, var39);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     var41.setForegroundAlpha(1.0f);
//     java.awt.Font var44 = var41.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
//     org.jfree.chart.util.RectangleInsets var47 = var46.getLabelPadding();
//     var46.setSectionOutlinesVisible(true);
//     java.awt.Paint var50 = var46.getBaseSectionPaint();
//     var41.setRangeCrosshairPaint(var50);
//     java.lang.Object var52 = var41.clone();
//     org.jfree.chart.LegendItemCollection var53 = var41.getLegendItems();
//     java.awt.Paint var54 = var41.getRangeCrosshairPaint();
//     var7.setDomainGridlinePaint(var54);
//     var1.setBaseSectionOutlinePaint(var54);
//     
//     // Checks the contract:  equals-hashcode on var1 and var46
//     assertTrue("Contract failed: equals-hashcode on var1 and var46", var1.equals(var46) ? var1.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var1
//     assertTrue("Contract failed: equals-hashcode on var46 and var1", var46.equals(var1) ? var46.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var12 = null;
//     var10.setToolTipGenerator(var12);
//     java.awt.Font var14 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var14);
//     var15.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var15.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var15.setURLText("Range[0.0,1.0]");
//     var7.setTitle(var15);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     org.jfree.chart.util.RectangleInsets var29 = var28.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var30 = null;
//     var28.setToolTipGenerator(var30);
//     java.awt.Font var32 = var28.getLabelFont();
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var32);
//     var33.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var33.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var33.setURLText("Range[0.0,1.0]");
//     org.jfree.chart.util.HorizontalAlignment var43 = var33.getHorizontalAlignment();
//     var15.setTextAlignment(var43);
//     
//     // Checks the contract:  equals-hashcode on var10 and var28
//     assertTrue("Contract failed: equals-hashcode on var10 and var28", var10.equals(var28) ? var10.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var10
//     assertTrue("Contract failed: equals-hashcode on var28 and var10", var28.equals(var10) ? var28.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Font var3 = var0.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
//     var5.setSectionOutlinesVisible(true);
//     java.awt.Paint var9 = var5.getBaseSectionPaint();
//     var0.setRangeCrosshairPaint(var9);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var15 = null;
//     var13.setDomainAxisLocation(1, var15, false);
//     java.awt.Stroke var18 = var13.getRangeCrosshairStroke();
//     var13.setRangeCrosshairLockedOnData(false);
//     java.awt.geom.Point2D var21 = var13.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     var0.draw(var11, var12, var21, var22, var23);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var7 = var6.clone();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
//     var9.setSectionOutlinesVisible(true);
//     java.awt.Paint var13 = var9.getBaseSectionPaint();
//     var6.setAxisLinePaint(var13);
//     org.jfree.data.Range var15 = var6.getDefaultAutoRange();
//     var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var6);
//     org.jfree.data.general.DatasetChangeEvent var17 = null;
//     var0.datasetChanged(var17);
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var20 = null;
//     var19.datasetChanged(var20);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     var19.setRenderer(1, var23);
//     org.jfree.chart.util.RectangleEdge var26 = var19.getDomainAxisEdge(10);
//     boolean var28 = var19.equals((java.lang.Object)(-1));
//     org.jfree.chart.axis.AxisLocation var30 = var19.getRangeAxisLocation(0);
//     var0.setRangeAxisLocation(var30);
//     java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var36);
//     org.jfree.chart.util.HorizontalAlignment var38 = null;
//     org.jfree.chart.util.VerticalAlignment var39 = null;
//     org.jfree.chart.block.ColumnArrangement var42 = new org.jfree.chart.block.ColumnArrangement(var38, var39, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var45 = null;
//     var43.setDomainAxisLocation(1, var45, false);
//     java.awt.Stroke var48 = var43.getRangeCrosshairStroke();
//     boolean var49 = var42.equals((java.lang.Object)var48);
//     java.awt.Color var53 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var54 = null;
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var36, var48, (java.awt.Paint)var53, var54, 1.0f);
//     float var57 = var56.getAlpha();
//     java.awt.Paint var58 = var56.getPaint();
//     boolean var59 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var56);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxisForDataset(0);
    var0.configureDomainAxes();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var14 = var0.getDomainAxisForDataset(15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedDimension();
//     org.jfree.data.RangeType var2 = var0.getRangeType();
//     var0.setLowerMargin(6.0d);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var11 = null;
//     var9.setToolTipGenerator(var11);
//     java.awt.Font var13 = var9.getLabelFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var13);
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("Other", var13);
//     java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var20);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var29 = null;
//     var27.setDomainAxisLocation(1, var29, false);
//     java.awt.Stroke var32 = var27.getRangeCrosshairStroke();
//     boolean var33 = var26.equals((java.lang.Object)var32);
//     java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var38 = null;
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var20, var32, (java.awt.Paint)var37, var38, 1.0f);
//     float var41 = var40.getAlpha();
//     java.awt.Paint var42 = var40.getLabelPaint();
//     java.awt.Paint var43 = var40.getPaint();
//     org.jfree.chart.text.TextFragment var45 = new org.jfree.chart.text.TextFragment("", var13, var43, (-1.0f));
//     var0.setTickLabelFont(var13);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     var48.setForegroundAlpha(1.0f);
//     java.awt.Paint var51 = var48.getRangeCrosshairPaint();
//     org.jfree.chart.util.SortOrder var52 = var48.getRowRenderingOrder();
//     var48.clearDomainAxes();
//     java.awt.geom.Rectangle2D var54 = null;
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var56 = null;
//     var55.setFixedDomainAxisSpace(var56, true);
//     var55.clearDomainMarkers(100);
//     org.jfree.chart.util.RectangleEdge var62 = var55.getRangeAxisEdge(0);
//     org.jfree.chart.axis.AxisSpace var63 = null;
//     org.jfree.chart.axis.AxisSpace var64 = var0.reserveSpace(var47, (org.jfree.chart.plot.Plot)var48, var54, var62, var63);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var4 = var3.getLabelShadowPaint();
    double var5 = var3.getMinimumArcAngleToDraw();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.set((-1), (java.lang.Object)var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-5d);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("java.awt.Color[r=255,g=0,b=0]", var1, var2, var3);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    var7.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var10 = var7.getPadding();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var11 = var7.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     var22.setRangeCrosshairLockedOnData(false);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
//     var22.setAxisOffset(var32);
//     var20.setItemLabelPadding(var32);
//     java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var39 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var38);
//     int var40 = var38.getGreen();
//     var20.setItemPaint((java.awt.Paint)var38);
//     java.awt.Graphics2D var42 = null;
//     java.awt.geom.Rectangle2D var43 = null;
//     var20.draw(var42, var43);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    var1.setSectionOutlinesVisible(true);
    double var7 = var1.getInteriorGap();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.PiePlotState var14 = var1.initialise(var8, var9, (org.jfree.chart.plot.PiePlot)var11, (java.lang.Integer)0, var13);
    org.jfree.chart.block.LineBorder var15 = new org.jfree.chart.block.LineBorder();
    boolean var16 = var11.equals((java.lang.Object)var15);
    org.jfree.chart.util.RectangleInsets var17 = var15.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Font var3 = var0.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
//     var5.setSectionOutlinesVisible(true);
//     java.awt.Paint var9 = var5.getBaseSectionPaint();
//     var0.setRangeCrosshairPaint(var9);
//     java.lang.Object var11 = var0.clone();
//     org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
//     var0.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var15 = null;
//     var0.setFixedDomainAxisSpace(var15);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.setForegroundAlpha(1.0f);
//     java.awt.Font var21 = var18.getNoDataMessageFont();
//     var18.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var18);
//     org.jfree.chart.axis.AxisLocation var25 = var18.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var26 = var18.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.ColumnArrangement var36 = new org.jfree.chart.block.ColumnArrangement(var32, var33, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18, (org.jfree.chart.block.Arrangement)var31, (org.jfree.chart.block.Arrangement)var36);
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
//     org.jfree.chart.util.RectangleInsets var40 = var39.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var41 = null;
//     var39.setToolTipGenerator(var41);
//     java.awt.Stroke var43 = var39.getBaseSectionOutlineStroke();
//     java.awt.Paint var44 = var39.getLabelLinkPaint();
//     var37.setItemPaint(var44);
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var48 = null;
//     var46.setDomainAxisLocation(1, var48, false);
//     java.awt.Stroke var51 = var46.getRangeCrosshairStroke();
//     var46.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.Plot var54 = var46.getRootPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     var46.setRenderer(var55);
//     java.awt.Paint var57 = var46.getDomainZeroBaselinePaint();
//     var37.setItemPaint(var57);
//     var0.setDomainGridlinePaint(var57);
//     
//     // Checks the contract:  equals-hashcode on var5 and var39
//     assertTrue("Contract failed: equals-hashcode on var5 and var39", var5.equals(var39) ? var5.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var5
//     assertTrue("Contract failed: equals-hashcode on var39 and var5", var39.equals(var5) ? var39.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 100);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var2 = var1.getLabelURL();
//     var1.configure();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     var5.setTickMarksVisible(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var8);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setForegroundAlpha(1.0f);
//     java.awt.Paint var15 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var12);
//     var12.configureRangeAxes();
//     boolean var18 = var12.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     java.util.List var20 = var12.getCategoriesForAxis(var19);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var25 = null;
//     var23.setDomainAxisLocation(1, var25, false);
//     java.awt.geom.Point2D var28 = var23.getQuadrantOrigin();
//     var12.zoomRangeAxes(6.0d, var22, var28, false);
//     org.jfree.chart.util.RectangleEdge var31 = var12.getDomainAxisEdge();
//     double var32 = var1.lengthToJava2D(0.0d, var11, var31);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
//     int var9 = var0.getRangeAxisCount();
//     org.jfree.chart.axis.AxisLocation var11 = var0.getDomainAxisLocation(100);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var16 = null;
//     var14.setDomainAxisLocation(1, var16, false);
//     java.awt.Stroke var19 = var14.getRangeCrosshairStroke();
//     var14.setRangeCrosshairLockedOnData(false);
//     java.awt.geom.Point2D var22 = var14.getQuadrantOrigin();
//     var0.zoomDomainAxes(3.0d, var13, var22);
//     
//     // Checks the contract:  equals-hashcode on var0 and var14
//     assertTrue("Contract failed: equals-hashcode on var0 and var14", var0.equals(var14) ? var0.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var5.setDomainAxes(var8);
//     org.jfree.data.xy.XYDataset var11 = var5.getDataset(100);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
//     var5.zoomRangeAxes(0.0d, var13, var15, false);
//     var0.zoomDomainAxes((-7.0d), var4, var15);
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var20 = var19.getLabelURL();
//     var19.configure();
//     java.awt.Paint var22 = var19.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var23 = var19.getTickLabelInsets();
//     double var25 = var23.calculateRightInset(0.05d);
//     var0.setAxisOffset(var23);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.setForegroundAlpha(1.0f);
//     java.awt.Font var30 = var27.getNoDataMessageFont();
//     var27.setAnchorValue(100.0d);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var35 = null;
//     var33.setDomainAxisLocation(1, var35, false);
//     java.awt.Stroke var38 = var33.getRangeCrosshairStroke();
//     org.jfree.chart.util.Layer var40 = null;
//     java.util.Collection var41 = var33.getRangeMarkers(10, var40);
//     java.util.List var42 = var33.getAnnotations();
//     org.jfree.chart.plot.PlotOrientation var43 = var33.getOrientation();
//     var27.setOrientation(var43);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.setForegroundAlpha(1.0f);
//     org.jfree.chart.axis.AxisSpace var48 = null;
//     var45.setFixedDomainAxisSpace(var48);
//     org.jfree.chart.util.SortOrder var50 = var45.getColumnRenderingOrder();
//     var27.setRowRenderingOrder(var50);
//     var0.setRowRenderingOrder(var50);
//     
//     // Checks the contract:  equals-hashcode on var14 and var33
//     assertTrue("Contract failed: equals-hashcode on var14 and var33", var14.equals(var33) ? var14.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var14
//     assertTrue("Contract failed: equals-hashcode on var33 and var14", var33.equals(var14) ? var33.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1, true);
//     var0.clearDomainMarkers(100);
//     var0.setOutlineVisible(true);
//     org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
//     java.awt.Paint var10 = var0.getRangeGridlinePaint();
//     var0.clearRangeMarkers();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var14 = null;
//     var12.setDomainAxisLocation(1, var14, false);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var19 = var18.clone();
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     org.jfree.chart.util.RectangleInsets var22 = var21.getLabelPadding();
//     var21.setSectionOutlinesVisible(true);
//     java.awt.Paint var25 = var21.getBaseSectionPaint();
//     var18.setAxisLinePaint(var25);
//     org.jfree.data.Range var27 = var18.getDefaultAutoRange();
//     var12.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var18);
//     org.jfree.data.general.DatasetChangeEvent var29 = null;
//     var12.datasetChanged(var29);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var32 = null;
//     var31.datasetChanged(var32);
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     var31.setRenderer(1, var35);
//     org.jfree.chart.util.RectangleEdge var38 = var31.getDomainAxisEdge(10);
//     boolean var40 = var31.equals((java.lang.Object)(-1));
//     org.jfree.chart.axis.AxisLocation var42 = var31.getRangeAxisLocation(0);
//     var12.setRangeAxisLocation(var42);
//     var0.setDomainAxisLocation(var42, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var31
//     assertTrue("Contract failed: equals-hashcode on var0 and var31", var0.equals(var31) ? var0.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var0
//     assertTrue("Contract failed: equals-hashcode on var31 and var0", var31.equals(var0) ? var31.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setForegroundAlpha(1.0f);
//     boolean var10 = var7.isDomainGridlinesVisible();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     var7.setRenderer(var11, true);
//     org.jfree.chart.axis.AxisLocation var15 = var7.getRangeAxisLocation((-1));
//     org.jfree.chart.axis.CategoryAnchor var16 = var7.getDomainGridlinePosition();
//     var0.setDomainGridlinePosition(var16);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    java.awt.Stroke var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setAxisLineStroke(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     var0.zoomDomainAxes((-1.0d), 3.0d, var3, var5);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.setForegroundAlpha(1.0f);
//     java.awt.Font var11 = var8.getNoDataMessageFont();
//     var8.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getDomainAxisLocation();
//     var0.setDomainAxisLocation(var15);
//     org.jfree.chart.axis.ValueAxis var18 = var0.getRangeAxis((-65536));
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.setForegroundAlpha(1.0f);
//     java.awt.Paint var22 = var19.getRangeCrosshairPaint();
//     org.jfree.chart.util.SortOrder var23 = var19.getRowRenderingOrder();
//     var0.setColumnRenderingOrder(var23);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var1 = var0.getPlotType();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var3 = null;
    var2.setFixedDomainAxisSpace(var3, true);
    var2.clearDomainMarkers(100);
    var2.setOutlineVisible(true);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var12 = var11.getTickLabelFont();
    var2.setNoDataMessageFont(var12);
    var0.setLabelFont(var12);
    double var15 = var0.getDepthFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Pie 3D Plot"+ "'", var1.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.12d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.setForegroundAlpha(1.0f);
    java.awt.Font var8 = var5.getNoDataMessageFont();
    var5.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var12.setMaximumCategoryLabelLines((-1));
    int var15 = var5.getDomainAxisIndex(var12);
    int var16 = var0.getDomainAxisIndex(var12);
    org.jfree.chart.annotations.CategoryAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset((-65536));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    var0.clearDomainAxes();
    org.jfree.chart.util.SortOrder var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRowRenderingOrder(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    var0.setRenderer(var5);
    java.awt.Stroke var7 = var0.getRangeCrosshairStroke();
    boolean var8 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]");
//     org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
//     java.awt.Graphics2D var3 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
//     org.jfree.chart.util.HorizontalAlignment var12 = null;
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var19 = null;
//     var17.setDomainAxisLocation(1, var19, false);
//     java.awt.Stroke var22 = var17.getRangeCrosshairStroke();
//     boolean var23 = var16.equals((java.lang.Object)var22);
//     java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var28 = null;
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var10, var22, (java.awt.Paint)var27, var28, 1.0f);
//     java.lang.Object var31 = var30.clone();
//     org.jfree.chart.text.TextAnchor var32 = var30.getLabelTextAnchor();
//     var1.draw(var3, 0.0f, (-1.0f), var32, 0.0f, 1.0f, 100.0d);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var1 = null;
//     var0.datasetChanged(var1);
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
//     java.awt.Stroke var5 = var0.getOutlineStroke();
//     var0.mapDatasetToRangeAxis(100, 0);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var0.handleClick(15, (-1), var11);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    org.jfree.chart.util.RectangleEdge var7 = var0.getRangeAxisEdge(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var9 = var0.getQuadrantPaint(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     var0.setRenderer(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     java.util.List var12 = null;
//     var0.drawRangeTickBands(var10, var11, var12);
//     java.awt.Image var14 = var0.getBackgroundImage();
//     java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var19);
//     org.jfree.chart.util.HorizontalAlignment var21 = null;
//     org.jfree.chart.util.VerticalAlignment var22 = null;
//     org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var28 = null;
//     var26.setDomainAxisLocation(1, var28, false);
//     java.awt.Stroke var31 = var26.getRangeCrosshairStroke();
//     boolean var32 = var25.equals((java.lang.Object)var31);
//     java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var37 = null;
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var19, var31, (java.awt.Paint)var36, var37, 1.0f);
//     float var40 = var39.getAlpha();
//     java.awt.Paint var41 = var39.getLabelPaint();
//     java.awt.Paint var42 = var39.getPaint();
//     var0.setDomainCrosshairPaint(var42);
//     java.util.List var44 = var0.getAnnotations();
//     java.awt.Color var49 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var50 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var49);
//     org.jfree.chart.util.HorizontalAlignment var51 = null;
//     org.jfree.chart.util.VerticalAlignment var52 = null;
//     org.jfree.chart.block.ColumnArrangement var55 = new org.jfree.chart.block.ColumnArrangement(var51, var52, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var58 = null;
//     var56.setDomainAxisLocation(1, var58, false);
//     java.awt.Stroke var61 = var56.getRangeCrosshairStroke();
//     boolean var62 = var55.equals((java.lang.Object)var61);
//     java.awt.Color var66 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var67 = null;
//     org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var49, var61, (java.awt.Paint)var66, var67, 1.0f);
//     int var70 = var66.getRGB();
//     var0.setDomainZeroBaselinePaint((java.awt.Paint)var66);
//     
//     // Checks the contract:  equals-hashcode on var26 and var56
//     assertTrue("Contract failed: equals-hashcode on var26 and var56", var26.equals(var56) ? var26.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var26
//     assertTrue("Contract failed: equals-hashcode on var56 and var26", var56.equals(var26) ? var56.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var50
//     assertTrue("Contract failed: equals-hashcode on var20 and var50", var20.equals(var50) ? var20.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var20
//     assertTrue("Contract failed: equals-hashcode on var50 and var20", var50.equals(var20) ? var50.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var55
//     assertTrue("Contract failed: equals-hashcode on var25 and var55", var25.equals(var55) ? var25.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var25
//     assertTrue("Contract failed: equals-hashcode on var55 and var25", var55.equals(var25) ? var55.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var69
//     assertTrue("Contract failed: equals-hashcode on var39 and var69", var39.equals(var69) ? var39.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var39
//     assertTrue("Contract failed: equals-hashcode on var69 and var39", var69.equals(var39) ? var69.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.14d, 3.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    var7.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var10 = var7.getPadding();
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    org.jfree.chart.util.RectangleInsets var13 = var12.getLabelPadding();
    boolean var14 = var10.equals((java.lang.Object)var12);
    java.awt.geom.Rectangle2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var16 = var10.createOutsetRectangle(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.text.TextAnchor var26 = var24.getLabelTextAnchor();
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var28 = null;
//     var27.setFixedDomainAxisSpace(var28, true);
//     var27.clearDomainMarkers(100);
//     var27.setOutlineVisible(true);
//     org.jfree.chart.axis.ValueAxis var36 = var27.getRangeAxis(0);
//     java.awt.Paint var37 = var27.getRangeGridlinePaint();
//     var27.clearRangeMarkers();
//     java.awt.Color var43 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var43);
//     org.jfree.chart.util.HorizontalAlignment var45 = null;
//     org.jfree.chart.util.VerticalAlignment var46 = null;
//     org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement(var45, var46, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var52 = null;
//     var50.setDomainAxisLocation(1, var52, false);
//     java.awt.Stroke var55 = var50.getRangeCrosshairStroke();
//     boolean var56 = var49.equals((java.lang.Object)var55);
//     java.awt.Color var60 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var61 = null;
//     org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var43, var55, (java.awt.Paint)var60, var61, 1.0f);
//     java.lang.Object var64 = var63.clone();
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var66 = var65.getQuadrantOrigin();
//     var65.setRangeCrosshairValue(10.0d, true);
//     org.jfree.data.xy.XYDataset var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = var65.getRendererForDataset(var70);
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
//     var73.setForegroundAlpha(1.0f);
//     java.awt.Font var76 = var73.getNoDataMessageFont();
//     var73.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var79 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var73);
//     org.jfree.chart.axis.AxisLocation var80 = var73.getDomainAxisLocation();
//     var65.setRangeAxisLocation(var80);
//     boolean var82 = var63.equals((java.lang.Object)var65);
//     java.awt.Paint var83 = var65.getDomainZeroBaselinePaint();
//     var27.setRangeGridlinePaint(var83);
//     var24.setOutlinePaint(var83);
//     
//     // Checks the contract:  equals-hashcode on var5 and var44
//     assertTrue("Contract failed: equals-hashcode on var5 and var44", var5.equals(var44) ? var5.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var5
//     assertTrue("Contract failed: equals-hashcode on var44 and var5", var44.equals(var5) ? var44.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var49
//     assertTrue("Contract failed: equals-hashcode on var10 and var49", var10.equals(var49) ? var10.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var10
//     assertTrue("Contract failed: equals-hashcode on var49 and var10", var49.equals(var10) ? var49.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var50
//     assertTrue("Contract failed: equals-hashcode on var11 and var50", var11.equals(var50) ? var11.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var11
//     assertTrue("Contract failed: equals-hashcode on var50 and var11", var50.equals(var11) ? var50.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var64
//     assertTrue("Contract failed: equals-hashcode on var25 and var64", var25.equals(var64) ? var25.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var25
//     assertTrue("Contract failed: equals-hashcode on var64 and var25", var64.equals(var25) ? var64.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
//     org.jfree.chart.util.UnitType var12 = var11.getUnitType();
//     var7.setPadding(var11);
//     org.jfree.chart.title.TextTitle var14 = var7.getTitle();
//     org.jfree.chart.event.TitleChangeEvent var15 = null;
//     var7.titleChanged(var15);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedDimension();
    org.jfree.data.RangeType var2 = var0.getRangeType();
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var2 = var0.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "Pie 3D Plot");
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var2);
    java.lang.String var6 = var5.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "poly"+ "'", var6.equals("poly"));

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "TextAnchor.CENTER", var3);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     var0.setRenderer(var8);
//     org.jfree.chart.axis.AxisSpace var10 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.setForegroundAlpha(1.0f);
//     java.awt.Font var16 = var13.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getLabelPadding();
//     var18.setSectionOutlinesVisible(true);
//     java.awt.Paint var22 = var18.getBaseSectionPaint();
//     var13.setRangeCrosshairPaint(var22);
//     java.lang.Object var24 = var13.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var28 = null;
//     var27.datasetChanged(var28);
//     java.awt.Paint var30 = var27.getRangeZeroBaselinePaint();
//     var27.setRangeGridlinesVisible(true);
//     var27.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var38 = var37.getQuadrantOrigin();
//     var27.zoomRangeAxes(0.0d, var36, var38);
//     var13.zoomDomainAxes((-1.0d), var26, var38);
//     var0.zoomRangeAxes(100.0d, var12, var38);
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var44 = var43.getQuadrantOrigin();
//     var43.setRangeCrosshairValue(10.0d, true);
//     boolean var48 = var43.isDomainZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = var43.getRendererForDataset(var49);
//     java.awt.Color var55 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var55);
//     org.jfree.chart.util.HorizontalAlignment var57 = null;
//     org.jfree.chart.util.VerticalAlignment var58 = null;
//     org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement(var57, var58, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var64 = null;
//     var62.setDomainAxisLocation(1, var64, false);
//     java.awt.Stroke var67 = var62.getRangeCrosshairStroke();
//     boolean var68 = var61.equals((java.lang.Object)var67);
//     java.awt.Color var72 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var73 = null;
//     org.jfree.chart.plot.ValueMarker var75 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var55, var67, (java.awt.Paint)var72, var73, 1.0f);
//     var43.setDomainCrosshairPaint((java.awt.Paint)var72);
//     org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var78 = null;
//     var77.setFixedLegendItems(var78);
//     java.awt.Graphics2D var80 = null;
//     java.awt.geom.Rectangle2D var81 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var83 = null;
//     boolean var84 = var77.render(var80, var81, 10, var83);
//     org.jfree.chart.axis.AxisLocation var85 = var77.getDomainAxisLocation();
//     var43.setRangeAxisLocation(var85);
//     var0.setDomainAxisLocation(1, var85);
//     
//     // Checks the contract:  equals-hashcode on var37 and var62
//     assertTrue("Contract failed: equals-hashcode on var37 and var62", var37.equals(var62) ? var37.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var37
//     assertTrue("Contract failed: equals-hashcode on var62 and var37", var62.equals(var37) ? var62.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var12 = null;
    var10.setToolTipGenerator(var12);
    java.awt.Font var14 = var10.getLabelFont();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var14);
    var15.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var15.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var15.setURLText("Range[0.0,1.0]");
    var7.setTitle(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var26 = var7.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var9};
    var8.setDomainAxes(var11);
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    var8.setRenderer(var13);
    java.awt.Stroke var15 = var8.getRangeCrosshairStroke();
    var7.setBorderStroke(var15);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var21);
    org.jfree.chart.util.HorizontalAlignment var23 = null;
    org.jfree.chart.util.VerticalAlignment var24 = null;
    org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var30 = null;
    var28.setDomainAxisLocation(1, var30, false);
    java.awt.Stroke var33 = var28.getRangeCrosshairStroke();
    boolean var34 = var27.equals((java.lang.Object)var33);
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var39 = null;
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var21, var33, (java.awt.Paint)var38, var39, 1.0f);
    float var42 = var41.getAlpha();
    java.awt.Paint var43 = var41.getLabelPaint();
    java.awt.Paint var44 = var41.getPaint();
    boolean var45 = var7.equals((java.lang.Object)var41);
    org.jfree.chart.util.LengthAdjustmentType var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var41.setLabelOffsetType(var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var9};
    var8.setDomainAxes(var11);
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    var8.setRenderer(var13);
    java.awt.Stroke var15 = var8.getRangeCrosshairStroke();
    var7.setBorderStroke(var15);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var21);
    org.jfree.chart.util.HorizontalAlignment var23 = null;
    org.jfree.chart.util.VerticalAlignment var24 = null;
    org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var30 = null;
    var28.setDomainAxisLocation(1, var30, false);
    java.awt.Stroke var33 = var28.getRangeCrosshairStroke();
    boolean var34 = var27.equals((java.lang.Object)var33);
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var39 = null;
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var21, var33, (java.awt.Paint)var38, var39, 1.0f);
    float var42 = var41.getAlpha();
    java.awt.Paint var43 = var41.getLabelPaint();
    java.awt.Paint var44 = var41.getPaint();
    boolean var45 = var7.equals((java.lang.Object)var41);
    java.awt.Paint var46 = var7.getBorderPaint();
    org.jfree.chart.event.ChartChangeListener var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addChangeListener(var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     var1.setAxisLinePaint(var8);
//     org.jfree.data.Range var10 = var1.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
//     org.jfree.chart.block.LengthConstraintType var12 = var11.getHeightConstraintType();
//     double var13 = var11.getHeight();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var15 = var14.clone();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getLabelPadding();
//     var17.setSectionOutlinesVisible(true);
//     java.awt.Paint var21 = var17.getBaseSectionPaint();
//     var14.setAxisLinePaint(var21);
//     org.jfree.data.Range var23 = var14.getDefaultAutoRange();
//     java.lang.String var24 = var23.toString();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var27 = var26.clone();
//     org.jfree.chart.util.RectangleInsets var28 = var26.getLabelInsets();
//     double var30 = var28.calculateBottomOutset(10.0d);
//     var25.setAxisOffset(var28);
//     var25.clearDomainAxes();
//     boolean var33 = var23.equals((java.lang.Object)var25);
//     org.jfree.chart.block.RectangleConstraint var34 = var11.toRangeWidth(var23);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.Comparable var2 = var1.getAggregatedItemsKey();
    java.lang.Comparable var3 = var1.getAggregatedItemsKey();
    java.lang.String var4 = var1.getPlotType();
    java.awt.Graphics2D var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    var1.drawBackgroundImage(var5, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Other"+ "'", var2.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Other"+ "'", var3.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Multiple Pie Plot"+ "'", var4.equals("Multiple Pie Plot"));

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedDomainAxisSpace(var3);
    org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
    var0.setAnchorValue(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    boolean var15 = var0.isRangeCrosshairVisible();
    boolean var16 = var0.isDomainZoomable();
    org.jfree.chart.annotations.CategoryAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, 1.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var1 = var0.getPlotType();
//     java.awt.Stroke var2 = var0.getLabelOutlineStroke();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var5.setDomainAxes(var8);
//     java.awt.geom.Point2D var10 = var5.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var0.draw(var3, var4, var10, var11, var12);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     boolean var7 = var0.render(var3, var4, 10, var6);
//     org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var12 = var11.getUpperMargin();
//     var0.setDomainAxis(10, var11, false);
//     var0.clearRangeAxes();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.setForegroundAlpha(1.0f);
//     java.awt.Paint var19 = var16.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var16);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setForegroundAlpha(1.0f);
//     java.awt.Font var24 = var21.getNoDataMessageFont();
//     var21.setAnchorValue(100.0d);
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var28.setMaximumCategoryLabelLines((-1));
//     int var31 = var21.getDomainAxisIndex(var28);
//     int var32 = var16.getDomainAxisIndex(var28);
//     java.util.List var33 = var0.getCategoriesForAxis(var28);
//     
//     // Checks the contract:  equals-hashcode on var16 and var0
//     assertTrue("Contract failed: equals-hashcode on var16 and var0", var16.equals(var0) ? var16.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var0.", var16.equals(var0) == var0.equals(var16));
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 1.0f};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 10};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    var0.setAnchorValue(0.0d, false);
    boolean var7 = var0.isRangeZoomable();
    org.jfree.chart.plot.CategoryMarker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(100, var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var14);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var23 = null;
    var21.setDomainAxisLocation(1, var23, false);
    java.awt.Stroke var26 = var21.getRangeCrosshairStroke();
    boolean var27 = var20.equals((java.lang.Object)var26);
    java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var32 = null;
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var14, var26, (java.awt.Paint)var31, var32, 1.0f);
    var0.setDomainGridlinePaint((java.awt.Paint)var14);
    float[] var37 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var38 = var14.getColorComponents(var37);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     var1.setAxisLinePaint(var8);
//     org.jfree.data.Range var10 = var1.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
//     org.jfree.chart.block.LengthConstraintType var12 = var11.getHeightConstraintType();
//     org.jfree.chart.block.RectangleConstraint var13 = var11.toUnconstrainedHeight();
//     org.jfree.chart.block.RectangleConstraint var14 = var11.toUnconstrainedWidth();
//     org.jfree.chart.util.Size2D var15 = null;
//     org.jfree.chart.util.Size2D var16 = var11.calculateConstrainedSize(var15);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.configureRangeAxes();
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var0.getCategoriesForAxis(var7);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.geom.Point2D var16 = var11.getQuadrantOrigin();
    var0.zoomRangeAxes(6.0d, var10, var16, false);
    org.jfree.chart.annotations.CategoryAnnotation var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var20 = var0.removeAnnotation(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

//  public void test320() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
//
//
//    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var0 == false);
//
//  }
//
  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var12 = null;
    var10.setToolTipGenerator(var12);
    java.awt.Font var14 = var10.getLabelFont();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var14);
    var15.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var15.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var15.setURLText("Range[0.0,1.0]");
    var7.setTitle(var15);
    org.jfree.chart.ChartRenderingInfo var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var29 = var7.createBufferedImage((-65536), 100, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-65536), var5, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var5 = var4.clone();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
    var7.setSectionOutlinesVisible(true);
    java.awt.Paint var11 = var7.getBaseSectionPaint();
    var4.setAxisLinePaint(var11);
    double var13 = var4.getLowerMargin();
    boolean var14 = var4.isVerticalTickLabels();
    var4.setPositiveArrowVisible(true);
    org.jfree.data.Range var17 = var4.getRange();
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(3.0d, var17);
    org.jfree.chart.util.Size2D var19 = var0.arrange(var1, var2, var18);
    org.jfree.chart.util.RectangleInsets var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPadding(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    var0.mapDatasetToDomainAxis((-1), 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var7 = var0.getRangeAxisForDataset((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     var1.setAxisLinePaint(var8);
//     org.jfree.data.Range var10 = var1.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var13 = var12.clone();
//     org.jfree.data.Range var14 = var12.getRange();
//     org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
//     boolean var17 = var10.contains(1.0E-5d);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var19 = var18.clone();
//     var18.setVisible(false);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var24 = var23.clone();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var26.getLabelPadding();
//     var26.setSectionOutlinesVisible(true);
//     java.awt.Paint var30 = var26.getBaseSectionPaint();
//     var23.setAxisLinePaint(var30);
//     org.jfree.data.Range var32 = var23.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(100.0d, var32);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var35 = var34.clone();
//     org.jfree.data.Range var36 = var34.getRange();
//     org.jfree.data.Range var37 = org.jfree.data.Range.combine(var32, var36);
//     var18.setRangeWithMargins(var36);
//     double var39 = var36.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint(var10, var36);
//     
//     // Checks the contract:  equals-hashcode on var4 and var26
//     assertTrue("Contract failed: equals-hashcode on var4 and var26", var4.equals(var26) ? var4.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var4
//     assertTrue("Contract failed: equals-hashcode on var26 and var4", var26.equals(var4) ? var26.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    var7.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var10 = var7.getPadding();
    var7.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var14 = var7.getSubtitle((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 100);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(100, var8, false);
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var24 = null;
    var22.setDomainAxisLocation(1, var24, false);
    java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
    boolean var28 = var21.equals((java.lang.Object)var27);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var33 = null;
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
    java.lang.Object var36 = var35.clone();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
    var0.setDomainCrosshairValue(4.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.setForegroundAlpha(1.0f);
//     java.awt.Font var6 = var3.getNoDataMessageFont();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var8 = null;
//     var7.datasetChanged(var8);
//     java.awt.Stroke var10 = var7.getOutlineStroke();
//     java.awt.Paint var11 = var7.getRangeZeroBaselinePaint();
//     org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6, var11);
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var6);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
//     var14.mapDatasetToDomainAxis(100, 0);
//     java.awt.Paint var19 = var14.getDomainCrosshairPaint();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.text.G2TextMeasurer var22 = new org.jfree.chart.text.G2TextMeasurer(var21);
//     org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var19, 10.0f, (org.jfree.chart.text.TextMeasurer)var22);
//     float var27 = var22.getStringWidth("", 1, 255);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
//     var0.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getRangeMarkers(var5);
//     int var7 = var0.getBackgroundImageAlignment();
//     org.jfree.chart.axis.ValueAxis[] var8 = null;
//     var0.setDomainAxes(var8);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    boolean var15 = var0.isRangeCrosshairVisible();
    org.jfree.chart.plot.CategoryMarker var17 = null;
    org.jfree.chart.util.Layer var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(1, var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.text.TextAnchor var26 = var24.getLabelTextAnchor();
//     float var27 = var24.getAlpha();
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var29.setCategoryLabelPositionOffset(1);
//     var29.setLabelAngle(0.0d);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     var36.setForegroundAlpha(1.0f);
//     java.awt.Font var39 = var36.getNoDataMessageFont();
//     var36.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var36);
//     org.jfree.chart.axis.AxisLocation var43 = var36.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var44 = var36.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var45 = null;
//     org.jfree.chart.util.VerticalAlignment var46 = null;
//     org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement(var45, var46, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var50 = null;
//     org.jfree.chart.util.VerticalAlignment var51 = null;
//     org.jfree.chart.block.ColumnArrangement var54 = new org.jfree.chart.block.ColumnArrangement(var50, var51, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36, (org.jfree.chart.block.Arrangement)var49, (org.jfree.chart.block.Arrangement)var54);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.PiePlot var57 = new org.jfree.chart.plot.PiePlot(var56);
//     org.jfree.chart.util.RectangleInsets var58 = var57.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var59 = null;
//     var57.setToolTipGenerator(var59);
//     java.awt.Stroke var61 = var57.getBaseSectionOutlineStroke();
//     java.awt.Paint var62 = var57.getLabelLinkPaint();
//     var55.setItemPaint(var62);
//     java.awt.Color var67 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Color var68 = var67.darker();
//     var55.setBackgroundPaint((java.awt.Paint)var68);
//     java.awt.Color var70 = var68.brighter();
//     var29.setTickLabelPaint((java.lang.Comparable)10, (java.awt.Paint)var70);
//     var24.setOutlinePaint((java.awt.Paint)var70);
//     
//     // Checks the contract:  equals-hashcode on var10 and var49
//     assertTrue("Contract failed: equals-hashcode on var10 and var49", var10.equals(var49) ? var10.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var10
//     assertTrue("Contract failed: equals-hashcode on var49 and var10", var49.equals(var10) ? var49.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var7.setURLText("Range[0.0,1.0]");
    boolean var17 = var7.getNotify();
    var7.setHeight(0.0d);
    var7.setExpandToFitSpace(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var8);
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setDomainAxisLocation(1, var17, false);
//     java.awt.Stroke var20 = var15.getRangeCrosshairStroke();
//     boolean var21 = var14.equals((java.lang.Object)var20);
//     java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var26 = null;
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var8, var20, (java.awt.Paint)var25, var26, 1.0f);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.text.TextAnchor var30 = var28.getLabelTextAnchor();
//     java.lang.String var31 = var30.toString();
//     java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var37);
//     org.jfree.chart.util.HorizontalAlignment var39 = null;
//     org.jfree.chart.util.VerticalAlignment var40 = null;
//     org.jfree.chart.block.ColumnArrangement var43 = new org.jfree.chart.block.ColumnArrangement(var39, var40, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var46 = null;
//     var44.setDomainAxisLocation(1, var46, false);
//     java.awt.Stroke var49 = var44.getRangeCrosshairStroke();
//     boolean var50 = var43.equals((java.lang.Object)var49);
//     java.awt.Color var54 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var55 = null;
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var37, var49, (java.awt.Paint)var54, var55, 1.0f);
//     java.lang.Object var58 = var57.clone();
//     org.jfree.chart.text.TextAnchor var59 = var57.getLabelTextAnchor();
//     java.lang.String var60 = var59.toString();
//     java.awt.Shape var61 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]", var1, (-1.0f), 1.0f, var30, 0.0d, var59);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var11.setDomainAxisLocation(1, var13, false);
    java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
    boolean var17 = var10.equals((java.lang.Object)var16);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var25 = null;
    var24.addChangeListener(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     float var25 = var24.getAlpha();
//     java.awt.Paint var26 = var24.getPaint();
//     double var27 = var24.getValue();
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var32);
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.ColumnArrangement var38 = new org.jfree.chart.block.ColumnArrangement(var34, var35, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var41 = null;
//     var39.setDomainAxisLocation(1, var41, false);
//     java.awt.Stroke var44 = var39.getRangeCrosshairStroke();
//     boolean var45 = var38.equals((java.lang.Object)var44);
//     java.awt.Color var49 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var50 = null;
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var32, var44, (java.awt.Paint)var49, var50, 1.0f);
//     java.awt.color.ColorSpace var53 = var32.getColorSpace();
//     boolean var54 = var24.equals((java.lang.Object)var32);
//     
//     // Checks the contract:  equals-hashcode on var5 and var33
//     assertTrue("Contract failed: equals-hashcode on var5 and var33", var5.equals(var33) ? var5.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var5
//     assertTrue("Contract failed: equals-hashcode on var33 and var5", var33.equals(var5) ? var33.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var38
//     assertTrue("Contract failed: equals-hashcode on var10 and var38", var10.equals(var38) ? var10.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var10
//     assertTrue("Contract failed: equals-hashcode on var38 and var10", var38.equals(var10) ? var38.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var39
//     assertTrue("Contract failed: equals-hashcode on var11 and var39", var11.equals(var39) ? var11.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var11
//     assertTrue("Contract failed: equals-hashcode on var39 and var11", var39.equals(var11) ? var39.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var52
//     assertTrue("Contract failed: equals-hashcode on var24 and var52", var24.equals(var52) ? var24.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var24
//     assertTrue("Contract failed: equals-hashcode on var52 and var24", var52.equals(var24) ? var52.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     boolean var7 = var0.render(var3, var4, 10, var6);
//     org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
//     org.jfree.chart.util.RectangleEdge var10 = var0.getRangeAxisEdge();
//     org.jfree.data.general.DatasetChangeEvent var11 = null;
//     var0.datasetChanged(var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var18 = var17.getQuadrantOrigin();
//     var13.zoomDomainAxes((-1.0d), 3.0d, var16, var18);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setForegroundAlpha(1.0f);
//     java.awt.Font var24 = var21.getNoDataMessageFont();
//     var21.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var21);
//     org.jfree.chart.axis.AxisLocation var28 = var21.getDomainAxisLocation();
//     var13.setDomainAxisLocation(var28);
//     var0.setDomainAxisLocation(var28, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1.0E-5d);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     var22.setRangeCrosshairLockedOnData(false);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
//     var22.setAxisOffset(var32);
//     var20.setItemLabelPadding(var32);
//     java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var39 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var38);
//     int var40 = var38.getGreen();
//     var20.setItemPaint((java.awt.Paint)var38);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     var43.setForegroundAlpha(1.0f);
//     java.awt.Font var46 = var43.getNoDataMessageFont();
//     var43.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var43);
//     org.jfree.chart.axis.AxisLocation var50 = var43.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var51 = var43.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var52 = null;
//     org.jfree.chart.util.VerticalAlignment var53 = null;
//     org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement(var52, var53, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var57 = null;
//     org.jfree.chart.util.VerticalAlignment var58 = null;
//     org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement(var57, var58, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43, (org.jfree.chart.block.Arrangement)var56, (org.jfree.chart.block.Arrangement)var61);
//     org.jfree.chart.util.RectangleEdge var63 = var62.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var66 = null;
//     var64.setDomainAxisLocation(1, var66, false);
//     java.awt.Stroke var69 = var64.getRangeCrosshairStroke();
//     var64.setRangeCrosshairLockedOnData(false);
//     org.jfree.data.general.PieDataset var72 = null;
//     org.jfree.chart.plot.PiePlot var73 = new org.jfree.chart.plot.PiePlot(var72);
//     org.jfree.chart.util.RectangleInsets var74 = var73.getLabelPadding();
//     var64.setAxisOffset(var74);
//     var62.setItemLabelPadding(var74);
//     var20.setItemLabelPadding(var74);
//     
//     // Checks the contract:  equals-hashcode on var1 and var43
//     assertTrue("Contract failed: equals-hashcode on var1 and var43", var1.equals(var43) ? var1.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var1
//     assertTrue("Contract failed: equals-hashcode on var43 and var1", var43.equals(var1) ? var43.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var49
//     assertTrue("Contract failed: equals-hashcode on var7 and var49", var7.equals(var49) ? var7.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var7
//     assertTrue("Contract failed: equals-hashcode on var49 and var7", var49.equals(var7) ? var49.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var56
//     assertTrue("Contract failed: equals-hashcode on var14 and var56", var14.equals(var56) ? var14.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var61
//     assertTrue("Contract failed: equals-hashcode on var19 and var61", var19.equals(var61) ? var19.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var14
//     assertTrue("Contract failed: equals-hashcode on var56 and var14", var56.equals(var14) ? var56.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var19
//     assertTrue("Contract failed: equals-hashcode on var61 and var19", var61.equals(var19) ? var61.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var64
//     assertTrue("Contract failed: equals-hashcode on var22 and var64", var22.equals(var64) ? var22.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var22
//     assertTrue("Contract failed: equals-hashcode on var64 and var22", var64.equals(var22) ? var64.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var73
//     assertTrue("Contract failed: equals-hashcode on var31 and var73", var31.equals(var73) ? var31.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var31
//     assertTrue("Contract failed: equals-hashcode on var73 and var31", var73.equals(var31) ? var73.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var13 = var7.getURLText();
    var7.setURLText("RectangleConstraintType.RANGE");
    var7.setNotify(true);
    java.awt.Paint var18 = null;
    var7.setBackgroundPaint(var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.block.RectangleConstraint var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var22 = var7.arrange(var20, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.AxisSpace var8 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var0.handleClick(15, 0, var11);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var18 = null;
//     var16.setDomainAxisLocation(1, var18, false);
//     java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
//     boolean var22 = var15.equals((java.lang.Object)var21);
//     java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
//     float var30 = var29.getAlpha();
//     java.awt.Paint var31 = var29.getLabelPaint();
//     double var32 = var29.getValue();
//     var0.addDomainMarker((org.jfree.chart.plot.Marker)var29);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var36 = var35.getLabelURL();
//     var35.configure();
//     java.awt.Paint var38 = var35.getTickLabelPaint();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     var39.setTickMarksVisible(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var42);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var46 = var45.clone();
//     java.awt.Shape var47 = var45.getLeftArrow();
//     var43.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var45, false);
//     int var50 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var45);
//     java.awt.Color var55 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var55);
//     org.jfree.chart.util.HorizontalAlignment var57 = null;
//     org.jfree.chart.util.VerticalAlignment var58 = null;
//     org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement(var57, var58, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var64 = null;
//     var62.setDomainAxisLocation(1, var64, false);
//     java.awt.Stroke var67 = var62.getRangeCrosshairStroke();
//     boolean var68 = var61.equals((java.lang.Object)var67);
//     java.awt.Color var72 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var73 = null;
//     org.jfree.chart.plot.ValueMarker var75 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var55, var67, (java.awt.Paint)var72, var73, 1.0f);
//     java.lang.Object var76 = var75.clone();
//     boolean var77 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var75);
//     
//     // Checks the contract:  equals-hashcode on var16 and var62
//     assertTrue("Contract failed: equals-hashcode on var16 and var62", var16.equals(var62) ? var16.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var16
//     assertTrue("Contract failed: equals-hashcode on var62 and var16", var62.equals(var16) ? var62.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var56
//     assertTrue("Contract failed: equals-hashcode on var10 and var56", var10.equals(var56) ? var10.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var10
//     assertTrue("Contract failed: equals-hashcode on var56 and var10", var56.equals(var10) ? var56.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var61
//     assertTrue("Contract failed: equals-hashcode on var15 and var61", var15.equals(var61) ? var15.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var15
//     assertTrue("Contract failed: equals-hashcode on var61 and var15", var61.equals(var15) ? var61.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var75
//     assertTrue("Contract failed: equals-hashcode on var29 and var75", var29.equals(var75) ? var29.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var29
//     assertTrue("Contract failed: equals-hashcode on var75 and var29", var75.equals(var29) ? var75.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
    java.awt.Paint var10 = var0.getRangeGridlinePaint();
    var0.clearRangeMarkers();
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.setForegroundAlpha(1.0f);
    java.awt.Paint var17 = var14.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var14);
    var14.configureRangeAxes();
    boolean var20 = var14.isDomainZoomable();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var14.getCategoriesForAxis(var21);
    var0.drawDomainTickBands(var12, var13, var22);
    double var24 = var0.getDomainCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     boolean var7 = var0.render(var3, var4, 10, var6);
//     org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var12 = var11.getUpperMargin();
//     var0.setDomainAxis(10, var11, false);
//     var0.clearRangeAxes();
//     var0.clearDomainMarkers();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     org.jfree.chart.util.RectangleInsets var21 = var20.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var22 = null;
//     var20.setToolTipGenerator(var22);
//     java.awt.Font var24 = var20.getLabelFont();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var24);
//     var25.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var31 = var25.getURLText();
//     org.jfree.chart.util.VerticalAlignment var32 = var25.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var33 = var25.getBounds();
//     var0.drawOutline(var17, var33);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     java.awt.Stroke var9 = var7.getBorderStroke();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var12 = var11.getPlotType();
//     org.jfree.chart.urls.PieURLGenerator var13 = null;
//     var11.setLegendLabelURLGenerator(var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var20 = null;
//     var18.setToolTipGenerator(var20);
//     java.awt.Font var22 = var18.getLabelFont();
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var22);
//     var23.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var29 = var23.getURLText();
//     org.jfree.chart.util.VerticalAlignment var30 = var23.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var31 = var23.getBounds();
//     var11.drawBackgroundImage(var15, var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     var33.setForegroundAlpha(1.0f);
//     java.awt.Font var36 = var33.getNoDataMessageFont();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getLabelPadding();
//     var38.setSectionOutlinesVisible(true);
//     java.awt.Paint var42 = var38.getBaseSectionPaint();
//     var33.setRangeCrosshairPaint(var42);
//     java.lang.Object var44 = var33.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var48 = null;
//     var47.datasetChanged(var48);
//     java.awt.Paint var50 = var47.getRangeZeroBaselinePaint();
//     var47.setRangeGridlinesVisible(true);
//     var47.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var58 = var57.getQuadrantOrigin();
//     var47.zoomRangeAxes(0.0d, var56, var58);
//     var33.zoomDomainAxes((-1.0d), var46, var58);
//     org.jfree.chart.ChartRenderingInfo var61 = null;
//     var7.draw(var10, var31, var58, var61);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var6 = null;
//     var4.setToolTipGenerator(var6);
//     java.awt.Font var8 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var8);
//     var9.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var15 = var9.getURLText();
//     org.jfree.chart.util.VerticalAlignment var16 = var9.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var17 = var9.getBounds();
//     var0.draw(var1, var17);
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var8);
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setDomainAxisLocation(1, var17, false);
//     java.awt.Stroke var20 = var15.getRangeCrosshairStroke();
//     boolean var21 = var14.equals((java.lang.Object)var20);
//     java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var26 = null;
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var8, var20, (java.awt.Paint)var25, var26, 1.0f);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.text.TextAnchor var30 = var28.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=255,g=0,b=0]", var1, 2.0f, 0.0f, var30, 0.12d, 0.0f, 100.0f);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var2 = var1.getTickLabelFont();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var4 = var3.clone();
    java.awt.Shape var5 = var3.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Pie 3D Plot");
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var9 = var8.clone();
    java.awt.Shape var10 = var8.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Pie 3D Plot");
    var7.setArea(var10);
    var1.setUpArrow(var10);
    var1.resizeRange(1.0d);
    var1.setAutoRangeMinimumSize(0.12d, false);
    var1.setUpperMargin(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
//     var0.setDomainAxes(var3);
//     org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     var0.setRenderer(100, var8, false);
//     java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     boolean var28 = var21.equals((java.lang.Object)var27);
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var33 = null;
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
//     java.lang.Object var36 = var35.clone();
//     var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
//     java.lang.Class var38 = null;
//     java.util.EventListener[] var39 = var35.getListeners(var38);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    boolean var3 = var1.getLabelLinksVisible();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
    org.jfree.chart.labels.PieSectionLabelGenerator var7 = var1.getLegendLabelToolTipGenerator();
    boolean var8 = var1.getSectionOutlinesVisible();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    var10.setSectionOutlinesVisible(true);
    java.awt.Paint var14 = var10.getShadowPaint();
    var1.setLabelShadowPaint(var14);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.Plot var5 = var4.getPlot();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setForegroundAlpha(1.0f);
//     java.awt.Font var10 = var7.getNoDataMessageFont();
//     var7.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var7);
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
//     org.jfree.chart.util.UnitType var18 = var17.getUnitType();
//     var13.setPadding(var17);
//     var4.setChart(var13);
//     var13.setBackgroundImageAlignment(10);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.setForegroundAlpha(1.0f);
//     java.awt.Paint var26 = var23.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var23);
//     var13.plotChanged(var27);
//     
//     // Checks the contract:  equals-hashcode on var0 and var23
//     assertTrue("Contract failed: equals-hashcode on var0 and var23", var0.equals(var23) ? var0.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var0
//     assertTrue("Contract failed: equals-hashcode on var23 and var0", var23.equals(var0) ? var23.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setDomainAxisLocation(1, var7, false);
    java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
    var1.setBaseSectionOutlineStroke(var10);
    java.awt.Paint var12 = var1.getLabelShadowPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var13 = var1.getLegendLabelToolTipGenerator();
    float var14 = var1.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.setRangeCrosshairValue(10.0d, true);
    boolean var5 = var0.isDomainZeroBaselineVisible();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRendererForDataset(var6);
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setDomainAxisLocation(1, var21, false);
    java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
    boolean var25 = var18.equals((java.lang.Object)var24);
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var30 = null;
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var24, (java.awt.Paint)var29, var30, 1.0f);
    var0.setDomainCrosshairPaint((java.awt.Paint)var29);
    int var34 = var29.getRed();
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Color var39 = var38.darker();
    float[] var43 = new float[] { 100.0f, 100.0f, (-1.0f)};
    float[] var44 = var39.getRGBColorComponents(var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var45 = var29.getRGBComponents(var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var1 = var0.getPlotType();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var2.setFixedDomainAxisSpace(var3, true);
//     var2.clearDomainMarkers(100);
//     var2.setOutlineVisible(true);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var12 = var11.getTickLabelFont();
//     var2.setNoDataMessageFont(var12);
//     var0.setLabelFont(var12);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var17 = var16.getPlotType();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var16.setLegendLabelURLGenerator(var18);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     org.jfree.chart.util.RectangleInsets var24 = var23.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var25 = null;
//     var23.setToolTipGenerator(var25);
//     java.awt.Font var27 = var23.getLabelFont();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var27);
//     var28.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var34 = var28.getURLText();
//     org.jfree.chart.util.VerticalAlignment var35 = var28.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var36 = var28.getBounds();
//     var16.drawBackgroundImage(var20, var36);
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var39 = var38.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     var0.draw(var15, var36, var39, var40, var41);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.Plot var5 = var4.getPlot();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setForegroundAlpha(1.0f);
//     java.awt.Font var10 = var7.getNoDataMessageFont();
//     var7.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var7);
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
//     org.jfree.chart.util.UnitType var18 = var17.getUnitType();
//     var13.setPadding(var17);
//     var4.setChart(var13);
//     org.jfree.chart.util.RectangleInsets var21 = var13.getPadding();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var24 = var23.clone();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var26.getLabelPadding();
//     var26.setSectionOutlinesVisible(true);
//     java.awt.Paint var30 = var26.getBaseSectionPaint();
//     var23.setAxisLinePaint(var30);
//     org.jfree.data.Range var32 = var23.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(100.0d, var32);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var35 = var34.clone();
//     org.jfree.data.Range var36 = var34.getRange();
//     org.jfree.data.Range var37 = org.jfree.data.Range.combine(var32, var36);
//     org.jfree.data.Range var39 = org.jfree.data.Range.shift(var36, 10.0d);
//     boolean var40 = var21.equals((java.lang.Object)10.0d);
//     
//     // Checks the contract:  equals-hashcode on var16 and var26
//     assertTrue("Contract failed: equals-hashcode on var16 and var26", var16.equals(var26) ? var16.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var16
//     assertTrue("Contract failed: equals-hashcode on var26 and var16", var26.equals(var16) ? var26.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var5 = var4.getPlot();
    org.jfree.chart.event.ChartChangeEventType var6 = var4.getType();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var8 = var7.clone();
    double var9 = var7.getLowerBound();
    boolean var10 = var6.equals((java.lang.Object)var7);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setForegroundAlpha(1.0f);
    java.awt.Font var15 = var12.getNoDataMessageFont();
    var12.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var12);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    var18.fireChartChanged();
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var18);
    org.jfree.chart.event.ChartChangeEventType var22 = var21.getType();
    java.lang.String var23 = var22.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var23.equals("ChartChangeEventType.GENERAL"));

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("poly", var1);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var11.setCategoryLabelPositionOffset((-65536));
    java.awt.Paint var18 = null;
    var11.setTickLabelPaint((java.lang.Comparable)"Other", var18);
    var11.clearCategoryLabelToolTips();
    java.lang.String var21 = var11.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var5 = var4.clone();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
    var7.setSectionOutlinesVisible(true);
    java.awt.Paint var11 = var7.getBaseSectionPaint();
    var4.setAxisLinePaint(var11);
    double var13 = var4.getLowerMargin();
    boolean var14 = var4.isVerticalTickLabels();
    var4.setPositiveArrowVisible(true);
    org.jfree.data.Range var17 = var4.getRange();
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(3.0d, var17);
    org.jfree.chart.util.Size2D var19 = var0.arrange(var1, var2, var18);
    org.jfree.chart.block.Arrangement var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setArrangement(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.setRangeCrosshairValue(10.0d, true);
    boolean var5 = var0.isDomainZeroBaselineVisible();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRendererForDataset(var6);
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setDomainAxisLocation(1, var21, false);
    java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
    boolean var25 = var18.equals((java.lang.Object)var24);
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var30 = null;
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var24, (java.awt.Paint)var29, var30, 1.0f);
    var0.setDomainCrosshairPaint((java.awt.Paint)var29);
    int var34 = var29.getRed();
    java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var39);
    org.jfree.chart.util.HorizontalAlignment var41 = null;
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var48 = null;
    var46.setDomainAxisLocation(1, var48, false);
    java.awt.Stroke var51 = var46.getRangeCrosshairStroke();
    boolean var52 = var45.equals((java.lang.Object)var51);
    java.awt.Color var56 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var57 = null;
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var39, var51, (java.awt.Paint)var56, var57, 1.0f);
    java.awt.color.ColorSpace var60 = var39.getColorSpace();
    float[] var62 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var63 = var29.getColorComponents(var60, var62);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.RenderingHints var8 = var7.getRenderingHints();
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    double var10 = var9.getDepthFactor();
    var9.setCircular(true, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setTextAntiAlias((java.lang.Object)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.12d);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var6 = null;
//     var4.setToolTipGenerator(var6);
//     java.awt.Font var8 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var8);
//     org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine("Other", var8);
//     java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     boolean var28 = var21.equals((java.lang.Object)var27);
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var33 = null;
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
//     float var36 = var35.getAlpha();
//     java.awt.Paint var37 = var35.getLabelPaint();
//     java.awt.Paint var38 = var35.getPaint();
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("", var8, var38, (-1.0f));
//     java.awt.Graphics2D var41 = null;
//     java.awt.Color var48 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var49 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var48);
//     org.jfree.chart.util.HorizontalAlignment var50 = null;
//     org.jfree.chart.util.VerticalAlignment var51 = null;
//     org.jfree.chart.block.ColumnArrangement var54 = new org.jfree.chart.block.ColumnArrangement(var50, var51, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var57 = null;
//     var55.setDomainAxisLocation(1, var57, false);
//     java.awt.Stroke var60 = var55.getRangeCrosshairStroke();
//     boolean var61 = var54.equals((java.lang.Object)var60);
//     java.awt.Color var65 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var66 = null;
//     org.jfree.chart.plot.ValueMarker var68 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var48, var60, (java.awt.Paint)var65, var66, 1.0f);
//     java.lang.Object var69 = var68.clone();
//     org.jfree.chart.text.TextAnchor var70 = var68.getLabelTextAnchor();
//     var40.draw(var41, 1.0f, 100.0f, var70, (-1.0f), 10.0f, 0.05d);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.setForegroundAlpha(1.0f);
//     java.awt.Font var6 = var3.getNoDataMessageFont();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var8 = null;
//     var7.datasetChanged(var8);
//     java.awt.Stroke var10 = var7.getOutlineStroke();
//     java.awt.Paint var11 = var7.getRangeZeroBaselinePaint();
//     org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6, var11);
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var6);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
//     var14.mapDatasetToDomainAxis(100, 0);
//     java.awt.Paint var19 = var14.getDomainCrosshairPaint();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.text.G2TextMeasurer var22 = new org.jfree.chart.text.G2TextMeasurer(var21);
//     org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var19, 10.0f, (org.jfree.chart.text.TextMeasurer)var22);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var27 = null;
//     var25.setDomainAxisLocation(1, var27, false);
//     java.awt.Stroke var30 = var25.getRangeCrosshairStroke();
//     java.awt.Font var31 = var25.getNoDataMessageFont();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     var33.setForegroundAlpha(1.0f);
//     java.awt.Font var36 = var33.getNoDataMessageFont();
//     var33.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var33);
//     java.awt.Paint var40 = var39.getBackgroundPaint();
//     var23.addLine("Multiple Pie Plot", var31, var40);
//     
//     // Checks the contract:  equals-hashcode on var7 and var25
//     assertTrue("Contract failed: equals-hashcode on var7 and var25", var7.equals(var25) ? var7.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var7
//     assertTrue("Contract failed: equals-hashcode on var25 and var7", var25.equals(var7) ? var25.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(100, var8, false);
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var24 = null;
    var22.setDomainAxisLocation(1, var24, false);
    java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
    boolean var28 = var21.equals((java.lang.Object)var27);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var33 = null;
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
    java.lang.Object var36 = var35.clone();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
    double var38 = var0.getRangeCrosshairValue();
    org.jfree.chart.util.Layer var39 = null;
    java.util.Collection var40 = var0.getDomainMarkers(var39);
    org.jfree.chart.axis.AxisLocation var41 = var0.getDomainAxisLocation();
    var0.mapDatasetToDomainAxis(0, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.CategoryAxis var9 = var0.getDomainAxis(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var2 = var1.clone();
    int var3 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     org.jfree.chart.util.RectangleInsets var4 = var3.getLabelPadding();
//     var3.setSectionOutlinesVisible(true);
//     java.awt.Paint var7 = var3.getBaseSectionPaint();
//     var0.setAxisLinePaint(var7);
//     org.jfree.data.Range var9 = var0.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var12 = var11.getTickLabelFont();
//     var0.setLabelFont(var12);
//     var0.setInverted(false);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var18 = var17.clone();
//     org.jfree.chart.axis.ValueAxis[] var19 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var16.setDomainAxes(var19);
//     java.awt.geom.Point2D var21 = var16.getQuadrantOrigin();
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     double var24 = var23.getFixedDimension();
//     org.jfree.data.RangeType var25 = var23.getRangeType();
//     org.jfree.data.Range var26 = var16.getDataRange((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var29 = var28.clone();
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
//     var31.setSectionOutlinesVisible(true);
//     java.awt.Paint var35 = var31.getBaseSectionPaint();
//     var28.setAxisLinePaint(var35);
//     org.jfree.data.Range var37 = var28.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(100.0d, var37);
//     org.jfree.chart.block.LengthConstraintType var39 = var38.getHeightConstraintType();
//     boolean var40 = var23.equals((java.lang.Object)var38);
//     
//     // Checks the contract:  equals-hashcode on var3 and var31
//     assertTrue("Contract failed: equals-hashcode on var3 and var31", var3.equals(var31) ? var3.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var3
//     assertTrue("Contract failed: equals-hashcode on var31 and var3", var31.equals(var3) ? var31.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
//     var0.setRangeCrosshairValue(10.0d, true);
//     boolean var5 = var0.isDomainZeroBaselineVisible();
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
//     org.jfree.chart.util.HorizontalAlignment var14 = null;
//     org.jfree.chart.util.VerticalAlignment var15 = null;
//     org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setDomainAxisLocation(1, var21, false);
//     java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
//     boolean var25 = var18.equals((java.lang.Object)var24);
//     java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var30 = null;
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var24, (java.awt.Paint)var29, var30, 1.0f);
//     float var33 = var32.getAlpha();
//     java.awt.Paint var34 = var32.getLabelPaint();
//     org.jfree.chart.util.Layer var35 = null;
//     boolean var36 = var0.removeRangeMarker((-65536), (org.jfree.chart.plot.Marker)var32, var35);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setDomainAxisLocation(1, var7, false);
    java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
    var1.setBaseSectionOutlineStroke(var10);
    var1.setCircular(false);
    int var14 = var1.getPieIndex();
    boolean var15 = var1.getIgnoreNullValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.String var2 = var1.getPlotType();
    java.awt.Paint var3 = var1.getAggregatedItemsPaint();
    double var4 = var1.getLimit();
    double var5 = var1.getLimit();
    java.lang.String var6 = var1.getPlotType();
    org.jfree.chart.util.TableOrder var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDataExtractOrder(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Multiple Pie Plot"+ "'", var2.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Multiple Pie Plot"+ "'", var6.equals("Multiple Pie Plot"));

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    double var4 = var2.calculateRightOutset(100.0d);
    java.lang.String var5 = var2.toString();
    double var7 = var2.calculateTopInset(1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-65536));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    org.jfree.chart.annotations.XYAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.Comparable var2 = var1.getAggregatedItemsKey();
    java.lang.String var3 = var1.getPlotType();
    org.jfree.data.category.CategoryDataset var4 = null;
    var1.setDataset(var4);
    org.jfree.data.category.CategoryDataset var6 = var1.getDataset();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.setForegroundAlpha(1.0f);
    java.awt.Paint var10 = var7.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.setForegroundAlpha(1.0f);
    java.awt.Font var17 = var14.getNoDataMessageFont();
    var14.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var14);
    java.awt.Paint var21 = var20.getBackgroundPaint();
    org.jfree.data.general.PieDataset var22 = null;
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
    org.jfree.chart.util.RectangleInsets var24 = var23.getLabelPadding();
    org.jfree.chart.util.UnitType var25 = var24.getUnitType();
    var20.setPadding(var24);
    var11.setChart(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPieChart(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Other"+ "'", var2.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Multiple Pie Plot"+ "'", var3.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.Range var14 = var12.getRange();
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var10, var14);
    boolean var17 = var10.contains(1.0E-5d);
    double var18 = var10.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var12 = null;
//     var10.setDomainAxisLocation(1, var12, false);
//     java.awt.Stroke var15 = var10.getRangeCrosshairStroke();
//     org.jfree.chart.util.Layer var17 = null;
//     java.util.Collection var18 = var10.getRangeMarkers(10, var17);
//     java.util.List var19 = var10.getAnnotations();
//     org.jfree.chart.plot.PlotOrientation var20 = var10.getOrientation();
//     org.jfree.chart.util.RectangleEdge var21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var9, var20);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.setForegroundAlpha(1.0f);
//     java.awt.Font var25 = var22.getNoDataMessageFont();
//     var22.setAnchorValue(100.0d);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var30 = null;
//     var28.setDomainAxisLocation(1, var30, false);
//     java.awt.Stroke var33 = var28.getRangeCrosshairStroke();
//     org.jfree.chart.util.Layer var35 = null;
//     java.util.Collection var36 = var28.getRangeMarkers(10, var35);
//     java.util.List var37 = var28.getAnnotations();
//     org.jfree.chart.plot.PlotOrientation var38 = var28.getOrientation();
//     var22.setOrientation(var38);
//     org.jfree.chart.util.RectangleEdge var40 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var9, var38);
//     
//     // Checks the contract:  equals-hashcode on var1 and var22
//     assertTrue("Contract failed: equals-hashcode on var1 and var22", var1.equals(var22) ? var1.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var1
//     assertTrue("Contract failed: equals-hashcode on var22 and var1", var22.equals(var1) ? var22.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var28
//     assertTrue("Contract failed: equals-hashcode on var10 and var28", var10.equals(var28) ? var10.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var10
//     assertTrue("Contract failed: equals-hashcode on var28 and var10", var28.equals(var10) ? var28.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.setForegroundAlpha(1.0f);
//     java.awt.Paint var8 = var5.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.plot.Plot var10 = var9.getPlot();
//     org.jfree.chart.event.ChartChangeEventType var11 = var9.getType();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var13 = var12.clone();
//     double var14 = var12.getLowerBound();
//     boolean var15 = var11.equals((java.lang.Object)var12);
//     var4.setType(var11);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("Multiple Pie Plot", var1, var2);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    org.jfree.chart.axis.AxisSpace var10 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.setForegroundAlpha(1.0f);
    java.awt.Font var16 = var13.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    org.jfree.chart.util.RectangleInsets var19 = var18.getLabelPadding();
    var18.setSectionOutlinesVisible(true);
    java.awt.Paint var22 = var18.getBaseSectionPaint();
    var13.setRangeCrosshairPaint(var22);
    java.lang.Object var24 = var13.clone();
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var28 = null;
    var27.datasetChanged(var28);
    java.awt.Paint var30 = var27.getRangeZeroBaselinePaint();
    var27.setRangeGridlinesVisible(true);
    var27.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var38 = var37.getQuadrantOrigin();
    var27.zoomRangeAxes(0.0d, var36, var38);
    var13.zoomDomainAxes((-1.0d), var26, var38);
    var0.zoomRangeAxes(100.0d, var12, var38);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    var42.setForegroundAlpha(1.0f);
    java.awt.Paint var45 = var42.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var46 = var42.getRowRenderingOrder();
    java.awt.Color var51 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var52 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var51);
    org.jfree.chart.util.HorizontalAlignment var53 = null;
    org.jfree.chart.util.VerticalAlignment var54 = null;
    org.jfree.chart.block.ColumnArrangement var57 = new org.jfree.chart.block.ColumnArrangement(var53, var54, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var60 = null;
    var58.setDomainAxisLocation(1, var60, false);
    java.awt.Stroke var63 = var58.getRangeCrosshairStroke();
    boolean var64 = var57.equals((java.lang.Object)var63);
    java.awt.Color var68 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var69 = null;
    org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var51, var63, (java.awt.Paint)var68, var69, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var72 = null;
    var71.addChangeListener(var72);
    var42.addRangeMarker((org.jfree.chart.plot.Marker)var71);
    var71.setLabel("UnitType.ABSOLUTE");
    org.jfree.chart.util.Layer var77 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var71, var77);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
    java.awt.Stroke var5 = var0.getOutlineStroke();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var9 = null;
    var7.setToolTipGenerator(var9);
    org.jfree.chart.labels.PieSectionLabelGenerator var11 = var7.getLegendLabelToolTipGenerator();
    var7.setLabelLinkMargin(100.0d);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var17 = null;
    var15.setToolTipGenerator(var17);
    java.awt.Stroke var19 = var15.getBaseSectionOutlineStroke();
    var7.setLabelOutlineStroke(var19);
    var0.setRangeCrosshairStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var23 = var22.clone();
    int var24 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var22);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var27 = null;
    var26.datasetChanged(var27);
    java.awt.Paint var29 = var26.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeListener var30 = null;
    var26.removeChangeListener(var30);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var34 = var33.clone();
    float var35 = var33.getTickMarkInsideLength();
    java.lang.String var36 = var33.getLabelURL();
    var26.setDomainAxis(100, (org.jfree.chart.axis.ValueAxis)var33, true);
    var0.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis)var33);
    java.awt.Paint var40 = var33.getTickMarkPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     var0.configureRangeAxes();
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var0.getCategoriesForAxis(var7);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.geom.Point2D var16 = var11.getQuadrantOrigin();
//     var0.zoomRangeAxes(6.0d, var10, var16, false);
//     org.jfree.chart.util.RectangleEdge var19 = var0.getDomainAxisEdge();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var21 = null;
//     var20.datasetChanged(var21);
//     java.awt.Stroke var23 = var20.getOutlineStroke();
//     java.awt.Paint var24 = var20.getRangeZeroBaselinePaint();
//     java.awt.Stroke var25 = var20.getOutlineStroke();
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     org.jfree.chart.util.RectangleInsets var28 = var27.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var29 = null;
//     var27.setToolTipGenerator(var29);
//     org.jfree.chart.labels.PieSectionLabelGenerator var31 = var27.getLegendLabelToolTipGenerator();
//     var27.setLabelLinkMargin(100.0d);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     org.jfree.chart.util.RectangleInsets var36 = var35.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var37 = null;
//     var35.setToolTipGenerator(var37);
//     java.awt.Stroke var39 = var35.getBaseSectionOutlineStroke();
//     var27.setLabelOutlineStroke(var39);
//     var20.setRangeCrosshairStroke(var39);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var43 = var42.clone();
//     int var44 = var20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var42);
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var47 = null;
//     var46.datasetChanged(var47);
//     java.awt.Paint var49 = var46.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeListener var50 = null;
//     var46.removeChangeListener(var50);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var54 = var53.clone();
//     float var55 = var53.getTickMarkInsideLength();
//     java.lang.String var56 = var53.getLabelURL();
//     var46.setDomainAxis(100, (org.jfree.chart.axis.ValueAxis)var53, true);
//     var20.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis)var53);
//     boolean var60 = var0.equals((java.lang.Object)10);
//     
//     // Checks the contract:  equals-hashcode on var11 and var46
//     assertTrue("Contract failed: equals-hashcode on var11 and var46", var11.equals(var46) ? var11.hashCode() == var46.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var46.", var11.equals(var46) == var46.equals(var11));
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("Range[0.0,1.0]");
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var6 = var5.clone();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    org.jfree.chart.util.RectangleInsets var9 = var8.getLabelPadding();
    var8.setSectionOutlinesVisible(true);
    java.awt.Paint var12 = var8.getBaseSectionPaint();
    var5.setAxisLinePaint(var12);
    org.jfree.data.Range var14 = var5.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(100.0d, var14);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var17 = var16.clone();
    org.jfree.data.Range var18 = var16.getRange();
    org.jfree.data.Range var19 = org.jfree.data.Range.combine(var14, var18);
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(3.0d, var18);
    org.jfree.chart.block.LengthConstraintType var21 = var20.getHeightConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var22 = var1.arrange(var2, var20);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var1 = var0.getContributors();
    java.lang.String var2 = var0.getLicenceText();
    java.lang.String var3 = var0.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("poly", "Category Plot", var3);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1, true);
//     var0.clearDomainMarkers(100);
//     org.jfree.chart.util.RectangleEdge var7 = var0.getRangeAxisEdge(0);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var9 = null;
//     var8.setFixedDomainAxisSpace(var9, true);
//     var8.clearDomainMarkers(100);
//     var8.setOutlineVisible(true);
//     org.jfree.data.general.DatasetGroup var16 = var8.getDatasetGroup();
//     boolean var17 = var8.isDomainCrosshairVisible();
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var22);
//     org.jfree.chart.util.HorizontalAlignment var24 = null;
//     org.jfree.chart.util.VerticalAlignment var25 = null;
//     org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var31 = null;
//     var29.setDomainAxisLocation(1, var31, false);
//     java.awt.Stroke var34 = var29.getRangeCrosshairStroke();
//     boolean var35 = var28.equals((java.lang.Object)var34);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var40 = null;
//     org.jfree.chart.plot.ValueMarker var42 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var22, var34, (java.awt.Paint)var39, var40, 1.0f);
//     java.awt.color.ColorSpace var43 = var22.getColorSpace();
//     var8.setDomainCrosshairPaint((java.awt.Paint)var22);
//     boolean var45 = var7.equals((java.lang.Object)var22);
//     
//     // Checks the contract:  equals-hashcode on var0 and var29
//     assertTrue("Contract failed: equals-hashcode on var0 and var29", var0.equals(var29) ? var0.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var0
//     assertTrue("Contract failed: equals-hashcode on var29 and var0", var29.equals(var0) ? var29.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.setForegroundAlpha(1.0f);
    java.awt.Font var6 = var3.getNoDataMessageFont();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var8 = null;
    var7.datasetChanged(var8);
    java.awt.Stroke var10 = var7.getOutlineStroke();
    java.awt.Paint var11 = var7.getRangeZeroBaselinePaint();
    org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6, var11);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var6);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
    var14.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var19 = var14.getDomainCrosshairPaint();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.text.G2TextMeasurer var22 = new org.jfree.chart.text.G2TextMeasurer(var21);
    org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var19, 10.0f, (org.jfree.chart.text.TextMeasurer)var22);
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.text.TextBlockAnchor var27 = null;
    var23.draw(var24, 1.0f, 2.0f, var27, 100.0f, 0.0f, 3.0d);
    org.jfree.chart.util.HorizontalAlignment var32 = var23.getLineAlignment();
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.text.TextBlockAnchor var36 = null;
    var23.draw(var33, 100.0f, 2.0f, var36, (-1.0f), (-1.0f), (-5.88d));
    java.awt.Graphics2D var41 = null;
    org.jfree.chart.text.TextBlockAnchor var44 = null;
    java.awt.Shape var48 = var23.calculateBounds(var41, 2.0f, 0.0f, var44, 0.0f, 0.0f, 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
    var1.clearDomainMarkers();
    var1.setRangeGridlinesVisible(true);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.setForegroundAlpha(1.0f);
    boolean var27 = var24.isDomainGridlinesVisible();
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    var24.setRenderer(var28, true);
    org.jfree.chart.axis.AxisLocation var32 = var24.getRangeAxisLocation((-1));
    org.jfree.chart.axis.CategoryAnchor var33 = var24.getDomainGridlinePosition();
    var1.setDomainGridlinePosition(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
//     var7.setSectionOutlinesVisible(true);
//     java.awt.Paint var11 = var7.getBaseSectionPaint();
//     var4.setAxisLinePaint(var11);
//     double var13 = var4.getLowerMargin();
//     boolean var14 = var4.isVerticalTickLabels();
//     var4.setPositiveArrowVisible(true);
//     org.jfree.data.Range var17 = var4.getRange();
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(3.0d, var17);
//     org.jfree.chart.util.Size2D var19 = var0.arrange(var1, var2, var18);
//     var1.clear();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var24 = var23.clone();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var26.getLabelPadding();
//     var26.setSectionOutlinesVisible(true);
//     java.awt.Paint var30 = var26.getBaseSectionPaint();
//     var23.setAxisLinePaint(var30);
//     org.jfree.data.Range var32 = var23.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(100.0d, var32);
//     org.jfree.chart.block.LengthConstraintType var34 = var33.getHeightConstraintType();
//     org.jfree.chart.block.RectangleConstraint var35 = var33.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var36 = var1.arrange(var21, var35);
//     
//     // Checks the contract:  equals-hashcode on var7 and var26
//     assertTrue("Contract failed: equals-hashcode on var7 and var26", var7.equals(var26) ? var7.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var7
//     assertTrue("Contract failed: equals-hashcode on var26 and var7", var26.equals(var7) ? var26.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
//     boolean var3 = var1.getLabelLinksVisible();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
//     org.jfree.chart.labels.PieSectionLabelGenerator var7 = var1.getLegendLabelToolTipGenerator();
//     boolean var8 = var1.getSectionOutlinesVisible();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
//     var10.setSectionOutlinesVisible(true);
//     java.awt.Paint var14 = var10.getShadowPaint();
//     var1.setLabelShadowPaint(var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var18 = var17.getQuadrantOrigin();
//     var17.mapDatasetToDomainAxis(100, 0);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var24 = var23.getPlotType();
//     org.jfree.chart.urls.PieURLGenerator var25 = null;
//     var23.setLegendLabelURLGenerator(var25);
//     java.awt.Graphics2D var27 = null;
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
//     org.jfree.chart.util.RectangleInsets var31 = var30.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var32 = null;
//     var30.setToolTipGenerator(var32);
//     java.awt.Font var34 = var30.getLabelFont();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var34);
//     var35.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var41 = var35.getURLText();
//     org.jfree.chart.util.VerticalAlignment var42 = var35.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var43 = var35.getBounds();
//     var23.drawBackgroundImage(var27, var43);
//     java.util.List var45 = null;
//     var17.drawRangeTickBands(var22, var43, var45);
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     var48.setForegroundAlpha(1.0f);
//     java.awt.Font var51 = var48.getNoDataMessageFont();
//     var48.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var48);
//     org.jfree.chart.axis.AxisLocation var55 = var48.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var56 = var48.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var57 = null;
//     org.jfree.chart.util.VerticalAlignment var58 = null;
//     org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement(var57, var58, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var62 = null;
//     org.jfree.chart.util.VerticalAlignment var63 = null;
//     org.jfree.chart.block.ColumnArrangement var66 = new org.jfree.chart.block.ColumnArrangement(var62, var63, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48, (org.jfree.chart.block.Arrangement)var61, (org.jfree.chart.block.Arrangement)var66);
//     var67.setID("hi!");
//     java.awt.Paint var70 = var67.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var71 = var67.getLegendItemGraphicAnchor();
//     java.awt.geom.Point2D var72 = org.jfree.chart.util.RectangleAnchor.coordinates(var43, var71);
//     var1.drawBackground(var16, var43);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    boolean var15 = var0.isRangeCrosshairVisible();
    var0.mapDatasetToDomainAxis(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var8 = null;
    var7.datasetChanged(var8);
    java.awt.Stroke var10 = var7.getOutlineStroke();
    java.awt.Paint var11 = var7.getRangeZeroBaselinePaint();
    java.awt.Stroke var12 = var7.getOutlineStroke();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
    org.jfree.chart.util.RectangleInsets var15 = var14.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var16 = null;
    var14.setToolTipGenerator(var16);
    org.jfree.chart.labels.PieSectionLabelGenerator var18 = var14.getLegendLabelToolTipGenerator();
    var14.setLabelLinkMargin(100.0d);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var24 = null;
    var22.setToolTipGenerator(var24);
    java.awt.Stroke var26 = var22.getBaseSectionOutlineStroke();
    var14.setLabelOutlineStroke(var26);
    var7.setRangeCrosshairStroke(var26);
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var30 = var29.clone();
    int var31 = var7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
    org.jfree.chart.axis.MarkerAxisBand var32 = null;
    var29.setMarkerBand(var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-65536), (org.jfree.chart.axis.ValueAxis)var29, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    double var10 = var1.getLowerMargin();
    boolean var11 = var1.isVerticalTickLabels();
    var1.setPositiveArrowVisible(true);
    org.jfree.data.Range var14 = var1.getRange();
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(3.0d, var14);
    double var16 = var14.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var6 = null;
//     var4.setToolTipGenerator(var6);
//     java.awt.Font var8 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var8);
//     org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine("Other", var8);
//     java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     boolean var28 = var21.equals((java.lang.Object)var27);
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var33 = null;
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
//     float var36 = var35.getAlpha();
//     java.awt.Paint var37 = var35.getLabelPaint();
//     java.awt.Paint var38 = var35.getPaint();
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("", var8, var38, (-1.0f));
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.util.Size2D var42 = var40.calculateDimensions(var41);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var5.setDomainAxisLocation(1, var7, false);
    java.awt.Stroke var10 = var5.getRangeCrosshairStroke();
    var1.setBaseSectionOutlineStroke(var10);
    var1.setLabelGap((-1.0d));
    var1.zoom((-7.0d));
    java.lang.Comparable var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var17 = var1.getSectionOutlinePaint(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var3 = var2.clone();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var2.setAxisLinePaint(var9);
    org.jfree.data.Range var11 = var2.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(100.0d, var11);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var14 = var13.clone();
    org.jfree.data.Range var15 = var13.getRange();
    org.jfree.data.Range var16 = org.jfree.data.Range.combine(var11, var15);
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(3.0d, var15);
    double var18 = var17.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.data.xy.XYDataset var6 = var0.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(100, var8, false);
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var24 = null;
    var22.setDomainAxisLocation(1, var24, false);
    java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
    boolean var28 = var21.equals((java.lang.Object)var27);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var33 = null;
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
    java.lang.Object var36 = var35.clone();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var35);
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var40 = null;
    var38.setDomainAxisLocation(1, var40, false);
    java.awt.Stroke var43 = var38.getRangeCrosshairStroke();
    var38.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    var38.setRenderer(var46);
    org.jfree.chart.axis.ValueAxis var49 = var38.getRangeAxisForDataset(0);
    var38.configureDomainAxes();
    var35.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var38);
    org.jfree.chart.util.LengthAdjustmentType var52 = var35.getLabelOffsetType();
    var35.setAlpha(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var7 = var6.clone();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
    var9.setSectionOutlinesVisible(true);
    java.awt.Paint var13 = var9.getBaseSectionPaint();
    var6.setAxisLinePaint(var13);
    org.jfree.data.Range var15 = var6.getDefaultAutoRange();
    var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var19 = null;
    var17.setDomainAxisLocation(1, var19, false);
    java.awt.Stroke var22 = var17.getRangeCrosshairStroke();
    var17.setRangeCrosshairLockedOnData(false);
    java.awt.geom.Point2D var25 = var17.getQuadrantOrigin();
    boolean var26 = var6.hasListener((java.util.EventListener)var17);
    boolean var27 = var6.isAutoTickUnitSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var1 = var0.getQuadrantOrigin();
    var0.mapDatasetToDomainAxis(100, 0);
    var0.setRangeCrosshairValue(0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     var0.configureRangeAxes();
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var0.getCategoriesForAxis(var7);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var10 = var9.getQuadrantOrigin();
//     var9.setRangeCrosshairValue(10.0d, true);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = var9.getRendererForDataset(var14);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.setForegroundAlpha(1.0f);
//     java.awt.Font var20 = var17.getNoDataMessageFont();
//     var17.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var17);
//     org.jfree.chart.axis.AxisLocation var24 = var17.getDomainAxisLocation();
//     var9.setRangeAxisLocation(var24);
//     var0.setDomainAxisLocation(var24);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.setForegroundAlpha(1.0f);
//     java.awt.Font var31 = var28.getNoDataMessageFont();
//     var28.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var28);
//     org.jfree.chart.axis.AxisLocation var35 = var28.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var36 = var28.getDomainAxisLocation();
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var39 = null;
//     var37.setDomainAxisLocation(1, var39, false);
//     java.awt.Stroke var42 = var37.getRangeCrosshairStroke();
//     org.jfree.chart.util.Layer var44 = null;
//     java.util.Collection var45 = var37.getRangeMarkers(10, var44);
//     java.util.List var46 = var37.getAnnotations();
//     org.jfree.chart.plot.PlotOrientation var47 = var37.getOrientation();
//     org.jfree.chart.util.RectangleEdge var48 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var36, var47);
//     org.jfree.chart.util.RectangleEdge var49 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var24, var47);
//     
//     // Checks the contract:  equals-hashcode on var17 and var28
//     assertTrue("Contract failed: equals-hashcode on var17 and var28", var17.equals(var28) ? var17.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var17
//     assertTrue("Contract failed: equals-hashcode on var28 and var17", var28.equals(var17) ? var28.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var34
//     assertTrue("Contract failed: equals-hashcode on var23 and var34", var23.equals(var34) ? var23.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var23
//     assertTrue("Contract failed: equals-hashcode on var34 and var23", var34.equals(var23) ? var34.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.util.List var12 = null;
    var0.drawRangeTickBands(var10, var11, var12);
    int var14 = var0.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     var0.setRenderer(var8);
//     org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxisForDataset(0);
//     var0.configureDomainAxes();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     var0.setRenderer(0, var14);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.setForegroundAlpha(1.0f);
//     java.awt.Font var20 = var17.getNoDataMessageFont();
//     var17.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var17);
//     org.jfree.chart.axis.AxisLocation var24 = var17.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var25 = var17.getDomainAxisLocation();
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var28 = null;
//     var26.setDomainAxisLocation(1, var28, false);
//     java.awt.Stroke var31 = var26.getRangeCrosshairStroke();
//     var26.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     var26.setRenderer(var34);
//     java.awt.Graphics2D var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     java.util.List var38 = null;
//     var26.drawRangeTickBands(var36, var37, var38);
//     float var40 = var26.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var42 = null;
//     var41.setFixedLegendItems(var42);
//     java.awt.Graphics2D var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     boolean var48 = var41.render(var44, var45, 10, var47);
//     org.jfree.chart.axis.AxisLocation var49 = var41.getDomainAxisLocation();
//     var26.setDomainAxisLocation(var49);
//     var17.setDomainAxisLocation(var49);
//     var0.setDomainAxisLocation(var49);
//     
//     // Checks the contract:  equals-hashcode on var0 and var26
//     assertTrue("Contract failed: equals-hashcode on var0 and var26", var0.equals(var26) ? var0.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.PaintMap var0 = new org.jfree.chart.PaintMap();
    var0.clear();
    var0.clear();

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
    boolean var5 = var0.isRangeCrosshairLockedOnData();
    var0.setRangeCrosshairLockedOnData(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Paint var4 = var1.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var5 = var1.getRowRenderingOrder();
    java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var19 = null;
    var17.setDomainAxisLocation(1, var19, false);
    java.awt.Stroke var22 = var17.getRangeCrosshairStroke();
    boolean var23 = var16.equals((java.lang.Object)var22);
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var28 = null;
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var10, var22, (java.awt.Paint)var27, var28, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var31 = null;
    var30.addChangeListener(var31);
    var1.addRangeMarker((org.jfree.chart.plot.Marker)var30);
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    var35.setForegroundAlpha(1.0f);
    java.awt.Font var38 = var35.getNoDataMessageFont();
    var35.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var42.setMaximumCategoryLabelLines((-1));
    int var45 = var35.getDomainAxisIndex(var42);
    var1.setDomainAxis(100, var42);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var49 = var48.getTickLabelFont();
    var48.setAutoRange(false);
    java.text.NumberFormat var52 = var48.getNumberFormatOverride();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var42, (org.jfree.chart.axis.ValueAxis)var48, var53);
    float var55 = var48.getTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0f);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.setForegroundAlpha(1.0f);
//     java.awt.Font var25 = var22.getNoDataMessageFont();
//     var22.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var22);
//     org.jfree.chart.axis.AxisLocation var29 = var22.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var30 = var22.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.ColumnArrangement var40 = new org.jfree.chart.block.ColumnArrangement(var36, var37, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var35, (org.jfree.chart.block.Arrangement)var40);
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot(var42);
//     org.jfree.chart.util.RectangleInsets var44 = var43.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var45 = null;
//     var43.setToolTipGenerator(var45);
//     java.awt.Stroke var47 = var43.getBaseSectionOutlineStroke();
//     java.awt.Paint var48 = var43.getLabelLinkPaint();
//     var41.setItemPaint(var48);
//     java.awt.Paint var50 = var41.getItemPaint();
//     java.awt.Paint var51 = var41.getItemPaint();
//     boolean var52 = var19.equals((java.lang.Object)var51);
//     
//     // Checks the contract:  equals-hashcode on var1 and var22
//     assertTrue("Contract failed: equals-hashcode on var1 and var22", var1.equals(var22) ? var1.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var1
//     assertTrue("Contract failed: equals-hashcode on var22 and var1", var22.equals(var1) ? var22.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var28
//     assertTrue("Contract failed: equals-hashcode on var7 and var28", var7.equals(var28) ? var7.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var7
//     assertTrue("Contract failed: equals-hashcode on var28 and var7", var28.equals(var7) ? var28.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var35
//     assertTrue("Contract failed: equals-hashcode on var14 and var35", var14.equals(var35) ? var14.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var40
//     assertTrue("Contract failed: equals-hashcode on var19 and var40", var19.equals(var40) ? var19.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var14
//     assertTrue("Contract failed: equals-hashcode on var35 and var14", var35.equals(var14) ? var35.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var19
//     assertTrue("Contract failed: equals-hashcode on var40 and var19", var40.equals(var19) ? var40.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var4.setMarkerBand(var5);
    org.jfree.data.Range var7 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var4);
    org.jfree.chart.axis.ValueAxis var8 = null;
    var0.setRangeAxis(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var4.setMarkerBand(var5);
    org.jfree.data.Range var7 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var4);
    var4.setLabelAngle((-1.0d));
    boolean var10 = var4.getAutoRangeIncludesZero();
    double var11 = var4.getUpperMargin();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var15 = var14.clone();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
    org.jfree.chart.util.RectangleInsets var18 = var17.getLabelPadding();
    var17.setSectionOutlinesVisible(true);
    java.awt.Paint var21 = var17.getBaseSectionPaint();
    var14.setAxisLinePaint(var21);
    org.jfree.data.Range var23 = var14.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(100.0d, var23);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var26 = var25.clone();
    org.jfree.data.Range var27 = var25.getRange();
    org.jfree.data.Range var28 = org.jfree.data.Range.combine(var23, var27);
    org.jfree.chart.block.RectangleConstraint var29 = new org.jfree.chart.block.RectangleConstraint(3.0d, var27);
    var4.setRange(var27);
    boolean var33 = var27.intersects((-7.0d), 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.util.UnitType var3 = var2.getUnitType();
    java.lang.String var4 = var3.toString();
    java.lang.String var5 = var3.toString();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    boolean var8 = var3.equals((java.lang.Object)"RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "UnitType.ABSOLUTE"+ "'", var4.equals("UnitType.ABSOLUTE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "UnitType.ABSOLUTE"+ "'", var5.equals("UnitType.ABSOLUTE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Font var3 = var0.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelPadding();
    var5.setSectionOutlinesVisible(true);
    java.awt.Paint var9 = var5.getBaseSectionPaint();
    var0.setRangeCrosshairPaint(var9);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
    var0.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    org.jfree.chart.util.Layer var23 = null;
    java.util.Collection var24 = var16.getRangeMarkers(10, var23);
    java.util.List var25 = var16.getAnnotations();
    org.jfree.chart.plot.PlotOrientation var26 = var16.getOrientation();
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    var28.setForegroundAlpha(1.0f);
    java.awt.Font var31 = var28.getNoDataMessageFont();
    var28.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var28);
    org.jfree.chart.axis.AxisLocation var35 = var28.getDomainAxisLocation();
    var16.setRangeAxisLocation(var35);
    var0.setRangeAxisLocation(0, var35, false);
    org.jfree.chart.axis.CategoryAxis var39 = var0.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + "UnitType.ABSOLUTE"+ "'", var0.equals("UnitType.ABSOLUTE"));

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var1 = null;
//     var0.datasetChanged(var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     var0.setRenderer(1, var4);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var6.setDomainAxisLocation(1, var8, false);
//     java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     boolean var28 = var21.equals((java.lang.Object)var27);
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var33 = null;
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var27, (java.awt.Paint)var32, var33, 1.0f);
//     float var36 = var35.getAlpha();
//     java.awt.Paint var37 = var35.getLabelPaint();
//     double var38 = var35.getValue();
//     var6.addDomainMarker((org.jfree.chart.plot.Marker)var35);
//     boolean var40 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var35);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedDimension();
//     org.jfree.data.RangeType var2 = var0.getRangeType();
//     var0.setLowerMargin(6.0d);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var11 = null;
//     var9.setToolTipGenerator(var11);
//     java.awt.Font var13 = var9.getLabelFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var13);
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("Other", var13);
//     java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var20);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var29 = null;
//     var27.setDomainAxisLocation(1, var29, false);
//     java.awt.Stroke var32 = var27.getRangeCrosshairStroke();
//     boolean var33 = var26.equals((java.lang.Object)var32);
//     java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var38 = null;
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var20, var32, (java.awt.Paint)var37, var38, 1.0f);
//     float var41 = var40.getAlpha();
//     java.awt.Paint var42 = var40.getLabelPaint();
//     java.awt.Paint var43 = var40.getPaint();
//     org.jfree.chart.text.TextFragment var45 = new org.jfree.chart.text.TextFragment("", var13, var43, (-1.0f));
//     var0.setTickLabelFont(var13);
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var50 = var49.clone();
//     org.jfree.data.general.PieDataset var51 = null;
//     org.jfree.chart.plot.PiePlot var52 = new org.jfree.chart.plot.PiePlot(var51);
//     org.jfree.chart.util.RectangleInsets var53 = var52.getLabelPadding();
//     var52.setSectionOutlinesVisible(true);
//     java.awt.Paint var56 = var52.getBaseSectionPaint();
//     var49.setAxisLinePaint(var56);
//     org.jfree.data.Range var58 = var49.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var59 = new org.jfree.chart.block.RectangleConstraint(100.0d, var58);
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var61 = var60.clone();
//     org.jfree.data.Range var62 = var60.getRange();
//     org.jfree.data.Range var63 = org.jfree.data.Range.combine(var58, var62);
//     org.jfree.chart.block.RectangleConstraint var64 = new org.jfree.chart.block.RectangleConstraint(3.0d, var62);
//     var0.setRangeWithMargins(var62);
//     
//     // Checks the contract:  equals-hashcode on var9 and var52
//     assertTrue("Contract failed: equals-hashcode on var9 and var52", var9.equals(var52) ? var9.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var9
//     assertTrue("Contract failed: equals-hashcode on var52 and var9", var52.equals(var9) ? var52.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setDomainAxes(var3);
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    var0.setRenderer(var5);
    var0.setRangeCrosshairValue(10.0d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDomainGridlinesVisible(false);
    var0.setBackgroundImageAlignment((-1));
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var9 = null;
    var7.setDomainAxisLocation(1, var9, false);
    java.awt.Stroke var12 = var7.getRangeCrosshairStroke();
    var7.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    var7.setRenderer(var15);
    org.jfree.chart.axis.ValueAxis var18 = var7.getRangeAxisForDataset(0);
    var7.configureDomainAxes();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    var7.setRenderer(0, var21);
    var7.setForegroundAlpha(100.0f);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var27 = var26.getQuadrantOrigin();
    var26.mapDatasetToDomainAxis(100, 0);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var33 = var32.getPlotType();
    org.jfree.chart.urls.PieURLGenerator var34 = null;
    var32.setLegendLabelURLGenerator(var34);
    java.awt.Graphics2D var36 = null;
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
    org.jfree.chart.util.RectangleInsets var40 = var39.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var41 = null;
    var39.setToolTipGenerator(var41);
    java.awt.Font var43 = var39.getLabelFont();
    org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var43);
    var44.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var50 = var44.getURLText();
    org.jfree.chart.util.VerticalAlignment var51 = var44.getVerticalAlignment();
    java.awt.geom.Rectangle2D var52 = var44.getBounds();
    var32.drawBackgroundImage(var36, var52);
    java.util.List var54 = null;
    var26.drawRangeTickBands(var31, var52, var54);
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
    var57.setForegroundAlpha(1.0f);
    java.awt.Font var60 = var57.getNoDataMessageFont();
    var57.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var57);
    org.jfree.chart.axis.AxisLocation var64 = var57.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var65 = var57.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var66 = null;
    org.jfree.chart.util.VerticalAlignment var67 = null;
    org.jfree.chart.block.ColumnArrangement var70 = new org.jfree.chart.block.ColumnArrangement(var66, var67, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var71 = null;
    org.jfree.chart.util.VerticalAlignment var72 = null;
    org.jfree.chart.block.ColumnArrangement var75 = new org.jfree.chart.block.ColumnArrangement(var71, var72, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var76 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57, (org.jfree.chart.block.Arrangement)var70, (org.jfree.chart.block.Arrangement)var75);
    var76.setID("hi!");
    java.awt.Paint var79 = var76.getBackgroundPaint();
    org.jfree.chart.util.RectangleAnchor var80 = var76.getLegendItemGraphicAnchor();
    java.awt.geom.Point2D var81 = org.jfree.chart.util.RectangleAnchor.coordinates(var52, var80);
    org.jfree.chart.plot.XYPlot var82 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var83 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var84 = var83.clone();
    org.jfree.chart.axis.ValueAxis[] var85 = new org.jfree.chart.axis.ValueAxis[] { var83};
    var82.setDomainAxes(var85);
    org.jfree.data.xy.XYDataset var88 = var82.getDataset(100);
    org.jfree.chart.plot.PlotRenderingInfo var90 = null;
    org.jfree.chart.plot.XYPlot var91 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var92 = var91.getQuadrantOrigin();
    var82.zoomRangeAxes(0.0d, var90, var92, false);
    org.jfree.chart.plot.PlotState var95 = null;
    org.jfree.chart.plot.PlotRenderingInfo var96 = null;
    var7.draw(var25, var52, var92, var95, var96);
    var0.zoomDomainAxes((-7.0d), var6, var92, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "Pie 3D Plot"+ "'", var33.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    var1.setSectionOutlinesVisible(true);
    boolean var7 = var1.getSectionOutlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { ""};
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.text.TextAnchor var26 = var24.getLabelTextAnchor();
//     java.lang.String var27 = var26.toString();
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.setForegroundAlpha(1.0f);
//     java.awt.Font var32 = var29.getNoDataMessageFont();
//     var29.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var29);
//     java.awt.Paint var36 = var35.getBackgroundPaint();
//     java.awt.Stroke var37 = var35.getBorderStroke();
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     var38.setForegroundAlpha(1.0f);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var45 = var44.clone();
//     org.jfree.chart.axis.ValueAxis[] var46 = new org.jfree.chart.axis.ValueAxis[] { var44};
//     var43.setDomainAxes(var46);
//     org.jfree.data.xy.XYDataset var49 = var43.getDataset(100);
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var53 = var52.getQuadrantOrigin();
//     var43.zoomRangeAxes(0.0d, var51, var53, false);
//     var38.zoomDomainAxes((-7.0d), var42, var53);
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var58 = var57.getLabelURL();
//     var57.configure();
//     java.awt.Paint var60 = var57.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var61 = var57.getTickLabelInsets();
//     double var63 = var61.calculateRightInset(0.05d);
//     var38.setAxisOffset(var61);
//     var35.setPadding(var61);
//     boolean var66 = var26.equals((java.lang.Object)var35);
//     
//     // Checks the contract:  equals-hashcode on var11 and var52
//     assertTrue("Contract failed: equals-hashcode on var11 and var52", var11.equals(var52) ? var11.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var11
//     assertTrue("Contract failed: equals-hashcode on var52 and var11", var52.equals(var11) ? var52.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var0.setTickUnit(var2, false, true);
    java.util.Date var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setMinimumDate(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     var20.setID("hi!");
//     java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var36 = null;
//     var34.setDomainAxisLocation(1, var36, false);
//     java.awt.Stroke var39 = var34.getRangeCrosshairStroke();
//     boolean var40 = var33.equals((java.lang.Object)var39);
//     java.awt.Color var44 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var45 = null;
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var27, var39, (java.awt.Paint)var44, var45, 1.0f);
//     float var48 = var47.getAlpha();
//     java.awt.Paint var49 = var47.getLabelPaint();
//     java.awt.Paint var50 = var47.getPaint();
//     org.jfree.chart.util.RectangleAnchor var51 = var47.getLabelAnchor();
//     var20.setLegendItemGraphicAnchor(var51);
//     
//     // Checks the contract:  equals-hashcode on var14 and var33
//     assertTrue("Contract failed: equals-hashcode on var14 and var33", var14.equals(var33) ? var14.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var14
//     assertTrue("Contract failed: equals-hashcode on var33 and var14", var33.equals(var14) ? var33.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    var0.setRenderer(1, var4);
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge(10);
    boolean var9 = var0.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(0);
    boolean var12 = var0.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.AxisSpace var13 = null;
    var0.setFixedDomainAxisSpace(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var1.setDomainAxisLocation(1, var3, false);
//     java.awt.Stroke var6 = var1.getRangeCrosshairStroke();
//     java.awt.Font var7 = var1.getNoDataMessageFont();
//     java.awt.Color var11 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Color var12 = var11.darker();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var7, (java.awt.Paint)var11);
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var11);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var17 = var16.getPlotType();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var16.setLegendLabelURLGenerator(var18);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     org.jfree.chart.util.RectangleInsets var24 = var23.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var25 = null;
//     var23.setToolTipGenerator(var25);
//     java.awt.Font var27 = var23.getLabelFont();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var27);
//     var28.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var34 = var28.getURLText();
//     org.jfree.chart.util.VerticalAlignment var35 = var28.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var36 = var28.getBounds();
//     var16.drawBackgroundImage(var20, var36);
//     var14.draw(var15, var36);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
    org.jfree.chart.util.RectangleEdge var10 = var0.getRangeAxisEdge();
    org.jfree.data.general.DatasetChangeEvent var11 = null;
    var0.datasetChanged(var11);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    var0.setRenderer(255, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    org.jfree.chart.util.UnitType var12 = var11.getUnitType();
    var7.setPadding(var11);
    org.jfree.chart.title.TextTitle var14 = var7.getTitle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var15 = var7.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var5.setLicenceName("hi!");
    org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var9 = var8.getContributors();
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var8);
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setForegroundAlpha(1.0f);
    java.awt.Paint var15 = var12.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var12);
    org.jfree.chart.plot.Plot var17 = var16.getPlot();
    org.jfree.chart.event.ChartChangeEventType var18 = var16.getType();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var20 = var19.clone();
    double var21 = var19.getLowerBound();
    boolean var22 = var18.equals((java.lang.Object)var19);
    org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var5, var11, var18);
    java.lang.String var24 = var5.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + ""+ "'", var24.equals(""));

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var11.setDomainAxisLocation(1, var13, false);
//     java.awt.Stroke var16 = var11.getRangeCrosshairStroke();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var22 = null;
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var16, (java.awt.Paint)var21, var22, 1.0f);
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var27 = var26.getQuadrantOrigin();
//     var26.setRangeCrosshairValue(10.0d, true);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = var26.getRendererForDataset(var31);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.setForegroundAlpha(1.0f);
//     java.awt.Font var37 = var34.getNoDataMessageFont();
//     var34.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var34);
//     org.jfree.chart.axis.AxisLocation var41 = var34.getDomainAxisLocation();
//     var26.setRangeAxisLocation(var41);
//     boolean var43 = var24.equals((java.lang.Object)var26);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.setForegroundAlpha(1.0f);
//     boolean var48 = var45.isDomainGridlinesVisible();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     var45.setRenderer(var49, true);
//     org.jfree.chart.axis.AxisLocation var53 = var45.getRangeAxisLocation((-1));
//     var26.setDomainAxisLocation(0, var53, true);
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var58 = null;
//     var56.setDomainAxisLocation(1, var58, false);
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var63 = var62.clone();
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.PiePlot var65 = new org.jfree.chart.plot.PiePlot(var64);
//     org.jfree.chart.util.RectangleInsets var66 = var65.getLabelPadding();
//     var65.setSectionOutlinesVisible(true);
//     java.awt.Paint var69 = var65.getBaseSectionPaint();
//     var62.setAxisLinePaint(var69);
//     org.jfree.data.Range var71 = var62.getDefaultAutoRange();
//     var56.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var62);
//     org.jfree.data.general.DatasetChangeEvent var73 = null;
//     var56.datasetChanged(var73);
//     org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var76 = null;
//     var75.datasetChanged(var76);
//     org.jfree.chart.renderer.xy.XYItemRenderer var79 = null;
//     var75.setRenderer(1, var79);
//     org.jfree.chart.util.RectangleEdge var82 = var75.getDomainAxisEdge(10);
//     boolean var84 = var75.equals((java.lang.Object)(-1));
//     org.jfree.chart.axis.AxisLocation var86 = var75.getRangeAxisLocation(0);
//     var56.setRangeAxisLocation(var86);
//     var26.setRangeAxisLocation(var86, true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var75
//     assertTrue("Contract failed: equals-hashcode on var11 and var75", var11.equals(var75) ? var11.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var11
//     assertTrue("Contract failed: equals-hashcode on var75 and var11", var75.equals(var11) ? var75.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.Plot var8 = var0.getRootPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(var9);
//     java.awt.Paint var11 = var0.getDomainZeroBaselinePaint();
//     org.jfree.chart.event.RendererChangeEvent var12 = null;
//     var0.rendererChanged(var12);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.setForegroundAlpha(1.0f);
//     java.awt.Font var17 = var14.getNoDataMessageFont();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.MarkerAxisBand var19 = null;
//     var18.setMarkerBand(var19);
//     org.jfree.data.Range var21 = var14.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var18);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var25 = null;
//     var24.setFixedLegendItems(var25);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     boolean var31 = var24.render(var27, var28, 10, var30);
//     java.awt.Stroke var32 = var24.getDomainGridlineStroke();
//     org.jfree.chart.axis.AxisLocation var33 = var24.getRangeAxisLocation();
//     var0.setRangeAxisLocation(10, var33);
//     
//     // Checks the contract:  equals-hashcode on var14 and var24
//     assertTrue("Contract failed: equals-hashcode on var14 and var24", var14.equals(var24) ? var14.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var14
//     assertTrue("Contract failed: equals-hashcode on var24 and var14", var24.equals(var14) ? var24.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var0.setTickUnit(var2, false, true);
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var8 = var7.clone();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
//     var10.setSectionOutlinesVisible(true);
//     java.awt.Paint var14 = var10.getBaseSectionPaint();
//     var7.setAxisLinePaint(var14);
//     org.jfree.data.Range var16 = var7.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(100.0d, var16);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var19 = var18.clone();
//     org.jfree.data.Range var20 = var18.getRange();
//     org.jfree.data.Range var21 = org.jfree.data.Range.combine(var16, var20);
//     org.jfree.data.Range var23 = org.jfree.data.Range.shift(var20, 10.0d);
//     var0.setRange(var23, false, true);
//     org.jfree.chart.axis.DateTickUnit var27 = null;
//     java.util.Date var28 = var0.calculateHighestVisibleTickValue(var27);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TextAnchor.CENTER", var1);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "Pie 3D Plot", var3);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.setForegroundAlpha(1.0f);
    java.awt.Font var6 = var3.getNoDataMessageFont();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var8 = null;
    var7.datasetChanged(var8);
    java.awt.Stroke var10 = var7.getOutlineStroke();
    java.awt.Paint var11 = var7.getRangeZeroBaselinePaint();
    org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6, var11);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var6);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
    var14.mapDatasetToDomainAxis(100, 0);
    java.awt.Paint var19 = var14.getDomainCrosshairPaint();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.text.G2TextMeasurer var22 = new org.jfree.chart.text.G2TextMeasurer(var21);
    org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var19, 10.0f, (org.jfree.chart.text.TextMeasurer)var22);
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.text.TextBlockAnchor var27 = null;
    var23.draw(var24, 1.0f, 2.0f, var27, 100.0f, 0.0f, 3.0d);
    org.jfree.chart.util.HorizontalAlignment var32 = var23.getLineAlignment();
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
    org.jfree.chart.util.RectangleInsets var36 = var35.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var37 = null;
    var35.setToolTipGenerator(var37);
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var41 = null;
    var39.setDomainAxisLocation(1, var41, false);
    java.awt.Stroke var44 = var39.getRangeCrosshairStroke();
    var35.setBaseSectionOutlineStroke(var44);
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
    var46.setForegroundAlpha(1.0f);
    java.awt.Font var49 = var46.getNoDataMessageFont();
    var35.setLabelFont(var49);
    java.awt.Paint var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.addLine("java.awt.Color[r=255,g=0,b=0]", var49, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateX(100.0d);
    var0.setGenerateEntities(false);
    double var5 = var0.getTranslateY();
    boolean var6 = var0.getGenerateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var7 = var6.clone();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
    var9.setSectionOutlinesVisible(true);
    java.awt.Paint var13 = var9.getBaseSectionPaint();
    var6.setAxisLinePaint(var13);
    org.jfree.data.Range var15 = var6.getDefaultAutoRange();
    var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.data.general.DatasetChangeEvent var17 = null;
    var0.datasetChanged(var17);
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var20 = null;
    var19.datasetChanged(var20);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    var19.setRenderer(1, var23);
    org.jfree.chart.util.RectangleEdge var26 = var19.getDomainAxisEdge(10);
    boolean var28 = var19.equals((java.lang.Object)(-1));
    org.jfree.chart.axis.AxisLocation var30 = var19.getRangeAxisLocation(0);
    var0.setRangeAxisLocation(var30);
    double var32 = var0.getDomainCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var2 = var0.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "Pie 3D Plot");
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var2);
    java.lang.Object var6 = var5.clone();
    java.lang.String var7 = var5.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Range[0.0,1.0]", var1, 0.08d, 0.0f, 1.0f);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]", var1, 1.0f, 1.0f, 0.14d, 1.0f, 100.0f);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedDomainAxisSpace(var1, true);
//     var0.clearDomainMarkers(100);
//     var0.setOutlineVisible(true);
//     org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxis(0);
//     java.awt.Paint var10 = var0.getRangeGridlinePaint();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
//     org.jfree.chart.util.RectangleInsets var15 = var14.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var16 = null;
//     var14.setToolTipGenerator(var16);
//     java.awt.Font var18 = var14.getLabelFont();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var18);
//     var19.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var25 = var19.getURLText();
//     org.jfree.chart.util.VerticalAlignment var26 = var19.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var27 = var19.getBounds();
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var29 = var28.getQuadrantOrigin();
//     var28.mapDatasetToDomainAxis(100, 0);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.plot.PiePlot3D var34 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var35 = var34.getPlotType();
//     org.jfree.chart.urls.PieURLGenerator var36 = null;
//     var34.setLegendLabelURLGenerator(var36);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     org.jfree.chart.util.RectangleInsets var42 = var41.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var43 = null;
//     var41.setToolTipGenerator(var43);
//     java.awt.Font var45 = var41.getLabelFont();
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var45);
//     var46.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var52 = var46.getURLText();
//     org.jfree.chart.util.VerticalAlignment var53 = var46.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var54 = var46.getBounds();
//     var34.drawBackgroundImage(var38, var54);
//     java.util.List var56 = null;
//     var28.drawRangeTickBands(var33, var54, var56);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     var59.setForegroundAlpha(1.0f);
//     java.awt.Font var62 = var59.getNoDataMessageFont();
//     var59.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var59);
//     org.jfree.chart.axis.AxisLocation var66 = var59.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var67 = var59.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var68 = null;
//     org.jfree.chart.util.VerticalAlignment var69 = null;
//     org.jfree.chart.block.ColumnArrangement var72 = new org.jfree.chart.block.ColumnArrangement(var68, var69, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var73 = null;
//     org.jfree.chart.util.VerticalAlignment var74 = null;
//     org.jfree.chart.block.ColumnArrangement var77 = new org.jfree.chart.block.ColumnArrangement(var73, var74, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var78 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59, (org.jfree.chart.block.Arrangement)var72, (org.jfree.chart.block.Arrangement)var77);
//     var78.setID("hi!");
//     java.awt.Paint var81 = var78.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var82 = var78.getLegendItemGraphicAnchor();
//     java.awt.geom.Point2D var83 = org.jfree.chart.util.RectangleAnchor.coordinates(var54, var82);
//     org.jfree.chart.plot.PlotState var84 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var85 = null;
//     var0.draw(var11, var27, var83, var84, var85);
//     
//     // Checks the contract:  equals-hashcode on var14 and var41
//     assertTrue("Contract failed: equals-hashcode on var14 and var41", var14.equals(var41) ? var14.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var14
//     assertTrue("Contract failed: equals-hashcode on var41 and var14", var41.equals(var14) ? var41.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 2.0f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var2 = var1.getLabelURL();
//     var1.configure();
//     java.awt.Paint var4 = var1.getTickLabelPaint();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     var5.setTickMarksVisible(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var8);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var9.handleClick(0, 0, var12);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var1 = null;
    var0.setMarkerBand(var1);
    java.awt.Font var3 = var0.getTickLabelFont();
    var0.setTickLabelsVisible(true);
    java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var19 = null;
    var17.setDomainAxisLocation(1, var19, false);
    java.awt.Stroke var22 = var17.getRangeCrosshairStroke();
    boolean var23 = var16.equals((java.lang.Object)var22);
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var28 = null;
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var10, var22, (java.awt.Paint)var27, var28, 1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisLineStroke(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedDomainAxisSpace(var3);
    org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
    java.util.List var6 = var0.getCategories();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setDomainAxisLocation(1, var18, false);
    java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
    boolean var22 = var15.equals((java.lang.Object)var21);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var27 = null;
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
    org.jfree.chart.event.MarkerChangeListener var30 = null;
    var29.addChangeListener(var30);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var29);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.setForegroundAlpha(1.0f);
    java.awt.Font var37 = var34.getNoDataMessageFont();
    var34.setAnchorValue(100.0d);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var41.setMaximumCategoryLabelLines((-1));
    int var44 = var34.getDomainAxisIndex(var41);
    var0.setDomainAxis(100, var41);
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var47 = null;
    var46.setMarkerBand(var47);
    int var49 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var46);
    var0.clearAnnotations();
    java.awt.Font var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNoDataMessageFont(var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-1));

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 10, var6);
    org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getUpperMargin();
    var0.setDomainAxis(10, var11, false);
    var0.setAnchorValue(0.0d);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var19 = var0.getDomainAxisIndex(var18);
    var18.setTickMarksVisible(false);
    double var22 = var18.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var0.setRenderer(var8);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var11.setDomainAxes(var14);
    org.jfree.data.xy.XYDataset var17 = var11.getDataset(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    var11.setRenderer(100, var19, false);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var26);
    org.jfree.chart.util.HorizontalAlignment var28 = null;
    org.jfree.chart.util.VerticalAlignment var29 = null;
    org.jfree.chart.block.ColumnArrangement var32 = new org.jfree.chart.block.ColumnArrangement(var28, var29, 10.0d, (-1.0d));
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var35 = null;
    var33.setDomainAxisLocation(1, var35, false);
    java.awt.Stroke var38 = var33.getRangeCrosshairStroke();
    boolean var39 = var32.equals((java.lang.Object)var38);
    java.awt.Color var43 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    java.awt.Stroke var44 = null;
    org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var26, var38, (java.awt.Paint)var43, var44, 1.0f);
    java.lang.Object var47 = var46.clone();
    var11.addDomainMarker((org.jfree.chart.plot.Marker)var46);
    double var49 = var11.getRangeCrosshairValue();
    org.jfree.chart.util.Layer var50 = null;
    java.util.Collection var51 = var11.getDomainMarkers(var50);
    org.jfree.chart.axis.AxisLocation var52 = var11.getDomainAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-1), var52, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.data.general.DatasetGroup var8 = var0.getDatasetGroup();
    boolean var9 = var0.isDomainCrosshairVisible();
    java.awt.Stroke var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainZeroBaselineStroke(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var7 = var6.clone();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getLabelPadding();
//     var9.setSectionOutlinesVisible(true);
//     java.awt.Paint var13 = var9.getBaseSectionPaint();
//     var6.setAxisLinePaint(var13);
//     org.jfree.data.Range var15 = var6.getDefaultAutoRange();
//     var0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     var0.setRenderer(0, var18, false);
//     java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var25);
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var34 = null;
//     var32.setDomainAxisLocation(1, var34, false);
//     java.awt.Stroke var37 = var32.getRangeCrosshairStroke();
//     boolean var38 = var31.equals((java.lang.Object)var37);
//     java.awt.Color var42 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var43 = null;
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var25, var37, (java.awt.Paint)var42, var43, 1.0f);
//     float var46 = var45.getAlpha();
//     java.awt.Paint var47 = var45.getPaint();
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot(var48);
//     org.jfree.chart.util.RectangleInsets var50 = var49.getLabelPadding();
//     boolean var51 = var49.getLabelLinksVisible();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var53 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var49.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var53);
//     boolean var55 = var45.equals((java.lang.Object)var49);
//     org.jfree.chart.util.Layer var56 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var45, var56);
//     java.awt.Graphics2D var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var60 = var59.getQuadrantOrigin();
//     var59.mapDatasetToDomainAxis(100, 0);
//     java.awt.Graphics2D var64 = null;
//     org.jfree.chart.plot.PiePlot3D var65 = new org.jfree.chart.plot.PiePlot3D();
//     java.lang.String var66 = var65.getPlotType();
//     org.jfree.chart.urls.PieURLGenerator var67 = null;
//     var65.setLegendLabelURLGenerator(var67);
//     java.awt.Graphics2D var69 = null;
//     org.jfree.data.general.PieDataset var71 = null;
//     org.jfree.chart.plot.PiePlot var72 = new org.jfree.chart.plot.PiePlot(var71);
//     org.jfree.chart.util.RectangleInsets var73 = var72.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var74 = null;
//     var72.setToolTipGenerator(var74);
//     java.awt.Font var76 = var72.getLabelFont();
//     org.jfree.chart.title.TextTitle var77 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var76);
//     var77.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     java.lang.String var83 = var77.getURLText();
//     org.jfree.chart.util.VerticalAlignment var84 = var77.getVerticalAlignment();
//     java.awt.geom.Rectangle2D var85 = var77.getBounds();
//     var65.drawBackgroundImage(var69, var85);
//     java.util.List var87 = null;
//     var59.drawRangeTickBands(var64, var85, var87);
//     var0.drawBackground(var58, var85);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 6.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    var0.clearDomainMarkers(100);
    var0.setOutlineVisible(true);
    org.jfree.data.general.DatasetGroup var8 = var0.getDatasetGroup();
    boolean var9 = var0.isDomainCrosshairVisible();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.setForegroundAlpha(1.0f);
    java.awt.Font var13 = var10.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelPadding();
    var15.setSectionOutlinesVisible(true);
    java.awt.Paint var19 = var15.getBaseSectionPaint();
    var10.setRangeCrosshairPaint(var19);
    java.lang.Object var21 = var10.clone();
    org.jfree.chart.LegendItemCollection var22 = var10.getLegendItems();
    var0.setFixedLegendItems(var22);
    org.jfree.chart.axis.ValueAxis var25 = var0.getDomainAxis(10);
    var0.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setDomainAxisLocation(1, var2, false);
//     java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     java.awt.geom.Point2D var8 = var0.getQuadrantOrigin();
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var0.setDomainAxis(1, var10);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var15 = null;
//     var13.setDomainAxisLocation(1, var15, false);
//     java.awt.Stroke var18 = var13.getRangeCrosshairStroke();
//     var13.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.LegendItemCollection var21 = var13.getLegendItems();
//     int var22 = var13.getRangeAxisCount();
//     org.jfree.chart.axis.AxisLocation var24 = var13.getDomainAxisLocation(100);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var27 = null;
//     var25.setDomainAxisLocation(1, var27, false);
//     java.awt.Stroke var30 = var25.getRangeCrosshairStroke();
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var25.getRangeMarkers(10, var32);
//     java.util.List var34 = var25.getAnnotations();
//     org.jfree.chart.plot.PlotOrientation var35 = var25.getOrientation();
//     org.jfree.chart.util.RectangleEdge var36 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var24, var35);
//     var0.setDomainAxisLocation(100, var24, true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var0.", var13.equals(var0) == var0.equals(var13));
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setDomainAxisLocation(1, var24, false);
//     java.awt.Stroke var27 = var22.getRangeCrosshairStroke();
//     var22.setRangeCrosshairLockedOnData(false);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
//     var22.setAxisOffset(var32);
//     var20.setItemLabelPadding(var32);
//     org.jfree.chart.util.RectangleInsets var35 = var20.getMargin();
//     org.jfree.chart.block.BlockContainer var36 = var20.getItemContainer();
//     java.awt.Graphics2D var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var41 = null;
//     var39.setDomainAxisLocation(1, var41, false);
//     java.awt.Stroke var44 = var39.getRangeCrosshairStroke();
//     java.awt.Font var45 = var39.getNoDataMessageFont();
//     java.lang.Object var46 = var36.draw(var37, var38, (java.lang.Object)var39);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    int var9 = var0.getIndexOf(var8);
    var0.setDomainZeroBaselineVisible(false);
    java.awt.Paint var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeCrosshairPaint(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.chart.event.ChartProgressEvent[source=1.0]", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var3);
    int var5 = var3.getGreen();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.setForegroundAlpha(1.0f);
    java.awt.Font var9 = var6.getNoDataMessageFont();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.util.RectangleInsets var12 = var11.getLabelPadding();
    var11.setSectionOutlinesVisible(true);
    java.awt.Paint var15 = var11.getBaseSectionPaint();
    var6.setRangeCrosshairPaint(var15);
    java.lang.Object var17 = var6.clone();
    org.jfree.chart.LegendItemCollection var18 = var6.getLegendItems();
    boolean var19 = var3.equals((java.lang.Object)var6);
    java.lang.String var20 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "java.awt.Color[r=255,g=0,b=0]"+ "'", var20.equals("java.awt.Color[r=255,g=0,b=0]"));

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var4);
    org.jfree.chart.axis.TickUnit var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setAngleTickUnit(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("XY Plot", var1);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.block.LengthConstraintType var12 = var11.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var13 = var11.toUnconstrainedHeight();
    org.jfree.data.Range var14 = var13.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     boolean var3 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     var0.setRenderer(var4, true);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.setForegroundAlpha(1.0f);
//     java.awt.Font var12 = var9.getNoDataMessageFont();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.MarkerAxisBand var14 = null;
//     var13.setMarkerBand(var14);
//     org.jfree.data.Range var16 = var9.getDataRange((org.jfree.chart.axis.ValueAxis)var13);
//     var9.setAnchorValue(0.08d);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setForegroundAlpha(1.0f);
//     java.awt.Paint var24 = var21.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var21);
//     var21.configureRangeAxes();
//     boolean var27 = var21.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     java.util.List var29 = var21.getCategoriesForAxis(var28);
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var34 = null;
//     var32.setDomainAxisLocation(1, var34, false);
//     java.awt.geom.Point2D var37 = var32.getQuadrantOrigin();
//     var21.zoomRangeAxes(6.0d, var31, var37, false);
//     var9.zoomRangeAxes(6.0d, var20, var37);
//     var0.zoomDomainAxes(10.0d, var8, var37, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var21
//     assertTrue("Contract failed: equals-hashcode on var0 and var21", var0.equals(var21) ? var0.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.setForegroundAlpha(1.0f);
//     java.awt.Font var6 = var3.getNoDataMessageFont();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.general.DatasetChangeEvent var8 = null;
//     var7.datasetChanged(var8);
//     java.awt.Stroke var10 = var7.getOutlineStroke();
//     java.awt.Paint var11 = var7.getRangeZeroBaselinePaint();
//     org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6, var11);
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", var6);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
//     var14.mapDatasetToDomainAxis(100, 0);
//     java.awt.Paint var19 = var14.getDomainCrosshairPaint();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.text.G2TextMeasurer var22 = new org.jfree.chart.text.G2TextMeasurer(var21);
//     org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var19, 10.0f, (org.jfree.chart.text.TextMeasurer)var22);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.util.Size2D var25 = var23.calculateDimensions(var24);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.setForegroundAlpha(1.0f);
//     java.awt.Paint var29 = var26.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var30 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var26);
//     var26.configureRangeAxes();
//     boolean var32 = var25.equals((java.lang.Object)var26);
//     
//     // Checks the contract:  equals-hashcode on var3 and var26
//     assertTrue("Contract failed: equals-hashcode on var3 and var26", var3.equals(var26) ? var3.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var3
//     assertTrue("Contract failed: equals-hashcode on var26 and var3", var26.equals(var3) ? var26.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setForegroundAlpha(1.0f);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.configureRangeAxes();
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var0.getCategoriesForAxis(var7);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var10 = var9.getQuadrantOrigin();
    var9.setRangeCrosshairValue(10.0d, true);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = var9.getRendererForDataset(var14);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setForegroundAlpha(1.0f);
    java.awt.Font var20 = var17.getNoDataMessageFont();
    var17.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var17);
    org.jfree.chart.axis.AxisLocation var24 = var17.getDomainAxisLocation();
    var9.setRangeAxisLocation(var24);
    var0.setDomainAxisLocation(var24);
    var0.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.Rotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDirection(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
    java.awt.Stroke var5 = var0.getOutlineStroke();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var9 = null;
    var7.setToolTipGenerator(var9);
    org.jfree.chart.labels.PieSectionLabelGenerator var11 = var7.getLegendLabelToolTipGenerator();
    var7.setLabelLinkMargin(100.0d);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var17 = null;
    var15.setToolTipGenerator(var17);
    java.awt.Stroke var19 = var15.getBaseSectionOutlineStroke();
    var7.setLabelOutlineStroke(var19);
    var0.setRangeCrosshairStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var23 = var22.clone();
    int var24 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var22);
    var22.setLabelToolTip("UnitType.ABSOLUTE");
    boolean var27 = var22.getAutoRangeStickyZero();
    var22.setLowerMargin(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var7.setURLText("Range[0.0,1.0]");
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var19 = var18.clone();
    org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var18};
    var17.setDomainAxes(var20);
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    var17.setRenderer(var22);
    org.jfree.chart.util.RectangleEdge var25 = var17.getRangeAxisEdge(0);
    var7.setPosition(var25);
    double var27 = var7.getHeight();
    var7.setPadding(100.0d, 3.0d, 0.2d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.Plot var5 = var4.getPlot();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setForegroundAlpha(1.0f);
//     java.awt.Font var10 = var7.getNoDataMessageFont();
//     var7.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var7);
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
//     org.jfree.chart.util.UnitType var18 = var17.getUnitType();
//     var13.setPadding(var17);
//     var4.setChart(var13);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setForegroundAlpha(1.0f);
//     java.awt.Paint var24 = var21.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var21);
//     org.jfree.chart.plot.Plot var26 = var25.getPlot();
//     org.jfree.chart.event.ChartChangeEventType var27 = var25.getType();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var29 = var28.clone();
//     double var30 = var28.getLowerBound();
//     boolean var31 = var27.equals((java.lang.Object)var28);
//     var4.setType(var27);
//     
//     // Checks the contract:  equals-hashcode on var0 and var21
//     assertTrue("Contract failed: equals-hashcode on var0 and var21", var0.equals(var21) ? var0.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var26
//     assertTrue("Contract failed: equals-hashcode on var5 and var26", var5.equals(var26) ? var5.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var5
//     assertTrue("Contract failed: equals-hashcode on var26 and var5", var26.equals(var5) ? var26.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(10);
    var1.sort();
    java.lang.String var3 = var1.toString();
    org.jfree.chart.plot.PieLabelRecord var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
    org.jfree.chart.util.UnitType var12 = var11.getUnitType();
    var7.setPadding(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var14 = var7.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 3.0d, 100.0d);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.setForegroundAlpha(1.0f);
    java.awt.Font var9 = var6.getNoDataMessageFont();
    var6.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.axis.AxisLocation var13 = var6.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var14 = var6.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var19, (org.jfree.chart.block.Arrangement)var24);
    org.jfree.data.general.PieDataset var26 = null;
    org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
    org.jfree.chart.util.RectangleInsets var28 = var27.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var29 = null;
    var27.setToolTipGenerator(var29);
    java.awt.Stroke var31 = var27.getBaseSectionOutlineStroke();
    java.awt.Paint var32 = var27.getLabelLinkPaint();
    var25.setItemPaint(var32);
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var36 = null;
    var34.setDomainAxisLocation(1, var36, false);
    java.awt.Stroke var39 = var34.getRangeCrosshairStroke();
    var34.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var42 = var34.getRootPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    var34.setRenderer(var43);
    java.awt.Paint var45 = var34.getDomainZeroBaselinePaint();
    var25.setItemPaint(var45);
    var25.setHeight(0.0d);
    java.lang.Object var49 = null;
    var4.add((org.jfree.chart.block.Block)var25, var49);
    org.jfree.chart.block.BlockFrame var51 = var25.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]");
//     org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
//     org.jfree.chart.text.TextFragment var3 = var1.getLastTextFragment();
//     java.awt.Graphics2D var4 = null;
//     java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var18 = null;
//     var16.setDomainAxisLocation(1, var18, false);
//     java.awt.Stroke var21 = var16.getRangeCrosshairStroke();
//     boolean var22 = var15.equals((java.lang.Object)var21);
//     java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var9, var21, (java.awt.Paint)var26, var27, 1.0f);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.text.TextAnchor var31 = var29.getLabelTextAnchor();
//     java.lang.String var32 = var31.toString();
//     float var33 = var3.calculateBaselineOffset(var4, var31);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setForegroundAlpha(1.0f);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.event.PlotChangeEvent var4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.Plot var5 = var4.getPlot();
//     org.jfree.chart.event.ChartChangeEventType var6 = var4.getType();
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var8 = var7.clone();
//     double var9 = var7.getLowerBound();
//     boolean var10 = var6.equals((java.lang.Object)var7);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setForegroundAlpha(1.0f);
//     java.awt.Font var15 = var12.getNoDataMessageFont();
//     var12.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var12);
//     java.awt.Paint var19 = var18.getBackgroundPaint();
//     var18.fireChartChanged();
//     org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var18);
//     int var22 = var18.getSubtitleCount();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.setForegroundAlpha(1.0f);
//     java.awt.Font var27 = var24.getNoDataMessageFont();
//     var24.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var24);
//     java.awt.RenderingHints var31 = var30.getRenderingHints();
//     var18.setRenderingHints(var31);
//     
//     // Checks the contract:  equals-hashcode on var12 and var24
//     assertTrue("Contract failed: equals-hashcode on var12 and var24", var12.equals(var24) ? var12.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var12
//     assertTrue("Contract failed: equals-hashcode on var24 and var12", var24.equals(var12) ? var24.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var30
//     assertTrue("Contract failed: equals-hashcode on var18 and var30", var18.equals(var30) ? var18.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var18
//     assertTrue("Contract failed: equals-hashcode on var30 and var18", var30.equals(var18) ? var30.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var0.setTickUnit(var2, false, true);
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var8 = var7.clone();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getLabelPadding();
//     var10.setSectionOutlinesVisible(true);
//     java.awt.Paint var14 = var10.getBaseSectionPaint();
//     var7.setAxisLinePaint(var14);
//     org.jfree.data.Range var16 = var7.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(100.0d, var16);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var19 = var18.clone();
//     org.jfree.data.Range var20 = var18.getRange();
//     org.jfree.data.Range var21 = org.jfree.data.Range.combine(var16, var20);
//     org.jfree.data.Range var23 = org.jfree.data.Range.shift(var20, 10.0d);
//     var0.setRange(var23, false, true);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var29 = var28.clone();
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getLabelPadding();
//     var31.setSectionOutlinesVisible(true);
//     java.awt.Paint var35 = var31.getBaseSectionPaint();
//     var28.setAxisLinePaint(var35);
//     org.jfree.data.Range var37 = var28.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(100.0d, var37);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var40 = var39.clone();
//     org.jfree.data.Range var41 = var39.getRange();
//     org.jfree.data.Range var42 = org.jfree.data.Range.combine(var37, var41);
//     boolean var44 = var37.contains(1.0E-5d);
//     var0.setRange(var37, false, false);
//     
//     // Checks the contract:  equals-hashcode on var10 and var31
//     assertTrue("Contract failed: equals-hashcode on var10 and var31", var10.equals(var31) ? var10.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var10
//     assertTrue("Contract failed: equals-hashcode on var31 and var10", var31.equals(var10) ? var31.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setDomainAxisLocation(1, var2, false);
    java.awt.Stroke var5 = var0.getRangeCrosshairStroke();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
    var0.zoomRangeAxes(0.0d, var9, var11, false);
    boolean var14 = var0.isDomainZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
    org.jfree.chart.labels.PieToolTipGenerator var4 = null;
    var2.setToolTipGenerator(var4);
    java.awt.Font var6 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
    var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
    java.lang.String var13 = var7.getURLText();
    java.lang.String var14 = var7.getToolTipText();
    boolean var15 = var7.getExpandToFitSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isRangeCrosshairVisible();
    org.jfree.chart.plot.Plot var2 = var0.getParent();
    org.jfree.chart.annotations.CategoryAnnotation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var4 = var0.removeAnnotation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var24 = null;
//     var22.setToolTipGenerator(var24);
//     java.awt.Stroke var26 = var22.getBaseSectionOutlineStroke();
//     java.awt.Paint var27 = var22.getLabelLinkPaint();
//     var20.setItemPaint(var27);
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Color var33 = var32.darker();
//     var20.setBackgroundPaint((java.awt.Paint)var33);
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var36 = null;
//     var35.setFixedDomainAxisSpace(var36, true);
//     var35.clearDomainMarkers(100);
//     org.jfree.chart.util.RectangleEdge var42 = var35.getRangeAxisEdge(0);
//     boolean var43 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var42);
//     boolean var44 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var42);
//     var20.setLegendItemGraphicEdge(var42);
//     org.jfree.chart.util.RectangleAnchor var46 = null;
//     var20.setLegendItemGraphicLocation(var46);
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     var48.setForegroundAlpha(1.0f);
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var55 = var54.clone();
//     org.jfree.chart.axis.ValueAxis[] var56 = new org.jfree.chart.axis.ValueAxis[] { var54};
//     var53.setDomainAxes(var56);
//     org.jfree.data.xy.XYDataset var59 = var53.getDataset(100);
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var63 = var62.getQuadrantOrigin();
//     var53.zoomRangeAxes(0.0d, var61, var63, false);
//     var48.zoomDomainAxes((-7.0d), var52, var63);
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var68 = var67.getLabelURL();
//     var67.configure();
//     java.awt.Paint var70 = var67.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var71 = var67.getTickLabelInsets();
//     double var73 = var71.calculateRightInset(0.05d);
//     var48.setAxisOffset(var71);
//     var20.setLegendItemGraphicPadding(var71);
//     
//     // Checks the contract:  equals-hashcode on var35 and var62
//     assertTrue("Contract failed: equals-hashcode on var35 and var62", var35.equals(var62) ? var35.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var35
//     assertTrue("Contract failed: equals-hashcode on var62 and var35", var62.equals(var35) ? var62.hashCode() == var35.hashCode() : true);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.general.DatasetChangeEvent var6 = null;
    var5.datasetChanged(var6);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    java.awt.Paint var9 = var5.getRangeZeroBaselinePaint();
    org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var4, var9);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var13 = var12.clone();
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelPadding();
    var15.setSectionOutlinesVisible(true);
    java.awt.Paint var19 = var15.getBaseSectionPaint();
    var12.setAxisLinePaint(var19);
    org.jfree.data.Range var21 = var12.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var24 = var23.getTickLabelFont();
    var12.setLabelFont(var24);
    org.jfree.data.general.PieDataset var26 = null;
    org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
    org.jfree.chart.util.RectangleInsets var28 = var27.getLabelPadding();
    boolean var29 = var27.getLabelLinksVisible();
    org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var32 = var31.getNextFillPaint();
    var27.setSectionOutlinePaint((java.lang.Comparable)"UnitType.ABSOLUTE", var32);
    org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("Size2D[width=3.0, height=0.0]", var24, var32, 2.0f);
    java.awt.Paint var36 = var35.getPaint();
    java.lang.String var37 = var35.getText();
    var10.addFragment(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "Size2D[width=3.0, height=0.0]"+ "'", var37.equals("Size2D[width=3.0, height=0.0]"));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "Range[0.0,1.0]"};
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("VerticalAlignment.CENTER", "poly", "Other", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var1 = null;
//     java.util.Date var2 = null;
//     var0.setRange(var1, var2);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var1 = null;
    var0.setMarkerBand(var1);
    java.awt.Font var3 = var0.getTickLabelFont();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var5 = var4.clone();
    var4.setVisible(false);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var10 = var9.clone();
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    org.jfree.chart.util.RectangleInsets var13 = var12.getLabelPadding();
    var12.setSectionOutlinesVisible(true);
    java.awt.Paint var16 = var12.getBaseSectionPaint();
    var9.setAxisLinePaint(var16);
    org.jfree.data.Range var18 = var9.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(100.0d, var18);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var21 = var20.clone();
    org.jfree.data.Range var22 = var20.getRange();
    org.jfree.data.Range var23 = org.jfree.data.Range.combine(var18, var22);
    var4.setRangeWithMargins(var22);
    var0.setRange(var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var28 = org.jfree.data.Range.expand(var22, (-1.88d), (-5.88d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
//     var4.setSectionOutlinesVisible(true);
//     java.awt.Paint var8 = var4.getBaseSectionPaint();
//     var1.setAxisLinePaint(var8);
//     org.jfree.data.Range var10 = var1.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var13 = var12.getTickLabelFont();
//     var1.setLabelFont(var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelPadding();
//     boolean var18 = var16.getLabelLinksVisible();
//     org.jfree.chart.plot.DefaultDrawingSupplier var20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var21 = var20.getNextFillPaint();
//     var16.setSectionOutlinePaint((java.lang.Comparable)"UnitType.ABSOLUTE", var21);
//     org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("Size2D[width=3.0, height=0.0]", var13, var21, 2.0f);
//     java.awt.Paint var25 = var24.getPaint();
//     java.awt.Graphics2D var26 = null;
//     java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var33);
//     org.jfree.chart.util.HorizontalAlignment var35 = null;
//     org.jfree.chart.util.VerticalAlignment var36 = null;
//     org.jfree.chart.block.ColumnArrangement var39 = new org.jfree.chart.block.ColumnArrangement(var35, var36, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var42 = null;
//     var40.setDomainAxisLocation(1, var42, false);
//     java.awt.Stroke var45 = var40.getRangeCrosshairStroke();
//     boolean var46 = var39.equals((java.lang.Object)var45);
//     java.awt.Color var50 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var51 = null;
//     org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var33, var45, (java.awt.Paint)var50, var51, 1.0f);
//     java.lang.Object var54 = var53.clone();
//     org.jfree.chart.text.TextAnchor var55 = var53.getLabelTextAnchor();
//     var24.draw(var26, (-1.0f), 0.5f, var55, 2.0f, (-1.0f), 1.0E-8d);
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("RectangleConstraintType.RANGE", 255, 100);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.data.general.PieDataset var2 = var1.getDataset();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var5.setDomainAxes(var8);
//     org.jfree.data.xy.XYDataset var11 = var5.getDataset(100);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
//     var5.zoomRangeAxes(0.0d, var13, var15, false);
//     org.jfree.chart.plot.PlotState var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     var1.draw(var3, var4, var15, var18, var19);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = null;
//     var2.setToolTipGenerator(var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6);
//     var7.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var7.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var7.setWidth((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.setForegroundAlpha(1.0f);
//     java.awt.Font var21 = var18.getNoDataMessageFont();
//     var18.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var18);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     org.jfree.chart.util.RectangleInsets var28 = var27.getLabelPadding();
//     org.jfree.chart.labels.PieToolTipGenerator var29 = null;
//     var27.setToolTipGenerator(var29);
//     java.awt.Font var31 = var27.getLabelFont();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var31);
//     var32.setPadding(0.05d, (-7.0d), 0.0d, 0.0d);
//     var32.setText("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var32.setURLText("Range[0.0,1.0]");
//     var24.setTitle(var32);
//     java.awt.RenderingHints var43 = var24.getRenderingHints();
//     org.jfree.chart.title.LegendTitle var45 = var24.getLegend((-65536));
//     var24.setBackgroundImageAlignment(15);
//     java.lang.Object var48 = var24.getTextAntiAlias();
//     var7.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var24);
//     
//     // Checks the contract:  equals-hashcode on var2 and var27
//     assertTrue("Contract failed: equals-hashcode on var2 and var27", var2.equals(var27) ? var2.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var2
//     assertTrue("Contract failed: equals-hashcode on var27 and var2", var27.equals(var2) ? var27.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
//     org.jfree.chart.util.HorizontalAlignment var14 = null;
//     org.jfree.chart.util.VerticalAlignment var15 = null;
//     org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setDomainAxisLocation(1, var21, false);
//     java.awt.Stroke var24 = var19.getRangeCrosshairStroke();
//     boolean var25 = var18.equals((java.lang.Object)var24);
//     java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var30 = null;
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var24, (java.awt.Paint)var29, var30, 1.0f);
//     java.lang.Object var33 = var32.clone();
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     java.awt.geom.Point2D var35 = var34.getQuadrantOrigin();
//     var34.setRangeCrosshairValue(10.0d, true);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = var34.getRendererForDataset(var39);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     var42.setForegroundAlpha(1.0f);
//     java.awt.Font var45 = var42.getNoDataMessageFont();
//     var42.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var42);
//     org.jfree.chart.axis.AxisLocation var49 = var42.getDomainAxisLocation();
//     var34.setRangeAxisLocation(var49);
//     boolean var51 = var32.equals((java.lang.Object)var34);
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     var53.setForegroundAlpha(1.0f);
//     boolean var56 = var53.isDomainGridlinesVisible();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     var53.setRenderer(var57, true);
//     org.jfree.chart.axis.AxisLocation var61 = var53.getRangeAxisLocation((-1));
//     var34.setDomainAxisLocation(0, var61, true);
//     var1.setDomainAxisLocation(var61);
//     int var65 = var1.getWeight();
//     java.awt.Color var70 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     org.jfree.chart.block.BlockBorder var71 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var70);
//     org.jfree.chart.util.HorizontalAlignment var72 = null;
//     org.jfree.chart.util.VerticalAlignment var73 = null;
//     org.jfree.chart.block.ColumnArrangement var76 = new org.jfree.chart.block.ColumnArrangement(var72, var73, 10.0d, (-1.0d));
//     org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisLocation var79 = null;
//     var77.setDomainAxisLocation(1, var79, false);
//     java.awt.Stroke var82 = var77.getRangeCrosshairStroke();
//     boolean var83 = var76.equals((java.lang.Object)var82);
//     java.awt.Color var87 = java.awt.Color.getHSBColor(0.0f, 1.0f, 1.0f);
//     java.awt.Stroke var88 = null;
//     org.jfree.chart.plot.ValueMarker var90 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var70, var82, (java.awt.Paint)var87, var88, 1.0f);
//     java.lang.Object var91 = var90.clone();
//     org.jfree.chart.text.TextAnchor var92 = var90.getLabelTextAnchor();
//     var1.addRangeMarker((org.jfree.chart.plot.Marker)var90);
//     
//     // Checks the contract:  equals-hashcode on var13 and var71
//     assertTrue("Contract failed: equals-hashcode on var13 and var71", var13.equals(var71) ? var13.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var13
//     assertTrue("Contract failed: equals-hashcode on var71 and var13", var71.equals(var13) ? var71.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var76
//     assertTrue("Contract failed: equals-hashcode on var18 and var76", var18.equals(var76) ? var18.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var18
//     assertTrue("Contract failed: equals-hashcode on var76 and var18", var76.equals(var18) ? var76.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var77
//     assertTrue("Contract failed: equals-hashcode on var19 and var77", var19.equals(var77) ? var19.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var19
//     assertTrue("Contract failed: equals-hashcode on var77 and var19", var77.equals(var19) ? var77.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var90
//     assertTrue("Contract failed: equals-hashcode on var32 and var90", var32.equals(var90) ? var32.hashCode() == var90.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var90 and var32
//     assertTrue("Contract failed: equals-hashcode on var90 and var32", var90.equals(var32) ? var90.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var91
//     assertTrue("Contract failed: equals-hashcode on var33 and var91", var33.equals(var91) ? var33.hashCode() == var91.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var91 and var33
//     assertTrue("Contract failed: equals-hashcode on var91 and var33", var91.equals(var33) ? var91.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setForegroundAlpha(1.0f);
    java.awt.Font var4 = var1.getNoDataMessageFont();
    var1.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    boolean var22 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(10);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 0);
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleConstraintType.RANGE", var1);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelPadding();
    var4.setSectionOutlinesVisible(true);
    java.awt.Paint var8 = var4.getBaseSectionPaint();
    var1.setAxisLinePaint(var8);
    org.jfree.data.Range var10 = var1.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, var10);
    org.jfree.chart.block.LengthConstraintType var12 = var11.getHeightConstraintType();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.setForegroundAlpha(1.0f);
    java.awt.Font var17 = var14.getNoDataMessageFont();
    var14.setAnchorValue(100.0d);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.axis.AxisLocation var21 = var14.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var22 = var14.getDomainAxisLocation();
    org.jfree.chart.util.HorizontalAlignment var23 = null;
    org.jfree.chart.util.VerticalAlignment var24 = null;
    org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 10.0d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var28 = null;
    org.jfree.chart.util.VerticalAlignment var29 = null;
    org.jfree.chart.block.ColumnArrangement var32 = new org.jfree.chart.block.ColumnArrangement(var28, var29, 100.0d, 1.0d);
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14, (org.jfree.chart.block.Arrangement)var27, (org.jfree.chart.block.Arrangement)var32);
    boolean var34 = var12.equals((java.lang.Object)var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    var14.setRenderer(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.setForegroundAlpha(1.0f);
//     java.awt.Font var4 = var1.getNoDataMessageFont();
//     var1.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.axis.AxisLocation var8 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 10.0d, (-1.0d));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 1.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     java.awt.Font var22 = var20.getItemFont();
//     org.jfree.chart.block.BlockFrame var23 = var20.getFrame();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.setForegroundAlpha(1.0f);
//     java.awt.Font var28 = var25.getNoDataMessageFont();
//     var25.setAnchorValue(100.0d);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (org.jfree.chart.plot.Plot)var25);
//     java.awt.Paint var32 = var31.getBackgroundPaint();
//     var31.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var34 = var31.getPadding();
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
//     org.jfree.chart.util.RectangleInsets var37 = var36.getLabelPadding();
//     boolean var38 = var34.equals((java.lang.Object)var36);
//     double var40 = var34.calculateLeftOutset(0.05d);
//     java.lang.String var41 = var34.toString();
//     var20.setItemLabelPadding(var34);
//     
//     // Checks the contract:  equals-hashcode on var1 and var25
//     assertTrue("Contract failed: equals-hashcode on var1 and var25", var1.equals(var25) ? var1.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var1
//     assertTrue("Contract failed: equals-hashcode on var25 and var1", var25.equals(var1) ? var25.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var31
//     assertTrue("Contract failed: equals-hashcode on var7 and var31", var7.equals(var31) ? var7.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var7
//     assertTrue("Contract failed: equals-hashcode on var31 and var7", var31.equals(var7) ? var31.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setTickMarksVisible(false);
    var0.setLabelToolTip("Range[0.0,1.0]");
    float var5 = var0.getTickMarkOutsideLength();
    var0.setLabelURL("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    var0.setAutoTickUnitSelection(false, false);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.lang.Object var12 = var11.clone();
    org.jfree.chart.util.RectangleInsets var13 = var11.getLabelInsets();
    double var15 = var13.calculateRightOutset(100.0d);
    var0.setLabelInsets(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 3.0d);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setAutoRangeIncludesZero(true);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("UnitType.ABSOLUTE", "UnitType.ABSOLUTE");
    java.lang.String var3 = var2.getName();
    java.lang.String var4 = var2.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "UnitType.ABSOLUTE"+ "'", var3.equals("UnitType.ABSOLUTE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "UnitType.ABSOLUTE"+ "'", var4.equals("UnitType.ABSOLUTE"));

  }

}
